#!/usr/bin/env python3
"""Q11: static_swapped — 型の割り当てを入れ替える（struct→e6/e7、payload→e0/e1）。

問い:
  Q8〜Q10 で「型で分けると等 FLOPs の dense より強い」ことは分かった。
  しかし **「分ければ何でもよい」のか「payload に大きな expert を割り当てる必要がある」のか**は
  分離していない。dense224x2（全トークン→e6/e7）は崩壊したので「payload が細いから負ける」は
  すでに否定されている（payload は 224 をもらっていた）。残る候補は
    (a) struct を大きな expert に入れると害（勾配干渉）
    (b) 割り当てそのものが重要（payload は大きな expert でなければならない）
   swapped は (b) を直接叩く。payload が幅 32 になるので、(b) が正しければ崩壊する。
  もし swapped が static_type と同等なら、**割り当ては無関係で「分離」だけが効いている**。

条件（hard、同一プロセス・同一 seed）:
  dynamic_lb     : 学習ルータ（参照）
  static_type    : struct→e0+e1(32), payload→e6+e7(224)   ← 正しい割り当て
  static_1x      : struct→e0(32),    payload→e6(224)      ← 2 本平均なし（Q10 の最良効率）
  static_swapped : struct→e6+e7(224), payload→e0+e1(32)   ← **入れ替え**

実装: q10_single_expert の `forward_pool` と POOLS をそのまま使い、swapped を 1 つ足すだけ。
"""
import argparse
import json
import os
import sys

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import q10_single_expert as Q10  # noqa: E402  （import 時に Q8.forward_dispatch をパッチする）
import q8_static_dispatch as Q8  # noqa: E402

# struct に大きな expert、payload に小さな expert
Q10.POOLS["static_swapped"] = ([(6, 0.5), (7, 0.5)], [(0, 0.5), (1, 0.5)])

OUTDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q11")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", nargs="+", default=["hard"])
    ap.add_argument("--modes", nargs="+",
                    default=["dynamic_lb", "static_type", "static_1x", "static_swapped"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4, 5])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--threads", type=int, default=6)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--outdir", default=None)
    args = ap.parse_args()

    global OUTDIR
    if args.outdir:
        OUTDIR = os.path.join(HERE, args.outdir)
    Q8.OUTDIR = OUTDIR
    os.makedirs(OUTDIR, exist_ok=True)
    torch.set_num_threads(args.threads)
    print(f"Q11: tasks={args.tasks} modes={args.modes} seeds={args.seeds}", flush=True)

    rows = []
    for task in args.tasks:
        for mode in args.modes:
            for seed in args.seeds:
                p = os.path.join(OUTDIR, f"H+LB_{task}_{mode}_s{seed}.json")
                if args.resume and os.path.exists(p):
                    with open(p, encoding="utf-8") as f:
                        r = json.load(f)
                    if r.get("n_eval") == 1024:
                        print(f"  [skip] {task} {mode} s{seed}", flush=True)
                        rows.append(r)
                        continue
                r = Q8.run(task, mode, seed, args.seqs, args.epochs, args.bs, args.lr)
                rows.append(r)
                e = r["eval"]["base"]
                print(f"  -> {task} {mode} s{seed}: "
                      f"acc pl={e['acc_payload']:.4f} iv={e['instr_valid']:.3f} "
                      f"ce pl={e['ce_payload']:.4f} "
                      f"w_st/pl={e['width_struct']:.1f}/{e['width_payload']:.1f}", flush=True)
                with open(p, "w", encoding="utf-8") as f:
                    json.dump(r, f, ensure_ascii=False, indent=2)

    with open(os.path.join(OUTDIR, "q11_results.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
    print(f"[write] {OUTDIR}", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
