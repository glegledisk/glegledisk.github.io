#!/usr/bin/env python3
"""Q6: 難度重み付き p_pen の集計・検定スクリプト。"""
import json
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q6")


def load_data():
    results = {}
    modes = ["base", "dw_soft", "dw_hard"]
    for mode in modes:
        results[mode] = []
        for seed in range(6):
            p = os.path.join(DATA_DIR, f"H+LB_compute_{mode}_s{seed}.json")
            if not os.path.exists(p):
                return None
            with open(p, encoding="utf-8") as f:
                results[mode].append(json.load(f))
    return results


def analyze():
    data = load_data()
    if data is None:
        print("Data not yet fully ready.")
        return

    modes = ["base", "dw_soft", "dw_hard"]
    summary = {}

    print("=" * 80)
    print("Q6: DIFFICULTY-WEIGHTED P_PEN ANALYSIS")
    print("=" * 80)

    for m in modes:
        runs = data[m]
        d_list = []
        w_st_list = []
        w_pl_list = []
        acc_pl_list = []
        ce_pl_list = []
        ent_list = []

        for r in runs:
            e = r["eval"]["base"]
            d = e["small_payload"] - e["small_struct"]
            d_list.append(d)
            w_st_list.append(e["width_struct"])
            w_pl_list.append(e["width_payload"])
            acc_pl_list.append(e["acc_payload"])
            ce_pl_list.append(e["ce_payload"])
            ent_list.append(e["usage_entropy"])

        summary[m] = {
            "delta": np.array(d_list),
            "width_st": np.array(w_st_list),
            "width_pl": np.array(w_pl_list),
            "acc_pl": np.array(acc_pl_list),
            "ce_pl": np.array(ce_pl_list),
            "entropy": np.array(ent_list),
        }

        print(f"\n[{m}] (n={len(runs)})")
        print(f"  Δ           : mean={np.mean(d_list):+.4f}, se={stats.sem(d_list):.4f}, "
              f"sd={np.std(d_list, ddof=1):.4f}, values={[round(x, 3) for x in d_list]}")
        print(f"  width_st    : mean={np.mean(w_st_list):.2f}, se={stats.sem(w_st_list):.2f}")
        print(f"  width_pl    : mean={np.mean(w_pl_list):.2f}, se={stats.sem(w_pl_list):.2f}")
        print(f"  acc_payload : mean={np.mean(acc_pl_list):.4f}, se={stats.sem(acc_pl_list):.4f}")
        print(f"  ce_payload  : mean={np.mean(ce_pl_list):.4f}, se={stats.sem(ce_pl_list):.4f}")
        print(f"  entropy     : mean={np.mean(ent_list):.4f}")

    # Paired comparisons (dw_soft vs base, dw_hard vs base)
    print("\n" + "=" * 80)
    print("PAIRED COMPARISONS (n=6, df=5)")
    print("=" * 80)

    for cand in ["dw_soft", "dw_hard"]:
        print(f"\n--- {cand} minus base ---")
        for key in ["delta", "width_pl", "width_st", "acc_pl", "ce_pl"]:
            diff = summary[cand][key] - summary["base"][key]
            m_diff = np.mean(diff)
            se_diff = stats.sem(diff)
            t_val = m_diff / (se_diff + 1e-12)
            p_val = stats.t.sf(np.abs(t_val), df=5) * 2
            sign_str = f"{np.sum(diff > 0)}/{len(diff)} 正" if m_diff > 0 else f"{np.sum(diff < 0)}/{len(diff)} 負"
            print(f"  Δ {key:<10}: {m_diff:+.4f} (se={se_diff:.4f}, t={t_val:+.2f}, p={p_val:.4f}, {sign_str})")

    # Save to json
    out_json = {}
    for m in modes:
        out_json[m] = {k: v.tolist() for k, v in summary[m].items()}
        out_json[m]["mean"] = {k: float(np.mean(v)) for k, v in summary[m].items()}
        out_json[m]["se"] = {k: float(stats.sem(v)) for k, v in summary[m].items()}

    with open(os.path.join(DATA_DIR, "q6_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(out_json, f, ensure_ascii=False, indent=2)
    print(f"\nSaved analysis to {os.path.join(DATA_DIR, 'q6_analysis.json')}")


if __name__ == "__main__":
    analyze()
