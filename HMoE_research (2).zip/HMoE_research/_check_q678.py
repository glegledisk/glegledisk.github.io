#!/usr/bin/env python3
"""Q6/Q7/Q8（Antigravity 作）の独立検算。

やること:
  1. 生 json から全数値を再計算し、報告書の表と突合
  2. 報告書が検定していない主張に検定を付ける（instr_valid など）
  3. 報告書が触れていない交絡を測る
     - Q6: dw_hard が実際に「どの型のトークンを免除したか」（w_norm の再配分）
     - Q7: dead expert を全層で数え直す / auxw=0.05 の dead が本当に 0 か
     - Q8: 同一条件のはずの Q7 と Q8 の重みが一致するか（forward 再実装の検証）
  4. Q8 の等幅対照の欠落を数値で示す（payload 幅と概算 FLOPs）
"""
import json
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))
D = os.path.join(HERE, "simulation_hmoe_mmlu", "data")

OUT = []
def w(s=""):
    print(s)
    OUT.append(s)


def st(x):
    x = np.asarray(x, float)
    n = len(x)
    m = x.mean()
    sd = x.std(ddof=1) if n > 1 else 0.0
    se = sd / np.sqrt(n) if n > 1 else 0.0
    t = m / se if se > 0 else 0.0
    p = 2 * stats.t.sf(abs(t), df=n - 1) if se > 0 else 1.0
    return m, sd, se, t, p, int((x > 0).sum()), int((x < 0).sum())


def load(d, name):
    with open(os.path.join(D, d, name), encoding="utf-8") as f:
        return json.load(f)


def line(tag, x, unit=""):
    m, sd, se, t, p, npos, nneg = st(x)
    w(f"    {tag:<26} {m:+.4f}{unit}  se {se:.4f}  t {t:+.2f}  p {p:.4f}  正{npos}/負{nneg}  n={len(x)}")
    return m, se, t, p


# =====================================================================
w("=" * 78)
w("Q6 検算: 難度重み付き p_pen")
w("=" * 78)

MODES = ["base", "dw_soft", "dw_hard"]
SEEDS = range(6)
q6 = {}
for m in MODES:
    rows = [load("q6", f"H+LB_compute_{m}_s{s}.json") for s in SEEDS]
    e = [r["eval"]["base"] for r in rows]
    q6[m] = {
        "delta": np.array([x["small_payload"] - x["small_struct"] for x in e]),
        "w_pl": np.array([x["width_payload"] for x in e]),
        "w_st": np.array([x["width_struct"] for x in e]),
        "s_st": np.array([x["small_struct"] for x in e]),
        "s_pl": np.array([x["small_payload"] for x in e]),
        "acc_pl": np.array([x["acc_payload"] for x in e]),
        "ce_pl": np.array([x["ce_payload"] for x in e]),
        "iv": np.array([x["instr_valid"] for x in e]),
        "H": np.array([x["usage_entropy"] for x in e]),
        "loss": np.array([r["loss_hist"][-1] for r in rows]),
        "nparam": rows[0]["nparam"],
    }

w("\n[1] 水準（報告書 §2 の表と突合）")
for m in MODES:
    v = q6[m]
    w(f"  {m:<8} Δ={v['delta'].mean():+.4f} (se {st(v['delta'])[2]:.4f})  "
      f"w_st={v['w_st'].mean():.1f}  w_pl={v['w_pl'].mean():.1f}  "
      f"acc_pl={v['acc_pl'].mean():.4f}  iv={v['iv'].mean():.3f}  H={v['H'].mean():.3f}  "
      f"nparam={v['nparam']}")
w(f"  per-seed Δ base    : {', '.join(f'{x:+.3f}' for x in q6['base']['delta'])}")
w(f"  per-seed Δ dw_soft : {', '.join(f'{x:+.3f}' for x in q6['dw_soft']['delta'])}")
w(f"  per-seed Δ dw_hard : {', '.join(f'{x:+.3f}' for x in q6['dw_hard']['delta'])}")

w("\n[2] 対応差（報告書 §3 の再計算）")
for base in ["base"]:
    for m in ["dw_soft", "dw_hard"]:
        w(f"  --- {m} − {base} ---")
        for k, lab in [("delta", "Δ"), ("w_st", "width_struct"), ("w_pl", "width_payload"),
                       ("s_st", "small_struct"), ("s_pl", "small_payload"),
                       ("acc_pl", "acc_payload")]:
            line(lab, q6[m][k] - q6[base][k])

w("\n[3] 報告書が検定していない主張")
w("  (a) instr_valid は「向上する」と §0-5 / §5 に書かれているが検定が無い")
line("instr_valid (dw_hard−base)", q6["dw_hard"]["iv"] - q6["base"]["iv"])
line("instr_valid (dw_soft−base)", q6["dw_soft"]["iv"] - q6["base"]["iv"])
w(f"    base    iv per-seed: {', '.join(f'{x:.3f}' for x in q6['base']['iv'])}")
w(f"    dw_hard iv per-seed: {', '.join(f'{x:.3f}' for x in q6['dw_hard']['iv'])}")
w(f"    base    iv 中央値 {np.median(q6['base']['iv']):.3f} / dw_hard 中央値 {np.median(q6['dw_hard']['iv']):.3f}")
w("    → 平均の差は seed2 の救済（0.054→0.949）と seed4 の崩壊（0.978→0.471）の交換")

w("\n[4] Q5 との整合（報告書 §2 の「ほぼ完全一致」）")
try:
    q5 = [load("q5", f"H+LB_compute_aw0.05_s{s}.json")["eval"]["base"] for s in SEEDS]
    d5 = np.array([x["small_payload"] - x["small_struct"] for x in q5])
    w(f"  Q5 aw0.05 : Δ={d5.mean():+.4f} (se {st(d5)[2]:.4f})  w_pl={np.mean([x['width_payload'] for x in q5]):.1f}  "
      f"w_st={np.mean([x['width_struct'] for x in q5]):.1f}  acc_pl={np.mean([x['acc_payload'] for x in q5]):.4f}")
    w(f"  Q6 base   : Δ={q6['base']['delta'].mean():+.4f}  w_pl={q6['base']['w_pl'].mean():.1f}  "
      f"w_st={q6['base']['w_st'].mean():.1f}  acc_pl={q6['base']['acc_pl'].mean():.4f}")
    line("Δ の対応差 (Q6base−Q5)", q6["base"]["delta"] - d5)
    w("    → 対応差が 0 でなければ「ビット精度水準で一致」ではない")
except FileNotFoundError as exc:
    w(f"  [skip] {exc}")


# =====================================================================
w("\n" + "=" * 78)
w("Q7 検算: 負荷分散損失の完全切除")
w("=" * 78)

CONDS = [(a, t, aw) for a in ["H+LB", "U+LB"] for t in ["compute", "hard"] for aw in [0.0, 0.05]]
q7 = {}
for arm, task, aw in CONDS:
    rows = [load("q7", f"{arm}_{task}_aw{aw:g}_s{s}.json") for s in SEEDS]
    e = [r["eval"]["base"] for r in rows]
    key = f"{arm}|{task}|{aw:g}"
    q7[key] = {
        "iv": np.array([x["instr_valid"] for x in e]),
        "acc_pl": np.array([x["acc_payload"] for x in e]),
        "w_pl": np.array([x["width_payload"] for x in e]),
        "w_st": np.array([x["width_struct"] for x in e]),
        "delta": np.array([x["small_payload"] - x["small_struct"] for x in e]),
        "H": np.array([x["usage_entropy"] for x in e]),
        "ms": np.array([x["usage_share_max"] for x in e]),
        "dead": np.array([x["dead_experts"] for x in e]),
        "dead_all": np.array([np.mean(x["layer_dead_experts"]) for x in e]),
        "dead_max": np.array([np.max(x["layer_dead_experts"]) for x in e]),
    }

w("\n[1] 水準（報告書 §2 の表と突合。dead は L0 のみ／全層平均を併記）")
for arm, task, aw in CONDS:
    v = q7[f"{arm}|{task}|{aw:g}"]
    w(f"  {arm:<5} {task:<8} aw{aw:<4} iv={v['iv'].mean():.3f} (se {st(v['iv'])[2]:.3f})  "
      f"H={v['H'].mean():.3f}  ms={v['ms'].mean():.3f}  deadL0={v['dead'].mean():.2f}  "
      f"dead全層={v['dead_all'].mean():.2f} (最大層 {v['dead_max'].mean():.2f})  "
      f"w_pl={v['w_pl'].mean():.1f}")

w("\n[2] 対応差 aw0 − aw0.05")
for arm, task in [(a, t) for a in ["H+LB", "U+LB"] for t in ["compute", "hard"]]:
    a0 = q7[f"{arm}|{task}|0"]
    a5 = q7[f"{arm}|{task}|0.05"]
    w(f"  --- {arm} {task} ---")
    for k, lab in [("iv", "instr_valid"), ("acc_pl", "acc_payload"), ("w_pl", "width_payload"),
                   ("delta", "Δ"), ("H", "entropy"), ("ms", "maxshare"), ("dead", "dead_experts")]:
        line(lab, a0[k] - a5[k])

w("\n[3] 「auxw=0.05 では死滅 0 個（全 48 条件で厳密に 0）」の検査")
z = []
for arm, task, aw in CONDS:
    if aw == 0.05:
        v = q7[f"{arm}|{task}|{aw:g}"]
        z.append((arm, task, v["dead"].tolist()))
for arm, task, lst in z:
    w(f"  {arm:<5} {task:<8} aw0.05 dead L0 per-seed = {lst}  (合計 {sum(lst)})")
w(f"  → aw0.05 で dead>=1 のラン数: {sum(sum(l) for _, _, l in z)} 個の expert-seed")

w("\n[4] 報告書が検定していない主張")
w("  (a) H compute の instr_valid 改善は 3/6 正で n.s. なのに §0-3 / §3 で「向上」と断定")
w("  (b) HMoE の方が集中が緩和（cross-architecture）は検定が無い → Welch t")
h = q7["H+LB|hard|0"]["ms"]
u = q7["U+LB|hard|0"]["ms"]
tt = stats.ttest_ind(h, u, equal_var=False)
w(f"    maxshare H hard aw0 = {h.mean():.3f} vs U = {u.mean():.3f}  "
  f"Welch t={tt.statistic:+.2f} p={tt.pvalue:.4f}  （n=6 vs 6、構成が違うので参考値）")
hc = q7["H+LB|compute|0"]["ms"]
uc = q7["U+LB|compute|0"]["ms"]
tt2 = stats.ttest_ind(hc, uc, equal_var=False)
w(f"    compute では H {hc.mean():.3f} vs U {uc.mean():.3f}  Welch t={tt2.statistic:+.2f} p={tt2.pvalue:.4f}"
  f"  → 主張の向きが hard 依存")


# =====================================================================
w("\n" + "=" * 78)
w("Q8 検算: 静的型ディスパッチ")
w("=" * 78)

MODES8 = ["dynamic_lb", "dynamic_no_lb", "static_type"]
q8 = {}
for task in ["compute", "hard"]:
    for m in MODES8:
        rows = [load("q8", f"H+LB_{task}_{m}_s{s}.json") for s in SEEDS]
        e = [r["eval"]["base"] for r in rows]
        q8[f"{task}|{m}"] = {
            "iv": np.array([x["instr_valid"] for x in e]),
            "acc_pl": np.array([x["acc_payload"] for x in e]),
            "ce_pl": np.array([x["ce_payload"] for x in e]),
            "w_pl": np.array([x["width_payload"] for x in e]),
            "w_st": np.array([x["width_struct"] for x in e]),
            "dead": np.array([x["dead_experts"] for x in e]),
            "H": np.array([x["usage_entropy"] for x in e]),
            "ms": np.array([x["usage_share_max"] for x in e]),
            "usage": [x["usage_l0"] for x in e],
            "nparam": rows[0]["nparam"],
        }

w("\n[1] 水準（報告書 §2/§3 の表と突合）")
for task in ["compute", "hard"]:
    for m in MODES8:
        v = q8[f"{task}|{m}"]
        w(f"  {task:<8} {m:<15} iv={v['iv'].mean():.3f} (se {st(v['iv'])[2]:.3f})  "
          f"acc_pl={v['acc_pl'].mean():.4f}  ce_pl={v['ce_pl'].mean():.4f}  "
          f"w_st={v['w_st'].mean():.1f} w_pl={v['w_pl'].mean():.1f}  "
          f"dead(JSON)={v['dead'].mean():.1f}  H={v['H'].mean():.3f}  nparam={v['nparam']}")

w("\n[2] 対応差")
for task in ["compute", "hard"]:
    for base in ["dynamic_lb", "dynamic_no_lb"]:
        w(f"  --- {task}: static_type − {base} ---")
        for k, lab in [("iv", "instr_valid"), ("acc_pl", "acc_payload"), ("ce_pl", "ce_payload"),
                       ("w_pl", "width_payload")]:
            line(lab, q8[f"{task}|static_type"][k] - q8[f"{task}|{base}"][k])

w("\n[3] compute の seed1 除外（報告書 §3 の「5 seed 平均 0.989」）")
iv = q8["compute|static_type"]["iv"]
w(f"  static_type compute iv per-seed: {', '.join(f'{x:.3f}' for x in iv)}")
w(f"  全 6 seed 平均 = {iv.mean():.3f} / seed1 除外 5 seed 平均 = {np.delete(iv,1).mean():.3f}")
w(f"  dynamic_lb compute iv 平均 = {q8['compute|dynamic_lb']['iv'].mean():.3f}")
w(f"  → 除外しなければ static_type は dynamic_lb より {iv.mean()-q8['compute|dynamic_lb']['iv'].mean():+.3f} 低い")

w("\n[4] dead expert の定義（報告書は「0.0/4」と書くが JSON は別）")
for task in ["compute", "hard"]:
    v = q8[f"{task}|static_type"]
    w(f"  {task}: JSON dead_experts per-seed = {v['dead'].tolist()}  usage_l0(s0) = {v['usage'][0]}")
w("  → 記録されるのは top-1 スロットだけ。static では常に e0 か e6 なので H/maxshare/dead は構成上意味を持たない")
w("  → e2〜e5 は 36 ラン全てで未使用（パラメータの半分を捨てている）")

w("\n[5] 等幅対照の欠落（payload 幅と概算 FLOPs）")
for m in MODES8:
    wp = q8[f"hard|{m}"]["w_pl"].mean()
    ffn = 4 * 128 * wp
    att = 4 * 128 * 128
    w(f"  {m:<15} payload 幅 {wp:6.1f}  FFN FLOPs/token/layer {ffn:8.0f}  "
      f"総計の比 {(att+ffn)/(att+4*128*q8['hard|dynamic_lb']['w_pl'].mean()):.2f}×")
w("  → static は payload 幅 2.6 倍。Q1〜Q7 の「幅」の効果と分離できていない")


# =====================================================================
w("\n" + "=" * 78)
w("交差検証: Q7 と Q8 の「同一条件」は同一か")
w("=" * 78)

import torch  # noqa: E402
import q2_difficulty_ladder as Q2  # noqa: E402
from e2b_rewrite_routing_fixed import RewriteMoE, WIDTHS  # noqa: E402
import q8_static_dispatch as Q8M  # noqa: E402

w("\n[1] チェックポイントの重みを直接比較（H+LB hard aw0 / dynamic_no_lb）")
for s in range(3):
    p7 = os.path.join(D, "q7", f"ckpt_H+LB_hard_aw0.0_s{s}.pt")
    p8 = os.path.join(D, "q8", f"ckpt_H+LB_hard_dynamic_no_lb_s{s}.pt")
    if not (os.path.exists(p7) and os.path.exists(p8)):
        w(f"  s{s}: ファイル無し")
        continue
    a = torch.load(p7, map_location="cpu")
    b = torch.load(p8, map_location="cpu")
    common = set(a) & set(b)
    md = max(float((a[k] - b[k]).abs().max()) for k in common)
    w(f"  s{s}: 共通キー {len(common)}  max|Δw| = {md:.3e}")

w("\n[2] 同じ重みに 2 つの forward を当てて CE を比較")
s = 0
p7 = os.path.join(D, "q7", f"ckpt_H+LB_hard_aw0.0_s{s}.pt")
if os.path.exists(p7):
    model = RewriteMoE(WIDTHS["H+LB"], seed=s)
    sd = torch.load(p7, map_location="cpu")
    with torch.no_grad():
        for k, v in model.params().items():
            v.copy_(sd[k])
    ev_rng = np.random.default_rng(777)
    seq, typ = Q2.make_trace_batch(ev_rng, 256, task="hard")
    x = torch.from_numpy(seq)
    t_b = torch.from_numpy(typ)
    with torch.no_grad():
        lg_q2, _ = Q2.forward_q(model, x, need_idx=True)
        lg_q8, _, _ = Q8M.forward_dispatch(model, x, typ=t_b, mode="dynamic_no_lb")
    w(f"  max|logit 差| = {float((lg_q2 - lg_q8).abs().max()):.3e}  "
      f"（0 でなければ Q8 の forward は Q2 と別物）")

w("\n[3] 同じ重みを 2 つの evaluate で測って instr_valid を比較")
if os.path.exists(p7):
    seq2, typ2 = Q2.make_trace_batch(np.random.default_rng(777), 1024, task="hard")
    ev7 = Q2.evaluate(model, seq2, typ2, {"base": (None, None)})["base"]
    ev8 = Q8M.evaluate_q8(model, seq2, typ2, mode="dynamic_no_lb")
    w(f"  Q8.evaluate_q8 : iv={ev8['instr_valid']:.3f}  w_pl={ev8['width_payload']:.1f}  "
      f"dead={ev8['dead_experts']}")
    w(f"  Q2.evaluate    : iv={ev7.get('instr_valid', float('nan')):.3f}  "
      f"w_pl={ev7.get('width_payload', float('nan')):.1f}")
    w(f"  記録済み Q7 json (s0, hard aw0) : iv={load('q7','H+LB_hard_aw0_s0.json')['eval']['base']['instr_valid']:.3f}")

w("\n[4] Q6 base と Q5 aw0.05 の重み比較")
p6 = os.path.join(D, "q6", "ckpt_H+LB_compute_base_s0.pt")
p5 = os.path.join(D, "q5", "ckpt_H+LB_compute_aw0.05_s0.pt")
if os.path.exists(p6) and os.path.exists(p5):
    a = torch.load(p6, map_location="cpu")
    b = torch.load(p5, map_location="cpu")
    common = set(a) & set(b)
    md = max(float((a[k] - b[k]).abs().max()) for k in common)
    w(f"  共通キー {len(common)}  max|Δw| = {md:.3e}")
else:
    w(f"  ファイル: q6={os.path.exists(p6)} q5={os.path.exists(p5)}")


# =====================================================================
w("\n" + "=" * 78)
w("Q6 の機構: dw_hard は実際に何を免除したか")
w("=" * 78)
p6 = os.path.join(D, "q6", "ckpt_H+LB_compute_base_s0.pt")
if os.path.exists(p6):
    model = RewriteMoE(WIDTHS["H+LB"], seed=0)
    sd = torch.load(p6, map_location="cpu")
    with torch.no_grad():
        for k, v in model.params().items():
            v.copy_(sd[k])
    seq, typ = Q2.make_trace_batch(np.random.default_rng(777), 512, task="compute")
    x = torch.from_numpy(seq)
    with torch.no_grad():
        lg, _ = Q2.forward_q(model, x, need_idx=True)
    import torch.nn.functional as F
    lg2 = lg[:, Q2.TRACE0 - 1:-1, :len(Q2.VOCAB)]
    tgt = torch.from_numpy(seq[:, Q2.TRACE0:])
    ce = F.cross_entropy(lg2.reshape(-1, len(Q2.VOCAB)), tgt.reshape(-1),
                         reduction="none").reshape(len(seq), -1).numpy()
    ty = typ[:, Q2.TRACE0:]
    med = float(np.median(ce))
    m_st = ty == Q2.TYP_STRUCT
    m_pl = ty == Q2.TYP_PAYLOAD
    w(f"  trace 全体の CE 中央値 = {med:.4f}")
    w(f"  CE 中央値: struct {float(np.median(ce[m_st])):.4f} / payload {float(np.median(ce[m_pl])):.4f}")
    w(f"  免除される割合（CE > 中央値）: struct {float((ce[m_st] > med).mean()):.3f}  "
      f"payload {float((ce[m_pl] > med).mean()):.3f}")
    w(f"  → 免除されるのはほぼ payload だけ。struct は 100% ペナルティを払い続ける")
    T = ce.shape[1] + Q2.TRACE0
    n_in = Q2.TRACE0 - 1
    keep = 1.0 - (ce > med).mean()
    mean_w = (n_in * 1.0 + (T - n_in - 1) * keep + 1.0) / T
    w(f"  レイアウト: T={T}, 入力 {n_in} 位置 + trace {T - n_in - 1} + 末尾 1")
    w(f"  w の平均 = {mean_w:.3f} → w_norm(残存トークン) = {1/mean_w:.3f}")
    w(f"  つまり残った側のペナルティは {1/mean_w:.2f} 倍に**増える**（除いた分は消えない）")
    w(f"  payload の実効重み = {1/mean_w:.2f} × {1-(ce[m_pl] > med).mean():.3f} = "
      f"{(1/mean_w)*(1-(ce[m_pl] > med).mean()):.2f}（base は 1.00）")
    w(f"  struct の実効重み = {1/mean_w:.2f} × {1-(ce[m_st] > med).mean():.3f} = "
      f"{(1/mean_w)*(1-(ce[m_st] > med).mean()):.2f}（base は 1.00）")

with open(os.path.join(HERE, "q678_check_out_utf8.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(OUT) + "\n")
print("\n[written] q678_check_out_utf8.txt")
