# -*- coding: utf-8 -*-
"""e4d_lambda_sweep.py — E4d 追試: コスト重み λ を振って「使わない」理由を特定する

E4d 本番の結果:
  edit_count は AUC(rin)=0.599（ベイズ上限 0.621 の 96%）なのに、
  選択性 Δ = -0.002、FFN コスト = 0.974（ほぼ未使用）、CE も不変。

仮説: λ=0.15 では「信号を使って恒等パスに流す」経済的便益が損失を下回るため、
      ルータは**合理的に**使っていない（最適化失敗ではない）。

  λ=0.15 での損益（ベイズ最適ポリシー t=0.13: 61.2% を恒等へ、うち 9.83% が編集）:
    便益 = 0.15 × 0.612 = +0.092 nats
    損失 = 誤って流す 6.0% のトークンが +2.1 nats ≈ -0.126 nats
    正味 = -0.034  → 使わない方が得

  λ を上げれば正味が正に転じ、Δ が立ち上がるはず。
  → λ ∈ {0.4, 0.8, 1.6} で edit_count を再実行し、閾値を同定する。
"""
import os, json, time
import numpy as np
import pandas as pd
from e4d_prefix_stats import run_arm

HERE = os.path.dirname(os.path.abspath(__file__))
LAMS = [0.4, 0.8, 1.6]
ARMS = ["edit_count", "baseline"]
SEEDS = [0, 1, 2]

rows = []
t0 = time.time()
for arm in ARMS:
    for lam in LAMS:
        for s in SEEDS:
            r = run_arm(arm, s, lam_cost=lam)
            r["lam"] = lam
            rows.append(r)
            print(f"  {arm:11s} λ={lam:4.2f} s{s} | Δ {r['sel_delta']:+.3f} | FFN {r['ffn_cost']:.3f} "
                  f"| CE {r['ce_all']:.4f} | acc {r['acc_all']:.4f} | AUC(rin) {r['auc_rin_lin']:.3f}",
                  flush=True)
        print(f"    ({time.time()-t0:.0f}s)", flush=True)

df = pd.DataFrame(rows)
df.to_csv(os.path.join(HERE, "e4d_lambda_sweep_results.csv"), index=False)

print("\n=== λ 別集約 (3 seeds) ===")
print(f"{'arm':12s} {'λ':>5s} {'Δ':>16s} {'FFN cost':>16s} {'CE':>16s}")
for arm in ARMS:
    for lam in LAMS:
        d = df[(df.arm == arm) & (df.lam == lam)]
        print(f"{arm:12s} {lam:5.2f} {d['sel_delta'].mean():+.3f}±{d['sel_delta'].std():.3f}  "
              f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f}  "
              f"{d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}")

# λ=0.15 の本番結果を併記
base = pd.read_csv(os.path.join(HERE, "e4d_prefix_stats_results.csv"))
print("\n=== λ=0.15（本番 E4d）との比較 ===")
for arm in ARMS:
    d = base[base.arm == arm]
    print(f"{arm:12s}  0.15 {d['sel_delta'].mean():+.3f}±{d['sel_delta'].std():.3f}  "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f}  "
          f"{d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}")

json.dump({"lambda_sweep": rows}, open(os.path.join(HERE, "e4d_lambda_sweep.json"), "w",
                                      encoding="utf-8"), indent=2, ensure_ascii=False)
print("\nsaved e4d_lambda_sweep_results.csv / .json")
