#!/usr/bin/env python3
"""Q4 の解析: Q2 のラダー（copy/compute/hard/harder）に mul4/mul5/mul6 を接続して 1 枚の表にする。

入力: simulation_hmoe_mmlu/data/q2/H+LB_{copy,compute,hard,harder}_s{0..2}.json
      simulation_hmoe_mmlu/data/q4/H+LB_{mul4,mul5,mul6}_s{0..5}.json
出力: simulation_hmoe_mmlu/data/q4/q4_analysis.json / 標準出力に表
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
D2 = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q2")
D4 = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q4")

ARM = "H+LB"
# (task, dir, 表示名, 倍率)
LADDER = [
    ("copy", D2, "copy", "—"),
    ("hard", D2, "hard", "×3"),
    ("compute", D2, "compute", "A/S/D"),
    ("mul4", D4, "mul4", "×4"),
    ("mul5", D4, "mul5", "×5"),
    ("mul6", D4, "mul6", "×6"),
    ("harder", D2, "harder", "×7"),
]
SEEDS = [0, 1, 2, 3, 4, 5]


def load(task, d, seed):
    p = os.path.join(d, f"{ARM}_{task}_s{seed}.json")
    if not os.path.exists(p):
        return None
    try:
        with open(p, encoding="utf-8") as f:
            r = json.load(f)
    except (json.JSONDecodeError, OSError):
        return None
    if r.get("n_eval") != 1024:
        return None
    return r


def stat(xs):
    a = np.asarray(xs, float)
    n = len(a)
    m = float(a.mean())
    sd = float(a.std(ddof=1)) if n > 1 else float("nan")
    se = sd / np.sqrt(n) if n > 1 else float("nan")
    t = m / se if se and se > 0 else float("nan")
    return m, sd, se, t


def main():
    out = {}
    for task, d, label, mult in LADDER:
        rows = [r for r in (load(task, d, s) for s in SEEDS) if r is not None]
        if not rows:
            print(f"[skip] {task}")
            continue
        b = [r["eval"]["base"] for r in rows]
        dd = [x["small_payload"] - x["small_struct"] for x in b]
        dw = [x["width_payload"] - x["width_struct"] for x in b]
        m, sd, se, t = stat(dd)
        out[task] = {
            "label": label, "mult": mult, "n": len(rows),
            "seeds": [r["seed"] for r in rows],
            "acc_payload": [x["acc_payload"] for x in b],
            "ce_payload": [x["ce_payload"] for x in b],
            "instr_valid": [x["instr_valid"] for x in b],
            "seq_valid": [x["seq_valid"] for x in b],
            "small_struct": [x["small_struct"] for x in b],
            "small_payload": [x["small_payload"] for x in b],
            "width_struct": [x["width_struct"] for x in b],
            "width_payload": [x["width_payload"] for x in b],
            "d": dd, "d_mean": m, "d_se": se, "d_t": t,
            "sign_negative": int(sum(x < 0 for x in dd)),
            "dw_mean": float(np.mean(dw)),
            "dw": dw,
        }

    with open(os.path.join(D4, "q4_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print(f"\n{'task':>8} {'op':>6} {'n':>2} {'acc_pl':>7} {'instr':>6} {'seq':>6} "
          f"{'sm_st':>6} {'sm_pl':>6} {'Δ':>7} {'se':>6} {'t':>7} {'Δ<0':>4} "
          f"{'wid_st':>7} {'wid_pl':>7} {'widΔ':>7}")
    for task, _, label, mult in LADDER:
        if task not in out:
            continue
        r = out[task]
        print(f"{label:>8} {mult:>6} {r['n']:>2} {np.mean(r['acc_payload']):>7.4f} "
              f"{np.mean(r['instr_valid']):>6.3f} {np.mean(r['seq_valid']):>6.3f} "
              f"{np.mean(r['small_struct']):>6.3f} {np.mean(r['small_payload']):>6.3f} "
              f"{r['d_mean']:>+7.3f} {r['d_se']:>6.3f} {r['d_t']:>+7.2f} "
              f"{r['sign_negative']}/{r['n']} "
              f"{np.mean(r['width_struct']):>7.1f} {np.mean(r['width_payload']):>7.1f} "
              f"{r['dw_mean']:>+7.1f}")

    print("\nper-seed Δ:")
    for task, _, label, _ in LADDER:
        if task in out:
            r = out[task]
            print(f"  {label:<8} " + " ".join(f"{x:+.3f}" for x in r["d"]) +
                  f"   (seeds {r['seeds']})")

    # 共通 seed での対応差
    print("\n対応差（共通 seed）:")
    for a, b in [("mul5", "mul4"), ("mul6", "mul5"), ("mul6", "mul4")]:
        if a not in out or b not in out:
            continue
        sa = dict(zip(out[a]["seeds"], out[a]["d"]))
        sb = dict(zip(out[b]["seeds"], out[b]["d"]))
        common = sorted(set(sa) & set(sb))
        if len(common) < 2:
            continue
        diff = np.array([sa[s] - sb[s] for s in common])
        m, sd, se, t = stat(diff)
        wsa = dict(zip(out[a]["seeds"], out[a]["width_payload"]))
        wsb = dict(zip(out[b]["seeds"], out[b]["width_payload"]))
        dwp = np.array([wsa[s] - wsb[s] for s in common])
        mwp, _, sewp, twp = stat(dwp)
        print(f"  {a} − {b}: Δ {m:+.3f}  se {se:.3f}  t {t:+.2f}  "
              f"負 {int((diff<0).sum())}/{len(common)}  |  width_payload {mwp:+.1f} "
              f"(se {sewp:.1f}, t {twp:+.2f}, 正 {int((dwp>0).sum())}/{len(common)})")

    # 難度指標と Δ の関係（タスク平均、n=7）
    xs = [(np.mean(out[t]["acc_payload"]), out[t]["d_mean"], out[t]["label"])
          for t in out]
    if len(xs) >= 3:
        a = np.array([x[0] for x in xs])
        y = np.array([x[1] for x in xs])
        print(f"\nΔ vs acc_payload（タスク平均, n={len(xs)}）: r = {np.corrcoef(a, y)[0,1]:+.3f}")
        iv = np.array([np.mean(out[t]["instr_valid"]) for t in out])
        print(f"Δ vs instr_valid（タスク平均, n={len(xs)}）: r = {np.corrcoef(iv, y)[0,1]:+.3f}")
        print("  " + "  ".join(f"{l}:{aa:.3f}/{yy:+.2f}" for aa, yy, l in xs))


if __name__ == "__main__":
    main()
    sys.exit(0)
