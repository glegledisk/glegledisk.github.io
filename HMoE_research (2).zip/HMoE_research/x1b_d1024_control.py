#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""X1b: D1024 代替腕（lr 5e-4 / 10 epoch）の収束訓練と同 params 編集感度対照（P3 の決着）。

事前登録: `X1b課題設計書_D1024代替_lr5e-4再訓練と同params編集対照_20261107.md`。
腕・seed 数・学習率・エポック数・収束ゲート・指標・正規化・Holm・MDE・校正条件は実行前に固定。

H / U は W2 の 8 ckpt、D256 は X1 の 8 ckpt を流用し、D1024 は lr 5e-4 / 10 epoch で再訓練。
編集は摂動比 relpert を H(α=6) に揃える。

出力: x1b_results.json / x1b_delta.npz / x1b_analysis.json / x1b_calib.json /
      x1b_train.json / x1b_out_utf8.txt / simulation_hmoe_mmlu/data/x1b/ckpt_D1024_s*.pt
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# ★ q2_difficulty_ladder を先に import しないと E2.SEQ=128 が効かず pos.w が壊れる。
import q8_static_dispatch as Q8            # noqa: E402
import q2_difficulty_ladder as Q2          # noqa: E402
import e2b_rewrite_routing_fixed as E2     # noqa: E402
from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS  # noqa: E402
from w1_local_edit_absorption import evaluate_full, selection_change  # noqa: E402

assert E2.SEQ == 128, "Q2 の import が E2.SEQ を設定していない"

W2DIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "w2")
Q12BDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q12b")
X1DIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "x1")
X1BDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "x1b")
os.makedirs(X1BDIR, exist_ok=True)

W_H = tuple(WIDTHS["H+LB"])
W_U = tuple(WIDTHS["U+LB"])
ARCH = ("H", "U", "D256", "D1024")
ARMS = ("none", "rand", "dir", "oracle")
WIDTHS_A = {"H": W_H, "U": W_U, "D256": (256,), "D1024": (1024,)}
K_A = {"H": 2, "U": 2, "D256": 1, "D1024": 1}
SEEDS = (0, 1, 2, 3, 4, 5, 6, 7)
CALIB_SEEDS = (0, 1, 2, 3, 4, 5)
N_EVAL, EVAL_SEED = 1024, 777
N_EDIT = 215
ALPHA_H = 6.0
SEQS, EPOCHS_D1024, BS, LR_D1024, AUXW = 3000, 10, 32, 5e-4, 0.05
SPAN = Q2.T_LEN - Q2.TRACE0
CAL_FIELDS = ("ce_all", "instr_valid", "acc_payload", "ce_payload", "width_struct")

assert sum(W_H) == 1024 and sum(W_U) == 1024
assert all(a in WIDTHS_A and a in K_A for a in ARCH)


# ---------------------------------------------------------------------------
# 一般化 forward
# ---------------------------------------------------------------------------
def forward_generic(model, idx, typ=None, k=None, need_grad=True):
    p = model.p
    k = model.k if k is None else k
    B, T = idx.shape
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    aux_sum = torch.zeros(())
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    idx_l = []
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
        topv, topi = logits.topk(k, dim=1)
        gate = torch.softmax(
            torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
        y = torch.zeros_like(h)
        for i in range(model.E):
            tok, _ = (topi == i).nonzero(as_tuple=True)
            if tok.numel() == 0:
                continue
            x_tok = h[tok]
            h1 = F.relu(F.linear(x_tok, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
            y.index_add_(0, tok,
                         F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                         * gate[tok, i].unsqueeze(1))
        top1 = topi[:, 0]
        f = torch.zeros(model.E, dtype=logits.dtype)
        f.scatter_add_(0, top1, torch.ones_like(top1, dtype=f.dtype))
        f = f / h.shape[0]
        P = torch.softmax(logits, dim=1).mean(0)
        dims = torch.tensor(model.dims, dtype=f.dtype)
        aux = model.E * (f * P * (dims / dims.mean())).sum()
        h = h + y
        aux_sum = aux_sum + aux
        idx_l.append(topi.reshape(B, T, k))
    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, -1)
    return out, aux_sum / model.L, idx_l


@torch.no_grad()
def evaluate_generic(model, seq, typ, k, bs=128):
    """W1.evaluate_full と同一の指標を、top-k の k だけ一般化して計算する。"""
    n, L, E = seq.shape[0], model.L, model.E
    dims = np.array(model.dims, dtype=np.float32)
    ce = np.zeros((n, SPAN), dtype=np.float32)
    hit = np.zeros((n, SPAN), dtype=bool)
    wid = np.zeros((n, SPAN), dtype=np.float32)
    top1_l = np.zeros((L, n, SPAN), dtype=np.int64)
    topi_store = [np.zeros((n, Q2.T_LEN, k), dtype=np.int8) for _ in range(L)]
    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = torch.from_numpy(seq[s])
        t_batch = torch.from_numpy(typ[s])
        logits, _, idx_l = forward_generic(model, x, typ=t_batch, k=k)
        lg = logits[:, Q2.TRACE0 - 1:-1, :len(Q2.VOCAB)]
        tgt = torch.from_numpy(seq[s, Q2.TRACE0:])
        lp = F.cross_entropy(lg.reshape(-1, len(Q2.VOCAB)), tgt.reshape(-1),
                             reduction="none").reshape(-1, SPAN)
        ce[s] = lp.numpy()
        pred = lg.argmax(-1).numpy()
        hit[s] = (pred == seq[s, Q2.TRACE0:])
        for l in range(L):
            a = idx_l[l].numpy()
            topi_store[l][s] = a.astype(np.int8)
            aa = a[:, Q2.TRACE0 - 1:-1, :]
            top1_l[l][s] = aa[:, :, 0]
            wid[s] += dims[aa].mean(-1) / L

    ty = typ[:, Q2.TRACE0:]
    m_st, m_pl = (ty == Q2.TYP_STRUCT), (ty == Q2.TYP_PAYLOAD)
    u_l0 = np.bincount(top1_l[0].reshape(-1), minlength=E)
    hp = hit.reshape(n, Q2.P_STEPS, Q2.TPI)[:, :, 2:]
    instr_ok = hp.all(-1)
    metrics = {
        "ce_all": float(ce.mean()),
        "ce_struct": float(ce[m_st].mean()),
        "ce_payload": float(ce[m_pl].mean()),
        "acc_struct": float(hit[m_st].mean()),
        "acc_payload": float(hit[m_pl].mean()),
        "width_struct": float(wid[m_st].mean()),
        "width_payload": float(wid[m_pl].mean()),
        "small_struct": float(np.isin(top1_l[-1][m_st], Q2.SMALL).mean()),
        "small_payload": float(np.isin(top1_l[-1][m_pl], Q2.SMALL).mean()),
        "usage_l0": u_l0.tolist(),
        "usage_entropy": Q8.usage_entropy(u_l0),
        "usage_share_max": float(u_l0.max() / max(1.0, u_l0.sum())),
        "dead_experts": int(np.sum((u_l0 / max(1.0, u_l0.sum())) < 0.01)),
        "instr_valid": float(instr_ok.all(-1).mean()),
        "instr_acc": float(instr_ok.mean()),
        "payload_token_acc": float(hp.mean()),
        "n_eval": int(n),
    }
    extras = {
        "instr_seq": instr_ok.all(-1).astype(np.int8),
        "ce_seq": ce.mean(1).astype(np.float64),
        "topi": topi_store,
        "usage_by_layer": [np.bincount(top1_l[l].reshape(-1), minlength=E)
                           for l in range(L)],
    }
    return metrics, extras


# ---------------------------------------------------------------------------
# ckpt
# ---------------------------------------------------------------------------
def build_model(arch, seed):
    return RewriteMoE(WIDTHS_A[arch], seed=seed, topk=K_A[arch])


def load_dict(path):
    return torch.load(path, map_location="cpu")


def fresh(model, clean):
    model.p = {k: v.clone() for k, v in clean.items()}
    for k in model.p:
        model.p[k].requires_grad_(False)
    return model


def load_arch(arch, seed):
    """H / U は W2 ckpt、D256 は X1 ckpt、D1024 は X1b ckpt。"""
    if arch in ("H", "U"):
        path = os.path.join(W2DIR, f"ckpt_{arch}_s{seed}.pt")
    elif arch == "D256":
        path = os.path.join(X1DIR, f"ckpt_{arch}_s{seed}.pt")
    elif arch == "D1024":
        path = os.path.join(X1BDIR, f"ckpt_{arch}_s{seed}.pt")
    else:
        raise ValueError(f"未登録のアーキテクチャ: {arch}")
    td = load_dict(path)
    model = build_model(arch, seed)
    assert set(td.keys()) == set(model.p.keys()), f"{arch} s{seed}: ckpt キー不一致"
    for k in td:
        assert tuple(td[k].shape) == tuple(model.p[k].shape), \
            f"{arch} s{seed}: {k} の形が違う"
    clean = {k: v.detach().clone() for k, v in td.items()}
    return model, clean


def train_dense(arch, seed, epochs=EPOCHS_D1024, lr=LR_D1024):
    """D1024b の訓練: lr 5e-4, 10 epoch。E=1 なので p_pen は定数で勾配を持たない。"""
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    model = build_model(arch, seed)
    opt = Adam(model.params(), lr=lr)
    steps = max(1, SEQS // BS)
    hist = []
    t0 = time.time()
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps):
            xs, ty = Q2.make_trace_batch(rng, BS, task="hard")
            logits, aux, _ = forward_generic(
                model, torch.from_numpy(xs), typ=torch.from_numpy(ty),
                k=K_A[arch])
            loss = Q2.trace_loss(logits, xs) + AUXW * aux
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        hist.append(float(run / steps))
    nparam = int(sum(v.numel() for v in model.params().values()))
    torch.save({k: v.detach() for k, v in model.params().items()},
               os.path.join(X1BDIR, f"ckpt_{arch}_s{seed}.pt"))
    return {"arch": arch, "seed": seed, "nparam": nparam,
            "loss_hist": hist, "loss_final": hist[-1],
            "sec": round(time.time() - t0, 1)}


# ---------------------------------------------------------------------------
# 編集計画: 摂動比を H(α=6) に揃える
# ---------------------------------------------------------------------------
def edit_plan(clean, arch, seed, target_relpert):
    W = clean["l0.e0.w2"]
    u = torch.linalg.svd(W, full_matrices=False)[0][:, 0]
    proj = u @ W
    D1 = -(u[:, None] * proj[None, :])          # α=1 の差分
    flat = D1.reshape(-1)
    idx = torch.topk(flat.abs(), N_EDIT).indices
    vals1 = flat[idx].clone()                   # (215,)
    params_norm = math.sqrt(sum(float((v ** 2).sum()) for v in clean.values()))
    vnorm = float(torch.linalg.vector_norm(vals1))
    assert vnorm > 0 and params_norm > 0
    if arch == "H":
        alpha = ALPHA_H
    else:
        target = target_relpert[seed]
        alpha = float((target * params_norm) / vnorm)
    return {
        "arch": arch, "seed": seed, "key": "l0.e0.w2",
        "u": u, "idx": idx, "vals1": vals1,
        "vnorm": vnorm, "params_norm": params_norm,
        "alpha": alpha, "target_relpert": target_relpert.get(seed, None),
        "w2_numel": int(W.numel()),
    }


def apply_edit(model, clean, arm, plan, seed):
    fresh(model, clean)
    p = model.p
    if arm == "none":
        return {"n_edited": 0, "alpha": 0.0, "keys": []}
    if arm in ("rand", "dir"):
        vals = plan["alpha"] * plan["vals1"]
        if arm == "dir":
            idx = plan["idx"]
        else:
            rng = np.random.default_rng(9000 + seed)
            idx = torch.from_numpy(
                rng.choice(plan["w2_numel"], size=N_EDIT, replace=False).astype(np.int64))
            perm = torch.randperm(
                N_EDIT, generator=torch.Generator().manual_seed(3000 + seed))
            vals = vals[perm]
        Wn = clean[plan["key"]].clone()
        fl = Wn.reshape(-1)
        fl[idx] = fl[idx] + vals
        p[plan["key"]] = Wn
        return {"n_edited": N_EDIT, "alpha": plan["alpha"], "keys": [plan["key"]]}
    if arm == "oracle":
        keys = [f"l{l}.e{i}.w2" for l in range(model.L) for i in range(model.E)]
        for k in keys:
            p[k] = torch.zeros_like(p[k])
        return {"n_edited": int(sum(p[k].numel() for k in keys)),
                "alpha": 0.0, "keys": keys}
    raise ValueError(f"編集規則が未定義: {arm}")


# ---------------------------------------------------------------------------
# 校正（本番前に成立させる）
# ---------------------------------------------------------------------------
def calibration(seq, typ, w2_rows, w1_rows, x1_rows):
    items = []

    def add(tag, arch, seed, field, want, got):
        if isinstance(want, list):
            d = float(np.max(np.abs(np.array(got, dtype=float) -
                                    np.array(want, dtype=float))))
        else:
            d = abs(float(want) - float(got))
        items.append({"check": tag, "arch": arch, "seed": seed, "field": field,
                      "want": want, "got": got, "abs_diff": d,
                      "bit_match": bool(d < 1e-12)})

    # C1: X1 の H / U / D256 の 8 seed 評価結果とビット一致
    for arch in ("H", "U", "D256"):
        for seed in SEEDS:
            model, clean = load_arch(arch, seed)
            fresh(model, clean)
            m, _ = evaluate_generic(model, seq, typ, K_A[arch])
            ref = next(r for r in x1_rows
                       if r["arch"] == arch and r["arm"] == "none" and r["seed"] == seed)
            for fld in CAL_FIELDS:
                add("C1", arch, seed, fld, ref[fld], m[fld])

    # C2: q12b の H ckpt を evaluate_generic で再評価し w1_results.json の none 腕と一致
    for seed in CALIB_SEEDS:
        td = load_dict(os.path.join(Q12BDIR,
                                    f"ckpt_H+LB_hard_dynamic_lb_s{seed}.pt"))
        model = RewriteMoE(W_H, seed=seed)
        clean = {k: v.detach().clone() for k, v in td.items()}
        fresh(model, clean)
        m, _ = evaluate_generic(model, seq, typ, 2)
        ref = next(r for r in w1_rows if r["arm"] == "none" and r["seed"] == seed)
        for fld in CAL_FIELDS:
            add("C2", "H(q12b)", seed, fld, ref[fld], m[fld])

    # C3: forward_generic と Q8.forward_dispatch の logits ビット一致
    model, clean = load_arch("H", 0)
    fresh(model, clean)
    x = torch.from_numpy(seq[:32])
    t = torch.from_numpy(typ[:32])
    with torch.no_grad():
        a, auxa, ia = Q8.forward_dispatch(model, x, typ=t, mode="dynamic_lb")
        b, auxb, ib = forward_generic(model, x, typ=t, k=2)
    d_logit = float((a - b).abs().max())
    d_aux = abs(float(auxa) - float(auxb))
    d_idx = float(max(float((x1 != x2).float().max()) for x1, x2 in zip(ia, ib)))
    items.append({"check": "C3", "arch": "H", "seed": 0, "field": "logits",
                  "want": 0.0, "got": d_logit, "abs_diff": d_logit,
                  "bit_match": bool(d_logit < 1e-12 and d_aux < 1e-12 and d_idx == 0.0)})
    items.append({"check": "C3", "arch": "H", "seed": 0, "field": "aux",
                  "want": 0.0, "got": d_aux, "abs_diff": d_aux,
                  "bit_match": bool(d_aux < 1e-12)})

    # C4: nparam assert
    for arch in ARCH:
        m = build_model(arch, 0)
        nparam = int(sum(v.numel() for v in m.params().values()))
        want = 1346877 if arch in ("H", "U") else (550177 if arch == "D256" else 1339681)
        items.append({"check": "C4", "arch": arch, "seed": 0, "field": "nparam",
                      "want": want, "got": nparam,
                      "abs_diff": abs(nparam - want),
                      "bit_match": bool(nparam == want)})
        items.append({"check": "C4", "arch": arch, "seed": 0, "field": "widths",
                      "want": list(WIDTHS_A[arch]), "got": list(m.dims),
                      "abs_diff": 0.0,
                      "bit_match": bool(list(m.dims) == list(WIDTHS_A[arch]))})

    # C5: 未知の腕・アーキテクチャで例外
    raised = 0
    try:
        apply_edit(model, clean, "__unknown__", None, 0)
    except ValueError:
        raised += 1
    try:
        load_arch("__unknown__", 0)
    except ValueError:
        raised += 1
    items.append({"check": "C5", "arch": "any", "seed": 0, "field": "exception_raised",
                  "want": 2, "got": raised, "abs_diff": abs(raised - 2),
                  "bit_match": bool(raised == 2)})

    all_ok = all(x["bit_match"] for x in items)
    return {"all_bit_match": all_ok, "n": len(items),
            "n_fail": sum(1 for x in items if not x["bit_match"]),
            "items": items}


# ---------------------------------------------------------------------------
# メイン
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, nargs="+", default=list(SEEDS))
    ap.add_argument("--archs", type=str, nargs="+", default=list(ARCH))
    ap.add_argument("--arms", type=str, nargs="+", default=list(ARMS))
    ap.add_argument("--n_eval", type=int, default=N_EVAL)
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--dense_epochs", type=int, default=EPOCHS_D1024)
    ap.add_argument("--dense_lr", type=float, default=LR_D1024)
    ap.add_argument("--reuse", action="store_true", help="D1024 ckpt を再訓練しない")
    ap.add_argument("--train_only", action="store_true",
                    help="D1024 の訓練だけ行って終了（本番は --reuse で再利用）")
    ap.add_argument("--train_threads", type=int, default=8,
                    help="D1024 訓練のみのスレッド数。評価・校正は常に --threads")
    ap.add_argument("--tag", type=str, default="x1b")
    args = ap.parse_args()

    tag = args.tag
    logpath = os.path.join(HERE, f"{tag}_out_utf8.txt")
    out_fh = open(logpath, "w", encoding="utf-8")

    def log(msg):
        out_fh.write(msg + "\n")
        out_fh.flush()
        print(msg, flush=True)

    log(f"=== X1b: D1024 代替腕の lr 5e-4 収束訓練とアーキテクチャ対照 (tag={tag}) ===")
    log(f"seeds={args.seeds} n_eval={args.n_eval} dense_epochs={args.dense_epochs} "
        f"dense_lr={args.dense_lr} train_threads={args.train_threads}")

    torch.set_num_threads(args.threads)
    rng_eval = np.random.default_rng(EVAL_SEED)
    seq, typ = Q2.make_trace_batch(rng_eval, args.n_eval, task="hard")

    # ---------------- D1024b の訓練 ----------------
    train_rows = []
    torch.set_num_threads(args.train_threads)
    try:
        for seed in args.seeds:
            ckpt_path = os.path.join(X1BDIR, f"ckpt_D1024_s{seed}.pt")
            if args.reuse and os.path.isfile(ckpt_path):
                log(f"  [train] D1024 s{seed} は既存 ckpt を再利用: {ckpt_path}")
            else:
                r = train_dense("D1024", seed, epochs=args.dense_epochs, lr=args.dense_lr)
                train_rows.append(r)
                log(f"  [train] D1024 s{seed} nparam={r['nparam']} "
                    f"loss_final={r['loss_final']:.4f} loss_hist={np.round(r['loss_hist'], 3).tolist()} "
                    f"sec={r['sec']}s train_threads={args.train_threads}")
    finally:
        torch.set_num_threads(args.threads)

    if args.train_only:
        with open(os.path.join(HERE, f"{tag}_train.json"), "w", encoding="utf-8") as f:
            json.dump({"rows": train_rows, "args": vars(args)},
                      f, ensure_ascii=False, indent=2, default=float)
        log(f"train_only 完了: {len(train_rows)} 走行。本番は --reuse で実行")
        os._exit(0)

    # ---------------- 校正 ----------------
    with open(os.path.join(HERE, "w2_results.json"), encoding="utf-8") as f:
        w2_rows = json.load(f)["rows"]
    with open(os.path.join(HERE, "w1_results.json"), encoding="utf-8") as f:
        w1_rows = json.load(f)["rows"]
    with open(os.path.join(HERE, "x1_results.json"), encoding="utf-8") as f:
        x1_rows = json.load(f)["rows"]

    calib = calibration(seq, typ, w2_rows, w1_rows, x1_rows)
    with open(os.path.join(HERE, f"{tag}_calib.json"), "w", encoding="utf-8") as f:
        json.dump(calib, f, ensure_ascii=False, indent=2)
    log(f"校正結果: n={calib['n']} all_bit_match={calib['all_bit_match']} "
        f"n_fail={calib['n_fail']}")
    if not calib["all_bit_match"]:
        for it in calib["items"]:
            if not it["bit_match"]:
                log(f"  [FAIL] {it['check']} {it['arch']} s{it['seed']} {it['field']}: "
                    f"want={it['want']} got={it['got']} diff={it['abs_diff']}")
        raise RuntimeError("校正が成立しなかったため本番走行を中止")

    # ---------------- H(α=6) の relpert を seed ごとに目標化 ----------------
    target = {}
    for seed in args.seeds:
        model, clean = load_arch("H", seed)
        plan_h = edit_plan(clean, "H", seed, {})
        target[seed] = ALPHA_H * plan_h["vnorm"] / plan_h["params_norm"]
        log(f"  target_relpert s{seed} = {target[seed]:.6f}")

    # ---------------- 本番評価 ----------------
    na, ne, ns, L = len(args.archs), len(args.arms), len(args.seeds), 4
    aa = {a: i for i, a in enumerate(args.archs)}
    ea = {e: i for i, e in enumerate(args.arms)}
    sa = {s: j for j, s in enumerate(args.seeds)}
    iv = np.full((na, ne, ns), np.nan)
    ce_all = np.full((na, ne, ns), np.nan)
    ce_pay = np.full((na, ne, ns), np.nan)
    acc_pay = np.full((na, ne, ns), np.nan)
    w_st = np.full((na, ne, ns), np.nan)
    w_pl = np.full((na, ne, ns), np.nan)
    instr_seq = np.zeros((na, ne, ns, args.n_eval), dtype=np.int8)
    ce_seq = np.zeros((na, ne, ns, args.n_eval), dtype=np.float64)
    selchg = np.zeros((na, ne, ns, L), dtype=np.float64)
    relpert = np.zeros((na, ne, ns), dtype=np.float64)
    alpha_arr = np.zeros((na, ne, ns), dtype=np.float64)
    diff_l2 = np.zeros((na, ne, ns), dtype=np.float64)
    nparam_arr = np.zeros(na, dtype=np.int64)
    w2num = np.zeros(na, dtype=np.int64)
    rows = []

    for arch in args.archs:
        nparam_arr[aa[arch]] = int(sum(v.numel() for v in
                                      build_model(arch, 0).params().values()))
        for seed in args.seeds:
            model, clean = load_arch(arch, seed)
            fresh(model, clean)
            plan = edit_plan(clean, arch, seed, target)
            w2num[aa[arch]] = plan["w2_numel"]
            m0, x0 = evaluate_generic(model, seq, typ, K_A[arch])
            for arm in args.arms:
                info = apply_edit(model, clean, arm, plan, seed)
                sq = sum(float(((model.p[k] - clean[k]) ** 2).sum()) for k in clean)
                dl2 = math.sqrt(sq)
                m, x = evaluate_generic(model, seq, typ, K_A[arch])
                i, j, q = aa[arch], ea[arm], sa[seed]
                iv[i, j, q] = m["instr_valid"]
                ce_all[i, j, q] = m["ce_all"]
                ce_pay[i, j, q] = m["ce_payload"]
                acc_pay[i, j, q] = m["acc_payload"]
                w_st[i, j, q] = m["width_struct"]
                w_pl[i, j, q] = m["width_payload"]
                instr_seq[i, j, q] = x["instr_seq"]
                ce_seq[i, j, q] = x["ce_seq"]
                relpert[i, j, q] = dl2 / max(1e-12, plan["params_norm"])
                diff_l2[i, j, q] = dl2
                alpha_arr[i, j, q] = info["alpha"]
                if arm == "none":
                    selchg[i, j, q] = 0.0
                else:
                    selchg[i, j, q] = selection_change(x0["topi"], x["topi"])
                rows.append({"arch": arch, "arm": arm, "seed": seed, **m,
                             "n_edited": info["n_edited"],
                             "alpha": info["alpha"],
                             "diff_l2": dl2,
                             "params_norm": plan["params_norm"],
                             "relpert": relpert[i, j, q],
                             "w2_numel": plan["w2_numel"],
                             "frac_in_matrix": float(info["n_edited"]) / plan["w2_numel"],
                             "sel_change": selchg[i, j, q].tolist(),
                             "nparam": int(nparam_arr[i])})
                log(f"  {arch:<5s} {arm:<7s} s{seed} iv={m['instr_valid']:.4f} "
                    f"ce={m['ce_all']:.5f} relpert={relpert[i,j,q]:.5f} "
                    f"alpha={info['alpha']:.3f} sel={np.round(selchg[i,j,q],3).tolist()}")

    # ---------------- 保存 ----------------
    with open(os.path.join(HERE, f"{tag}_results.json"), "w", encoding="utf-8") as f:
        json.dump({"rows": rows, "train_rows": train_rows, "args": vars(args),
                   "archs": list(args.archs), "arms": list(args.arms),
                   "seeds": list(args.seeds), "target_relpert": target,
                   "widths": {a: list(WIDTHS_A[a]) for a in args.archs}},
                  f, ensure_ascii=False, indent=2, default=float)
    np.savez_compressed(
        os.path.join(HERE, f"{tag}_delta.npz"),
        archs=np.array(args.archs, dtype=object), arms=np.array(args.arms, dtype=object),
        seeds=np.array(args.seeds), iv=iv, ce_all=ce_all, ce_payload=ce_pay,
        acc_payload=acc_pay, width_struct=w_st, width_payload=w_pl,
        instr_seq=instr_seq, ce_seq=ce_seq, sel_change=selchg,
        relpert=relpert, alpha=alpha_arr, diff_l2=diff_l2,
        nparam=nparam_arr, w2_numel=w2num)

    # ---------------- 集計 ----------------
    def paired(d):
        d = np.asarray(d, dtype=float)
        se = float(d.std(ddof=1) / math.sqrt(len(d))) if len(d) >= 2 else float("nan")
        if not np.isfinite(se) or se == 0:
            t, p, mde = 0.0, 1.0, 0.0
        else:
            t = float(d.mean() / se)
            p = float(2 * stats.t.sf(abs(t), df=len(d) - 1))
            mde = float(stats.t.ppf(0.975, len(d) - 1) * se)
        return {"delta": float(d.mean()), "se": se, "t": t, "p": p,
                "mde": mde, "n": int(len(d)), "per_seed": d.tolist(),
                "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum())}

    def dseq(arch, arm):
        a = ce_seq[aa[arch], ea[arm]] - ce_seq[aa[arch], ea["none"]]
        return a.mean(1)                      # seed ごとの系列平均差

    within = {}
    for arch in args.archs:
        within[arch] = {}
        for arm in args.arms:
            if arm == "none":
                continue
            r = paired(iv[aa[arch], ea[arm]] - iv[aa[arch], ea["none"]])
            r["iv_none"] = float(iv[aa[arch], ea["none"]].mean())
            r["iv_arm"] = float(iv[aa[arch], ea[arm]].mean())
            r["ce_seq"] = paired(dseq(arch, arm))
            dd = (ce_seq[aa[arch], ea[arm]] - ce_seq[aa[arch], ea["none"]]).reshape(-1)
            ab = np.abs(dd)
            ntop = max(1, int(math.ceil(len(ab) * 0.01)))
            r["ce_seq_top1_share"] = float(np.sort(ab)[-ntop:].sum() /
                                           max(1e-12, ab.sum()))
            r["relpert"] = float(relpert[aa[arch], ea[arm]].mean())
            r["alpha"] = float(alpha_arr[aa[arch], ea[arm]].mean())
            r["n_edited"] = int(next(x["n_edited"] for x in rows
                                    if x["arch"] == arch and x["arm"] == arm))
            r["w2_numel"] = int(w2num[aa[arch]])
            r["frac_in_matrix"] = r["n_edited"] / max(1, r["w2_numel"])
            r["sel_change_mean"] = selchg[aa[arch], ea[arm]].mean(0).tolist()
            within[arch][arm] = r

    # 主比較 P1 / P2 / P3（instr_valid の差の差）
    PRIMARY = (("P1", "H", "U"), ("P2", "H", "D256"), ("P3", "H", "D1024"))
    comps = {}
    for name, a, b in PRIMARY:
        if a not in aa or b not in aa:
            continue
        d = (iv[aa[a], ea["dir"]] - iv[aa[a], ea["none"]]) - \
            (iv[aa[b], ea["dir"]] - iv[aa[b], ea["none"]])
        r = paired(d)
        r["pair"] = f"{a}-{b}"
        r["ce_seq"] = paired(dseq(a, "dir") - dseq(b, "dir"))
        comps[name] = r
    order = sorted(comps, key=lambda k: comps[k]["p"])
    run = 0.0
    holm = {}
    for rank, k in enumerate(order):
        run = max(run, min(1.0, (len(comps) - rank) * comps[k]["p"]))
        holm[k] = {"p_raw": comps[k]["p"], "p_holm": float(run),
                   "rank": rank + 1, "m": len(comps)}
    for k in comps:
        comps[k]["p_holm"] = holm[k]["p_holm"]
        comps[k]["detected"] = bool(
            abs(comps[k]["delta"]) > comps[k]["mde"] and
            comps[k]["p_holm"] < 0.05 and
            max(comps[k]["n_pos"], comps[k]["n_neg"]) >= 7)

    # 副次（Δce_seq の差の差にも Holm m=3）
    comps_ce = {}
    for k, c in comps.items():
        r = dict(c["ce_seq"])
        r["pair"] = c["pair"]
        comps_ce[k] = r
    order_ce = sorted(comps_ce, key=lambda k: comps_ce[k]["p"])
    run_ce = 0.0
    holm_ce = {}
    for rank, k in enumerate(order_ce):
        run_ce = max(run_ce, min(1.0, (len(comps_ce) - rank) * comps_ce[k]["p"]))
        holm_ce[k] = {"p_raw": comps_ce[k]["p"], "p_holm": float(run_ce),
                      "rank": rank + 1, "m": len(comps_ce)}
    for k in comps_ce:
        comps_ce[k]["p_holm"] = holm_ce[k]["p_holm"]
        comps_ce[k]["detected"] = bool(
            abs(comps_ce[k]["delta"]) > comps_ce[k]["mde"] and
            comps_ce[k]["p_holm"] < 0.05 and
            max(comps_ce[k]["n_pos"], comps_ce[k]["n_neg"]) >= 7)

    # 3 点対照・感度・正規化
    monotonic = {}
    for arch in args.archs:
        means = [float(iv[aa[arch], ea[e]].mean()) for e in ARMS if e in ea]
        monotonic[arch] = bool(all(means[k] >= means[k + 1] - 1e-9
                                   for k in range(len(means) - 1)))
    oracle_ok = {arch: bool(within[arch]["oracle"]["delta"] <= -0.30)
                 for arch in args.archs if "oracle" in within[arch]}

    max_norm_diff = float(max(
        abs(relpert[aa[a], ea["dir"], q] - relpert[aa[a], ea["rand"], q])
        for a in args.archs for q in range(ns)))

    # 収束ゲート G1, G2, G3（D1024b）
    g1_loss = [r["loss_final"] for r in train_rows if r["arch"] == "D1024"]
    g1_ok = bool(len(g1_loss) == 8 and sum(1 for l in g1_loss if l < 0.30) >= 6) if g1_loss else None
    g2_iv = [float(iv[aa["D1024"], ea["none"], q]) for q in range(ns)]
    g2_ok = bool(sum(1 for v in g2_iv if v >= 0.10) >= 6)
    g3_oracle = [float(iv[aa["D1024"], ea["oracle"], q] - iv[aa["D1024"], ea["none"], q]) for q in range(ns)]
    g3_ok = bool(sum(1 for d in g3_oracle if d <= -0.30) >= 6)
    convergence_gates = {
        "G1_loss_lt_030": {"ok": g1_ok, "values": g1_loss, "pass_count": sum(1 for l in g1_loss if l < 0.30) if g1_loss else None},
        "G2_iv_none_ge_010": {"ok": g2_ok, "values": g2_iv, "pass_count": sum(1 for v in g2_iv if v >= 0.10)},
        "G3_oracle_le_m030": {"ok": g3_ok, "values": g3_oracle, "pass_count": sum(1 for d in g3_oracle if d <= -0.30)},
        "all_gates_pass": bool((g1_ok is None or g1_ok) and g2_ok and g3_ok),
    }

    analysis = {
        "within_architecture": within,
        "primary_comparisons": comps,
        "ce_seq_comparisons": comps_ce,
        "holm": holm,
        "holm_ce_seq": holm_ce,
        "monotonicity_none_ge_rand_ge_dir_ge_oracle": monotonic,
        "oracle_sensitivity_le_minus03": oracle_ok,
        "relpert_norm_match_max_diff": max_norm_diff,
        "norm_match_ok": bool(max_norm_diff < 1e-6),
        "calibration": calib,
        "convergence_gates": convergence_gates,
    }

    with open(os.path.join(HERE, f"{tag}_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2, default=float)

    log("\n=== 集計完了 ===")
    log(f"収束ゲート: G1={g1_ok} G2={g2_ok} G3={g3_ok} (all_pass={convergence_gates['all_gates_pass']})")
    for name, c in comps.items():
        log(f"  {name} ({c['pair']}): Δinstr={c['delta']:+.4f} se={c['se']:.4f} "
            f"t={c['t']:+.2f} p={c['p']:.4f} holm={c['p_holm']:.4f} "
            f"mde={c['mde']:.4f} n_pos={c['n_pos']} n_neg={c['n_neg']} "
            f"detected={c['detected']}")
    for name, c in comps_ce.items():
        log(f"  {name}_ce ({c['pair']}): Δce_seq={c['delta']:+.4f} se={c['se']:.4f} "
            f"t={c['t']:+.2f} p={c['p']:.4f} holm={c['p_holm']:.4f} "
            f"mde={c['mde']:.4f} n_pos={c['n_pos']} n_neg={c['n_neg']} "
            f"detected={c['detected']}")

    out_fh.close()
    os._exit(0)


if __name__ == "__main__":
    main()
