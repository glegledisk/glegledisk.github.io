# -*- coding: utf-8 -*-
"""e5_d64_60ep.py — d=64 で 60 epoch の再測定（容量を上げると FFN は不要になるか）

背景:
  12 epoch の容量プローブでは
      d=64 : FFN 寄与 ΔCE 0.068 nats（飽和）
      d=16 : ΔCE 0.396 nats（未学習気味）
  だった。しかしその後の検証で「12 epoch は d=16 にとって未学習」と判明。
  d=64 は 12 epoch で CE 0.0023 まで収束していた（＝ d=64 は学習が速い）ので、
  12 epoch の d=64 の結果自体は有効と考えられる。ただし確認のため 60 epoch で測り直す。

問い: 十分に学習させた d=64 で、FFN はどれだけ品質に寄与するか。
  - ΔCE が小さい（< 0.03）-> 容量を上げると FFN が冗長。実モデル規模ではルーティングの意味が薄い。
  - ΔCE が大きい（> 0.1） -> 容量によらず FFN は必要。ルーティングの余地がある。

構成: d=64, L=16, A=16, anchor_vals=(0,1,2,3), epochs=60
      frozen_ffn / frozen_identity × seeds 0-3
出力: e5_d64_60ep.csv（逐次保存）
"""
import os, json, time
import numpy as np
import pandas as pd
from e5_dependency_task import run

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=16, anchor_vals=(0, 1, 2, 3), d=64, epochs=60)
ARMS = ["frozen_ffn", "frozen_identity"]
SEEDS = [0, 1, 2, 3]
OUT = os.path.join(HERE, "e5_d64_60ep.csv")

rows = []
if os.path.exists(OUT):
    rows = pd.read_csv(OUT).to_dict("records")
have = {(r["arm"], int(r["seed"])) for r in rows}

t0 = time.time()
for arm in ARMS:
    for s in SEEDS:
        if (arm, s) in have:
            continue
        r = run(arm, s, **CFG)
        r["arm"] = arm
        rows.append(r)
        pd.DataFrame(rows).to_csv(OUT, index=False)
        print(f"  {arm:16s} s{s} | CE {r['ce_all']:.4f} | acc {r['acc_all']:.4f} "
              f"(anchor {r['acc_anchor']:.3f}) | FFN {r['ffn_cost']:.3f} | {time.time()-t0:.0f}s", flush=True)

df = pd.DataFrame(rows)
print("\n=== d=64, 60 epoch ===")
for a in ARMS:
    d = df[df.arm == a]
    print(f" {a:16s} n={len(d)}  CE {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"acc {d['acc_all'].mean():.4f}  anchor {d['acc_anchor'].mean():.4f}")

piv = df.pivot_table(index="seed", columns="arm", values="ce_all")
if {"frozen_ffn", "frozen_identity"}.issubset(piv.columns):
    diff = (piv["frozen_identity"] - piv["frozen_ffn"]).dropna()
    print(f"\n FFN の寄与 ΔCE = {diff.mean():+.4f} ± {diff.std(ddof=1):.4f} "
          f"(n={len(diff)}, 各 seed: {[round(x,4) for x in diff.values]})")
    # 比較用の参照値
    print("\n === 比較: 12 epoch と d=16/60ep ===")
    print("  d=64 / 12ep  : ΔCE +0.0684（capacity_probe, 2 seeds）")
    print("  d=16 / 60ep  : ΔCE +0.2616（e5_60ep_all, 7 seeds）")
    print(f"  d=64 / 60ep  : ΔCE {diff.mean():+.4f}（本測定, {len(diff)} seeds）")
    json.dump({"d": 64, "epochs": 60, "n": int(len(diff)),
               "dce_mean": float(diff.mean()), "dce_sd": float(diff.std(ddof=1)),
               "ce_ffn": float(piv["frozen_ffn"].mean()),
               "ce_id": float(piv["frozen_identity"].mean()),
               "raw": rows},
              open(os.path.join(HERE, "e5_d64_60ep.json"), "w", encoding="utf-8"),
              indent=2, ensure_ascii=False)
print("\nsaved e5_d64_60ep.csv / .json")
