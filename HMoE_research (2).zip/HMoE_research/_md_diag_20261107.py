# -*- coding: utf-8 -*-
"""_md_diag_20261107.py — レンダリング後に残る ** がどの行かを特定する使い捨て診断。"""
import re
import sys
from markdown_it import MarkdownIt

path = sys.argv[1]
lines = open(path, encoding="utf-8").read().split("\n")
md = MarkdownIt("commonmark").enable("table")
for i, ln in enumerate(lines, 1):
    if "**" not in ln:
        continue
    html = md.render(ln)
    body = re.sub(r"<pre>.*?</pre>", "", html, flags=re.S)
    body = re.sub(r"<code>.*?</code>", "<code>X</code>", body, flags=re.S)
    n = len(re.findall(r"\*\*", body))
    if n:
        print(f"L{i}: {n} | {ln[:200]}")
