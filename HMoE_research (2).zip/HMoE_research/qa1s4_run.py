# -*- coding: utf-8 -*-
"""QA1S4: re-run QA1 width arms after explicit gain completion and random dedup."""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
import traceback
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "simulation_hmoe_mmlu"))

import a4_small_expert_act as A4
import q1_trace_routing as Q1
import qa1s2_policy as POL
import qa1s2_run as Q2

TAG = "qa1s4"
PROD_TAG = "_qa1s4prod"
SMOKE_TAG = "_qa1s4smoke"
W_REF, W_MID, W_FLAT = Q2.W_REF, Q2.W_MID, Q2.W_FLAT
ARMS = Q2.ARMS
ACTS, SEEDS = Q2.ACTS, Q2.SEEDS
POLICIES = Q2.C5_POLICIES
N_POS = Q2.N_POS
P4_MAX_REL_DEV = 0.05
P5_LIMIT = 10.0 * math.log(Q2.VOCAB_Q1)
EPS_EVAL = 1e-6
BASELINE_TAG = "_qa1s2prod"
CACHE_DIR = HERE / "qa1s4_cache"
CACHE_VERSION = 1


def _maxdiff_numeric(a, b) -> float:
    aa, bb = np.asarray(a, dtype=np.float64), np.asarray(b, dtype=np.float64)
    if aa.shape != bb.shape:
        return float("inf")
    return float(np.max(np.abs(aa - bb))) if aa.size else 0.0


def _run(arm: str, seed: int, tag: str) -> dict:
    import torch
    torch.set_num_threads(1)
    widths = ARMS[arm]
    box = []
    out = A4.run_one(arm=arm, seed=seed, scale=1.0, n_seqs=Q2.N_SEQS,
                     epochs=Q2.EPOCHS, bs=Q2.BS, lr=Q2.LR, auxw=Q2.AUXW,
                     gain="matched", eval_every=Q2.EVAL_EVERY, tag=tag,
                     widths_override=widths, act_override=ACTS, model_out=box,
                     complete_gain_map=True)
    assert len(box) == 1, "run_one(model_out) must return exactly one trained model"
    trained = box[0]
    model = POL.PolicyActMoE(widths, "relu", seed=seed, act_i=ACTS,
                             rng_seed=seed, policy="learned",
                             random_without_replacement=True)
    model.p = trained.p
    model.gain_l = dict(trained.gain_l)
    same_p = model.p is trained.p
    same_gain_l = model.gain_l == trained.gain_l

    eval_rng = np.random.default_rng(Q2.EVAL_SEED)
    ev_seq, ev_typ = Q1.make_trace_batch(eval_rng, Q2.EVAL_N)
    raw = {p: POL.eval_policy(model, ev_seq, ev_typ, p, bs=128) for p in POLICIES}
    policy = {}
    for p, r in raw.items():
        policy[p] = {"ce_all": float(r["ce_all"]),
                     "ce_struct": float(r["ce_struct"]),
                     "ce_payload": float(r["ce_payload"]),
                     "instr_valid": float(r["instr_valid"]),
                     "instr_acc": float(r["instr_acc"])}

    # P1: distinct policy logits; compare the three control policies pairwise.
    control_names = ("uniform", "random", "oracle")
    logits_diff = {}
    for i, a in enumerate(control_names):
        for b in control_names[i + 1:]:
            logits_diff[f"{a}_vs_{b}"] = _maxdiff_numeric(
                raw[a]["first_logits"], raw[b]["first_logits"])
    p1 = bool(all(v > 0 for v in logits_diff.values()))

    # P2: both oracle experts belong to the prescribed type group.
    oracle_topi = np.asarray(raw["oracle"]["topi"], dtype=np.int64)
    oracle_ty = np.asarray(raw["oracle"]["typ_flat"], dtype=np.int64).reshape(-1)
    expected = np.where(oracle_ty == Q1.TYP_PAYLOAD, len(ACTS) - 2, 0)
    oracle_group_ok = ((oracle_topi[:, 0] == expected) &
                       (oracle_topi[:, 1] == expected + 1))
    p2_agreement = float(oracle_group_ok.mean()) if oracle_group_ok.size else 0.0
    p2 = abs(p2_agreement - 1.0) < 1e-12

    # P3: uniform policy visits all experts.
    uniform_topi = np.asarray(raw["uniform"]["topi"], dtype=np.int64)
    uniform_coverage = int(np.unique(uniform_topi).size)
    p3 = uniform_coverage == N_POS // 4

    # P4: first-slot random usage across the full 1,024-sequence evaluation batch.
    random_topi = np.asarray(raw["random"]["topi"], dtype=np.int64)
    random_counts = np.bincount(random_topi[:, 0], minlength=N_POS // 4)
    expected_share = 1.0 / (N_POS // 4)
    random_usage = random_counts / max(int(random_counts.sum()), 1)
    p4_dev = float(np.max(np.abs(random_usage - expected_share) / expected_share))
    p4 = p4_dev < P4_MAX_REL_DEV
    random_dup = float(np.mean(random_topi[:, 0] == random_topi[:, 1]))

    # P5: finite scale check; P6: the 4-policy contrast is not fully at endpoints.
    ce_values = [policy[p]["ce_all"] for p in POLICIES]
    p5 = bool(np.isfinite(ce_values).all() and max(ce_values) <= P5_LIMIT)
    iv_values = [policy[p]["instr_valid"] for p in POLICIES]
    p6_uninformative = bool(all(v in (0.0, 1.0) for v in iv_values))
    p6 = not p6_uninformative

    # C7: compare epoch-6 training evaluator with learned-policy re-evaluation on the same data.
    final_eval = out["evals"][-1]
    c7 = {
        "ce_all_diff": abs(float(final_eval["ce_all"]) - policy["learned"]["ce_all"]),
        "instr_valid_diff": abs(float(final_eval["instr_valid"])
                                  - policy["learned"]["instr_valid"]),
    }
    c7["pass"] = bool(max(c7["ce_all_diff"], c7["instr_valid_diff"]) <= EPS_EVAL)

    tail_iv = [float(e["instr_valid"]) for e in out["evals"][-Q2.TAIL_K:]]
    tail_ce = [float(e["ce_all"]) for e in out["evals"][-Q2.TAIL_K:]]
    iv_main = float(np.median(tail_iv))
    ce_main = float(np.median(tail_ce))
    gate = Q2.tail_stats(out["loss_hist"])
    e_flag = bool((not np.isfinite(ce_main)) or ce_main > Q2.CE_ALL_LIMIT
                  or iv_main in (0.0, 1.0))
    e_plus = bool(iv_main >= Q2.IV_GATE_MIN)
    p_checks = {"P1_logits_distinct": p1, "P2_oracle_type_agreement": p2,
                "P3_uniform_coverage": p3, "P4_random_usage": p4,
                "P5_finite_and_bounded_ce": p5, "P6_not_endpoint_pinned": p6,
                "C7_same_checkpoint_eval": c7["pass"]}

    # Compare retrained legacy metrics to the preserved QA1S2 raw run.
    old_path = HERE / "data" / "a4" / f"{arm}_s{seed}{BASELINE_TAG}.json"
    old = json.loads(old_path.read_text(encoding="utf-8"))
    c1 = {
        "loss_hist_maxdiff": _maxdiff_numeric(out["loss_hist"], old["loss_hist"]),
        "evals_maxdiff": _maxdiff_numeric(
            [v for e in out["evals"] for k, v in e.items() if k != "ep"],
            [v for e in old["evals"] for k, v in e.items() if k != "ep"]),
        "summary_maxdiff": max(abs(float(out["gain"][k]) - float(old["gain"][k]))
                                for k in ("n", "min", "max", "mean")),
        "gain_by_expert_maxdiff": _maxdiff_numeric(
            out["gain"]["by_expert"], old["gain"]["by_expert"]),
    }
    c1["pass"] = bool(c1["loss_hist_maxdiff"] == 0 and c1["evals_maxdiff"] == 0
                       and c1["summary_maxdiff"] == 0
                       and c1["gain_by_expert_maxdiff"] < Q2.EPS_ROUND)

    full_gain = out["gain"]["by_position"]
    row = {
        "arm": arm, "seed": int(seed), "widths": list(widths),
        "width_sum": int(sum(widths)), "act_i": list(ACTS),
        "sec": float(out["sec"]), "loss_hist": [float(x) for x in out["loss_hist"]],
        "evals": out["evals"], "iv_series_tail": tail_iv, "iv_main": iv_main,
        "ce_all_main": ce_main, "T_plus": bool(gate["T_plus"]),
        "T": gate, "E_flag": e_flag, "E_plus": e_plus,
        "gain": {"mode": out["gain"]["mode"], "n": int(out["gain"]["n"]),
                 "min": float(out["gain"]["min"]), "max": float(out["gain"]["max"]),
                 "mean": float(out["gain"]["mean"]),
                 "by_expert": [float(v) for v in out["gain"]["by_expert"]],
                 "by_position": full_gain},
        "gain_key_count": len(full_gain),
        "gain_nonfinite": int(sum(not np.isfinite(v) for v in full_gain.values())),
        "same_p": bool(same_p), "same_gain_l": bool(same_gain_l),
        "policies": policy,
        "P": {"logits_pair_maxdiff": logits_diff,
              "oracle_typ_agreement": p2_agreement,
              "uniform_expert_coverage": uniform_coverage,
              "random_usage_max_rel_dev": p4_dev,
              "random_topi_dup_rate": random_dup,
              "random_usage_counts": random_counts.astype(int).tolist(),
              "uninformative": p6_uninformative, "pass": p_checks},
        "C1_legacy_reproduction": c1,
        "C7_final_eval_vs_policy_eval": c7,
        "_raw": {
            "first_logits": np.stack([np.asarray(raw[p]["first_logits"], dtype=np.float32)
                                       for p in POLICIES]),
            "random_topi": np.asarray(raw["random"]["topi"], dtype=np.int16),
            "oracle_topi": np.asarray(raw["oracle"]["topi"], dtype=np.int16),
            "uniform_topi": np.asarray(raw["uniform"]["topi"], dtype=np.int16),
            "typ_flat": np.asarray(raw["oracle"]["typ_flat"], dtype=np.int16),
        },
    }
    return row


def global_c1_gain_reference() -> dict:
    base_path = HERE / "data" / "a4" / "all_relu2_s0_g.json"
    check_path = HERE / "data" / "a4" / "all_relu2_s0_qa1s2c1.json"
    base = json.loads(base_path.read_text(encoding="utf-8"))["gain"]
    checked = json.loads(check_path.read_text(encoding="utf-8"))["gain"]
    d = {"n": abs(int(base["n"]) - int(checked["n"])),
         "min": abs(float(base["min"]) - float(checked["min"])),
         "max": abs(float(base["max"]) - float(checked["max"])),
         "mean": abs(float(base["mean"]) - float(checked["mean"])),
         "by_expert_maxdiff": _maxdiff_numeric(base["by_expert"], checked["by_expert"])}
    return {"diff": d, "pass": bool(max(d[k] for k in ("n", "min", "max", "mean")) == 0
                                      and d["by_expert_maxdiff"] < Q2.EPS_ROUND)}


def analyze(rows: list[dict], smoke: bool, runtime: float) -> dict:
    rows = sorted(rows, key=lambda r: (list(ARMS).index(r["arm"]), r["seed"]))
    checks = {}
    checks["C1"] = bool(global_c1_gain_reference()["pass"] and
                        all(r["C1_legacy_reproduction"]["pass"] for r in rows))
    checks["C2"] = bool(all(r["gain_key_count"] == N_POS and r["gain_nonfinite"] == 0
                            for r in rows))
    checks["C3"] = bool(all(r["width_sum"] == Q2.WIDTH_TOTAL and r["act_i"] == ACTS
                            for r in rows))
    cells = {(t, e): 0 for t in (True, False) for e in (True, False)}
    for r in rows:
        cells[(r["T_plus"], r["E_plus"])] += 1
    expected = 1 if smoke else len(ARMS) * len(SEEDS)
    checks["C4"] = bool(len(rows) == expected and sum(cells.values()) == expected)
    checks["C5"] = bool(all(
        r["P"]["pass"][k] for r in rows for k in
        ("P1_logits_distinct", "P2_oracle_type_agreement", "P3_uniform_coverage",
         "P4_random_usage", "P5_finite_and_bounded_ce", "P6_not_endpoint_pinned")) and
        all(r["policies"]["random"]["instr_valid"] <= r["policies"]["oracle"]["instr_valid"]
            for r in rows))
    checks["C6"] = True
    checks["C7"] = bool(all(r["C7_final_eval_vs_policy_eval"]["pass"] for r in rows))
    nonfinite_paths = []
    def scan(x, path="root"):
        if isinstance(x, dict):
            for k, v in x.items(): scan(v, f"{path}.{k}")
        elif isinstance(x, (list, tuple)):
            for i, v in enumerate(x): scan(v, f"{path}[{i}]")
        elif isinstance(x, (float, np.floating)) and not np.isfinite(x):
            nonfinite_paths.append(path)
    scan(rows)
    checks["C6"] = not nonfinite_paths
    out = {
        "tag": TAG + ("_s1_smoke" if smoke else ""),
        "phase": "smoke" if smoke else "production",
        "design": "QA1S4課題設計書_補完gainと重複なしrandomで幅実験を再走する_20261116.md",
        "runtime_seconds": float(runtime),
        "rows": [{k: v for k, v in r.items() if k != "_raw"} for r in rows],
        "global_C1_gain_reference": global_c1_gain_reference(),
        "classification_grid": {f"T{'+' if t else '-'}E{'+' if e else '-'}": n
                                 for (t, e), n in cells.items()},
        "nonfinite_paths": nonfinite_paths, "checks": checks,
    }
    if not smoke and len(rows) == len(ARMS) * len(SEEDS):
        lookup = {(r["arm"], r["seed"]): r for r in rows}
        iv_ref = np.asarray([lookup[("w_ref", s)]["iv_main"] for s in SEEDS])
        iv_mid = np.asarray([lookup[("w_mid", s)]["iv_main"] for s in SEEDS])
        iv_flat = np.asarray([lookup[("w_flat", s)]["iv_main"] for s in SEEDS])
        out["primary"] = Q2.paired_stats(iv_mid, iv_ref)
        out["primary"]["estimand"] = "mean_seed[iv(w_mid)-iv(w_ref)]"
        out["exploratory"] = Q2.paired_stats(iv_flat, iv_ref)
        out["exploratory"]["estimand"] = "mean_seed[iv(w_flat)-iv(w_ref)]"
        out["three_point_summary"] = {
            arm: {p: {
                "iv_mean": float(np.mean([lookup[(arm, s)]["policies"][p]["instr_valid"]
                                           for s in SEEDS])),
                "ce_all_mean": float(np.mean([lookup[(arm, s)]["policies"][p]["ce_all"]
                                               for s in SEEDS])),
            } for p in POLICIES} for arm in ARMS}
    out["verdict"] = "PASS" if all(checks.values()) else "STOP"
    if smoke:
        out["confirmatory_test_run"] = False
    else:
        out["confirmatory判定可能"] = bool(all(checks.values()))
    return out


def cache_signature(arm: str, seed: int) -> dict:
    return {"version": CACHE_VERSION, "arm": arm, "seed": int(seed),
            "widths": list(ARMS[arm]), "epochs": Q2.EPOCHS, "lr": Q2.LR,
            "n_seqs": Q2.N_SEQS, "eval_n": Q2.EVAL_N,
            "complete_gain_map": True, "random_without_replacement": True,
            "design": "QA1S4-20261116"}


def cache_paths(arm: str, seed: int) -> tuple[Path, Path]:
    stem = f"qa1s4_{arm}_s{seed}"
    return CACHE_DIR / f"{stem}.json", CACHE_DIR / f"{stem}.npz"


def save_run_cache(row: dict) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    arm, seed = row["arm"], int(row["seed"])
    json_path, npz_path = cache_paths(arm, seed)
    clean = {k: v for k, v in row.items() if k != "_raw"}
    payload = {"signature": cache_signature(arm, seed), "row": clean}
    json_tmp = json_path.with_name(json_path.name + ".tmp")
    json_tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False),
                        encoding="utf-8")
    raw_tmp = npz_path.with_name(npz_path.name + ".tmp")
    with raw_tmp.open("wb") as fh:
        np.savez_compressed(fh, **row["_raw"])
    json_tmp.replace(json_path)
    raw_tmp.replace(npz_path)


def load_run_cache(arm: str, seed: int) -> dict | None:
    json_path, npz_path = cache_paths(arm, seed)
    if not json_path.exists() and not npz_path.exists():
        return None
    if not json_path.exists() or not npz_path.exists():
        # A prior interrupted write may leave only one half of this task-owned cache.
        # Discard that incomplete pair and recompute the run from its fixed seed.
        if json_path.exists():
            json_path.unlink()
        if npz_path.exists():
            npz_path.unlink()
        return None
    payload = json.loads(json_path.read_text(encoding="utf-8"))
    expected = cache_signature(arm, seed)
    if payload.get("signature") != expected:
        raise RuntimeError(f"QA1S4 cache signature mismatch for {arm} seed {seed}")
    with np.load(npz_path, allow_pickle=False) as z:
        raw = {k: z[k] for k in z.files}
    return {**payload["row"], "_raw": raw}


def load_smoke_as_production(arm: str, seed: int) -> dict | None:
    """Reuse a fully identical smoke run only when the production raw output confirms it."""
    if (arm, int(seed)) != ("w_ref", 0):
        return None
    metrics_path = HERE / "qa1s4_s1_smoke_metrics.json"
    arrays_path = HERE / "qa1s4_s1_smoke_arrays.npz"
    prod_path = HERE / "data" / "a4" / f"{arm}_s{seed}{PROD_TAG}.json"
    if not metrics_path.exists() or not arrays_path.exists() or not prod_path.exists():
        return None
    smoke = json.loads(metrics_path.read_text(encoding="utf-8"))
    if smoke.get("verdict") != "PASS" or len(smoke.get("rows", [])) != 1:
        return None
    row = smoke["rows"][0]
    if row.get("arm") != arm or int(row.get("seed", -1)) != int(seed):
        return None
    prod = json.loads(prod_path.read_text(encoding="utf-8"))
    smoke_gain = row["gain"]["by_position"]
    prod_gain = prod["gain"]["by_position"]
    gain_keys_match = set(smoke_gain) == set(prod_gain)
    gain_pos_diff = (max((abs(float(smoke_gain[k]) - float(prod_gain[k]))
                          for k in smoke_gain), default=0.0)
                     if gain_keys_match else float("inf"))
    exact = (_maxdiff_numeric(row["loss_hist"], prod["loss_hist"]) == 0 and
             _maxdiff_numeric([v for e in row["evals"] for k, v in e.items() if k != "ep"],
                              [v for e in prod["evals"] for k, v in e.items() if k != "ep"]) == 0 and
             _maxdiff_numeric(row["gain"]["by_expert"], prod["gain"]["by_expert"]) < Q2.EPS_ROUND and
             gain_pos_diff == 0 and len(prod_gain) == N_POS)
    if not exact:
        return None
    with np.load(arrays_path, allow_pickle=False) as z:
        raw = {k: z[k][0] for k in ("first_logits", "random_topi", "oracle_topi",
                                      "uniform_topi", "typ_flat")}
    return {**row, "_raw": raw}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--smoke", action="store_true", help="w_ref seed 0 only; no confirmatory test")
    ap.add_argument("--no-resume", action="store_true", help="ignore per-run production caches")
    args = ap.parse_args()
    jobs = [("w_ref", 0)] if args.smoke else [(a, s) for a in ARMS for s in SEEDS]
    tag = SMOKE_TAG if args.smoke else PROD_TAG
    rows, t0 = [], time.time()
    for i, (arm, seed) in enumerate(jobs, 1):
        cached = None if (args.smoke or args.no_resume) else load_run_cache(arm, seed)
        if cached is None and not args.smoke and not args.no_resume:
            cached = load_smoke_as_production(arm, seed)
            if cached is not None:
                save_run_cache(cached)
        if cached is not None:
            rows.append(cached)
            print(f"[{i}/{len(jobs)}] cached {arm} seed={seed}", flush=True)
            continue
        print(f"[{i}/{len(jobs)}] start {arm} seed={seed}", flush=True)
        row = _run(arm, seed, tag)
        rows.append(row)
        if not args.smoke:
            save_run_cache(row)
        print(f"[{i}/{len(jobs)}] done {arm} seed={seed} iv={row['iv_main']:.6f} "
              f"dup={row['P']['random_topi_dup_rate']:.6f} C7={row['C7_final_eval_vs_policy_eval']['pass']} "
              f"({time.time()-t0:.0f}s)", flush=True)
        # Keep each finished run recoverable if the long wrapper is interrupted.
        partial = analyze(rows, args.smoke, time.time() - t0)
        partial_path = HERE / ("qa1s4_s1_smoke_metrics.json" if args.smoke
                               else "qa1s4_partial_metrics.json")
        temp = partial_path.with_suffix(".tmp")
        temp.write_text(json.dumps(partial, ensure_ascii=False, indent=2, allow_nan=False),
                        encoding="utf-8")
        temp.replace(partial_path)
    out = analyze(rows, args.smoke, time.time() - t0)
    metric_name = "qa1s4_s1_smoke_metrics.json" if args.smoke else "qa1s4_metrics.json"
    log_name = "qa1s4_s1_smoke.log" if args.smoke else "qa1s4.log"
    (HERE / metric_name).write_text(json.dumps(out, ensure_ascii=False, indent=2,
                                                allow_nan=False), encoding="utf-8")
    raw_tag = "qa1s4_s1_smoke_arrays.npz" if args.smoke else "qa1s4_control_arrays.npz"
    raw_rows = sorted(rows, key=lambda r: (list(ARMS).index(r["arm"]), r["seed"]))
    raw_arrays = {
        "first_logits": np.stack([r["_raw"]["first_logits"] for r in raw_rows]),
        "random_topi": np.stack([r["_raw"]["random_topi"] for r in raw_rows]),
        "oracle_topi": np.stack([r["_raw"]["oracle_topi"] for r in raw_rows]),
        "uniform_topi": np.stack([r["_raw"]["uniform_topi"] for r in raw_rows]),
        "typ_flat": np.stack([r["_raw"]["typ_flat"] for r in raw_rows]),
        "arm": np.asarray([r["arm"] for r in raw_rows]),
        "seed": np.asarray([r["seed"] for r in raw_rows], dtype=np.int64),
    }
    np.savez_compressed(HERE / raw_tag, **raw_arrays)
    if not args.smoke and len(rows) == len(ARMS) * len(SEEDS):
        lookup = {(r["arm"], r["seed"]): r for r in rows}
        iv_ref = np.asarray([lookup[("w_ref", s)]["iv_main"] for s in SEEDS], dtype=np.float64)
        iv_mid = np.asarray([lookup[("w_mid", s)]["iv_main"] for s in SEEDS], dtype=np.float64)
        iv_flat = np.asarray([lookup[("w_flat", s)]["iv_main"] for s in SEEDS], dtype=np.float64)
        np.savez_compressed(HERE / "qa1s4_delta.npz", seeds=np.asarray(SEEDS),
                            iv_ref=iv_ref, iv_mid=iv_mid, iv_flat=iv_flat,
                            delta_iv_per_seed=iv_mid - iv_ref,
                            policy_iv=np.asarray([[lookup[(a, s)]["policies"][p]["instr_valid"]
                                                   for p in POLICIES]
                                                  for a in ARMS for s in SEEDS], dtype=np.float64),
                            policy_ce_all=np.asarray([[lookup[(a, s)]["policies"][p]["ce_all"]
                                                       for p in POLICIES]
                                                      for a in ARMS for s in SEEDS], dtype=np.float64),
                            random_dup=np.asarray([[lookup[(a, s)]["P"]["random_topi_dup_rate"]
                                                    for s in SEEDS] for a in ARMS], dtype=np.float64))
    lines = [f"tag={TAG}{'_s1_smoke' if args.smoke else ''}",
             f"verdict={out['verdict']}", f"runtime_seconds={out['runtime_seconds']:.1f}",
             f"checks={out['checks']}", f"classification={out['classification_grid']}"]
    if "primary" in out:
        p = out["primary"]
        lines.append(f"Delta_iv={p['delta']:.8f} se={p['se']:.8f} t={p['t']} "
                     f"p={p['p']:.8g} n={p['n']} MDE={p['mde']:.8f} CI90={p['ci90']}")
    (HERE / log_name).write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines), flush=True)


if __name__ == "__main__":
    main()
