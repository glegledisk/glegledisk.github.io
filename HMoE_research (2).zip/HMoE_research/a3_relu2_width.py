#!/usr/bin/env python3
"""A3: 仮説「ReLU² の勝ちは幅で説明できる」の検証。

A1 では ReLU² は**一度も勝たなかった**（`relu2_w15 − swiglu` は 0/6, p=0.0013）。
その帯は最適化律速で、幅は資源ではなくコストだった（params を増やすと悪化する）。
**「ReLU² の勝ち」は容量が縛られる帯でしか意味を持たない**ので、ここでは
幅を絞って容量を縛り、その上で活性化 × 幅の 2 因子を振る。

設計（3 活性化 × 幅 2 水準 = 6 アーム）
  arm          act     幅   行列  params/MACs
  relu_1x      ReLU    1.0   2     2dw
  relu_15x     ReLU    1.5   2     3dw
  relu2_1x     ReLU²   1.0   2     2dw
  relu2_15x    ReLU²   1.5   2     3dw   ← swiglu_1x と**等 params・等 MACs**
  swiglu_1x    SwiGLU  1.0   3     3dw
  swiglu_15x   SwiGLU  1.5   3     4.5dw

検定の構造
  仮説 H「ReLU² の勝ちは幅で説明できる」= 品質は幅だけで決まる、の系として
    (a) relu2_1x < swiglu_1x（等幅では ReLU² が負ける＝パラメータが 2/3 だから）
    (b) relu2_15x ≈ swiglu_1x（幅を 1.5 倍にして初めて追いつく＝勝ちの正体は幅）
  対立 H'「形が効く」
    (a') relu2_1x ≈ swiglu_1x
    (b') relu2_15x > swiglu_1x
  どちらも起きず relu2_15x < swiglu_1x なら「ReLU² は幅を与えても負ける」（A1 の再現）。

出力: data/a3/{arm}_s{seed}.json, ce_{arm}_s{seed}.npy, a3_results.json
"""
import argparse
import json
import math
import os
import sys
import time
import traceback

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import q1_trace_routing as Q1                                    # noqa: E402
from a1_activation_ffn import (ActMoE, Adam, BASE_W, branch_rms,  # noqa: E402
                               evaluate, NMAT)

OUTDIR = os.path.join(HERE, "data", "a3")

ARMS = {
    "relu_1x":    dict(act="relu",   mult=1.0),
    "relu_15x":   dict(act="relu",   mult=1.5),
    "relu2_1x":   dict(act="relu2",  mult=1.0),
    "relu2_15x":  dict(act="relu2",  mult=1.5),
    "swiglu_1x":  dict(act="swiglu", mult=1.0),
    "swiglu_15x": dict(act="swiglu", mult=1.5),
}


def widths_of(arm, scale):
    c = ARMS[arm]
    return tuple(max(4, int(round(w * scale * c["mult"]))) for w in BASE_W)


def run_one(arm, seed, scale, n_seqs, epochs, bs, lr, auxw, eval_every=1):
    torch.set_num_threads(1)
    cfg = ARMS[arm]
    widths = widths_of(arm, scale)
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)

    cal_rng = np.random.default_rng(999)
    cal_seq, _ = Q1.make_trace_batch(cal_rng, 128)
    model = ActMoE(widths, cfg["act"], seed=seed)
    rms_self = branch_rms(model, cal_seq)
    ref = ActMoE(widths, "relu", seed=seed)
    rms_ref = rms_self if cfg["act"] == "relu" else branch_rms(ref, cal_seq)
    model.gain = rms_ref / max(rms_self, 1e-12)

    opt = Adam(model.params(), lr=lr)
    nparam = sum(v.numel() for v in model.params().values())
    macs = model.k * sum(widths) * model.d * NMAT[cfg["act"]] / len(widths)
    steps_per_ep = max(1, n_seqs // bs)
    t0 = time.time()
    hist, evals = [], []
    ev_rng = np.random.default_rng(777)
    ev_seq, ev_typ = Q1.make_trace_batch(ev_rng, 1024)
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps_per_ep):
            seq, _ = Q1.make_trace_batch(rng, bs)
            x = torch.from_numpy(seq)
            logits, aux, _ = model(x, aux_mode="p_pen")
            loss = Q1.trace_loss(logits, seq) + auxw * aux
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        hist.append(run / steps_per_ep)
        if (ep + 1) % eval_every == 0 or ep == epochs - 1:
            ev, _ = evaluate(model, ev_seq, ev_typ)
            ev["ep"] = ep + 1
            evals.append(ev)

    out = {"arm": arm, "seed": seed, "act": cfg["act"], "mult": cfg["mult"],
           "scale": scale, "widths": list(widths), "n_mat": NMAT[cfg["act"]],
           "nparam": nparam, "nominal_macs": macs, "gain": model.gain,
           "rms_init_raw": rms_self, "rms_init_ref": rms_ref,
           "loss_hist": hist, "evals": evals, "sec": round(time.time() - t0, 1)}
    os.makedirs(OUTDIR, exist_ok=True)
    with open(os.path.join(OUTDIR, f"{arm}_s{seed}.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    return out


def _worker(job):
    try:
        return run_one(**job)
    except Exception:
        return {"arm": job.get("arm"), "seed": job.get("seed"),
                "error": traceback.format_exc()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", nargs="+", default=list(ARMS))
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4, 5])
    ap.add_argument("--scale", type=float, default=0.5, help="BASE_W に掛ける倍率（容量を縛る）")
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--auxw", type=float, default=0.05)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--tag", default="")
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()

    os.makedirs(OUTDIR, exist_ok=True)
    if args.smoke:
        args.arms, args.seeds, args.epochs, args.workers = ["relu_1x", "relu2_1x"], [0], 1, 2

    kw = dict(scale=args.scale, n_seqs=args.seqs, epochs=args.epochs, bs=args.bs,
              lr=args.lr, auxw=args.auxw, eval_every=1)
    jobs = [dict(arm=a, seed=s, **kw) for a in args.arms for s in args.seeds]
    print(f"scale={args.scale} arms={len(args.arms)} seeds={len(args.seeds)} "
          f"jobs={len(jobs)} epochs={args.epochs}", flush=True)
    for a in args.arms:
        print(f"  {a:11s} widths={widths_of(a, args.scale)}", flush=True)

    from concurrent.futures import ProcessPoolExecutor, as_completed
    rows, t0 = [], time.time()
    with ProcessPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(_worker, j): j for j in jobs}
        for k, fu in enumerate(as_completed(futs), 1):
            r = fu.result()
            if "error" in r:
                print(f"[FAIL] {r.get('arm')} s{r.get('seed')}\n{r['error']}", flush=True)
                continue
            rows.append(r)
            e = r["evals"][-1]
            print(f"[{k}/{len(jobs)}] {r['arm']:11s} s{r['seed']} CE={e['ce_all']:.4f} "
                  f"iv={e['instr_valid']:.3f} params={r['nparam']:,} "
                  f"({r['sec']:.0f}s, tot {time.time()-t0:.0f}s)", flush=True)

    with open(os.path.join(OUTDIR, f"a3_results{args.tag}.json"), "w", encoding="utf-8") as fh:
        json.dump(rows, fh, ensure_ascii=False, indent=2)
    print(f"\n[write] {OUTDIR} ({time.time()-t0:.0f}s)", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
