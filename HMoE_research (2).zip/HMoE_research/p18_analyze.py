# -*- coding: utf-8 -*-
"""P18 解析: mid-flight 通信は best-of-N の独立性を壊すか

arm A: 独立 8 本（P14） / arm B: 先頭の答えを後続 7 本に注入 / arm C: 無情報の数字を注入
B − C が「情報の伝達」の効果、C − A が「prompt が長くなった」効果。

主指標:
  copy_rate      : 後続 7 本のうち注入値と同じ答えを出した割合
  error_corr     : P(両方誤) / P(誤)^2（1 が独立、>1 が正相関）
  pass@8, maj    : 多様性と多数決
  recovery       : (maj − pass@1) / (pass@8 − pass@1)

出力: p18_analysis.json / p18_analysis_out_utf8.txt
"""
import json
import os
from collections import Counter

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = []


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def majority(preds):
    """最多票。同点は「先に現れた方」で切る（全 arm で同じ規則）。"""
    c = Counter([p for p in preds if p is not None])
    if not c:
        return None, 0, True
    top = c.most_common()
    best = top[0][1]
    tie = sum(1 for _, v in top if v == best) > 1
    for p in preds:                      # 先頭優先
        if p is not None and c[p] == best:
            return p, best, tie
    return top[0][0], best, tie


def paired(a):
    a = np.asarray(a, float)
    a = a[np.isfinite(a)]
    sd = float(np.std(a, ddof=1))
    se = sd / np.sqrt(len(a))
    t, p = stats.ttest_1samp(a, 0.0) if sd > 0 else (float("nan"), float("nan"))
    return {"mean": float(np.mean(a)), "se": float(se), "t": float(t), "p": float(p),
            "n": int(len(a)), "mde80": float(2.802 * sd / np.sqrt(len(a))) if sd > 0 else float("nan")}


def main():
    recs = [json.loads(l) for l in open(os.path.join(HERE, "p18_comm.jsonl"),
                                        encoding="utf-8") if l.strip()]
    # arm A
    A = {}
    for line in open(os.path.join(HERE, "p14_bestofn.jsonl"), encoding="utf-8"):
        r = json.loads(line)
        if r.get("round") == "greedy":
            continue
        A[(r["round"], r["q"])] = r["samples"]
    log("records=%d  armA=%d" % (len(recs), len(A)))

    arms = ["A", "B", "C"]
    per = {a: {"maj": [], "pass8": [], "s1": [], "copy": [], "ndist": [],
               "share": [], "both_wrong": [], "p_wrong": [], "tie": 0} for a in arms}
    inj_hit = {"B": [], "C": []}

    for r in recs:
        key = (r["round"], r["q"])
        gold = r["gold"]
        sA = A[key]
        full = {
            "A": sA,
            "B": [sA[0]] + r["arms"]["B"],
            "C": [sA[0]] + r["arms"]["C"],
        }
        for a in arms:
            ss = full[a]
            preds = [s["pred"] for s in ss]
            corr = [bool(s["correct"]) for s in ss]
            mp, cnt, tie = majority(preds)
            per[a]["maj"].append(float(mp == gold))
            per[a]["pass8"].append(float(any(corr)))
            per[a]["s1"].append(float(corr[0]))
            per[a]["share"].append(cnt / 8.0)
            per[a]["tie"] += int(tie)
            per[a]["ndist"].append(len(set(p for p in preds if p is not None)))
            # 誤り相関: 8 本の全ペア
            pw = 1.0 - float(np.mean(corr))
            bw = 0.0
            n = 0
            for i in range(8):
                for j in range(i + 1, 8):
                    bw += float((not corr[i]) and (not corr[j]))
                    n += 1
            per[a]["p_wrong"].append(pw)
            per[a]["both_wrong"].append(bw / n)
        for a in ["B", "C"]:
            inj = r["inj_ans"] if a == "B" else r["placebo"]
            hits = sum(1 for s in r["arms"][a] if s["pred"] == inj)
            inj_hit[a].append(hits / float(len(r["arms"][a])))

    # ---- 表 1: arm 別の水準 ----
    log("\n[1] arm summary (n=%d pairs)" % len(recs))
    log("  %-4s %8s %8s %8s %8s %8s %8s %8s" %
        ("arm", "s1", "maj", "pass@8", "recovery", "share", "ndist", "err_corr"))
    summ = {}
    for a in arms:
        s1 = float(np.mean(per[a]["s1"]))
        mj = float(np.mean(per[a]["maj"]))
        p8 = float(np.mean(per[a]["pass8"]))
        rec = (mj - s1) / (p8 - s1) if (p8 - s1) > 1e-9 else float("nan")
        pw = float(np.mean(per[a]["p_wrong"]))
        bw = float(np.mean(per[a]["both_wrong"]))
        ec = bw / (pw ** 2) if pw > 1e-9 else float("nan")
        summ[a] = {"s1": s1, "maj": mj, "pass8": p8, "recovery": rec,
                   "share": float(np.mean(per[a]["share"])),
                   "ndist": float(np.mean(per[a]["ndist"])), "err_corr": ec,
                   "p_wrong": pw, "both_wrong": bw, "ties": per[a]["tie"]}
        log("  %-4s %8.4f %8.4f %8.4f %8.3f %8.4f %8.2f %8.2f"
            % (a, s1, mj, p8, rec, summ[a]["share"], summ[a]["ndist"], ec))

    log("\n  injection hit rate (後続 7 本が注入値と一致した割合)")
    for a in ["B", "C"]:
        log("    %s: %.4f  (B は先頭の答え、C は無情報の乱数)" % (a, float(np.mean(inj_hit[a]))))

    # ---- 表 2: 対応差 ----
    log("\n[2] paired diffs (n=%d)" % len(recs))
    tests = []
    for x, y in [("B", "A"), ("C", "A"), ("B", "C")]:
        for metric in ["maj", "pass8"]:
            d = np.array(per[x][metric]) - np.array(per[y][metric])
            a = np.array(per[x][metric]).astype(bool)
            b = np.array(per[y][metric]).astype(bool)
            w10 = int(np.sum(a & ~b))
            w01 = int(np.sum(~a & b))
            pmc = (float(stats.binomtest(w10, w10 + w01, 0.5).pvalue)
                   if (w10 + w01) > 0 else float("nan"))
            t_ = {"pair": "%s - %s" % (x, y), "metric": metric,
                  "diff": paired(d), "mcnemar": {"w": w10, "b": w01, "p": pmc}}
            tests.append(t_)
            log("  %-8s %-7s d=%+.4f (t=%+.2f, p=%.3g, McN %d/%d p=%.3g, MDE80 %.4f)"
                % (t_["pair"], metric, t_["diff"]["mean"], t_["diff"]["t"],
                   t_["diff"]["p"], w10, w01, pmc, t_["diff"]["mde80"]))
    # 誤り相関の差（周辺確率の交絡を除くため excess = both_wrong − p_wrong^2 も見る）
    for x, y in [("B", "A"), ("C", "A"), ("B", "C")]:
        d = np.array(per[x]["both_wrong"]) - np.array(per[y]["both_wrong"])
        log("  %-8s both_wrong d=%+.4f (t=%+.2f, p=%.3g)"
            % ("%s - %s" % (x, y), d.mean(), *stats.ttest_1samp(d, 0)[:2]))
    log("\n  --- 周辺確率を除いた相関 (excess = P(両方誤) − P(誤)^2) ---")
    excess = {}
    for a in arms:
        ex = np.array(per[a]["both_wrong"]) - np.array(per[a]["p_wrong"]) ** 2
        excess[a] = ex
        log("    %s: mean=%+.4f (n=%d, >0 が正相関)" % (a, ex.mean(), len(ex)))
    for x, y in [("B", "A"), ("C", "A"), ("B", "C")]:
        d = excess[x] - excess[y]
        log("  %-8s excess d=%+.4f (t=%+.2f, p=%.3g)"
            % ("%s - %s" % (x, y), d.mean(), *stats.ttest_1samp(d, 0)[:2]))

    # 多様性の対応差
    log("\n  --- 多様性 (distinct answers / vote share) ---")
    for metric in ["ndist", "share"]:
        for x, y in [("B", "A"), ("C", "A"), ("B", "C")]:
            d = np.array(per[x][metric]) - np.array(per[y][metric])
            log("  %-8s %-6s d=%+.4f (t=%+.2f, p=%.3g)"
                % ("%s - %s" % (x, y), metric, d.mean(), *stats.ttest_1samp(d, 0)[:2]))

    # 注入コピーの条件付き率（s1 が正しいとき / 誤りのとき）
    log("\n  --- 注入コピーは選択的か（s1 の正誤で分ける）---")
    log("      対照 = arm A の後続 7 本が s1 の答えと一致する率（注入なしの自然一致）")
    cond = {}
    for a in ["B", "C"]:
        for lab, want in [("s1_correct", True), ("s1_wrong", False)]:
            vals, base = [], []
            for i, r in enumerate(recs):
                if bool(per["A"]["s1"][i]) != want:
                    continue
                inj = r["inj_ans"] if a == "B" else r["placebo"]
                hits = sum(1 for s in r["arms"][a] if s["pred"] == inj)
                vals.append(hits / float(len(r["arms"][a])))
                s1p = A[(r["round"], r["q"])][0]["pred"]
                nat = sum(1 for s in A[(r["round"], r["q"])][1:] if s["pred"] == s1p)
                base.append(nat / 7.0)
            cond["%s|%s" % (a, lab)] = {"mean": float(np.mean(vals)),
                                        "natural": float(np.mean(base)),
                                        "excess": float(np.mean(vals) - np.mean(base)),
                                        "n": len(vals)}
            log("    %s  %-11s copy=%.4f  自然一致=%.4f  超過=%+.4f (n=%d)"
                % (a, lab, np.mean(vals), np.mean(base),
                   np.mean(vals) - np.mean(base), len(vals)))
    e_ok = cond["B|s1_correct"]["excess"]
    e_bad = cond["B|s1_wrong"]["excess"]
    log("    → 超過の差 (s1 正 − s1 誤) = %+.4f  [>0 なら『正しい方に強く引かれる』]"
        % (e_ok - e_bad))

    # 多数決が反転したペアの中身
    log("\n  --- majority flips (A vs B) ---")
    for i, r in enumerate(recs):
        ma, mb = per["A"]["maj"][i], per["B"]["maj"][i]
        if ma == mb:
            continue
        log("    %s | gold=%s | A_maj=%d B_maj=%d | s1 correct=%s | inj=%s | "
            "A_ndist=%d B_ndist=%d"
            % (r["q"], r["gold"], ma, mb, bool(per["A"]["s1"][i]), r["inj_ans"],
               per["A"]["ndist"][i], per["B"]["ndist"][i]))

    out = {"n_pairs": len(recs), "summary": summ, "tests": tests,
           "inj_hit": {a: float(np.mean(inj_hit[a])) for a in ["B", "C"]},
           "excess_corr": {a: float(np.mean(excess[a])) for a in arms},
           "copy_conditional": cond,
           "both_wrong_tests": {}}
    for x, y in [("B", "A"), ("C", "A"), ("B", "C")]:
        d = np.array(per[x]["both_wrong"]) - np.array(per[y]["both_wrong"])
        out["both_wrong_tests"]["%s-%s" % (x, y)] = paired(d)
        out.setdefault("excess_tests", {})["%s-%s" % (x, y)] = paired(excess[x] - excess[y])

    with open(os.path.join(HERE, "p18_analysis.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    with open(os.path.join(HERE, "p18_analysis_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    log("saved: p18_analysis.json")
    os._exit(0)


if __name__ == "__main__":
    main()
