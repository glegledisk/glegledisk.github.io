#!/usr/bin/env python3
"""A1 の図。data/a1/a1_analysis.json を読むだけ（測定と分離）。"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "MS Gothic", "sans-serif"]
matplotlib.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a1")
with open(os.path.join(D, "a1_analysis.json"), encoding="utf-8") as fh:
    J = json.load(fh)
A, C = J["aggregate"], J["contrasts"]

ORDER = [a for a in sorted(A, key=lambda k: -A[k]["iv"])]
GROUP = {}
for a in ORDER:
    if a.startswith("silu"):
        GROUP[a] = "#4c72b0"          # 2 行列・滑らか
    elif a.startswith("relu2"):
        GROUP[a] = "#c44e52"          # 2 行列・二乗
    elif a.startswith("drelu"):
        GROUP[a] = "#8172b2"          # 3 行列・ReLU ゲート
    elif a.startswith("swiglu"):
        GROUP[a] = "#dd8452"          # 3 行列・SiLU ゲート
    else:
        GROUP[a] = "#55a868"          # relu 系（幅を振る）

fig, (ax1, ax2, ax3) = plt.subplots(1, 3, figsize=(17, 5.0),
                                    gridspec_kw={"width_ratios": [1.25, 1.0, 1.0]})

# --- (a) instr_valid ---
xs = np.arange(len(ORDER))
iv = [A[a]["iv"] for a in ORDER]
sd = [A[a]["iv_sd"] for a in ORDER]
ax1.bar(xs, iv, yerr=sd, capsize=3, color=[GROUP[a] for a in ORDER],
        edgecolor="black", linewidth=0.6)
ax1.axhline(A["relu"]["iv"], color="black", ls="--", lw=1)
ax1.text(len(ORDER) - 0.4, A["relu"]["iv"] + 0.015, "relu", fontsize=8, ha="right")
ax1.set_xticks(xs)
ax1.set_xticklabels([f"{a}\n{A[a]['nparam']/1e6:.2f}M" for a in ORDER],
                    rotation=45, ha="right", fontsize=8)
ax1.set_ylabel("instr_valid（0-1、6 seed 平均 ± SD）")
ax1.set_title("(a) 系列ごとの到達点（3 epoch 固定予算）", fontsize=11)
ax1.grid(axis="y", alpha=0.3)
ax1.set_ylim(0, 1.0)

# --- (b) instr_valid vs params ---
for a in ORDER:
    ax2.scatter(A[a]["nparam"] / 1e6, A[a]["iv"], s=70, color=GROUP[a],
                edgecolor="black", linewidth=0.6, zorder=3)
    ax2.annotate(a, (A[a]["nparam"] / 1e6, A[a]["iv"]), fontsize=7,
                 xytext=(4, 4), textcoords="offset points")
ax2.axhline(A["relu"]["iv"], color="black", ls="--", lw=1)
ax2.set_xlabel("パラメータ数（百万）")
ax2.set_ylabel("instr_valid")
ax2.set_title("(b) パラメータを増やすと悪化する", fontsize=11)
ax2.grid(alpha=0.3)
ax2.set_ylim(0, 1.0)

# --- (c) forest（instr_valid）---
sub = [c for c in C if c["metric"] == "instr_valid"]
sub = sorted(sub, key=lambda c: c["mean"])
ys = np.arange(len(sub))
for y, c in zip(ys, sub):
    sig = c["p"] < 0.05
    ax3.plot([c["ci_lo"], c["ci_hi"]], [y, y], color="black" if sig else "gray", lw=2)
    ax3.plot(c["mean"], y, "o", color="#c44e52" if sig else "white",
             markeredgecolor="black", ms=8, zorder=3)
    ax3.text(c["ci_hi"] + 0.02, y, f"{c['mean']:+.2f}", va="center", fontsize=7)
ax3.axvline(0, color="black", lw=1)
ax3.set_yticks(ys)
ax3.set_yticklabels([f"{c['a']} − {c['b']}" for c in sub], fontsize=8)
ax3.set_xlabel("Δinstr_valid（seed 対応差、95%CI）")
ax3.set_title("(c) 対比（黒＝p<0.05）", fontsize=11)
ax3.grid(axis="x", alpha=0.3)

plt.tight_layout()
out = os.path.join(D, "a1_figure.png")
plt.savefig(out, dpi=150)
print(f"[write] {out}")
