# -*- coding: utf-8 -*-
"""e6_routing_7seed.py — E6 で free / sidecar を 60 epoch・7 seed で測定

目的:
  E6（ランダム 4096 エントリのルックアップ表）は d=64 でも FFN 寄与 0.243 nats を達成した。
  これにより「FFN が効く」条件が容量に依存しなくなった。
  ここで E5 d=16 で見られた「サイドカーが全 FFN に 7/7 で勝利」が再現するかを調べる。

  = HMoE 品質側テーゼの、容量に依存しない実証になる。

構成: L=16, A=64, lag=3, anchor_vals=range(16), d=64, epochs=60, λ=0.15
      4 アーム × 7 seed（不足分のみ実行）
"""
import os, json, time
import numpy as np
import pandas as pd
from e6_memory_task import run, make_lookup_table

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=64, lag=3, anchor_vals=tuple(range(16)), d=64, epochs=60)
ARMS = ["frozen_ffn", "frozen_identity", "free", "sidecar"]
SEEDS = list(range(7))
OUT = os.path.join(HERE, "e6_routing_7seed.csv")
LAMS = [0.03, 0.05, 0.08, 0.15, 0.30]
tab = make_lookup_table(64)

rows = []
if os.path.exists(OUT):
    rows = pd.read_csv(OUT).to_dict("records")
have = {(r["arm"], int(r["seed"])) for r in rows}
print(f"既存 {len(have)} 件")

todo = [(a, s) for a in ARMS for s in SEEDS if (a, s) not in have]
print(f"追加実行 {len(todo)} 件")

t0 = time.time()
for i, (arm, s) in enumerate(todo, 1):
    r = run(arm, s, table=tab, **CFG)
    r["arm"] = arm
    rows.append(r)
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"  [{i}/{len(todo)}] {arm:16s} s{s} | CE {r['ce_all']:.4f} | FFN {r['ffn_cost']:.3f} "
          f"| acc {r['acc_all']:.4f} (anchor {r['acc_anchor']:.3f}) | {time.time()-t0:.0f}s", flush=True)

df = pd.DataFrame(rows)
df["obj015"] = df["ce_all"] + 0.15 * df["ffn_cost"]
df = df.sort_values(["arm", "seed"]).reset_index(drop=True)
df.to_csv(OUT, index=False)

print("\n=== E6 ルーティング比較（60 epoch・7 seed, d=64, アンカー 25%） ===")
print(f"{'arm':16s} {'CE':>16s} {'FFN':>14s} {'obj(λ=.15)':>16s} {'acc':>16s} {'acc anchor':>16s}")
for a in ARMS:
    d = df[df.arm == a]
    print(f"{a:16s} {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f}  "
          f"{d['obj015'].mean():.4f}±{d['obj015'].std():.4f}  "
          f"{d['acc_all'].mean():.4f}±{d['acc_all'].std():.4f}  "
          f"{d['acc_anchor'].mean():.4f}±{d['acc_anchor'].std():.4f}")

piv = df.pivot_table(index="seed", columns="arm", values=["ce_all", "ffn_cost", "obj015", "acc_all"])

print("\n=== seed 対応差（各アーム − frozen_ffn、7 seeds） ===")
res = {}
for a in ["free", "sidecar"]:
    line = f" {a:8s}"
    for k in ("obj015", "ce_all", "ffn_cost", "acc_all"):
        d = (piv[k][a] - piv[k]["frozen_ffn"]).dropna()
        m, sd = d.mean(), d.std(ddof=1)
        t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
        rng = np.random.default_rng(0)
        boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(20000)])
        lo, hi = np.percentile(boot, [2.5, 97.5])
        wins = int((d < 0).sum()) if k != "acc_all" else int((d > 0).sum())
        res[f"{a}_{k}"] = {"mean": float(m), "sd": float(sd), "t": float(t),
                           "ci": [float(lo), float(hi)], "wins": wins, "n": int(len(d))}
        line += f" | {k} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {wins}/{len(d)}"
    print(line)

print("\n=== λ 感度 ===")
print(f"{'λ':>5s} " + "".join(f"{a:>15s}" for a in ARMS) + "   最良")
lam_tab = {}
for lam in LAMS:
    vals = {a: df[df.arm == a]["ce_all"].mean() + lam * df[df.arm == a]["ffn_cost"].mean() for a in ARMS}
    best = min(vals, key=vals.get)
    lam_tab[str(lam)] = {"vals": {k: float(v) for k, v in vals.items()}, "best": best}
    print(f"{lam:5.2f} " + "".join(f"{vals[a]:15.4f}" for a in ARMS) + f"   {best}")

ce_f = df[df.arm == "frozen_ffn"]["ce_all"].mean()
for a in ["free", "sidecar"]:
    ce_r = df[df.arm == a]["ce_all"].mean(); ff_r = df[df.arm == a]["ffn_cost"].mean()
    if ff_r < 1.0:
        print(f"\n {a} vs 全FFN の crossover λ* = {(ce_r - ce_f)/(1.0 - ff_r):.4f}")

print("\n=== seed 別（free / sidecar） ===")
for a in ["free", "sidecar"]:
    d = df[df.arm == a]
    print(f" {a:8s} CE  " + " ".join(f"{x:.3f}" for x in d["ce_all"]))
    print(f" {'':8s} FFN " + " ".join(f"{x:.3f}" for x in d["ffn_cost"]))
    print(f" {'':8s} obj " + " ".join(f"{x:.3f}" for x in d["obj015"]))

json.dump({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in CFG.items()},
           "summary": {a: {k: float(df[df.arm == a][k].mean()) for k in
                           ["ce_all", "ffn_cost", "obj015", "acc_all", "acc_anchor"]} for a in ARMS},
           "paired_vs_ffn": res, "lambda_sensitivity": lam_tab, "raw": rows},
          open(os.path.join(HERE, "e6_routing_7seed.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e6_routing_7seed.csv / .json")
