"""e4b_plan_injection.py — E4b: PLAN信号注入によるルータ可視性（probe AUC）と選択性の回復実験

因果的不可視性の打開:
  系列構成:
    SRC (長さ 16) + SEP + PLAN (長さ 16) + SEP + OUT (長さ 16)
    - PLAN[j] は 'C' (Copy) または 'E' (Edit) を明示するトークン。
  
  タスク:
    アテンションによって PLAN[j] の情報が OUT[j] 予測時の隠れ状態 h_j に注入される。
"""

import os
import sys
import time
import math
import json
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

os.environ["CUDA_VISIBLE_DEVICES"] = ""

# 語彙定義
BASE_VOCAB = "()[]{}0123456789+-*/ abcdefgh"
PLAN_TOKENS = ["<COPY>", "<EDIT>"]
ALL_VOCAB = list(BASE_VOCAB) + PLAN_TOKENS
V = len(ALL_VOCAB)
C2I = {c: i for i, c in enumerate(ALL_VOCAB)}
SEP = C2I[" "]
TOK_PLAN_COPY = C2I["<COPY>"]
TOK_PLAN_EDIT = C2I["<EDIT>"]

# 高速・確実なサイズ設定
L_SRC = 16
L_PLAN = 16
L_OUT = 16
POS_SRC = 0
POS_PLAN = L_SRC + 1
POS_OUT = POS_PLAN + L_PLAN + 1
SEQ_LEN = POS_OUT + L_OUT

D_MODEL = 64
N_HEAD = 4
N_LAYERS = 2
E_NUM = 8
TOPK = 2
W_FF = 64
ID_IDX = 7 # 8番目を恒等エキスパート


def make_plan_batch(rng, n, max_k=3):
    base_v = len(BASE_VOCAB) - 2
    src = rng.integers(0, base_v, size=(n, L_SRC))
    out = src.copy()
    plan = np.full((n, L_PLAN), TOK_PLAN_COPY, dtype=np.int64)
    edit_mask = np.zeros((n, L_OUT), dtype=bool)
    
    for i in range(n):
        k = int(rng.integers(1, max_k + 1))
        edit_pos = rng.choice(L_OUT, size=k, replace=False)
        for p in edit_pos:
            alt = int(rng.integers(0, base_v - 1))
            if alt >= out[i, p]:
                alt += 1
            out[i, p] = alt
            plan[i, p] = TOK_PLAN_EDIT
            edit_mask[i, p] = True
            
    seq = np.empty((n, SEQ_LEN), dtype=np.int64)
    seq[:, POS_SRC : POS_SRC + L_SRC] = src
    seq[:, POS_SRC + L_SRC] = SEP
    seq[:, POS_PLAN : POS_PLAN + L_PLAN] = plan
    seq[:, POS_PLAN + L_PLAN] = SEP
    seq[:, POS_OUT : POS_OUT + L_OUT] = out
    
    return torch.from_numpy(seq), edit_mask


class PathMoELayer(nn.Module):
    def __init__(self, d_model=D_MODEL, n_head=N_HEAD, e_num=E_NUM, w_ff=W_FF, topk=TOPK, ident=True):
        super().__init__()
        self.d = d_model
        self.e_num = e_num
        self.topk = topk
        self.ident = ident
        
        self.attn_q = nn.Linear(d_model, d_model, bias=False)
        self.attn_k = nn.Linear(d_model, d_model, bias=False)
        self.attn_v = nn.Linear(d_model, d_model, bias=False)
        self.attn_out = nn.Linear(d_model, d_model, bias=False)
        self.n_head = n_head
        self.d_head = d_model // n_head
        
        self.router = nn.Linear(d_model, e_num, bias=False)
        self.ffn_up = nn.Parameter(torch.randn(e_num, d_model, w_ff) * 0.05)
        self.ffn_down = nn.Parameter(torch.randn(e_num, w_ff, d_model) * 0.05)
        
    def forward(self, x, mask=None):
        B, T, D = x.shape
        
        # Self-Attention
        q = self.attn_q(x).view(B, T, self.n_head, self.d_head).transpose(1, 2)
        k = self.attn_k(x).view(B, T, self.n_head, self.d_head).transpose(1, 2)
        v = self.attn_v(x).view(B, T, self.n_head, self.d_head).transpose(1, 2)
        
        scores = (q @ k.transpose(-2, -1)) / math.sqrt(self.d_head)
        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)
        attn_weights = F.softmax(scores, dim=-1)
        attn_ctx = (attn_weights @ v).transpose(1, 2).reshape(B, T, D)
        x = x + self.attn_out(attn_ctx)
        
        # Router
        h_router = x
        logits = self.router(h_router)
        topk_logits, topk_idx = torch.topk(logits, self.topk, dim=-1)
        topk_gates = F.softmax(topk_logits, dim=-1)
        
        # MoE Computation
        out_moe = torch.zeros_like(x)
        for k_i in range(self.topk):
            e_idx = topk_idx[:, :, k_i]
            gate = topk_gates[:, :, k_i].unsqueeze(-1)
            
            # Identity
            if self.ident:
                id_mask = (e_idx == ID_IDX).unsqueeze(-1)
                out_moe = out_moe + torch.where(id_mask, gate * x, torch.zeros_like(x))
                
            # FFNs
            for e in range(self.e_num):
                if self.ident and e == ID_IDX:
                    continue
                mask_e = (e_idx == e).unsqueeze(-1)
                if mask_e.any():
                    # [B, T, D] @ [D, W] -> [B, T, W] @ [W, D] -> [B, T, D]
                    ffn_e = F.relu(x @ self.ffn_up[e]) @ self.ffn_down[e]
                    out_moe = out_moe + torch.where(mask_e, gate * ffn_e, torch.zeros_like(x))
                    
        x = x + out_moe
        return x, h_router, topk_idx, topk_gates


class ModelWithPlan(nn.Module):
    def __init__(self, vocab_size=V, d_model=D_MODEL, n_layers=N_LAYERS):
        super().__init__()
        self.tok_emb = nn.Embedding(vocab_size, d_model)
        self.pos_emb = nn.Embedding(SEQ_LEN, d_model)
        self.layers = nn.ModuleList([PathMoELayer() for _ in range(n_layers)])
        self.head = nn.Linear(d_model, vocab_size, bias=False)
        
    def forward(self, seq):
        B, T = seq.shape
        pos = torch.arange(T, device=seq.device).unsqueeze(0)
        x = self.tok_emb(seq) + self.pos_emb(pos)
        causal_mask = torch.tril(torch.ones(T, T, device=seq.device)).unsqueeze(0).unsqueeze(0)
        
        all_h = []
        all_topk_idx = []
        all_topk_gates = []
        for layer in self.layers:
            x, h_r, idx, gates = layer(x, mask=causal_mask)
            all_h.append(h_r)
            all_topk_idx.append(idx)
            all_topk_gates.append(gates)
            
        logits = self.head(x)
        return logits, all_h, all_topk_idx, all_topk_gates


def evaluate_probe_auc(scores, labels):
    order = np.argsort(scores)
    ranks = np.empty(len(scores), dtype=np.float64)
    ranks[order] = np.arange(1, len(scores) + 1)
    n1 = labels.sum()
    n0 = len(labels) - n1
    if n1 == 0 or n0 == 0:
        return 0.5
    return float((ranks[labels == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def train_and_evaluate(with_plan=True, lam_cost=0.2, epochs=8, batch_size=64):
    mode_str = "E4b_WITH_PLAN" if with_plan else "E4_NO_PLAN"
    print(f"\n==========================================", flush=True)
    print(f"Training mode: {mode_str} (lam_cost={lam_cost})", flush=True)
    print(f"==========================================", flush=True)
    
    rng = np.random.default_rng(42)
    model = ModelWithPlan()
    optimizer = torch.optim.Adam(model.parameters(), lr=0.005)
    loss_fn = nn.CrossEntropyLoss()
    
    t0 = time.time()
    batches = 25
    for epoch in range(1, epochs + 1):
        model.train()
        total_loss = 0.0
        total_cost_loss = 0.0
        
        for _ in range(batches):
            seq, edit_mask = make_plan_batch(rng, batch_size)
            if not with_plan:
                seq[:, POS_PLAN : POS_PLAN + L_PLAN] = SEP
                
            optimizer.zero_grad()
            logits, all_h, all_topk_idx, all_topk_gates = model(seq)
            
            pred_logits = logits[:, POS_OUT - 1 : POS_OUT + L_OUT - 1]
            targets = seq[:, POS_OUT : POS_OUT + L_OUT]
            
            ce_loss = loss_fn(pred_logits.reshape(-1, V), targets.reshape(-1))
            
            cost_loss = 0.0
            for gates, idx in zip(all_topk_gates, all_topk_idx):
                out_gates = gates[:, POS_OUT - 1 : POS_OUT + L_OUT - 1]
                out_idx = idx[:, POS_OUT - 1 : POS_OUT + L_OUT - 1]
                is_ffn = (out_idx != ID_IDX).float()
                ffn_cost = (out_gates * is_ffn).sum(dim=-1).mean()
                cost_loss += ffn_cost
                
            loss = ce_loss + lam_cost * cost_loss
            loss.backward()
            optimizer.step()
            
            total_loss += ce_loss.item()
            total_cost_loss += cost_loss.item()
            
        print(f"Epoch {epoch:2d}/{epochs}: CE={total_loss/batches:.4f}, Cost={total_cost_loss/batches:.4f} ({time.time()-t0:.1f}s)", flush=True)
        
    # 評価
    model.eval()
    test_n = 1024
    test_seq, test_edit_mask = make_plan_batch(rng, test_n)
    if not with_plan:
        test_seq[:, POS_PLAN : POS_PLAN + L_PLAN] = SEP
        
    with torch.no_grad():
        test_logits, test_h, test_idx, test_gates = model(test_seq)
        
    # プローブ AUC
    probe_aucs = []
    y_true = test_edit_mask.reshape(-1).astype(np.int64)
    
    for l_idx, h in enumerate(test_h):
        out_h = h[:, POS_OUT - 1 : POS_OUT + L_OUT - 1].reshape(-1, D_MODEL).numpy()
        split = int(0.7 * len(y_true))
        X_tr, y_tr = out_h[:split], y_true[:split]
        X_te, y_te = out_h[split:], y_true[split:]
        
        w = torch.zeros(D_MODEL, requires_grad=True)
        b = torch.zeros(1, requires_grad=True)
        opt_p = torch.optim.Adam([w, b], lr=0.08)
        X_tr_t = torch.from_numpy((X_tr - X_tr.mean(0)) / (X_tr.std(0) + 1e-6))
        y_tr_t = torch.from_numpy(y_tr.astype(np.float32))
        
        for _ in range(150):
            p_loss = F.binary_cross_entropy_with_logits(X_tr_t @ w + b, y_tr_t)
            opt_p.zero_grad()
            p_loss.backward()
            opt_p.step()
            
        X_te_t = torch.from_numpy((X_te - X_tr.mean(0)) / (X_tr.std(0) + 1e-6))
        scores = (X_te_t @ w + b).detach().numpy()
        auc_val = evaluate_probe_auc(scores, y_te)
        probe_aucs.append(auc_val)
        
    # 選択性 (copy vs edit)
    last_topk_idx = test_idx[-1][:, POS_OUT - 1 : POS_OUT + L_OUT - 1].numpy()
    top1_idx = last_topk_idx[:, :, 0]
    
    id_chosen = (top1_idx == ID_IDX)
    id_rate_copy = float(id_chosen[~test_edit_mask].mean())
    id_rate_edit = float(id_chosen[test_edit_mask].mean())
    selectivity_delta = id_rate_copy - id_rate_edit
    
    all_gate_id_copy = []
    all_gate_id_edit = []
    for gates, idx in zip(test_gates, test_idx):
        g = gates[:, POS_OUT - 1 : POS_OUT + L_OUT - 1].numpy()
        i = idx[:, POS_OUT - 1 : POS_OUT + L_OUT - 1].numpy()
        is_id = (i == ID_IDX)
        id_gate = np.sum(g * is_id, axis=-1)
        all_gate_id_copy.append(float(id_gate[~test_edit_mask].mean()))
        all_gate_id_edit.append(float(id_gate[test_edit_mask].mean()))
        
    res = {
        "mode": mode_str,
        "with_plan": with_plan,
        "probe_auc_by_layer": probe_aucs,
        "mean_probe_auc": float(np.mean(probe_aucs)),
        "id_top1_rate_copy": id_rate_copy,
        "id_top1_rate_edit": id_rate_edit,
        "selectivity_delta": selectivity_delta,
        "gate_id_copy": float(np.mean(all_gate_id_copy)),
        "gate_id_edit": float(np.mean(all_gate_id_edit)),
        "gate_selectivity_delta": float(np.mean(all_gate_id_copy) - np.mean(all_gate_id_edit))
    }
    
    print(f"\n--- Results for {mode_str} ---", flush=True)
    print(f"  Probe AUC by layer: {[round(x, 4) for x in probe_aucs]} (Mean: {res['mean_probe_auc']:.4f})", flush=True)
    print(f"  ID Top-1 Rate: Copy={id_rate_copy*100:.2f}%, Edit={id_rate_edit*100:.2f}%", flush=True)
    print(f"  Selectivity Delta (Copy - Edit): {selectivity_delta*100:+.2f} pp", flush=True)
    print(f"  Gate Mass: Copy={res['gate_id_copy']:.4f}, Edit={res['gate_id_edit']:.4f} (Delta: {res['gate_selectivity_delta']:+.4f})", flush=True)
    
    return res


def main():
    print("Starting E4b (PLAN Signal Injection Verification)...", flush=True)
    t_start = time.time()
    
    # 1. NO_PLAN (E4の再現: 因果的不可視)
    res_no_plan = train_and_evaluate(with_plan=False, lam_cost=0.2, epochs=8)
    
    # 2. WITH_PLAN (E4b: PLAN注入)
    res_with_plan = train_and_evaluate(with_plan=True, lam_cost=0.2, epochs=8)
    
    comparison = {
        "no_plan": res_no_plan,
        "with_plan": res_with_plan,
        "elapsed_sec": time.time() - t_start
    }
    
    out_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "e4b_plan_injection_results.json")
    with open(out_file, "w", encoding="utf-8") as fp:
        json.dump(comparison, fp, indent=2)
        
    print(f"\nAll done in {time.time()-t_start:.1f}s. Saved to {out_file}", flush=True)

if __name__ == "__main__":
    main()
