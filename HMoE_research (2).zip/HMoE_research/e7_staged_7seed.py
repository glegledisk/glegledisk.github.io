# -*- coding: utf-8 -*-
"""e7_staged_7seed.py — warm_bias 感度 + sp_wb3_w10 の 13 seed 拡張

## 動慕（staged pressure レポート §9-1）
sp_wb3_w10（warmup 10 ep で ff 位置の identity logit に +3.0）が最良（obj 0.1238、E6 効果量 132%）。
残る 2 つの問い:

1. **warm_bias の感度**: 3.0 は 1 seed 予備実験で選んだ。5.0 はゲート飽和で失敗（idff 0.11）。
   2.0 / 4.0 を同条件で測り、最適値と飽和境界を同定する。
2. **sp_wb3_w10 の 13 seed 拡張**: 7 seed では bias10 との obj 差が n.s.（−0.038, t=−1.43, 4/7）。
   seed を増やして「最良アーム」の主張を確定する。**paired 検定には新 seed の baseline が必要**なので
   frozen_ffn・bias10 も seed 7〜12 で実行する（seed 0 は再現性チェックを兼ねる）。

## アーム（いずれも tokid + entropy β=0.05, 60 epoch, warmup 10 ep, 解凍後 λ=0.15）
| アーム | warm_bias | seeds |
|---|---|---|
| `sp_wb2_w10` | 2.0 | 0〜6 |
| `sp_wb3_w10` | 3.0 | 0〜12（0〜6 は既存） |
| `sp_wb4_w10` | 4.0 | 0〜6 |
| `frozen_ffn` | — | 0, 7〜12（baseline） |
| `bias10` | — | 0, 7〜12（baseline） |

## 判定
1. **warm_bias の用量反応**: CE / FFN / obj / idff / m50 が warm_bias にどう依存するか。単調か、最適はどこか。
2. **飽和境界**: 4.0 はまだ成功するか（5.0 は失敗）。
3. **13 seed の sp_wb3_w10**: frozen_ffn・bias10 との paired 検定（ obj / CE / FFN ）。tail リスク。
4. 再現性チェック（frozen_ffn seed 0 が E7 の値と一致するか）。

構成: 34 ラン（不足分のみ実行・逐次保存・再開可能）
"""
import os, json, time
import numpy as np
import pandas as pd
import torch
from e7_stabilize_task import run, make_lookup_table, ROLE_NAME

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)), d=64, epochs=60)
OUT = os.path.join(HERE, "e7_staged_7seed.csv")
DEV = "cuda" if torch.cuda.is_available() else "cpu"
tab = make_lookup_table(64)

SPEC_FREE = dict(route="free", router="linear", stab="entropy", extra="tokid")
SPEC_FFN = dict(route="ffn_only", router="linear", stab=None, extra=None)
S7, S13 = list(range(7)), list(range(13))
ARMS = {
    "sp_wb2_w10": dict(spec=SPEC_FREE, warmup=10, warm_bias=2.0, lam_post=0.15, seeds=S13),
    "sp_wb3_w10": dict(spec=SPEC_FREE, warmup=10, warm_bias=3.0, lam_post=0.15, seeds=S13),
    "sp_wb4_w10": dict(spec=SPEC_FREE, warmup=10, warm_bias=4.0, lam_post=0.15, seeds=S13),
    # baseline（新 seed 用。seed 0 は再現性チェック）
    "frozen_ffn": dict(spec=SPEC_FFN, warmup=0, warm_bias=0.0, lam_post=0.15, seeds=[0] + list(range(7, 13))),
    "bias10": dict(spec=SPEC_FREE, warmup=0, warm_bias=0.0, lam_post=0.15, id_bias=1.0, seeds=[0] + list(range(7, 13))),
}

rows = []
if os.path.exists(OUT):
    rows = pd.read_csv(OUT).to_dict("records")
have = {(r["variant"], int(r["seed"])) for r in rows}
print(f"device: {DEV}  既存 {len(have)} 件")

todo = [(v, s) for v, a in ARMS.items() for s in a["seeds"] if (v, s) not in have]
print(f"追加実行 {len(todo)} 件")

t0 = time.time()
for i, (v, s) in enumerate(todo, 1):
    a = ARMS[v]
    kw = dict(table=tab, device=DEV, spec=a["spec"], lam_cost=0.15, ent_beta=0.05,
              warmup=a["warmup"], warm_bias=a["warm_bias"], lam_post=a["lam_post"])
    if "id_bias" in a:
        kw["id_bias"] = a["id_bias"]
    r = run(v, s, **kw, **CFG)
    rows.append(r)
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"  [{i}/{len(todo)}] {v:12s} s{s:2d} | CE {r['ce_all']:.4f} | FFN {r['ffn_cost']:.3f} "
          f"| obj {r['ce_all']+0.15*r['ffn_cost']:.4f} "
          f"| acc {r['acc_all']:.4f} (ff {r['acc_ff']:.3f} / fr {r['acc_fr']:.3f} / rr {r['acc_rr']:.3f}) "
          f"| idff {r['id_rate_ff']:.3f} | m50 {r['fin_margin_p50_ff']:+.1f} | {time.time()-t0:.0f}s", flush=True)

df = pd.DataFrame(rows)
df["obj015"] = df["ce_all"] + 0.15 * df["ffn_cost"]
df = df.sort_values(["variant", "seed"]).reset_index(drop=True)
df.to_csv(OUT, index=False)


def get(a):
    return df[df.variant == a].set_index("seed")


# 外部参照（品質参照用。seed 0〜6 のみ）
ts = pd.read_csv(os.path.join(HERE, "e7_tokid_stab_7seed.csv"))
ts["obj015"] = ts["ce_all"] + 0.15 * ts["ffn_cost"]
w = pd.read_csv(os.path.join(HERE, "e7_warmup_7seed.csv"))
w["obj015"] = w["ce_all"] + 0.15 * w["ffn_cost"]
EXT = {"tokid_entropy": ts[ts.variant == "tokid_entropy"].set_index("seed"),
       "warm20": w[w.variant == "tokid_ent_warm20"].set_index("seed")}

print("\n=== warm_bias 感度 + 13 seed 拡張（60 epoch, E7 課題, λ=0.15） ===")
print(f"{'arm':14s} {'n':>3s} {'CE':>16s} {'max CE':>8s} {'FFN':>14s} {'obj(λ=.15)':>16s} "
      f"{'acc rr':>8s} {'id ff':>7s} {'id rr':>7s} {'m50 ff':>8s}")
for a in ["frozen_ffn", "bias10", "sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]:
    d = get(a)
    print(f"{a:14s} {len(d):3d} {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f} {d['ce_all'].max():8.4f} "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f} {d['obj015'].mean():.4f}±{d['obj015'].std():.4f} "
          f"{d['acc_rr'].mean():8.4f} {d['id_rate_ff'].mean():7.3f} {d['id_rate_rr'].mean():7.3f} "
          f"{d['fin_margin_p50_ff'].mean():+8.1f}")

print("\n=== 再現性チェック（seed 0 の frozen_ffn / bias10 が過去の値と一致するか） ===")
e7 = pd.read_csv(os.path.join(HERE, "e7_routing_7seed.csv"))
dz = pd.read_csv(os.path.join(HERE, "e7_deadzone_7seed.csv"))
old_ffn = e7[(e7.arm == "frozen_ffn") & (e7.seed == 0)].iloc[0]
old_b10 = dz[(dz.variant == "bias10") & (dz.seed == 0)].iloc[0]
for name, old in [("frozen_ffn", old_ffn), ("bias10", old_b10)]:
    new = get(name).loc[0]
    ok = abs(new["ce_all"] - old["ce_all"]) < 1e-9 and abs(new["ffn_cost"] - old["ffn_cost"]) < 1e-9
    print(f" {name:10s} CE {new['ce_all']:.4f}（過去 {old['ce_all']:.4f}）  FFN {new['ffn_cost']:.3f}"
          f"（過去 {old['ffn_cost']:.3f}）  → {'一致' if ok else '不一致'}")

print("\n=== warm_bias の用量反応（seed 0〜6, paired vs frozen_ffn / bias10） ===")


def paired(d_new, d_base, key):
    d = (d_new[key] - d_base[key]).dropna()
    m, sd = d.mean(), d.std(ddof=1)
    t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
    rng = np.random.default_rng(0)
    boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(20000)])
    lo, hi = np.percentile(boot, [2.5, 97.5])
    return m, lo, hi, t, int((d < 0).sum()), len(d)


for v in ["sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]:
    dv = get(v)
    for base_name in ["frozen_ffn", "bias10"]:
        db = get(base_name)
        for k in ("obj015", "ce_all", "ffn_cost"):
            m, lo, hi, t, w_, n = paired(dv, db, k)
            print(f" {v:12s} vs {base_name:10s} {k:9s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {w_}/{n}")

print("\n=== 13 seed: sp_wb3_w10 の paired 検定 ===")
res = {}
d13 = get("sp_wb3_w10")
for base_name in ["frozen_ffn", "bias10"]:
    db = get(base_name)
    for k in ("obj015", "ce_all", "ffn_cost"):
        m, lo, hi, t, w_, n = paired(d13, db, k)
        res[f"wb3_vs_{base_name}_{k}"] = {"mean": float(m), "ci": [float(lo), float(hi)],
                                          "t": float(t), "wins": w_, "n": n}
        print(f" sp_wb3_w10(n={len(d13)}) vs {base_name:10s}(n={len(db)}) {k:9s} "
              f"{m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {w_}/{n}")

print("\n=== E6 効果量からの回復率（obj, frozen_ffn 比） ===")
e6 = -0.1509
for a in ["bias10", "sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]:
    d = get(a)
    o = d["obj015"].mean() - get("frozen_ffn")["obj015"].mean()
    print(f" {a:12s} obj 差 {o:+.4f}（E6 効果の {100 * o / e6:.0f}%）  CE 差 "
          f"{d['ce_all'].mean() - get('frozen_ffn')['ce_all'].mean():+.4f}  "
          f"FFN 差 {d['ffn_cost'].mean() - get('frozen_ffn')['ffn_cost'].mean():+.4f}")

print("\n=== tail リスク（CE > 0.15 の seed 数 / max CE） ===")
for a in ["frozen_ffn", "bias10", "sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]:
    d = get(a)
    print(f" {a:12s} n={len(d)}  CE>0.15: {int((d['ce_all'] > 0.15).sum())}/{len(d)}  max CE {d['ce_all'].max():.4f}")

print("\n=== seed 別（CE / FFN / id_ff） ===")
for a in ["sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]:
    d = get(a).sort_index()
    print(f" {a:12s} CE  " + " ".join(f"{x:.3f}" for x in d["ce_all"]))
    print(f" {'':12s} FFN " + " ".join(f"{x:.3f}" for x in d["ffn_cost"]))
    print(f" {'':12s} idF " + " ".join(f"{x:.3f}" for x in d["id_rate_ff"]))

print("\n=== λ 感度（合成目的） ===")
print(f"{'λ':>5s} {'frozen_ffn':>12s} {'bias10':>10s} " + "".join(f"{v:>12s}" for v in ["sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]))
lam_tab = {}
for lam in [0.03, 0.05, 0.08, 0.15, 0.30]:
    vals = {a: get(a)["ce_all"].mean() + lam * get(a)["ffn_cost"].mean()
            for a in ["frozen_ffn", "bias10", "sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]}
    lam_tab[str(lam)] = {k: float(x) for k, x in vals.items()}
    print(f"{lam:5.2f} {vals['frozen_ffn']:12.4f} {vals['bias10']:10.4f} "
          + "".join(f"{vals[v]:12.4f}" for v in ["sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]))

json.dump({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in CFG.items()},
           "device": DEV,
           "arms": {k: {kk: vv for kk, vv in v.items() if kk != "spec"} for k, v in ARMS.items()},
           "summary": {a: {k: float(get(a)[k].mean()) for k in
                           ["ce_all", "ffn_cost", "obj015", "acc_all", "acc_ff", "acc_fr", "acc_rr",
                            "ce_ff", "ce_fr", "ce_rr", "id_rate_ff", "id_rate_fr", "id_rate_rr"]}
                       for a in ["frozen_ffn", "bias10", "sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]},
           "paired_13seed": res, "lambda_sensitivity": lam_tab, "raw": rows},
          open(os.path.join(HERE, "e7_wb_sens_7seed.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e7_staged_7seed.csv / e7_wb_sens_7seed.json")
