# -*- coding: utf-8 -*-
"""e4d_ceiling.py — (j,r) 信号だけで到達できる理論上限の算出
ルータが P(edit | j, r) を完全に知っているとき、
「恒等パスに流す割合」と「編集を誤って流す割合」のトレードオフ曲線を出す。
"""
import os, json
import numpy as np
from math import comb

HERE = os.path.dirname(os.path.abspath(__file__))
L = 16

# 生成過程: k~U{1,2,3}, 位置を一様抽出（重複なし）
def post(j, r):
    num = den = 0.0
    for k in (1, 2, 3):
        if r > k or k - r > L - j:
            continue
        lik = comb(j, r) * comb(L - j, k - r) / comb(L, k)
        den += lik
        num += lik * (k - r) / (L - j)
    return num / den if den else 0.0

# (j, r) の同時分布（位置は一様なので 1/L を掛ける）
P = {}
for j in range(L):
    for r in range(0, j + 1):
        p = 0.0
        for k in (1, 2, 3):
            if r <= k and k - r <= L - j:
                p += (1/3) * comb(j, r) * comb(L - j, k - r) / comb(L, k)
        P[(j, r)] = p / L

tot = sum(P.values())
assert abs(tot - 1) < 1e-9, tot

print("=== P(edit|j,r) の分布（重み付き） ===")
bins = {}
for (j, r), w in P.items():
    q = post(j, r)
    bins.setdefault(round(q, 3), 0.0)
    bins[round(q, 3)] += w
for q in sorted(bins):
    print(f"  P={q:.3f}  位置割合 {100*bins[q]:5.2f}%")

print("\n=== 恒等パスに流す閾値と誤りのトレードオフ ===")
print(" 閾値t  | 恒等に流す割合 | そのうち編集の割合(=誤り率) | 削減できるFFN割合")
rows = []
for t in [0.13, 0.15, 0.17, 0.19, 0.21, 0.25, 0.30, 0.50, 1.01]:
    ident = sum(w for (j, r), w in P.items() if post(j, r) < t)
    wrong = sum(w * post(j, r) for (j, r), w in P.items() if post(j, r) < t)
    err = wrong / ident if ident > 0 else 0.0
    rows.append({"t": t, "ident_frac": ident, "err_rate": err})
    print(f"  {t:5.2f} | {100*ident:6.2f}%       | {100*err:6.2f}%                  | {100*ident:6.2f}%")

print("\n 参考: 何もせず全部恒等 → 編集 12.5% を全部落とす")
print(" 参考: 何もせず全部FFN  → 削減 0%")

# ベイズ AUC（(j,r) のスコアで edit を並べたとき）
sc, lb = [], []
for (j, r), w in P.items():
    n = int(round(w * 1e7))
    sc += [post(j, r)] * n
    lb += [0] * n
# 実際のラベル分布で重み付けするため、位置ごとの編集率を掛ける
sc2, lb2 = [], []
for (j, r), w in P.items():
    p_ed = post(j, r)
    n_ed = int(round(w * p_ed * 1e7))
    n_cp = int(round(w * (1 - p_ed) * 1e7))
    sc2 += [p_ed] * (n_ed + n_cp)
    lb2 += [1] * n_ed + [0] * n_cp
sc2 = np.array(sc2); lb2 = np.array(lb2)
order = np.argsort(sc2, kind="mergesort")
ranks = np.empty(len(sc2)); ranks[order] = np.arange(1, len(sc2) + 1)
u, inv, c = np.unique(sc2, return_inverse=True, return_counts=True)
ranks = (np.bincount(inv, weights=ranks) / c)[inv]
n1, n0 = lb2.sum(), len(lb2) - lb2.sum()
auc = (ranks[lb2 == 1].sum() - n1*(n1+1)/2) / (n1*n0)
print(f"\n=== ベイズ最適 AUC（(j,r) のみ） = {auc:.4f} ===")

json.dump({"bayes_auc": float(auc), "tradeoff": rows,
           "posterior_table": {f"{j},{r}": post(j, r) for j in range(L) for r in range(j+1)}},
          open(os.path.join(HERE, "e4d_ceiling.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("saved e4d_ceiling.json")
