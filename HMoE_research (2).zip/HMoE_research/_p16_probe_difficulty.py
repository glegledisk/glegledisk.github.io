# -*- coding: utf-8 -*-
"""P16 probe: 難度ラダーの候補を選ぶ（使い捨て・正解率だけ見る）

P15 の clean プールは 37/40 正解で飽和している。較正が「天井の産物」でないかを
見るには、正解率が中間（0.5〜0.8）になる課題が要る。候補を 4 つ試して選ぶ。

出力: _p16_probe_out_utf8.txt / _p16_probe.json
"""
import argparse
import json
import os
import random
import re

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "qwen3-0.6b")
SYS = "You are a careful arithmetic assistant. Solve the problem and give the final answer."
VAL_RE = re.compile(r"-?\d+")
OUT = []


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def make(level, n, rnd):
    out = []
    for _ in range(n):
        if level == "add5":
            a, b = rnd.randint(10001, 99999), rnd.randint(10001, 99999)
            out.append({"q": "Compute %d + %d." % (a, b), "gold": str(a + b)})
        elif level == "mul2":
            a, b = rnd.randint(11, 99), rnd.randint(11, 99)
            out.append({"q": "Compute %d * %d." % (a, b), "gold": str(a * b)})
        elif level == "add3t":
            a, b, c = (rnd.randint(10001, 99999) for _ in range(3))
            out.append({"q": "Compute %d + %d + %d." % (a, b, c), "gold": str(a + b + c)})
        elif level == "sub5":
            a, b = rnd.randint(50001, 99999), rnd.randint(10001, 49999)
            out.append({"q": "Compute %d - %d." % (a, b), "gold": str(a - b)})
        else:
            raise ValueError(level)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_prob", type=int, default=12)
    ap.add_argument("--n_samp", type=int, default=4)
    ap.add_argument("--seed", type=int, default=41)
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer
    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, torch_dtype=torch.bfloat16, device_map="cuda",
        attn_implementation="sdpa").eval()

    rnd = random.Random(args.seed)
    res = {}
    for level in ["add5", "mul2", "add3t", "sub5"]:
        probs = make(level, args.n_prob, rnd)
        prompts = [tok.apply_chat_template(
            [{"role": "system", "content": SYS}, {"role": "user", "content": p["q"]}],
            tokenize=False, add_generation_prompt=True, enable_thinking=False) for p in probs]
        torch.manual_seed(args.seed)
        accs, ntok, trunc = [], [], 0
        for i, p in enumerate(probs):
            enc = tok([prompts[i]] * args.n_samp, return_tensors="pt",
                      padding=True, add_special_tokens=False).to(model.device)
            with torch.no_grad():
                o = model.generate(**enc, max_new_tokens=96, do_sample=True,
                                   temperature=0.9, top_p=0.95,
                                   pad_token_id=tok.pad_token_id)
            gen = o[:, enc["input_ids"].shape[1]:]
            for j in range(args.n_samp):
                ids = [t for t in gen[j].tolist() if t != tok.pad_token_id]
                txt = tok.decode(ids, skip_special_tokens=True)
                nums = VAL_RE.findall(txt.replace(",", ""))
                pred = nums[-1] if nums else None
                accs.append(float(pred == p["gold"]))
                ntok.append(len(ids))
                trunc += int(len(ids) >= 96)
        res[level] = {"acc": float(np.mean(accs)), "n": len(accs),
                      "trunc_rate": trunc / float(len(accs)),
                      "mean_ntok": float(np.mean(ntok))}
        log("%-6s acc=%.3f  trunc=%.3f  ntok=%.1f  (n=%d)"
            % (level, res[level]["acc"], res[level]["trunc_rate"],
               res[level]["mean_ntok"], res[level]["n"]))

    with open(os.path.join(HERE, "_p16_probe.json"), "w", encoding="utf-8") as fp:
        json.dump(res, fp, ensure_ascii=False, indent=2)
    with open(os.path.join(HERE, "_p16_probe_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    os._exit(0)


if __name__ == "__main__":
    main()
