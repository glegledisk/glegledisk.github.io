"""s6_regression.py — §6 の回帰（HMoE の重みが無い前提でできる最大限）

やること:
  A. 論文 Appendix I の expert→トークン表（5 群 × 10 トークン）を、
     コーパス上の「語内位置」で特徴づけ、expert サイズとの Spearman を見る。
     → "_" が語頭マーカーか継続マーカーかも、これで決着する。
  B. Qwen3-0.6B を CPU で回し、トークン型ごとに
     (H1) 文脈エントロピー / (H2) 語末率・語頭フラグ / (H3) 頻度・長さ / TV
     を作って相関行列を見る。
     → H1 と H2 がそもそも分離可能かを判定する（回帰の識別可能性）。

GPU 不使用。
"""

import bisect
import glob
import json
import os
import re
import sys
import time

os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(HERE, "models", "qwen3-0.6b")

# 論文 Appendix I, Table 3（FFN 隠れ次元, 代表トークン）
TABLE = [
    (2304, ["the", "such", "your", "these", "most", "you", "both", "no", "they", "each"]),
    (3328, ["tables", "valley", "sun", "temper", "places", "day", "war", "water", "through", "clean"]),
    (3840, ["known", "least", "lowest", "immediately", "bare", "heavy", "higher", "several", "independent"]),
    (5376, ["_ly", "_zen", "_icker", "_last", "_per", "_var", "_orous", "_next", "_end", "_flat"]),
    (5888, ["_decom", "_iz", "_ro", "_inf", "_scra", "_coord", "_er", "problem", "_och", "_foss"]),
]


def rank(x):
    x = np.asarray(x, dtype=float)
    order = np.argsort(x)
    r = np.empty(len(x))
    r[order] = np.arange(len(x), dtype=float)
    # 同順位は平均
    vals, inv, cnt = np.unique(x, return_inverse=True, return_counts=True)
    if (cnt > 1).any():
        for i, v in enumerate(vals):
            if cnt[i] > 1:
                m = x == v
                r[m] = r[m].mean()
    return r


def spearman(a, b):
    ra, rb = rank(a), rank(b)
    ra = ra - ra.mean()
    rb = rb - rb.mean()
    d = np.sqrt((ra ** 2).sum() * (rb ** 2).sum())
    return float((ra * rb).sum() / d) if d > 0 else 0.0


# ---------------------------------------------------------------- A. 位置特徴

def positional_stats(text, s):
    """文字列 s の出現を、語頭 / 語中 / 語末 / 単独 に分類する。"""
    cnt = {"init": 0, "med": 0, "final": 0, "alone": 0}
    i = 0
    n = len(text)
    L = len(s)
    while True:
        i = text.find(s, i)
        if i < 0:
            break
        prev_c = text[i - 1] if i > 0 else " "
        next_c = text[i + L] if i + L < n else " "
        p_alpha = prev_c.isalpha()
        n_alpha = next_c.isalpha()
        if not p_alpha and n_alpha:
            cnt["init"] += 1
        elif p_alpha and n_alpha:
            cnt["med"] += 1
        elif p_alpha and not n_alpha:
            cnt["final"] += 1
        else:
            cnt["alone"] += 1
        i += 1
    return cnt


def part_a(text):
    print("\n" + "=" * 78)
    print("A. 論文 Table 3 のトークンを、コーパス上の語内位置で特徴づける")
    print("=" * 78)
    rows = []
    for dim, toks in TABLE:
        for t in toks:
            s = t.lstrip("_").lower()
            c = positional_stats(text, s)
            tot = sum(c.values())
            if tot == 0:
                continue
            rows.append({
                "tok": t, "dim": dim, "s": s, "n": tot,
                "init": c["init"] / tot, "med": c["med"] / tot,
                "final": c["final"] / tot, "alone": c["alone"] / tot,
                "len": len(s), "logf": np.log10(tot + 1),
            })
    print(f"{'token':10s} {'dim':>5s} {'n':>6s} {'語頭':>6s} {'語中':>6s} {'語末':>6s} {'単独':>6s} {'len':>4s}")
    for r in rows:
        print(f"{r['tok']:10s} {r['dim']:5d} {r['n']:6d} {r['init']:6.2f} {r['med']:6.2f} "
              f"{r['final']:6.2f} {r['alone']:6.2f} {r['len']:4d}")

    dims = np.array([r["dim"] for r in rows])
    print(f"\nn = {len(rows)} tokens / 5 expert groups")
    print(f"{'feature':12s} {'Spearman(dim)':>14s}")
    for f in ["init", "med", "final", "alone", "len", "logf"]:
        v = np.array([r[f] for r in rows])
        print(f"{f:12s} {spearman(dims, v):+14.3f}")

    # 断片（完全な語でない）かどうか = 単独率が低い
    frag = 1 - np.array([r["alone"] for r in rows])
    print(f"{'fragment':12s} {spearman(dims, frag):+14.3f}")
    return rows


# ---------------------------------------------------------------- B. 特徴の分離可能性

def bytes_to_unicode():
    bs = (list(range(ord("!"), ord("~") + 1))
          + list(range(ord("¡"), ord("¬") + 1))
          + list(range(ord("®"), ord("ÿ") + 1)))
    cs = bs[:]
    n = 0
    for b in range(256):
        if b not in bs:
            bs.append(b)
            cs.append(256 + n)
            n += 1
    return {chr(c): b for b, c in zip(bs, cs)}


UNI2BYTE = bytes_to_unicode()


def token_bytes(s):
    out = bytearray()
    for ch in s:
        b = UNI2BYTE.get(ch)
        if b is None:
            return None
        out.append(b)
    return bytes(out)


class Lattice:
    def __init__(self, tj):
        from tokenizers import Tokenizer
        self.tk = Tokenizer.from_file(tj)
        pairs = []
        for s, i in self.tk.get_vocab().items():
            b = token_bytes(s)
            if b:
                pairs.append((b, i))
        pairs.sort()
        self.keys = [p[0] for p in pairs]
        self.ids = np.array([p[1] for p in pairs], dtype=np.int64)
        self.pos = {b: k for k, (b, _) in enumerate(pairs)}
        self.maxlen = max(len(b) for b in self.keys)
        self.id2bytes = {i: b for b, i in pairs}
        self.V = self.tk.get_vocab_size()
        self._r = {}

    def rng(self, p):
        r = self._r.get(p)
        if r is None:
            r = (bisect.bisect_left(self.keys, p),
                 bisect.bisect_left(self.keys, p + b"\xff" * (self.maxlen + 1)))
            self._r[p] = r
        return r


def part_b(text, ntok=6000):
    print("\n" + "=" * 78)
    print("B. H1/H2/H3 の特徴は分離可能か（Qwen3-0.6B, CPU）")
    print("=" * 78)
    import torch
    from transformers import AutoModelForCausalLM

    lat = Lattice(os.path.join(MODEL_DIR, "tokenizer.json"))
    ids = lat.tk.encode(text, add_special_tokens=False).ids[:ntok]
    torch.set_num_threads(max(1, (os.cpu_count() or 4) - 1))
    t0 = time.time()
    try:
        model = AutoModelForCausalLM.from_pretrained(MODEL_DIR, dtype=torch.float32)
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(MODEL_DIR, torch_dtype=torch.float32)
    model.eval()
    print(f"[model] {time.time()-t0:.1f}s")

    L = 512
    chunks = []
    t0 = time.time()
    with torch.no_grad():
        for s in range(0, len(ids) - 1, L):
            c = ids[s:s + L]
            if len(c) < 2:
                break
            chunks.append(model(torch.tensor([c], dtype=torch.long)).logits[0].float().numpy())
    print(f"[fwd] {time.time()-t0:.1f}s  tokens={len(ids)}")

    # トークン型ごとの集計
    ent_sum, ent_n = {}, {}
    tv_sum, tv_n = {}, {}
    fin_sum, fin_n = {}, {}
    pos = 0
    for lg in chunks:
        for t in range(lg.shape[0] - 1):
            cur = pos + t
            if cur + 1 >= len(ids):
                break
            w = ids[cur + 1]
            z = lg[t].astype(np.float64)
            z -= z.max()
            p = np.exp(z)
            p /= p.sum()
            ent = float(-(p[p > 0] * np.log(p[p > 0])).sum())
            ent_sum[w] = ent_sum.get(w, 0.0) + ent
            ent_n[w] = ent_n.get(w, 0) + 1
            # 語末率: 次トークンが空白始まりでない割合
            nxt = ids[cur + 2] if cur + 2 < len(ids) else None
            nb = lat.id2bytes.get(nxt, b"") if nxt is not None else b""
            is_fin = 0.0 if (nb.startswith(b" ") or nb == b"") else 1.0
            fin_sum[w] = fin_sum.get(w, 0.0) + is_fin
            fin_n[w] = fin_n.get(w, 0) + 1
            # TV（境界曖昧性）
            b = lat.id2bytes.get(w)
            if b and len(b) > 1:
                ps = p[lat.ids]
                cum = np.concatenate(([0.0], np.cumsum(ps)))
                for j in range(1, len(b)):
                    lo, hi = lat.rng(b[:j])
                    Z = cum[hi] - cum[lo]
                    k = lat.pos.get(b[:j])
                    T = ps[k] if k is not None else 0.0
                    tv_sum[w] = tv_sum.get(w, 0.0) + (T / Z if Z > 0 else 0.0)
                    tv_n[w] = tv_n.get(w, 0) + 1
        pos += lg.shape[0]

    freq = np.bincount(ids, minlength=lat.V + 1)
    rows = []
    for w in ent_n:
        if ent_n[w] < 5:
            continue
        b = lat.id2bytes.get(w)
        if not b or len(b) < 2:
            continue
        rows.append({
            "id": w, "n": ent_n[w],
            "H1_ent": ent_sum[w] / ent_n[w],
            "H2_final": fin_sum[w] / max(1, fin_n[w]),
            "H2_init": 1.0 if b.startswith(b" ") else 0.0,
            "H3_logf": float(np.log10(freq[w] + 1)),
            "len": len(b),
            "TV": tv_sum[w] / tv_n[w] if tv_n.get(w) else 0.0,
        })
    print(f"[types] {len(rows)} tokens with n>=5 occurrences")

    feats = ["H1_ent", "H2_final", "H2_init", "H3_logf", "len", "TV"]
    M = np.array([[r[f] for f in feats] for r in rows])
    print("\nSpearman 相関行列")
    print("        " + "".join(f"{f:>10s}" for f in feats))
    for i, fi in enumerate(feats):
        line = f"{fi:8s}"
        for j, fj in enumerate(feats):
            line += f"{spearman(M[:, i], M[:, j]):+10.2f}"
        print(line)

    print("\n群別平均（語頭フラグ別）")
    for v in (0.0, 1.0):
        m = M[:, 2] == v
        if m.sum():
            print(f"  init={int(v)}: n={int(m.sum()):5d}  H={M[m,0].mean():.2f}  "
                  f"final_rate={M[m,1].mean():.2f}  TV={M[m,5].mean():.4f}  len={M[m,4].mean():.1f}")
    return rows


def main():
    files = glob.glob(os.path.join(HERE, "english_version", "**", "*.md"), recursive=True)
    text = "\n\n".join(open(f, encoding="utf-8", errors="ignore").read() for f in sorted(files))
    print(f"[corpus] {len(text):,} chars / {len(files)} files")
    part_a(text)
    part_b(text, ntok=6000)
    return 0


if __name__ == "__main__":
    sys.exit(main())
