import numpy as np
d = np.load("p6a_decision_curve.npz", allow_pickle=True)
for q, pk, yk in (("Q1","ptop1","top1"), ("Q2","mass5","in5")):
    p8 = d["k8_"+pk].astype(float); p6 = d["k6_"+pk].astype(float)
    y8 = d["k8_"+yk].astype(float); y6 = d["k6_"+yk].astype(float)
    for tau in (0.8, 0.9):
        inc = (p8 < tau) & (p6 >= tau)      # 新たに閾値を越えた
        out = (p8 >= tau) & (p6 < tau)      # 閾値を割った
        print("%s tau=%.1f: 新規参入 n=%3d 誤り率=%.3f | 脱落 n=%3d 誤り率(k=8)=%.3f | 既存(k=8 で commit) 誤り率 %.4f->%.4f"
              % (q, tau, inc.sum(), (1-y6[inc]).mean() if inc.sum() else float('nan'),
                 out.sum(), (1-y8[out]).mean() if out.sum() else float('nan'),
                 (1-y8[p8>=tau]).mean(), (1-y6[p8>=tau]).mean()))