#!/usr/bin/env python3
"""P24: 層を 4 分割してコストプロファイルを測り、条件式 `c_b/c_f > 1+ρ` を満たす層群があるか。

背景: P3b は層を前半 8 / 後半 8 の 2 分割で「非対称性 1.66 < 1+ρ=3.44 → 均一が最良」とした。
P7/P7c はさらに「α は幅の代理にならない」「半幅は丸ごと落とすコストの 66%」を示した。
しかし**どれも 2 分割**で、ρ も c も層で違うはずのものを平均している。4 分割（4 層ずつ）で
測り直し、**条件式を満たす層群が存在するか**を直接判定する。

設計（P7c の実幅ハーネスをそのまま使う）
  群 G0..G3 = 層 0-3 / 4-7 / 8-11 / 12-15（各 4 層）
  各群について 3 水準:
    h : 各層の rank-8 を**実半幅**（前半 512 ニューロン）で計算   = 0.5 スロット
    s : 各層の rank-8 を落とす                                   = 1 スロット
    t : rank-8 と rank-7 を落とす                                = 2 スロット
  条件 = base + 4 群 × 3 水準 = 13。データは凍結コーパス（en/ja 24 窓 × 256 = 12,240 トークン）。

判定
  c_g(1) = C_g(1)                 （1 本目の限界コスト）
  c_g(2) = C_g(2) − C_g(1)        （2 本目の限界コスト）
  ρ_g    = c_g(2) / c_g(1)        （その群の凸性比）
  A_ji   = c_j(1) / c_i(1)        （群 j と i の非対称性）
  **1 本を j から i へ移す（i に 2 本、j に 0 本）と得か**: c_i(2) < c_j(1) ⟺ A_ji > ρ_g(i)
  P3b 形式（c_b/c_f > 1+ρ）でも併記する。

予測（事前登録）
  P1: c_g(1) は層とともに単調増加する（P7 の「後半が高い」の 4 分割版）
  P2: ρ_g は 2〜4 の範囲（P3b の 2.44、P7 の 3.18/3.27 と同帯）
  P3: A_ji は 1.5〜2.5 で、**どの組でも A < 1+ρ**（＝条件式を満たす層群は無い）
  Kill: どこかの組で A_ji > 1+ρ_i が出たら「層方向で効かない」は 4 分割で崩れる

出力: p24_layer_cost.npz / p24_layer_cost.json / p24_layer_cost_out_utf8.txt
"""
import argparse
import json
import os
import sys
import time
import types

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from p7c_width import make_forward, load_frozen  # noqa: E402

GROUPS = {"G0": list(range(0, 4)), "G1": list(range(4, 8)),
          "G2": list(range(8, 12)), "G3": list(range(12, 16))}
LEVELS = {"h": {1: "half"}, "s": {1: "skip"}, "t": {1: "skip", 2: "skip"}}


def build_conds():
    conds = {"base": None}
    for gname, layers in GROUPS.items():
        for lv, spec in LEVELS.items():
            conds[f"{gname}{lv}"] = {L: dict(spec) for L in layers}
    return conds


def log(msg):
    print(msg, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()

    conds = build_conds()
    names = list(conds)
    n_win = 1 if args.smoke else args.windows

    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[1/4] load model")
    t0 = time.time()
    AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      %.0f s" % (time.time() - t0))

    n_layers = model.config.num_hidden_layers
    d_ff = model.config.intermediate_size
    gates = [l.mlp.gate for l in model.model.layers]
    experts = [l.mlp.experts for l in model.model.layers]
    gate_fwd = [g.forward for g in gates]
    exp_fwd = [e.forward for e in experts]
    exp_old = [getattr(e, "_old_forward", None) for e in experts]
    log("      layers=%d d_ff=%d  _old_forward=%d/%d"
        % (n_layers, d_ff, sum(1 for x in exp_old if x is not None), n_layers))

    first = torch.arange(d_ff // 2)

    log("[2/4] corpus")
    seqs = load_frozen(n_win, args.len)
    lang = np.array([lg for lg, _ in seqs])
    log("      %d windows, %d tokens" % (len(seqs), len(seqs) * args.len))

    def restore():
        for i, e in enumerate(experts):
            if exp_old[i] is not None:
                e._old_forward = exp_old[i]
            else:
                e.forward = exp_fwd[i]
            gates[i].forward = gate_fwd[i]

    log("[3/4] forward")
    res = {}
    for cname in names:
        restore()
        spec = conds[cname]
        if spec is not None:
            for i, e in enumerate(experts):
                fn = make_forward(spec.get(i, {}), first)
                if hasattr(e, "_old_forward"):
                    e._old_forward = types.MethodType(fn, e)
                else:
                    e.forward = types.MethodType(fn, e)

        nll_c, acc_c = [], []
        t1 = time.time()
        with torch.no_grad():
            for lg, ids in seqs:
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                logit = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(logit, tgt, reduction="none")
                true_l = logit.gather(1, tgt.unsqueeze(-1))
                acc_c.append(((logit > true_l).sum(-1) == 0).float().cpu().numpy())
                nll_c.append(nll.cpu().numpy())
                del out, logit
        res[cname] = {"nll": np.concatenate(nll_c), "acc1": np.concatenate(acc_c)}
        log("      %-6s CE %.5f  top1 %.4f  (%.0f s)"
            % (cname, res[cname]["nll"].mean(), res[cname]["acc1"].mean(),
               time.time() - t1))

    restore()

    log("[4/4] summary")
    base = res["base"]["nll"]
    out = {"n_tokens": int(base.size), "n_windows": len(seqs), "results": {}}
    for c in names:
        d = (res[c]["nll"] - base).astype(np.float64)
        out["results"][c] = {"ce": float(res[c]["nll"].mean()),
                             "dce": float(d.mean()),
                             "top1": float(res[c]["acc1"].mean())}
    np.savez_compressed(os.path.join(HERE, "p24_layer_cost.npz"),
                        **{"nll_%s" % c: res[c]["nll"] for c in names},
                        **{"acc1_%s" % c: res[c]["acc1"] for c in names}, lang=lang)
    with open(os.path.join(HERE, "p24_layer_cost.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)

    log("")
    log("%-6s %10s %11s %8s" % ("cond", "CE", "dCE", "top1"))
    for c in names:
        r = out["results"][c]
        log("%-6s %10.5f %+11.5f %8.4f" % (c, r["ce"], r["dce"], r["top1"]))
    log("saved: p24_layer_cost.npz / .json")
    os._exit(0)


if __name__ == "__main__":
    main()
