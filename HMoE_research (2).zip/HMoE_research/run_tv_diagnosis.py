"""run_tv_diagnosis.py — Marginalize-It の TV 距離 ゼロ学習診断

SmolLM-135M (49k) と Qwen3-0.6B (151k) の両方について、
同一の日英コーパスを用いて、実教師モデルロジット p_T から
TV = T/Z (全変動距離) を計算し、語彙規模 × 言語での影響を確定する。
"""

import os
import sys
import time
import math
import glob
import json
import torch
import numpy as np
from transformers import AutoTokenizer, AutoModelForCausalLM

os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["TOKENIZERS_PARALLELISM"] = "false"

HERE = os.path.dirname(os.path.abspath(__file__))

def bytes_to_unicode():
    bs = (list(range(ord("!"), ord("~") + 1))
          + list(range(ord("¡"), ord("¬") + 1))
          + list(range(ord("®"), ord("ÿ") + 1)))
    cs = bs[:]
    n = 0
    for b in range(256):
        if b not in bs:
            bs.append(b)
            cs.append(256 + n)
            n += 1
    return {chr(c): b for b, c in zip(bs, cs)}

UNI2BYTE = bytes_to_unicode()

def token_bytes(s):
    out = bytearray()
    for ch in s:
        b = UNI2BYTE.get(ch)
        if b is None:
            # direct utf-8 fallback
            try:
                return s.encode("utf-8")
            except Exception:
                return None
        out.append(b)
    return bytes(out)

class VocabularyLattice:
    def __init__(self, tokenizer):
        import bisect
        self.tokenizer = tokenizer
        vocab = tokenizer.get_vocab()
        pairs = []
        for s, idx in vocab.items():
            b = token_bytes(s)
            if b:
                pairs.append((b, idx))
        pairs.sort()
        self.keys = [p[0] for p in pairs]
        self.ids = np.array([p[1] for p in pairs], dtype=np.int64)
        self.maxlen = max(len(b) for b in self.keys) if self.keys else 0
        self.id2bytes = {idx: b for b, idx in pairs}
        self.V = len(vocab)
        self._cache = {}

    def get_subtree_indices(self, prefix):
        import bisect
        res = self._cache.get(prefix)
        if res is None:
            lo = bisect.bisect_left(self.keys, prefix)
            hi = bisect.bisect_left(self.keys, prefix + b"\xff" * (self.maxlen + 1))
            exact_idx = None
            if lo < len(self.keys) and self.keys[lo] == prefix:
                exact_idx = self.ids[lo]
            matched_ids = self.ids[lo:hi]
            res = (matched_ids, exact_idx)
            self._cache[prefix] = res
        return res

def load_texts():
    en_files = sorted(glob.glob(os.path.join(HERE, "english_version", "**", "*.md"), recursive=True))
    en_text = "\n\n".join(open(f, encoding="utf-8", errors="ignore").read() for f in en_files[:10])
    
    ja_files = [f for f in sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True)) if "english_version" not in f]
    ja_text = "\n\n".join(open(f, encoding="utf-8", errors="ignore").read() for f in ja_files[:10])
    
    return {"en": en_text, "ja": ja_text}

def run_diagnosis_for_model(model_dir, model_name, texts, max_tokens=2048, chunk_len=512):
    print(f"\n==========================================")
    print(f"Diagnosing: {model_name} from {model_dir}")
    print(f"==========================================")
    
    t0 = time.time()
    tokenizer = AutoTokenizer.from_pretrained(model_dir, local_files_only=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
        
    model = AutoModelForCausalLM.from_pretrained(
        model_dir,
        local_files_only=True,
        dtype=torch.float32,
        low_cpu_mem_usage=True
    )
    model.eval()
    print(f"Loaded {model_name} in {time.time()-t0:.2f}s. Vocab size: {len(tokenizer)}")
    
    lattice = VocabularyLattice(tokenizer)
    print(f"Built vocabulary lattice: {len(lattice.keys)} valid byte tokens")
    
    results = {}
    
    for lang in ["en", "ja"]:
        text = texts[lang]
        enc = tokenizer(text, return_tensors="pt", add_special_tokens=False)
        ids = enc["input_ids"][0][:max_tokens].numpy()
        
        # Forward pass in chunks
        t_fwd = time.time()
        chunks_logits = []
        with torch.no_grad():
            for s in range(0, len(ids) - 1, chunk_len):
                c = ids[s:s + chunk_len + 1]
                if len(c) < 2:
                    break
                inp = torch.tensor([c[:-1]], dtype=torch.long)
                out = model(inp)
                # float32 numpy
                chunks_logits.append(out.logits[0].float().numpy())
                
        fwd_time = time.time() - t_fwd
        
        # TV = T / Z の計算
        # 各位置での次トークン w_{t+1} のバイト列 b の各プレフィックス p に対して
        tv_list = []
        j_list = []
        t_mass_list = []
        z_mass_list = []
        
        pos = 0
        for lg in chunks_logits:
            for step in range(lg.shape[0]):
                cur_pos = pos + step
                if cur_pos + 1 >= len(ids):
                    break
                
                next_tok_id = ids[cur_pos + 1]
                tok_b = lattice.id2bytes.get(next_tok_id)
                if not tok_b or len(tok_b) < 2:
                    continue
                
                # softmax で p_T を計算
                logits = lg[step]
                logits_max = np.max(logits)
                exp_logits = np.exp(logits - logits_max)
                p_T = exp_logits / np.sum(exp_logits)
                
                # prefix 長 j = 1 .. len(tok_b)-1
                for j in range(1, len(tok_b)):
                    prefix = tok_b[:j]
                    matched_ids, exact_id = lattice.get_subtree_indices(prefix)
                    
                    if len(matched_ids) == 0:
                        continue
                        
                    Z = np.sum(p_T[matched_ids])
                    T = p_T[exact_id] if exact_id is not None else 0.0
                    
                    if Z > 1e-12:
                        tv = float(T / Z)
                        # 数値誤差クリップ
                        tv = max(0.0, min(1.0, tv))
                        tv_list.append(tv)
                        j_list.append(j)
                        t_mass_list.append(float(T))
                        z_mass_list.append(float(Z))
                        
            pos += lg.shape[0]
            
        tv_arr = np.array(tv_list)
        j_arr = np.array(j_list)
        
        # 位置別集計
        j_stats = {}
        for target_j in range(1, 9):
            mask = (j_arr == target_j)
            if np.any(mask):
                j_stats[target_j] = {
                    "count": int(np.sum(mask)),
                    "mean_tv": float(np.mean(tv_arr[mask]))
                }
                
        res = {
            "model": model_name,
            "vocab_size": len(tokenizer),
            "lang": lang,
            "evaluated_positions": len(tv_arr),
            "mean_tv": float(np.mean(tv_arr)) if len(tv_arr) > 0 else 0.0,
            "median_tv": float(np.median(tv_arr)) if len(tv_arr) > 0 else 0.0,
            "p90_tv": float(np.percentile(tv_arr, 90)) if len(tv_arr) > 0 else 0.0,
            "p99_tv": float(np.percentile(tv_arr, 99)) if len(tv_arr) > 0 else 0.0,
            "pct_tv_gt_0_05": float(np.mean(tv_arr > 0.05)) * 100.0 if len(tv_arr) > 0 else 0.0,
            "pct_tv_gt_0_10": float(np.mean(tv_arr > 0.10)) * 100.0 if len(tv_arr) > 0 else 0.0,
            "mean_T": float(np.mean(t_mass_list)) if len(t_mass_list) > 0 else 0.0,
            "mean_Z": float(np.mean(z_mass_list)) if len(z_mass_list) > 0 else 0.0,
            "j_breakdown": j_stats,
            "fwd_time_sec": fwd_time
        }
        
        results[lang] = res
        print(f"[{lang.upper()}] Positions: {res['evaluated_positions']}, Mean TV: {res['mean_tv']*100:.2f}% (median: {res['median_tv']*100:.3f}%)")
        print(f"  p90: {res['p90_tv']*100:.2f}%, p99: {res['p99_tv']*100:.2f}%")
        print(f"  TV > 5%: {res['pct_tv_gt_0_05']:.1f}%, TV > 10%: {res['pct_tv_gt_0_10']:.1f}%")
        if 1 in j_stats:
            print(f"  j=1 TV: {j_stats[1]['mean_tv']*100:.2f}% (n={j_stats[1]['count']})")
        if 3 in j_stats:
            print(f"  j=3 TV: {j_stats[3]['mean_tv']*100:.2f}% (n={j_stats[3]['count']})")
            
    return results

def main():
    texts = load_texts()
    models = [
        ("qwen3-0.6b", os.path.join(HERE, "models", "qwen3-0.6b")),
        ("smollm-135m", os.path.join(HERE, "models", "smollm-135m")),
    ]
    
    all_res = {}
    for name, path in models:
        all_res[name] = run_diagnosis_for_model(path, name, texts, max_tokens=1536, chunk_len=512)
        
    out_file = os.path.join(HERE, "tv_diagnosis_results.json")
    with open(out_file, "w", encoding="utf-8") as fp:
        json.dump(all_res, fp, indent=2, ensure_ascii=False)
        
    print(f"\nAll TV diagnosis complete. Results saved to {out_file}")

if __name__ == "__main__":
    main()
