# -*- coding: utf-8 -*-
"""_debug_width_gpu2.py — 差し替え forward の中で重みが meta か実体かを出す（使い捨て）"""
import os
import types

import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "olmoe-1b-7b")

from transformers import AutoModelForCausalLM

m = AutoModelForCausalLM.from_pretrained(
    MODEL, torch_dtype=torch.bfloat16, device_map="auto",
    max_memory={0: "7.0GiB", "cpu": "8.5GiB"}).eval()

z = __import__("numpy").load(os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"))
ids = torch.from_numpy(z["en_ids"][:256].astype("int64")).unsqueeze(0)

seen = set()


def make_forward(mode, half_idx):
    def fwd(self, hidden_states, top_k_index, top_k_weights):
        key = id(self)
        first = key not in seen
        if first:
            seen.add(key)
            print("  layer? gu meta=%s dev=%s dn meta=%s hidden dev=%s dtype=%s"
                  % (self.gate_up_proj.is_meta, self.gate_up_proj.device,
                     self.down_proj.is_meta, hidden_states.device, hidden_states.dtype))
        final = torch.zeros_like(hidden_states)
        K = top_k_index.shape[-1]
        with torch.no_grad():
            mask = F.one_hot(top_k_index, num_classes=self.num_experts + 1).permute(2, 1, 0)
            hit = torch.greater(mask.sum(dim=(-1, -2)), 0).nonzero()
        for ei in hit:
            e = int(ei[0])
            if e == self.num_experts:
                continue
            pos, tokidx = torch.where(mask[e])
            is_r8 = (pos == K - 1)
            gu = self.gate_up_proj[e]
            dn = self.down_proj[e]
            keep = ~is_r8
            if keep.any():
                x = hidden_states[tokidx[keep]]
                g, u = F.linear(x, gu).chunk(2, dim=-1)
                hh = F.linear(self.act_fn(g) * u, dn)
                hh = hh * top_k_weights[tokidx[keep], pos[keep], None]
                final.index_add_(0, tokidx[keep], hh.to(final.dtype))
            if not is_r8.any():
                continue
            x = hidden_states[tokidx[is_r8]]
            g, u = F.linear(x, gu).chunk(2, dim=-1)
            hh = F.linear(self.act_fn(g) * u, dn)
            hh = hh * top_k_weights[tokidx[is_r8], pos[is_r8], None]
            final.index_add_(0, tokidx[is_r8], hh.to(final.dtype))
        if first:
            print("    -> finite=%s  max|x|=%.3f" % (
                bool(torch.isfinite(final).all().item()),
                float(hidden_states.abs().max())))
        return final
    return fwd


fn = make_forward("full", torch.arange(512))
for e in [l.mlp.experts for l in m.model.layers]:
    e.forward = types.MethodType(fn, e)

with torch.no_grad():
    out = m(input_ids=ids, use_cache=False)
print("logits finite:", torch.isfinite(out.logits).all().item())
