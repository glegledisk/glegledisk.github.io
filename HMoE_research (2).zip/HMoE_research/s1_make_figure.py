# -*- coding: utf-8 -*-
"""Report figure for S1 (reads s1_core.npz only; no measurement).

far is restricted to the 5 domains without education (n=75) everywhere,
matching the primary comparison in the report.
"""
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

import s1_analyze as A

HERE = os.path.dirname(os.path.abspath(__file__))
plt.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "DejaVu Sans"]

z, meta, rows, gold_tok, gold_row = A.load(os.path.join(HERE, "s1_core.npz"))
recs, san = A.attach_margins(z, rows, gold_tok, gold_row)
domains = sorted(set(r["domain"] for r in rows))
FIVE = [d for d in domains if d != "education"]


def qm(p, t, a="base", value="margin"):
    m = A.qmap(recs, p, a, t, value=value)
    if t == "far":
        m = {k: v for k, v in m.items() if k[0] in FIVE}
    return m


def st(p, t, a="base", value="margin"):
    return A.map_stats(qm(p, t, a, value))


fig, axes = plt.subplots(2, 2, figsize=(12.5, 8.4))
W = 0.36
COL = {"sibling": "tab:blue", "far": "tab:green", "cousin": "tab:orange"}

# --- A: margin by prompt ----------------------------------------------------
ax = axes[0, 0]
prompts = [("toc", "ToC"), ("toc_drop", "ToC\n-gold leaf"), ("none", "none"), ("shuffle", "shuffle")]
for j, t in enumerate(("sibling", "far")):
    xs, ys, es = [], [], []
    for i, (p, _) in enumerate(prompts):
        s = st(p, t)
        if s["n"]:
            xs.append(i + (j - 0.5) * W)
            ys.append(s["mean"])
            es.append(s["se"])
    ax.bar(xs, ys, W, yerr=es, capsize=2, label=t, color=COL[t], alpha=0.9)
ax.axhline(0, color="k", lw=0.6)
ax.set_xticks(range(len(prompts)))
ax.set_xticklabels([lab for _, lab in prompts], fontsize=9)
ax.set_ylabel("gold - distractor logp at divergence")
ax.set_title("(a) Absolute margin by prompt (far = 5 domains)")
ax.legend(fontsize=8)

# --- B: paired contrasts ----------------------------------------------------
ax = axes[0, 1]
contrasts = [("toc", "none", "ToC - none"),
             ("toc", "toc_drop", "ToC - no-gold"),
             ("toc_drop", "none", "no-gold - none"),
             ("toc", "shuffle", "ToC - shuffle")]
for j, t in enumerate(("sibling", "far")):
    xs, ys, es = [], [], []
    for i, (p1, p0, _) in enumerate(contrasts):
        d = A.diff_maps(qm(p1, t), qm(p0, t))
        s = A.map_stats(d)
        if s["n"]:
            xs.append(i + (j - 0.5) * W)
            ys.append(s["mean"])
            es.append(1.96 * s["se"])
    ax.bar(xs, ys, W, yerr=es, capsize=2, label=t, color=COL[t], alpha=0.9)
ax.axhline(0, color="k", lw=0.6)
ax.set_xticks(range(len(contrasts)))
ax.set_xticklabels([lab for _, _, lab in contrasts], fontsize=9)
ax.set_ylabel("delta margin (95% CI)")
ax.set_title("(b) Paired prompt contrasts (far = 5 domains)")
ax.legend(fontsize=8)

# --- C: rare share at divergence -------------------------------------------
ax = axes[1, 0]
types = ("sibling", "cousin", "far")
PCOL = {"toc": "tab:blue", "none": "tab:gray", "shuffle": "tab:purple"}
for j, p in enumerate(("toc", "none", "shuffle")):
    xs, ys, es = [], [], []
    for i, t in enumerate(types):
        s = st(p, t, value="rare_div")
        if s["n"]:
            xs.append(i + (j - 1) * W)
            ys.append(s["mean"])
            es.append(s["se"])
    ax.bar(xs, ys, W, yerr=es, capsize=2, label=p, alpha=0.9, color=PCOL[p])
ax.set_xticks(range(len(types)))
ax.set_xticklabels(types)
ax.set_ylim(0, 0.15)
ax.set_ylabel("rare-expert share of active slots")
ax.set_title("(c) Rare share at the divergence token (far = 5 domains)")
ax.legend(fontsize=8)

# --- D: ablation hurt under ToC --------------------------------------------
ax = axes[1, 1]
arms = ("g_rare", "g_freq", "l_rare", "l_freq")
for j, t in enumerate(("sibling", "far")):
    xs, ys, es = [], [], []
    for i, a in enumerate(arms):
        b = qm("toc", t)
        m = qm("toc", t, a=a)
        d = {k: b[k] - m[k] for k in set(b) & set(m)}
        s = A.map_stats(d)
        if s["n"]:
            xs.append(i + (j - 0.5) * W)
            ys.append(s["mean"])
            es.append(s["se"])
    ax.bar(xs, ys, W, yerr=es, capsize=2, label=t, color=COL[t], alpha=0.9)
ax.axhline(0, color="k", lw=0.6)
ax.set_xticks(range(len(arms)))
ax.set_xticklabels(arms)
ax.set_ylabel("hurt = margin(base) - margin(ablated)")
ax.set_title("(d) Expert ablation hurt under ToC (far = 5 domains)")
ax.legend(fontsize=8)

fig.tight_layout()
out = os.path.join(HERE, "s1_report_figure.png")
fig.savefig(out, dpi=160)
print("wrote", out)
