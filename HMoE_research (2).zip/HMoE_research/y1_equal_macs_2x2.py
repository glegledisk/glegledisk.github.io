#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Y1: 等 MACs 2×2 対照で中心命題（不均一性そのものの寄与）を直接検定する。

事前登録: `Y1課題設計書_等MACs2x2対照で中心命題を直接検定_20261107.md`。
腕・幅ベクトル・指標・判定・MDE・収束ゲート・校正条件はすべて実行前に固定。
本ファイルはその実装であって設計を変更しない。

本命 P1 = (H_1024 − U_1024) − (H_688 − U_688)  ← 同幅和内で params を揃えた
2 組の差の差なので、params 主効果が代数的に相殺される。

幅和 1024 の 3 腕は W2 の 8 ckpt を流用。幅和 688 の 3 腕のみ新規訓練。
各構成に「全層 w2 零化」の oracle 腕を置き、測定器の感度上限 (G3) を確認する。

出力: y1_results.json / y1_delta.npz / y1_analysis.json / y1_calib.json /
      y1_train.json / y1_out_utf8.txt / simulation_hmoe_mmlu/data/y1/ckpt_*.pt
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# ★ q2_difficulty_ladder を先に import しないと E2.SEQ=128 が効かず pos.w が壊れる。
import q8_static_dispatch as Q8            # noqa: E402
import q2_difficulty_ladder as Q2          # noqa: E402
import e2b_rewrite_routing_fixed as E2     # noqa: E402
from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS  # noqa: E402

assert E2.SEQ == 128, "Q2 の import が E2.SEQ を設定していない"

W2DIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "w2")
Y1DIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "y1")
Y1SMOKEDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "y1_smoke")
ACTIVE_Y1DIR = Y1DIR

PERM = tuple(int(i) for i in np.random.default_rng(20261106).permutation(8))
H_1024 = tuple(WIDTHS["H+LB"])
U_1024 = tuple(WIDTHS["U+LB"])
R_1024 = tuple(int(H_1024[i]) for i in PERM)
H_688 = (22, 22, 64, 64, 108, 108, 150, 150)
U_688 = (86,) * 8
R_688 = tuple(int(H_688[i]) for i in PERM)

WIDTHS_A = {
    "H_1024": H_1024, "U_1024": U_1024, "R_1024": R_1024,
    "H_688": H_688, "U_688": U_688, "R_688": R_688,
}
ARCHS = ("H_1024", "U_1024", "R_1024", "H_688", "U_688", "R_688")
NEW_ARCHS = ("H_688", "U_688", "R_688")
W2NAME = {"H_1024": "H", "U_1024": "U", "R_1024": "R"}
TRAIN_LOG = os.path.join(HERE, "y1_train.json")
ORACLE_ARMS = tuple(f"oracle_{a}" for a in ARCHS)
ARMS = ARCHS + ORACLE_ARMS

SEEDS = (0, 1, 2, 3, 4, 5, 6, 7)
N_EVAL, EVAL_SEED = 1024, 777
SEQS, EPOCHS, BS, LR, AUXW = 3000, 6, 32, 2e-3, 0.05
SPAN = Q2.T_LEN - Q2.TRACE0
CAL_FIELDS = ("ce_all", "instr_valid", "acc_payload", "ce_payload", "width_struct")

for _a, _w in WIDTHS_A.items():
    assert len(_w) == 8 and all(int(x) > 0 for x in _w), _a
assert sum(H_1024) == 1024 and sum(U_1024) == 1024 and sum(R_1024) == 1024
assert sum(H_688) == 688 and sum(U_688) == 688 and sum(R_688) == 688
assert R_1024 == (96, 96, 32, 160, 160, 224, 224, 32), \
    "W2 の R 幅ベクトルと一致しない（置換順の取り違え）"


# ---------------------------------------------------------------------------
# forward & evaluate（Q8.forward_dispatch の dynamic 経路とビット一致させる）
# ---------------------------------------------------------------------------
def forward_generic(model, idx, typ=None, k=2):
    p = model.p
    B, T = idx.shape
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    aux_sum = torch.zeros(())
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    idx_l = []
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
        topv, topi = logits.topk(k, dim=1)
        gate = torch.softmax(
            torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
        y = torch.zeros_like(h)
        for i in range(model.E):
            tok, _ = (topi == i).nonzero(as_tuple=True)
            if tok.numel() == 0:
                continue
            x_tok = h[tok]
            h1 = F.relu(F.linear(x_tok, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
            y.index_add_(0, tok,
                         F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                         * gate[tok, i].unsqueeze(1))
        top1 = topi[:, 0]
        f = torch.zeros(model.E, dtype=logits.dtype)
        f.scatter_add_(0, top1, torch.ones_like(top1, dtype=f.dtype))
        f = f / h.shape[0]
        P = torch.softmax(logits, dim=1).mean(0)
        dims = torch.tensor(model.dims, dtype=f.dtype)
        aux = model.E * (f * P * (dims / dims.mean())).sum()
        h = h + y
        aux_sum = aux_sum + aux
        idx_l.append(topi.reshape(B, T, k))
    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, -1)
    return out, aux_sum / model.L, idx_l


@torch.no_grad()
def evaluate_generic(model, seq, typ, k=2, bs=128):
    """W1/W2/X1 と同一の指標 + 実測 active 幅（C4 用）。"""
    n, L, E = seq.shape[0], model.L, model.E
    dims = np.array(model.dims, dtype=np.float32)
    ce = np.zeros((n, SPAN), dtype=np.float32)
    hit = np.zeros((n, SPAN), dtype=bool)
    wid = np.zeros((n, SPAN), dtype=np.float32)
    top1_l = np.zeros((L, n, SPAN), dtype=np.int64)
    topi_store = [np.zeros((n, Q2.T_LEN, k), dtype=np.int8) for _ in range(L)]
    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = torch.from_numpy(seq[s])
        t_batch = torch.from_numpy(typ[s])
        logits, _, idx_l = forward_generic(model, x, typ=t_batch, k=k)
        lg = logits[:, Q2.TRACE0 - 1:-1, :len(Q2.VOCAB)]
        tgt = torch.from_numpy(seq[s, Q2.TRACE0:])
        lp = F.cross_entropy(lg.reshape(-1, len(Q2.VOCAB)), tgt.reshape(-1),
                             reduction="none").reshape(-1, SPAN)
        ce[s] = lp.numpy()
        hit[s] = (lg.argmax(-1).numpy() == tgt.numpy())
        for l, ti in enumerate(idx_l):
            a = ti.numpy()
            topi_store[l][s] = a.astype(np.int8)
            aa = a[:, Q2.TRACE0 - 1:-1, :]
            top1_l[l][s] = aa[:, :, 0]
            wid[s] += dims[aa].mean(-1) / L

    ty = typ[:, Q2.TRACE0:]
    m_st, m_pl = (ty == Q2.TYP_STRUCT), (ty == Q2.TYP_PAYLOAD)
    u_l0 = np.bincount(top1_l[0].reshape(-1), minlength=E)
    hp = hit.reshape(n, Q2.P_STEPS, Q2.TPI)[:, :, 2:]
    instr_ok = hp.all(-1)
    # wid は「選択された top-2 の幅の平均」を層で平均したもの。active 幅は 2 倍。
    active_width = 2.0 * float(wid.mean())
    metrics = {
        "ce_all": float(ce.mean()),
        "ce_struct": float(ce[m_st].mean()),
        "ce_payload": float(ce[m_pl].mean()),
        "acc_struct": float(hit[m_st].mean()),
        "acc_payload": float(hit[m_pl].mean()),
        "width_struct": float(wid[m_st].mean()),
        "width_payload": float(wid[m_pl].mean()),
        "active_width": active_width,
        "small_struct": float(np.isin(top1_l[-1][m_st], Q2.SMALL).mean()),
        "small_payload": float(np.isin(top1_l[-1][m_pl], Q2.SMALL).mean()),
        "usage_l0": u_l0.tolist(),
        "usage_entropy": Q8.usage_entropy(u_l0),
        "usage_share_max": float(u_l0.max() / max(1.0, u_l0.sum())),
        "dead_experts": int(np.sum((u_l0 / max(1.0, u_l0.sum())) < 0.01)),
        "instr_valid": float(instr_ok.all(-1).mean()),
        "instr_acc": float(instr_ok.mean()),
        "payload_token_acc": float(hp.mean()),
        "n_eval": int(n),
    }
    extras = {
        "instr_seq": instr_ok.all(-1).astype(np.int8),
        "ce_seq": ce.mean(1).astype(np.float64),
        "topi": topi_store,
        "usage_by_layer": [np.bincount(top1_l[l].reshape(-1), minlength=E)
                           for l in range(L)],
    }
    return metrics, extras


# ---------------------------------------------------------------------------
# ckpt
# ---------------------------------------------------------------------------
def build_model(arch, seed):
    return RewriteMoE(WIDTHS_A[arch], seed=seed, topk=2)


def fresh(model, clean):
    model.p = {k: v.clone() for k, v in clean.items()}
    for k in model.p:
        model.p[k].requires_grad_(False)
    return model


def load_arch(arch, seed):
    """1024 側は W2 ckpt を流用、688 側は Y1 で訓練した ckpt。キー・形状を assert。"""
    if arch not in WIDTHS_A:
        raise ValueError(f"未登録のアーキテクチャ: {arch}")
    if arch in NEW_ARCHS:
        path = os.path.join(ACTIVE_Y1DIR, f"ckpt_{arch}_s{seed}.pt")
    elif arch in W2NAME:
        path = os.path.join(W2DIR, f"ckpt_{W2NAME[arch]}_s{seed}.pt")
    else:
        raise ValueError(f"ckpt の出所が未定義: {arch}")
    td = torch.load(path, map_location="cpu")
    model = build_model(arch, seed)
    assert set(td.keys()) == set(model.p.keys()), f"{arch} s{seed}: ckpt キー不一致"
    for kk in td:
        assert tuple(td[kk].shape) == tuple(model.p[kk].shape), \
            f"{arch} s{seed}: {kk} の形が違う"
    clean = {k: v.detach().clone() for k, v in td.items()}
    return model, clean


def apply_oracle(model, clean):
    keys = [f"l{l}.e{i}.w2" for l in range(model.L) for i in range(model.E)]
    fresh(model, clean)
    for kk in keys:
        model.p[kk] = torch.zeros_like(model.p[kk])
    return {"n_zeroed": int(sum(model.p[kk].numel() for kk in keys)),
            "keys": keys}


def train_one(arch, seed, epochs=EPOCHS):
    """W2.run_one と完全同一の訓練（widths だけ差し替え）。"""
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    model = build_model(arch, seed)
    assert list(model.dims) == list(WIDTHS_A[arch])
    opt = Adam(model.params(), lr=LR)
    nparam = int(sum(v.numel() for v in model.params().values()))
    steps = max(1, SEQS // BS)
    hist = []
    t0 = time.time()
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps):
            xs, ty = Q2.make_trace_batch(rng, BS, task="hard")
            logits, aux, _ = forward_generic(
                model, torch.from_numpy(xs), typ=torch.from_numpy(ty), k=2)
            loss = Q2.trace_loss(logits, xs) + AUXW * aux
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        hist.append(float(run / steps))
    os.makedirs(ACTIVE_Y1DIR, exist_ok=True)
    torch.save({k: v.detach() for k, v in model.params().items()},
               os.path.join(ACTIVE_Y1DIR, f"ckpt_{arch}_s{seed}.pt"))
    return {"arch": arch, "seed": seed, "widths": list(WIDTHS_A[arch]),
            "nparam": nparam, "loss_hist": hist,
            "sec": round(time.time() - t0, 1)}


# ---------------------------------------------------------------------------
# 校正
# ---------------------------------------------------------------------------
def calibration(seq, typ, w2_rows):
    items = []

    def add(tag, arch, seed, field, want, got):
        if isinstance(want, list):
            d = float(np.max(np.abs(np.array(got, dtype=float) -
                                    np.array(want, dtype=float))))
        else:
            d = abs(float(want) - float(got))
        items.append({"check": tag, "arch": arch, "seed": seed, "field": field,
                      "want": want, "got": got, "abs_diff": d,
                      "bit_match": bool(d < 1e-12)})

    # C1: W2 の H / U / R ckpt を再評価し w2_results.json の eval と照合（120 項目）
    for arch in ("H_1024", "U_1024", "R_1024"):
        for seed in SEEDS:
            model, clean = load_arch(arch, seed)
            fresh(model, clean)
            m, _ = evaluate_generic(model, seq, typ, k=2)
            ref = next(r["eval"] for r in w2_rows
                       if r["arm"] == W2NAME[arch] and r["seed"] == seed)
            for fld in CAL_FIELDS:
                add("C1", arch, seed, fld, ref[fld], m[fld])

    # C2: forward_generic と Q8.forward_dispatch の一致
    model, clean = load_arch("H_1024", 0)
    fresh(model, clean)
    x = torch.from_numpy(seq[:32])
    t = torch.from_numpy(typ[:32])
    with torch.no_grad():
        a, auxa, ia = Q8.forward_dispatch(model, x, typ=t, mode="dynamic_lb")
        b, auxb, ib = forward_generic(model, x, typ=t, k=2)
    d_logit = float((a - b).abs().max())
    d_aux = abs(float(auxa) - float(auxb))
    d_idx = float(max(float((x1 != x2).float().max()) for x1, x2 in zip(ia, ib)))
    items.append({"check": "C2", "arch": "H_1024", "seed": 0, "field": "logits",
                  "want": 0.0, "got": d_logit, "abs_diff": d_logit,
                  "bit_match": bool(d_logit < 1e-12 and d_aux < 1e-12 and d_idx == 0.0)})
    items.append({"check": "C2", "arch": "H_1024", "seed": 0, "field": "aux",
                  "want": 0.0, "got": d_aux, "abs_diff": d_aux,
                  "bit_match": bool(d_aux < 1e-12)})

    # C3: nparam（1024 側 3 腕 = 1,346,877、688 側 3 腕が互いに一致）
    np1024 = [sum(v.numel() for v in build_model(a, 0).params().values())
              for a in ("H_1024", "U_1024", "R_1024")]
    np688 = [sum(v.numel() for v in build_model(a, 0).params().values())
             for a in NEW_ARCHS]
    items.append({"check": "C3", "arch": "1024", "seed": 0, "field": "nparam_equal",
                  "want": 1346877, "got": int(np1024[0]),
                  "abs_diff": abs(int(np1024[0]) - 1346877),
                  "bit_match": bool(all(v == 1346877 for v in np1024))})
    items.append({"check": "C3", "arch": "688", "seed": 0, "field": "nparam_equal",
                  "want": int(np688[0]), "got": int(np688[1]),
                  "abs_diff": abs(int(np688[0]) - int(np688[1])),
                  "bit_match": bool(len(set(np688)) == 1)})
    for a in ARCHS:
        m = build_model(a, 0)
        items.append({"check": "C3", "arch": a, "seed": 0, "field": "widths",
                      "want": list(WIDTHS_A[a]), "got": list(m.dims),
                      "abs_diff": 0.0,
                      "bit_match": bool(list(m.dims) == list(WIDTHS_A[a]))})

    # C5: 未知の腕名・アーキテクチャで例外
    raised = 0
    try:
        load_arch("__unknown__", 0)
    except ValueError:
        raised += 1
    items.append({"check": "C5", "arch": "-", "seed": 0, "field": "unknown_raises",
                  "want": 1, "got": raised, "abs_diff": abs(1 - raised),
                  "bit_match": bool(raised == 1)})
    return items


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=list(SEEDS))
    ap.add_argument("--archs", nargs="+", default=list(ARMS))
    ap.add_argument("--train_archs", nargs="+", default=list(NEW_ARCHS))
    ap.add_argument("--tag", default="y1")
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--n_eval", type=int, default=N_EVAL)
    ap.add_argument("--epochs", type=int, default=EPOCHS)
    ap.add_argument("--reuse", action="store_true", help="688 側 ckpt を再訓練しない")
    ap.add_argument("--train_only", action="store_true",
                    help="688 側の訓練だけ行って終了（本番は --reuse で再利用）")
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()

    global ACTIVE_Y1DIR
    ACTIVE_Y1DIR = Y1SMOKEDIR if args.smoke else Y1DIR
    # ★ smoke の 1-epoch 走行を本番の訓練ログに混ぜない（X1 で踏んだ罠）
    train_log = os.path.join(HERE, "y1_smoke_train.json") if args.smoke else TRAIN_LOG
    if args.smoke:
        args.seeds = [0]
        args.epochs = 1
    torch.set_num_threads(args.threads)
    torch.manual_seed(12345)

    tag = args.tag
    LOG = os.path.join(HERE, f"{tag}_out_utf8.txt")
    if os.path.exists(LOG):
        os.remove(LOG)

    def log(msg):
        print(msg, flush=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")

    for a in args.archs:
        if a not in ARMS:
            raise ValueError(f"未登録の腕: {a}")
    log(f"Y1: threads={args.threads} arms={len(args.archs)} seeds={args.seeds} "
        f"n_eval={args.n_eval} epochs={args.epochs} reuse={args.reuse} "
        f"train_only={args.train_only} smoke={args.smoke}")
    for a in ARCHS:
        log(f"  {a:<9s} widths={WIDTHS_A[a]} sum={sum(WIDTHS_A[a])}")
    assert E2.SEQ == 128

    ev_rng = np.random.default_rng(EVAL_SEED)
    seq, typ = Q2.make_trace_batch(ev_rng, args.n_eval, task="hard")
    log(f"eval batch: seq={seq.shape} typ={typ.shape} SPAN={SPAN}")

    with open(os.path.join(HERE, "w2_results.json"), encoding="utf-8") as f:
        w2_rows = json.load(f)["rows"]

    # ---------------- 校正 ----------------
    calib, ok_calib = [], True
    if not args.train_only:
        t0 = time.time()
        calib = calibration(seq, typ, w2_rows)
        ok_calib = all(c["bit_match"] for c in calib)
        with open(os.path.join(HERE, f"{tag}_calib.json"), "w", encoding="utf-8") as f:
            json.dump({"items": calib, "n": len(calib),
                       "all_bit_match": bool(ok_calib)},
                      f, ensure_ascii=False, indent=2, default=float)
        log(f"校正: {sum(c['bit_match'] for c in calib)}/{len(calib)} bit-match "
            f"all={ok_calib} ({time.time()-t0:.0f}s)")
        for c in calib:
            if not c["bit_match"]:
                log(f"  MISMATCH {c['check']} {c['arch']} s{c['seed']} "
                    f"{c['field']}: want={c['want']} got={c['got']} "
                    f"diff={c['abs_diff']}")
        if not ok_calib:
            log("校正が落ちたので本番を走らせない。原因を調べること。")
            os._exit(1)

    # ---------------- 688 側の訓練 ----------------
    train_rows = []
    for arch in args.train_archs:
        if arch not in NEW_ARCHS:
            raise ValueError(f"訓練対象は 688 側のみ: {arch}")
        for seed in args.seeds:
            path = os.path.join(ACTIVE_Y1DIR, f"ckpt_{arch}_s{seed}.pt")
            if args.reuse and os.path.exists(path):
                log(f"  [reuse] {arch} s{seed}")
                continue
            r = train_one(arch, seed, epochs=args.epochs)
            train_rows.append(r)
            log(f"  [train] {arch} s{seed} nparam={r['nparam']} "
                f"loss[-1]={r['loss_hist'][-1]:.4f} {r['sec']}s")

    if args.train_only:
        # 本番が --reuse のとき G1 を評価できるよう、常に y1_train.json に固定する。
        if os.path.exists(train_log):
            with open(train_log, encoding="utf-8") as f:
                prev = json.load(f).get("rows", [])
            merged = {f"{r['arch']}_s{r['seed']}": r for r in prev}
            for r in train_rows:
                merged[f"{r['arch']}_s{r['seed']}"] = r
            train_rows = list(merged.values())
        with open(train_log, "w", encoding="utf-8") as f:
            json.dump({"rows": train_rows, "args": vars(args),
                       "widths": {a: list(WIDTHS_A[a]) for a in ARCHS}},
                      f, ensure_ascii=False, indent=2, default=float)
        log(f"train_only 完了: 今回 {len(args.train_archs) * len(args.seeds)} 走行、"
            f"y1_train.json 累計 {len(train_rows)} 走行。本番は --reuse で実行")
        os._exit(0)

    # --reuse のとき train_rows は空なので、訓練ログから G1 を復元する
    if not train_rows and os.path.exists(train_log):
        with open(train_log, encoding="utf-8") as f:
            train_rows = json.load(f).get("rows", [])
        log(f"  G1 用に {train_log} から {len(train_rows)} 走行を復元")

    # ---------------- 本番評価 ----------------
    na, ns = len(args.archs), len(args.seeds)
    aa = {a: i for i, a in enumerate(args.archs)}
    sa = {s: j for j, s in enumerate(args.seeds)}
    iv = np.full((na, ns), np.nan)
    ce_all = np.full((na, ns), np.nan)
    ce_pay = np.full((na, ns), np.nan)
    acc_pay = np.full((na, ns), np.nan)
    w_st = np.full((na, ns), np.nan)
    w_pl = np.full((na, ns), np.nan)
    act_w = np.full((na, ns), np.nan)
    instr_seq = np.zeros((na, ns, args.n_eval), dtype=np.int8)
    ce_seq = np.zeros((na, ns, args.n_eval), dtype=np.float64)
    nparam_arr = np.zeros(na, dtype=np.int64)
    rows = []

    for arch in args.archs:
        base = arch[len("oracle_"):] if arch.startswith("oracle_") else arch
        for seed in args.seeds:
            model, clean = load_arch(base, seed)
            if arch.startswith("oracle_"):
                info = apply_oracle(model, clean)
            else:
                fresh(model, clean)
                info = {"n_zeroed": 0, "keys": []}
            m, x = evaluate_generic(model, seq, typ, k=2)
            i, j = aa[arch], sa[seed]
            iv[i, j] = m["instr_valid"]
            ce_all[i, j] = m["ce_all"]
            ce_pay[i, j] = m["ce_payload"]
            acc_pay[i, j] = m["acc_payload"]
            w_st[i, j] = m["width_struct"]
            w_pl[i, j] = m["width_payload"]
            act_w[i, j] = m["active_width"]
            instr_seq[i, j] = x["instr_seq"]
            ce_seq[i, j] = x["ce_seq"]
            nparam_arr[i] = int(sum(v.numel() for v in clean.values()))
            rows.append({"arm": arch, "arch": base, "seed": seed, **m,
                         "n_zeroed": info["n_zeroed"],
                         "nparam": int(nparam_arr[i])})
            log(f"  {arch:<17s} s{seed} iv={m['instr_valid']:.4f} "
                f"ce={m['ce_all']:.5f} actW={m['active_width']:.1f} "
                f"w_st/pl={m['width_struct']:.1f}/{m['width_payload']:.1f}")

    # ---------------- 保存 ----------------
    with open(os.path.join(HERE, f"{tag}_results.json"), "w", encoding="utf-8") as f:
        json.dump({"rows": rows, "train_rows": train_rows, "args": vars(args),
                   "arms": list(args.archs), "seeds": list(args.seeds),
                   "widths": {a: list(WIDTHS_A[a]) for a in ARCHS},
                   "perm": list(PERM)},
                  f, ensure_ascii=False, indent=2, default=float)
    np.savez_compressed(
        os.path.join(HERE, f"{tag}_delta.npz"),
        arms=np.array(args.archs, dtype=object), seeds=np.array(args.seeds),
        iv=iv, ce_all=ce_all, ce_payload=ce_pay, acc_payload=acc_pay,
        width_struct=w_st, width_payload=w_pl, active_width=act_w,
        instr_seq=instr_seq, ce_seq=ce_seq, nparam=nparam_arr)

    # ---------------- 集計 ----------------
    def paired(d):
        d = np.asarray(d, dtype=float)
        se = float(d.std(ddof=1) / math.sqrt(len(d))) if len(d) >= 2 else float("nan")
        if not np.isfinite(se) or se == 0:
            t, p, mde = 0.0, 1.0, 0.0
        else:
            t = float(d.mean() / se)
            p = float(2 * stats.t.sf(abs(t), df=len(d) - 1))
            mde = float(stats.t.ppf(0.975, len(d) - 1) * se)
        return {"delta": float(d.mean()), "se": se, "t": t, "p": p,
                "mde": mde, "n": int(len(d)), "per_seed": d.tolist(),
                "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum())}

    def series_diff(arch_a, arch_b):
        """seed ごとの系列平均差、および系列単位の配列（裾の診断用）。"""
        if arch_a not in aa or arch_b not in aa:
            return None, None
        d = ce_seq[aa[arch_a]] - ce_seq[aa[arch_b]]
        return d.mean(1), d

    # 主指標 ce_seq の 4 比較
    def make_comp(name, expr_ce, expr_iv, dseq):
        r = paired(expr_ce)
        r["iv"] = paired(expr_iv)
        r["pair"] = name
        if dseq is not None:
            ab = np.abs(dseq.reshape(-1))
            ntop = max(1, int(math.ceil(len(ab) * 0.01)))
            r["ce_top1_share"] = float(np.sort(ab)[-ntop:].sum() /
                                       max(1e-12, ab.sum()))
            r["ce_median"] = float(np.median(dseq))
            r["ce_max"] = float(ab.max())
        return r

    comps = {}
    if all(a in aa for a in ("H_1024", "U_1024", "H_688", "U_688", "R_1024", "R_688")):
        ce_a, da = series_diff("H_1024", "U_1024")
        ce_b, db = series_diff("H_688", "U_688")
        iv_a = iv[aa["H_1024"]] - iv[aa["U_1024"]]
        iv_b = iv[aa["H_688"]] - iv[aa["U_688"]]
        comps["P1"] = make_comp("(H_1024-U_1024)-(H_688-U_688)",
                                ce_a - ce_b, iv_a - iv_b, da - db)
        ce_p2, dp2 = series_diff("H_1024", "U_688")
        comps["P2"] = make_comp("H_1024-U_688", ce_p2,
                                iv[aa["H_1024"]] - iv[aa["U_688"]], dp2)
        comps["P3"] = make_comp("H_1024-U_1024", ce_a, iv_a, da)
        ce_p4a, dp4a = series_diff("H_1024", "R_1024")
        ce_p4b, dp4b = series_diff("H_688", "R_688")
        comps["P4_1024"] = make_comp("H_1024-R_1024", ce_p4a,
                                     iv[aa["H_1024"]] - iv[aa["R_1024"]], dp4a)
        comps["P4_688"] = make_comp("H_688-R_688", ce_p4b,
                                    iv[aa["H_688"]] - iv[aa["R_688"]], dp4b)

    # Holm m = 3 を P1/P2/P3 に（主指標 ce_seq）
    prim = [k for k in ("P1", "P2", "P3") if k in comps]
    order = sorted(prim, key=lambda k: comps[k]["p"])
    run = 0.0
    holm = {}
    for rank, k in enumerate(order):
        run = max(run, min(1.0, (len(prim) - rank) * comps[k]["p"]))
        holm[k] = {"p_raw": comps[k]["p"], "p_holm": float(run),
                   "rank": rank + 1, "m": len(prim)}
    for k in comps:
        comps[k]["p_holm"] = holm[k]["p_holm"] if k in holm else None
        comps[k]["class"] = "primary" if k in holm else "exploratory"
        comps[k]["detected"] = bool(
            k in holm and abs(comps[k]["delta"]) > comps[k]["mde"] and
            comps[k]["p_holm"] < 0.05 and
            max(comps[k]["n_pos"], comps[k]["n_neg"]) >= 7)

    # 収束ゲート G1 / G2 / G3
    g1 = {}
    for a in NEW_ARCHS:
        losses = [r["loss_hist"][-1] for r in train_rows if r["arch"] == a]
        g1[a] = {"n": len(losses), "median_last_loss":
                 float(np.median(losses)) if losses else None,
                 "pass": bool(losses and float(np.median(losses)) < 0.30)}
    g2 = {a: {"n_seed_iv_ge_010": int((iv[aa[a]] >= 0.10).sum()),
              "pass": bool(a in aa and int((iv[aa[a]] >= 0.10).sum()) >= 6)}
          for a in ARCHS if a in aa}
    g3 = {}
    for a in ARCHS:
        o = f"oracle_{a}"
        if o in aa and a in aa:
            d = (ce_seq[aa[o]] - ce_seq[aa[a]]).mean()
            g3[a] = {"delta_ce_seq": float(d), "pass": bool(d >= 0.30)}

    # C4: 実測 active 幅
    c4 = {}
    if "H_1024" in aa and "U_688" in aa:
        h = float(act_w[aa["H_1024"]].mean())
        u = float(act_w[aa["U_688"]].mean())
        c4 = {"H_1024": h, "U_688": u,
              "abs_diff": abs(h - u),
              "rel_diff": abs(h - u) / max(1e-12, 0.5 * (h + u)),
              "within_10pct": bool(abs(h - u) / max(1e-12, 0.5 * (h + u)) <= 0.10)}
    c4["active_width_mean"] = {a: float(act_w[aa[a]].mean())
                               for a in ARCHS if a in aa}

    analysis = {
        "calibration": {"n": len(calib), "all_bit_match": bool(ok_calib)},
        "comparisons": comps,
        "holm": holm,
        "gates": {"G1_train_convergence": g1, "G2_iv_floor": g2,
                  "G3_oracle_sensitivity": g3},
        "C4_active_width": c4,
        "nparam": {a: int(nparam_arr[aa[a]]) for a in args.archs},
        "baseline": {a: {"iv": float(iv[aa[a]].mean()),
                         "ce_all": float(ce_all[aa[a]].mean()),
                         "width_struct": float(w_st[aa[a]].mean()),
                         "width_payload": float(w_pl[aa[a]].mean()),
                         "active_width": float(act_w[aa[a]].mean())}
                     for a in ARCHS if a in aa},
        "verdict": {
            "calibration_ok": bool(ok_calib),
            "g1_ok": bool(all(v["pass"] for v in g1.values())) if g1 else None,
            "g2_ok": bool(all(v["pass"] for v in g2.values())) if g2 else None,
            "g3_ok": bool(all(v["pass"] for v in g3.values())) if g3 else None,
            "detected": {k: comps[k]["detected"] for k in comps},
        },
        "meta": {"threads": args.threads, "n_eval": args.n_eval,
                 "eval_seed": EVAL_SEED, "epochs": args.epochs,
                 "seqs": SEQS, "bs": BS, "lr": LR, "auxw": AUXW,
                 "seeds": list(args.seeds), "arms": list(args.archs),
                 "n_rows": len(rows), "n_train": len(train_rows),
                 "smoke": args.smoke, "perm": list(PERM)},
    }
    with open(os.path.join(HERE, f"{tag}_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2, default=float)

    log("")
    log(f"== 校正 {sum(c['bit_match'] for c in calib)}/{len(calib)} "
        f"all={ok_calib} | gates G1={analysis['verdict']['g1_ok']} "
        f"G2={analysis['verdict']['g2_ok']} G3={analysis['verdict']['g3_ok']}")
    log("== baseline ==")
    for a in ARCHS:
        if a in aa:
            b = analysis["baseline"][a]
            log(f"  {a:<9s} iv={b['iv']:.4f} ce={b['ce_all']:.5f} "
                f"actW={b['active_width']:.1f} w_st/pl={b['width_struct']:.1f}/"
                f"{b['width_payload']:.1f} nparam={analysis['nparam'][a]}")
    log("== 主比較（ce_seq, Holm m=3）==")
    for k, c in comps.items():
        ph = c["p_holm"]
        log(f"  {k:<9s} Δ={c['delta']:+.4f} se={c['se']:.4f} t={c['t']:+.2f} "
            f"p={c['p']:.4f} Holm={('%.4f' % ph) if ph is not None else 'explore':>8s} "
            f"MDE={c['mde']:.4f} 符号 {c['n_pos']}正/{c['n_neg']}負 "
            f"Δiv={c['iv']['delta']:+.4f} detected={c['detected']}")
    log(f"  C4 active width: {c4}")
    log(f"verdict: {analysis['verdict']}")
    log(f"saved: {tag}_results.json / {tag}_delta.npz / "
        f"{tag}_analysis.json / {tag}_calib.json")
    os._exit(0)


if __name__ == "__main__":
    main()
