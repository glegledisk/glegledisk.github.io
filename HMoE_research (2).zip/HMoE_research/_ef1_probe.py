# -*- coding: utf-8 -*-
"""使い捨て: EF1 設計書の δ0 と MDE / se の関係を一次 json から検算する。

- δ0 は AX9 meta の走行前固定値 delta_tost をそのまま継承
- 「Δ ≤ δ0 を棄却する」検定の t は (mean − δ0)/se であって mean/MDE ではない
- 結果は _ef1_probe.json に UTF-8 で保存
"""
import json

with open("ax10_shift_avg.json", encoding="utf-8") as f:
    A10 = json.load(f)
with open("ax8_feasible_probe.json", encoding="utf-8") as f:
    A8 = json.load(f)
with open("ax9_cross_ckpt.json", encoding="utf-8") as f:
    A9 = json.load(f)

x = A10["confirmatory"]["P1_length"]
t975 = x["mde"] / x["se"]  # t_{0.975, 12239} を MDE/se から復元
delta0 = A9["meta"]["delta_tost"]  # 0.005、AX9 で走行前に固定

out = {"delta0_from": "ax9_cross_ckpt.json meta.delta_tost (走行前固定)",
       "delta0": delta0, "t975_from_ax10_mde_over_se": t975, "arms": {}}

for tag, J in (("AX8", A8), ("AX9", A9)):
    c = J["confirmatory"]["S2_gap"]
    mean, se, sd, mde, n = c["mean"], c["se"], c["sd"], c["mde"], c["n"]
    out["arms"][tag] = {
        "gap_mean": mean, "se": se, "sd": sd, "mde": mde, "n": n,
        "holm_S2": J["confirmatory"]["holm"]["S2"],
        "ci90": c["ci90"],
        "t_for_H0_gap_le_delta0": (mean - delta0) / se,
        "delta0_over_mde": delta0 / mde,
        "n_need_for_delta0_exceed": (t975 * sd / (mean - delta0)) ** 2,
        "n_need_over_actual": (t975 * sd / (mean - delta0)) ** 2 / n,
    }

with open("_ef1_probe.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print(json.dumps(out, ensure_ascii=False, indent=2))
