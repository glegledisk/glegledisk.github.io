# -*- coding: utf-8 -*-
"""e5_stability_check.py — タスクの学習安定性が比較の検出力を潰していないか

7 seed の結果、frozen_ffn（ルーティング固定・上限）の CE が 0.549〜0.913（SD 0.155）と
大きくばらついた。これはルータの問題ではなく「課題の学習が seed によって失敗する」ため。
この状態では free と frozen_ffn の差（0.047 nats）がノイズに埋もれる。

仮説: エポック数が足りない（12 epoch）。
検証: frozen_ffn を 12 / 30 / 60 epoch で回し、CE の平均と SD がどう変わるかを見る。
"""
import os, json, time
import numpy as np
import pandas as pd
from e5_dependency_task import run

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=16, anchor_vals=(0, 1, 2, 3), d=16)
EPOCHS = [12, 30, 60]
SEEDS = [0, 1, 2, 3, 4]

rows = []
t0 = time.time()
for ep in EPOCHS:
    for s in SEEDS:
        r = run("frozen_ffn", s, epochs=ep, **CFG)
        r["epochs"] = ep
        rows.append(r)
        print(f"  frozen_ffn ep={ep:2d} s{s} | acc {r['acc_all']:.4f} (anchor {r['acc_anchor']:.3f}) "
              f"| CE {r['ce_all']:.4f}", flush=True)
    d = pd.DataFrame(rows); d = d[d.epochs == ep]
    print(f"    -> ep={ep}: CE {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"acc {d['acc_all'].mean():.4f}±{d['acc_all'].std():.4f}  ({time.time()-t0:.0f}s)", flush=True)

df = pd.DataFrame(rows)
df.to_csv(os.path.join(HERE, "e5_stability_check.csv"), index=False)
print("\n=== エポック数と学習の安定性（5 seeds） ===")
print(f"{'epochs':>7s} {'CE mean':>9s} {'CE SD':>8s} {'CE min':>8s} {'CE max':>8s} {'acc mean':>9s} {'acc SD':>8s}")
summary = []
for ep in EPOCHS:
    d = df[df.epochs == ep]
    print(f"{ep:7d} {d['ce_all'].mean():9.4f} {d['ce_all'].std():8.4f} {d['ce_all'].min():8.4f} "
          f"{d['ce_all'].max():8.4f} {d['acc_all'].mean():9.4f} {d['acc_all'].std():8.4f}")
    summary.append({"epochs": ep, "ce_mean": float(d["ce_all"].mean()), "ce_sd": float(d["ce_all"].std()),
                    "ce_min": float(d["ce_all"].min()), "ce_max": float(d["ce_all"].max()),
                    "acc_mean": float(d["acc_all"].mean()), "acc_sd": float(d["acc_all"].std())})
json.dump(summary, open(os.path.join(HERE, "e5_stability_check.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e5_stability_check.csv / .json")
