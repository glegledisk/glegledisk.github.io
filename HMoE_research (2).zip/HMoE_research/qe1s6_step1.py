# -*- coding: utf-8 -*-
"""QE1S6 Step 1: K=2048 sqrt write + 2% uniform mix calibration (no training/GPU).

設計書: `QE1S6課題設計書_K2048固定でsqrt写一様混合2パーセントを走行前固定する_20261116.md`
        §1〜§2 / §4

固定: K=2048, ALPHA=0.5, EPS_MIX=0.02, seed=0, n_seq=4000。
zipf は QE1S4 paired stream とビット一致、mixed2048 は同じ u を sqrt 圧縮し
pick RNG の後続消費で 2% を一様 support へ差し替える。
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "不均一MoE-Corpus"))

from corpus_common import (COPY_WINDOW, N_TYPES, SEQ_LEN, TRAIN_SEED_BASE,  # noqa: E402
                           V_IDENT, V_SYNTAX, VOCAB, zipf_cdf)
from qe1_make_task import (CALIB_SEED, EPS_EDIT, EPS_EDIT_MI, EPS_POS,  # noqa: E402
                           INIT_SEED_BASE, N_CALIB_SEQ, POS_BINS, SYNTAX_PER_TYPE,
                           QE1Corpus, QE1S4_IDENT_STREAM_OFFSET,
                           QE1S4_SYNR_STREAM_OFFSET, calibrate, eta2_categorical,
                           joint_table, mi_over_entropy, pos_bins)

TAG = "qe1s6_step1"
K_SQRT = 2048
ALPHA = 0.5
EPS_MIX = 0.02
EPS_H = 0.10
EPS_P_DIFF = 0.02
MIN_P_COPY = 0.10
ARRAY_KEYS = ("tokens", "types", "next_tok", "copy_mask", "is_syntax",
              "ident_rank", "type_draw", "a", "changed", "base")


def build(freq: str):
    shape = (int(N_CALIB_SEQ), SEQ_LEN)
    rng = np.random.default_rng(int(CALIB_SEED) + int(TRAIN_SEED_BASE))
    type_draw = rng.integers(0, N_TYPES, size=shape, dtype=np.int64)
    is_syntax = rng.random(shape) < 0.25
    ident_rng = np.random.default_rng(
        int(CALIB_SEED) + int(TRAIN_SEED_BASE) + QE1S4_IDENT_STREAM_OFFSET)
    u = ident_rng.random(shape)
    rank = np.clip(np.searchsorted(zipf_cdf(), u, side="right"), 0, V_IDENT - 1)
    if freq == "zipf":
        ident = rank
        idmod = V_IDENT
    else:
        base = np.clip(np.floor(np.power(rank.astype(np.float64), ALPHA)
                                * (K_SQRT / np.power(V_IDENT, ALPHA))).astype(np.int64),
                       0, K_SQRT - 1)
        flat = np.floor(u * K_SQRT).astype(np.int64)
        pick = ident_rng.random(shape) < EPS_MIX
        ident = np.where(pick, flat, base)
        idmod = K_SQRT
    syn_r = np.random.default_rng(
        int(CALIB_SEED) + int(TRAIN_SEED_BASE) + QE1S4_SYNR_STREAM_OFFSET).integers(
            0, SYNTAX_PER_TYPE, size=shape, dtype=np.int64)
    syntax_id = N_TYPES + type_draw * SYNTAX_PER_TYPE + syn_r
    tokens = np.where(is_syntax, syntax_id, V_SYNTAX + ident).astype(np.int64)

    pos = np.broadcast_to(np.arange(SEQ_LEN, dtype=np.int64), shape)
    last = np.maximum.accumulate(np.where(is_syntax, pos, -1), axis=1)
    rows = np.arange(shape[0])[:, None]
    fill = np.random.default_rng(int(CALIB_SEED) + INIT_SEED_BASE).integers(
        0, N_TYPES, size=(shape[0], 1), dtype=np.int64)
    a = np.where(last >= 0, type_draw[rows, np.clip(last, 0, None)], fill)

    bt = np.empty(shape, dtype=np.int64)
    bt[:, :-1] = tokens[:, 1:]
    bt[:, -1] = tokens[:, 0]
    ib = bt >= V_SYNTAX
    inc = np.where(ib, V_SYNTAX + ((bt - V_SYNTAX + 1) % idmod), bt)
    lag = np.empty(shape, dtype=np.int64)
    lag[:, 2:] = tokens[:, :-2]
    lag[:, :2] = bt[:, :2]
    prev = np.empty(shape, dtype=np.int64)
    prev[:, 1:] = tokens[:, :-1]
    prev[:, 0] = bt[:, 0]
    nxt = np.select([a == 0, a == 1, a == 2, a == 3],
                    [bt, inc, lag, prev], default=bt).astype(np.int64)
    changed = nxt != bt
    cm = np.zeros(shape, dtype=bool)
    for l in range(1, COPY_WINDOW + 1):
        pt = np.zeros(shape, dtype=np.int64)
        pt[:, l:] = tokens[:, :-l]
        cm |= pt == nxt
    cm &= ~(nxt < V_SYNTAX)
    cm[:, -1] = False
    pf = np.broadcast_to(np.arange(SEQ_LEN, dtype=np.float64), shape).ravel()
    tf = type_draw.ravel().astype(np.float64)
    r = float(np.corrcoef(pf, tf)[0, 1])
    if not np.isfinite(r):
        r = 0.0
    return QE1Corpus(
        tokens=tokens, types=a.copy(), next_tok=nxt, copy_mask=cm,
        is_syntax=is_syntax, ident_rank=ident.astype(np.int16),
        pos_corr=abs(r), type_draw=type_draw.astype(np.int8),
        a=a.astype(np.int8), changed=changed, base=bt.astype(np.int16))


def entropy_copy(c):
    x = np.asarray(c.next_tok)[np.asarray(c.copy_mask, dtype=bool)]
    cnt = np.bincount(x, minlength=VOCAB).astype(np.float64)
    p = cnt[cnt > 0] / x.size
    return float(-np.sum(p * np.log(p)))


def recurrence(c):
    cm = np.asarray(c.copy_mask, dtype=bool)
    tok = np.asarray(c.tokens, dtype=np.int64)
    nxt = np.asarray(c.next_tok, dtype=np.int64)
    rows, cols = np.nonzero(cm)
    found = np.zeros(rows.size, dtype=bool)
    tgt = nxt[rows, cols]
    for lag in range(1, COPY_WINDOW + 1):
        src = cols - lag
        ok = src >= 0
        found[ok] |= tok[rows[ok], src[ok]] == tgt[ok]
    return float(found.mean())


def measure(c, label):
    cal = calibrate(c, label)
    pb = pos_bins(c.tokens.shape)
    cm = np.asarray(c.copy_mask, dtype=bool)
    return {
        "label": label,
        "n_seq": int(c.tokens.shape[0]), "n_tokens": int(c.tokens.size),
        "R_copy": float(cm.astype(np.float64).mean()),
        "H_emp": entropy_copy(c),
        "P_rule": {r: float(cal["by_edit_rule"][r]["p_copyable"])
                   for r in ("copy", "inc", "lag", "prev")},
        "P_re": recurrence(c),
        "N_syn": float((np.asarray(c.next_tok)[cm] < V_SYNTAX).mean()),
        "C2_eta2_type_pos": float(cal["C2_eta2_type_pos"]),
        "C2_mi_type_pos_norm": float(cal["C2_mi_type_pos_norm"]),
        "C3_eta2_edit_given_pos": float(cal["C3_eta2_edit_given_pos"]),
        "C3_mi_edit_norm": float(cal["C3_mi_edit_norm"]),
        "C7_eta2_a_pos": float(eta2_categorical(c.a, pb, POS_BINS, N_TYPES)),
        "C7_mi_a_pos_norm": float(mi_over_entropy(
            joint_table(pb, c.a, POS_BINS, N_TYPES))),
        "copy_positions": int(cm.sum()),
    }


def maxdiff(a, b):
    return int(np.max(np.abs(np.asarray(a, dtype=np.int64)
                             - np.asarray(b, dtype=np.int64))))


def main():
    out = {"tag": TAG, "phase": "QE1S6 Step 1 (K=2048 sqrt + 2% uniform mix)",
           "design": "QE1S6課題設計書_K2048固定でsqrt写一様混合2パーセントを走行前固定する_20261116.md",
           "no_training": True, "no_gpu": True, "no_confirmatory_test": True}
    out["prereg"] = {"K_SQRT": K_SQRT, "ALPHA": ALPHA, "EPS_MIX": EPS_MIX,
                     "SEED": CALIB_SEED, "N_CALIB_SEQ": N_CALIB_SEQ,
                     "EPS_H": EPS_H, "EPS_P_DIFF": EPS_P_DIFF,
                     "MIN_P_COPY": MIN_P_COPY, "COPY_WINDOW": COPY_WINDOW,
                     "V_IDENT": V_IDENT}

    corpora = {f: build(f) for f in ("zipf", "mixed2048")}
    m = {f: measure(corpora[f], f"qe1s6_{f}") for f in corpora}
    z, s = m["zipf"], m["mixed2048"]
    dh = float(s["H_emp"] - z["H_emp"])
    dp = float(s["P_rule"]["copy"] - z["P_rule"]["copy"])

    from qe1_make_task import make_task
    ref_zipf = make_task(CALIB_SEED, N_CALIB_SEQ, base=TRAIN_SEED_BASE,
                         freq="zipf", init_type="uniform",
                         ident_vocab_size=V_IDENT, paired_frequency=True)
    zipf_vs_s4 = {k: maxdiff(getattr(ref_zipf, k), getattr(corpora["zipf"], k))
                  for k in ARRAY_KEYS}
    common = {}
    for k in ("type_draw", "is_syntax", "a"):
        common[k] = maxdiff(getattr(corpora["zipf"], k), getattr(corpora["mixed2048"], k))
    syntax_equal = bool(np.array_equal(
        np.asarray(corpora["zipf"].tokens)[np.asarray(corpora["zipf"].is_syntax, dtype=bool)],
        np.asarray(corpora["mixed2048"].tokens)[np.asarray(corpora["mixed2048"].is_syntax, dtype=bool)]))

    old = np.load(HERE / "qe1s3_step1_arrays.npz")
    defz = make_task(CALIB_SEED, N_CALIB_SEQ, base=TRAIN_SEED_BASE,
                     freq="zipf", init_type="uniform")
    defz2 = make_task(CALIB_SEED, N_CALIB_SEQ, base=TRAIN_SEED_BASE,
                      freq="zipf", init_type="uniform")
    c1, c1_repeat = {}, {}
    for k in ARRAY_KEYS:
        refk = f"zipf_{k}"
        if refk in old.files:
            ref = old[refk]
        elif k == "types":
            ref = old["zipf_a"]
        elif k == "is_syntax":
            ref = old["zipf_tokens"] < V_SYNTAX
        else:
            raise KeyError(refk)
        c1[k] = maxdiff(getattr(defz, k), ref)
        c1_repeat[k] = maxdiff(getattr(defz, k), getattr(defz2, k))

    pos_ok = all(v < EPS_POS for f in ("zipf", "mixed2048")
                 for v in (m[f]["C2_eta2_type_pos"], m[f]["C2_mi_type_pos_norm"],
                           m[f]["C7_eta2_a_pos"], m[f]["C7_mi_a_pos_norm"]))
    edit_ok = all(m[f]["C3_eta2_edit_given_pos"] > EPS_EDIT
                  and m[f]["C3_mi_edit_norm"] > EPS_EDIT_MI
                  for f in ("zipf", "mixed2048"))
    checks = {
        "C1_default_path_maxdiff_zero": bool(max(list(c1.values())
                                                  + list(c1_repeat.values())) == 0),
        "C2_common_streams": bool(max(common.values()) == 0 and syntax_equal
                                  and max(zipf_vs_s4.values()) == 0),
        "C3_entropy_match": bool(abs(dh) <= EPS_H),
        "C4_copy_recurrence_match": bool(abs(dp) <= EPS_P_DIFF
                                         and s["P_rule"]["copy"] >= MIN_P_COPY),
        "C5_position_independence": bool(pos_ok),
        "C6_edit_signal": bool(edit_ok),
        "C7_copy_mask_integrity": bool(all(
            abs(m[f]["P_re"] - 1.0) < 1e-12 and abs(m[f]["N_syn"]) < 1e-12
            for f in ("zipf", "mixed2048"))),
    }
    out.update({
        "measurement": m, "delta_H": dh, "delta_P_copy": dp,
        "common_stream_maxdiff": common, "syntax_ids_equal": syntax_equal,
        "zipf_vs_s4_maxdiff": zipf_vs_s4,
        "C1_default_maxdiff": c1, "C1_repeat_maxdiff": c1_repeat,
        "checks": checks,
        "verdict": "PASS" if all(checks.values()) else "FAIL",
    })

    def scan(o, path="root"):
        bad = []
        if isinstance(o, dict):
            for k, v in o.items():
                bad += scan(v, f"{path}.{k}")
        elif isinstance(o, list):
            for j, v in enumerate(o):
                bad += scan(v, f"{path}[{j}]")
        elif isinstance(o, float) and not np.isfinite(o):
            bad.append(path)
        return bad
    nf = scan(out)
    out["C8_nonfinite"] = nf
    if nf:
        out["verdict"] = "FAIL"

    arrays = {}
    for f, c in corpora.items():
        for k in ARRAY_KEYS:
            arrays[f"{f}_{k}"] = np.asarray(getattr(c, k))
    arrays["zipf_pos_bin"] = pos_bins(corpora["zipf"].tokens.shape).astype(np.int8)
    arrays["mixed2048_pos_bin"] = pos_bins(corpora["mixed2048"].tokens.shape).astype(np.int8)
    np.savez(HERE / f"{TAG}_arrays.npz", **arrays)
    (HERE / f"{TAG}_metrics.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    lines = [
        f"tag={TAG}", f"verdict={out['verdict']}",
        f"H_emp zipf={z['H_emp']:.8f} mixed2048={s['H_emp']:.8f} delta={dh:+.8f}",
        f"P_copy zipf={z['P_rule']['copy']:.8f} mixed2048={s['P_rule']['copy']:.8f} delta={dp:+.8f}",
        f"R_copy zipf={z['R_copy']:.8f} mixed2048={s['R_copy']:.8f}",
        f"checks={checks}", f"nonfinite={nf}", "",
    ]
    (HERE / f"{TAG}.log").write_text("\n".join(lines), encoding="utf-8")
    sys.stdout.write("\n".join(lines))
    sys.stdout.flush()


if __name__ == "__main__":
    main()
