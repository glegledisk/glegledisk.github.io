# -*- coding: utf-8 -*-
"""e7_beta_7seed.py — entropy β の感度（tail リスク再発境界の特定）

## 動機（tokid+安定化レポート §9-1）
tokid_entropy（β=0.05）は全アーム中最良（CE 0.0766、FFN 0.746、obj 0.1885）で、
entropy 単体の tail リスク（1/7 seed で CE 1.93）も解消した。
しかし **β は 0.05 しか試していない**。β を上げればオフロード圧力が強まり最適方針
（FFN 0.425）に近づく可能性がある一方、tail リスクが再発する可能性もある。

## 設計: β の用量反応（5 点）
| β | 意味 | データ |
|---|---|---|
| 0（entropy なし） | tokid 単体 | A4 の free_tokid（既存 7 seed） |
| 0.02 | 弱い圧力 | 新規 7 seed |
| 0.05 | 現行の最良 | tokid+安定化の tokid_entropy（既存 7 seed） |
| 0.15 | 強い圧力 | 新規 7 seed |
| 0.30 | 過剰圧力（λ 項と同程度） | 新規 7 seed |
| 0.60 | 極端（λ 項の 2 倍） | 追加 7 seed（境界の上端を探す） |

## 判定
1. **tail リスク**: 各 β の最大 CE / CE>0.5 の seed 数 / CE SD。どこで再発するか。
2. **用量反応**: β に対して FFN cost・id_ff（オフロード率）・CE がどう動くか。単調か。
3. **最適方針への接近**: FFN cost が 0.425 に近づくか、それとも CE が犠牲になるか。
4. **検出力の限界**: 7 seed では 10% の失敗率を 0/7 と観測する確率が 48%。境界の同定は粗い
   （レポートに明記する）。

構成: 3 β × 7 seed（不足分のみ実行・逐次保存・再開可能）
"""
import os, json, time
import numpy as np
import pandas as pd
import torch
from e7_stabilize_task import run, make_lookup_table, ROLE_NAME

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)), d=64, epochs=60)
SEEDS = list(range(7))
OUT = os.path.join(HERE, "e7_beta_7seed.csv")
LAMS = [0.03, 0.05, 0.08, 0.15, 0.30]
DEV = "cuda" if torch.cuda.is_available() else "cpu"
tab = make_lookup_table(64)

BETAS = [0.02, 0.15, 0.30, 0.60]
SPEC = dict(route="free", router="linear", stab="entropy", extra="tokid")


def vname(b):
    return f"tokid_ent_b{int(round(b * 100)):02d}"


rows = []
if os.path.exists(OUT):
    rows = pd.read_csv(OUT).to_dict("records")
have = {(r["variant"], int(r["seed"])) for r in rows}
print(f"device: {DEV}  既存 {len(have)} 件")

todo = [(b, s) for b in BETAS for s in SEEDS if (vname(b), s) not in have]
print(f"追加実行 {len(todo)} 件")

t0 = time.time()
for i, (b, s) in enumerate(todo, 1):
    r = run(vname(b), s, ent_beta=b, table=tab, device=DEV, spec=SPEC, **CFG)
    r["ent_beta"] = b
    rows.append(r)
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"  [{i}/{len(todo)}] β={b:.2f} s{s} | CE {r['ce_all']:.4f} | FFN {r['ffn_cost']:.3f} "
          f"| acc {r['acc_all']:.4f} (ff {r['acc_ff']:.3f} / fr {r['acc_fr']:.3f} / rr {r['acc_rr']:.3f}) "
          f"| idff {r['id_rate_ff']:.3f} | {time.time()-t0:.0f}s", flush=True)

df = pd.DataFrame(rows)
df["obj015"] = df["ce_all"] + 0.15 * df["ffn_cost"]
df = df.sort_values(["ent_beta", "seed"]).reset_index(drop=True)
df.to_csv(OUT, index=False)

# 既存の β=0（free_tokid）と β=0.05（tokid_entropy）
a4 = pd.read_csv(os.path.join(HERE, "e7_stabilize_7seed.csv"))
a4["obj015"] = a4["ce_all"] + 0.15 * a4["ffn_cost"]
ts = pd.read_csv(os.path.join(HERE, "e7_tokid_stab_7seed.csv"))
ts["obj015"] = ts["ce_all"] + 0.15 * ts["ffn_cost"]
e7 = pd.read_csv(os.path.join(HERE, "e7_routing_7seed.csv"))
e7["obj015"] = e7["ce_all"] + 0.15 * e7["ffn_cost"]
ffn = e7[e7.arm == "frozen_ffn"].set_index("seed")

CURVE = [(0.0, "tokid 単体", a4[a4.variant == "free_tokid"].set_index("seed"))]
for b in BETAS:
    CURVE.append((b, vname(b), df[df.ent_beta == b].set_index("seed")))
CURVE.append((0.05, "tokid_entropy", ts[ts.variant == "tokid_entropy"].set_index("seed")))
CURVE = sorted(CURVE, key=lambda x: x[0])

print("\n=== β の用量反応（60 epoch・7 seed, E7 課題, λ=0.15） ===")
print(f"{'β':>5s} {'CE':>16s} {'max CE':>8s} {'CE>0.5':>7s} {'FFN':>14s} {'obj(λ=.15)':>16s} "
      f"{'acc rr':>8s} {'id ff':>7s} {'id rr':>7s}")
curve = {}
for b, name, d in CURVE:
    mx, nbad = float(d["ce_all"].max()), int((d["ce_all"] > 0.5).sum())
    curve[str(b)] = {"name": name, "ce": float(d["ce_all"].mean()), "ce_sd": float(d["ce_all"].std()),
                     "max_ce": mx, "n_catastrophic": nbad, "ffn": float(d["ffn_cost"].mean()),
                     "ffn_sd": float(d["ffn_cost"].std()), "obj": float(d["obj015"].mean()),
                     "acc_rr": float(d["acc_rr"].mean()), "id_ff": float(d["id_rate_ff"].mean()),
                     "id_rr": float(d["id_rate_rr"].mean())}
    print(f"{b:5.2f} {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f} {mx:8.4f} {nbad:7d} "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f} {d['obj015'].mean():.4f}±{d['obj015'].std():.4f} "
          f"{d['acc_rr'].mean():8.4f} {d['id_rate_ff'].mean():7.3f} {d['id_rate_rr'].mean():7.3f}")

print("\n=== 各 β − frozen_ffn（seed 対応） ===")
res_ffn = {}
for b, name, d in CURVE:
    for k in ("obj015", "ce_all", "ffn_cost"):
        dd = (d[k] - ffn[k]).dropna()
        m, sd = dd.mean(), dd.std(ddof=1)
        t = m / (sd / np.sqrt(len(dd))) if sd > 0 else float("nan")
        rng = np.random.default_rng(0)
        boot = np.array([rng.choice(dd.values, len(dd), replace=True).mean() for _ in range(20000)])
        lo, hi = np.percentile(boot, [2.5, 97.5])
        res_ffn[f"b{b}_{k}"] = {"mean": float(m), "ci": [float(lo), float(hi)], "t": float(t),
                                "wins": int((dd < 0).sum()), "n": int(len(dd))}
        print(f" β={b:.2f} {k:9s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {int((dd<0).sum())}/{len(dd)}")

print("\n=== 各 β − β=0.05（seed 対応）: β を動かす効果 ===")
base05 = dict((b, d) for b, name, d in CURVE)[0.05]
res_05 = {}
for b, name, d in CURVE:
    if b == 0.05:
        continue
    for k in ("obj015", "ce_all", "ffn_cost"):
        dd = (d[k] - base05[k]).dropna()
        m, sd = dd.mean(), dd.std(ddof=1)
        t = m / (sd / np.sqrt(len(dd))) if sd > 0 else float("nan")
        rng = np.random.default_rng(1)
        boot = np.array([rng.choice(dd.values, len(dd), replace=True).mean() for _ in range(20000)])
        lo, hi = np.percentile(boot, [2.5, 97.5])
        res_05[f"b{b}_{k}"] = {"mean": float(m), "ci": [float(lo), float(hi)], "t": float(t)}
        print(f" β={b:.2f} {k:9s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f}")

print("\n=== seed 別 CE（tail リスクの目視） ===")
for b, name, d in CURVE:
    print(f" β={b:.2f} ({name:14s}) " + " ".join(f"{x:.3f}" for x in d["ce_all"]))

print("\n=== seed 別 FFN cost ===")
for b, name, d in CURVE:
    print(f" β={b:.2f} " + " ".join(f"{x:.3f}" for x in d["ffn_cost"]))

print("\n=== λ 感度（合成目的） ===")
print(f"{'λ':>5s} {'frozen_ffn':>12s} " + "".join(f"{'β='+format(b,'.2f'):>12s}" for b, _, _ in CURVE))
lam_tab = {}
for lam in LAMS:
    vals = {"frozen_ffn": ffn["ce_all"].mean() + lam * ffn["ffn_cost"].mean()}
    for b, name, d in CURVE:
        vals[f"b{b}"] = d["ce_all"].mean() + lam * d["ffn_cost"].mean()
    lam_tab[str(lam)] = {k: float(x) for k, x in vals.items()}
    print(f"{lam:5.2f} {vals['frozen_ffn']:12.4f} " + "".join(f"{vals[f'b{b}']:12.4f}" for b, _, _ in CURVE))

json.dump({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in CFG.items()},
           "device": DEV, "betas": BETAS, "curve": curve,
           "paired_vs_ffn": res_ffn, "paired_vs_b05": res_05,
           "lambda_sensitivity": lam_tab, "raw": rows},
          open(os.path.join(HERE, "e7_beta_7seed.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e7_beta_7seed.csv / .json")
