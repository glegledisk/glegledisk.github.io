# -*- coding: utf-8 -*-
"""e7_deadzone_7seed.py — top-k dead zone の直接検証

## 仮説（H-B レポート §4）
tokid_entropy が ff の 45% しかオフロードしない原因の候補: **top-k gating の dead zone**。
identity logit が top-2 に入っていない位置では、ゲートが identity logit に依存しないため
コスト圧力の勾配が届かず（∂g/∂z_id = 0）、identity logit が上がる動機が生まれない。
→ オフロード率は「初期化・早期訓練で identity が top-2 に入った位置の割合」で凍結する。

## 検証 1: マージン分布・in-zone 率の追跡（直接測度）
マージン m = identity logit − 全体 2 位の logit。m > 0 なら identity は top-2 内。
probe アーム（tokid_entropy, 3 seed）で epoch 5〜60 の in-zone 率とマージン分布を追跡:
  - in-zone 率が早期に凍結し、以降动かない → dead zone 支持
  - 最終 in-zone 率 ≈ id_rate（オフロード率）→ zone に入った位置だけが逃がされる
  - マージン分布が 0 の周りで二峰（gap）→ zone 内外の間を行き来できない

## 検証 2: identity logit バイアス介入（因果検証）
identity logit に定数 b を足す（top-2 入りやすくする）。dead zone が律速なら:
  - b を上げると in-zone 率が上がり → コスト勾配が届く → オフロードが増える（FFN ↓）
  - fr/rr では CE 勾配が identity を押し戻すので、ff 選択的なオフロードが実現する
b = 0（tokid_entropy と同条件）を baseline に、b ∈ {1.0, 3.0} で連続的に変化するかを見る。

構成: probe 3 seed + b=1.0 7 seed + b=3.0 7 seed（逐次保存・再開可能）
"""
import os, json, time
import numpy as np
import pandas as pd
import torch
from e7_stabilize_task import run, make_lookup_table, ROLE_NAME

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)), d=64, epochs=60)
OUT = os.path.join(HERE, "e7_deadzone_7seed.csv")
DEV = "cuda" if torch.cuda.is_available() else "cpu"
tab = make_lookup_table(64)

SPEC = dict(route="free", router="linear", stab="entropy", extra="tokid")
PROBE_EPOCHS = (5, 10, 20, 30, 40, 50, 60)
ARMS = {
    "probe": dict(spec=SPEC, id_bias=0.0, probe=PROBE_EPOCHS, seeds=[0, 1, 2]),
    "bias10": dict(spec=SPEC, id_bias=1.0, probe=(), seeds=list(range(7))),
    "bias30": dict(spec=SPEC, id_bias=3.0, probe=(), seeds=list(range(7))),
}

rows = []
if os.path.exists(OUT):
    rows = pd.read_csv(OUT).to_dict("records")
have = {(r["variant"], int(r["seed"])) for r in rows}
print(f"device: {DEV}  既存 {len(have)} 件")

todo = [(v, s) for v, a in ARMS.items() for s in a["seeds"] if (v, s) not in have]
print(f"追加実行 {len(todo)} 件")

t0 = time.time()
for i, (v, s) in enumerate(todo, 1):
    a = ARMS[v]
    r = run(v, s, table=tab, device=DEV, spec=a["spec"], id_bias=a["id_bias"],
            probe_epochs=a["probe"], **CFG)
    rows.append(r)
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"  [{i}/{len(todo)}] {v:8s} s{s} | CE {r['ce_all']:.4f} | FFN {r['ffn_cost']:.3f} "
          f"| acc {r['acc_all']:.4f} | idff {r['id_rate_ff']:.3f} | inzone_ff {r['fin_inzone_ff']:.3f} "
          f"| m50_ff {r['fin_margin_p50_ff']:+.2f} | {time.time()-t0:.0f}s", flush=True)

df = pd.DataFrame(rows)
df["obj015"] = df["ce_all"] + 0.15 * df["ffn_cost"]
df = df.sort_values(["variant", "seed"]).reset_index(drop=True)
df.to_csv(OUT, index=False)

# baselines
ts = pd.read_csv(os.path.join(HERE, "e7_tokid_stab_7seed.csv"))
ts["obj015"] = ts["ce_all"] + 0.15 * ts["ffn_cost"]
e7 = pd.read_csv(os.path.join(HERE, "e7_routing_7seed.csv"))
e7["obj015"] = e7["ce_all"] + 0.15 * e7["ffn_cost"]
ffn = e7[e7.arm == "frozen_ffn"].set_index("seed")
te = ts[ts.variant == "tokid_entropy"].set_index("seed")

print("\n=== dead zone 検証: サマリー（60 epoch・7 seed, E7 課題, λ=0.15） ===")
print(f"{'arm':10s} {'bias':>5s} {'CE':>16s} {'FFN':>14s} {'obj(λ=.15)':>16s} {'acc rr':>8s} "
      f"{'id ff':>7s} {'inzone ff':>10s} {'m50 ff':>8s}")
print(f"{'frozen_ffn':10s} {'0':>5s} {ffn['ce_all'].mean():.4f}±{ffn['ce_all'].std():.4f} "
      f"{ffn['ffn_cost'].mean():.3f}±{ffn['ffn_cost'].std():.3f} {ffn['ce_all'].mean()+0.15:.4f}±{ffn['ce_all'].std():.4f} "
      f"{ffn['acc_rr'].mean():8.4f} {0.0:7.3f} {0.0:10.3f} {0.0:8.2f}")
print(f"{'tokid_ent':10s} {'0':>5s} {te['ce_all'].mean():.4f}±{te['ce_all'].std():.4f} "
      f"{te['ffn_cost'].mean():.3f}±{te['ffn_cost'].std():.3f} {te['obj015'].mean():.4f}±{te['obj015'].std():.4f} "
      f"{te['acc_rr'].mean():8.4f} {te['id_rate_ff'].mean():7.3f} {'—':>10s} {'—':>8s}")
summ = {}
for v in ARMS:
    d = df[df.variant == v]
    if len(d) == 0:
        continue
    print(f"{v:10s} {ARMS[v]['id_bias']:5.1f} {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f} "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f} {d['obj015'].mean():.4f}±{d['obj015'].std():.4f} "
          f"{d['acc_rr'].mean():8.4f} {d['id_rate_ff'].mean():7.3f} {d['fin_inzone_ff'].mean():10.3f} "
          f"{d['fin_margin_p50_ff'].mean():+8.2f}")
    summ[v] = {k: float(d[k].mean()) for k in
               ["ce_all", "ffn_cost", "obj015", "acc_all", "acc_rr", "acc_ff", "acc_fr",
                "id_rate_ff", "id_rate_fr", "id_rate_rr", "fin_inzone_ff", "fin_margin_p50_ff",
                "ce_ff", "ce_fr", "ce_rr"]}

print("\n=== 検証 1: probe アームの in-zone 率の推移（seed 平均） ===")
dp = df[df.variant == "probe"]
if len(dp) > 0:
    logs = [json.loads(x) for x in dp["probe_log"]]
    eps = [e["epoch"] for e in logs[0]]
    print(f"{'epoch':>6s} {'inzone_ff':>10s} {'inzone_fr':>10s} {'inzone_rr':>10s} "
          f"{'m50_ff':>8s} {'m90_ff':>8s} {'id_rate_ff':>10s}")
    # 最終 epoch の id_rate と比較するため、probe の最後と res の id_rate を併記
    for k, ep in enumerate(eps):
        inz = {nm: np.mean([lg[k][f"inzone_{nm}"] for lg in logs]) for nm in ROLE_NAME.values()}
        m50 = np.mean([lg[k]["margin_p50_ff"] for lg in logs])
        m90 = np.mean([lg[k]["margin_p90_ff"] for lg in logs])
        print(f"{ep:6d} {inz['ff']:10.3f} {inz['fr']:10.3f} {inz['rr']:10.3f} {m50:+8.2f} {m90:+8.2f}")
    print(f"{'final':>6s} {'—':>10s} {'—':>10s} {'—':>10s} {'—':>8s} {'—':>8s} "
          f"{dp['id_rate_ff'].mean():10.3f}  ← 実際のオフロード率（final inzone_ff = {dp['fin_inzone_ff'].mean():.3f}）")

print("\n=== 検証 1b: in-zone 率とオフロード率の一致（seed 別） ===")
if len(dp) > 0:
    for _, r in dp.sort_values("seed").iterrows():
        print(f"  s{int(r['seed'])}: inzone_ff {r['fin_inzone_ff']:.3f}  id_rate_ff {r['id_rate_ff']:.3f}  "
              f"idmass_ff {r['idmass_ff']:.3f}  差 {r['fin_inzone_ff']-r['id_rate_ff']:+.3f}")

print("\n=== 検証 2: バイアスの効果（seed 対応検定） ===")


def paired(d_new, d_base, key):
    d = (d_new[key] - d_base[key]).dropna()
    m, sd = d.mean(), d.std(ddof=1)
    t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
    rng = np.random.default_rng(0)
    boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(20000)])
    lo, hi = np.percentile(boot, [2.5, 97.5])
    return m, lo, hi, t, int((d < 0).sum()), len(d)


res = {}
for v in ["bias10", "bias30"]:
    dv = df[df.variant == v].set_index("seed")
    for base_name, base in [("tokid_ent", te), ("frozen_ffn", ffn)]:
        for k in ("obj015", "ce_all", "ffn_cost", "id_rate_ff"):
            if k not in dv.columns and k == "id_rate_ff":
                continue
            m, lo, hi, t, w, n = paired(dv, base, k)
            res[f"{v}_vs_{base_name}_{k}"] = {"mean": float(m), "ci": [float(lo), float(hi)],
                                              "t": float(t), "wins": w}
            print(f" {v:8s} vs {base_name:11s} {k:11s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {w}/{n}")

print("\n=== seed 別（bias アーム） ===")
for v in ["bias10", "bias30"]:
    d = df[df.variant == v].sort_values("seed")
    print(f" {v:8s} CE  " + " ".join(f"{x:.3f}" for x in d["ce_all"]))
    print(f" {'':8s} FFN " + " ".join(f"{x:.3f}" for x in d["ffn_cost"]))
    print(f" {'':8s} idF " + " ".join(f"{x:.3f}" for x in d["id_rate_ff"]))
    print(f" {'':8s} inzF" + " ".join(f"{x:.3f}" for x in d["fin_inzone_ff"]))

print("\n=== λ 感度（合成目的） ===")
print(f"{'λ':>5s} {'frozen_ffn':>12s} {'b=0':>10s} {'b=1.0':>10s} {'b=3.0':>10s}")
lam_tab = {}
for lam in [0.03, 0.05, 0.08, 0.15, 0.30]:
    vals = {"frozen_ffn": ffn["ce_all"].mean() + lam * ffn["ffn_cost"].mean(),
            "b0": te["ce_all"].mean() + lam * te["ffn_cost"].mean()}
    for v in ["bias10", "bias30"]:
        d = df[df.variant == v]
        if len(d):
            vals[v] = d["ce_all"].mean() + lam * d["ffn_cost"].mean()
    lam_tab[str(lam)] = {k: float(x) for k, x in vals.items()}
    print(f"{lam:5.2f} {vals['frozen_ffn']:12.4f} {vals['b0']:10.4f} "
          + " ".join(f"{vals[v]:10.4f}" for v in ["bias10", "bias30"] if v in vals))

json.dump({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in CFG.items()},
           "device": DEV, "arms": {k: {kk: vv for kk, vv in v.items() if kk != "spec"} for k, v in ARMS.items()},
           "summary": summ, "paired": res, "lambda_sensitivity": lam_tab, "raw": rows},
          open(os.path.join(HERE, "e7_deadzone_7seed.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e7_deadzone_7seed.csv / .json")
