# -*- coding: utf-8 -*-
"""p6g_layer_rescale.py — 層の非対称性は質量の欠落で説明できるか

P6b: f8b6（後半を削る）は f6b8（前半を削る）より p を 9 倍押し上げる。
P6c: k を一様に削ったときの p の押し上げは「質量の欠落」が作っていた。

ここでは層の非対称性に rescale を掛ける。2x2 + base:
    base       : 全層 top-8
    f6b8       : 前半(0-7) top-6 / 後半 top-8
    f6b8_rs    : 同 + rescale
    f8b6       : 前半 top-8 / 後半(8-15) top-6
    f8b6_rs    : 同 + rescale

f6b8 と f8b6 は削るスロット数が同じ（16）なので、**失う質量の総量はほぼ同じ**。
それでも p の押し上げが 9 倍違うなら、「どれだけ失うか」ではなく
「どこで失うか」が効いていることになる。rescale で差が消えれば質量由来、
残れば内容（位置）由来。

出力: p6g_layer_rescale.npz / p6g_out_utf8.txt

実行:
  python p6g_layer_rescale.py --gpu-gib 7.5 --cpu-gib 12.0
"""

import argparse
import os
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


CONDS = [
    ("base", None, False),
    ("f6b8", "0-7:6,8-15:8", False),
    ("f6b8_rs", "0-7:6,8-15:8", True),
    ("f8b6", "0-7:8,8-15:6", False),
    ("f8b6_rs", "0-7:8,8-15:6", True),
]


def parse_alloc(spec, n_layers, full_k):
    ks = [full_k] * n_layers
    if not spec:
        return ks
    for part in spec.split(","):
        rng, k = part.split(":")
        k = int(k)
        if rng.strip() == "all":
            idx = range(n_layers)
        elif "-" in rng:
            a, b = rng.split("-")
            idx = range(int(a), int(b) + 1)
        else:
            idx = [int(rng)]
        for i in idx:
            ks[i] = k
    return ks


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--ids", type=str, default=os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"))
    ap.add_argument("--gpu-gib", type=float, default=7.5)
    ap.add_argument("--cpu-gib", type=float, default=12.0)
    args = ap.parse_args()

    import torch
    from transformers import AutoModelForCausalLM

    log("[1/3] loading %s" % args.model)
    t0 = time.time()
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      loaded in %.0f s" % (time.time() - t0))

    n_layers = int(model.config.num_hidden_layers)
    FULL_K = int(model.config.num_experts_per_tok)
    gates = [layer.mlp.gate for layer in model.model.layers]
    ORIG = [g.forward for g in gates]

    def make_rescaled(orig, full_k):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            if scores.shape[-1] < full_k:
                probs = torch.softmax(logits.float(), dim=-1)
                m_full = torch.topk(probs, full_k, dim=-1).values.sum(-1, keepdim=True)
                m_now = scores.float().sum(-1, keepdim=True).clamp_min(1e-9)
                scores = (scores.float() * (m_full / m_now)).to(scores.dtype)
            return logits, scores, idx
        return _patched

    kept = []
    handles = []
    for g in gates:
        def mk():
            def hook(module, inp, out):
                kept.append(out[1].detach().float().sum(-1).cpu())
            return hook
        handles.append(g.register_forward_hook(mk()))

    z = np.load(args.ids, allow_pickle=True)
    seqs = []
    for lang in ("en", "ja"):
        ids = torch.from_numpy(z["%s_ids" % lang].astype(np.int64))
        for w in range(ids.numel() // 256):
            seqs.append((lang, ids[w * 256:(w + 1) * 256]))
    lang_arr = np.array([s[0] for s in seqs])
    log("[2/3] frozen corpus: %d windows x 256 = %d tokens" % (len(seqs), len(seqs) * 256))

    store = {}
    for name, spec, rescale in CONDS:
        ks = parse_alloc(spec, n_layers, FULL_K)
        for i, g in enumerate(gates):
            g.top_k = ks[i]
            g.forward = make_rescaled(ORIG[i], FULL_K) if rescale else ORIG[i]
        kept.clear()
        t1 = time.time()
        ch = {key: [] for key in ("nll", "ptop1", "top1", "mass5", "in5")}
        with torch.no_grad():
            for lang, ids in seqs:
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                lg = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                logZ = torch.logsumexp(lg, dim=-1)
                true_l = lg.gather(1, tgt.unsqueeze(-1)).squeeze(-1)
                rank = (lg > true_l.unsqueeze(-1)).sum(dim=-1) + 1
                top1_l, _ = lg.max(dim=-1)
                top5_l = torch.topk(lg, 5, dim=-1).values
                ch["nll"].append((logZ - true_l).cpu().numpy())
                ch["ptop1"].append(torch.exp(top1_l - logZ).cpu().numpy())
                ch["top1"].append((rank == 1).float().cpu().numpy())
                ch["mass5"].append(torch.exp(torch.logsumexp(top5_l, dim=-1) - logZ).cpu().numpy())
                ch["in5"].append((rank <= 5).float().cpu().numpy())
                del out, lg, logZ, true_l, rank, top5_l
                torch.cuda.empty_cache()
        store[name] = {kk: np.concatenate(v) for kk, v in ch.items()}
        km = torch.stack(kept[-n_layers * len(seqs):]).numpy()
        km = km.reshape(n_layers, len(seqs), -1).mean(axis=(1, 2))
        store[name]["kept_mass_by_layer"] = km
        log("      %-8s ks=%s rs=%d  CE %.5f  p_top1 %.4f  acc %.4f  mass %.4f (%.0f s)"
            % (name, "".join(str(k) for k in ks), int(rescale),
               store[name]["nll"].mean(), store[name]["ptop1"].mean(),
               store[name]["top1"].mean(), float(km.mean()), time.time() - t1))

    for h in handles:
        h.remove()

    np.savez_compressed(
        os.path.join(HERE, "p6g_layer_rescale.npz"), lang=lang_arr,
        **{("%s_%s" % (n, kk)): store[n][kk] for n in store for kk in store[n]})
    with open(os.path.join(HERE, "p6g_out_utf8.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(LOG))
    log("saved p6g_layer_rescale.npz")
    import sys
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
