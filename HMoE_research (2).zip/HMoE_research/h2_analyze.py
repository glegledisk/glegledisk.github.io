"""H2 の解析: セル別の「容量の限界価値」と、軸（t vs 難易度）の非対称性。"""
import json
import os
from collections import defaultdict

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    rows = []
    with open(os.path.join(HERE, "h2_capacity_map.jsonl"), encoding="utf-8") as fp:
        for line in fp:
            if line.strip():
                rows.append(json.loads(line))
    if not rows:
        print("no data")
        return

    cells = sorted(rows[0]["ce"].keys())
    widths = sorted({r["width"] for r in rows})

    # cell -> width -> mean CE over seeds
    tab = defaultdict(dict)
    for r in rows:
        for c, v in r["ce"].items():
            tab[c].setdefault(r["width"], []).append(v)

    print("=== CE(width) をセル別に（seed 平均）===")
    print("%-14s" % "cell" + "".join("%10.2f" % w for w in widths))
    for c in cells:
        print("%-14s" % c + "".join("%10.4f" % np.mean(tab[c][w]) for w in widths))

    print("\n=== 容量の限界価値 dCE/dwidth（幅 1.0→2.0 の傾き）===")
    slopes = {}
    for c in cells:
        xs = np.array(widths, dtype=float)
        ys = np.array([np.mean(tab[c][w]) for w in widths])
        d = np.gradient(ys, xs)
        slopes[c] = float(np.interp(1.5, xs, d))
        print("%-14s %+9.4f   (全体傾き %+.4f)" % (c, slopes[c], (ys[-1] - ys[0]) / (xs[-1] - xs[0])))

    # 軸ごとの変動: t 軸（難易度を固定して t を動かす）/ 難易度軸（t を固定して kind を動かす）
    tb = sorted({c.split("|")[0] for c in cells})
    print("\n=== 軸の非対称性（限界価値の変動幅）===")
    for kind in ("hard", "easy"):
        vals = [slopes[f"{t}|{kind}"] for t in tb if f"{t}|{kind}" in slopes]
        if vals:
            print("t 軸 (%s): max/min = %.2f  (幅 %.4f)" %
                  (kind, max(vals) / min(vals) if min(vals) > 0 else float("inf"), max(vals) - min(vals)))
    for t in tb:
        h, e = slopes.get(f"{t}|hard"), slopes.get(f"{t}|easy")
        if h is not None and e is not None:
            print("難易度軸 (t=%s): hard/easy = %.2f  (差 %+.4f)" % (t, h / e if e else float("inf"), h - e))

    allv = np.array(list(slopes.values()))
    print("\n全セルの限界価値: min %.4f / max %.4f / 比 %.2f" %
          (allv.min(), allv.max(), allv.max() / allv.min() if allv.min() > 0 else float("inf")))

    # 一様配分 vs 難易度で配分したときの理論利得（線形近似）
    print("\n=== 参考: セル別限界価値のばらつきが許す最大利得（線形近似）===")
    print("  すべてのセルで同じ傾きなら配分の余地は 0。比が大きいほど余地が大きい。")


if __name__ == "__main__":
    main()
