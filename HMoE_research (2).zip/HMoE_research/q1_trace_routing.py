#!/usr/bin/env python3
"""Q1: 合成トレース上でトークン種別（struct / payload）× expert サイズの選択を測る。

背景: `考察_QwenputerとHMoE_20261030.md` §6-2 の実験。Qwenputer 型の決定論的トレースを
E2b の HMoE に流し、(a) どのサイズの expert が活性化するか、(b) k を落とすとどれだけ
劣化するかを測る。

タスク（Qwenputer の最小模擬）
  pos 0..N_DIG-1    : 初期値（一様乱数、**入力なので損失なし**）
  pos N_DIG         : ':' 区切り
  pos N_DIG+1+7s .. : トレース 1 命令 = [op, '=', 値 5 桁]
  op は**固定プログラム**（位置で決まる → 構造トークンはエントロピーゼロ）
  値は 0..99999 で A(+1) / S(-1) / D(×2) を順に適用した状態（payload、繰り上がりを含む）

  **設計の経緯（2026-10-30）**: 最初は「ランダムなプログラム領域 + 0 から始めるトレース」にしたが、
  (1) トレースに op が入っているのでプログラム領域が完全に冗長、(2) 0 から 10 ステップでは
  到達する値が 2^10 程度にしかならず上位桁が常に 0、という 2 つの理由でリークした
  （プログラムを別系列に入れ替えても payload 精度 1.0000 のまま）。初期値を一様乱数にし、
  プログラムを固定して解決した。

トークン種別
  struct : op（コピー）と '='（位置で決まる）→ ほぼエントロピーゼロ
  payload: 値の 2 桁 → 状態依存。実行しないと決まらない

アーム
  H+LB : 幅 32/32/96/96/160/160/224/224, top-2, p_pen
  U+LB : 幅 128 x 8,                  top-2, switch

測るもの
  種別ごとの acc / CE / 幅 / 小 expert（e0,e1）選択率、層別の同じ量
  k 削減（k=1 全層 / f1=前半 2 層 / b1=後半 2 層）と強制部分集合での劣化
  命令単位・系列単位の有効率（0-1 損失）と最初の誤り位置

出力: data/q1/{arm}_s{seed}.json, data/q1/summary.csv, data/q1/q1_results.json
"""
import argparse
import csv
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, E2DIR)
from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS  # noqa: E402
import e2b_rewrite_routing_fixed as E2  # noqa: E402

E2.SEQ = 128          # 位置埋め込みを広げる（既定 95 では T=109 が入らない）

OUTDIR = os.path.join(E2DIR, "data", "q1")

# ---------------------------------------------------------------------------
# 語彙とタスク
# ---------------------------------------------------------------------------
DIG = "0123456789"
OPS = "ASD"
VOCAB = DIG + OPS + "=:"          # 15 文字（モデル側の埋め込みは 29 なので収まる）
C2I = {c: i for i, c in enumerate(VOCAB)}
ID_A, ID_S, ID_D = C2I["A"], C2I["S"], C2I["D"]
ID_EQ, ID_SEP = C2I["="], C2I[":"]

P_STEPS = 10
N_DIG = 8                              # 値は 0..10^8-1。8 桁の繰り上がりを 10 命令ぶん
TPI = 2 + N_DIG                        # 1 命令 = [op, '='] + 8 桁
MOD = 10 ** N_DIG
T_LEN = N_DIG + 1 + TPI * P_STEPS      # 109
TRACE0 = N_DIG + 1                     # 9

# 固定プログラム（op は位置で決まる = 構造トークンのエントロピーがゼロ）
FIXED_OPS = "ADADSDADAS"
assert len(FIXED_OPS) == P_STEPS

# 種別コード
TYP_INPUT, TYP_STRUCT, TYP_PAYLOAD = 0, 1, 2


def apply_op(v, op_code):
    """op_code: 0=A(+1) 1=S(-1) 2=D(x2)"""
    return np.where(op_code == 0, v + 1,
                    np.where(op_code == 1, v - 1, v * 2)) % MOD


def make_trace_batch(rng, n, p_steps=P_STEPS, task="compute"):
    """-> seq (n,T), typ (n,T)

    初期値は一様乱数（入力、損失なし）。
      task="compute": 固定プログラムを実行したトレース（値は繰り上がりを含む計算結果）
      task="copy"   : 各命令が初期値をそのまま繰り返す（レイアウト同一・計算なしの対照）
    op は位置で決まるので構造トークンはエントロピーゼロ。
    """
    T = N_DIG + 1 + TPI * p_steps
    v0 = rng.integers(0, MOD, size=n).astype(np.int64)
    v = v0.copy()
    seq = np.zeros((n, T), dtype=np.int64)
    typ = np.zeros((n, T), dtype=np.int64)

    for k in range(N_DIG):
        seq[:, k] = (v0 // (10 ** (N_DIG - 1 - k))) % 10
    seq[:, N_DIG] = ID_SEP

    for s in range(p_steps):
        base = N_DIG + 1 + TPI * s
        op = OPS.index(FIXED_OPS[s])
        seq[:, base] = op + ID_A
        typ[:, base] = TYP_STRUCT
        seq[:, base + 1] = ID_EQ
        typ[:, base + 1] = TYP_STRUCT
        if task == "compute":
            v = apply_op(v, op)
        else:
            v = v0
        for k in range(N_DIG):
            seq[:, base + 2 + k] = (v // (10 ** (N_DIG - 1 - k))) % 10
            typ[:, base + 2 + k] = TYP_PAYLOAD
    return seq, typ


# ---------------------------------------------------------------------------
# forward（k を層ごとに変えられる / 許可 expert を絞れる）
# ---------------------------------------------------------------------------
def forward_q1(model, idx, k_by_layer=None, allow=None, need_idx=False):
    p = model.p
    B, T = idx.shape
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    idx_l = []
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
        if allow is not None:
            mask = torch.full_like(logits, float("-inf"))
            mask[:, list(allow)] = 0.0
            logits = logits + mask
        kl = model.k if k_by_layer is None else k_by_layer[l]
        topv, topi = logits.topk(kl, dim=1)
        gate = torch.softmax(
            torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
        y = torch.zeros_like(h)
        for i in range(model.E):
            tok, _ = (topi == i).nonzero(as_tuple=True)
            if tok.numel() == 0:
                continue
            x = h[tok]
            h1 = F.relu(F.linear(x, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
            y.index_add_(0, tok,
                         F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                         * gate[tok, i].unsqueeze(1))
        h = h + y
        if need_idx:
            idx_l.append(topi.reshape(B, T, -1))
    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, -1)
    return out, idx_l


def trace_loss(logits, seq):
    # 位置 t の logits は t+1 を予測する。TRACE0 以降を当てるには t = TRACE0-1 .. T-2 を見る。
    lg = logits[:, TRACE0 - 1:-1, :len(VOCAB)].reshape(-1, len(VOCAB))
    tgt = torch.from_numpy(seq[:, TRACE0:]).reshape(-1)
    return F.cross_entropy(lg, tgt)


# ---------------------------------------------------------------------------
# 評価
# ---------------------------------------------------------------------------
SMALL = (0, 1)
LARGE = (6, 7)


@torch.no_grad()
def evaluate(model, seq, typ, conds, bs=128):
    n = seq.shape[0]
    dims = np.array(model.dims, dtype=np.float32)
    res = {}
    for cname, (kbl, allow) in conds.items():
        ce = np.zeros((n, T_LEN - TRACE0), dtype=np.float32)
        hit = np.zeros((n, T_LEN - TRACE0), dtype=bool)
        wid = np.zeros((n, T_LEN - TRACE0), dtype=np.float32)
        top1 = np.zeros((n, T_LEN - TRACE0), dtype=np.int64)
        wid_l = np.zeros((model.L, n, T_LEN - TRACE0), dtype=np.float32)
        top1_l = np.zeros((model.L, n, T_LEN - TRACE0), dtype=np.int64)
        for i in range(0, n, bs):
            s = slice(i, min(i + bs, n))
            x = torch.from_numpy(seq[s])
            logits, idx_l = forward_q1(model, x, k_by_layer=kbl, allow=allow, need_idx=True)
            lg = logits[:, TRACE0 - 1:-1, :len(VOCAB)]
            tgt = torch.from_numpy(seq[s, TRACE0:])
            lp = F.cross_entropy(lg.reshape(-1, len(VOCAB)), tgt.reshape(-1),
                                 reduction="none").reshape(-1, T_LEN - TRACE0)
            ce[s] = lp.numpy()
            hit[s] = (lg.argmax(-1).numpy() == tgt.numpy())
            for l, ti in enumerate(idx_l):
                # 位置 t のルーティングは t+1 のトークンを予測するときのもの → 種別も t+1 側に合わせる
                a = ti.numpy()[:, TRACE0 - 1:-1, :]
                wid_l[l][s] = dims[a].mean(-1)
                top1_l[l][s] = a[:, :, 0]
                wid[s] += dims[a].mean(-1) / model.L
                # top-1 は層ごとに別なので、最終層の top-1 を代表にしない（下で層別に集計）
            top1[s] = top1_l[-1][s]
        ty = typ[:, TRACE0:]
        m_st, m_pl = (ty == TYP_STRUCT), (ty == TYP_PAYLOAD)
        out = {
            "ce_all": float(ce.mean()),
            "ce_struct": float(ce[m_st].mean()),
            "ce_payload": float(ce[m_pl].mean()),
            "acc_struct": float(hit[m_st].mean()),
            "acc_payload": float(hit[m_pl].mean()),
            "width_struct": float(wid[m_st].mean()),
            "width_payload": float(wid[m_pl].mean()),
            "small_struct": float(np.isin(top1[m_st], SMALL).mean()),
            "small_payload": float(np.isin(top1[m_pl], SMALL).mean()),
            "width_struct_l": [float(wid_l[l][m_st].mean()) for l in range(model.L)],
            "width_payload_l": [float(wid_l[l][m_pl].mean()) for l in range(model.L)],
            "small_struct_l": [float(np.isin(top1_l[l][m_st], SMALL).mean())
                               for l in range(model.L)],
            "small_payload_l": [float(np.isin(top1_l[l][m_pl], SMALL).mean())
                                for l in range(model.L)],
            "usage_l0": np.bincount(top1_l[0].reshape(-1), minlength=model.E).tolist(),
        }
        # 0-1 損失: 命令単位 / 系列単位
        hp = hit.reshape(n, P_STEPS, TPI)[:, :, 2:]   # 1 命令 = [op, '='] + 3 桁
        instr_ok = hp.all(-1)                    # (n, steps)
        out["instr_valid"] = float(instr_ok.all(-1).mean())
        out["instr_acc"] = float(instr_ok.mean())
        out["payload_token_acc"] = float(hp.mean())
        first = np.where(~instr_ok, np.arange(P_STEPS)[None, :], 10 ** 6).min(-1)
        out["first_err_mean"] = float(np.where(first >= 10 ** 6, P_STEPS, first).mean())
        out["seq_valid"] = float((first >= 10 ** 6).mean())
        res[cname] = out
    return res


# ---------------------------------------------------------------------------
# 訓練
# ---------------------------------------------------------------------------
def run_arm(arm, seed, n_seqs, epochs, bs, lr, auxw, task="compute"):
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    widths = WIDTHS[arm]
    aux_mode = "p_pen" if arm.startswith("H") else "switch"
    model = RewriteMoE(widths, seed=seed)
    opt = Adam(model.params(), lr=lr)
    nparam = sum(v.numel() for v in model.params().values())

    steps_per_ep = max(1, n_seqs // bs)
    t0 = time.time()
    hist = []
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps_per_ep):
            seq, _ = make_trace_batch(rng, bs, task=task)
            x = torch.from_numpy(seq)
            logits, aux, _ = model(x, aux_mode=aux_mode)
            loss = trace_loss(logits, seq) + auxw * aux
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        hist.append(run / steps_per_ep)
        print(f"    [{arm} s{seed}] ep{ep+1}/{epochs} loss={hist[-1]:.4f} "
              f"({time.time()-t0:.0f}s)", flush=True)

    ev_rng = np.random.default_rng(777)
    seq, typ = make_trace_batch(ev_rng, 1024, task=task)
    conds = {
        "base": (None, None),
        "k1": ([1] * model.L, None),
        "f1": ([1, 1, 2, 2], None),
        "b1": ([2, 2, 1, 1], None),
        "force_small": (None, SMALL),
        "force_large": (None, LARGE),
    }
    ev = evaluate(model, seq, typ, conds)
    out = {"arm": arm, "seed": seed, "task": task, "nparam": nparam, "loss_hist": hist,
           "n_eval": 1024, "sec": round(time.time() - t0, 1), "eval": ev}
    os.makedirs(OUTDIR, exist_ok=True)
    torch.save({k: v.detach() for k, v in model.params().items()},
               os.path.join(OUTDIR, f"ckpt_{arm}_{task}_s{seed}.pt"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", nargs="+", default=["H+LB", "U+LB"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--auxw", type=float, default=0.05)
    ap.add_argument("--task", default="compute", choices=["compute", "copy"])
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()

    os.makedirs(OUTDIR, exist_ok=True)
    torch.set_num_threads(6)
    if args.smoke:
        args.arms, args.seeds = ["H+LB"], [0]

    print(f"T={T_LEN} (init {N_DIG} + sep 1 + trace {TPI*P_STEPS}), "
          f"d=128, L=4, E=8, k=2, prog={FIXED_OPS}", flush=True)
    print(f"seqs={args.seqs} epochs={args.epochs} bs={args.bs} arms={args.arms}", flush=True)

    rows = []
    for arm in args.arms:
        for seed in args.seeds:
            r = run_arm(arm, seed, args.seqs, args.epochs, args.bs, args.lr, args.auxw,
                        task=args.task)
            rows.append(r)
            e = r["eval"]["base"]
            print(f"  -> {arm} {args.task} s{seed}: acc st/pl = {e['acc_struct']:.3f}/{e['acc_payload']:.3f} "
                  f"width st/pl = {e['width_struct']:.1f}/{e['width_payload']:.1f} "
                  f"small st/pl = {e['small_struct']:.3f}/{e['small_payload']:.3f} "
                  f"instr_valid={e['instr_valid']:.3f}", flush=True)
            with open(os.path.join(OUTDIR, f"{arm}_{args.task}_s{seed}.json"), "w",
                      encoding="utf-8") as f:
                json.dump(r, f, ensure_ascii=False, indent=2)

    with open(os.path.join(OUTDIR, f"q1_results_{args.task}.json"), "w",
              encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)

    keys = ["arm", "seed", "ce_all", "ce_struct", "ce_payload", "acc_struct", "acc_payload",
            "width_struct", "width_payload", "small_struct", "small_payload",
            "instr_valid", "instr_acc", "payload_token_acc", "seq_valid", "nparam", "sec"]
    with open(os.path.join(OUTDIR, f"summary_{args.task}.csv"), "w", newline="",
              encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            row = {k: r[k] for k in ("arm", "seed", "nparam", "sec")}
            row.update({k: r["eval"]["base"][k] for k in keys if k in r["eval"]["base"]})
            w.writerow(row)
    print(f"[write] {OUTDIR}", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
