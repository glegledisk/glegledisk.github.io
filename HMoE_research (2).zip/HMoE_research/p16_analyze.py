# -*- coding: utf-8 -*-
"""P16 解析: 難度ラダーで P15 の較正結果が天井の産物かを判定する

P15 の clean プールは 37/40 正解で飽和していた。gap −0.0018 が
「較正が良い」のか「天井だから gap が出ない」のかは 1 水準では分からない。
3 水準（add5 / sub5 / mul2）で同じ規則を測り、正解率を動かして較正を見る。

規則・プールの定義は p15_analyze.py と同一（比較可能性のため）。
単位は (round, problem)。水準ごとに 2 ラウンド × 20 問 = 40 ペア。
出力: p16_analysis.json / p16_analysis_out_utf8.txt
"""

import json
import os
from collections import Counter

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
LEVELS = ["add5", "sub5", "mul2"]
OUT = []


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def auroc(scores, labels):
    s = np.asarray(scores, float)
    y = np.asarray(labels, bool)
    ok = np.isfinite(s)
    s, y = s[ok], y[ok]
    pos, neg = s[y], s[~y]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    d = (pos[:, None] > neg[None, :]).sum() + 0.5 * (pos[:, None] == neg[None, :]).sum()
    return float(d / (len(pos) * len(neg)))


def auroc_cluster(scores, labels, clusters, n_boot=2000, seed=0):
    s = np.asarray(scores, float)
    y = np.asarray(labels, bool)
    cl_in = list(clusters)
    ok = np.isfinite(s)
    s, y = s[ok], y[ok]
    cl = [cl_in[i] for i in np.where(ok)[0]]
    point = auroc(s, y)
    uniq = sorted(set(cl))
    idx_by = {}
    for k, c in enumerate(cl):
        idx_by.setdefault(c, []).append(k)
    idx_by = {c: np.array(v) for c, v in idx_by.items()}
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(n_boot):
        pick = [uniq[j] for j in rng.integers(0, len(uniq), len(uniq))]
        idx = np.concatenate([idx_by[c] for c in pick])
        v = auroc(s[idx], y[idx])
        if np.isfinite(v):
            vals.append(v)
    if not vals:
        return point, (float("nan"), float("nan"))
    return point, (float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5)))


def paired(arr):
    a = np.asarray(arr, float)
    a = a[np.isfinite(a)]
    mean = float(np.mean(a))
    sd = float(np.std(a, ddof=1))
    se = sd / np.sqrt(len(a))
    if sd > 0:
        t, p = stats.ttest_1samp(a, 0.0)
        mde = float(2.802 * sd / np.sqrt(len(a)))
    else:
        t, p, mde = float("nan"), float("nan"), float("nan")
    return {"mean": mean, "se": float(se), "t": float(t), "p": float(p),
            "n": int(len(a)), "mde80": mde}


POOLS = {"all": lambda s: True,
         "clean": lambda s: s["ntok"] < 96,
         # 代替規則: 打ち切りではなく「解答 span が短すぎる」で切る。
         # 難課題では打ち切られても答えを書いている場合があるため（mul2 で 35.5%）。
         "nans3": lambda s: s["n_ans"] >= 3}


def pick(sub, pool, key):
    cand = [(j, s) for j, s in enumerate(sub)
            if s[key] is not None and s["pred"] is not None and pool(s)]
    if not cand:
        return None
    return max(cand, key=lambda t: (t[1][key], -t[0]))[1]


def maj(sub, pool, nominal_n):
    cand = [s for s in sub if s["pred"] is not None and pool(s)]
    if not cand:
        return None
    by = {}
    for s in cand:
        by.setdefault(s["pred"], []).append(s)
    best = None
    for pred, lst in by.items():
        k = (len(lst), max(x["p_ans"] for x in lst))
        if best is None or k > best[0]:
            best = (k, pred, lst)
    _, pred, lst = best
    rep = max(lst, key=lambda s: s["p_ans"])
    return {"pred": pred, "share_pool": len(lst) / float(len(cand)),
            "share_nominal": len(lst) / float(nominal_n), "rep_conf": rep["p_ans"]}


def main():
    with open(os.path.join(HERE, "p16_difficulty.jsonl"), encoding="utf-8") as fp:
        rows = [json.loads(l) for l in fp if l.strip()]
    recs = [r for r in rows if r.get("round") != "greedy"]
    greedy = [r for r in rows if r.get("round") == "greedy"]
    log("recs=%d greedy=%d" % (len(recs), len(greedy)))

    sl = [g["slack"] for g in greedy if g.get("slack") is not None]
    log("greedy argmax-slack: mean=%.6f max=%.6f n=%d"
        % (float(np.mean(sl)), float(np.max(sl)), len(sl)))
    assert float(np.mean(sl)) < 0.05, "scoring convention suspect"

    summary = {"levels": {}, "slack": {"mean": float(np.mean(sl)), "max": float(np.max(sl))}}

    for lv in LEVELS:
        rlv = [r for r in recs if r["level"] == lv]
        rounds = sorted(set(r["round"] for r in rlv))
        P = len([r for r in rlv if r["round"] == rounds[0]])
        assert len(rlv) == len(rounds) * P, (lv, len(rlv))
        by_round = {ri: [r for r in rlv if r["round"] == ri] for ri in rounds}
        pairs = [(ri, by_round[ri][i]) for ri in rounds for i in range(P)]

        S = [s for r in rlv for s in r["samples"]]
        trunc = np.array([s["ntok"] >= 96 for s in S])
        corr = np.array([bool(s["correct"]) for s in S])
        log("\n=== %s ===  samples=%d  truncated=%d (%.3f)  acc=%.4f"
            % (lv, len(S), int(trunc.sum()), trunc.mean(), corr.mean()))
        log("  acc truncated=%.4f (n=%d) / complete=%.4f (n=%d)"
            % (corr[trunc].mean() if trunc.sum() else float("nan"), int(trunc.sum()),
               corr[~trunc].mean() if (~trunc).sum() else float("nan"), int((~trunc).sum())))

        rng = np.random.default_rng(7)
        cells = {}
        dropped = {p: 0 for p in POOLS}
        used = {p: [] for p in POOLS}
        for ri, r in pairs:
            sub, gold = r["samples"], r["gold"]
            s1 = sub[0]
            for pool_name, pool in POOLS.items():
                cand = [x for x in sub if pool(x) and x["pred"] is not None]
                if not cand:
                    # このプールではペアごと落とす（s1 / oracle も入れない → 長さが揃う）
                    dropped[pool_name] += 1
                    continue
                used[pool_name].append((ri, r["q"]))
                cells.setdefault((pool_name, "s1"), []).append(
                    (float(s1["pred"] == gold), s1["p_ans"]))
                cells.setdefault((pool_name, "oracle"), []).append(
                    (float(any(x["correct"] for x in sub)), np.nan))
                idx = rng.integers(0, len(cand), 200)
                cells.setdefault((pool_name, "rand"), []).append(
                    (float(np.mean([float(cand[k]["pred"] == gold) for k in idx])),
                     float(np.mean([cand[k]["p_ans"] for k in idx]))))
                cm = pick(sub, pool, "p_ans")
                cells.setdefault((pool_name, "confmax"), []).append(
                    (float(cm["pred"] == gold), cm["p_ans"]))
                cf = pick(sub, pool, "p_full")
                cells.setdefault((pool_name, "confmaxF"), []).append(
                    (float(cf["pred"] == gold), cf["p_full"]))
                mj = maj(sub, pool, 8)
                cells.setdefault((pool_name, "maj"), []).append(
                    (float(mj["pred"] == gold), mj["share_pool"]))
                cells.setdefault((pool_name, "majnom"), []).append(
                    (float(mj["pred"] == gold), mj["share_nominal"]))
                cells.setdefault((pool_name, "majrep"), []).append(
                    (float(mj["pred"] == gold), mj["rep_conf"]))

        lvsum = {"n_pairs": len(pairs), "trunc_rate": float(trunc.mean()),
                 "acc_sample": float(corr.mean()), "dropped_empty_pool": dropped,
                 "table": [], "tests": [], "aurocs": []}
        log("  dropped pairs (empty pool): %s" % dropped)
        for pool_name in POOLS:
            for rule in ["s1", "rand", "confmax", "confmaxF", "maj", "majnom",
                         "majrep", "oracle"]:
                if (pool_name, rule) not in cells:
                    continue
                a = np.array([x[0] for x in cells[(pool_name, rule)]], float)
                c = np.array([x[1] for x in cells[(pool_name, rule)]], float)
                row = {"pool": pool_name, "rule": rule, "n": len(a),
                       "acc": float(np.mean(a)), "conf": None, "gap": None}
                if np.all(np.isfinite(c)):
                    row["conf"] = float(np.mean(c))
                    row["gap"] = row["conf"] - row["acc"]
                lvsum["table"].append(row)
                log("  %-5s %-9s acc=%.4f conf=%s gap=%s"
                    % (pool_name, rule, row["acc"],
                       "   -  " if row["conf"] is None else "%.4f" % row["conf"],
                       "   -  " if row["gap"] is None else "%+.4f" % row["gap"]))

        for pool_name in POOLS:
            for rule in ["confmax", "confmaxF", "maj", "majnom", "majrep"]:
                if (pool_name, rule) not in cells:
                    continue
                a1 = np.array([x[0] for x in cells[(pool_name, "s1")]], float)
                c1 = np.array([x[1] for x in cells[(pool_name, "s1")]], float)
                a2 = np.array([x[0] for x in cells[(pool_name, rule)]], float)
                c2 = np.array([x[1] for x in cells[(pool_name, rule)]], float)
                w10 = int(np.sum(a2.astype(bool) & ~a1.astype(bool)))
                w01 = int(np.sum(~a2.astype(bool) & a1.astype(bool)))
                pmc = (float(stats.binomtest(w10, w10 + w01, 0.5).pvalue)
                       if (w10 + w01) > 0 else float("nan"))
                t_ = {"name": "%s/%s - s1" % (pool_name, rule),
                      "conf": paired(c2 - c1), "acc": paired(a2 - a1),
                      "gap": paired((c2 - c1) - (a2 - a1)),
                      "mcnemar": {"w_rule": w10, "w_base": w01, "p": pmc}}
                assert abs(t_["gap"]["mean"] - (t_["conf"]["mean"] - t_["acc"]["mean"])) < 1e-9
                lvsum["tests"].append(t_)
        for t_ in lvsum["tests"]:
            log("  %-22s dAcc=%+.4f(t=%+.2f,p=%.3g,McN %d/%d p=%.3g) dGap=%+.4f(t=%+.2f,p=%.3g)"
                % (t_["name"], t_["acc"]["mean"], t_["acc"]["t"],
                   t_["acc"]["p"], t_["mcnemar"]["w_rule"], t_["mcnemar"]["w_base"],
                   t_["mcnemar"]["p"], t_["gap"]["mean"], t_["gap"]["t"], t_["gap"]["p"]))

        cl_all = [(ri, i) for ri in rounds for i in range(P)]
        for pool_name in POOLS:
            for rule in ["maj", "confmax", "confmaxF"]:
                if (pool_name, rule) not in cells:
                    continue
                a = [x[0] for x in cells[(pool_name, rule)]]
                c = [x[1] for x in cells[(pool_name, rule)]]
                cl = used[pool_name]
                assert len(cl) == len(a), (pool_name, rule, len(cl), len(a))
                pt, (lo, hi) = auroc_cluster(c, a, cl)
                lvsum["aurocs"].append({"pool": pool_name, "rule": rule, "auc": pt,
                                        "ci": [lo, hi], "pos": int(sum(a)), "n": len(a)})
                log("  AUC %-5s %-9s = %.3f [%.3f, %.3f]  (pos %d/%d)"
                    % (pool_name, rule, pt, lo, hi, int(sum(a)), len(a)))
        summary["levels"][lv] = lvsum

    # ---- 水準をまたぐ較正の要約 ----
    log("\n[summary] clean pool: acc / share_pool / gap  by level")
    log("  %-6s %8s %10s %8s %10s %8s" %
        ("level", "acc", "share", "gap", "gap_nominal", "trunc"))
    for lv in LEVELS:
        tb = {(r["pool"], r["rule"]): r for r in summary["levels"][lv]["table"]}
        m = tb.get(("clean", "maj"))
        mn = tb.get(("clean", "majnom"))
        if m is None:
            continue
        log("  %-6s %8.4f %10.4f %+8.4f %10s %8.3f"
            % (lv, m["acc"], m["conf"], m["gap"],
               "-" if mn is None or mn["gap"] is None else "%+.4f" % mn["gap"],
               summary["levels"][lv]["trunc_rate"]))
        summary["levels"][lv]["calibration"] = {"acc": m["acc"], "share": m["conf"],
                                                "gap": m["gap"],
                                                "gap_nominal": None if mn is None else mn["gap"]}

    # ---- 対応のある比較: clean プールが空でないペアだけで all と clean を比べる ----
    # mul2 は 10/40 ペアで clean が空 → 40 ペアの all と 30 ペアの clean を
    # そのまま比べると交絡する。ここで揃える。
    log("\n[matched] all vs clean on the SAME pairs (clean pool non-empty)")
    log("  %-6s %5s %8s %8s %8s %8s %8s %8s %8s %8s"
        % ("level", "n", "s1", "cm_all", "cm_cln", "cm_n3", "mj_all", "mj_cln",
           "oracl_cl", "oracl_al"))
    for lv in LEVELS:
        rlv = [r for r in recs if r["level"] == lv]
        rounds = sorted(set(r["round"] for r in rlv))
        by_round = {ri: [r for r in rlv if r["round"] == ri] for ri in rounds}
        P = len(by_round[rounds[0]])
        acc = {"s1": [], "cm_all": [], "cm_cln": [], "cm_n3": [], "mj_all": [],
               "mj_cln": [], "oracle": [], "oracle_all": [], "oracle_n3": [],
               "cf_cln": []}
        agree = {"cf_cln_mj_cln": 0, "cf_all_mj_all": 0, "n": 0}
        for ri in rounds:
            for i in range(P):
                r = by_round[ri][i]
                sub, gold = r["samples"], r["gold"]
                if not (any(POOLS["clean"](s) for s in sub)
                        and any(POOLS["nans3"](s) for s in sub)):
                    continue
                acc["s1"].append(float(sub[0]["pred"] == gold))
                a = pick(sub, POOLS["all"], "p_ans")
                b = pick(sub, POOLS["clean"], "p_ans")
                e = pick(sub, POOLS["nans3"], "p_ans")
                c = pick(sub, POOLS["all"], "p_full")
                d = pick(sub, POOLS["clean"], "p_full")
                ma = maj(sub, POOLS["all"], 8)
                mb = maj(sub, POOLS["clean"], 8)
                acc["cm_all"].append(float(a["pred"] == gold))
                acc["cm_cln"].append(float(b["pred"] == gold))
                acc["cm_n3"].append(float(e["pred"] == gold))
                acc["cf_cln"].append(float(d["pred"] == gold))
                acc["mj_all"].append(float(ma["pred"] == gold))
                acc["mj_cln"].append(float(mb["pred"] == gold))
                acc["oracle"].append(float(any(x["correct"] for x in sub
                                               if POOLS["clean"](x))))
                acc["oracle_n3"].append(float(any(x["correct"] for x in sub
                                                  if POOLS["nans3"](x))))
                acc["oracle_all"].append(float(any(x["correct"] for x in sub)))
                agree["n"] += 1
                agree["cf_cln_mj_cln"] += int(d["pred"] == mb["pred"])
                agree["cf_all_mj_all"] += int(c["pred"] == ma["pred"])
        n = len(acc["s1"])
        log("  %-6s %5d %8.4f %8.4f %8.4f %8.4f %8.4f %8.4f %8.4f %8.4f"
            % (lv, n, np.mean(acc["s1"]), np.mean(acc["cm_all"]), np.mean(acc["cm_cln"]),
               np.mean(acc["cm_n3"]), np.mean(acc["mj_all"]), np.mean(acc["mj_cln"]),
               np.mean(acc["oracle"]), np.mean(acc["oracle_all"])))
        log("         oracle(n_ans>=3) on same pairs = %.4f" % np.mean(acc["oracle_n3"]))
        log("         agreement: p_full(clean)==maj(clean) %d/%d, p_full(all)==maj(all) %d/%d"
            % (agree["cf_cln_mj_cln"], agree["n"], agree["cf_all_mj_all"], agree["n"]))
        summary["levels"][lv]["matched"] = {
            "n": n,
            "s1": float(np.mean(acc["s1"])),
            "confmax_all": float(np.mean(acc["cm_all"])),
            "confmax_clean": float(np.mean(acc["cm_cln"])),
            "confmax_nans3": float(np.mean(acc["cm_n3"])),
            "oracle_nans3": float(np.mean(acc["oracle_n3"])),
            "confmaxF_clean": float(np.mean(acc["cf_cln"])),
            "maj_all": float(np.mean(acc["mj_all"])),
            "maj_clean": float(np.mean(acc["mj_cln"])),
            "oracle_clean": float(np.mean(acc["oracle"])),
            "oracle_all": float(np.mean(acc["oracle_all"])),
            "agree_pfull_maj_clean": agree["cf_cln_mj_cln"],
            "agree_pfull_maj_all": agree["cf_all_mj_all"]}

    with open(os.path.join(HERE, "p16_analysis.json"), "w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    with open(os.path.join(HERE, "p16_analysis_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    log("saved: p16_analysis.json")
    os._exit(0)


if __name__ == "__main__":
    main()
