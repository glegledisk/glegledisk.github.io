#!/usr/bin/env python3
"""K1e の異常 ckpt（s3 生徒, CE 1.6069）が「終盤スパイク」か「悪い盆地」かを切り分ける。

方法
  壊れた ckpt から同じ条件で 2 epoch だけ訓練を続け、評価 CE の軌跡を見る。
  - 1 epoch で 0.35 前後に戻る → **一過性スパイク**（重みは壊れたが回復可能）
  - 戻らない → **悪い盆地**（その run は失敗として扱うべき）

  ckpt は epoch 16 の最終重みのみ保存しているので、中間の軌跡は見られない。
  継続訓練がその代わりになる（同じ学習率・同じデータ生成）。

出力: k1e_spike_out_utf8.txt
"""
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from p13c_retrain import (  # noqa: E402
    E2DIR, Adam, make_batch, to_seq, out_loss, forward_forced, RewriteMoE, SL, OL, V,
)

OUT = os.path.join(HERE, "k1e_spike_out_utf8.txt")
lines = []


def p(s=""):
    print(s, flush=True)
    lines.append(s)


def load(widths, seed, path, topk):
    m = RewriteMoE(widths, seed=seed, topk=topk)
    sd = torch.load(path, map_location="cpu")
    for k, v in sd.items():
        with torch.no_grad():
            m.p[k].copy_(v)
    return m


@torch.no_grad()
def ce(model, src, out, k=1, bs=128):
    tot = []
    for i in range(0, src.shape[0], bs):
        s = slice(i, min(i + bs, src.shape[0]))
        x = to_seq(src[s], out[s])
        logits, _ = forward_forced(model, x, force=None, k=k)
        lg = logits[:, SL:SL + OL, :]
        tgt = torch.from_numpy(out[s])
        tot.append(F.cross_entropy(lg.reshape(-1, V), tgt.reshape(-1),
                                   reduction="none").numpy())
    return float(np.concatenate(tot).mean())


def main():
    torch.set_num_threads(1)
    ev = np.random.default_rng(777)
    src, out, em, ks = make_batch(ev, 2048)
    d = os.path.join(E2DIR, "data", "k1")
    path = os.path.join(d, "ckpt_dense161_s3_e16.pt")

    torch.manual_seed(3)
    m = load([161], 3, path, 1)
    p("s3 生徒（16 epoch の最終 ckpt）から継続訓練")
    p("  開始時 CE %.4f（記録 1.6069）" % ce(m, src, out))
    opt = Adam(m.params(), lr=2e-3)
    rng = np.random.default_rng(1000 + 3)
    for ep in range(2):
        run = 0.0
        for _ in range(3000 // 32):
            s, o, e, _ = make_batch(rng, 32)
            x = to_seq(s, o)
            logits, _, _ = m(x, aux_mode="none")
            loss = out_loss(logits, o)
            loss.backward()
            opt.step(m.params())
            run += float(loss.detach())
        c = ce(m, src, out)
        p("  +%d epoch: 学習損失 %.4f  評価 CE %.4f" % (ep + 1, run / (3000 // 32), c))

    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n[write] %s" % OUT)


if __name__ == "__main__":
    main()
