"""並列チャンク・ダウンローダ（HF の単一接続が遅い環境向け）。

- 1 ファイルを複数スレッドで範囲分割ダウンロードし、オフセット指定で直接書き込む
  （チャンクファイルを作らないので後片付け不要・サンドボックスの削除制約も回避）
- 既存ファイルはバイト単位でレジュームする

使い方:
  python _dl_parallel.py <repo_id> <out_dir> [--threads 8] [--chunk-mb 32]
"""
import argparse
import os
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE = "https://huggingface.co"


def _write_at(fd, data, offset):
    os.lseek(fd, offset, os.SEEK_SET)
    n = 0
    while n < len(data):
        n += os.write(fd, data[n:])
    return n


def fetch_to(url, start, end, path):
    want = end - start + 1
    req = urllib.request.Request(url, headers={"Range": "bytes=%d-%d" % (start, end)})
    fd = os.open(path, os.O_RDWR | os.O_CREAT)
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            off = start
            remaining = want
            while remaining > 0:
                b = r.read(min(1 << 20, remaining))
                if not b:
                    break
                off += _write_at(fd, b, off)
                remaining -= len(b)
        if off - start != want:
            raise IOError("short/over read for %s [%d,%d]: got %d want %d"
                          % (os.path.basename(path), start, end, off - start, want))
        return off - start, want
    finally:
        os.close(fd)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("repo")
    ap.add_argument("outdir")
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--chunk-mb", type=int, default=32)
    ap.add_argument("--files", nargs="*", default=None)
    ap.add_argument("--force", action="store_true", help="既存ファイルを無視して最初から取り直す")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    from huggingface_hub import HfApi
    api = HfApi()
    info = api.model_info(args.repo, files_metadata=True)
    targets = []
    for s in info.siblings:
        if s.rfilename.endswith((".gitattributes", ".md", ".png", ".jpg")):
            continue
        if args.files and s.rfilename not in args.files:
            continue
        if s.size:
            targets.append((s.rfilename, s.size))
    if not targets:
        print("no files to download", file=sys.stderr)
        return 1

    done_bytes = 0
    total_bytes = sum(sz for _, sz in targets)
    print("total %.2f GB" % (total_bytes / 1024 ** 3), flush=True)
    t0 = time.time()
    import hashlib
    for fname, size in targets:
        out = os.path.join(args.outdir, fname)
        url = "%s/%s/resolve/main/%s" % (BASE, args.repo, fname)
        cur = os.path.getsize(out) if os.path.exists(out) else 0
        if args.force:
            cur = 0
        if cur > size:
            # 長すぎる場合は期待サイズに切り詰める（safetensors はファイルサイズを検証する）
            with open(out, "r+b") as fp:
                fp.truncate(size)
            cur = size
            print("  truncated %s to %d" % (fname, size), flush=True)
        have = cur
        chunk = args.chunk_mb * 1024 * 1024
        ranges = [(s, min(s + chunk - 1, size - 1)) for s in range(0, size, chunk) if s >= have]
        got = 0
        if ranges:
            with ThreadPoolExecutor(args.threads) as ex:
                futs = [ex.submit(fetch_to, url, s, e, out) for (s, e) in ranges]
                for f in as_completed(futs):
                    n, want = f.result()
                    if n != want:
                        print("SHORT %s %d/%d" % (fname, n, want), file=sys.stderr, flush=True)
                        return 1
                    got += n
        done_bytes += have + got
        el = time.time() - t0
        print("  %-42s %6.2f GB  (total %5.1f%%, %4.1f MB/s)"
              % (fname, size / 1024 ** 3, 100.0 * done_bytes / total_bytes,
                 (done_bytes - sum(s for _, s in targets[:targets.index((fname, size))])) / 1e6 / max(el, 1e-6)),
              flush=True)
        if os.path.getsize(out) != size:
            print("SIZE MISMATCH %s %d != %d" % (fname, os.path.getsize(out), size), file=sys.stderr)
            return 1
        # sha256 検証（API メタデータの LFS ハッシュと比較）
        exp = None
        for s in info.siblings:
            if s.rfilename == fname:
                exp = (s.lfs or {}).get("sha256") or getattr(s, "sha256", None)
        if exp:
            h = hashlib.sha256()
            with open(out, "rb") as fp:
                while True:
                    b = fp.read(1 << 22)
                    if not b:
                        break
                    h.update(b)
            got = h.hexdigest()
            print("      sha256 %s (%s)" % ("OK" if got == exp else "MISMATCH " + got[:16] + " != " + exp[:16], fname), flush=True)
            if got != exp:
                return 1
    print("DONE %s" % args.outdir, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
