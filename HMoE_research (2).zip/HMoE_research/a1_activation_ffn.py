#!/usr/bin/env python3
"""A1: 仮説「活性化の形は効かない、幅だけが効く」の検定。

背景: `考察_HMoEに最適な活性化関数_20261101.md` §6-2 の Step 1 / Step 2 を 1 本にまとめた。
Q1 のトレース課題（8 桁 × 10 命令、T=109）と E2b の RewriteMoE をそのまま使い、
**expert の FFN の活性化だけ**を差し替える。

設計（7+1 アーム）— 幅・パラメータ・形を分離する
  arm            act     幅倍率  行列   params  MACs   何を分離するか
  relu           relu    1.0     2     1.00    1.00   ベースライン（既存ハーネスと同一）
  silu           silu    1.0     2     1.00    1.00   形だけ（等パラメータ・等幅）
  relu2          relu2   1.0     2     1.00    1.00   形だけ（等パラメータ・等幅）
  swiglu         swiglu  1.0     3     1.50    1.50   行列数（形＋params）
  drelu          drelu   1.0     3     1.50    1.50   形だけ（等パラメータ・等幅、GLU 内）
  relu_w15       relu    1.5     2     1.50    1.50   幅（形は同じ）
  relu2_w15      relu2   1.5     2     1.50    1.50   幅＋形（swiglu と等 params/MACs）
  relu2_raw      relu2   1.0     2     1.00    1.00   質量の効果（gain 補正なし）

3 つの分解
  (a) 形: relu / silu / relu2 は **params も幅も完全に同一**。差が出なければ形は無効。
  (b) params か幅か: swiglu(幅 1.0, 1.5 倍 params) vs relu_w15(幅 1.5, 1.5 倍 params)
      → 幅が効くなら relu_w15 > swiglu、params だけなら両者同等。
  (c) 実務の交換: swiglu(w) vs relu2_w15(1.5w) は等 params・等 MACs。どちらが上か。

質量の統制
  アームごとに**初期化時の分岐 RMS を実測**し、relu 基準に揃える gain を掛ける
  （`--mass matched` が既定）。`relu2_raw` だけ gain=1 で、質量を動かしたときの効果を測る。
  gain は Adam の per-parameter 正規化に対してほぼ中立なので、「分岐の音量」だけを揃える介入になる。

出力: data/a1/{arm}_s{seed}.json, ce_{arm}_s{seed}.npy, a1_results.json, a1_summary.csv
"""
import argparse
import csv
import json
import math
import os
import sys
import time
import traceback

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
for _p in (HERE, E2DIR):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import e2b_rewrite_routing_fixed as E2                      # noqa: E402
from e2b_rewrite_routing_fixed import Adam                  # noqa: E402
import q1_trace_routing as Q1                               # noqa: E402  (E2.SEQ=128 を設定する)

OUTDIR = os.path.join(HERE, "data", "a1")

# ---------------------------------------------------------------------------
# アーム定義
# ---------------------------------------------------------------------------
BASE_W = (32, 32, 96, 96, 160, 160, 224, 224)      # Q1 / E2b の H+LB と同一
W15 = tuple(int(round(w * 1.5)) for w in BASE_W)   # 48/48/144/144/240/240/336/336
W067 = tuple(int(round(w * 2 / 3)) for w in BASE_W)  # 21/21/64/64/107/107/149/149

GATED = ("swiglu", "drelu")

ARMS = {
    "relu":      dict(act="relu",   widths=BASE_W, gain="matched"),
    "silu":      dict(act="silu",   widths=BASE_W, gain="matched"),
    "relu2":     dict(act="relu2",  widths=BASE_W, gain="matched"),
    "swiglu":    dict(act="swiglu", widths=BASE_W, gain="matched"),
    "drelu":     dict(act="drelu",  widths=BASE_W, gain="matched"),
    "relu_w15":  dict(act="relu",   widths=W15,    gain="matched"),
    "relu2_w15": dict(act="relu2",  widths=W15,    gain="matched"),
    "relu2_raw": dict(act="relu2",  widths=BASE_W, gain="none"),
    # --- gain 交絡を切る対照（raw = 初期化スケールそのまま）と、幅を削る方向の対照 ---
    "silu_raw":   dict(act="silu",   widths=BASE_W, gain="none"),
    "swiglu_raw": dict(act="swiglu", widths=BASE_W, gain="none"),
    "relu_w067":  dict(act="relu",   widths=W067,   gain="matched"),
}

NMAT = {"relu": 2, "silu": 2, "relu2": 2, "swiglu": 3, "drelu": 3}


# ---------------------------------------------------------------------------
# モデル: RewriteMoE の expert FFN だけを差し替える
# ---------------------------------------------------------------------------
class ActMoE(E2.RewriteMoE):
    def __init__(self, widths, act="relu", seed=0, router="sm", norm=True, act_i=None):
        super().__init__(widths, seed=seed)
        self.act = act
        self.act_i = act_i            # None なら全 expert が self.act。リストなら expert ごと
        self.gain = 1.0
        self.gain_l = {}              # dict[(l,i)] -> float。(l,i) が無ければ self.gain
        self.rms_log = None           # 校正用: dict[(l,i)] -> (sum of out^2, count)
        self.router = router          # "sm" = softmax / "sig" = sigmoid
        self.norm = norm              # top-k 内で再正規化するか
        self.mass_log = None          # 評価時にゲート質量を貯める
        self.collect = None           # dict[(l,i)] -> list of (w,) zero-fraction
        gated = any(a in GATED for a in (act_i if act_i is not None else [act]))
        if gated:
            g = torch.Generator().manual_seed(seed * 1000 + 7)
            for l in range(self.L):
                for i, w in enumerate(widths):
                    for nm, shape, sc in ((f"l{l}.e{i}.wg", (w, self.d), 1.0 / math.sqrt(self.d)),
                                          (f"l{l}.e{i}.bg", (w,), 1.0 / math.sqrt(self.d))):
                        t = torch.empty(shape)
                        with torch.no_grad():
                            t.normal_(0.0, sc, generator=g)
                        t.requires_grad_(True)
                        self.p[nm] = t

    def ffn(self, l, i, x):
        p = self.p
        act = self.act if self.act_i is None else self.act_i[i]
        z = F.linear(x, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"])
        if act == "relu":
            h = F.relu(z)
        elif act == "relu2":
            h = F.relu(z).pow(2)
        elif act == "silu":
            h = z * torch.sigmoid(z)
        elif act == "swiglu":
            g = F.linear(x, p[f"l{l}.e{i}.wg"], p[f"l{l}.e{i}.bg"])
            h = (g * torch.sigmoid(g)) * z
        elif act == "drelu":
            g = F.linear(x, p[f"l{l}.e{i}.wg"], p[f"l{l}.e{i}.bg"])
            h = F.relu(g) * F.relu(z)
        else:
            raise ValueError(act)
        if self.collect is not None:
            self.collect.setdefault((l, i), []).append((h == 0).float().mean(0).detach())
        out = F.linear(h * self.gain_l.get((l, i), self.gain),
                       p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
        if self.rms_log is not None:
            s, c = self.rms_log.get((l, i), (0.0, 0))
            self.rms_log[(l, i)] = (s + float(out.pow(2).sum()), c + out.numel())
        return out

    def gate_of(self, logits, topv, topi):
        """ルータの 4 変種。(softmax|sigmoid) × (top-k 正規化 on|off)。

        選択（topi）はここに入る前の topk で決まるので、**4 変種で同一**。
        変わるのは重みと、その総和（＝質量）だけ。
        """
        if self.router == "sm":
            if self.norm:
                g = torch.softmax(
                    torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
            else:
                p = torch.softmax(logits, dim=1)
                g = torch.zeros_like(p).scatter(1, topi, p.gather(1, topi))
        else:
            s = torch.sigmoid(topv)
            if self.norm:
                s = s / s.sum(1, keepdim=True)
            g = torch.zeros_like(logits).scatter(1, topi, s)
        if self.mass_log is not None:
            self.mass_log.append(g.sum(1).detach())
        return g

    def forward(self, idx, aux_mode="p_pen", need_idx=False, need_hiddens=False):
        # RewriteMoE.__call__ は W5b 以降 need_hiddens を常に forward へ渡す。
        # ActMoE は 3 値 (out, aux, idxs) 返却のままなので True は受け付けない。
        # 返り値の形を変えない最小修正（A4 / A4b / QA1 の全呼び出しが 3 値を期待）。
        assert not need_hiddens, "ActMoE.forward does not support need_hiddens (3-tuple return)"
        p = self.p
        B, T = idx.shape
        h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
        h = h.reshape(B * T, -1)
        aux_sum = torch.zeros(())
        idxs = [] if need_idx else None
        causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
        dims = torch.tensor(self.dims, dtype=torch.float32)
        for l in range(self.L):
            hb = h.reshape(B, T, -1)
            q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, self.nh, self.dh).transpose(1, 2)
            kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, self.nh, self.dh).transpose(1, 2)
            v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, self.nh, self.dh).transpose(1, 2)
            att = (q @ kk.transpose(-1, -2)) / math.sqrt(self.dh)
            att = att.masked_fill(causal, float("-inf")).softmax(-1)
            o = (att @ v).transpose(1, 2).reshape(B, T, -1)
            h = (hb + F.linear(o, p[f"l{l}.o.w"])).reshape(B * T, -1)

            logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
            topv, topi = logits.topk(self.k, dim=1)
            gate = self.gate_of(logits, topv, topi)
            y = torch.zeros_like(h)
            for i in range(self.E):
                tok, _ = (topi == i).nonzero(as_tuple=True)
                if tok.numel() == 0:
                    continue
                y.index_add_(0, tok, self.ffn(l, i, h[tok]) * gate[tok, i].unsqueeze(1))
            top1 = topi[:, 0]
            f = torch.zeros(self.E)
            f.scatter_add_(0, top1, torch.ones_like(top1, dtype=f.dtype))
            f = f / h.shape[0]
            P = torch.softmax(logits, dim=1).mean(0)
            if aux_mode == "switch":
                aux = self.E * (f * P).sum()
            elif aux_mode == "p_pen":
                aux = self.E * (f * P * (dims / dims.mean())).sum()
            else:
                aux = torch.zeros(())
            h = h + y
            aux_sum = aux_sum + aux
            if need_idx:
                idxs.append(topi.reshape(B, T, self.k))
        out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, -1)
        return out, aux_sum / self.L, idxs


@torch.no_grad()
def branch_rms(model, seq, bs=128):
    """初期化時の分岐出力 y の RMS（層平均）。gain の校正に使う。"""
    acc, n = 0.0, 0
    for i in range(0, seq.shape[0], bs):
        x = torch.from_numpy(seq[i:i + bs])
        acc += _branch_sq(model, x)
        n += 1
    return math.sqrt(acc / max(n, 1))


@torch.no_grad()
def per_expert_rms(model, seq, bs=128):
    """(l, i) ごとの分岐出力 RMS。expert ごとの gain 校正に使う（gain は 1 にして測る）。"""
    model.rms_log = {}
    for i in range(0, seq.shape[0], bs):
        model(torch.from_numpy(seq[i:i + bs]), aux_mode="none")
    log, model.rms_log = model.rms_log, None
    return {k: math.sqrt(s / max(c, 1)) for k, (s, c) in log.items()}


@torch.no_grad()
def _branch_sq(model, x):
    """1 バッチ分の分岐出力の二乗平均（全層・全トークン）。"""
    p = model.p
    B, T = x.shape
    h = p["emb.w"][x] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    tot, cnt = 0.0, 0
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = (hb + F.linear(o, p[f"l{l}.o.w"])).reshape(B * T, -1)
        logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
        topv, topi = logits.topk(model.k, dim=1)
        gate = torch.softmax(
            torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
        y = torch.zeros_like(h)
        for i in range(model.E):
            tok, _ = (topi == i).nonzero(as_tuple=True)
            if tok.numel() == 0:
                continue
            y.index_add_(0, tok, model.ffn(l, i, h[tok]) * gate[tok, i].unsqueeze(1))
        tot += float(y.pow(2).mean())
        cnt += 1
        h = h + y
    return tot / max(cnt, 1)


# ---------------------------------------------------------------------------
# 評価（per-token CE を返す）
# ---------------------------------------------------------------------------
@torch.no_grad()
def evaluate(model, seq, typ, bs=128):
    n = seq.shape[0]
    W = Q1.T_LEN - Q1.TRACE0
    ce = np.zeros((n, W), dtype=np.float32)
    hit = np.zeros((n, W), dtype=bool)
    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = torch.from_numpy(seq[s])
        logits, _, _ = model(x, aux_mode="none")
        lg = logits[:, Q1.TRACE0 - 1:-1, :len(Q1.VOCAB)]
        tgt = torch.from_numpy(seq[s, Q1.TRACE0:])
        ce[s] = F.cross_entropy(lg.reshape(-1, len(Q1.VOCAB)), tgt.reshape(-1),
                                reduction="none").reshape(-1, W).numpy()
        hit[s] = (lg.argmax(-1).numpy() == tgt.numpy())
    ty = typ[:, Q1.TRACE0:]
    m_st, m_pl = (ty == Q1.TYP_STRUCT), (ty == Q1.TYP_PAYLOAD)
    hp = hit.reshape(n, Q1.P_STEPS, Q1.TPI)[:, :, 2:]
    instr_ok = hp.all(-1)
    return {
        "ce_all": float(ce.mean()),
        "ce_struct": float(ce[m_st].mean()),
        "ce_payload": float(ce[m_pl].mean()),
        "acc_struct": float(hit[m_st].mean()),
        "acc_payload": float(hit[m_pl].mean()),
        "instr_valid": float(instr_ok.all(-1).mean()),
        "instr_acc": float(instr_ok.mean()),
    }, ce


# ---------------------------------------------------------------------------
# 1 ラン
# ---------------------------------------------------------------------------
def run_one(arm, seed, n_seqs, epochs, bs, lr, auxw, eval_every=1, tag=""):
    torch.set_num_threads(1)
    cfg = ARMS[arm]
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)

    # --- gain 校正（初期化時の分岐 RMS を relu に揃える）---
    cal_rng = np.random.default_rng(999)
    cal_seq, _ = Q1.make_trace_batch(cal_rng, 128)
    model = ActMoE(cfg["widths"], cfg["act"], seed=seed)
    rms_self = branch_rms(model, cal_seq)
    ref = ActMoE(cfg["widths"], "relu", seed=seed)
    rms_ref = rms_self if cfg["act"] == "relu" else branch_rms(ref, cal_seq)
    if cfg["gain"] == "matched":
        model.gain = rms_ref / max(rms_self, 1e-12)
    rms_after = branch_rms(model, cal_seq)

    opt = Adam(model.params(), lr=lr)
    nparam = sum(v.numel() for v in model.params().values())
    macs = model.k * sum(cfg["widths"]) * model.d * NMAT[cfg["act"]] / len(cfg["widths"])
    steps_per_ep = max(1, n_seqs // bs)
    t0 = time.time()
    hist, evals, ce_hist = [], [], []
    ev_rng = np.random.default_rng(777)
    ev_seq, ev_typ = Q1.make_trace_batch(ev_rng, 1024)
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps_per_ep):
            seq, _ = Q1.make_trace_batch(rng, bs)
            x = torch.from_numpy(seq)
            logits, aux, _ = model(x, aux_mode="p_pen")
            loss = Q1.trace_loss(logits, seq) + auxw * aux
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        hist.append(run / steps_per_ep)
        if (ep + 1) % eval_every == 0 or ep == epochs - 1:
            ev_k, ce_k = evaluate(model, ev_seq, ev_typ)
            ev_k["ep"] = ep + 1
            evals.append(ev_k)
            ce_hist.append(ce_k)

    # --- 死んだユニット率（最終 epoch の重みで）---
    model.collect = {}
    _ = evaluate(model, ev_seq, ev_typ)
    dead = {f"l{l}.e{i}": float(torch.stack(v).mean()) for (l, i), v in model.collect.items()}
    model.collect = None

    out = {"arm": arm, "seed": seed, "act": cfg["act"], "widths": list(cfg["widths"]),
           "n_mat": NMAT[cfg["act"]], "nparam": nparam, "nominal_macs": macs,
           "gain": model.gain, "rms_init_raw": rms_self, "rms_init_ref": rms_ref,
           "rms_init_after": rms_after, "loss_hist": hist, "evals": evals,
           "n_eval": 1024, "sec": round(time.time() - t0, 1),
           "dead_by_expert": dead}
    os.makedirs(OUTDIR, exist_ok=True)
    np.save(os.path.join(OUTDIR, f"ce_{tag}{arm}_s{seed}.npy"), np.stack(ce_hist))
    with open(os.path.join(OUTDIR, f"{tag}{arm}_s{seed}.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    return out


def _worker(job):
    arm, seed, kw = job
    try:
        return run_one(arm, seed, **kw)
    except Exception:
        return {"arm": arm, "seed": seed, "error": traceback.format_exc()}


# ---------------------------------------------------------------------------
# 集計
# ---------------------------------------------------------------------------
def paired(rows, a, b, ep=-1):
    """seed ごとの平均 CE の対応差。n = seed 数。"""
    from scipy import stats
    da = {r["seed"]: r["evals"][ep]["ce_all"] for r in rows if r["arm"] == a and "evals" in r}
    db = {r["seed"]: r["evals"][ep]["ce_all"] for r in rows if r["arm"] == b and "evals" in r}
    ks = sorted(set(da) & set(db))
    if len(ks) < 2:
        return None
    d = np.array([da[k] - db[k] for k in ks])
    n = len(d)
    se = d.std(ddof=1) / math.sqrt(n)
    t, p = stats.ttest_rel([da[k] for k in ks], [db[k] for k in ks])
    tc = stats.t.ppf(0.975, n - 1) + stats.t.ppf(0.80, n - 1)
    return {"a": a, "b": b, "n": n, "mean": float(d.mean()), "se": float(se),
            "t": float(t), "p": float(p), "pos": int((d > 0).sum()),
            "mde": float(tc * se), "per_seed": d.round(6).tolist()}


CONTRASTS = [
    ("silu", "relu", "形（等パラメータ・等幅）"),
    ("relu2", "relu", "形＋行列数（等幅）"),
    ("swiglu", "relu", "行列数（等幅・1.5 倍 params）"),
    ("drelu", "swiglu", "形（3 行列・等パラメータ）"),
    ("relu_w15", "relu", "幅（1.5 倍、形は同じ）"),
    ("relu2_w15", "swiglu", "幅 vs 行列数（等 params・等 MACs）"),
    ("relu2_raw", "relu2", "質量（gain 補正の有無）"),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", nargs="+", default=list(ARMS))
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4, 5])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--auxw", type=float, default=0.05)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--eval_every", type=int, default=1)
    ap.add_argument("--gain", choices=["matched", "none", "arms"], default="arms",
                    help="arms=ARMS の定義どおり / matched=全アーム揃える / none=全部 raw")
    ap.add_argument("--tag", default="", help="出力ファイル名の接頭辞（--gain 対照を混ぜない）")
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()

    if args.gain != "arms":
        for a in ARMS:
            ARMS[a]["gain"] = args.gain

    os.makedirs(OUTDIR, exist_ok=True)
    if args.smoke:
        args.arms, args.seeds, args.epochs, args.workers = ["relu", "relu2"], [0], 1, 2

    kw = dict(n_seqs=args.seqs, epochs=args.epochs, bs=args.bs, lr=args.lr, auxw=args.auxw,
              eval_every=args.eval_every, tag=args.tag)
    jobs = [(a, s, kw) for a in args.arms for s in args.seeds]
    print(f"T={Q1.T_LEN} arms={len(args.arms)} seeds={len(args.seeds)} "
          f"jobs={len(jobs)} epochs={args.epochs} workers={args.workers}", flush=True)

    from concurrent.futures import ProcessPoolExecutor, as_completed
    rows = []
    t0 = time.time()
    with ProcessPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(_worker, j): j for j in jobs}
        for k, fu in enumerate(as_completed(futs), 1):
            r = fu.result()
            if "error" in r:
                print(f"[FAIL] {r['arm']} s{r['seed']}\n{r['error']}", flush=True)
                continue
            rows.append(r)
            e = r["evals"][-1]
            print(f"[{k}/{len(jobs)}] {r['arm']:10s} s{r['seed']} "
                  f"CE={e['ce_all']:.4f} pl={e['ce_payload']:.4f} "
                  f"iv={e['instr_valid']:.3f} gain={r['gain']:.3f} "
                  f"dead={np.mean(list(r['dead_by_expert'].values())):.3f} "
                  f"({r['sec']:.0f}s, tot {time.time()-t0:.0f}s)", flush=True)

    with open(os.path.join(OUTDIR, f"a1_results{args.tag}.json"), "w", encoding="utf-8") as fh:
        json.dump(rows, fh, ensure_ascii=False, indent=2)

    # 集計表（最終 epoch）
    agg = []
    for a in args.arms:
        rs = [r for r in rows if r["arm"] == a and "evals" in r]
        if not rs:
            continue
        agg.append({
            "arm": a, "n": len(rs),
            "ce_all": float(np.mean([r["evals"][-1]["ce_all"] for r in rs])),
            "ce_all_sd": float(np.std([r["evals"][-1]["ce_all"] for r in rs], ddof=1)) if len(rs) > 1 else 0.0,
            "ce_payload": float(np.mean([r["evals"][-1]["ce_payload"] for r in rs])),
            "instr_valid": float(np.mean([r["evals"][-1]["instr_valid"] for r in rs])),
            "acc_payload": float(np.mean([r["evals"][-1]["acc_payload"] for r in rs])),
            "dead": float(np.mean([np.mean(list(r["dead_by_expert"].values())) for r in rs])),
            "nparam": rs[0]["nparam"], "macs": rs[0]["nominal_macs"],
            "gain": float(np.mean([r["gain"] for r in rs])),
            "rms_raw": float(np.mean([r["rms_init_raw"] for r in rs])),
        })
    with open(os.path.join(OUTDIR, f"a1_summary{args.tag}.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(agg[0]))
        w.writeheader()
        w.writerows(agg)

    # 対比は epoch ごとに出す
    by_ep = {}
    for ep in range(-args.epochs, 0):
        cons = []
        for a, b, label in CONTRASTS:
            if a in args.arms and b in args.arms:
                r = paired(rows, a, b, ep=ep)
                if r:
                    r["label"] = label
                    cons.append(r)
        by_ep[str(ep)] = cons
    with open(os.path.join(OUTDIR, f"a1_contrasts{args.tag}.json"), "w", encoding="utf-8") as fh:
        json.dump({"aggregate": agg, "contrasts_by_epoch": by_ep}, fh,
                  ensure_ascii=False, indent=2)

    print("\n=== aggregate (final epoch) ===", flush=True)
    for a in agg:
        print(f"  {a['arm']:10s} CE={a['ce_all']:.4f}±{a['ce_all_sd']:.4f} "
              f"pl={a['ce_payload']:.4f} iv={a['instr_valid']:.3f} dead={a['dead']:.3f} "
              f"params={a['nparam']:,} macs={a['macs']:.0f}", flush=True)
    print("\n=== contrasts (a - b, seed paired) ===", flush=True)
    for ep, cons in by_ep.items():
        print(f"  -- epoch {ep} --", flush=True)
        for c in cons:
            print(f"    {c['a']:10s}-{c['b']:10s} Δ={c['mean']:+.4f} se={c['se']:.4f} "
                  f"t={c['t']:+.2f} p={c['p']:.4f} {c['pos']}/{c['n']} "
                  f"MDE={c['mde']:.4f} [{c['label']}]", flush=True)
    print(f"\n[write] {OUTDIR}  ({time.time()-t0:.0f}s)", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
