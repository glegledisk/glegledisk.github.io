"""H8: expert-choice routing で二峰性と崩壊を同時に避けられるか。

## 背景（§9 の結論）

token-choice routing には抜け道が無かった:
  - 負荷分散あり → 専門化を妨げる → 二峰性（SD 0.64）
  - 負荷分散なし → 1 expert に崩壊（8 個中 7 個が死ぬ）→ 不均一 MoE でなくなる

expert-choice（各 expert が自分の上位トークンを選ぶ）は**容量が構造的に決まる**ので、
崩壊が起きない。専門化も選抜スコアで決まるので妨げられない。両方の問題を同時に
避けられる可能性がある。

## 容量の決め方（重要）

FLOPs を token-choice top-2 と揃える。expert e の受入数を C_e とすると
活性 FLOPs ∝ Σ_e C_e · s_e。これを N · target_width に固定する:

    C_e = N · target_width / (E · s_e)

小さい expert ほど多くのトークンを受ける（s=0.5 なら 2 倍、s=1.5 なら 2/3 倍）。
C_e · s_e が全 expert で等しいので、**FLOPs が完全に均衡する**。

HET = [.5,.5,.75,.75,1.25,1.25,1.5,1.5], E=8, target_width=2.0, N=2048 のとき
    C_e = 512/s_e  → [1024,1024,683,683,410,410,341,341]
    1 トークンあたり平均 2.4 expert が選ぶ（Σ C_e / N = 2.4）

## 条件（4 つ × 7 seed）

  tok_uni_k2    token-choice, 均一サイズ, top-2, λ=0, soft 負荷分散（baseline）
  tok_het_aux   token-choice, 不均一, top-2, λ=0.01, soft 負荷分散（§9 の二峰性 regime）
  ec_het        expert-choice, 不均一, target_width=2.0
  ec_uni        expert-choice, 均一, target_width=2.0（routing の効果と不均一の効果を分離）

## 測るもの

  depth1 CE（解けるか）/ cost（活性幅）/ per-expert 使用率 / top-1 シェア
  seed 間 SD（二峰性が消えたか）/ **死んだ expert の数**（崩壊の検出）
"""
import argparse
import gc
import json
import os
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from h3_bigvocab import block_mask, sample_mask, diff_loss, evaluate, SEQ
from h4_arith import mup_init
from h5_tasks import gen_comp, make_types, TYPE_NAMES, ce_by_type

HERE = os.path.dirname(os.path.abspath(__file__))

C = 31
D_FF = 512
HET = [0.5, 0.5, 0.75, 0.75, 1.25, 1.25, 1.5, 1.5]
UNI = [1.0] * 8
STEPS = 3000
LR = 3e-3
AUX_W = 0.1
LAM = 0.01
DEAD = 0.02          # 使用率がこれ未満の expert を「死んだ」とみなす


# ---------------------------------------------------------------- expert-choice MoE
class ECMoE(nn.Module):
    def __init__(self, d, d_ff, sizes, target_width=2.0):
        super().__init__()
        self.E = len(sizes)
        hs = [max(8, int(round(s * d_ff))) for s in sizes]
        H = max(hs)
        self.hs = hs
        self.W1 = nn.Parameter(torch.empty(self.E, H, d))
        self.b1 = nn.Parameter(torch.zeros(self.E, H))
        self.W2 = nn.Parameter(torch.empty(self.E, d, H))
        self.b2 = nn.Parameter(torch.zeros(self.E, d))
        m1 = torch.zeros(self.E, H)
        for e, h in enumerate(hs):
            m1[e, :h] = 1.0
        self.register_buffer("m1", m1)
        self.register_buffer("sizes", torch.tensor(sizes, dtype=torch.float32))
        self.size_list = [float(s) for s in sizes]
        self.router = nn.Linear(d, self.E, bias=False)
        self.target_width = target_width
        # 同じ隠れ幅の expert をまとめる（HET は対になっているので 8 -> 4 グループ）。
        # グループ内は容量も等しいので 1 本の bmm で回せる。
        self.groups = []
        for e, h in enumerate(hs):
            for g in self.groups:
                if g[0] == h:
                    g[1].append(e)
                    break
            else:
                self.groups.append([h, [e]])

    def forward(self, x):
        B, Ln, D = x.shape
        N = B * Ln
        fx = x.reshape(N, D)
        G = self.router(x).reshape(N, self.E)          # (N,E)

        # 容量: C_e = N*target/(E*s_e)。C_e*s_e が全 expert で等しい＝FLOPs 均衡
        caps = [max(1, min(N, int(round(N * self.target_width / (self.E * s)))))
                for s in self.size_list]

        mask = torch.zeros(N, self.E, dtype=torch.bool, device=x.device)
        idx_all = []
        for h, es in self.groups:
            cap = caps[es[0]]
            idx = G[:, es].T.topk(cap, dim=-1).indices       # (m, cap)
            idx_all.append(idx)
            for i, e in enumerate(es):
                mask[idx[i], e] = True

        # 重みは全グループの割当が確定してから 1 回だけ計算する
        W = G.masked_fill(~mask, float("-inf")).softmax(-1)
        W = torch.nan_to_num(W, nan=0.0)

        out = torch.zeros(N, D, device=x.device, dtype=fx.dtype)
        for (h, es), idx in zip(self.groups, idx_all):
            xe = fx[idx]                                     # (m, cap, d)
            y = F.gelu(torch.bmm(xe, self.W1[es][:, :h].transpose(1, 2))
                       + self.b1[es][:, :h].unsqueeze(1))
            y = torch.bmm(y, self.W2[es][:, :, :h].transpose(1, 2)) + self.b2[es].unsqueeze(1)
            w = torch.stack([W[idx[i], es[i]] for i in range(len(es))])   # (m, cap)
            out.index_add_(0, idx.reshape(-1), (y * w.unsqueeze(-1)).reshape(-1, D))

        # FLOPs は構成上 target_width に固定
        cost = torch.full((), self.target_width, device=x.device)
        # 負荷分散は容量で構造的に担保されるので補助損失は不要
        aux = torch.zeros((), device=x.device)
        return out.view(B, Ln, D), cost, aux, mask, W


class TCBlock(nn.Module):
    """token-choice（h3 と同じ）＋ soft 負荷分散。"""

    def __init__(self, d, nh, d_ff, sizes, k, aux_mode):
        super().__init__()
        self.ln1 = nn.LayerNorm(d)
        self.attn = nn.MultiheadAttention(d, nh, batch_first=True)
        self.ln2 = nn.LayerNorm(d)
        self.E = len(sizes)
        self.k = k
        hs = [max(8, int(round(s * d_ff))) for s in sizes]
        H = max(hs)
        self.hs = hs
        self.W1 = nn.Parameter(torch.empty(self.E, H, d))
        self.b1 = nn.Parameter(torch.zeros(self.E, H))
        self.W2 = nn.Parameter(torch.empty(self.E, d, H))
        self.b2 = nn.Parameter(torch.zeros(self.E, d))
        m1 = torch.zeros(self.E, H)
        for e, h in enumerate(hs):
            m1[e, :h] = 1.0
        self.register_buffer("m1", m1)
        self.register_buffer("sizes", torch.tensor(sizes, dtype=torch.float32))
        self.router = nn.Linear(d, self.E, bias=False)
        self.aux_mode = aux_mode
        self.bal_target = torch.ones(self.E) / self.E

    def ffn(self, x):
        B, Ln, D = x.shape
        N = B * Ln
        fx = x.reshape(N, D)
        logits = self.router(x)
        probs = logits.softmax(-1)
        w, idx = logits.topk(self.k, dim=-1)
        w = w.softmax(-1)
        fw = w.reshape(N, self.k)
        fi = idx.reshape(N, self.k)
        h = torch.bmm(fx.unsqueeze(0).expand(self.E, -1, -1), self.W1.transpose(1, 2))
        h = F.gelu(h + self.b1.unsqueeze(1)) * self.m1.unsqueeze(1)
        y = torch.bmm(h, self.W2.transpose(1, 2)) + self.b2.unsqueeze(1).expand(-1, N, -1)
        y = y.permute(1, 0, 2)
        gate = torch.zeros(N, self.E, device=x.device, dtype=fx.dtype)
        gate.scatter_add_(1, fi, fw)
        out = (gate.unsqueeze(-1) * y).sum(1)
        hard = self.sizes[fi].sum(-1).mean()
        soft = self.k * (probs * self.sizes).sum(-1).mean()
        cost = hard + (soft - soft.detach())
        if self.aux_mode == "none":
            aux = torch.zeros((), device=x.device)
        else:
            frac = probs.reshape(-1, self.E).mean(0)
            aux = self.E * ((frac - self.bal_target.to(x.device)) ** 2).sum()
        return out.view(B, Ln, D), cost, aux, fi, gate

    def forward(self, x, am):
        h = self.ln1(x)
        a, _ = self.attn(h, h, h, attn_mask=am, need_weights=False)
        x = x + a
        y, cost, aux, fi, gate = self.ffn(self.ln2(x))
        return x + y, cost, aux, fi, gate


class ECBlock(nn.Module):
    def __init__(self, d, nh, d_ff, sizes, target_width):
        super().__init__()
        self.ln1 = nn.LayerNorm(d)
        self.attn = nn.MultiheadAttention(d, nh, batch_first=True)
        self.ln2 = nn.LayerNorm(d)
        self.moe = ECMoE(d, d_ff, sizes, target_width)

    def forward(self, x, am):
        h = self.ln1(x)
        a, _ = self.attn(h, h, h, attn_mask=am, need_weights=False)
        x = x + a
        y, cost, aux, mask, W = self.moe(self.ln2(x))
        return x + y, cost, aux, mask, W


class Net(nn.Module):
    def __init__(self, n_class, d, nh, nlay, blocks):
        super().__init__()
        self.emb = nn.Embedding(n_class, d)
        self.pos = nn.Parameter(torch.zeros(SEQ, d))
        self.blocks = nn.ModuleList(blocks)
        self.ln_f = nn.LayerNorm(d)
        self.head = nn.Linear(d, n_class, bias=False)
        nn.init.normal_(self.pos, std=0.02)

    def forward(self, x, am):
        h = self.emb(x) + self.pos
        cs, as_, outs = [], [], []
        for blk in self.blocks:
            h, c, a, m, w = blk(h, am)
            cs.append(c)
            as_.append(a)
            outs.append((m, w))
        # h3 の diff_loss / evaluate / ce_by_type が 5 値を期待するので合わせる
        return self.head(self.ln_f(h)), torch.stack(cs).mean(), torch.stack(as_).mean(), outs, None


def mup_init_ec(model, d):
    for blk in model.blocks:
        moe = blk.moe if hasattr(blk, "moe") else blk
        with torch.no_grad():
            for e, h in enumerate(moe.hs):
                moe.W1[e, :h].normal_(0.0, (1.0 / d) ** 0.5)
                moe.W2[e, :, :h].normal_(0.0, (1.0 / h) ** 0.5)
                moe.b1[e, :h].zero_()
                moe.b2[e].zero_()


# ---------------------------------------------------------------- conditions
CONDS = {
    "tok_uni_k2":  dict(kind="tc", sizes=UNI, k=2, aux="uniform", lam=0.0),
    "tok_het_aux": dict(kind="tc", sizes=HET, k=2, aux="uniform", lam=LAM),
    "ec_het":      dict(kind="ec", sizes=HET, target_width=2.0),
    "ec_uni":      dict(kind="ec", sizes=UNI, target_width=2.0),
}


@torch.no_grad()
def diagnose(model, xs, am, mask_id, kind):
    """depth 型ごとの活性幅・使用率・死んだ expert 数。"""
    g = torch.Generator().manual_seed(4242)
    dev = xs.device
    tm = make_types("comp").to(dev)
    E = len(model.blocks[0].moe.sizes) if kind == "ec" else model.blocks[0].E
    sizes = model.blocks[0].moe.sizes if kind == "ec" else model.blocks[0].sizes
    widths, hist, use = {}, {}, torch.zeros(E, device=dev)
    nb = 0
    for _ in range(6):
        m, _ = sample_mask(xs.shape[0], 0.1, g, dev)
        inp = torch.where(m, torch.full_like(xs, mask_id), xs)
        _, _, _, outs, _ = model(inp, am)
        mask, W = outs[-1]
        if kind == "ec":
            width = (mask.float() * sizes.unsqueeze(0)).sum(-1)       # (N,)
            top1 = W.argmax(-1)
            has = mask.any(-1)
        else:
            fi, gate = mask, W
            width = sizes[fi].sum(-1)
            top1 = fi[:, 0]
            has = torch.ones_like(top1, dtype=torch.bool)
        width = width.view(xs.shape[0], SEQ)
        top1 = top1.view(xs.shape[0], SEQ)
        has = has.view(xs.shape[0], SEQ)
        use += torch.bincount(top1[has].flatten(), minlength=E).float()
        nb += has.sum()
        for ti, tn in enumerate(TYPE_NAMES["comp"]):
            sel = m & (tm == ti).unsqueeze(0) & has
            if not sel.any():
                continue
            widths.setdefault(tn, []).append(float(width[sel].mean()))
            h = torch.bincount(top1[sel], minlength=E).float()
            hist.setdefault(tn, []).append((h / h.sum()).cpu())
    out = {}
    for tn in TYPE_NAMES["comp"]:
        if tn not in widths:
            continue
        H = torch.stack(hist[tn]).mean(0)
        p = H.clamp_min(1e-9)
        out[tn] = dict(width=float(np.mean(widths[tn])),
                       top1_share=float(H.max()),
                       entropy=float(-(p * p.log()).sum()),
                       hist=[round(float(v), 3) for v in H])
    u = (use / max(1.0, float(nb))).cpu().numpy()
    out["_usage"] = [round(float(v), 3) for v in u]
    out["_dead"] = int((u < DEAD).sum())
    out["_unassigned"] = float(1.0 - min(1.0, float(nb) / (6 * xs.shape[0] * SEQ * 0.5)))
    return out


def run(cond, seed, b=1, steps=STEPS):
    spec = CONDS[cond]
    torch.manual_seed(seed)
    np.random.seed(seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    n_class = 2 * C + 1
    mask_id = 2 * C

    if spec["kind"] == "tc":
        blocks = [TCBlock(128, 4, D_FF, spec["sizes"], spec["k"], spec["aux"]) for _ in range(4)]
    else:
        blocks = [ECBlock(128, 4, D_FF, spec["sizes"], spec["target_width"]) for _ in range(4)]
    model = Net(n_class, 128, 4, 4, blocks).to(dev)
    mup_init_ec(model, 128)

    opt = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda i: min(1.0, i / max(1, steps * 0.05)))
    am = ~block_mask(b).to(dev)

    gt = torch.Generator().manual_seed(1234)
    f = torch.randint(0, C, (C, C), generator=gt)
    gen = torch.Generator(device="cpu").manual_seed(seed * 77 + 1)
    xv = gen_comp(512, C, f, torch.Generator().manual_seed(7)).to(dev)

    lam = spec.get("lam", 0.0)
    t0 = time.time()
    for _ in range(steps):
        x = gen_comp(64, C, f, gen).to(dev)
        loss, cost, aux = diff_loss(model, x, am, gen, mask_id)
        opt.zero_grad(set_to_none=True)
        (loss + lam * cost + AUX_W * aux).backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()

    val = evaluate(model, xv, am, mask_id)
    tm = make_types("comp").to(dev)
    cells = ce_by_type(model, xv, am, mask_id, tm, TYPE_NAMES["comp"])
    diag = diagnose(model, xv, am, mask_id, spec["kind"])
    with torch.no_grad():
        xb = gen_comp(256, C, f, torch.Generator().manual_seed(11)).to(dev)
        m, _ = sample_mask(256, 0.5, torch.Generator().manual_seed(5), dev)
        inp = torch.where(m, torch.full_like(xb, mask_id), xb)
        _, cost_meas, _, _, _ = model(inp, am)
    rec = dict(cond=cond, seed=seed, b=b, steps=steps, val=val,
               cost=float(cost_meas), cells=cells, diag=diag, sec=time.time() - t0)
    # ジョブ間で GPU を確実に返す（これが無いと 2 ジョブ目で 7776 MiB まで膨れてハングした）
    del model, opt
    gc.collect()
    torch.cuda.empty_cache()
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--conds", default="tok_uni_k2,tok_het_aux,ec_het,ec_uni")
    ap.add_argument("--seeds", default="0,1,2,3,4,5,6")
    ap.add_argument("--b", type=int, default=1)
    ap.add_argument("--steps", type=int, default=STEPS)
    ap.add_argument("--out", default="h8_results.jsonl")
    a = ap.parse_args()

    out = os.path.join(HERE, a.out)
    done = set()
    if os.path.exists(out):
        with open(out, encoding="utf-8") as fp:
            for line in fp:
                if line.strip():
                    d = json.loads(line)
                    done.add((d["cond"], d["seed"], d["steps"]))
    conds = a.conds.split(",")
    seeds = [int(x) for x in a.seeds.split(",")]
    jobs = [(c, s) for c in conds for s in seeds
            if (c, s, a.steps) not in done]
    print(f"jobs: {len(jobs)} (skip {len(done)} already done)", flush=True)

    t0 = time.time()
    for i, (c, s) in enumerate(jobs, 1):
        print(f"[{i}/{len(jobs)}] {c} seed={s} elapsed={(time.time()-t0)/60:.1f}m", flush=True)
        try:
            r = run(c, s, a.b, a.steps)
        except Exception as e:                                   # noqa: BLE001
            print(f"  FAIL {type(e).__name__}: {e}", flush=True)
            torch.cuda.empty_cache()
            continue
        with open(out, "a", encoding="utf-8") as fp:
            fp.write(json.dumps(r, ensure_ascii=False) + "\n")
        d = r["diag"]
        print(f"  val={r['val']:.3f} cost={r['cost']:.2f} d1={r['cells']['depth1']:.3f} "
              f"dead={d['_dead']} share={d['depth1']['top1_share']:.2f} sec={r['sec']:.0f}", flush=True)
    print("DONE", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
