#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX9 走行前調査: 「別モデル / 別 seed」で何が実現できるかを確定する（モデル多様性の棚卸し）

1. ローカル ckpt のアーキテクチャ一覧
2. _smoke_olmoe が学習済みかランダム初期化かを 1 forward の NLL で判定
3. 外部の学習済み MoE ckpt へアクセスできるか（ダウンロードはしない）
"""
import json
import math
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
MODELS = os.path.join(HERE, "models")
OUT = {}


def cfg_of(name):
    p = os.path.join(MODELS, name, "config.json")
    if not os.path.isfile(p):
        return {"present": False}
    with open(p, encoding="utf-8") as fp:
        c = json.load(fp)
    return {"present": True,
            "arch": (c.get("architectures") or [None])[0],
            "model_type": c.get("model_type"),
            "layers": c.get("num_hidden_layers"),
            "experts": c.get("num_experts"),
            "per_tok": c.get("num_experts_per_tok"),
            "hidden": c.get("hidden_size"),
            "vocab": c.get("vocab_size"),
            "d_model": c.get("d_model")}


def main():
    names = sorted(d for d in os.listdir(MODELS)
                   if os.path.isdir(os.path.join(MODELS, d)))
    OUT["local_configs"] = {n: cfg_of(n) for n in names}

    # ---- _smoke_olmoe の NLL（ランダム重みなら ln(vocab) 付近）----
    try:
        import torch
        import torch.nn.functional as F
        from transformers import AutoModelForCausalLM
        torch.manual_seed(0)
        m = AutoModelForCausalLM.from_pretrained(
            os.path.join(MODELS, "_smoke_olmoe"), torch_dtype=torch.float32).eval()
        v = int(m.config.vocab_size)
        x = torch.randint(0, v, (1, 32))
        with torch.no_grad():
            logit = m(input_ids=x, use_cache=False).logits[0, :-1].float()
        nll = float(F.cross_entropy(logit, x[0, 1:], reduction="mean"))
        OUT["smoke_olmoe"] = {"nll_random_ids": nll, "ln_vocab": math.log(v),
                              "ratio_to_ln_vocab": nll / math.log(v),
                              "verdict": "random_like" if nll / math.log(v) > 0.90
                              else "trained_like"}
        del m
    except Exception as e:
        OUT["smoke_olmoe"] = {"error": "%s: %s" % (type(e).__name__, str(e)[:200])}

    # ---- 外部 ckpt の参照可否（ダウンロードしない）----
    ext = {}
    try:
        from huggingface_hub import model_info
        for mid in ("allenai/OLMoE-1B-7B-0924-Instruct",
                    "Qwen/Qwen1.5-MoE-A2.7B",
                    "mistralai/Mixtral-8x7B-Instruct-v0.1"):
            try:
                i = model_info(mid)
                sib = [s.rfilename for s in (i.siblings or [])]
                ext[mid] = {"reachable": True, "n_files": len(sib),
                            "has_safetensors": any(s.endswith(".safetensors") for s in sib),
                            "id": i.id}
            except Exception as e:
                ext[mid] = {"reachable": False,
                            "error": "%s: %s" % (type(e).__name__, str(e)[:160])}
    except Exception as e:
        ext["huggingface_hub"] = {"error": "%s: %s" % (type(e).__name__, str(e)[:160])}
    OUT["external"] = ext

    with open(os.path.join(HERE, "_ax9_probe.json"), "w", encoding="utf-8") as fp:
        json.dump(OUT, fp, ensure_ascii=False, indent=2, allow_nan=False)
    print(json.dumps(OUT, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
