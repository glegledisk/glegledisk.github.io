import os, sys, time
os.environ["CUDA_VISIBLE_DEVICES"] = ""      # GPU は使わない（凍結）
os.environ["TRANSFORMERS_NO_ADVISORY_WARNINGS"] = "1"
os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"

t0 = time.time()
from transformers import AutoTokenizer
print("transformers ok", time.time() - t0)

for name in ["Qwen/Qwen3-0.6B", "allenai/OLMo-2-0425-1B"]:
    try:
        t0 = time.time()
        tok = AutoTokenizer.from_pretrained(name)
        print(f"[OK] {name}  {time.time()-t0:.1f}s  vocab={len(tok)}  class={type(tok).__name__}")
        print("     byte_decoder:", hasattr(tok, "byte_decoder"))
        print("     sample:", [tok.convert_ids_to_tokens(i) for i in range(200, 205)])
    except Exception as e:
        print(f"[NG] {name}: {type(e).__name__}: {str(e)[:200]}")
