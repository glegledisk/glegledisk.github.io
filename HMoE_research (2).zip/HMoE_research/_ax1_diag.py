# -*- coding: utf-8 -*-
"""AX1 post-hoc diagnostics (EXPLORATORY, explicitly not pre-registered).

Purpose: verify that the surprising S_lay ~ S_tok is a real per-token signal
and not a mechanical consequence of the estimator. No confirmatory test here;
ax1_analysis.json is untouched.

Output: _ax1_diag.json
"""
import os
import json
import numpy as np
from scipy import stats

ROOT = os.path.dirname(os.path.abspath(__file__))
D = np.load(os.path.join(ROOT, "ax1_delta.npz"), allow_pickle=False)
E, U, C6 = D["E"], D["U"], D["C6"]
F1, B1, F2, B2 = D["F1"], D["B1"], D["F2"], D["B2"]
T_o, T_p, T_r = D["T_o"], D["T_p"], D["T_r"]
R_tok, R_lay, L_o = D["R_tok"], D["R_lay"], D["L_o"]
cf, cb = D["cf"], D["cb"]
d_AX, d_AXf = D["d_AX"], D["d_AX_feas"]
N = E.size
rng = np.random.RandomState(20261111)

out = {}

# 1. Does the independent 1-slot signal predict the cheaper 16-slot arm?
cheaper_front = F2 < B2
equal_arm = F2 == B2
signal_front = cf < cb
ties_signal = cf == cb
hit = float((signal_front == cheaper_front).mean())
out["oracle_signal"] = {
    "n_ties_cf_cb": int(ties_signal.sum()),
    "n_equal_F2_B2": int(equal_arm.sum()),
    "P_signal_front": float(signal_front.mean()),
    "P_cheaper_front": float(cheaper_front.mean()),
    "agreement_rate": hit,
    "confusion": {
        "sig_front_and_F2_cheaper": int((signal_front & cheaper_front).sum()),
        "sig_front_and_B2_cheaper": int((signal_front & ~cheaper_front).sum()),
        "sig_back_and_F2_cheaper": int((~signal_front & cheaper_front).sum()),
        "sig_back_and_B2_cheaper": int((~signal_front & ~cheaper_front).sum()),
    },
    "mean_abs_F2_minus_B2": float(np.abs(F2 - B2).mean()),
    "mean_abs_C6_minus_E": float(np.abs(C6 - E).mean()),
    "half_mean_abs_F2_minus_B2": float(0.5 * np.abs(F2 - B2).mean()),
    "half_mean_abs_C6_minus_E": float(0.5 * np.abs(C6 - E).mean()),
    "S_lay_observed": float((R_lay - L_o).mean()),
    "S_tok_observed": float((R_tok - T_o).mean()),
}

# 2. perfect-outcome oracle vs our signal oracle vs anti-oracle
L_perfect = np.minimum(F2, B2)
L_anti = np.maximum(F2, B2)
out["oracle_bounds"] = {
    "G_lay_perfect_vs_U": float((L_perfect - U).mean()),
    "G_lay_signal_vs_U": float((L_o - U).mean()),
    "G_lay_anti_vs_U": float((L_anti - U).mean()),
    "G_lay_random_vs_U": float((R_lay - U).mean()),
    "L_o_equals_perfect_rate": float((L_o == L_perfect).mean()),
    "G_tok_oracle_vs_U": float((T_o - U).mean()),
}

# 3. realised random layer allocation: S must be ~0 in expectation
draws = []
for _ in range(200):
    pick = rng.rand(N) < 0.5
    chosen = np.where(pick, F2, B2)
    draws.append(float((R_lay - chosen).mean()))
draws = np.array(draws)
out["random_layer_control"] = {
    "n_draws": len(draws), "mean": float(draws.mean()),
    "sd": float(draws.std(ddof=1)),
    "min": float(draws.min()), "max": float(draws.max()),
    "abs_mean_over_sd": float(abs(draws.mean()) / draws.std(ddof=1)),
}

# 4. permutation test: shuffle the 1-slot signal, recompute S_lay
perm = []
for _ in range(2000):
    p = rng.permutation(N)
    chosen = np.where(cf[p] < cb[p], F2, B2)
    perm.append(float((R_lay - chosen).mean()))
perm = np.array(perm)
obs = float((R_lay - L_o).mean())
p_perm = float((np.sum(perm >= obs) + 1) / (len(perm) + 1))
out["permutation_test_S_lay"] = {
    "n_perm": len(perm), "observed": obs,
    "perm_mean": float(perm.mean()), "perm_sd": float(perm.std(ddof=1)),
    "perm_min": float(perm.min()), "perm_max": float(perm.max()),
    "p_one_sided_greater": p_perm,
}

# 5. direct axis comparison of oracle gains (exploratory)
d_direct = (T_o - U) - (L_o - U)
tt = stats.ttest_rel(d_direct, np.zeros_like(d_direct))
out["direct_oracle_gain_difference"] = {
    "mean": float(d_direct.mean()),
    "se": float(d_direct.std(ddof=1) / np.sqrt(N)),
    "t": float(tt.statistic), "p_two": float(tt.pvalue),
    "mde": float(stats.t.ppf(0.975, N - 1) * d_direct.std(ddof=1) / np.sqrt(N)),
    "ci90": list(map(float, stats.t.interval(
        0.90, N - 1, loc=d_direct.mean(),
        scale=d_direct.std(ddof=1) / np.sqrt(N)))),
}

# 6. window decomposition of AX
wm = d_AX.reshape(48, 255).mean(axis=1)
out["AX_by_window"] = {
    "n_positive_windows": int((wm > 0).sum()),
    "n_negative_windows": int((wm < 0).sum()),
    "window_mean_min": float(wm.min()),
    "window_mean_max": float(wm.max()),
    "top5_window_share_of_signed_sum": float(
        np.sort(wm)[::-1][:5].sum() / wm.sum()) if wm.sum() != 0 else None,
    "AX_excluding_largest_abs_window": float(
        np.delete(wm, int(np.argmax(np.abs(wm)))).mean()),
}

# 7. quartile decomposition by baseline NLL
order = np.argsort(E, kind="stable")
groups = np.array_split(order, 4)
out["quartiles"] = []
for i, g in enumerate(groups, 1):
    out["quartiles"].append({
        "q": i, "n": int(g.size),
        "baseline_ce": float(E[g].mean()),
        "S_tok": float((R_tok - T_o)[g].mean()),
        "S_lay": float((R_lay - L_o)[g].mean()),
        "d_AX": float(d_AX[g].mean()),
        "G_tok_oracle": float((T_o - U)[g].mean()),
        "G_lay_oracle": float((L_o - U)[g].mean()),
    })

# 8. how much of each arm is exactly at baseline (zero-inflation)
out["zero_inflation"] = {
    "U_eq_E_rate": float((U == E).mean()),
    "F2_eq_B2_rate": float((F2 == B2).mean()),
    "F1_eq_E_rate": float((F1 == E).mean()),
    "B1_eq_E_rate": float((B1 == E).mean()),
    "C6_eq_E_rate": float((C6 == E).mean()),
}

with open(os.path.join(ROOT, "_ax1_diag.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2, allow_nan=True)

lines = [
    "=== AX1 POST-HOC DIAGNOSTICS (exploratory) ===",
    "signal/cheaper agreement = %.6f  (cf==cb ties %d, F2==B2 %d)" %
    (hit, int(ties_signal.sum()), int(equal_arm.sum())),
    "half*mean|F2-B2| = %.6f   half*mean|C6-E| = %.6f" %
    (out["oracle_signal"]["half_mean_abs_F2_minus_B2"],
     out["oracle_signal"]["half_mean_abs_C6_minus_E"]),
    "G_lay perfect/signal/anti/random = %.6f / %.6f / %.6f / %.6f" %
    (out["oracle_bounds"]["G_lay_perfect_vs_U"],
     out["oracle_bounds"]["G_lay_signal_vs_U"],
     out["oracle_bounds"]["G_lay_anti_vs_U"],
     out["oracle_bounds"]["G_lay_random_vs_U"]),
    "random layer control: mean %.8f sd %.8f over %d draws" %
    (draws.mean(), draws.std(ddof=1), len(draws)),
    "permutation S_lay: observed %.6f  perm mean %.6f sd %.6f  p=%.6f" %
    (obs, perm.mean(), perm.std(ddof=1), p_perm),
    "direct G_tok_oracle - G_lay_oracle = %+.8f (t=%+.3f, p=%.5f, MDE=%.6f)" %
    (out["direct_oracle_gain_difference"]["mean"],
     out["direct_oracle_gain_difference"]["t"],
     out["direct_oracle_gain_difference"]["p_two"],
     out["direct_oracle_gain_difference"]["mde"]),
    "AX windows: %d positive / %d negative; excluding largest = %+.8f" %
    (out["AX_by_window"]["n_positive_windows"],
     out["AX_by_window"]["n_negative_windows"],
     out["AX_by_window"]["AX_excluding_largest_abs_window"]),
]
print("\n".join(lines))
