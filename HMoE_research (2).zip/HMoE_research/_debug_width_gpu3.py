# -*- coding: utf-8 -*-
"""_debug_width_gpu3.py — max_memory を外すと meta が消えるか（使い捨て）"""
import os

import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "olmoe-1b-7b")

from transformers import AutoModelForCausalLM

m = AutoModelForCausalLM.from_pretrained(
    MODEL, torch_dtype=torch.bfloat16, device_map="auto").eval()

print("device_map:", {k: str(v) for k, v in m.hf_device_map.items()})
for i, l in enumerate(m.model.layers):
    e = l.mlp.experts
    print("  layer %2d gu meta=%s dev=%s" % (i, e.gate_up_proj.is_meta, e.gate_up_proj.device))
print("mem allocated GiB: %.2f" % (torch.cuda.memory_allocated() / 2**30))
