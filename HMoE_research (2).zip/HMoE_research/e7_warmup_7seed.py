# -*- coding: utf-8 -*-
"""e7_warmup_7seed.py — H-B（鶏と卵）の直接検証: 恒等パスのウォームアップ

## 動慕（tokid+安定化レポート §9-2、β 感度レポート §9-1）
tokid_entropy（β=0.05）は ff の 45% しか恒等に逃がさず（FFN cost 0.746、最適 0.425）。
β を 0.60 に上げても 0.67 で止まる。2 つの候補:

  **H-B（鶏と卵）**: 恒等パスが ff を学習しきれていない → ルータが ff を逃がすと
  CE が悪化する → 逃がさない → 恒等パスが ff を学習しない、という循環。
  **H-C（ルータ最適化）**: 恒等パスは ff を十分解けるが、ルータの最適化が
  完全オフロードの極点に届かない。

## 実験: 恒等パスのウォームアップ
最初の warmup=20 epoch は **ff 位置を強制的に恒等パスへルーティング**する
（e5 の MoELayer に force_id を追加。fr/rr は自由）。これで恒等パスに ff を学習させてから
残り 40 epoch は自由ルーティングに戻す。

| アーム | 構成 |
|---|---|
| `tokid_ent` | tokid + entropy(0.05)、warmup なし（診断付き再ラン。既存 tokid_entropy との再現性確認にもなる） |
| `tokid_ent_warm20` | 同上 + warmup 20 epoch |

## 判定
1. **H-B の検証**: warm アームの id_ff / ffn_cost が 1.0 / 0.425 に届くか。
   届く → H-B 支持（鶏と卵が律速）。届かない → H-B は棄却、H-C（ルータ最適化）が残る。
2. **診断（H-C の直接測度）**: ff 位置を経路別に分解した CE。
   - ce_ff_onid ≒ ce_ff_onffn（両パスとも ff をほぼ完全に解ける）→ ルータは CE 上
     どちらを選んでも同じ → 「逃がさない」は最適化の産物（H-C）。
   - ce_ff_onid ≫ ce_ff_onffn（恒等パスが ff を解けない）→ H-B（能力の欠如）。
3. いずれも CE / obj / tail リスク（frozen_ffn・tokid_entropy との seed 対応検定）。

構成: 2 アーム × 7 seed（不足分のみ実行・逐次保存・再開可能）
"""
import os, json, time
import numpy as np
import pandas as pd
import torch
from e7_stabilize_task import run, make_lookup_table, ROLE_NAME

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)), d=64, epochs=60)
SEEDS = list(range(7))
OUT = os.path.join(HERE, "e7_warmup_7seed.csv")
DEV = "cuda" if torch.cuda.is_available() else "cpu"
tab = make_lookup_table(64)

SPEC = dict(route="free", router="linear", stab="entropy", extra="tokid")
ARMS = {
    "tokid_ent": dict(spec=SPEC, warmup=0),
    "tokid_ent_warm20": dict(spec=SPEC, warmup=20),
}

rows = []
if os.path.exists(OUT):
    rows = pd.read_csv(OUT).to_dict("records")
have = {(r["variant"], int(r["seed"])) for r in rows}
print(f"device: {DEV}  既存 {len(have)} 件")

todo = [(v, s) for v in ARMS for s in SEEDS if (v, s) not in have]
print(f"追加実行 {len(todo)} 件")

t0 = time.time()
for i, (v, s) in enumerate(todo, 1):
    r = run(v, s, table=tab, device=DEV, spec=ARMS[v]["spec"], warmup=ARMS[v]["warmup"], **CFG)
    rows.append(r)
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"  [{i}/{len(todo)}] {v:18s} s{s} | CE {r['ce_all']:.4f} | FFN {r['ffn_cost']:.3f} "
          f"| acc {r['acc_all']:.4f} (ff {r['acc_ff']:.3f} / fr {r['acc_fr']:.3f} / rr {r['acc_rr']:.3f}) "
          f"| idff {r['id_rate_ff']:.3f} | idmass_ff {r.get('idmass_ff', float('nan')):.3f} "
          f"| ce_ff on/off {r.get('ce_ff_onid', float('nan')):.4f}/{r.get('ce_ff_onffn', float('nan')):.4f} "
          f"| {time.time()-t0:.0f}s", flush=True)

df = pd.DataFrame(rows)
df["obj015"] = df["ce_all"] + 0.15 * df["ffn_cost"]
df = df.sort_values(["variant", "seed"]).reset_index(drop=True)
df.to_csv(OUT, index=False)

# baselines
ts = pd.read_csv(os.path.join(HERE, "e7_tokid_stab_7seed.csv"))
ts["obj015"] = ts["ce_all"] + 0.15 * ts["ffn_cost"]
e7 = pd.read_csv(os.path.join(HERE, "e7_routing_7seed.csv"))
e7["obj015"] = e7["ce_all"] + 0.15 * e7["ffn_cost"]
REF = {
    "frozen_ffn": e7[e7.arm == "frozen_ffn"].set_index("seed"),
    "tokid_entropy": ts[ts.variant == "tokid_entropy"].set_index("seed"),
}
ARMS_ORDER = ["tokid_ent", "tokid_ent_warm20"]
ALL = ["frozen_ffn", "tokid_entropy", "tokid_ent", "tokid_ent_warm20"]


def get(a):
    return df[df.variant == a].set_index("seed") if a in ARMS else REF[a]


print("\n=== H-B ウォームアップの比較（60 epoch・7 seed, E7 課題, λ=0.15） ===")
print(f"{'arm':18s} {'CE':>16s} {'max CE':>8s} {'FFN':>14s} {'obj(λ=.15)':>16s} {'acc rr':>8s} "
      f"{'id ff':>7s} {'id rr':>7s}")
for a in ALL:
    d = get(a)
    print(f"{a:18s} {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f} {d['ce_all'].max():8.4f} "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f} {d['obj015'].mean():.4f}±{d['obj015'].std():.4f} "
          f"{d['acc_rr'].mean():8.4f} {d['id_rate_ff'].mean():7.3f} {d['id_rate_rr'].mean():7.3f}")

print("\n=== 再現性チェック: tokid_ent（本実験の再ラン） vs tokid_entropy（tokid+安定化レポート） ===")
for k in ("ce_all", "ffn_cost", "obj015"):
    d = (get("tokid_ent")[k] - REF["tokid_entropy"][k]).dropna()
    print(f" {k:9s} 差 {d.mean():+.6f}（SD {d.std():.2e}）— {'完全一致' if abs(d.mean()) < 1e-9 and d.std() < 1e-9 else '不一致'}")

print("\n=== H-B 診断: ff 位置を経路別に分解した CE ===")
for a in ["tokid_ent", "tokid_ent_warm20"]:
    d = get(a)
    print(f" {a:18s} ce_ff_onid {d['ce_ff_onid'].mean():.4f}  ce_ff_onffn {d['ce_ff_onffn'].mean():.4f}  "
          f"（差 {d['ce_ff_onid'].mean()-d['ce_ff_onffn'].mean():+.4f}）  "
          f"frac_ff_onid {d['frac_ff_onid'].mean():.3f}  idmass_ff {d['idmass_ff'].mean():.3f}")
print(" → ce_ff_onid ≈ ce_ff_onffn なら恒等パスは ff を十分解ける（H-B 棄却・H-C 残る）")


def paired(d_new, d_base, key):
    d = (d_new[key] - d_base[key]).dropna()
    m, sd = d.mean(), d.std(ddof=1)
    t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
    rng = np.random.default_rng(0)
    boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(20000)])
    lo, hi = np.percentile(boot, [2.5, 97.5])
    return m, lo, hi, t, int((d < 0).sum()), len(d)


print("\n=== seed 対応検定（− tokid_entropy: ウォームアップの効果） ===")
res = {}
for a in ["tokid_ent", "tokid_ent_warm20"]:
    da = get(a)
    for k in ("obj015", "ce_all", "ffn_cost"):
        m, lo, hi, t, w, n = paired(da, REF["tokid_entropy"], k)
        res[f"{a}_vs_te_{k}"] = {"mean": float(m), "ci": [float(lo), float(hi)], "t": float(t), "wins": w}
        print(f" {a:18s} {k:9s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {w}/{n}")

print("\n=== seed 対応検定（− frozen_ffn） ===")
res2 = {}
for a in ARMS_ORDER:
    da = get(a)
    for k in ("obj015", "ce_all", "ffn_cost"):
        m, lo, hi, t, w, n = paired(da, REF["frozen_ffn"], k)
        res2[f"{a}_vs_ffn_{k}"] = {"mean": float(m), "ci": [float(lo), float(hi)], "t": float(t), "wins": w}
        print(f" {a:18s} {k:9s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {w}/{n}")

print("\n=== seed 別（CE / FFN cost / id_ff / idmass_ff） ===")
for a in ALL:
    d = get(a).sort_index()
    print(f" {a:18s} CE  " + " ".join(f"{x:.3f}" for x in d["ce_all"]))
    print(f" {'':18s} FFN " + " ".join(f"{x:.3f}" for x in d["ffn_cost"]))
    print(f" {'':18s} idF " + " ".join(f"{x:.3f}" for x in d["id_rate_ff"]))

json.dump({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in CFG.items()},
           "device": DEV, "warmup": 20,
           "summary": {a: {k: float(get(a)[k].mean()) for k in
                           ["ce_all", "ffn_cost", "obj015", "acc_all", "acc_ff", "acc_fr", "acc_rr",
                            "ce_ff", "ce_fr", "ce_rr", "id_rate_ff", "id_rate_fr", "id_rate_rr",
                            "idmass_ff", "ce_ff_onid", "ce_ff_onffn", "frac_ff_onid"]
                           if k in get(a).columns} for a in ALL},
           "paired_vs_tokid_entropy": res, "paired_vs_ffn": res2, "raw": rows},
          open(os.path.join(HERE, "e7_warmup_7seed.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e7_warmup_7seed.csv / .json")
