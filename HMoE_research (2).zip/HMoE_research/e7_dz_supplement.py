# -*- coding: utf-8 -*-
"""e7_dz_supplement.py — dead zone 実験の追加解析"""
import pandas as pd

d = pd.read_csv("e7_deadzone_7seed.csv")
d["obj"] = d["ce_all"] + 0.15 * d["ffn_cost"]
print("=== 役割別（アーム平均） ===")
print(d.groupby("variant")[["ce_ff", "ce_fr", "ce_rr", "acc_rr", "acc_ff", "acc_fr",
                            "id_rate_fr", "id_rate_rr"]].mean().round(4).to_string())

print("\n=== E6 効果量からの回復率（obj, frozen_ffn 比） ===")
e6, ffn = -0.1509, 0.3237
for v in ["bias10", "bias30", "probe"]:
    o = d[d.variant == v]["obj"].mean() - ffn
    print(f" {v:8s} {o:+.4f} ({100 * o / e6:.0f}%)")
ts = pd.read_csv("e7_tokid_stab_7seed.csv")
ts["obj"] = ts["ce_all"] + 0.15 * ts["ffn_cost"]
w = pd.read_csv("e7_warmup_7seed.csv")
w["obj"] = w["ce_all"] + 0.15 * w["ffn_cost"]
for name, dd in [("warm20", w[w.variant == "tokid_ent_warm20"]), ("tokid_entropy", ts[ts.variant == "tokid_entropy"])]:
    o = dd["obj"].mean() - ffn
    print(f" {name:8s} {o:+.4f} ({100 * o / e6:.0f}%)")

print("\n=== probe arm の seed 構成 ===")
print("probe seeds:", sorted(d[d.variant == "probe"]["seed"].tolist()))
print("bias10/bias30 seeds:", sorted(d[d.variant == "bias10"]["seed"].tolist()))

print("\n=== in-zone = id_rate の一致（全アーム・全 seed） ===")
for v in ["probe", "bias10", "bias30"]:
    dd = d[d.variant == v]
    diff = (dd["fin_inzone_ff"] - dd["id_rate_ff"]).abs().max()
    print(f" {v:8s} max |inzone - id_rate| = {diff:.4f}")

print("\n=== bias10 の seed 別 ===")
for _, r in d[d.variant == "bias10"].sort_values("seed").iterrows():
    print(f" s{int(r['seed'])}: CE {r['ce_all']:.4f} FFN {r['ffn_cost']:.3f} obj {r['obj']:.4f} "
          f"idff {r['id_rate_ff']:.3f} idrr {r['id_rate_rr']:.3f} acc_rr {r['acc_rr']:.3f}")
