# -*- coding: utf-8 -*-
"""e5_seed_confirm.py — free ルーティングの正の結果を 7 seed で確認する

E5 テストベッド（d=16, A=16, anchor_vals=(0,1,2,3)）の 3 seed 予備実験で
  合成目的（CE + 0.15*FFN）= free 0.6975 < 全FFN 0.7220
という「動的ルーティングが損益プラス」の初めての兆候が出た。
ただし free の FFN コストは seed 間で 0.995 / 0.147 / 0.309 と双安定で、3 seed では結論不能。

本スクリプトは seed を 7 に増やし、
  1. アーム別の平均・SD・中央値
  2. seed を対応させた差の検定（free - frozen_ffn、合成目的）
  3. λ 感度（どの λ で free が全FFN を上回るか）
  4. FFN コストの分布（双安定の確認）
を出す。
"""
import os, json, time
import numpy as np
import pandas as pd
from e5_dependency_task import run

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=16, anchor_vals=(0, 1, 2, 3), d=16)
ARMS = ["frozen_ffn", "frozen_identity", "free", "sidecar"]
SEEDS = [0, 1, 2, 3, 4, 5, 6]
LAMS = [0.05, 0.10, 0.15, 0.30, 0.50]

rows = []
t0 = time.time()
for arm in ARMS:
    for s in SEEDS:
        r = run(arm, s, **CFG)
        rows.append(r)
        print(f"  {arm:16s} s{s} | acc {r['acc_all']:.4f} (anchor {r.get('acc_anchor',0):.3f}) "
              f"| CE {r['ce_all']:.4f} | FFN {r['ffn_cost']:.3f} | "
              f"obj(λ=.15) {r['ce_all']+0.15*r['ffn_cost']:.4f}", flush=True)
    print(f"    ({time.time()-t0:.0f}s)", flush=True)

df = pd.DataFrame(rows)
df["obj015"] = df["ce_all"] + 0.15 * df["ffn_cost"]
df.to_csv(os.path.join(HERE, "e5_seed_confirm.csv"), index=False)

print("\n=== アーム別（7 seeds） ===")
print(f"{'arm':16s} {'acc':>16s} {'acc anchor':>16s} {'CE':>16s} {'FFN':>16s} {'obj(λ=.15)':>16s}")
for arm in ARMS:
    d = df[df.arm == arm]
    print(f"{arm:16s} {d['acc_all'].mean():.4f}±{d['acc_all'].std():.4f}  "
          f"{d['acc_anchor'].mean():.4f}±{d['acc_anchor'].std():.4f}  "
          f"{d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f}  "
          f"{d['obj015'].mean():.4f}±{d['obj015'].std():.4f}")

print("\n=== seed 対応差（free − frozen_ffn） ===")
piv = df.pivot_table(index="seed", columns="arm", values=["ce_all", "ffn_cost", "obj015", "acc_all"])
for key in ("obj015", "ce_all", "ffn_cost", "acc_all"):
    d = piv[key]["free"] - piv[key]["frozen_ffn"]
    m, sd = d.mean(), d.std(ddof=1)
    t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
    rng = np.random.default_rng(0)
    boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(10000)])
    lo, hi = np.percentile(boot, [2.5, 97.5])
    wins = int((d < 0).sum()) if key != "acc_all" else int((d > 0).sum())
    print(f" {key:8s}: 平均差 {m:+.4f} (SD {sd:.4f})  95%CI [{lo:+.4f}, {hi:+.4f}]  "
          f"t={t:+.2f}  free が優位な seed {wins}/{len(d)}")

print("\n=== λ 感度：合成目的の平均（7 seeds） ===")
print(f"{'λ':>5s} " + "".join(f"{a:>16s}" for a in ARMS) + "   最良")
best_by_lam = {}
for lam in LAMS:
    vals = {a: (df[df.arm == a]["ce_all"].mean() + lam * df[df.arm == a]["ffn_cost"].mean()) for a in ARMS}
    best = min(vals, key=vals.get)
    best_by_lam[lam] = {"vals": vals, "best": best}
    print(f"{lam:5.2f} " + "".join(f"{vals[a]:16.4f}" for a in ARMS) + f"   {best}")

print("\n=== FFN コストの分布（双安定の確認） ===")
for arm in ARMS:
    v = np.sort(df[df.arm == arm]["ffn_cost"].values)
    print(f" {arm:16s} " + " ".join(f"{x:.2f}" for x in v))

json.dump({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in CFG.items()},
           "seeds": SEEDS,
           "arm_summary": {a: {k: float(df[df.arm == a][k].mean()) for k in
                               ["acc_all", "acc_anchor", "ce_all", "ffn_cost", "obj015"]} for a in ARMS},
           "paired_free_minus_ffn": {k: float((piv[k]["free"] - piv[k]["frozen_ffn"]).mean())
                                     for k in ("obj015", "ce_all", "ffn_cost", "acc_all")},
           "lambda_best": {str(k): v["best"] for k, v in best_by_lam.items()},
           "raw": rows},
          open(os.path.join(HERE, "e5_seed_confirm.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e5_seed_confirm.csv / .json")
