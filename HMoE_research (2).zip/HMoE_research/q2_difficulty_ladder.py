#!/usr/bin/env python3
"""Q2: payload をさらに難しくすると、小 expert 選択の Δ が負に転じるか（頻度仮説の直接検証）。

前提: `検証報告_Q1_*_20261030.md`。Q1 の結論 = トレースでは **payload（難しい方）が小さい
expert に送られる**（H compute Δ +0.290 / copy Δ +0.728）。機構は「頻度」:
payload がトレースの 80% を占め、幅ペナルティ p_pen は幅に比例するので多数派を細く
寄せるのが常に得。Q1 §3 の未検証予測 = 「payload をもっと難しくすれば Δ は 0 を跨いで
負に転じるはず」。本スクリプトはこれを直接測る。

設計（難度ラダー、レイアウトとトークン頻度は固定）
  1 命令 = [op, '='] + 値 8 桁（payload 8/10 = 80%、T=109 不変）
  初期値は一様乱数 0..10^8-1（入力、損失なし）。
  op は固定プログラム（位置で決まる = struct トークンはエントロピーゼロ）。
  **タスク間で変わるのは、値を生む計算の深さだけ**:

    copy    (Q1) : 値 = 初期値のコピー        （深さ 0 の対照）
    compute (Q1) : プログラム ADADSDADAS       A(+1)/S(-1)/D(×2)
    hard         : プログラム MMMMMMMMMM       M(×3)  — 連鎖切断率 0.343、MSD 遡り ~3 桁
    harder       : プログラム KKKKKKKKKK       K(×7)  — 連鎖切断率 0.152、MSD 遡り ~5 桁

  （×2 の繰り上がりは c∈{0,1} で d_j だけで決まる=深さ ~2、×3 は c∈{0,1,2}、
   ×7 は c∈{0..6} でほぼ全桁を遡る。`_q2_task_scan.py` で理論値を確認済み。）
  値は mod 10^8（レジスタ風ラップ）。一様乱数入力 → 全桁が marginal にも一様
  （退化なし、スキャン済み）。

予測（事前登録）
  P1（操作チェック）: base payload 正解率は copy > compute > hard > harder と単調減少
  P2（主予測）     : Δ = 小 expert 選択率(payload) − 小 expert 選択率(struct) は
                     難度とともに減少する。copy ≈ +0.7 / compute ≈ +0.3（Q1 実測）→
                     hard でさらに下がり、0 を跨いで負に転じる可能性
  P3（補助）       : 単調性は「広い expert が解ける範囲」で成り立つ。harder が
                     誰にも解けない（≈ 10% = random）なら、ルーティングは損失を
                     下げられず p_pen に戻る = Δ が正に反発する可能性（非単調）
  Kill 条件        : payload 正解率が ~0.85 以下に落ちたのに Δ が compute と同水準以上
                     を保つ → 「難度が上がれば loss 圧力が payload を広い expert に
                     買い上げる」という頻度対損失のトレードオフ物語は反証

アーム: H+LB（幅 32/32/96/96/160/160/224/224, p_pen）/ U+LB（幅 128x8, switch）。
訓練条件は Q1 と完全同一（3000 系列 × 6 epoch, bs 32, lr 2e-3, auxw 0.05, seed 0..2）。
**copy/compute は Q1 の結果を再利用する**（同一スクリプト系・同一 seed で再訓練しない）。

測るもの（Q1 に加えて）
  種別ごとの acc / CE / 平均幅 / 小 expert 選択率、層別の同じ量
  ★ payload の桁位置別（MSD→LSD）acc / CE / 小 expert 選択率
    （連鎖深さの直結予測: MSD 桁ほど難しく、MSD 桁ほど広い expert に送られるはず）
  k 削減（k1/f1/b1）、強制部分集合（force_small / force_large / force_wide）
  命令単位・系列単位の有効率（0-1 損失）と最初の誤り位置

出力: data/q2/{arm}_{task}_s{seed}.json, data/q2/q2_results_{task}.json,
      data/q2/summary_{task}.csv, data/q2/ckpt_..., data/q2/run_*.log (UTF-8)
"""
import argparse
import csv
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, E2DIR)
from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS  # noqa: E402
import e2b_rewrite_routing_fixed as E2  # noqa: E402

E2.SEQ = 128          # 位置埋め込みを広げる（既定 95 では T=109 が入らない）。Q1 と同一

# ---------------------------------------------------------------------------
# 語彙とタスク
# ---------------------------------------------------------------------------
DIG = "0123456789"
OPS = "ASDMK"
VOCAB = DIG + OPS + "=:"          # 17 文字（埋め込みは 29 なので収まる）
C2I = {c: i for i, c in enumerate(VOCAB)}
OP_ID = {ch: C2I[ch] for ch in OPS}
ID_EQ, ID_SEP = C2I["="], C2I[":"]

P_STEPS = 10
N_DIG = 8                              # 値は 0..10^8-1
TPI = 2 + N_DIG                        # 1 命令 = [op, '='] + 8 桁
MOD = 10 ** N_DIG
T_LEN = N_DIG + 1 + TPI * P_STEPS      # 109
TRACE0 = N_DIG + 1                     # 9
PAY_LEN = N_DIG

# 難度ラダー（固定プログラム。op は位置で決まる = struct のエントロピー ゼロ）
TASKS = {
    "copy": "ADADSDADAS",       # 値 = 初期値のコピー（glyph は Q1 copy と同じ）
    "compute": "ADADSDADAS",    # Q1 の計算条件
    "hard": "MMMMMMMMMM",       # ×3 を 10 ステップ
    "harder": "KKKKKKKKKK",     # ×7 を 10 ステップ
}
assert all(len(v) == P_STEPS for v in TASKS.values())

# 種別コード
TYP_INPUT, TYP_STRUCT, TYP_PAYLOAD = 0, 1, 2

SMALL = (0, 1)
LARGE = (6, 7)
WIDE = (4, 5, 6, 7)


def apply_op(v, ch):
    """v: (n,) 状態。ch: op 文字。mod 10^8。"""
    if ch == "A":
        return (v + 1) % MOD
    if ch == "S":
        return (v - 1) % MOD
    return (v * {"D": 2, "M": 3, "K": 7}[ch]) % MOD


def make_trace_batch(rng, n, task="compute", p_steps=P_STEPS):
    """-> seq (n,T), typ (n,T)

    Q1 と同一構造。**rng の消費順も同一**（seed 777 で呼べば v0 が全タスクで共通になる）。
    task=copy は値を v0 のコピーにする（Q1 copy と同一）。
    """
    T = N_DIG + 1 + TPI * p_steps
    prog = TASKS[task]
    v0 = rng.integers(0, MOD, size=n).astype(np.int64)
    v = v0.copy()
    seq = np.zeros((n, T), dtype=np.int64)
    typ = np.zeros((n, T), dtype=np.int64)

    for k in range(N_DIG):
        seq[:, k] = (v0 // (10 ** (N_DIG - 1 - k))) % 10
    seq[:, N_DIG] = ID_SEP

    for s in range(p_steps):
        base = N_DIG + 1 + TPI * s
        seq[:, base] = OP_ID[prog[s]]
        typ[:, base] = TYP_STRUCT
        seq[:, base + 1] = ID_EQ
        typ[:, base + 1] = TYP_STRUCT
        if task != "copy":
            v = apply_op(v, prog[s])
        else:
            v = v0
        for k in range(N_DIG):
            seq[:, base + 2 + k] = (v // (10 ** (N_DIG - 1 - k))) % 10
            typ[:, base + 2 + k] = TYP_PAYLOAD
    return seq, typ


# ---------------------------------------------------------------------------
# forward（k を層ごとに変えられる / 許可 expert を絞れる）— Q1 と同一
# ---------------------------------------------------------------------------
def forward_q(model, idx, k_by_layer=None, allow=None, need_idx=False):
    p = model.p
    B, T = idx.shape
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    idx_l = []
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
        if allow is not None:
            mask = torch.full_like(logits, float("-inf"))
            mask[:, list(allow)] = 0.0
            logits = logits + mask
        kl = model.k if k_by_layer is None else k_by_layer[l]
        topv, topi = logits.topk(kl, dim=1)
        gate = torch.softmax(
            torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
        y = torch.zeros_like(h)
        for i in range(model.E):
            tok, _ = (topi == i).nonzero(as_tuple=True)
            if tok.numel() == 0:
                continue
            x = h[tok]
            h1 = F.relu(F.linear(x, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
            y.index_add_(0, tok,
                         F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                         * gate[tok, i].unsqueeze(1))
        h = h + y
        if need_idx:
            idx_l.append(topi.reshape(B, T, -1))
    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, -1)
    return out, idx_l


def trace_loss(logits, seq):
    # 位置 t の logits は t+1 を予測する。TRACE0 以降を当てるには t = TRACE0-1 .. T-2 を見る。
    lg = logits[:, TRACE0 - 1:-1, :len(VOCAB)].reshape(-1, len(VOCAB))
    tgt = torch.from_numpy(seq[:, TRACE0:]).reshape(-1)
    return F.cross_entropy(lg, tgt)


# ---------------------------------------------------------------------------
# 評価
# ---------------------------------------------------------------------------
@torch.no_grad()
def evaluate(model, seq, typ, conds, bs=128):
    n = seq.shape[0]
    assert n == 1024, f"eval n が想定外: {n}"
    dims = np.array(model.dims, dtype=np.float32)
    res = {}
    for cname, (kbl, allow) in conds.items():
        ce = np.zeros((n, T_LEN - TRACE0), dtype=np.float32)
        hit = np.zeros((n, T_LEN - TRACE0), dtype=bool)
        wid = np.zeros((n, T_LEN - TRACE0), dtype=np.float32)
        top1 = np.zeros((n, T_LEN - TRACE0), dtype=np.int64)
        wid_l = np.zeros((model.L, n, T_LEN - TRACE0), dtype=np.float32)
        top1_l = np.zeros((model.L, n, T_LEN - TRACE0), dtype=np.int64)
        for i in range(0, n, bs):
            s = slice(i, min(i + bs, n))
            x = torch.from_numpy(seq[s])
            logits, idx_l = forward_q(model, x, k_by_layer=kbl, allow=allow, need_idx=True)
            lg = logits[:, TRACE0 - 1:-1, :len(VOCAB)]
            tgt = torch.from_numpy(seq[s, TRACE0:])
            lp = F.cross_entropy(lg.reshape(-1, len(VOCAB)), tgt.reshape(-1),
                                 reduction="none").reshape(-1, T_LEN - TRACE0)
            ce[s] = lp.numpy()
            hit[s] = (lg.argmax(-1).numpy() == tgt.numpy())
            for l, ti in enumerate(idx_l):
                # 位置 t のルーティングは t+1 のトークンを予測するときのもの → 種別も t+1 側に合わせる
                a = ti.numpy()[:, TRACE0 - 1:-1, :]
                wid_l[l][s] = dims[a].mean(-1)
                top1_l[l][s] = a[:, :, 0]
                wid[s] += dims[a].mean(-1) / model.L
            top1[s] = top1_l[-1][s]
        ty = typ[:, TRACE0:]
        m_st, m_pl = (ty == TYP_STRUCT), (ty == TYP_PAYLOAD)
        out = {
            "ce_all": float(ce.mean()),
            "ce_struct": float(ce[m_st].mean()),
            "ce_payload": float(ce[m_pl].mean()),
            "acc_struct": float(hit[m_st].mean()),
            "acc_payload": float(hit[m_pl].mean()),
            "width_struct": float(wid[m_st].mean()),
            "width_payload": float(wid[m_pl].mean()),
            "small_struct": float(np.isin(top1[m_st], SMALL).mean()),
            "small_payload": float(np.isin(top1[m_pl], SMALL).mean()),
            "small_struct_l": [float(np.isin(top1_l[l][m_st], SMALL).mean())
                               for l in range(model.L)],
            "small_payload_l": [float(np.isin(top1_l[l][m_pl], SMALL).mean())
                                for l in range(model.L)],
            "usage_l0": np.bincount(top1_l[0].reshape(-1), minlength=model.E).tolist(),
        }
        # ★ payload の桁位置別（MSD→LSD）: 連鎖深さの直結予測用
        # hp: (n, steps, 8)。桁 k = base+2+k の位置。
        hp = hit.reshape(n, P_STEPS, TPI)[:, :, 2:]
        cp = ce.reshape(n, P_STEPS, TPI)[:, :, 2:]
        tp = (ty == TYP_PAYLOAD).reshape(n, P_STEPS, TPI)[:, :, 2:]
        assert tp.all(), "payload mask が桁割りと不一致"
        # top1 は (n, Tout) — reshape の整合を assert してから使う
        assert top1.shape[1] == P_STEPS * TPI
        sp = np.isin(top1.reshape(n, P_STEPS, TPI)[:, :, 2:], SMALL)
        out["acc_payload_bydigit"] = [float(hp[..., k].mean()) for k in range(PAY_LEN)]
        out["ce_payload_bydigit"] = [float(cp[..., k].mean()) for k in range(PAY_LEN)]
        out["small_payload_bydigit"] = [float(sp[..., k].mean()) for k in range(PAY_LEN)]
        # 0-1 損失: 命令単位 / 系列単位
        instr_ok = hp.all(-1)                    # (n, steps)
        out["instr_valid"] = float(instr_ok.all(-1).mean())
        out["instr_acc"] = float(instr_ok.mean())
        out["payload_token_acc"] = float(hp.mean())
        first = np.where(~instr_ok, np.arange(P_STEPS)[None, :], 10 ** 6).min(-1)
        out["first_err_mean"] = float(np.where(first >= 10 ** 6, P_STEPS, first).mean())
        out["seq_valid"] = float((first >= 10 ** 6).mean())
        # ペイロードの誤り率の裾: 上位 1% の系列が全体誤りの何%を占めるか
        tok_err = 1.0 - hp.reshape(n, -1).mean(axis=1)   # (n,) 系列あたり payload 誤り率
        out["err_top1pct_share"] = float(
            np.sort(tok_err)[::-1][:max(1, n // 100)].sum() / (tok_err.sum() + 1e-12))
        res[cname] = out
    return res


# ---------------------------------------------------------------------------
# 訓練
# ---------------------------------------------------------------------------
def run_arm(arm, task, seed, n_seqs, epochs, bs, lr, auxw, outdir, logf):
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    widths = WIDTHS[arm]
    aux_mode = "p_pen" if arm.startswith("H") else "switch"
    model = RewriteMoE(widths, seed=seed)
    opt = Adam(model.params(), lr=lr)
    nparam = sum(v.numel() for v in model.params().values())

    steps_per_ep = max(1, n_seqs // bs)
    t0 = time.time()
    hist = []
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps_per_ep):
            seq, _ = make_trace_batch(rng, bs, task=task)
            x = torch.from_numpy(seq)
            logits, aux, _ = model(x, aux_mode=aux_mode)
            loss = trace_loss(logits, seq) + auxw * aux
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        hist.append(run / steps_per_ep)
        msg = f"    [{arm} {task} s{seed}] ep{ep+1}/{epochs} loss={hist[-1]:.4f} ({time.time()-t0:.0f}s)"
        print(msg, flush=True)
        logf.write(msg + "\n")
        logf.flush()

    ev_rng = np.random.default_rng(777)   # Q1 と同一 seed → v0 が全タスク共通
    seq, typ = make_trace_batch(ev_rng, 1024, task=task)
    conds = {
        "base": (None, None),
        "k1": ([1] * model.L, None),
        "f1": ([1, 1, 2, 2], None),
        "b1": ([2, 2, 1, 1], None),
        "force_small": (None, SMALL),
        "force_large": (None, LARGE),
        "force_wide": (None, WIDE),
    }
    ev = evaluate(model, seq, typ, conds)
    out = {"arm": arm, "seed": seed, "task": task, "nparam": nparam, "loss_hist": hist,
           "n_eval": 1024, "sec": round(time.time() - t0, 1), "eval": ev}
    torch.save({k: v.detach() for k, v in model.params().items()},
               os.path.join(outdir, f"ckpt_{arm}_{task}_s{seed}.pt"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", nargs="+", default=["H+LB", "U+LB"])
    ap.add_argument("--tasks", nargs="+", default=["hard", "harder"],
                    choices=list(TASKS))
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--auxw", type=float, default=0.05)
    ap.add_argument("--outdir", default=None)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--resume", action="store_true",
                    help="n_eval==1024 の完了 json がある (arm,task,seed) をスキップ")
    args = ap.parse_args()

    outdir = args.outdir or os.path.join(E2DIR, "data", "q2")
    os.makedirs(outdir, exist_ok=True)
    torch.set_num_threads(6)
    if args.smoke:
        args.arms, args.seeds, args.tasks = ["H+LB"], [0], ["hard"]

    log_path = os.path.join(outdir, f"run_{'_'.join(args.tasks)}_{int(time.time())}.log")
    logf = open(log_path, "w", encoding="utf-8")

    def w(msg):
        print(msg, flush=True)
        logf.write(msg + "\n")
        logf.flush()

    w(f"T={T_LEN} (init {N_DIG} + sep 1 + trace {TPI*P_STEPS}), d=128, L=4, E=8, k=2, "
      f"VOCAB={len(VOCAB)}, tasks={args.tasks}")
    w(f"seqs={args.seqs} epochs={args.epochs} bs={args.bs} arms={args.arms} out={outdir}")

    rows = []
    for arm in args.arms:
        for task in args.tasks:
            for seed in args.seeds:
                done_path = os.path.join(outdir, f"{arm}_{task}_s{seed}.json")
                if args.resume and os.path.exists(done_path):
                    try:
                        with open(done_path, encoding="utf-8") as f:
                            old = json.load(f)
                        if old.get("n_eval") == 1024 and old.get("task") == task:
                            w(f"  [skip] {arm} {task} s{seed}: 完了済み（resume）")
                            rows.append(old)
                            continue
                    except (json.JSONDecodeError, OSError):
                        w(f"  [warn] {done_path} が読めないので再実行する")
                r = run_arm(arm, task, seed, args.seqs, args.epochs, args.bs, args.lr,
                            args.auxw, outdir, logf)
                rows.append(r)
                e = r["eval"]["base"]
                w(f"  -> {arm} {task} s{seed}: "
                  f"small st/pl = {e['small_struct']:.3f}/{e['small_payload']:.3f} "
                  f"(Δ={e['small_payload']-e['small_struct']:+.3f}) "
                  f"acc st/pl = {e['acc_struct']:.3f}/{e['acc_payload']:.3f} "
                  f"ce_pl = {e['ce_payload']:.3f} instr_valid = {e['instr_valid']:.3f} "
                  f"({r['sec']}s)")
                # per-seed の結果は必ず 1 run すぐ書く（途中で死んでも残す）
                with open(os.path.join(outdir, f"{arm}_{task}_s{seed}.json"), "w",
                          encoding="utf-8") as f:
                    json.dump(r, f, ensure_ascii=False, indent=2)

            with open(os.path.join(outdir, f"q2_results_{task}.json"), "w",
                      encoding="utf-8") as f:
                json.dump([r for r in rows if r["task"] == task], f, ensure_ascii=False, indent=2)

            keys = ["arm", "seed", "ce_all", "ce_struct", "ce_payload", "acc_struct",
                    "acc_payload", "width_struct", "width_payload", "small_struct",
                    "small_payload", "instr_valid", "instr_acc", "payload_token_acc",
                    "seq_valid", "nparam", "sec"]
            with open(os.path.join(outdir, f"summary_{task}.csv"), "w", newline="",
                      encoding="utf-8") as f:
                wr = csv.DictWriter(f, fieldnames=keys)
                wr.writeheader()
                for r in rows:
                    if r["task"] != task:
                        continue
                    row = {k: r[k] for k in ("arm", "seed", "nparam", "sec")}
                    row.update({k: r["eval"]["base"][k] for k in keys
                                if k in r["eval"]["base"]})
                    wr.writerow(row)

    w(f"[write] {outdir}  log={log_path}")
    logf.close()
    os._exit(0)


if __name__ == "__main__":
    main()
