# -*- coding: utf-8 -*-
"""AX2 Step 4: 独立再計算（ax2_layer_cost.py を import しない別経路）。

scipy.stats.ttest_rel 経路で Δ・se・t・p・Holm・TOST・MDE を作り直し、
npz の生配列から決定・mean_k・校正・probe 品質・探索的量をすべて再構築して
ax2_layer_cost.json と突合する。使い方: python _ax2_verify.py [tag]
"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats as scistats

HERE = os.path.dirname(os.path.abspath(__file__))
TAG = sys.argv[1] if len(sys.argv) > 1 else "ax2"
N_FOLD = 5
H_STRATA = (0, 5, 10, 15)
LAM = 10.0
ALPHA = 0.05
DELTA = 0.01
PERM_SEED = 777
PERM_TARGETS = ("c8_00", "c8_15", "c7_08", "d_j")

ITEMS = []
MISMATCH = []


def chk(name, got, exp, rtol=1e-6, atol=1e-9):
    ITEMS.append(name)
    ok = False
    if isinstance(exp, (list, tuple)):
        ok = (list(got) == list(exp))
    elif isinstance(exp, bool) or isinstance(exp, str):
        ok = (got == exp)
    elif isinstance(exp, (int, np.integer)) and isinstance(got, (int, np.integer)):
        ok = (int(got) == int(exp))
    else:
        try:
            ok = math.isclose(float(got), float(exp), rel_tol=rtol, abs_tol=atol)
        except Exception:
            ok = False
    if not ok:
        MISMATCH.append((name, got, exp))


def rst(d, tok_per_win=255):
    """paired stats（scipy ttest_rel 経路）。d は float64。"""
    d = np.asarray(d, dtype=np.float64).ravel()
    n = d.size
    m = float(d.mean())
    t, p = scistats.ttest_rel(d, np.zeros_like(d))
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    tc975 = float(scistats.t.ppf(0.975, n - 1))
    tc95 = float(scistats.t.ppf(0.95, n - 1))
    wm = d.reshape(-1, tok_per_win).mean(axis=1)
    sew = float(wm.std(ddof=1) / math.sqrt(wm.size))
    return {"mean": m, "se": se, "t": float(t), "p_two": float(p),
            "mde": tc975 * se, "ci95": [m - tc975 * se, m + tc975 * se],
            "ci90": [m - tc95 * se, m + tc95 * se],
            "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
            "se_win": sew}


def tost_p(m, se, df, delta):
    p_low = float(scistats.t.sf((m + delta) / se, df))
    p_high = float(scistats.t.cdf((m - delta) / se, df))
    return max(p_low, p_high), p_low, p_high


def holm_adj(pvals):
    ids = sorted(pvals, key=lambda k: pvals[k])
    out, run = {}, 0.0
    for i, k in enumerate(ids):
        run = max(run, (len(ids) - i) * pvals[k])
        out[k] = min(1.0, run)
    return out


def ridge_oof(X, y, groups, lam=LAM):
    pred = np.zeros(len(y))
    for f in range(N_FOLD):
        te = (groups % N_FOLD) == f
        tr = ~te
        if te.any():
            Xtr, Xte = X[tr], X[te]
            ytr = y[tr]
            mu = Xtr.mean(0)
            sd = Xtr.std(0) + 1e-8
            A = (Xtr - mu) / sd
            B = (Xte - mu) / sd
            ym = ytr.mean()
            d = A.shape[1]
            if d <= A.shape[0]:
                w = np.linalg.solve(A.T @ A + lam * np.eye(d), A.T @ (ytr - ym))
            else:
                a = np.linalg.solve(A @ A.T + lam * np.eye(A.shape[0]), ytr - ym)
                w = A.T @ a
            pred[te] = B @ w + ym
    return pred


def spearman(a, b):
    ra = np.argsort(np.argsort(a)).astype(np.float64)
    rb = np.argsort(np.argsort(b)).astype(np.float64)
    ra -= ra.mean()
    rb -= rb.mean()
    return float((ra * rb).sum() / np.sqrt((ra ** 2).sum() * (rb ** 2).sum()))


def gate_stats(G):
    z = G.astype(np.float64)
    p = np.exp(z - z.max(1, keepdims=True))
    p /= p.sum(1, keepdims=True)
    top8 = np.sort(p, axis=1)[:, -8:]
    return np.stack([z.max(1), z.mean(1), z.std(1), top8.sum(1),
                     -(p * np.log(p + 1e-12)).sum(1),
                     (z > 0).sum(1).astype(np.float64),
                     z.max(1) - np.median(z, axis=1)], axis=1)


def main():
    z = np.load(os.path.join(HERE, "%s_layer_cost.npz" % TAG))
    with open(os.path.join(HERE, "%s_layer_cost.json" % TAG), encoding="utf-8") as fp:
        J = json.load(fp)
    n_tok = J["meta"]["n_tok"]
    n_win = J["meta"]["windows"]
    n_eval = n_tok // n_win
    n_layers = 16
    lang = z["lang"]
    wi = z["wi"].astype(np.int64)

    arms = [k[4:] for k in z.files if k.startswith("nll_")]
    N = {a: z["nll_" + a].astype(np.float64) for a in arms}

    # ---- C4 配列健全性 ----
    for a in arms:
        v = z["nll_" + a]
        chk("C4.shape_" + a, v.shape == (n_tok,), True)
        chk("C4.finite_" + a, bool(np.isfinite(v).all()), True)
        chk("C4.nonneg_" + a, bool((v >= 0).all()), True)
    chk("C4.lang_en", bool(np.all(lang[:n_win // 2] == "en")), True)
    chk("C4.lang_ja", bool(np.all(lang[n_win // 2:] == "ja")), True)
    chk("C4.n_arms", len(arms), J["meta"]["n_arms"])

    # ---- 結果表 ----
    for a in arms:
        r = J["results"][a]
        chk("arm.ce_" + a, float(N[a].mean()), r["ce"])
        chk("arm.dce_" + a, float((N[a] - N["u7"]).mean()), r["delta_vs_u7"])
        chk("arm.top1_" + a, float(z["acc1_" + a].mean()), r["top1"])
        if r["mean_k"] is not None and a in J["calib"]["C5"]["mean_k"]:
            chk("arm.meank_" + a, float(r["mean_k"]), float(J["calib"]["C5"]["mean_k"][a]))

    # ---- 確認的統計（ttest_rel 別経路）----
    d1 = N["u7"] - N["lay_swap_oracle"]
    d2 = N["u7"] - N["lay_swap_probe"]
    d3 = N["tok_probe50"] - N["lay_swap_probe"]
    for sid, d, key in (("T1", d1, "T1_lay_oracle"), ("T2", d2, "T2_lay_probe"),
                        ("T3", d3, "T3_lay_probe_vs_tok_probe")):
        s = rst(d, n_eval)
        rj = J["confirmatory"][key]
        for f in ("mean", "se", "t", "p_two", "mde", "se_win"):
            chk("%s.%s" % (sid, f), s[f], rj[f])
        chk("%s.n_pos" % sid, s["n_pos"], rj["n_pos"])
        chk("%s.n_neg" % sid, s["n_neg"], rj["n_neg"])
        chk("%s.ci95_lo" % sid, s["ci95"][0], rj["ci95"][0])
        chk("%s.ci95_hi" % sid, s["ci95"][1], rj["ci95"][1])
        chk("%s.ci90_lo" % sid, s["ci90"][0], rj["ci90"][0])
        chk("%s.ci90_hi" % sid, s["ci90"][1], rj["ci90"][1])
    df3 = n_tok - 1
    m3, se3 = float(d3.mean()), float(d3.std(ddof=1) / math.sqrt(n_tok))
    p_tost, p_low, p_high = tost_p(m3, se3, df3, DELTA)
    to3 = J["confirmatory"]["T3_tost"]
    chk("T3.p_tost", p_tost, to3["p_tost"])
    chk("T3.p_low", p_low, to3["p_low"])
    chk("T3.p_high", p_high, to3["p_high"])
    chk("T3.equivalent", bool((p_tost < ALPHA) and (tc90lo(d3) > -DELTA) and (tc90hi(d3) < DELTA)),
        to3["equivalent"])
    ph = holm_adj({"T1": J["confirmatory"]["T1_lay_oracle"]["p_two"],
                   "T2": J["confirmatory"]["T2_lay_probe"]["p_two"],
                   "T3": p_tost})
    for k, v in ph.items():
        chk("holm." + k, v, J["confirmatory"]["holm"][k])
    # ケースの再判定
    rej = {k: ph[k] < ALPHA for k in ph}
    g1, g2 = float(d1.mean()), float(d2.mean())
    case = ("A" if (rej["T2"] and g2 > 0) else
            "B" if (rej["T1"] and g1 > 0 and not rej["T2"]) else
            "C" if ((not rej["T1"]) and (not rej["T2"]) and rej["T3"]) else
            "D" if (rej["T1"] and g1 < 0) else "UNLISTED")
    chk("case", case, J["confirmatory"]["case"])

    # ---- C1/C2/C3 ----
    z24 = np.load(os.path.join(HERE, "p24_layer_cost.npz"))
    b24 = z24["nll_base"].astype(np.float64)
    c1 = J["calib"]["C1"]
    if c1.get("tier") != "SKIP":
        d_c1 = N["base"] - b24
        chk("C1.maxdiff", float(np.abs(d_c1).max()), c1["maxdiff"])
        chk("C1.meandiff", float(d_c1.mean()), c1["meandiff"])
    else:
        chk("C1.skip", c1["tier"], "SKIP")
    d_c2 = N["mask7"] - N["u7"]
    chk("C2.meandiff", float(d_c2.mean()), J["calib"]["C2"]["meandiff"])
    chk("C2.maxdiff", float(np.abs(d_c2).max()), J["calib"]["C2"]["maxdiff"])
    chk("C2.sd", float(d_c2.std(ddof=1)), J["calib"]["C2"]["sd"])
    zp4 = np.load(os.path.join(HERE, "p4_adaptive_nll.npz"))
    dp4 = zp4["mask7"].astype(np.float64) - zp4["uniform7"].astype(np.float64)
    chk("C2.p4c_meandiff", float(dp4.mean()), J["calib"]["C2"]["p4c_precedent"]["meandiff"])
    j24 = json.load(open(os.path.join(HERE, "p24_layer_cost.json"), encoding="utf-8"))
    bad = 0
    for cname, rj in j24["results"].items():
        arr = z24["nll_" + cname].astype(np.float64)
        if abs(float(arr.mean()) - rj["ce"]) > 1e-6 or abs(float((arr - b24).mean()) - rj["dce"]) > 1e-6:
            bad += 1
    chk("C3.n_bad", bad, J["calib"]["C3"]["n_bad"])

    # ---- 決定の再構築と mean_k（C5/C7）----
    c8f = z["c8"].astype(np.float32)
    c7f = z["c7"].astype(np.float32)
    oof = z["oof"].astype(np.float64)
    pc8 = oof[:, :n_layers].T.astype(np.float32)
    pc7 = oof[:, n_layers:2 * n_layers].T.astype(np.float32)
    cut_o = np.argmin(c7f, axis=0).astype(np.int8)
    prot_o = np.argmax(np.where(np.arange(n_layers)[:, None] == cut_o[None, :], -np.inf, c8f), axis=0).astype(np.int8)
    cut_p = np.argmin(pc7, axis=0).astype(np.int8)
    prot_p = np.argmax(np.where(np.arange(n_layers)[:, None] == cut_p[None, :], -np.inf, pc8), axis=0).astype(np.int8)
    chk("dec.cut_o", int((cut_o != z["cut_o"]).sum()), 0)
    chk("dec.prot_o", int((prot_o != z["prot_o"]).sum()), 0)
    chk("dec.cut_p", int((cut_p != z["cut_p"]).sum()), 0)
    chk("dec.prot_p", int((prot_p != z["prot_p"]).sum()), 0)
    cond_o = (c8f.max(axis=0) - c7f.min(axis=0)) > 0
    cond_p = (pc8.max(axis=0) - pc7.min(axis=0)) > 0
    chk("dec.cond_o", int((cond_o != z["cond_o"]).sum()), 0)
    chk("dec.cond_p", int((cond_p != z["cond_p"]).sum()), 0)

    def kmat_eval(cut, prot):
        km = np.full((n_layers, n_tok), 7, dtype=np.int8)
        km[cut, np.arange(n_tok)] = 6
        km[prot, np.arange(n_tok)] = 8
        return km

    def mean_k_windows(kmat_eval=None, kvec=None, pad_val=7):
        if kvec is not None:
            kv = np.concatenate([kvec, np.full((n_win, 1), pad_val, dtype=np.float32)], axis=1)
            km = np.tile(kv[None, :, :], (n_layers, 1, 1))
        else:
            km = kmat_eval.reshape(n_layers, n_win, n_eval)
            km = np.concatenate([km, np.full((n_layers, n_win, 1), pad_val, dtype=kmat_eval.dtype)], axis=2)
        return float(km.mean())

    def topk_k(mat, f, lo=6, hi=8):
        out = np.full(mat.shape, lo, dtype=np.float32)
        m = int(round(f * mat.size))
        order = np.argsort(-mat.ravel())
        keep = np.zeros(mat.size, bool)
        keep[order[:m]] = True
        out.ravel()[keep] = hi
        return out

    d_j = z["d_j"].astype(np.float32)
    kv_o = topk_k(d_j.reshape(n_win, n_eval), 0.5)
    kv_p = topk_k(oof[:, 2 * n_layers].astype(np.float32).reshape(n_win, n_eval), 0.5)
    exp_mk = {"base": 8.0, "u7": 7.0, "u6": 6.0, "mask7": 7.0,
              "tok_oracle50": mean_k_windows(kvec=kv_o, pad_val=6),
              "tok_probe50": mean_k_windows(kvec=kv_p, pad_val=6),
              "lay_swap_oracle": mean_k_windows(kmat_eval=kmat_eval(cut_o, prot_o)),
              "lay_swap_probe": mean_k_windows(kmat_eval=kmat_eval(cut_p, prot_p)),
              "lay_swap_oracle_cond": mean_k_windows(
                  kmat_eval=np.where(cond_o[None, :], kmat_eval(cut_o, prot_o), np.int8(7)).astype(np.int8)),
              "lay_swap_probe_cond": mean_k_windows(
                  kmat_eval=np.where(cond_p[None, :], kmat_eval(cut_p, prot_p), np.int8(7)).astype(np.int8))}
    for L in range(n_layers):
        exp_mk["ab7_%02d" % L] = (15 * 8 + 7) / 16
        exp_mk["ab6_%02d" % L] = (15 * 8 + 6) / 16
    for a, v in exp_mk.items():
        chk("C5." + a, float(J["calib"]["C5"]["mean_k"][a]), v)
        chk("C5.exp_" + a, float(J["calib"]["C5"]["expected"][a]), v)
    conf_o = int((np.argmax(c8f, axis=0) == cut_o).sum())
    conf_p = int((np.argmax(pc8, axis=0) == cut_p).sum())
    chk("C7.conflict_o", conf_o, J["calib"]["C7"]["conflict_oracle"])
    chk("C7.conflict_p", conf_p, J["calib"]["C7"]["conflict_probe"])
    chk("C7.swap_o", float(cond_o.mean()), J["calib"]["C7"]["swap_rate_oracle_cond"])
    chk("C7.swap_p", float(cond_p.mean()), J["calib"]["C7"]["swap_rate_probe_cond"])
    for i in range(n_layers):
        chk("C7.cut_hist_o_%02d" % i, int((z["cut_o"] == i).sum()), J["calib"]["C7"]["cut_hist_oracle"][i])
        chk("C7.prot_hist_o_%02d" % i, int((z["prot_o"] == i).sum()), J["calib"]["C7"]["prot_hist_oracle"][i])

    # ---- probe 品質の再計算（oof 列は c8 ブロック→c7 ブロック→d_j の順）----
    oof_cols = ["c8_%02d" % L for L in range(n_layers)] \
        + ["c7_%02d" % L for L in range(n_layers)] + ["d_j"]
    chk("meta.oof_columns", J["meta"].get("oof_columns", oof_cols), oof_cols)
    tdict = {}
    for L in range(n_layers):
        tdict["c8_%02d" % L] = z["c8"][L].astype(np.float64)
        tdict["c7_%02d" % L] = z["c7"][L].astype(np.float64)
    tdict["d_j"] = z["d_j"].astype(np.float64)
    for i, nm in enumerate(oof_cols):
        y = tdict[nm]
        pred = oof[:, i]
        r2 = 1.0 - float(((y - pred) ** 2).sum() / ((y - y.mean()) ** 2).sum())
        chk("probe.rho_" + nm, spearman(y, pred), J["probe_quality"][nm]["spearman"])
        chk("probe.r2_" + nm, r2, J["probe_quality"][nm]["r2"])

    # ---- 探索的量 ----
    E = J["exploratory"]
    for key, (a, b) in {"G_tok_oracle": ("u7", "tok_oracle50"),
                        "G_tok_probe50": ("u7", "tok_probe50"),
                        "G_lay_oracle_cond": ("u7", "lay_swap_oracle_cond"),
                        "G_lay_probe_cond": ("u7", "lay_swap_probe_cond"),
                        "G_lay_oracle_maskref": ("mask7", "lay_swap_oracle"),
                        "G_lay_probe_maskref": ("mask7", "lay_swap_probe"),
                        "G_tok_oracle_maskref": ("mask7", "tok_oracle50"),
                        "G_tok_probe50_maskref": ("mask7", "tok_probe50")}.items():
        chk("exp." + key, float((N[a] - N[b]).mean()), E[key]["mean"])
    chk("exp.c8_mean_0", float(z["c8"][0].mean()), E["c8_mean"][0])
    chk("exp.c7_mean_15", float(z["c7"][15].mean()), E["c7_mean"][15])
    chk("exp.rho_glob", float((N["u6"].mean() - N["u7"].mean()) / (N["u7"].mean() - N["base"].mean())),
        E["rho_glob"])
    for g, ls in {"G0": range(0, 4), "G1": range(4, 8), "G2": range(8, 12), "G3": range(12, 16)}.items():
        if g in E["additivity_p24"]:
            chk("exp.add_%s" % g, float(z["c8"][list(ls)].sum(axis=0).mean()),
                E["additivity_p24"][g]["sum_ab7"])

    # ---- C6 permutation の独立再実行 ----
    X = z["X"].astype(np.float64)
    perm = np.random.RandomState(PERM_SEED).permutation(n_tok)
    # 特徴列の再構築（層内因果の列マップ）
    nfeat = X.shape[1]
    hcol0 = n_layers * 71
    hist_col = hcol0 + 256 * len(H_STRATA)

    def cols_for_layer(L):
        cs = list(range(0, 71 * (L + 1)))
        for si, s in enumerate(H_STRATA):
            if s <= L:
                cs += list(range(hcol0 + 256 * si, hcol0 + 256 * (si + 1)))
        cs += list(range(hist_col, nfeat))
        return np.array(cs)

    cols_tok = []
    for l in (0, 4, 8, 12, 15):
        cols_tok += list(range(71 * l, 71 * (l + 1)))
    cols_tok += list(range(hcol0, nfeat))
    cols_tok = np.array(cols_tok)
    perm_map = {"c8_00": (tdict["c8_00"], cols_for_layer(0)),
                "c8_15": (tdict["c8_15"], cols_for_layer(15)),
                "c7_08": (tdict["c7_08"], cols_for_layer(8)),
                "d_j": (tdict["d_j"], cols_tok)}
    for nm in PERM_TARGETS:
        y, cs = perm_map[nm]
        pred = ridge_oof(X[:, cs], y[perm], wi, LAM)
        chk("C6.perm_" + nm, spearman(y[perm], pred), J["calib"]["C6"]["perm_stats"][nm])

    # ---- まとめ ----
    lines = ["AX2 Step 4 verify (tag=%s)" % TAG,
             "items=%d  mismatches=%d" % (len(ITEMS), len(MISMATCH))]
    for nm, got, exp in MISMATCH[:20]:
        lines.append("  MISMATCH %s: got=%r exp=%r" % (nm, got, exp))
    txt = "\n".join(lines)
    print(txt)
    with open(os.path.join(HERE, "_ax2_verify_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write(txt + "\n")


def tc90lo(d):
    d = np.asarray(d, dtype=np.float64).ravel()
    m, se = float(d.mean()), float(d.std(ddof=1) / math.sqrt(d.size))
    return m - float(scistats.t.ppf(0.95, d.size - 1)) * se


def tc90hi(d):
    d = np.asarray(d, dtype=np.float64).ravel()
    m, se = float(d.mean()), float(d.std(ddof=1) / math.sqrt(d.size))
    return m + float(scistats.t.ppf(0.95, d.size - 1)) * se


if __name__ == "__main__":
    main()
