"""H8b の解析: routing (token/expert-choice) × sizes (均一/不均一) の 2x2。

要因計画なので、主効果と交互作用を paired seed で分解する。

  routing の主効果  = [(ec_het − tok_het) + (ec_uni − tok_uni)] / 2
  sizes の主効果    = [(tok_het − tok_uni) + (ec_het − ec_uni)] / 2
  交互作用          = (ec_het − ec_uni) − (tok_het − tok_uni)
"""
import json
import os
import sys
from collections import defaultdict

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SUCCESS = 0.5
ORDER = ["tok_uni_k2", "tok_het_aux", "ec_uni", "ec_het"]
LABEL = {
    "tok_uni_k2": "token-choice / 均一",
    "tok_het_aux": "token-choice / 不均一",
    "ec_uni": "expert-choice / 均一",
    "ec_het": "expert-choice / 不均一",
}


def paired(a, b):
    d = np.asarray(a, float) - np.asarray(b, float)
    n = d.size
    if n < 2:
        return d.mean() if n else float("nan"), float("nan"), float("nan"), n
    se = d.std(ddof=1) / np.sqrt(n)
    t = d.mean() / se if se > 0 else float("inf")
    return d.mean(), se, t, n


def main():
    fname = sys.argv[1] if len(sys.argv) > 1 else "h8b_results.jsonl"
    rows = []
    with open(os.path.join(HERE, fname), encoding="utf-8") as fp:
        for line in fp:
            if line.strip():
                rows.append(json.loads(line))
    if not rows:
        print("no data")
        return
    by = defaultdict(dict)
    for r in rows:
        by[r["cond"]][r["seed"]] = r
    conds = [c for c in ORDER if c in by]
    seeds = sorted(set.intersection(*[set(by[c]) for c in conds]))

    print("file: %s   seed %d 本: %s" % (fname, len(seeds), seeds))

    print("\n=== 条件別（平均 ± SD）===")
    print("%-24s %7s %7s %7s %7s %7s %7s %6s %6s" %
          ("条件", "val", "sd", "cost", "d1", "d1_sd", "share", "成功", "死"))
    for c in conds:
        rs = [by[c][s] for s in seeds]
        v = np.array([r["val"] for r in rs])
        cost = np.array([r["cost"] for r in rs])
        d1 = np.array([r["cells"]["depth1"] for r in rs])
        sh = np.array([r["diag"]["depth1"]["top1_share"] for r in rs])
        dead = np.array([r["diag"]["_dead"] for r in rs])
        print("%-24s %7.3f %7.3f %7.3f %7.3f %7.3f %7.3f %6s %6.1f" %
              (LABEL[c], v.mean(), v.std(ddof=1), cost.mean(), d1.mean(),
               d1.std(ddof=1), sh.mean(), f"{int((d1 < SUCCESS).sum())}/{len(d1)}",
               dead.mean()))

    def vec(c, key):
        return [by[c][s][key] if key == "val" else by[c][s]["cells"][key] for s in seeds]

    for metric, getter in (("depth1 CE", lambda c: vec(c, "depth1")),
                           ("val", lambda c: vec(c, "val"))):
        print(f"\n=== {metric} の 2x2 分解（paired, 負なら前者が良い）===")
        print("%-34s %8s %8s %8s %4s" % ("効果", "Δ", "se", "t", "n"))
        need = ["tok_uni_k2", "tok_het_aux", "ec_uni", "ec_het"]
        if not all(c in by for c in need):
            print("  （4 条件が揃っていない）")
            continue
        A = {c: np.array(getter(c), float) for c in need}
        combos = [
            ("routing|不均一: ec_het − tok_het", A["ec_het"] - A["tok_het_aux"]),
            ("routing|均一:   ec_uni − tok_uni", A["ec_uni"] - A["tok_uni_k2"]),
            ("sizes|token:   tok_het − tok_uni", A["tok_het_aux"] - A["tok_uni_k2"]),
            ("sizes|expert:  ec_het − ec_uni", A["ec_het"] - A["ec_uni"]),
            ("routing 主効果", ((A["ec_het"] - A["tok_het_aux"]) + (A["ec_uni"] - A["tok_uni_k2"])) / 2),
            ("sizes 主効果", ((A["tok_het_aux"] - A["tok_uni_k2"]) + (A["ec_het"] - A["ec_uni"])) / 2),
            ("交互作用", (A["ec_het"] - A["ec_uni"]) - (A["tok_het_aux"] - A["tok_uni_k2"])),
        ]
        for name, d in combos:
            n = d.size
            se = d.std(ddof=1) / np.sqrt(n) if n > 1 else float("nan")
            t = d.mean() / se if se and se > 0 else float("nan")
            print("%-34s %8.3f %8.3f %8.2f %4d" % (name, d.mean(), se, t, n))

    print("\n=== 個別 seed の depth1 CE ===")
    print("%-24s %s" % ("条件", " ".join(f"s{s}" for s in seeds)))
    for c in conds:
        print("%-24s %s" % (LABEL[c], " ".join("%6.3f" % by[c][s]["cells"]["depth1"] for s in seeds)))

    print("\n=== depth 別の平均活性幅（seed 平均）===")
    print("%-24s %8s %8s %8s" % ("条件", "depth1", "depth2", "depth3"))
    for c in conds:
        rs = [by[c][s] for s in seeds]
        w = [np.mean([r["diag"][k]["width"] for r in rs]) for k in ("depth1", "depth2", "depth3")]
        print("%-24s %8.2f %8.2f %8.2f" % (LABEL[c], *w))

    print("\n=== per-expert 使用率（seed 平均）===")
    for c in conds:
        u = np.mean([by[c][s]["diag"]["_usage"] for s in seeds], axis=0)
        print("%-24s %s" % (LABEL[c], " ".join("%.2f" % x for x in u)))


if __name__ == "__main__":
    main()
