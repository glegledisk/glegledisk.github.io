#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""W4: 裾が実測できる eval プローブで検定 D を再走する。

事前登録: `W4課題設計書_長尾evalプローブ再走_20261106.md`。
訓練は元ハーネス `corpus_common.run_model` をそのまま呼んでビット一致させ、
eval だけを帯層化＋ペア構造のプローブに差し替える。

出力: w4_results.json / w4_delta.npz / w4_analysis.json / w4_out_utf8.txt
"""
import argparse
import json
import math
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
CORPUS = os.path.join(HERE, "不均一MoE-Corpus")
for _p in (HERE, CORPUS):
    if _p not in sys.path:
        sys.path.insert(0, _p)
import corpus_common as C  # noqa: E402

PROBE_SEED_BASE = 3000
N_PROBE_SEQ = 512
P_STRAT = 0.30          # 設計書 追記 2: 30% 帯層化 / 70% Zipf
SEQ_LEN = C.SEQ_LEN
HEAD_HI = int(C.V_IDENT * C.HEAD_Q)
TAIL_LO = int(C.V_IDENT * (1.0 - C.TAIL_Q))
TEACHER_WIDTHS = (224, 224, 224, 224)
ARM_WIDTHS = {"E": (C.WIDTH_UNIFORM, C.WIDTH_UNIFORM),
              "H": tuple(C.WIDTH_LADDER)}
ARMS = ("E", "H")
SEEDS = tuple(range(13))
BITS = math.log2(C.VOCAB)


def log_line(fh, msg):
    print(msg, flush=True)
    fh.write(msg + "\n")
    fh.flush()


# ---------------------------------------------------------------------------
def make_probe(seed, n_seq=N_PROBE_SEQ, p_strat=P_STRAT):
    """帯層化＋gap-3 ブロック構造の eval プローブ。訓練分布は一切変えない。

    copy_mask は lag >= 1 しか見ない（corpus_common.make_corpus と同一）。
    したがって隣接重複 (pos, pos+1) は copy にならない。(X, filler, X) の
    3 トークンブロックにすると、t = pos+1 の予測対象が X になり、
    X が t-1 に存在するため lag=1 で copy_mask が立つ。

    rank は p_strat の確率で 3 帯層化、残りは訓練と同じ Zipf から引く。
    純粋な層化プローブはモデルを全コピー対象で chance に落とし
    （smoke で CE_copy ≈ 9.7 nats、正解 0）、測定器として機能しなかった。
    混合にすることで頭部は訓練分布を保ちつつ裾事象を確保する。
    """
    rng = np.random.default_rng(PROBE_SEED_BASE + int(seed))
    shape = (n_seq, SEQ_LEN)
    ranks = np.zeros(shape, dtype=np.int64)
    is_syntax = np.zeros(shape, dtype=bool)
    tokens = np.zeros(shape, dtype=np.int64)
    bands = ((0, HEAD_HI), (HEAD_HI, TAIL_LO), (TAIL_LO, C.V_IDENT))
    cdf = C.zipf_cdf()

    for row in range(n_seq):
        pos = 0
        while pos + 2 < SEQ_LEN:
            if rng.random() < p_strat:
                b = int(rng.integers(0, 3))
                lo, hi = bands[b]
                r = int(rng.integers(lo, hi))
            else:
                r = int(np.searchsorted(cdf, rng.random(), side="right"))
                r = min(r, C.V_IDENT - 1)
            tokens[row, pos] = C.V_SYNTAX + r
            tokens[row, pos + 2] = C.V_SYNTAX + r
            ranks[row, pos] = r
            ranks[row, pos + 2] = r
            # 全体の構文率が P0 の 0.25 になるよう、filler は 0.75 で構文
            if rng.random() < 0.75:
                tokens[row, pos + 1] = int(rng.integers(0, C.V_SYNTAX))
                is_syntax[row, pos + 1] = True
                ranks[row, pos + 1] = int(rng.integers(0, C.V_IDENT))
            else:
                r2 = int(rng.integers(0, C.V_IDENT))
                tokens[row, pos + 1] = C.V_SYNTAX + r2
                ranks[row, pos + 1] = r2
            pos += 3
        while pos < SEQ_LEN:
            tokens[row, pos] = int(rng.integers(0, C.V_SYNTAX))
            is_syntax[row, pos] = True
            ranks[row, pos] = int(rng.integers(0, C.V_IDENT))
            pos += 1
    types = rng.integers(0, C.N_TYPES, size=shape, dtype=np.int64)

    next_tok = np.zeros(shape, dtype=np.int64)
    next_tok[:, :-1] = tokens[:, 1:]
    next_syntax = np.ones(shape, dtype=bool)
    next_syntax[:, :-1] = is_syntax[:, 1:]

    copy_mask = np.zeros(shape, dtype=bool)
    for lag in range(1, C.COPY_WINDOW + 1):
        prev = np.zeros(shape, dtype=np.int64)
        prev[:, lag:] = tokens[:, :-lag]
        copy_mask |= (prev == next_tok)
    copy_mask &= ~next_syntax
    copy_mask[:, -1] = False

    target_rank = np.full(shape, -1, dtype=np.int64)
    target_rank[:, :-1] = ranks[:, 1:]
    target_rank[next_syntax] = -1

    return {"tokens": tokens, "types": types, "next_tok": next_tok,
            "copy_mask": copy_mask, "target_rank": target_rank,
            "input_rank": ranks, "is_syntax": is_syntax}


@torch.no_grad()
def probe_eval(model, probe, seed, policies, device):
    """全系列・全チャンクを方策ごとに forward して指標を集約する。"""
    n_seq, L = probe["tokens"].shape
    batch, chunk = 16, 64
    acc = {p: {"ce_sum": 0.0, "n_all": 0,
               "copy_sum": 0.0, "n_copy": 0,
               "head_sum": 0.0, "n_head": 0,
               "tail_sum": 0.0, "n_tail": 0,
               "head_hit": 0, "tail_hit": 0,
               "distinct": set(), "distinct_tail": set()}
           for p in policies}
    counts = {"n_copy": 0, "n_head": 0, "n_tail": 0}
    ci = 0
    for s0 in range(0, n_seq, batch):
        rows = slice(s0, min(s0 + batch, n_seq))
        for t0 in range(0, L, chunk):
            sl = slice(t0, min(t0 + chunk, L))
            x = torch.from_numpy(probe["tokens"][rows, sl]).to(device)
            y = torch.from_numpy(probe["next_tok"][rows, sl]).to(device)
            cm = torch.from_numpy(probe["copy_mask"][rows, sl]).to(device)
            ty = torch.from_numpy(probe["types"][rows, sl]).to(device)
            tr = torch.from_numpy(probe["target_rank"][rows, sl]).to(device)
            head_m = cm & (tr >= 0) & (tr < HEAD_HI)
            tail_m = cm & (tr >= TAIL_LO)
            counts["n_copy"] += int(cm.sum())
            counts["n_head"] += int(head_m.sum())
            counts["n_tail"] += int(tail_m.sum())

            for pol in policies:
                prng = np.random.default_rng(PROBE_SEED_BASE + int(seed)
                                             + 977 + ci)
                logits, _, _ = model(x, policy=pol, types=ty, rng=prng)
                loss = F.cross_entropy(logits.reshape(-1, C.VOCAB),
                                       y.reshape(-1),
                                       reduction="none").view(y.shape)
                corr = (logits.argmax(-1) == y)
                a = acc[pol]
                a["ce_sum"] += float(loss.sum().cpu())
                a["n_all"] += int(loss.numel())
                a["copy_sum"] += float(loss[cm].sum().cpu())
                a["n_copy"] += int(cm.sum())
                a["head_sum"] += float(loss[head_m].sum().cpu())
                a["n_head"] += int(head_m.sum())
                a["tail_sum"] += float(loss[tail_m].sum().cpu())
                a["n_tail"] += int(tail_m.sum())
                a["head_hit"] += int(corr[head_m].sum())
                a["tail_hit"] += int(corr[tail_m].sum())
                hit = (corr & cm).detach().cpu().numpy()
                yt = y.detach().cpu().numpy()
                a["distinct"].update(np.unique(yt[hit]).tolist())
                ht = (corr & tail_m).detach().cpu().numpy()
                a["distinct_tail"].update(np.unique(yt[ht]).tolist())
            ci += 1

    out = {}
    for p, a in acc.items():
        out[p] = {
            "ce_all": a["ce_sum"] / max(1, a["n_all"]),
            "ce_copy": a["copy_sum"] / max(1, a["n_copy"]),
            "ce_copy_head": a["head_sum"] / max(1, a["n_head"]),
            "ce_copy_tail": a["tail_sum"] / max(1, a["n_tail"]),
            "ps_head": a["head_hit"] / max(1, a["n_head"]),
            "ps_tail": a["tail_hit"] / max(1, a["n_tail"]),
            "n_recalled_distinct": len(a["distinct"]),
            "n_recalled_distinct_tail": len(a["distinct_tail"]),
        }
    return {"policies": out, "counts": counts, "n_chunks": ci}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="w4")
    ap.add_argument("--seeds", nargs="+", type=int, default=list(SEEDS))
    ap.add_argument("--arms", nargs="+", default=list(ARMS))
    ap.add_argument("--n-probe-seq", type=int, default=N_PROBE_SEQ)
    ap.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    torch.set_num_threads(1)

    tag = args.tag
    LOG = os.path.join(HERE, f"{tag}_out_utf8.txt")
    if os.path.exists(LOG):
        os.remove(LOG)
    fh = open(LOG, "a", encoding="utf-8")

    def log(m):
        log_line(fh, m)

    log(f"W4: seeds={args.seeds} arms={args.arms} probe_seq={args.n_probe_seq} "
        f"device={args.device} smoke={args.smoke} threads=1")
    log(f"  probe: {args.n_probe_seq}x{SEQ_LEN} tokens, "
        f"head<{HEAD_HI}, tail>={TAIL_LO}, bits/token={BITS:.9f}")

    ref = np.load(os.path.join(CORPUS, "full_d_delta.npz"))
    rows, calib = [], []
    probe_diag = []
    for seed in args.seeds:
        cfg = C.RunConfig(tag=tag, seed=seed, epochs=40, batches=8,
                          n_seq=4000, batch=16, chunk=64,
                          device=args.device, smoke=False)
        probe = make_probe(seed, args.n_probe_seq)
        prank = probe["input_rank"].ravel()
        hist = np.bincount(prank, minlength=C.V_IDENT)
        diag = {"seed": seed,
                "observed_zero_bins": int((hist == 0).sum()),
                "observed_nonzero_bins": int((hist > 0).sum()),
                "observed_tokens": int(hist.sum()),
                "tail_input_tokens": int(hist[TAIL_LO:].sum()),
                "head_input_tokens": int(hist[:HEAD_HI].sum())}

        # --- teacher（元 D と同一訓練）。learned のみプローブ評価 ---
        t = C.run_model(cfg, widths=TEACHER_WIDTHS)
        tp = t["policies"]["learned"]
        calib.append({"seed": seed, "arm": "teacher", "field": "ps_tail",
                      "got": float(tp["ps_tail"]),
                      "want": float(ref["ps_tail"][seed]),
                      "bit_match": bool(abs(float(tp["ps_tail"]) -
                                            float(ref["ps_tail"][seed])) < 1e-12)})
        calib.append({"seed": seed, "arm": "teacher",
                      "field": "n_recalled_distinct",
                      "got": int(tp["n_recalled_distinct"]),
                      "want": int(round(float(ref["cap_teacher_bits"][seed]) / BITS)),
                      "bit_match": bool(int(tp["n_recalled_distinct"]) ==
                                        int(round(float(ref["cap_teacher_bits"][seed]) / BITS)))})
        tres = probe_eval(t["model"], probe, seed, ("learned",), args.device)
        diag["n_copy"] = tres["counts"]["n_copy"]
        diag["n_head"] = tres["counts"]["n_head"]
        diag["n_tail"] = tres["counts"]["n_tail"]
        diag["teacher_conv"] = int(t["summary"]["converged"])
        rows.append({"seed": seed, "arm": "T", "legacy": {
            k: tp[k] for k in ("ps_head", "ps_tail", "ce_copy_head",
                               "ce_copy_tail", "n_recalled_distinct")},
            "probe": tres["policies"]["learned"],
            "converged": int(t["summary"]["converged"])})
        del t["model"], t
        if args.device.startswith("cuda") and torch.cuda.is_available():
            torch.cuda.empty_cache()

        # --- student 各腕 ---
        for arm in args.arms:
            s = C.run_model(cfg, widths=ARM_WIDTHS[arm])
            sp = s["policies"]
            if arm == "E":
                for pol, key in (("uniform", "ps_tail_uniform"),
                                 ("random", "ps_tail_random"),
                                 ("oracle", "ps_tail_oracle"),
                                 ("learned", "ps_tail")):
                    got, want = float(sp[pol]["ps_tail"]), float(ref[key][seed])
                    calib.append({"seed": seed, "arm": "E", "field": key,
                                  "got": got, "want": want,
                                  "bit_match": bool(abs(got - want) < 1e-12)})
                got = int(sp["learned"]["n_recalled_distinct"])
                want = int(round(float(ref["cap_student_bits"][seed]) / BITS))
                calib.append({"seed": seed, "arm": "E",
                              "field": "cap_student_bits",
                              "got": got, "want": want,
                              "bit_match": bool(got == want)})
            sres = probe_eval(s["model"], probe, seed,
                              C.POLICIES + ("learned",), args.device)
            rows.append({"seed": seed, "arm": arm, "legacy": {
                k: sp["learned"][k] for k in
                ("ps_head", "ps_tail", "ce_copy_head", "ce_copy_tail",
                 "n_recalled_distinct")},
                "probe": {p: sres["policies"][p] for p in C.POLICIES + ("learned",)},
                "converged": int(s["summary"]["converged"])})
            log(f"  s{seed} {arm}: tail_tokens={diag['n_tail']} "
                f"ps_tail(u/r/o)={sres['policies']['uniform']['ps_tail']:.4f}/"
                f"{sres['policies']['random']['ps_tail']:.4f}/"
                f"{sres['policies']['oracle']['ps_tail']:.4f} "
                f"distinct(learned)={sres['policies']['learned']['n_recalled_distinct']}")
            del s["model"], s
            if args.device.startswith("cuda") and torch.cuda.is_available():
                torch.cuda.empty_cache()
        probe_diag.append(diag)
        log(f"  s{seed}: zero_bins={diag['observed_zero_bins']} "
            f"copy/head/tail={diag['n_copy']}/{diag['n_head']}/{diag['n_tail']} "
            f"T_conv={diag['teacher_conv']}")

    # ---------------- 集計 ----------------
    def by(arm):
        return sorted([r for r in rows if r["arm"] == arm],
                      key=lambda r: r["seed"])

    T = by("T")
    arr = {"seeds": np.asarray(args.seeds),
           "probe_zero_bins": np.asarray([d["observed_zero_bins"] for d in probe_diag]),
           "probe_tail_tokens": np.asarray([d["n_tail"] for d in probe_diag]),
           "probe_copy_tokens": np.asarray([d["n_copy"] for d in probe_diag])}
    analysis_arms = {}
    for arm in args.arms:
        S = by(arm)
        cap_t = np.asarray([T[i]["probe"]["n_recalled_distinct"] * BITS
                            for i in range(len(S))], dtype=np.float64)
        cap_s = np.asarray([r["probe"]["learned"]["n_recalled_distinct"] * BITS
                            for r in S], dtype=np.float64)
        with np.errstate(divide="ignore", invalid="ignore"):
            ratio = np.where(cap_s > 0, cap_t / cap_s, np.nan)
        cap_stat = C.paired(cap_t, cap_s)
        n_zero_cap_s = int(np.sum(cap_s == 0))
        d3 = C.paired(np.asarray([r["probe"]["learned"]["ce_copy_tail"] for r in S]),
                      np.asarray([r["probe"]["learned"]["ce_copy_head"] for r in S]))
        d4 = C.paired(np.asarray([r["probe"]["learned"]["ps_head"] for r in S]),
                      np.asarray([r["probe"]["learned"]["ps_tail"] for r in S]))
        u = float(np.mean([r["probe"]["uniform"]["ps_tail"] for r in S]))
        rr = float(np.mean([r["probe"]["random"]["ps_tail"] for r in S]))
        o = float(np.mean([r["probe"]["oracle"]["ps_tail"] for r in S]))
        gain = o - u
        opened = bool(gain >= C.TH_D_ORACLE_GAIN and u < rr < o
                      and not (u == rr == o))
        cap_ok = bool(n_zero_cap_s < len(S) / 2
                      and np.isfinite(float(np.nanmean(ratio)))
                      and float(np.nanmean(ratio)) >= C.TH_D_RCAP
                      and cap_stat["p"] < C.ALPHA)
        analysis_arms[arm] = {
            "cap_ratio_mean": (float(np.nanmean(ratio))
                               if np.isfinite(np.nanmean(ratio)) else None),
            "cap_ratio_per_seed": ratio.tolist(),
            "distinct_teacher": [int(round(v / BITS)) for v in cap_t],
            "distinct_student": [int(round(v / BITS)) for v in cap_s],
            "n_zero_cap_student": n_zero_cap_s,
            "cap_stat": cap_stat,
            "D3": d3, "D4": d4,
            "D5": {"uniform": u, "random": rr, "oracle": o,
                   "oracle_gain": gain, "opened": opened,
                   "head_uniform": float(np.mean(
                       [r["probe"]["uniform"]["ps_head"] for r in S])),
                   "head_random": float(np.mean(
                       [r["probe"]["random"]["ps_head"] for r in S])),
                   "head_oracle": float(np.mean(
                       [r["probe"]["oracle"]["ps_head"] for r in S])),
                   "distinct_tail_uniform": float(np.mean(
                       [r["probe"]["uniform"]["n_recalled_distinct_tail"] for r in S])),
                   "distinct_tail_random": float(np.mean(
                       [r["probe"]["random"]["n_recalled_distinct_tail"] for r in S])),
                   "distinct_tail_oracle": float(np.mean(
                       [r["probe"]["oracle"]["n_recalled_distinct_tail"] for r in S]))},
            "W4_1_capacity_ok": cap_ok,
            "W4_2_controls_open": opened,
            "W4_3_prediction_supported": bool(cap_ok and opened),
            "converged": int(sum(r["converged"] for r in S)),
            "n": len(S),
        }
        arr[f"cap_t_{arm}"] = cap_t
        arr[f"cap_s_{arm}"] = cap_s
        arr[f"ratio_{arm}"] = ratio
        arr[f"d3_{arm}"] = np.asarray([r["probe"]["learned"]["ce_copy_tail"] -
                                       r["probe"]["learned"]["ce_copy_head"] for r in S])
        arr[f"d4_{arm}"] = np.asarray([r["probe"]["learned"]["ps_head"] -
                                       r["probe"]["learned"]["ps_tail"] for r in S])
        for p in C.POLICIES:
            arr[f"ps_tail_{p}_{arm}"] = np.asarray(
                [r["probe"][p]["ps_tail"] for r in S])
            arr[f"ps_head_{p}_{arm}"] = np.asarray(
                [r["probe"][p]["ps_head"] for r in S])
            arr[f"distinct_tail_{p}_{arm}"] = np.asarray(
                [r["probe"][p]["n_recalled_distinct_tail"] for r in S])

    calib_ok = all(c["bit_match"] for c in calib)
    sens_ok = bool(np.mean(arr["probe_zero_bins"]) < 2000
                   and np.mean(arr["probe_tail_tokens"]) > 1000)
    analysis = {
        "calibration": {"items": calib, "n": len(calib),
                        "all_bit_match": bool(calib_ok)},
        "sensitivity": {"mean_zero_bins": float(np.mean(arr["probe_zero_bins"])),
                        "mean_tail_tokens": float(np.mean(arr["probe_tail_tokens"])),
                        "mean_copy_tokens": float(np.mean(arr["probe_copy_tokens"])),
                        "ok": sens_ok},
        "probe_diagnostics": probe_diag,
        "arms": analysis_arms,
        "thresholds": {"TH_D_RCAP": C.TH_D_RCAP, "ALPHA": C.ALPHA,
                       "TH_D_ORACLE_GAIN": C.TH_D_ORACLE_GAIN,
                       "TH_D_TAIL_CE": C.TH_D_TAIL_CE,
                       "TH_D_PS_GAP": C.TH_D_PS_GAP},
        "verdict": {
            "primary_arm": "E" if "E" in analysis_arms else args.arms[0],
            "W4_3_prediction_supported": bool(
                analysis_arms.get("E", {}).get("W4_3_prediction_supported", False)),
            "calibration_ok": bool(calib_ok),
            "sensitivity_ok": sens_ok,
        },
        "meta": {"seeds": list(args.seeds), "arms": list(args.arms),
                 "n_probe_seq": args.n_probe_seq, "device": args.device,
                 "smoke": args.smoke, "n_rows": len(rows),
                 "probe_seq_len": SEQ_LEN, "bits_per_token": BITS,
                 "head_hi": HEAD_HI, "tail_lo": TAIL_LO,
                 "p_strat": P_STRAT},
    }
    with open(os.path.join(HERE, f"{tag}_results.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2, default=float)
    np.savez_compressed(os.path.join(HERE, f"{tag}_delta.npz"), **arr)
    with open(os.path.join(HERE, f"{tag}_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2, default=float)

    log("")
    log(f"== 校正: {sum(c['bit_match'] for c in calib)}/{len(calib)} "
        f"bit-match  all={calib_ok}")
    for c in calib:
        if not c["bit_match"]:
            log(f"  MISMATCH s{c['seed']} {c['arm']} {c['field']}: "
                f"got={c['got']} want={c['want']}")
    log(f"== 感度: mean_zero_bins={analysis['sensitivity']['mean_zero_bins']:.1f} "
        f"mean_tail_tokens={analysis['sensitivity']['mean_tail_tokens']:.1f} "
        f"ok={sens_ok}")
    for arm, a in analysis_arms.items():
        rmean = a["cap_ratio_mean"]
        rs = f"{rmean:.4f}" if rmean is not None else "undefined"
        log(f"  {arm}: R_cap={rs} "
            f"distinct_t/s={a['distinct_teacher'][:3]}/{a['distinct_student'][:3]} "
            f"zero_cap_s={a['n_zero_cap_student']} "
            f"Δbit={a['cap_stat']['delta']:+.2f} t={a['cap_stat']['t']:+.2f} "
            f"p={a['cap_stat']['p']:.4g} MDE={a['cap_stat']['mde']:.2f} "
            f"| D3={a['D3']['delta']:+.4f} D4={a['D4']['delta']:+.4f} "
            f"| D5 u/r/o={a['D5']['uniform']:.4f}/{a['D5']['random']:.4f}/"
            f"{a['D5']['oracle']:.4f} gain={a['D5']['oracle_gain']:+.4f} "
            f"opened={a['D5']['opened']} "
            f"| W4-1={a['W4_1_capacity_ok']} W4-2={a['W4_2_controls_open']}")
    log(f"  prediction_supported={analysis['verdict']['W4_3_prediction_supported']}")
    log(f"saved: {tag}_results.json / {tag}_delta.npz / {tag}_analysis.json")
    fh.close()
    os._exit(0)


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        sys.stderr.write(f"[w4_tail_probe] ERROR {type(exc).__name__}: {exc}\n")
        sys.stderr.flush()
        raise
