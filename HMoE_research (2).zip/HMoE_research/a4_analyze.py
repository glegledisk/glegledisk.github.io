#!/usr/bin/env python3
"""A4 の検算と集計。「小 expert に ReLU² が正しい」を 2×2 で見る。

ReLU と ReLU² は**同じ 2 行列**なので、幅・params・MACs が完全に同一。
したがって差はすべて非線形性に帰属できる（A1/A3 のようなパラメータ交絡が無い）。

2×2
              大 ReLU          大 ReLU²
  小 ReLU     all_relu        large_relu2
  小 ReLU²    small_relu2     all_relu2

主効果  : small_relu2 − all_relu（小に置く効果）/ large_relu2 − all_relu（大に置く効果）
直接対決: small_relu2 − large_relu2  ← 「小の方が正しい」の検定
交互作用: (small_relu2 − all_relu) − (all_relu2 − large_relu2)
"""
import argparse
import json
import math
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a4")
ORDER = ["all_relu", "small_relu2", "large_relu2", "all_relu2"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="")
    ap.add_argument("--json", default="a4_analysis.json")
    args = ap.parse_args()

    with open(os.path.join(D, f"a4_results{args.tag}.json"), encoding="utf-8") as fh:
        rows = [r for r in json.load(fh) if "evals" in r]
    arms = [a for a in ORDER if any(r["arm"] == a for r in rows)]
    E = len(rows[0]["evals"])

    print("=== 1. 構成（すべて 2 行列・同一 params）===")
    print("  n per arm:", {a: sum(1 for r in rows if r["arm"] == a) for a in arms})
    for a in arms:
        r = next(x for x in rows if x["arm"] == a)
        print(f"  {a:12s} params={r['nparam']:,} widths={tuple(r['widths'])}")
    ps = {next(x for x in rows if x["arm"] == a)["nparam"] for a in arms}
    print(f"  params の種類: {len(ps)} 種類 {sorted(ps)}  "
          f"{'✓ 全アーム同一' if len(ps) == 1 else '✗ 揃っていない'}")

    def col(a, k, key):
        return np.array([r["evals"][k][key] for r in rows if r["arm"] == a])

    print("\n=== 2. 到達点（最終 epoch, n=6）===")
    print(f"  {'arm':12s}{'CE':>9s}{'instr':>8s}{'acc_pl':>9s}{'small_share':>13s}")
    for a in arms:
        sh = np.array([r["routing"]["small_share"] for r in rows if r["arm"] == a])
        print(f"  {a:12s}{col(a, E-1, 'ce_all').mean():>9.4f}"
              f"{col(a, E-1, 'instr_valid').mean():>8.3f}"
              f"{col(a, E-1, 'acc_payload').mean():>9.4f}"
              f"{sh.mean():>9.3f}±{sh.std(ddof=1):.3f}")

    def paired(a, b, key, ep=-1):
        da = {r["seed"]: r["evals"][ep][key] for r in rows if r["arm"] == a}
        db = {r["seed"]: r["evals"][ep][key] for r in rows if r["arm"] == b}
        ks = sorted(set(da) & set(db))
        if len(ks) < 3:
            return None
        x = np.array([da[i] for i in ks])
        y = np.array([db[i] for i in ks])
        d = x - y
        n = len(d)
        se = d.std(ddof=1) / math.sqrt(n)
        t, p = stats.ttest_rel(x, y)
        ci = stats.t.ppf(0.975, n - 1) * se
        mde = (stats.t.ppf(0.975, n - 1) + stats.t.ppf(0.80, n - 1)) * se
        return dict(a=a, b=b, metric=key, n=n, mean=float(d.mean()), se=float(se),
                    t=float(t), p=float(p), ci_lo=float(d.mean() - ci),
                    ci_hi=float(d.mean() + ci), pos=int((d > 0).sum()), mde=float(mde),
                    per_seed=d.round(5).tolist())

    CONTRASTS = [
        ("small_relu2", "all_relu", "小に ReLU² を置く（主効果・小）"),
        ("large_relu2", "all_relu", "大に ReLU² を置く（主効果・大）"),
        ("all_relu2", "all_relu", "両方に置く"),
        ("small_relu2", "large_relu2", "**どちらの置き方が良いか**"),
    ]
    res = []
    print("\n=== 3. 対比（seed 対応、n=6、最終 epoch）===")
    for a, b, lab in CONTRASTS:
        if a not in arms or b not in arms:
            continue
        print(f"  [{lab}]  {a} − {b}")
        for key in ("instr_valid", "ce_all"):
            c = paired(a, b, key)
            if not c:
                continue
            c["label"] = lab
            res.append(c)
            star = " *" if c["p"] < 0.05 else "  "
            print(f"    {key:11s} Δ={c['mean']:+.4f} se={c['se']:.4f} t={c['t']:+.2f} "
                  f"p={c['p']:.4f}{star} {c['pos']}/{c['n']} "
                  f"CI[{c['ci_lo']:+.4f},{c['ci_hi']:+.4f}] MDE={c['mde']:.4f}")

    print("\n=== 4. 交互作用（小の効果 − 大の効果）===")
    s = paired("small_relu2", "all_relu", "instr_valid")
    l = paired("large_relu2", "all_relu", "instr_valid")
    if s and l:
        print(f"  小に置く効果 = {s['mean']:+.4f} / 大に置く効果 = {l['mean']:+.4f}")
        print(f"  差（交互作用の片側） = {s['mean'] - l['mean']:+.4f}")
    s2 = paired("small_relu2", "all_relu", "ce_all")
    l2 = paired("large_relu2", "all_relu", "ce_all")
    if s2 and l2:
        print(f"  CE で: 小 = {s2['mean']:+.4f} / 大 = {l2['mean']:+.4f} / "
              f"差 = {s2['mean'] - l2['mean']:+.4f}")

    print("\n=== 5. ルーティングは動いたか（小 expert の top-1 占有率）===")
    for a in arms:
        sh = np.array([r["routing"]["small_share"] for r in rows if r["arm"] == a])
        print(f"  {a:12s} small_share = {sh.mean():.4f} ± {sh.std(ddof=1):.4f}")
    print("  --- seed 対応差 ---")
    for a, b, lab in (("small_relu2", "all_relu", "小に置く"),
                      ("large_relu2", "all_relu", "大に置く"),
                      ("all_relu2", "all_relu", "両方に置く")):
        if a not in arms or b not in arms:
            continue
        da = {r["seed"]: r["routing"]["small_share"] for r in rows if r["arm"] == a}
        db = {r["seed"]: r["routing"]["small_share"] for r in rows if r["arm"] == b}
        ks = sorted(set(da) & set(db))
        d = np.array([da[i] - db[i] for i in ks])
        se = d.std(ddof=1) / math.sqrt(len(d))
        t, p = stats.ttest_rel([da[i] for i in ks], [db[i] for i in ks])
        print(f"  {a:12s}− {b:10s} Δ={d.mean():+.4f} se={se:.4f} t={t:+.2f} "
              f"p={p:.4f} {int((d < 0).sum())}/{len(d)} が負   [{lab}]")

    print("\n=== 6. epoch ごとの軌跡（instr_valid）===")
    for a in arms:
        cells = "".join(f"{col(a, k, 'instr_valid').mean():>9.3f}" for k in range(E))
        print(f"  {a:12s}{cells}")

    agg = {}
    for a in arms:
        r = next(x for x in rows if x["arm"] == a)
        sh = np.array([x["routing"]["small_share"] for x in rows if x["arm"] == a])
        agg[a] = dict(n=sum(1 for x in rows if x["arm"] == a),
                      ce=float(col(a, E - 1, "ce_all").mean()),
                      ce_sd=float(col(a, E - 1, "ce_all").std(ddof=1)),
                      iv=float(col(a, E - 1, "instr_valid").mean()),
                      iv_sd=float(col(a, E - 1, "instr_valid").std(ddof=1)),
                      acc_pl=float(col(a, E - 1, "acc_payload").mean()),
                      iv_by_ep=[float(col(a, k, "instr_valid").mean()) for k in range(E)],
                      ce_by_ep=[float(col(a, k, "ce_all").mean()) for k in range(E)],
                      small_share=float(sh.mean()), small_share_sd=float(sh.std(ddof=1)),
                      nparam=r["nparam"], act_i=r["act_i"])
    out = {"aggregate": agg, "contrasts": res, "epochs": E, "n_runs": len(rows),
           "scale": rows[0]["scale"]}
    with open(os.path.join(D, args.json), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(f"\n[write] {os.path.join(D, args.json)}")


if __name__ == "__main__":
    main()
