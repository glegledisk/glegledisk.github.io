# -*- coding: utf-8 -*-
"""P8 解析: 長さ L のパイロット（A1 / A2）

入力: p8_length.jsonl
出力: p8_analysis.json / p8_analysis_out_utf8.txt

独立単位は問題（n=20）。率の CI は Wilson、対応のある差は McNemar。
n が小さいので MDE を必ず併記する。
"""

import json
import math
import os
import re

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ORDER = ["cap128", "cap256", "cap512", "cap1024", "force256", "soft", "nothink"]


def wilson(k, n, z=1.96):
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))


def mcnemar(b, c):
    """b = 条件1だけ正解, c = 条件2だけ正解。正確検定（両側）。"""
    n = b + c
    if n == 0:
        return float("nan")
    k = min(b, c)
    p = sum(math.comb(n, i) for i in range(k + 1)) / (2 ** n) * 2
    return min(1.0, p)


def main():
    path = os.path.join(HERE, "p8_length.jsonl")
    recs = [json.loads(l) for l in open(path, encoding="utf-8")]

    # --- 抽出の修正（2026-10-28）---
    # 生ログを見ると、易しい問題は \boxed{} を付けず「811 + 219 = 1030.」で終わり、
    # 難しい問題は \boxed{} を付ける。形式が難度で変わるので、boxed だけを解答と
    # みなすと add3 が全部「答えなし」になる（初版のバグ）。
    # 判定: 「自然停止（EOS）した」かつ「末尾に数値がある」→ 解答あり。
    # force256 だけは強制生成なので EOS を要求しない。
    def resolve(r):
        src = r.get("forced_tail") if r["cond"] == "force256" else r["text_tail"]
        nums = re.findall(r"-?\d+", (src or "").replace(",", ""))
        pred = nums[-1] if nums else None
        ok = (pred is not None) and (r["cond"] == "force256" or r["finished"])
        return pred, ok

    for r in recs:
        pred, ok = resolve(r)
        r["pred"] = pred
        r["answered"] = ok
        r["correct"] = bool(ok and pred == r["gold"])

    conds = [c for c in ORDER if any(r["cond"] == c for r in recs)]
    levels = ["add4", "add3"]
    qs = sorted(set(r["q"] for r in recs))

    lines = []
    def emit(s=""):
        lines.append(s)
        print(s, flush=True)

    emit("=== P8 長さパイロット（%d 問: add4 %d / add3 %d）==="
         % (len(qs), len([q for q in qs if any(r["q"] == q and r["level"] == "add4" for r in recs)]),
            len([q for q in qs if any(r["q"] == q and r["level"] == "add3" for r in recs)])))
    emit("")
    out = {"n_problems": len(qs), "conds": conds}

    def get(cond, level=None):
        return {r["q"]: r for r in recs
                if r["cond"] == cond and (level is None or r["level"] == level)}

    # ---------- 0. 率 ----------
    emit("[0] 答えなし率 / 正解率 / サイレント失敗率（Wilson 95% CI）")
    emit("%-9s %-6s %5s %18s %18s %18s" %
         ("cond", "level", "n", "answer", "acc_all", "silent"))
    for c in conds:
        for lv in levels + [None]:
            d = get(c, lv)
            if not d:
                continue
            n = len(d)
            ans = sum(r["answered"] for r in d.values())
            acc = sum(r["correct"] for r in d.values())
            sil = sum(r["answered"] and not r["correct"] for r in d.values())
            a_lo, a_hi = wilson(ans, n)
            s_lo, s_hi = wilson(sil, n)
            lab = lv if lv else "全体"
            emit("%-9s %-6s %5d %8.2f [%.2f,%.2f] %8.2f       %8.2f [%.2f,%.2f]"
                 % (c, lab, n, ans / n, a_lo, a_hi, acc / n, sil / n, s_lo, s_hi))
            out.setdefault("rates", {})["%s:%s" % (c, lab)] = {
                "n": n, "answer": ans / n, "acc": acc / n, "silent": sil / n,
                "answer_ci": [a_lo, a_hi], "silent_ci": [s_lo, s_hi]}
    emit("")

    # ---------- 1. A1: P(pass | L) ----------
    emit("[1] A1: P(pass | L) の形")
    emit("%-7s %8s %8s %10s" % ("cap", "add4", "add3", "答えなし率"))
    for c in [x for x in conds if x.startswith("cap")]:
        d4, d3 = get(c, "add4"), get(c, "add3")
        p4 = np.mean([r["correct"] for r in d4.values()]) if d4 else float("nan")
        p3 = np.mean([r["correct"] for r in d3.values()]) if d3 else float("nan")
        na = np.mean([not r["answered"] for r in list(d4.values()) + list(d3.values())])
        emit("%-7s %8.2f %8.2f %10.2f" % (c, p4, p3, na))
    emit("  → 曲線の形（凹 / S 字 / 崖）はこの分解能では判定できない")
    emit("")

    # ---------- 2. A2: 失敗は観測できるか ----------
    emit("[2] A2: 同じ失敗が、条件によって「答えなし」になるか「誤答」になるか")
    hard, force, nt = get("cap256"), get("force256"), get("nothink")
    common = sorted(set(hard) & set(force) & set(nt))
    if common:
        no_ans = [q for q in common if not hard[q]["answered"]]
        emit("    hard-A（cap256）で答えなし: %d/%d 問" % (len(no_ans), len(common)))
        if no_ans:
            f_wrong = sum(not force[q]["correct"] for q in no_ans)
            n_wrong = sum(not nt[q]["correct"] for q in no_ans)
            f_ans = sum(force[q]["answered"] for q in no_ans)
            n_ans = sum(nt[q]["answered"] for q in no_ans)
            emit("    そのうち force256 が答えた: %d/%d、うち誤答 %d/%d（%.2f）"
                 % (f_ans, len(no_ans), f_wrong, len(no_ans), f_wrong / len(no_ans)))
            emit("    そのうち nothink が答えた: %d/%d、うち誤答 %d/%d（%.2f）"
                 % (n_ans, len(no_ans), n_wrong, len(no_ans), n_wrong / len(no_ans)))
            lo, hi = wilson(f_wrong, len(no_ans))
            emit("    **サイレント化率（force256）= %.2f, 95%% CI [%.2f, %.2f]**"
                 % (f_wrong / len(no_ans), lo, hi))
            out["a2"] = {"n_no_answer": len(no_ans),
                         "force_answered": f_ans, "force_wrong": f_wrong,
                         "nothink_answered": n_ans, "nothink_wrong": n_wrong,
                         "silent_rate_force": f_wrong / len(no_ans),
                         "silent_rate_force_ci": [lo, hi]}
    emit("")

    # ---------- 3. 対応のある比較 ----------
    emit("[3] 対応のある比較（McNemar 正確検定、n=%d）" % len(common))
    pairs = [("cap256", "force256"), ("cap256", "nothink"), ("force256", "nothink")]
    out["mcnemar"] = {}
    for a, b in pairs:
        da, db = get(a), get(b)
        cc = sorted(set(da) & set(db))
        if not cc:
            continue
        b01 = sum(1 for q in cc if da[q]["correct"] and not db[q]["correct"])
        b10 = sum(1 for q in cc if not da[q]["correct"] and db[q]["correct"])
        p = mcnemar(b01, b10)
        emit("    %-9s vs %-9s: 前者だけ正解 %d / 後者だけ正解 %d / p=%.3f"
             % (a, b, b01, b10, p))
        out["mcnemar"]["%s_vs_%s" % (a, b)] = {"b01": b01, "b10": b10, "p": p}
    emit("")

    # ---------- 4. 検出力 ----------
    n = len(common)
    se = math.sqrt(0.25 / n) if n else float("nan")
    emit("[4] 検出力（n=%d）" % n)
    emit("    率の差の SE ≈ %.3f、MDE80 ≈ %.3f（2.8×SE）" % (se, 2.8 * se))
    emit("    **この n では 30 ポイント未満の差は検出できない。以下は記述であって検定ではない。**")
    out["power"] = {"n": n, "se": se, "mde80": 2.8 * se}

    with open(os.path.join(HERE, "p8_analysis.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2, default=float)
    with open(os.path.join(HERE, "p8_analysis_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(lines) + "\n")
    print("saved: p8_analysis.json / p8_analysis_out_utf8.txt")


if __name__ == "__main__":
    main()
