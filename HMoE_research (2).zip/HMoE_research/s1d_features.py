# -*- coding: utf-8 -*-
"""S1d: structural features of the 3 social-sciences books (same definitions as S1c)."""
import json
import os
import re
from collections import Counter, defaultdict

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
STOP = set("""the a an of and or to in for on with by from as at is are be been being this that these those
it its your you we our their his her them they i he she not but if when which what how why who whom whose can
could may might will would shall should must do does did done than then into within about over under between
among such other others more most some any all each both one two three first second new using use used also
there here where while because so than only just very much many few own same""".split())


def cw(s):
    s = re.sub(r"^\s*\d+(?:\.\d+)*\s*[:.]?\s*", "", str(s))
    toks = re.findall(r"[A-Za-z][A-Za-z\-']+", s.lower())
    return [t for t in toks if t not in STOP and len(t) > 1]


def jac(a, b):
    A, B = set(a), set(b)
    return len(A & B) / len(A | B) if A and B else float("nan")


def parent(i):
    return tuple(str(i).split(".")[:-1])


with open(os.path.join(HERE, "s1d_manifest.json"), encoding="utf-8") as f:
    M = json.load(f)

out = {}
for bid, d in M["domains"].items():
    toc = d["toc"]
    titles = [r["title"] for r in toc]
    raw = [len(t.split()) for t in titles]
    by_parent = defaultdict(list)
    for r in toc:
        p = parent(r["id"])
        if p:
            by_parent[p].append(r["title"])
    tight, cov = [], []
    for v in by_parent.values():
        if len(v) < 2:
            continue
        w = [cw(t) for t in v]
        js = [jac(w[i], w[j]) for i in range(len(w)) for j in range(i + 1, len(w))]
        if js:
            tight.append(float(np.mean(js)))
        c = Counter(x for t in w for x in set(t))
        if c:
            cov.append(c.most_common(1)[0][1] / len(v))
    gs = [jac(cw(e["gold"]), cw(e["sibling"])) for e in d["entries"]]
    qg = [jac(cw(e["query"]), cw(e["gold"])) for e in d["entries"]]
    branch = [len(v) for v in by_parent.values()]
    out[bid] = {
        "book": d["book"], "n_titles": len(toc), "n_entries": len(d["entries"]),
        "title_raw_words": float(np.mean(raw)),
        "children_per_parent": float(np.mean(branch)),
        "sibling_set_jaccard": float(np.mean(tight)),
        "gold_sibling_jaccard": float(np.mean(gs)),
        "marker_coverage": float(np.mean(cov)),
        "query_gold_jaccard": float(np.mean(qg)),
    }

print("%-16s %6s %7s %7s %8s %8s %8s %8s" % ("book", "n_toc", "raw_w", "child", "sib_jac", "gs_jac", "marker", "q-g_jac"))
for bid, r in out.items():
    print("%-16s %6d %7.2f %7.2f %8.3f %8.3f %8.3f %8.3f"
          % (bid, r["n_titles"], r["title_raw_words"], r["children_per_parent"],
             r["sibling_set_jaccard"], r["gold_sibling_jaccard"], r["marker_coverage"], r["query_gold_jaccard"]))

with open(os.path.join(HERE, "s1d_features.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1)
print("wrote s1d_features.json")
