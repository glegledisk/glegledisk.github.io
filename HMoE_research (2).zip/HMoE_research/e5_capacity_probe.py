# -*- coding: utf-8 -*-
"""e5_capacity_probe.py — なぜ FFN が不要なのかを切り分ける

E5 のヘッドルーム測定で、frozen_identity（FFN を一切使わない）でも acc 0.98 に達した。
原因候補:
  (a) 課題が易しすぎる（変換が単純）
  (b) モデルの容量が大きすぎる（Attention の softmax が非線形性を担い、FFN が不要）

(b) を切り分けるため、モデル幅 d を 64 -> 32 -> 16 と下げ、
frozen_ffn と frozen_identity の差（= FFN の寄与）がどう変わるかを見る。
FFN の寄与が容量を下げると大きくなるなら、原因は (b)。
"""
import os, json, time
import numpy as np
import pandas as pd
from e5_dependency_task import run

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=16, anchor_vals=(0, 1, 2, 3))
DS = [64, 32, 16]
SEEDS = [0, 1]

rows = []
t0 = time.time()
for d in DS:
    for arm in ("frozen_ffn", "frozen_identity"):
        for s in SEEDS:
            r = run(arm, s, d=d, **CFG)
            r["d"] = d
            rows.append(r)
            print(f"  d={d:2d} {arm:16s} s{s} | acc {r['acc_all']:.4f} "
                  f"(copy {r.get('acc_copy',0):.3f}/anchor {r.get('acc_anchor',0):.3f}) "
                  f"| CE {r['ce_all']:.4f} | FFN {r['ffn_cost']:.3f}", flush=True)
    print(f"    ({time.time()-t0:.0f}s)", flush=True)

df = pd.DataFrame(rows)
df.to_csv(os.path.join(HERE, "e5_capacity_probe.csv"), index=False)

print("\n=== モデル幅 d と FFN の寄与（2 seeds 平均） ===")
print(f"{'d':>4s} {'CE(FFN)':>10s} {'CE(恒等)':>10s} {'ΔCE':>8s} {'acc(FFN)':>10s} {'acc(恒等)':>10s} {'acc差':>8s}")
summary = []
for d in DS:
    a = df[(df.d == d) & (df.arm == "frozen_ffn")]
    b = df[(df.d == d) & (df.arm == "frozen_identity")]
    dce = b["ce_all"].mean() - a["ce_all"].mean()
    dacc = a["acc_all"].mean() - b["acc_all"].mean()
    print(f"{d:4d} {a['ce_all'].mean():10.4f} {b['ce_all'].mean():10.4f} {dce:+8.4f} "
          f"{a['acc_all'].mean():10.4f} {b['acc_all'].mean():10.4f} {dacc:+8.4f}")
    summary.append({"d": d, "ce_ffn": float(a["ce_all"].mean()), "ce_id": float(b["ce_all"].mean()),
                    "dce": float(dce), "acc_ffn": float(a["acc_all"].mean()),
                    "acc_id": float(b["acc_all"].mean()), "dacc": float(dacc)})

json.dump(summary, open(os.path.join(HERE, "e5_capacity_probe.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e5_capacity_probe.csv / .json")
