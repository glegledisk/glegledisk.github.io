# -*- coding: utf-8 -*-
"""e7_stab_supplement.py — A4 実験の追加解析"""
import numpy as np
import pandas as pd

df = pd.read_csv("e7_stabilize_7seed.csv")
df["obj015"] = df["ce_all"] + 0.15 * df["ffn_cost"]
b = pd.read_csv("e7_routing_7seed.csv")
b["obj015"] = b["ce_all"] + 0.15 * b["ffn_cost"]
base_ffn = b[b.arm == "frozen_ffn"].set_index("seed")
base_free = b[b.arm == "free"].set_index("seed")
VAR = ["free_entropy", "free_balance", "free_tokid", "free_mlp"]

print("=== 役割別 CE（アーム平均） ===")
print(f"{'arm':16s} {'ce_ff':>8s} {'ce_fr':>8s} {'ce_rr':>8s} {'acc_rr':>8s}")
for a, d in [("frozen_ffn", base_ffn), ("E7 free", base_free)] + [(v, df[df.variant == v].set_index("seed")) for v in VAR]:
    print(f"{a:16s} {d['ce_ff'].mean():8.4f} {d['ce_fr'].mean():8.4f} {d['ce_rr'].mean():8.4f} {d['acc_rr'].mean():8.4f}")

print("\n=== free_tokid の役割別 seed 対応差（− frozen_ffn） ===")
dv = df[df.variant == "free_tokid"].set_index("seed")
for nm in ["ff", "fr", "rr"]:
    d = (dv[f"ce_{nm}"] - base_ffn[f"ce_{nm}"]).dropna()
    m, sd = d.mean(), d.std(ddof=1)
    t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
    rng = np.random.default_rng(3)
    boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(20000)])
    lo, hi = np.percentile(boot, [2.5, 97.5])
    print(f" ce_{nm}: {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {int((d<0).sum())}/{len(d)}")

print("\n=== free_tokid の役割別 seed 対応差（− E7 free） ===")
for nm in ["ff", "fr", "rr"]:
    d = (dv[f"ce_{nm}"] - base_free[f"ce_{nm}"]).dropna()
    m, sd = d.mean(), d.std(ddof=1)
    t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
    print(f" ce_{nm}: {m:+.4f} (t={t:+.2f}) {int((d<0).sum())}/{len(d)}")

print("\n=== entropy の seed 5 除外感度（投稿ホック注意） ===")
de = df[df.variant == "free_entropy"].set_index("seed")
de6 = de.drop(index=5)
print(f" 全 7 seed: CE {de['ce_all'].mean():.4f}±{de['ce_all'].std():.4f}  FFN {de['ffn_cost'].mean():.3f}  obj {de['obj015'].mean():.4f}")
print(f" s5 除外:  CE {de6['ce_all'].mean():.4f}±{de6['ce_all'].std():.4f}  FFN {de6['ffn_cost'].mean():.3f}  obj {de6['obj015'].mean():.4f}")
print(f" （参考）free_tokid: CE {dv['ce_all'].mean():.4f}  FFN {dv['ffn_cost'].mean():.3f}  obj {dv['obj015'].mean():.4f}")
print(f" seed 5 の各アーム CE: frozen_ffn {base_ffn.loc[5,'ce_all']:.4f} / E7 free {base_free.loc[5,'ce_all']:.4f} / "
      f"entropy {de.loc[5,'ce_all']:.4f} / balance {df[(df.variant=='free_balance')&(df.seed==5)]['ce_all'].iloc[0]:.4f} / "
      f"tokid {dv.loc[5,'ce_all']:.4f} / mlp {df[(df.variant=='free_mlp')&(df.seed==5)]['ce_all'].iloc[0]:.4f}")

print("\n=== E6 効果量からの回復率（合成目的の差） ===")
e6_obj = -0.1509
for name, m in [("E7 free", base_free["obj015"].mean() - base_ffn["obj015"].mean())] + \
              [(v, df[df.variant == v]["obj015"].mean() - base_ffn["obj015"].mean()) for v in VAR]:
    print(f" {name:14s} obj 差 {m:+.4f}  E6 効果の {100*(-m/e6_obj):5.1f}%")

print("\n=== id_rate の seed 別（二峰性の確認） ===")
for v in VAR:
    d = df[df.variant == v].sort_values("seed")
    print(f" {v:14s} idRR " + " ".join(f"{x:.3f}" for x in d["id_rate_rr"])
          + "   idFF " + " ".join(f"{x:.3f}" for x in d["id_rate_ff"]))
print(f" {'E7 free':14s} idRR " + " ".join(f"{x:.3f}" for x in base_free.sort_index()["id_rate_rr"])
      + "   idFF " + " ".join(f"{x:.3f}" for x in base_free.sort_index()["id_rate_ff"]))

print("\n=== FFN cost の seed 間 SD（安定性） ===")
print(f" E7 free       {base_free['ffn_cost'].std():.3f}")
for v in VAR:
    print(f" {v:14s} {df[df.variant == v]['ffn_cost'].std():.3f}")

print("\n=== free_tokid vs E7 free: per-seed obj ===")
for s in range(7):
    t = dv.loc[s, "obj015"]; f = base_free.loc[s, "obj015"]
    print(f"  s{s}: tokid {t:.4f}  free {f:.4f}  差 {t-f:+.4f}")
