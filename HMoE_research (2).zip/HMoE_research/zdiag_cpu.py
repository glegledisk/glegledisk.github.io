"""zdiag_cpu.py — SmolLM-135M を CPU で回し、実 p_T で TV を測る

TV(q_EOT, q_MI) = T/Z （lattice_tv.py で証明済み）を、
unigram 近似ではなく実際の教師分布 p_T で評価する。

- GPU 不使用（CUDA_VISIBLE_DEVICES=""）
- モデルは urllib で直接取得（hf_hub_download はこの環境で snapshot 作成に失敗するため）
"""

import os
import sys

os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import bisect
import glob
import json
import time
import urllib.request

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(HERE, "models", "smollm-135m")
TOK_PATH = os.path.join(HERE, "tok_cache", "smollm.json")
REPO = "HuggingFaceTB/SmolLM-135M"
FILES = ["config.json", "model.safetensors", "tokenizer.json",
         "tokenizer_config.json", "special_tokens_map.json", "generation_config.json"]


def dl():
    os.makedirs(MODEL_DIR, exist_ok=True)
    os.makedirs(os.path.dirname(TOK_PATH), exist_ok=True)
    for fn in FILES:
        dst = TOK_PATH if fn == "tokenizer.json" else os.path.join(MODEL_DIR, fn)
        if os.path.exists(dst) and os.path.getsize(dst) > 0:
            print(f"[cached] {fn} {os.path.getsize(dst)/1e6:.2f} MB")
            continue
        url = f"https://huggingface.co/{REPO}/resolve/main/{fn}"
        t0 = time.time()
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "curl/8"})
            with urllib.request.urlopen(req, timeout=900) as r:
                data = r.read()
            with open(dst, "wb") as f:
                f.write(data)
            print(f"[dl] {fn} {len(data)/1e6:.2f} MB {time.time()-t0:.1f}s")
        except Exception as e:
            print(f"[FAIL] {fn}: {type(e).__name__}: {str(e)[:120]}")


def bytes_to_unicode():
    bs = (list(range(ord("!"), ord("~") + 1))
          + list(range(ord("¡"), ord("¬") + 1))
          + list(range(ord("®"), ord("ÿ") + 1)))
    cs = bs[:]
    n = 0
    for b in range(256):
        if b not in bs:
            bs.append(b)
            cs.append(256 + n)
            n += 1
    return {chr(c): b for b, c in zip(bs, cs)}


UNI2BYTE = bytes_to_unicode()


def token_bytes(s):
    out = bytearray()
    for ch in s:
        b = UNI2BYTE.get(ch)
        if b is None:
            return None
        out.append(b)
    return bytes(out)


class Lattice:
    def __init__(self, tokenizer_json):
        from tokenizers import Tokenizer
        self.tk = Tokenizer.from_file(tokenizer_json)
        pairs = []
        for s, i in self.tk.get_vocab().items():
            b = token_bytes(s)
            if b:
                pairs.append((b, i))
        pairs.sort()
        self.keys = [p[0] for p in pairs]
        self.ids = np.array([p[1] for p in pairs], dtype=np.int64)
        self.pos = {b: k for k, (b, _) in enumerate(pairs)}
        self.maxlen = max(len(b) for b in self.keys)
        self.n = len(pairs)
        self.id2bytes = {i: b for b, i in pairs}
        self.V = self.tk.get_vocab_size()
        self._rng = {}

    def subtree_range(self, p):
        r = self._rng.get(p)
        if r is None:
            lo = bisect.bisect_left(self.keys, p)
            hi = bisect.bisect_left(self.keys, p + b"\xff" * (self.maxlen + 1))
            r = (lo, hi)
            self._rng[p] = r
        return r


def main():
    dl()
    if not os.path.exists(os.path.join(MODEL_DIR, "model.safetensors")):
        print("[abort] model.safetensors が無い")
        return 1

    lat = Lattice(TOK_PATH)
    print(f"[tok] vocab={lat.V} lattice={lat.n} max_bytes={lat.maxlen}")

    files = glob.glob(os.path.join(HERE, "english_version", "**", "*.md"), recursive=True)
    text = "\n\n".join(open(f, encoding="utf-8", errors="ignore").read() for f in sorted(files))
    ids = lat.tk.encode(text, add_special_tokens=False).ids
    N_TOK = 3000
    ids = ids[:N_TOK]
    print(f"[corpus] {len(text):,} chars -> {len(ids)} tokens")

    import torch
    from transformers import AutoModelForCausalLM
    torch.set_num_threads(max(1, (os.cpu_count() or 4) - 1))
    t0 = time.time()
    try:
        model = AutoModelForCausalLM.from_pretrained(MODEL_DIR, dtype=torch.float32)
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(MODEL_DIR, torch_dtype=torch.float32)
    model.eval()
    print(f"[model] {time.time()-t0:.1f}s  params={sum(p.numel() for p in model.parameters())/1e6:.0f}M")

    L = 512
    chunks = []
    t0 = time.time()
    with torch.no_grad():
        for s in range(0, len(ids) - 1, L):
            c = ids[s:s + L]
            if len(c) < 2:
                break
            chunks.append(model(torch.tensor([c], dtype=torch.long)).logits[0].float().numpy())
    print(f"[fwd] {time.time()-t0:.1f}s  chunks={len(chunks)}")

    counts = np.bincount(ids, minlength=lat.V).astype(np.float64)
    pu_all = counts[lat.ids] / counts.sum()
    cumu_all = np.concatenate(([0.0], np.cumsum(pu_all)))

    tv_model, tv_uni, js, ent_entry = [], [], [], []
    Tmass = []
    pos = 0
    for lg in chunks:
        for t in range(lg.shape[0] - 1):
            cur = pos + t
            if cur + 1 >= len(ids):
                break
            w = ids[cur + 1]
            b = lat.id2bytes.get(w)
            if not b or len(b) < 2:
                continue
            z = lg[t].astype(np.float64)
            z -= z.max()
            p = np.exp(z)
            p /= p.sum()
            ps = p[lat.ids]
            cum = np.concatenate(([0.0], np.cumsum(ps)))
            ent = float(-(p[p > 0] * np.log(p[p > 0])).sum())
            for j in range(1, len(b)):
                lo, hi = lat.subtree_range(b[:j])
                Z = cum[hi] - cum[lo]
                Zu = cumu_all[hi] - cumu_all[lo]
                k = lat.pos.get(b[:j])
                T = ps[k] if k is not None else 0.0
                Tu = pu_all[k] if k is not None else 0.0
                tv_model.append(T / Z if Z > 0 else 0.0)
                tv_uni.append(Tu / Zu if Zu > 0 else 0.0)
                js.append(j)
                ent_entry.append(ent)
                Tmass.append(T)
        pos += lg.shape[0]

    tv_model = np.array(tv_model)
    tv_uni = np.array(tv_uni)
    js = np.array(js)
    ent_entry = np.array(ent_entry)

    print("\n=== 実 p_T vs unigram 近似（同一トークン列・同一位置） ===")
    print(f"positions           : {len(tv_model)}")
    print(f"mean TV (model p_T) : {tv_model.mean():.4f}")
    print(f"mean TV (unigram)   : {tv_uni.mean():.4f}")
    print(f"median/p90/p99      : {np.median(tv_model):.4f} / {np.quantile(tv_model,0.9):.4f} / {np.quantile(tv_model,0.99):.4f}")
    print(f"frac TV>0.05 / >0.10: {(tv_model>0.05).mean():.3f} / {(tv_model>0.10).mean():.3f}")
    print(f"mean boundary mass T: {np.mean(Tmass):.5f}")
    print(f"entropy (nats)      : mean {ent_entry.mean():.3f}  median {np.median(ent_entry):.3f}")

    print("\n=== j 別 ===")
    for j in range(1, 9):
        m = js == j
        if m.sum():
            print(f"  j={j}: n={int(m.sum()):6d}  TV={tv_model[m].mean():.4f}  (unigram {tv_uni[m].mean():.4f})")

    print("\n=== エントロピー分位別（実 p_T） ===")
    qs = np.quantile(ent_entry, [0.2, 0.4, 0.6, 0.8])
    bins = np.digitize(ent_entry, qs)
    for k in range(5):
        m = bins == k
        if m.sum():
            print(f"  Q{k+1}: n={int(m.sum()):6d}  TV={tv_model[m].mean():.4f}  entropy={ent_entry[m].mean():.3f}")

    np.savez(os.path.join(HERE, "lattice_out", "zdiag_cpu.npz"),
             tv_model=tv_model, tv_uni=tv_uni, j=js, ent=ent_entry)
    print("\n[saved] lattice_out/zdiag_cpu.npz")
    return 0


if __name__ == "__main__":
    sys.exit(main())
