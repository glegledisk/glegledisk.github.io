# -*- coding: utf-8 -*-
"""audit2_20261024.py — 追検証: レプリカ効果の再計算（wbar固定）と TV の j 層別比較"""
import os, json
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SIM = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "cache_traces")
E = 8
W = {"U+LB":[256]*8,"U+noLB":[256]*8,"H+LB":[64,64,192,192,320,320,448,448],
     "H+noLB":[64,64,192,192,320,320,448,448],"H+shared":[64,64,192,192,320,320,448,448]}

def counts(trs):
    L = trs[0].shape[0]
    tot = np.zeros(L*E)
    for tr in trs:
        lay = np.arange(L, dtype=np.int32)*E
        tot += np.bincount((tr+lay.reshape(-1,1,1)).reshape(-1), minlength=L*E)
    return tot

print("=== 1. レプリカ効果（wbar を固定 = 総仕事量不変という正しい式） ===")
print("   I_rep = N_slots * max(load/R) / wbar_original")
for arm in W:
    trs = [np.load(os.path.join(SIM, "%s_s%d_%s.npy" % (arm,s,t))).astype(np.int32)
           for s in (0,1,2) for t in ("task0","task1","task2")
           if os.path.exists(os.path.join(SIM, "%s_s%d_%s.npy" % (arm,s,t)))]
    if not trs: continue
    ws = np.asarray(W[arm], float); L = trs[0].shape[0]
    tot = counts(trs); p = tot/tot.sum(); wslot = np.tile(ws, L)
    base = p*wslot; wbar = base.sum(); N = len(p)
    row = ["R=1:%.3f" % (N*base.max()/wbar)]
    for k in (1,2,3,4,8):          # ホット k 個を複製
        for R in (2,4):
            l = base.copy(); top = np.argsort(-l)[:k]; l[top] /= R
            row.append("top%d x%d:%.3f" % (k, R, N*l.max()/wbar))
    print(" %-9s %s" % (arm, "  ".join(row)))

print("\n=== 2. TV の j 層別比較（既存 JSON から再集計） ===")
d = json.load(open(os.path.join(HERE, "tv_diagnosis_results.json"), encoding="utf-8"))
keys = [("smollm-135m","en"),("smollm-135m","ja"),("qwen3-0.6b","en"),("qwen3-0.6b","ja")]
# 共通 j 分布 = 4 条件の合計カウント
common = {}
for j in range(1,9):
    common[j] = sum(d[m][l]["j_breakdown"].get(str(j),{}).get("count",0) for m,l in keys)
tot_common = sum(common.values())
print(" 共通 j 重み (4条件合算):", {j: round(c/tot_common,3) for j,c in common.items()})
print(" %-12s %-3s %8s %8s %8s   %s" % ("model","lang","mean(j1-8)","j1のみ","j1-3のみ","再重み付け平均"))
for m,l in keys:
    jb = d[m][l]["j_breakdown"]
    num = den = 0.0
    for j in range(1,9):
        if str(j) in jb:
            num += jb[str(j)]["mean_tv"]*common[j]; den += common[j]
    rew = num/den
    def sub(lo,hi):
        n_=sum(jb[str(j)]["count"] for j in range(lo,hi+1) if str(j) in jb)
        s_=sum(jb[str(j)]["mean_tv"]*jb[str(j)]["count"] for j in range(lo,hi+1) if str(j) in jb)
        return s_/n_ if n_ else float('nan')
    print(" %-12s %-3s %8.4f %8.4f %8.4f   %8.4f  (報告値 %.4f)"
          % (m,l, d[m][l]["mean_tv"], sub(1,1), sub(1,3), rew, d[m][l]["mean_tv"]))
print("\n ※ 報告値は (pos,j) 単位の単純平均。j 分布が条件間で異なるため、")
print("    再重み付け平均（共通 j 分布）と j=1 のみの比較が公平な比較になる。")

print("\n=== 3. 報告書の『層あたりExpert総重み』行の検算 (8GB予算) ===")
d4, nE = 4096, 8
wh = np.array([4096,6963,9830,12697,15564,18431,21298,25809], float)
par = 3*d4*wh
print(" FP8常駐(2個) = %.1f MB, INT2退避(6個) = %.1f MB, 合計 = %.1f MB"
      % (par[:2].sum()/1e6, par[2:].sum()*0.25/1e6, (par[:2].sum()+par[2:].sum()*0.25)/1e6))
print(" 報告書: 『HBM常駐 250 MB ＋ ホスト退避 235 MB ＝ 485 MB（-31%）』")
print(" → 250MB は『予算』であり使用量ではない。合計は 454.2MB = 均一704.6MB の 64.5% (-35.5%)")
