# -*- coding: utf-8 -*-
"""p6q_corpus_compare.py — 3 コーパスの比較（GPU 不要）

en-wiki（英語・百科事典）/ en-doc（英語・技術文書）/ ja-md（日本語・技術文書）で
層の非対称性（f6b8 − f8b6 の較正ギャップ差）を比べる。

  en-wiki と en-doc が同じ → コーパス/ジャンルは無関係 → 言語が原因
  en-wiki と en-doc が違う → コーパス/ジャンルが原因
"""
import json
import math

import numpy as np

LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


def ttest(a, b=None):
    a = np.asarray(a, float)
    if b is not None:
        a = a - np.asarray(b, float)
    se = a.std(ddof=1) / math.sqrt(a.size)
    return float(a.mean()), float(se), float(a.mean() / se) if se > 0 else float("nan")


def load(path, prefix=""):
    z = np.load(path, allow_pickle=True)
    out = {}
    for c in ("base", "f6b8", "f8b6"):
        g = z["%s%s_ptop1" % (prefix, c)].astype(float) - z["%s%s_top1" % (prefix, c)].astype(float)
        out[c] = dict(nll=z["%s%s_nll" % (prefix, c)].astype(float), gap=g,
                      p=z["%s%s_ptop1" % (prefix, c)].astype(float),
                      acc=z["%s%s_top1" % (prefix, c)].astype(float))
    return out


# en-wiki / ja-md は p6c（lang 列で分割）、en-doc は p6p
c = np.load("p6c_layer_cal.npz", allow_pickle=True)
tl = np.repeat(c["lang"], c["base_nll"].size // c["lang"].size)
wiki = {u: load("p6c_layer_cal.npz") for u in ("en", "ja")}   # 全体を読んで後でマスク
doc = load("p6p_doc.npz")

log("=== 各コーパスの水準 ===")
log("%-10s %8s %10s %10s %10s %10s %10s" %
    ("corpus", "n", "CE(base)", "p_top1", "acc", "base gap", "mass"))
rows = {}
for u in ("en", "ja"):
    s = tl == u
    base = wiki[u]["base"]
    rows["%s-wiki" % u if u == "en" else "ja-md"] = dict(
        n=int(s.sum()), ce=float(base["nll"][s].mean()), p=float(base["p"][s].mean()),
        acc=float(base["acc"][s].mean()), gap=float(base["gap"][s].mean()))
d0 = doc["base"]
rows["en-doc"] = dict(n=int(d0["nll"].size), ce=float(d0["nll"].mean()),
                      p=float(d0["p"].mean()), acc=float(d0["acc"].mean()),
                      gap=float(d0["gap"].mean()))
for k, r in rows.items():
    log("%-10s %8d %10.4f %10.4f %10.4f %+10.2f %10s"
        % (k, r["n"], r["ce"], r["p"], r["acc"], 100 * r["gap"], ""))

log("")
log("=== 層の非対称性（f6b8 − f8b6 の較正ギャップ差, pt） ===")
log("%-10s %12s %10s %12s %12s" % ("corpus", "Δgap", "t", "ΔCE", "Δmass"))
OUT = {"levels": rows, "asym": {}}
for name in ("en-wiki", "en-doc", "ja-md"):
    if name == "en-doc":
        a, b = doc["f6b8"], doc["f8b6"]
    else:
        u = "en" if name == "en-wiki" else "ja"
        s = tl == u
        a = {k: v[s] for k, v in wiki[u]["f6b8"].items()}
        b = {k: v[s] for k, v in wiki[u]["f8b6"].items()}
    m, se, t = ttest(a["gap"], b["gap"])
    ce = (a["nll"] - b["nll"]).mean()
    dm = None
    log("%-10s %+12.3f %+10.2f %+12.5f %12s"
        % (name, 100 * m, t, ce, "-" if dm is None else "%.4f" % dm))
    OUT["asym"][name] = dict(dgap=float(100 * m), t=float(t), dce=float(ce), n=int(a["gap"].size))

log("")
log("=== 質量欠落（p6p は mass を保存している） ===")
z = np.load("p6p_doc.npz", allow_pickle=True)
for nm in ("base", "f6b8", "f8b6"):
    log("  en-doc %-5s mass=%.4f" % (nm, float(z["%s_mass" % nm].mean())))

log("")
log("=== 判定 ===")
w = OUT["asym"]["en-wiki"]["dgap"]
d = OUT["asym"]["en-doc"]["dgap"]
j = OUT["asym"]["ja-md"]["dgap"]
log("  en-wiki %+.3f / en-doc %+.3f / ja-md %+.3f pt" % (w, d, j))
log("  言語を固定した差（en-doc − en-wiki）= %+.3f pt" % (d - w))
log("  コーパスを固定した差（ja-md − en-doc は言語も違うので参考）")
if abs(d - w) < abs(j - w) * 0.5:
    log("  → en-doc は en-wiki に近い。**コーパス/ジャンルは主因ではない＝言語が主因**")
else:
    log("  → en-doc は en-wiki から離れている。**コーパス/ジャンルが効いている**")

with open("p6q_compare.json", "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=2)
with open("p6q_out_utf8.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(LOG))
