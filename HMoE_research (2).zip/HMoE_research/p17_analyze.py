# -*- coding: utf-8 -*-
"""P17 解析: 「答えが出たか」ベースの除去規則は打ち切り規則より良いか

P16 の穴: 打ち切り（ntok==96）を「答えなし」とすると、難課題では正解まで捨てる
（mul2 の clean oracle 0.900 < all 1.000）。除去規則を「答えが出たか」に置き換える。

規則（すべて GT 不使用）:
  all     : 除去なし
  trunc   : ntok < 96                          （P15/P16 の規則）
  dig     : 抽出値の桁数がオペランドから導ける範囲に入る（答えの型検査）
  dig_tr  : dig かつ trunc
  box     : \\boxed がある、または "final answer"/"the answer is" を含む

dig は**正解の必要条件**（正解の桁数は必ず範囲に入る）→ recall 1.0 は構成上自明。
したがって評価するのは「どれだけ junk を落とせるか」と「選択品質が上がるか」。

出力: p17_analysis.json / p17_analysis_out_utf8.txt
"""

import json
import os
import re
from collections import Counter

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
LEVELS = ["add5", "mul2"]
OUT = []
NUM_RE = re.compile(r"-?\d[\d,]*")


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def auroc(scores, labels):
    s = np.asarray(scores, float)
    y = np.asarray(labels, bool)
    ok = np.isfinite(s)
    s, y = s[ok], y[ok]
    pos, neg = s[y], s[~y]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    d = (pos[:, None] > neg[None, :]).sum() + 0.5 * (pos[:, None] == neg[None, :]).sum()
    return float(d / (len(pos) * len(neg)))


def paired(arr):
    a = np.asarray(arr, float)
    a = a[np.isfinite(a)]
    mean = float(np.mean(a))
    sd = float(np.std(a, ddof=1))
    se = sd / np.sqrt(len(a))
    if sd > 0:
        t, p = stats.ttest_1samp(a, 0.0)
        mde = float(2.802 * sd / np.sqrt(len(a)))
    else:
        t, p, mde = float("nan"), float("nan"), float("nan")
    return {"mean": mean, "se": float(se), "t": float(t), "p": float(p),
            "n": int(len(a)), "mde80": mde}


def digits_ok(pred, q):
    """オペランドの桁だけから導く妥当桁数（gold を計算しない）。"""
    if pred is None or not re.fullmatch(r"-?\d+", pred):
        return False
    m = re.match(r"Compute (\d+) ([-+*]) (\d+)\.", q)
    if not m:
        return False
    la, lb, op = len(m.group(1)), len(m.group(3)), m.group(2)
    if op == "+":
        allowed = {la, la + 1} if la == lb else {max(la, lb), max(la, lb) + 1}
    elif op == "-":
        allowed = set(range(1, max(la, lb) + 1))
    else:
        allowed = {la + lb - 1, la + lb}
    return len(pred.lstrip("-")) in allowed


def has_box(txt):
    return bool(re.search(r"\\boxed\s*\{", txt)) or bool(
        re.search(r"final answer|the answer is|the result is|answer is", txt.lower()))


POOLS = {
    "all": lambda s, q: True,
    "trunc": lambda s, q: s["ntok"] < 96,
    "dig": lambda s, q: digits_ok(s["pred"], q),
    "dig_tr": lambda s, q: digits_ok(s["pred"], q) and s["ntok"] < 96,
    "box": lambda s, q: has_box(s["text"]),
}


def pick(sub, q, pool, key):
    cand = [(j, s) for j, s in enumerate(sub)
            if s[key] is not None and s["pred"] is not None and pool(s, q)]
    if not cand:
        return None
    return max(cand, key=lambda t: (t[1][key], -t[0]))[1]


def maj(sub, q, pool):
    cand = [s for s in sub if s["pred"] is not None and pool(s, q)]
    if not cand:
        return None
    by = {}
    for s in cand:
        by.setdefault(s["pred"], []).append(s)
    best = None
    for pred, lst in by.items():
        k = (len(lst), max(x["p_ans"] for x in lst))
        if best is None or k > best[0]:
            best = (k, pred, lst)
    _, pred, lst = best
    rep = max(lst, key=lambda s: s["p_ans"])
    return {"pred": pred, "share": len(lst) / float(len(cand)), "rep": rep["p_ans"],
            "n_pool": len(cand)}


def main():
    rows = [json.loads(l) for l in open(os.path.join(HERE, "p17_runs.jsonl"),
                                        encoding="utf-8") if l.strip()]
    summary = {"levels": {}}

    for lv in LEVELS:
        rlv = [r for r in rows if r["level"] == lv]
        rounds = sorted(set(r["round"] for r in rlv))
        by_round = {ri: [r for r in rlv if r["round"] == ri] for ri in rounds}
        P = len(by_round[rounds[0]])
        pairs = [(ri, by_round[ri][i]) for ri in rounds for i in range(P)]
        S = [s for r in rlv for s in r["samples"]]
        y = np.array([bool(s["correct"]) for s in S])
        log("\n=== %s === pairs=%d samples=%d correct=%d" % (lv, len(pairs), len(S), y.sum()))

        # ---- 1. 各規則の被覆と上界 ----
        log("  [1] pool coverage and ceiling")
        log("     %-7s %7s %10s %10s %10s" %
            ("pool", "cover", "mean|pool|", "pool acc", "oracle"))
        cov = {}
        for pname, pool in POOLS.items():
            sizes, accs, orc = [], [], []
            for ri, r in pairs:
                sub = r["samples"]
                c = [s for s in sub if pool(s, r["q"]) and s["pred"] is not None]
                sizes.append(len(c))
                if c:
                    accs.append(float(np.mean([bool(s["correct"]) for s in c])))
                    orc.append(float(any(s["correct"] for s in c)))
            cov[pname] = {"coverage": float(np.mean([1 if k > 0 else 0 for k in sizes])),
                          "mean_pool": float(np.mean(sizes)),
                          "pool_acc": float(np.mean(accs)),
                          "oracle": float(np.mean(orc))}
            log("     %-7s %7.3f %10.2f %10.4f %10.4f"
                % (pname, cov[pname]["coverage"], cov[pname]["mean_pool"],
                   cov[pname]["pool_acc"], cov[pname]["oracle"]))

        # ---- 2. 規則 × プールの選択品質（被覆ペアのみ）----
        log("  [2] selection quality (each pool on its covered pairs)")
        log("     %-7s %5s %8s %8s %8s %8s %8s" %
            ("pool", "n", "s1", "confmax", "confmaxF", "maj", "gap(maj)"))
        tb = {}
        for pname, pool in POOLS.items():
            acc = {"s1": [], "cm": [], "cmf": [], "mj": []}
            conf = {"cm": [], "cmf": [], "mj": []}
            for ri, r in pairs:
                sub, q, gold = r["samples"], r["q"], r["gold"]
                c = [s for s in sub if pool(s, q) and s["pred"] is not None]
                if not c:
                    continue
                acc["s1"].append(float(sub[0]["pred"] == gold))
                a = pick(sub, q, pool, "p_ans")
                b = pick(sub, q, pool, "p_full")
                m = maj(sub, q, pool)
                acc["cm"].append(float(a["pred"] == gold))
                acc["cmf"].append(float(b["pred"] == gold))
                acc["mj"].append(float(m["pred"] == gold))
                conf["cm"].append(a["p_ans"])
                conf["cmf"].append(b["p_full"])
                conf["mj"].append(m["share"])
            row = {"n": len(acc["s1"]),
                   "s1": float(np.mean(acc["s1"])),
                   "confmax": float(np.mean(acc["cm"])),
                   "confmaxF": float(np.mean(acc["cmf"])),
                   "maj": float(np.mean(acc["mj"])),
                   "gap_maj": float(np.mean(conf["mj"]) - np.mean(acc["mj"])),
                   "auc_maj": auroc(conf["mj"], acc["mj"]),
                   "auc_confmaxF": auroc(conf["cmf"], acc["cmf"])}
            tb[pname] = row
            log("     %-7s %5d %8.4f %8.4f %8.4f %8.4f %+8.4f"
                % (pname, row["n"], row["s1"], row["confmax"], row["confmaxF"],
                   row["maj"], row["gap_maj"]))

        # ---- 3. 対応比較: 全プールが非空のペアで confmax / maj を比べる ----
        log("  [3] matched: confmax and maj on pairs where every pool is non-empty")
        common = []
        for ri, r in pairs:
            if all(any(POOLS[p](s, r["q"]) and s["pred"] is not None for s in r["samples"])
                   for p in POOLS):
                common.append((ri, r))
        log("     common pairs = %d / %d" % (len(common), len(pairs)))
        per = {p: {"cm": [], "mj": [], "cmf": []} for p in POOLS}
        s1a = []
        for ri, r in common:
            sub, q, gold = r["samples"], r["q"], r["gold"]
            s1a.append(float(sub[0]["pred"] == gold))
            for p in POOLS:
                per[p]["cm"].append(float(pick(sub, q, POOLS[p], "p_ans")["pred"] == gold))
                per[p]["cmf"].append(float(pick(sub, q, POOLS[p], "p_full")["pred"] == gold))
                per[p]["mj"].append(float(maj(sub, q, POOLS[p])["pred"] == gold))
        s1a = np.array(s1a)
        tests = []
        for p in POOLS:
            for rule in ["cm", "cmf", "mj"]:
                a = np.array(per[p][rule])
                w10 = int(np.sum(a.astype(bool) & ~s1a.astype(bool)))
                w01 = int(np.sum(~a.astype(bool) & s1a.astype(bool)))
                pmc = (float(stats.binomtest(w10, w10 + w01, 0.5).pvalue)
                       if (w10 + w01) > 0 else float("nan"))
                tests.append({"pool": p, "rule": rule, "dAcc": paired(a - s1a),
                              "mcnemar": {"w": w10, "b": w01, "p": pmc}})
        for t_ in tests:
            if t_["rule"] == "cm":
                log("     %-7s confmax dAcc=%+.4f (t=%+.2f, p=%.3g, McN %d/%d p=%.3g)"
                    % (t_["pool"], t_["dAcc"]["mean"], t_["dAcc"]["t"], t_["dAcc"]["p"],
                       t_["mcnemar"]["w"], t_["mcnemar"]["b"], t_["mcnemar"]["p"]))
        # dig vs trunc の直接比較（同一ペア）
        if "dig" in per and "trunc" in per:
            a = np.array(per["dig"]["cm"])
            b = np.array(per["trunc"]["cm"])
            d = a - b
            w10 = int(np.sum(a.astype(bool) & ~b.astype(bool)))
            w01 = int(np.sum(~a.astype(bool) & b.astype(bool)))
            pmc = (float(stats.binomtest(w10, w10 + w01, 0.5).pvalue)
                   if (w10 + w01) > 0 else float("nan"))
            log("     confmax(dig) - confmax(trunc): dAcc=%+.4f (t=%+.2f, p=%.3g, McN %d/%d p=%.3g)"
                % (d.mean(), *stats.ttest_1samp(d, 0)[:2], w10, w01, pmc))
            summary.setdefault(lv, {})["dig_vs_trunc_confmax"] = {
                "dAcc": paired(d), "mcnemar": {"w": w10, "b": w01, "p": pmc}}

        summary[lv] = {"pairs": len(pairs), "n_common": len(common),
                       "coverage": cov, "table": tb, "tests": tests,
                       "common_pairs_acc": {p: {k: float(np.mean(v)) for k, v in per[p].items()}
                                            for p in POOLS}}

    with open(os.path.join(HERE, "p17_analysis.json"), "w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    with open(os.path.join(HERE, "p17_analysis_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    log("saved: p17_analysis.json")
    os._exit(0)


if __name__ == "__main__":
    main()
