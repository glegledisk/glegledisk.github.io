"""H7 の解析: 負荷分散の有無が二峰性を生むかを見る。"""
import json
import os
from collections import defaultdict

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SUCCESS = 0.5


def main():
    rows = []
    with open(os.path.join(HERE, "h7_results.jsonl"), encoding="utf-8") as fp:
        for line in fp:
            if line.strip():
                rows.append(json.loads(line))
    if not rows:
        print("no data")
        return

    by = defaultdict(list)
    for r in rows:
        by[(r["lam"], r["aux_mode"])].append(r)

    print("=== 条件別（seed 平均 ± SD）===")
    print("%6s %-8s %7s %7s %7s %7s %7s %7s %7s %6s" %
          ("lam", "aux", "val", "sd", "cost", "d1", "d1_sd", "share", "H", "成功"))
    for (lm, m), rs in sorted(by.items()):
        v = np.array([r["val"] for r in rs])
        c = np.array([r["cost"] for r in rs])
        d1 = np.array([r["cells"]["depth1"] for r in rs])
        sh = np.array([r["diag"]["depth1"]["top1_share"] for r in rs])
        en = np.array([r["diag"]["depth1"]["entropy"] for r in rs])
        print("%6.3f %-8s %7.3f %7.3f %7.3f %7.3f %7.3f %7.2f %7.2f %6s" %
              (lm, m, v.mean(), v.std(ddof=1) if len(v) > 1 else 0, c.mean(),
               d1.mean(), d1.std(ddof=1) if len(d1) > 1 else 0,
               sh.mean(), en.mean(), f"{int((d1 < SUCCESS).sum())}/{len(d1)}"))

    print("\n=== 個別 seed ===")
    print("%6s %-8s %4s %8s %7s %8s %7s" % ("lam", "aux", "seed", "d1", "share", "entropy", "cost"))
    for (lm, m), rs in sorted(by.items()):
        for r in sorted(rs, key=lambda x: x["seed"]):
            d = r["diag"]["depth1"]
            print("%6.3f %-8s %4d %8.3f %7.2f %8.2f %7.2f" %
                  (lm, m, r["seed"], r["cells"]["depth1"], d["top1_share"], d["entropy"], r["cost"]))

    print("\n=== 二峰性の指標（d1 の SD が小さいほど再現する）===")
    print("%6s %-8s %10s %10s %8s" % ("lam", "aux", "d1 の SD", "val の SD", "成功"))
    for (lm, m), rs in sorted(by.items()):
        d1 = np.array([r["cells"]["depth1"] for r in rs])
        v = np.array([r["val"] for r in rs])
        print("%6.3f %-8s %10.3f %10.3f %8s" %
              (lm, m, d1.std(ddof=1) if len(d1) > 1 else 0,
               v.std(ddof=1) if len(v) > 1 else 0,
               f"{int((d1 < SUCCESS).sum())}/{len(d1)}"))


if __name__ == "__main__":
    main()
