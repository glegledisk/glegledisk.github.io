import re, sys
from markdown_it import MarkdownIt
src = open(sys.argv[1], encoding="utf-8").read()
md = MarkdownIt("commonmark").enable("table")
html = md.render(src)
ols = re.findall(r"<ol>.*?</ol>", html, re.S)
print("=== 最初の <ol>（§0 結論）===")
print(ols[0][:1800] if ols else "none")
print("\n=== 各 ol の項目数 ===")
for i, o in enumerate(ols):
    print(f"  ol{i}: {o.count('<li>')} items")