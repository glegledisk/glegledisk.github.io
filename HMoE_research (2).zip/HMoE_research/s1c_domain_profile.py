# -*- coding: utf-8 -*-
"""S1c: profile the five SearchTome domains and relate them to the S1b A/B split.

Features are computed from three sources only:
  data_searchtome/<domain>_corpus.jsonl   (section title + text)
  data_searchtome/<domain>_test.jsonl     (full query set)
  s1_manifest.json                        (the 15 selected queries + candidates)

Outcome variables (A, B) are read from s1b_analysis.json / s1_core.npz and are
NOT recomputed here.

Writes s1c_domain_profile.json / s1c_domain_profile_out_utf8.txt
"""
import difflib
import json
import math
import os
import re
from collections import Counter

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LINES = []

STOP = set("""the a an of and or to in for on with by from as at is are be been being this that these those
it its your you we our their his her them they i he she not but if when which what how why who whom whose can
could may might will would shall should must do does did done than then into within about over under between
among such other others more most some any all each both one two three first second new using use used also
there here where while because so than only just very much many few own same""".split())


def w(s=""):
    LINES.append(str(s))
    print(s, flush=True)


def content_words(s):
    s = re.sub(r"^\s*\d+(?:\.\d+)*\.?\s*", "", s)
    toks = re.findall(r"[A-Za-z][A-Za-z\-']+", s.lower())
    return [t for t in toks if t not in STOP and len(t) > 1]


def jaccard(a, b):
    A, B = set(a), set(b)
    if not A or not B:
        return float("nan")
    return len(A & B) / len(A | B)


def shared_rate(a, b):
    A, B = set(a), set(b)
    if not A or not B:
        return float("nan")
    return len(A & B) / min(len(A), len(B))


def num_parts(t):
    m = re.match(r"^\s*(\d+(?:\.\d+)*)", t)
    return [int(x) for x in m.group(1).split(".")] if m else None


def parent_key(t):
    p = num_parts(t)
    return tuple(p[:-1]) if p and len(p) > 1 else None


def mean(xs):
    xs = [x for x in xs if x == x]
    return float(np.mean(xs)) if xs else float("nan")


def sd(xs):
    xs = [x for x in xs if x == x]
    return float(np.std(xs, ddof=1)) if len(xs) > 1 else float("nan")


def spearman(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    rx = np.argsort(np.argsort(x)).astype(float)
    ry = np.argsort(np.argsort(y)).astype(float)
    return float(np.corrcoef(rx, ry)[0, 1])


with open(os.path.join(HERE, "s1_manifest.json"), encoding="utf-8") as f:
    man = json.load(f)
with open(os.path.join(HERE, "s1b_analysis.json"), encoding="utf-8") as f:
    s1b = json.load(f)

DOMS = ["finance", "law", "medicine", "natural_sciences", "social_sciences"]
OUT = {}

for dom in DOMS:
    with open(os.path.join(HERE, "data_searchtome", dom + "_corpus.jsonl"), encoding="utf-8") as f:
        docs = [json.loads(line) for line in f]
    with open(os.path.join(HERE, "data_searchtome", dom + "_test.jsonl"), encoding="utf-8") as f:
        test = [json.loads(line) for line in f]

    titles = [d["title"] for d in docs]
    contents = [d["content"] for d in docs]

    # ---- title structure ----
    tlen = [len(content_words(t)) for t in titles]
    traw = [len(re.sub(r"^\s*\d+(?:\.\d+)*\.?\s*", "", t).split()) for t in titles]
    depths = [len(num_parts(t)) if num_parts(t) else 0 for t in titles]
    by_parent = {}
    for t in titles:
        pk = parent_key(t)
        if pk is not None:
            by_parent.setdefault(pk, []).append(t)
    branch = [len(v) for v in by_parent.values()]

    # paradigm tightness: mean pairwise jaccard inside each parent group
    tight = []
    marker_cov = []
    for v in by_parent.values():
        if len(v) < 2:
            continue
        cw = [content_words(t) for t in v]
        js = [jaccard(cw[i], cw[j]) for i in range(len(cw)) for j in range(i + 1, len(cw))]
        if js:
            tight.append(float(np.mean(js)))
        cnt = Counter(x for c in cw for x in set(c))
        if cnt:
            marker_cov.append(cnt.most_common(1)[0][1] / len(v))

    # vocabulary richness on titles
    all_tw = [x for t in titles for x in content_words(t)]
    ttr_title = len(set(all_tw)) / max(1, len(all_tw))

    # ---- prose ----
    text = "\n".join(contents)
    toks = re.findall(r"[A-Za-z0-9]+", text)
    ntok = len(toks)
    low = [t.lower() for t in toks]
    doc_ttr = []
    for c in contents:
        ct = [x.lower() for x in re.findall(r"[A-Za-z]+", c)]
        if len(ct) > 200:
            doc_ttr.append(len(set(ct)) / len(ct))
    sents = re.split(r"[.!?]+", text)
    sent_len = np.mean([len(s.split()) for s in sents if len(s.split()) > 3]) if sents else float("nan")
    digits = sum(1 for t in toks if any(ch.isdigit() for ch in t)) / max(1, ntok) * 1000
    math_sym = sum(text.count(s) for s in "=+×÷%²³§") / max(1, ntok) * 1000
    fig = len(re.findall(r"\b(Figure|Table|Fig\.)\b", text)) / max(1, ntok) * 1000
    you = low.count("you") / max(1, ntok) * 1000
    because = low.count("because") / max(1, ntok) * 1000
    must = (low.count("must") + low.count("shall")) / max(1, ntok) * 1000
    lo = len(re.findall(r"Learning Objectives|will be able to", text, re.I)) / max(1, len(contents))

    # ---- queries (full test set) ----
    qlen = [len(q["query"].split()) for q in test]
    q_digit = np.mean([bool(re.search(r"\d", q["query"])) for q in test])
    q_what = np.mean([q["query"].strip().lower().startswith(("what", "how", "why", "which", "who", "when", "where"))
                      for q in test])
    ans_digit = np.mean([bool(re.search(r"\d", q.get("answer", ""))) for q in test])
    ans_len = [len(q.get("answer", "").split()) for q in test]
    qg_jac, qg_head = [], []
    for q in test:
        qw = content_words(q["query"])
        gw = content_words(q["gold_doc_title"])
        qg_jac.append(jaccard(qw, gw))
        qg_head.append(1.0 if (gw and gw[-1] in set(qw)) else 0.0)

    # ---- manifest: selected 15 + sibling geometry ----
    ents = man["domains"][dom]["entries"]
    sib_jac, sib_share, sib_edit, sib_head, sib_len_ratio = [], [], [], [], []
    for e in ents:
        sib = next((c for c in e["candidates"] if c["type"] == "sibling"), None)
        if sib is None:
            continue
        a = content_words(e["gold"])
        b = content_words(sib["title"])
        sib_jac.append(jaccard(a, b))
        sib_share.append(shared_rate(a, b))
        sib_edit.append(difflib.SequenceMatcher(None, " ".join(a), " ".join(b)).ratio())
        sib_head.append(1.0 if (a and b and a[-1] == b[-1]) else 0.0)
        sib_len_ratio.append(min(len(a), len(b)) / max(len(a), len(b), 1))
    train = [e["gold_train_count"] for e in ents]
    gold_depth = [e["gold_depth"] for e in ents]

    OUT[dom] = {
        "book": man["domains"][dom]["book"],
        "n_titles": len(titles),
        "n_test": len(test),
        "title_words_mean": mean(tlen),
        "title_words_median": float(np.median(tlen)),
        "title_words_sd": sd(tlen),
        "title_raw_words_mean": mean(traw),
        "title_raw_short_frac": float(np.mean([x <= 4 for x in traw])),
        "title_short_frac": float(np.mean([x <= 3 for x in tlen])),
        "marker_coverage": mean(marker_cov),
        "depth_mean": mean(depths),
        "depth_hist": {int(k): int(v) for k, v in zip(*np.unique(depths, return_counts=True))},
        "n_chapters": int(sum(1 for x in depths if x == 1)),
        "max_depth": int(max(depths)) if depths else 0,
        "branch_mean": mean(branch),
        "branch_max": int(max(branch)) if branch else 0,
        "paradigm_tightness": mean(tight),
        "title_ttr": ttr_title,
        "doc_chars_mean": mean([len(c) for c in contents]),
        "doc_ttr": mean(doc_ttr),
        "sent_len": float(sent_len),
        "digit_per_1k": digits,
        "math_sym_per_1k": math_sym,
        "figure_per_1k": fig,
        "you_per_1k": you,
        "because_per_1k": because,
        "must_per_1k": must,
        "learning_obj_per_doc": lo,
        "query_words": mean(qlen),
        "query_digit_frac": float(q_digit),
        "query_wh_frac": float(q_what),
        "answer_digit_frac": float(ans_digit),
        "answer_words": mean(ans_len),
        "query_gold_jaccard": mean(qg_jac),
        "query_gold_head_frac": mean(qg_head),
        "sibling_jaccard": mean(sib_jac),
        "sibling_shared_rate": mean(sib_share),
        "sibling_edit_ratio": mean(sib_edit),
        "sibling_same_head_frac": mean(sib_head),
        "sibling_len_ratio": mean(sib_len_ratio),
        "gold_train_mean": mean(train),
        "gold_depth_mean": mean(gold_depth),
        "n_sibling": len(sib_jac),
    }

# ---- outcomes from S1b ----
for dom in DOMS:
    OUT[dom]["A"] = s1b["by_domain"][dom]["A"]["mean"]
    OUT[dom]["B"] = s1b["by_domain"][dom]["B"]["mean"]
    OUT[dom]["A_plus_B"] = s1b["by_domain"][dom]["A_plus_B"]["mean"]

keys = [
    ("n_titles", "ToC titles"),
    ("title_words_mean", "title content words"),
    ("title_raw_words_mean", "title raw words"),
    ("title_raw_short_frac", "title <=4 raw words"),
    ("marker_coverage", "chapter marker coverage"),
    ("title_short_frac", "title <=3 words"),
    ("branch_mean", "children/parent"),
    ("paradigm_tightness", "sibling-set Jaccard"),
    ("sibling_jaccard", "gold-sibling Jaccard"),
    ("sibling_shared_rate", "shared-word rate"),
    ("sibling_same_head_frac", "same head word"),
    ("query_words", "query words"),
    ("query_gold_jaccard", "query-gold Jaccard"),
    ("answer_digit_frac", "answer has digit"),
    ("doc_ttr", "doc type-token ratio"),
    ("digit_per_1k", "digits / 1k tok"),
    ("figure_per_1k", "Figure/Table / 1k"),
    ("you_per_1k", "\"you\" / 1k"),
    ("because_per_1k", "\"because\" / 1k"),
    ("must_per_1k", "must/shall / 1k"),
    ("sent_len", "sentence length"),
    ("gold_train_mean", "gold train count"),
]

w("")
w("%-16s %-42s %7s %7s %7s" % ("domain", "book", "A", "B", "A+B"))
for dom in DOMS:
    o = OUT[dom]
    w("%-16s %-42s %+7.3f %+7.3f %+7.3f" % (dom, o["book"][:42], o["A"], o["B"], o["A_plus_B"]))

w("")
w("%-26s %8s %8s %8s %8s %8s" % ("feature", *[d[:8] for d in DOMS]))
for k, lab in keys:
    w("%-26s %8.3f %8.3f %8.3f %8.3f %8.3f" % (lab, *[OUT[d][k] for d in DOMS]))
w("%-26s %8d %8d %8d %8d %8d" % ("chapters (depth 1)", *[OUT[d]["n_chapters"] for d in DOMS]))
w("%-26s %8d %8d %8d %8d %8d" % ("max depth", *[OUT[d]["max_depth"] for d in DOMS]))
w("%-26s %8s %8s %8s %8s %8s" % ("depth histogram", *["" for _ in DOMS]))
for d in DOMS:
    w("  %-16s %s" % (d, json.dumps(OUT[d]["depth_hist"])))

Avec = [OUT[d]["A"] for d in DOMS]
Bvec = [OUT[d]["B"] for d in DOMS]
ABvec = [OUT[d]["A_plus_B"] for d in DOMS]
w("")
w("Spearman with S1b outcome (n=5 domains; descriptive)")
w("%-26s %8s %8s %8s" % ("feature", "A", "B", "A+B"))
for k, lab in keys:
    fv = [OUT[d][k] for d in DOMS]
    w("%-26s %+8.2f %+8.2f %+8.2f" % (lab, spearman(fv, Avec), spearman(fv, Bvec), spearman(fv, ABvec)))

w("")
w("== manifest entries (gold | sibling | query) ==")
for dom in DOMS:
    w("")
    w("-- %s (%s) --" % (dom, man["domains"][dom]["book"]))
    for e in man["domains"][dom]["entries"]:
        sib = next((c["title"] for c in e["candidates"] if c["type"] == "sibling"), "-")
        w("  G: %-58s | S: %s" % (e["gold"][:58], sib[:58]))
        w("  Q: %s" % e["query"][:150])

with open(os.path.join(HERE, "s1c_domain_profile.json"), "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=1, default=float)
with open(os.path.join(HERE, "s1c_domain_profile_out_utf8.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(LINES))
print("wrote s1c_domain_profile.json")
