# -*- coding: utf-8 -*-
"""S1d: build manifests for the 3 social-sciences books (SGK86 SearchTome rebuild).

Content leaves only (front/back matter and <200-char stubs removed), one query
per gold leaf, length-matched sibling under the same parent, length-matched far
leaf in a different top-level chapter.

Writes s1d_manifest.json
"""
import json
import os
import random
import re
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "s1d_manifest.json")
BOOKS = {
    "auralskills": "Aural Skills (Foundations of Aural Skills)",
    "behavioralecon": "A Practicum in Behavioral Economics",
    "compgov": "Introduction to Comparative Government and Politics",
}
N_PER_BOOK = 20
SEED = 13

EXCLUDE = re.compile(
    r"^(contents|table of contents|preface|dedication|acknowledg|about the authors?|"
    r"references?|bibliography|index|glossary|key terms?|review questions?|study questions?|"
    r"learning objectives?|chapter outline|chapter (one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|\d+)|"
    r"appendix|appendices|web ?sites?|articles|books|datasets?( and websites)?|further reading|"
    r"notes|image credits|media attributions|versioning history|accessibility|licen[cs]e|"
    r"organization of this book|approaching this textbook|"
    r"dr\.\s|professor\s|about the book|how to use|note to (instructors|students)|"
    r"this book|the textbook|introduction to the book)",
    re.I,
)


def idsort(s):
    return [int(x) for x in str(s).split(".")]


def parent(leaf_id):
    return tuple(str(leaf_id).split(".")[:-1])


def top(leaf_id):
    return str(leaf_id).split(".")[0]


def clean_title(s):
    s = str(s)
    for a, b in (("窶冱", "'s"), ("窶・", "-"), ("窶廃", "-"), ("窶", ""), ("\ufffd", "")):
        s = s.replace(a, b)
    s = re.sub(r"^\s*\d+(?:\.\d+)*\s*[:.]?\s*", "", s)  # embedded numbering
    s = s.replace("**", "").replace("*", "")
    s = re.sub(r"[^\x00-\x7f]", lambda m: m.group(0) if m.group(0) in "éèêàçüöäñ" else "", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


PERSON = re.compile(r"^[A-Z][a-z]+(?: [A-Z][a-z]+){1,2}$")
BIO = re.compile(r"Ph\.?\s?D|Professor|Dr\.|University|research interests|received (his|her)", re.I)


def is_bio(title, text):
    return bool(PERSON.match(title)) and len(text) < 2500 and len(BIO.findall(text)) >= 2


def main():
    rng = random.Random(SEED)
    out = {"books": BOOKS, "seed": SEED, "n_per_book": N_PER_BOOK, "domains": {}}

    for bid, book in BOOKS.items():
        with open(os.path.join(HERE, "data_sgk", bid + "_leaf_docs.jsonl"), encoding="utf-8") as f:
            leaves = [json.loads(line) for line in f]
        leaves = [r for r in leaves if r.get("leaf_id") is not None and r.get("title")]
        leaves.sort(key=lambda r: idsort(r["leaf_id"]))
        content = []
        for r in leaves:
            t = clean_title(r["title"])
            if len(r.get("text") or "") < 200:
                continue
            if EXCLUDE.match(t):
                continue
            if is_bio(t, r.get("text") or ""):
                continue
            r["title_clean"] = t
            content.append(r)
        by_parent = defaultdict(list)
        for r in content:
            by_parent[parent(r["leaf_id"])].append(r)
        by_top = defaultdict(list)
        for r in content:
            by_top[top(r["leaf_id"])].append(r)

        with open(os.path.join(HERE, "data_sgk", bid + "_questions.jsonl"), encoding="utf-8") as f:
            qs = [json.loads(line) for line in f]
        qs = [q for q in qs if q.get("split") == "test" and q.get("leaf_id") is not None and q.get("leaf_title")]
        content_ids = {str(r["leaf_id"]) for r in content}
        qs = [q for q in qs if str(q["leaf_id"]) in content_ids]

        cands = []
        for q in qs:
            gid = str(q["leaf_id"])
            sibs = [r for r in by_parent[parent(gid)] if str(r["leaf_id"]) != gid]
            if parent(gid) == () or len(sibs) == 0:
                continue
            cands.append((q, sibs))

        by_ch = defaultdict(list)
        for q, sibs in cands:
            by_ch[top(str(q["leaf_id"]))].append((q, sibs))
        for k in by_ch:
            by_ch[k].sort(key=lambda t: str(t[0].get("paragraph_id", "")))
            rng.shuffle(by_ch[k])
        chosen, used_gold = [], set()
        order = sorted(by_ch, key=lambda x: idsort(x))
        while len(chosen) < N_PER_BOOK and order:
            for k in list(order):
                if len(chosen) >= N_PER_BOOK:
                    break
                while by_ch[k]:
                    q, sibs = by_ch[k].pop()
                    if str(q["leaf_id"]) in used_gold:
                        continue
                    used_gold.add(str(q["leaf_id"]))
                    chosen.append((q, sibs))
                    break
                if not by_ch[k]:
                    order.remove(k)

        entries = []
        for q, sibs in chosen:
            gid = str(q["leaf_id"])
            gtitle = clean_title(q["leaf_title"])
            sib = min(sibs, key=lambda r: (abs(len(r["title_clean"]) - len(gtitle)), rng.random()))
            far_pool = [r for r in content if top(str(r["leaf_id"])) != top(gid)]
            far = min(far_pool, key=lambda r: (abs(len(r["title_clean"]) - len(gtitle)), rng.random())) if far_pool else None
            entries.append({
                "book_id": bid,
                "query": q["query"],
                "gold_id": gid,
                "gold": gtitle,
                "gold_depth": len(str(gid).split(".")),
                "sibling_id": str(sib["leaf_id"]),
                "sibling": sib["title_clean"],
                "far_id": str(far["leaf_id"]) if far else None,
                "far": far["title_clean"] if far else None,
                "paragraph_id": q.get("paragraph_id"),
                "n_sibling_pool": len(sibs),
            })

        toc = [{"id": str(r["leaf_id"]), "title": r["title_clean"]} for r in content]
        out["domains"][bid] = {"book": book, "toc": toc, "entries": entries,
                               "n_leaves": len(leaves), "n_content": len(content),
                               "n_test": len(qs), "n_candidates": len(cands)}
        print("%-16s leaves=%d content=%d test=%d cand=%d chosen=%d"
              % (bid, len(leaves), len(content), len(qs), len(cands), len(entries)))

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
