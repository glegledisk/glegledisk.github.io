#!/usr/bin/env python3
"""P19 補助: 位置種別（SRC / OUT）で routing はどれだけ違うか（使い捨て）

k（編集数）は routing をほとんど動かさなかった（flops/token 648→651）。
このテストベッドで作れる異質性の別軸として「prompt 側（SRC）か answer 側（OUT）か」を見る。
"""
import os
import sys

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
SIM = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, SIM)
from e2b_rewrite_routing_fixed import RewriteMoE, WIDTHS, to_seq, SL, OL  # noqa: E402
from p19_fanout import load_model, make_fixed_k  # noqa: E402

torch.set_grad_enabled(False)
for arm in ["U+LB", "H+LB"]:
    w = torch.tensor(WIDTHS[arm], dtype=torch.float64)
    print("=== %s ===" % arm)
    for seed in [0, 1, 2]:
        m = load_model(arm, seed)
        rng = np.random.default_rng(2000 + seed)
        src, out = make_fixed_k(rng, 64, 0)
        _, _, idxs = m(to_seq(src, out), need_idx=True)
        for name, sl in [("SRC", slice(0, SL)), ("OUT", slice(SL + 1, SL + 1 + OL))]:
            per = torch.zeros(0, dtype=torch.float64)
            cnt = torch.zeros(len(WIDTHS[arm]), dtype=torch.float64)
            for ix in idxs:
                sub = ix[:, sl, :]
                per = torch.cat([per, w[sub].sum(-1).reshape(-1)])
                for j in range(sub.shape[-1]):
                    e = sub[:, :, j].reshape(-1)
                    cnt.index_add_(0, e, torch.ones_like(e, dtype=torch.float64))
            share = cnt / cnt.sum()
            print("  s%d %-3s flops/tok=%.1f  max_share=%.3f  min_share=%.3f"
                  % (seed, name, per.mean(), share.max(), share.min()))
    print("")
