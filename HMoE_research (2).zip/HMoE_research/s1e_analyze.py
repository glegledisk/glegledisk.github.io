# -*- coding: utf-8 -*-
"""S1e analysis: does the explicit hierarchy (section numbers) matter?

Contrasts on the same queries:
    toc - flat     numbers removed, order and titles kept   -> hierarchy effect
    flat - shuffle order without numbers                    -> order effect (no numbers)
    flat - none    title list without numbers               -> list effect
    toc - shuffle  order + numbers (S1 replication)
    toc - none     total ToC effect

Also recomputes the A/B decomposition with flat as the reference:
    A_flat = flat - toc_drop ; B_flat = flat - distractor_drop ; A_flat + B_flat
"""
import json
import math
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
FAR5 = ["finance", "law", "medicine", "natural_sciences", "social_sciences"]
LINES = []


def w(s=""):
    LINES.append(str(s))
    print(s, flush=True)


def paired(d, name=""):
    d = np.asarray(d, float)
    d = d[np.isfinite(d)]
    n = d.size
    if n < 3:
        return dict(name=name, n=int(n), mean=float("nan"))
    m = float(d.mean())
    se = float(d.std(ddof=1)) / math.sqrt(n)
    t = m / se
    p = float(stats.t.sf(abs(t), n - 1) * 2)
    a = np.sort(np.abs(d))[::-1]
    k = max(1, int(math.ceil(0.01 * n)))
    return dict(name=name, n=int(n), mean=m, se=se, t=t, p=p, mde=2.8 * se,
                median=float(np.median(d)), top1=float(a[:k].sum() / (np.abs(d).sum() + 1e-30)),
                mn=float(d.min()), mx=float(d.max()))


def show(tag, s):
    if "se" not in s:
        w("%-34s n=%d (too few)" % (tag, s["n"]))
        return
    w("%-34s %+0.4f (se %0.4f, t=%+0.2f, p=%.4f, n=%d, MDE %.3f, med %+0.3f)"
      % (tag, s["mean"], s["se"], s["t"], s["p"], s["n"], s["mde"], s["median"]))


def load_margins(path, prompt_filter=None):
    z = np.load(path, allow_pickle=True)
    n = len(z["row_domain"])
    keys = [(str(z["row_domain"][i]), int(z["row_query_id"][i]),
             str(z["row_prompt"][i]), str(z["row_ablation"][i])) for i in range(n)]
    is_gold = z["row_is_gold"].astype(int)
    ctype = np.array([str(x) for x in z["row_cand_type"]], dtype=object)
    div = z["row_div_idx"].astype(int)
    logp = z["row_logp_div"].astype(float)
    gkeys = [k for k, g in zip(keys, is_gold) if g == 1]
    gpos = {k: i for i, k in enumerate(gkeys)}
    out = {}
    for i in range(n):
        if is_gold[i]:
            continue
        if str(z["row_ablation"][i]) != "base":
            continue
        k = keys[i]
        if prompt_filter and k[2] != prompt_filter:
            continue
        if k not in gpos:
            continue
        j = div[i]
        C = int(z["gold_len"][gpos[k]])
        if 0 <= j < C and np.isfinite(logp[i]):
            out[(k[0], k[1], k[2], ctype[i])] = float(z["gold_logp"][gpos[k], j]) - logp[i]
    return out


def qmap(m, prompt, t, doms=None):
    d = {}
    for (dom, q, p, ct), v in m.items():
        if p != prompt or ct != t:
            continue
        if doms and dom not in doms:
            continue
        d[(dom, q)] = v
    return d


def diff(a, b):
    ks = sorted(set(a) & set(b))
    return np.array([a[k] - b[k] for k in ks]), ks


core = load_margins(os.path.join(HERE, "s1_core.npz"))
flat = load_margins(os.path.join(HERE, "s1e_flat.npz"))
dd = load_margins(os.path.join(HERE, "s1b_distractor_drop.npz"))
w("loaded: core=%d flat=%d dd=%d margins" % (len(core), len(flat), len(dd)))

w("\n== flat vs toc / shuffle / none ==")
for t, doms in (("sibling", None), ("far", FAR5)):
    w("\n-- %s --" % t)
    for p1, p2, lab in (("toc", "flat", "toc - flat (hierarchy)"),
                        ("flat", "shuffle", "flat - shuffle (order, no numbers)"),
                        ("flat", "none", "flat - none (list, no numbers)"),
                        ("toc", "shuffle", "toc - shuffle (order + numbers)"),
                        ("toc", "none", "toc - none (total)")):
        a, b = qmap(core, p1, t, doms), qmap(core, p2, t, doms)
        if p1 == "flat":
            a = qmap(flat, "flat", t, doms)
        if p2 == "flat":
            b = qmap(flat, "flat", t, doms)
        d, _ = diff(a, b)
        show("  " + lab, paired(d))

w("\n== A/B decomposition with flat as reference (sibling, n=73) ==")
ts = qmap(core, "toc", "sibling")
td = qmap(core, "toc_drop", "sibling")
ds = qmap(dd, "distractor_drop", "sibling")
fs = qmap(flat, "flat", "sibling")
common = sorted(set(ts) & set(td) & set(ds) & set(fs))
w("  common queries: %d" % len(common))
A_toc = np.array([ts[k] - td[k] for k in common])
B_toc = np.array([ts[k] - ds[k] for k in common])
A_flat = np.array([fs[k] - td[k] for k in common])
B_flat = np.array([fs[k] - ds[k] for k in common])
show("  A_toc = toc - toc_drop", paired(A_toc))
show("  B_toc = toc - dd", paired(B_toc))
show("  A_flat = flat - toc_drop", paired(A_flat))
show("  B_flat = flat - dd", paired(B_flat))
show("  A_flat + B_flat", paired(A_flat + B_flat))
show("  A_flat - A_toc", paired(A_flat - A_toc))
show("  B_flat - B_toc", paired(B_flat - B_toc))

w("\n== prompt length ==")
z = np.load(os.path.join(HERE, "s1e_flat.npz"), allow_pickle=True)
ig = z["row_is_gold"].astype(int) == 1
gl = z["row_prompt_len"][ig].astype(int)
tl = z["row_toc_prompt_len"][ig].astype(int)
w("  flat = %.1f tokens ; toc = %.1f ; drop = %.1f"
  % (gl.mean(), tl.mean(), (tl - gl).mean()))

out = {
    "n_common_sibling": len(common),
    "prompt_len": {"flat": float(gl.mean()), "toc": float(tl.mean()), "drop": float((tl - gl).mean())},
    "A_toc": paired(A_toc), "B_toc": paired(B_toc),
    "A_flat": paired(A_flat), "B_flat": paired(B_flat),
    "A_flat_plus_B_flat": paired(A_flat + B_flat),
    "A_flat_minus_A_toc": paired(A_flat - A_toc),
    "B_flat_minus_B_toc": paired(B_flat - B_toc),
}
with open(os.path.join(HERE, "s1e_analysis.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1, default=float)
with open(os.path.join(HERE, "s1e_analysis_out_utf8.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(LINES))
print("wrote s1e_analysis.json")
