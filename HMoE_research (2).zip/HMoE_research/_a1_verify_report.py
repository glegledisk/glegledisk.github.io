# -*- coding: utf-8 -*-
"""_a1_verify_report.py — 検証報告_A1 の数値を json から引き直して突合する。

報告書に書いた「導出値」（RMS、比率、差）を、生の json から独立に再計算する。
存在確認で終わらせず、符号と桁まで見る。
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a1")

rows = []
for fn in ("a1_results.json", "a1_results_b.json"):
    with open(os.path.join(D, fn), encoding="utf-8") as fh:
        rows += [r for r in json.load(fh) if "evals" in r]
by = {(r["arm"], r["seed"]): r for r in rows}

ok, bad = [], []


def chk(name, got, want, tol=1e-3):
    if abs(got - want) <= tol * max(1.0, abs(want)):
        ok.append(f"  OK  {name}: {got:.6g} (report {want})")
    else:
        bad.append(f"  NG  {name}: {got:.6g} != report {want}")


def mean_of(arm, key):
    v = [r[key] for r in rows if r["arm"] == arm]
    return float(np.mean(v))


# --- 1. 初期化時の分岐 RMS（報告書 §3-4 の表）---
chk("rms relu", mean_of("relu", "rms_init_raw"), 0.1648)
chk("rms relu2", mean_of("relu2", "rms_init_raw"), 0.1020)
chk("rms swiglu", mean_of("swiglu", "rms_init_raw"), 0.0845)
chk("rms drelu", mean_of("drelu", "rms_init_raw"), 0.0846)
chk("rms relu2 / relu", mean_of("relu2", "rms_init_raw") / mean_of("relu", "rms_init_raw"), 0.619)
chk("rms swiglu / relu", mean_of("swiglu", "rms_init_raw") / mean_of("relu", "rms_init_raw"), 0.513)

# gain が rms 比と整合するか（gain = rms_ref / rms_self）
for a in ("relu2", "swiglu", "drelu"):
    g = mean_of(a, "gain")
    r = mean_of(a, "rms_init_raw") / mean_of(a, "rms_init_ref")
    chk(f"gain {a} == rms_ref/rms_self", g, 1.0 / r, tol=2e-3)

# --- 2. パラメータ比（報告書 §2-3 と §3-1）---
p = {a: by[(a, 0)]["nparam"] for a in ("relu", "relu_w067", "relu_w15", "swiglu", "relu2_w15")}
chk("relu_w15/relu", p["relu_w15"] / p["relu"], 1.391, tol=2e-3)
chk("relu_w067/relu", p["relu_w067"] / p["relu"], 0.739, tol=2e-3)
chk("swiglu/relu", p["swiglu"] / p["relu"], 1.392, tol=2e-3)
chk("relu2_w15/relu", p["relu2_w15"] / p["relu"], 1.391, tol=2e-3)
chk("params relu_w067 (絶対)", p["relu_w067"], 995301, tol=0)
chk("params relu_w15 (絶対)", p["relu_w15"], 1873213, tol=0)
chk("params swiglu (絶対)", p["swiglu"], 1875261, tol=0)

# --- 3. 到達点の表（§2-1）---
TAB = {"silu_raw": (0.0096, 0.836), "silu": (0.0127, 0.794), "relu_w067": (0.0115, 0.790),
       "relu": (0.0219, 0.643), "relu_w15": (0.0284, 0.562), "swiglu_raw": (0.0229, 0.557),
       "swiglu": (0.0267, 0.490), "drelu": (0.0775, 0.223), "relu2_raw": (0.0651, 0.121),
       "relu2": (0.3139, 0.039), "relu2_w15": (0.4623, 0.020)}
for a, (ce, iv) in TAB.items():
    rs = [r for r in rows if r["arm"] == a]
    chk(f"CE {a}", float(np.mean([r["evals"][-1]["ce_all"] for r in rs])), ce, tol=5e-3)
    chk(f"iv {a}", float(np.mean([r["evals"][-1]["instr_valid"] for r in rs])), iv, tol=5e-3)

# --- 4. 対比（§2-2）---
with open(os.path.join(D, "a1_analysis.json"), encoding="utf-8") as fh:
    J = json.load(fh)
got = {(c["a"], c["b"], c["metric"]): c for c in J["contrasts"]}
WANT = {
    ("silu_raw", "relu", "instr_valid"): (+0.193, 0.072),
    ("relu2_raw", "relu", "instr_valid"): (-0.522, 0.0005),
    ("drelu", "swiglu", "instr_valid"): (-0.266, 0.033),
    ("swiglu", "relu", "instr_valid"): (-0.154, 0.158),
    ("relu_w15", "relu", "instr_valid"): (-0.081, 0.576),
    ("relu_w067", "relu", "instr_valid"): (+0.147, 0.032),
    ("relu_w067", "relu_w15", "instr_valid"): (+0.227, 0.067),
    ("relu2_w15", "swiglu", "instr_valid"): (-0.470, 0.0013),
    ("silu_raw", "relu_w067", "instr_valid"): (+0.047, 0.448),
    ("relu2_raw", "relu", "ce"): (+0.0432, 0.011),
    ("relu_w067", "relu", "ce"): (-0.0104, 0.032),
}
for k, (m, pv) in WANT.items():
    c = got.get(k)
    if c is None:
        bad.append(f"  NG  対比が無い: {k}")
        continue
    chk(f"{k[0]}-{k[1]} [{k[2]}] mean", c["mean"], m, tol=5e-3)
    if pv >= 0.001:
        chk(f"{k[0]}-{k[1]} [{k[2]}] p", c["p"], pv, tol=5e-2)

# --- 5. 裾の確認（§2-1 の「1 seed が 1.137」）---
for a, want_max, want_ratio in (("relu2", 1.1372, 9.5), ("relu_w067", 0.0140, 1.2)):
    v = np.array([r["evals"][-1]["ce_all"] for r in rows if r["arm"] == a])
    chk(f"CE max {a}", float(v.max()), want_max, tol=2e-3)
    chk(f"max/median {a}", float(v.max() / np.median(v)), want_ratio, tol=5e-2)

# --- 6. 6 epoch 版の飽和（§1 / §3-1）---
p6 = os.path.join(HERE, "data", "a1_e6_partial", "relu_s0.json")
if os.path.exists(p6):
    with open(p6, encoding="utf-8") as fh:
        r6 = json.load(fh)
    chk("6ep relu CE", r6["eval"]["ce_all"], 0.00109, tol=5e-3)
    chk("6ep relu instr", r6["eval"]["instr_valid"], 0.984, tol=5e-3)

print("\n".join(ok))
if bad:
    print("\n".join(bad))
    print(f"\nFAIL: {len(bad)} 件")
    sys.exit(1)
print(f"\nPASS: {len(ok)} 件すべて報告書と一致")
