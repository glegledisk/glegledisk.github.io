#!/usr/bin/env python3
"""_p13d_verify.py — P13d の Step 4 検算（AGENTS.md §3 / §7）。

p13d_results.json から Δ・t・件数・尾を独立に再計算し、p13d_analysis.json と
突き合わせる。baseline は p13c_analysis.json（= P13 §4 の一次ソース）と
ビット一致するかを確認する。
出力: _p13d_verify_metrics.json / _p13d_verify_out_utf8.txt
"""
import json
import math
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
res = json.load(open(os.path.join(HERE, "p13d_results.json"), encoding="utf-8"))
ana = json.load(open(os.path.join(HERE, "p13d_analysis.json"), encoding="utf-8"))
ref = json.load(open(os.path.join(HERE, "p13c_analysis.json"), encoding="utf-8"))

checks = []


def ck(name, ok, got=None, want=None, tol=None):
    checks.append({"name": name, "ok": bool(ok), "got": got, "want": want, "tol": tol})


rows = res["rows"]
ck("row_count_57", len(rows) == 57, len(rows), 57)
ck("n_eval_2048_all", all(r["n_eval"] == 2048 for r in rows),
   sorted({r["n_eval"] for r in rows}), [2048])
ck("ce_seq_len_2048_all", all(len(r["ce_seq"]) == 2048 for r in rows),
   sorted({len(r["ce_seq"]) for r in rows}), [2048])
ck("threads_6", res["args"]["threads"] == 6, res["args"]["threads"], 6)
ck("seeds_012", res["args"]["seeds"] == [0, 1, 2], res["args"]["seeds"], [0, 1, 2])

# ce_all は ce_seq の平均と一致するか（float32 経由の丸めを許容）
max_ce_gap = max(abs(r["ce_all"] - float(np.mean(r["ce_seq"]))) for r in rows)
ck("ce_all_equals_ce_seq_mean", max_ce_gap < 1e-6, max_ce_gap, 0.0, 1e-6)

# 校正: fixed の 3 seed 平均が p13c_analysis.json とビット一致
calib_map = [
    ("H+LB:top1", "H+LB", "top1"), ("H+LB:base", "H+LB", "base"),
    ("U+LB:top1", "U+LB", "top1"), ("U+LB:base", "U+LB", "base"),
    ("dense:97", "dense97", "dense"), ("dense:180", "dense180", "dense"),
    ("dense:256", "dense256", "dense"),
]
for ref_key, arm, cond in calib_map:
    sel = sorted([r for r in rows if r["arm"] == arm and r["cond"] == cond
                  and r["mode"] == "fixed"], key=lambda x: x["seed"])
    got = float(np.mean([r["ce_all"] for r in sel]))
    want = float(ref["points"][ref_key]["ce"])
    ck("calib_" + ref_key, abs(got - want) < 1e-12, got, want, 1e-12)
    # per_seed も突き合わせ
    ps = [float(x) for x in ref["points"][ref_key]["per_seed"]]
    ck("calib_perseed_" + ref_key,
       max(abs(a - b) for a, b in zip([r["ce_all"] for r in sel], ps)) < 1e-12)

# fixed と native は同一（内部整合）
for arm in ("H+LB", "U+LB", "dense97", "dense180", "dense256"):
    cond = "dense" if arm.startswith("dense") else "base"
    f = sorted([r for r in rows if r["arm"] == arm and r["cond"] == cond
                and r["mode"] == "fixed"], key=lambda x: x["seed"])
    n = sorted([r for r in rows if r["arm"] == arm and r["cond"] == cond
                and r["mode"] == "native"], key=lambda x: x["seed"])
    ck("native_equals_fixed_" + arm,
       len(f) == len(n) and max(abs(a["ce_all"] - b["ce_all"])
                                for a, b in zip(f, n)) < 1e-12)

# dense は buggy == fixed（E=1 / k=1 なので slot == i == 0）
for w in (97, 180, 256):
    arm = "dense%d" % w
    f = sorted([r for r in rows if r["arm"] == arm and r["mode"] == "fixed"],
               key=lambda x: x["seed"])
    b = sorted([r for r in rows if r["arm"] == arm and r["mode"] == "buggy"],
               key=lambda x: x["seed"])
    ck("dense_buggy_zero_" + arm,
       max(abs(x["ce_all"] - y["ce_all"]) for x, y in zip(f, b)) < 1e-12)

# バイアス buggy - fixed を results から再計算
for key, v in ana["bias_buggy_minus_fixed"].items():
    arm, cond = key.split("|")
    f = {r["seed"]: r["ce_all"] for r in rows
         if r["arm"] == arm and r["cond"] == cond and r["mode"] == "fixed"}
    b = {r["seed"]: r["ce_all"] for r in rows
         if r["arm"] == arm and r["cond"] == cond and r["mode"] == "buggy"}
    seeds = sorted(set(f) & set(b))
    d = np.array([b[s] - f[s] for s in seeds])
    ck("bias_mean_" + key, abs(d.mean() - v["d_ce"]) < 1e-12, float(d.mean()), v["d_ce"])
    se = float(d.std(ddof=1) / np.sqrt(len(d))) if len(d) > 1 else 0.0
    ck("bias_se_" + key, abs(se - v["se"]) < 1e-12, se, v["se"])
    ck("bias_perseed_" + key,
       max(abs(a - c) for a, c in zip(d.tolist(), v["per_seed"])) < 1e-12)

# P13 §4 の差を summary から再計算
g = ana["p13_s4_gap"]
for mode in ("fixed", "buggy"):
    hs = [r["ce_all"] for r in rows if r["arm"] == "H+LB"
          and r["cond"] == "base" and r["mode"] == mode]
    ds = [r["ce_all"] for r in rows if r["arm"] == "dense180"
          and r["mode"] == mode]
    ck("gap_h_" + mode, abs(float(np.mean(hs)) - g[mode]["H_ce"]) < 1e-12)
    ck("gap_d_" + mode, abs(float(np.mean(ds)) - g[mode]["dense_ce"]) < 1e-12)
    ck("gap_" + mode,
       abs((np.mean(hs) - np.mean(ds)) - g[mode]["gap"]) < 1e-12,
       float(np.mean(hs) - np.mean(ds)), g[mode]["gap"])

# 条件 D を独立再計算
D = ana["condition_D"]
h = sorted([r for r in rows if r["arm"] == "H+LB" and r["cond"] == "base"
            and r["mode"] == "fixed"], key=lambda x: x["seed"])
u = sorted([r for r in rows if r["arm"] == "U+LB" and r["cond"] == "base"
            and r["mode"] == "fixed"], key=lambda x: x["seed"])
ck("D_params_equal", D["params_H"] == D["params_U"] == 1342653,
   [D["params_H"], D["params_U"]], [1342653, 1342653])
ck("D_params_from_ckpt",
   all(r["nparam"] == 1342653 for r in h + u),
   sorted({r["nparam"] for r in h + u}))

hv = np.array([r["ce_all"] for r in h])
uv = np.array([r["ce_all"] for r in u])
dv = hv - uv
tt = stats.ttest_rel(hv, uv)
se = float(dv.std(ddof=1) / np.sqrt(len(dv)))
mde = float(stats.t.ppf(0.975, len(dv) - 1) * se)
S = D["seed_level"]
for name, got, want in [
    ("D_delta", float(dv.mean()), S["delta"]),
    ("D_se", se, S["se"]),
    ("D_t", float(tt.statistic), S["t"]),
    ("D_p", float(tt.pvalue), S["p"]),
    ("D_mde", mde, S["mde"]),
    ("D_n", len(dv), S["n"]),
    ("D_n_neg", int((dv < 0).sum()), S["n_neg"]),
]:
    ck(name, abs(got - want) < 1e-10 if isinstance(want, float) else got == want,
       got, want)

# 系列対応 t と上位 1% 寄与率、P13 §4-2 の既存値との一致
ref_t = [-5.6, 41.9, -7.3]
ref_d = [-0.0090, 0.0542, -0.0095]
for i, (a, b) in enumerate(zip(h, u)):
    da = np.array(a["ce_seq"]) - np.array(b["ce_seq"])
    t2 = stats.ttest_rel(np.array(a["ce_seq"]), np.array(b["ce_seq"]))
    absd = np.abs(da)
    ntop = max(1, int(math.ceil(len(absd) * 0.01)))
    share = float(np.sort(absd)[-ntop:].sum() / absd.sum())
    r = D["seq_level"][i]
    ck("D_seq_delta_s%d" % a["seed"], abs(float(da.mean()) - r["delta"]) < 1e-10)
    ck("D_seq_t_s%d" % a["seed"], abs(float(t2.statistic) - r["t"]) < 1e-9)
    ck("D_seq_share_s%d" % a["seed"], abs(share - r["top1_share"]) < 1e-10)
    ck("D_seq_matches_P13_s%d" % a["seed"],
       abs(float(da.mean()) - ref_d[i]) < 5e-4 and abs(float(t2.statistic) - ref_t[i]) < 0.15,
       [float(da.mean()), float(t2.statistic)], [ref_d[i], ref_t[i]])
    ck("D_seq_tail_ok_s%d" % a["seed"], share < 0.50, share, 0.50)

out = {
    "n_checks": len(checks),
    "n_ok": sum(1 for c in checks if c["ok"]),
    "n_fail": sum(1 for c in checks if not c["ok"]),
    "ok": all(c["ok"] for c in checks),
    "checks": checks,
    "max_ce_all_vs_seq_gap": max_ce_gap,
}
with open(os.path.join(HERE, "_p13d_verify_metrics.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2, default=float)
lines = ["P13d Step 4 検算: %d 項目 / 不一致 %d / ok=%s"
         % (out["n_checks"], out["n_fail"], out["ok"])]
for c in checks:
    if not c["ok"]:
        lines.append("  FAIL %-34s got=%s want=%s" % (c["name"], c["got"], c["want"]))
with open(os.path.join(HERE, "_p13d_verify_out_utf8.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")
print("\n".join(lines))
