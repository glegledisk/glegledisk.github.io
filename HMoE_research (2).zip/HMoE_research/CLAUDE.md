# CLAUDE.md

このリポジトリの作業規約は **`AGENTS.md` が正本**。以下の import で全文を読み込む。

@AGENTS.md

---

## Claude Code 固有の注意（AGENTS.md の補足のみ）

### ツール選択

- **`Bash` ツールは使えない。** `fork: Resource temporarily unavailable` で必ず失敗する。シェル作業はすべて **`PowerShell` ツール**で行う。
- ファイル読み書きは `Read` / `Write` / `Edit`、検索は `Glob` / `Grep` を使う（`Get-ChildItem -Recurse` や `Select-String` に頼らない）。
- 590 秒を超える計算は `PowerShell` ツールを `run_in_background: true` にして、その中で `Start-Process -Wait` を呼ぶ。

### サブエージェント

- 探索は `Explore`、設計は `Plan` に投げてよい。ただし**報告書の執筆と数値の検算は自分でやる**（委譲すると数値が伝聞になる）。
- 委譲した場合、返ってきた数値は必ず出力ファイルと突き合わせてから報告書に書く。

### 完了条件

このリポジトリでは「コードが動いた」は完了ではない。

> **`検証報告_*.md`（または該当種別の `.md`）が存在し、`## 0. 結論` に数値と検定が入っていること**が完了条件。

`TodoWrite` を使う場合、最後の項目は必ず「報告書を書く」「メモリに追記する」にする。

### コンテキスト管理

- 長いセッションでは `MEMORY.md` と直近の日次ログだけを保持し、古い報告書は必要になったときだけ読む。
- セッションを畳む前に `セッション総括_YYYYMMDD_*.md` を書く（AGENTS.md §3 Step 7）。
