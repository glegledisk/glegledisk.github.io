import ast, glob, os
root = r"C:\Users\gochu\.workbuddy-ai\binaries\python\envs\gpu\Lib\site-packages\transformers"
files = sorted(glob.glob(os.path.join(root, "**", "*.py"), recursive=True))
print("py files:", len(files))
parts, used = [], 0
for f in files:
    try:
        src = open(f, encoding="utf-8").read()
        tree = ast.parse(src)
    except Exception:
        continue
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            d = ast.get_docstring(node)
            if d and len(d) > 80:
                parts.append(d); used += 1
    if sum(len(x) for x in parts) > 900000:
        break
txt = "\n\n".join(parts)
print("docstrings:", used, " chars:", len(txt))
print("先頭 400 文字:"); print(txt[:400])