# -*- coding: utf-8 -*-
"""e6_memory_task.py — E6: 記憶を要求する依存課題（Lag-3 Dependent Lookup）

## なぜ必要か
d=64 の再測定（`検証報告_d64_60epoch_FFNが効く領域は容量の関数_20261024.md`）で、
E5 の `(a+b) mod A` は Attention の softmax + 線形ヘッドで実装できてしまうことが分かった。
幅を上げると FFN の寄与は 0.028 nats に消える。つまり「FFN が効く領域」は
低容量（d=16）に閉じており、テストベッドとしての意味が薄い。

## E6 の設計: ランダム巨大ルックアップ表
ANCHOR 位置の出力を `(a+b) mod A` から**ランダムな関数** π: {0..A-1}² → {0..A-1} に変える。

  ANCHOR (src[i] ∈ anchor_vals): out[i] = π(src[i], src[i-1])   ← 記憶そのもの
  DEP    (src[i-lag] ∈ anchor_vals): out[i] = out[i-lag]        ← 依存コピー（lag=3）
  COPY   : out[i] = src[i]

### なぜ FFN が必要になるか
出力ヘッドは線形なので、x が e_a ⊕ e_b の線形結合であれば argmax_c W[c,a]+W[c,b] しか出せず、
これは擬群（quasigroup）構造を要する。**ランダムな π はこれを持たない**ため、線形では不可能。
Attention の softmax は「選択」はできるが、値ベクトルの線形結合で 4096 個のランダムな
対応を実装するのに必要な容量はヘッド（d×V 個）には収まらない。
一方 FFN は ReLU で非線形写像を直接書けるので、表を記憶する容量を持ちうる。

A=64 なら表は 4096 エントリ。FFN のパラメータ（8 Expert × 2 × d × w_ff）が d=64, w_ff=64 で
65536 個。記憶に必要な ~4096×6 bit = 24576 bit に対して 2.7 倍の余裕があり、
「理論上は可能だが線形では不可能」という領域に入る。

### 期待される性質
- frozen_identity は COPY/DEP（87.5%）は解けるが ANCHOR（12.5%）は不可能
  → CE_identity ≈ 0.125 × log(64) ≈ 0.52
- frozen_ffn は表を記憶できれば CE ≈ 0
  → **ΔCE ≈ 0.5**（E5 の 0.26 の 2 倍、E5 d=64 の 0.028 の 18 倍）
"""
import os, json, time
import numpy as np
import pandas as pd
import torch
from e5_dependency_task import run as e5_run, COPY, ANCHOR, DEP, ROLE_NAME


def make_lookup_table(A, seed=12345):
    """固定シードでランダムな関数 π: (a,b) -> c を作る。全 run・train/test で共通。"""
    rng = np.random.default_rng(seed)
    return rng.integers(0, A, size=(A, A))


def make_lookup_batch(rng, n, L=16, A=64, lag=3, anchor_vals=tuple(range(8)), mode="no_plan",
                      table=None):
    """E6 の系列生成。E5 と同じ構造で ANCHOR の変換だけをルックアップに差し替える。"""
    if table is None:
        table = make_lookup_table(A)
    av = np.asarray(anchor_vals)
    src = rng.integers(0, A, size=(n, L))
    out = src.copy()
    role = np.zeros((n, L), dtype=np.int8)
    is_anchor_src = np.isin(src, av)
    for i in range(L):
        prev = src[:, i - 1] if i >= 1 else src[:, i]
        hard = table[src[:, i], prev]                      # π(src[i], src[i-1])
        if i >= lag:
            dep = is_anchor_src[:, i - lag]
            out[:, i] = np.where(dep, out[:, i - lag],
                                 np.where(is_anchor_src[:, i], hard, src[:, i]))
            role[:, i] = np.where(dep, DEP, np.where(is_anchor_src[:, i], ANCHOR, COPY))
        else:
            out[:, i] = np.where(is_anchor_src[:, i], hard, src[:, i])
            role[:, i] = np.where(is_anchor_src[:, i], ANCHOR, COPY)

    SEP = A
    if mode == "oracle_plan":
        PLAN_COPY, PLAN_EDIT = A + 1, A + 2
        plan = np.where(role == ANCHOR, PLAN_EDIT, PLAN_COPY).astype(np.int64)
        seq = np.empty((n, 2 * L + L + 2), dtype=np.int64)
        seq[:, 0:L] = src
        seq[:, L] = SEP
        seq[:, L + 1:2 * L + 1] = plan
        seq[:, 2 * L + 1] = SEP
        seq[:, 2 * L + 2:] = out
        pos_out = 2 * L + 2
    else:
        seq = np.empty((n, 2 * L + 1), dtype=np.int64)
        seq[:, 0:L] = src
        seq[:, L] = SEP
        seq[:, L + 1:] = out
        pos_out = L + 1
    return torch.from_numpy(seq), role, pos_out


def run(arm, seed, L=16, A=64, lag=3, anchor_vals=tuple(range(8)), n_train=3500, n_val=2048,
        epochs=60, bs=64, lam_cost=0.15, d=64, table=None):
    if table is None:
        table = make_lookup_table(A)
    fn = lambda rng, n, L_, A_, lag_, av_, mode_: make_lookup_batch(
        rng, n, L_, A_, lag_, av_, mode_, table=table)
    return e5_run(arm, seed, L=L, A=A, lag=lag, anchor_vals=anchor_vals, n_train=n_train,
                  n_val=n_val, epochs=epochs, bs=bs, lam_cost=lam_cost, d=d,
                  make_batch_fn=fn)


if __name__ == "__main__":
    CFG = dict(L=16, A=64, lag=3, anchor_vals=tuple(range(8)), d=64)
    tab = make_lookup_table(64)
    print("表サイズ:", tab.shape, "エントリ数:", tab.size)
    rng = np.random.default_rng(0)
    seq, role, po = make_lookup_batch(rng, 20000, table=tab)
    rl = np.asarray(role)
    print("役割分布: " + "  ".join(f"{nm}={100*(rl==r).mean():.1f}%" for r, nm in ROLE_NAME.items()))
    src = seq[:, :16].numpy(); out = seq[:, 17:].numpy()
    prev = np.concatenate([src[:, :1], src[:, :-1]], axis=1)
    hard = tab[src, prev]
    lagged = np.concatenate([np.full((20000, 3), -1), out[:, :-3]], axis=1)
    exp = np.where(rl == DEP, lagged, np.where(rl == ANCHOR, hard, src))
    print("生成規則の整合:", bool((exp == out).all()))
    print("例 (ANCHOR 位置):")
    idx = np.where(rl == ANCHOR)
    for k in range(5):
        i, j = idx[0][k], idx[1][k]
        print(f"  src[{j}]={src[i,j]:2d}  src[{j-1}]={prev[i,j]:2d}  ->  out={out[i,j]:2d} "
              f"(表 {tab[src[i,j], prev[i,j]]})")
    print("\n予想 CE（記憶に完全に失敗した場合）: log(64) =", round(np.log(64), 3))
    print("→ frozen_identity の CE は ~0.125 × 4.16 ≈ 0.52 になるはず")
