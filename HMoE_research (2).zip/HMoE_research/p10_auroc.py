# -*- coding: utf-8 -*-
"""P10: 高速経路の自信の歪み（考察 20261029 §7 予測 2）

問い:
  top-k を削ると「自信は上がるが正解率は下がる」（P6c）。だとすると
  **確信度で正誤を分ける力（AUROC）が落ちる**はず。落ちるなら、高速経路は
  「間違えたときに分からない」経路であり、閾値運用に使えない。

測り方:
  OLMoE の next-token 予測を「課題」にする。各トークンで
    正誤 = (argmax == 正解トークン)
    確信度 = p_top1（argmax の確率）
  AUROC(確信度 → 正誤) を条件間で比べる。窓（48）でクラスタした対応差も出す。

条件:
  base    k=8 全層
  f1      前半 8 層だけ top-7（実 FLOPs あたり最良。P7c）
  u1      全層 top-7
  f1_rs   f1 + 質量を k=8 に戻す（P6c の rescale。予測の「対策」側）

出力: p10_auroc.npz / p10_auroc.json
"""

import argparse
import json
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
FROZEN = os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz")

FRONT = set(range(0, 8))
CONDS = [
    ("base", "all", 8, False),
    ("f1", "front", 7, False),
    ("u1", "all", 7, False),
    ("f1_rs", "front", 7, True),
]


def log(m):
    print(m, flush=True)


def load_frozen(n_win, ln):
    z = np.load(FROZEN, allow_pickle=True)
    seqs = []
    for lang in ("en", "ja"):
        ids = torch.from_numpy(z["%s_ids" % lang].astype(np.int64))
        for w in range(n_win):
            seqs.append((lang, ids[w * ln:(w + 1) * ln]))
    return seqs


def make_rescaled(orig, full_k):
    def _patched(hidden_states):
        logits, scores, idx = orig(hidden_states)
        if scores.shape[-1] < full_k:
            probs = torch.softmax(logits.float(), dim=-1)
            m_full = torch.topk(probs, full_k, dim=-1).values.sum(-1, keepdim=True)
            m_now = scores.float().sum(-1, keepdim=True).clamp_min(1e-9)
            scores = (scores.float() * (m_full / m_now)).to(scores.dtype)
        return logits, scores, idx
    return _patched


def auroc(score, label):
    """Mann-Whitney の順位公式。"""
    score = np.asarray(score, np.float64)
    label = np.asarray(label, bool)
    npos = int(label.sum())
    nneg = label.size - npos
    if npos == 0 or nneg == 0:
        return float("nan")
    order = np.argsort(score, kind="mergesort")
    ranks = np.empty(score.size, np.float64)
    ranks[order] = np.arange(1, score.size + 1)
    # 同順位は平均順位
    s = score[order]
    i = 0
    while i < s.size:
        j = i
        while j + 1 < s.size and s[j + 1] == s[i]:
            j += 1
        if j > i:
            ranks[order[i:j + 1]] = (i + j + 2) / 2.0
        i = j + 1
    return float((ranks[label].sum() - npos * (npos + 1) / 2) / (npos * nneg))


def ece(conf, correct, nb=15):
    conf = np.asarray(conf, np.float64)
    correct = np.asarray(correct, np.float64)
    edges = np.linspace(0, 1, nb + 1)
    e = 0.0
    for i in range(nb):
        m = (conf > edges[i]) & (conf <= edges[i + 1])
        if m.sum() == 0:
            continue
        e += m.mean() * abs(correct[m].mean() - conf[m].mean())
    return float(e)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--tag", type=str, default="p10")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer

    n_win = 1 if args.smoke else args.windows
    log("[1/4] load")
    t0 = time.time()
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      %.0f s" % (time.time() - t0))

    n_layers = model.config.num_hidden_layers
    FULL_K = int(model.config.num_experts_per_tok)
    gates = [l.mlp.gate for l in model.model.layers]
    ORIG = [g.forward for g in gates]

    seqs = load_frozen(n_win, args.len)
    lang = np.array([lg for lg, _ in seqs])
    log("      %d windows, %d tokens" % (len(seqs), len(seqs) * args.len))

    res = {}
    for name, cut, k, rs in CONDS:
        for i, g in enumerate(gates):
            g.forward = ORIG[i]
            g.top_k = k if (cut == "all" or i in FRONT) else FULL_K
        if rs:
            for g in gates:
                g.forward = make_rescaled(g.forward, FULL_K)
        nll_c, p_c, cor_c, gp_c = [], [], [], []
        t1 = time.time()
        with torch.no_grad():
            for lg, ids in seqs:
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                lgts = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(lgts, tgt, reduction="none")
                probs = torch.softmax(lgts, dim=-1)
                ptop, amax = probs.max(dim=-1)
                gold_p = probs.gather(1, tgt.unsqueeze(-1)).squeeze(1)
                nll_c.append(nll.cpu().numpy())
                p_c.append(ptop.cpu().numpy())
                cor_c.append((amax == tgt).cpu().numpy())
                gp_c.append(gold_p.cpu().numpy())
                del out, lgts, probs
        res[name] = {"nll": np.concatenate(nll_c), "ptop": np.concatenate(p_c),
                     "correct": np.concatenate(cor_c), "gold_p": np.concatenate(gp_c)}
        log("      %-6s CE %.5f  top1 %.4f  p_top1 %.4f  (%.0f s)"
            % (name, res[name]["nll"].mean(), res[name]["correct"].mean(),
               res[name]["ptop"].mean(), time.time() - t1))
    for i, g in enumerate(gates):
        g.forward = ORIG[i]
        g.top_k = FULL_K

    # ---- 集計 ----
    log("")
    log("%-7s %9s %8s %8s %8s %8s %8s" %
        ("cond", "CE", "top1", "p_top1", "AUROC", "ECE", "err@.8"))
    summary = {}
    n = res["base"]["nll"].size
    per = n // len(seqs)
    for name, _, _, _ in CONDS:
        r = res[name]
        au = auroc(r["ptop"], r["correct"])
        ec = ece(r["ptop"], r["correct"])
        hi = r["ptop"] >= 0.8
        err_hi = float((~r["correct"][hi]).mean()) if hi.sum() else float("nan")
        log("%-7s %9.5f %8.4f %8.4f %8.4f %8.4f %8.4f"
            % (name, r["nll"].mean(), r["correct"].mean(), r["ptop"].mean(), au, ec, err_hi))
        summary[name] = {"ce": float(r["nll"].mean()), "top1": float(r["correct"].mean()),
                         "ptop": float(r["ptop"].mean()), "auroc": au, "ece": ec,
                         "err_at_0.8": err_hi, "frac_hi": float(hi.mean())}

    # ---- 窓クラスタの対応差 ----
    log("")
    log("[窓クラスタ] AUROC の対応差（48 窓）")
    for name, _, _, _ in CONDS[1:]:
        a = res[name]
        b = res["base"]
        d = []
        for w in range(len(seqs)):
            sl = slice(w * per, (w + 1) * per)
            d.append(auroc(a["ptop"][sl], a["correct"][sl]) -
                     auroc(b["ptop"][sl], b["correct"][sl]))
        d = np.array(d, np.float64)
        se = d.std(ddof=1) / np.sqrt(d.size)
        log("    %-6s − base: ΔAUROC %+.4f (se %.4f, t %+.2f, n=%d)  MDE80 %.4f"
            % (name, d.mean(), se, d.mean() / se, d.size, 2.8 * se))
        summary[name]["d_auroc"] = {"mean": float(d.mean()), "se": float(se),
                                    "t": float(d.mean() / se), "mde80": float(2.8 * se)}

    np.savez_compressed(os.path.join(HERE, "%s_auroc.npz" % args.tag),
                        **{"%s_%s" % (k, f): res[k][f] for k in res for f in res[k]},
                        lang=lang)
    with open(os.path.join(HERE, "%s_auroc.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2, default=float)
    log("")
    log("saved: %s_auroc.npz / %s_auroc.json" % (args.tag, args.tag))


if __name__ == "__main__":
    main()
