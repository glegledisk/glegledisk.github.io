#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX5 本番前の end-to-end 配管テスト（モデルをロードしない偽モデル）。

forward 後の stats / exploratory / save までを実際に通し、KeyError などの
配管バグを 45 分の本番前に検出する。出力は faketest_* に隔離する。
"""
import os
import sys
import types

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import ax5_granularity_mech as m  # noqa: E402

VOCAB = 50400


class FakeTokenizer:
    @staticmethod
    def from_pretrained(*a, **k):
        return FakeTokenizer()


class FakeGate:
    def __init__(self):
        self.norm_topk_prob = False
        self.top_k = 8
        self.forward = self._f

    def _f(self, hs):
        n = hs.shape[0]
        scores = torch.full((n, 8), 1.0 / 8.0)
        logits = torch.zeros(n, 64)
        idx = torch.arange(8).unsqueeze(0).repeat(n, 1)
        return logits, scores, idx


class FakeModel:
    def __init__(self):
        self.config = types.SimpleNamespace(num_experts_per_tok=8,
                                            num_hidden_layers=16)
        self.model = types.SimpleNamespace(layers=[
            types.SimpleNamespace(mlp=types.SimpleNamespace(gate=FakeGate()))
            for _ in range(16)])
        self.device = torch.device("cpu")

    def eval(self):
        return self

    def __call__(self, input_ids, use_cache=False):
        b, s = input_ids.shape
        return types.SimpleNamespace(logits=torch.zeros(b, s, VOCAB))


class FakeAutoModel:
    @staticmethod
    def from_pretrained(*a, **k):
        return FakeModel()


fake = types.ModuleType("transformers")
fake.AutoTokenizer = FakeTokenizer
fake.AutoModelForCausalLM = FakeAutoModel
sys.modules["transformers"] = fake

sys.argv = ["ax5_granularity_mech.py", "--tag", "faketest"]
m.main()
