"""
P4d: 決定規則の価値（正しい正規化）と、「難易度を予測して割り当てる」方案の評価

定義:
  f の割合のトークンだけ k=8 に保護し、残りを k=6 にすると
      ΔCE = (1/n) * Σ_{未保護} d_j = (1-f) * mean(d_j | 未保護)
  予算は mean_k = 6 + 2f（f=0.5 が均一 top-7 と同じ予算）

信号の種類:
  oracle_cost : 真の d_j（達成不可能な上限）
  true_diff   : 真の nll_j（難易度。これも達成不可能だが「難易度で配分する」の上限）
  probe_cost  : d_j を予測して割り当てる（本命の実装可能案）
  probe_diff  : nll_j を予測して割り当てる（難易度ベースの実装可能案）
  random      : ランダム

出力: p4_decision_results.json / p4_preds2.npz
"""

import json
import os

import numpy as np

from p4b_probe import auc_score, build_features, cv_predict, spearman

HERE = os.path.dirname(os.path.abspath(__file__))


def decision_value(score, d_j, f):
    """score の上位 f を k=8 で保護したときの ΔCE（正しい正規化）。"""
    n = d_j.size
    m = int(round(f * n))
    keep = np.zeros(n, bool)
    keep[np.argsort(-score)[:m]] = True
    return float(d_j[~keep].sum() / n)


def main():
    d = np.load(os.path.join(HERE, "p4_feats.npz"), allow_pickle=True)
    p3 = np.load(os.path.join(HERE, "p3_topk_nll.npz"))
    nll_j = p3["k8"]
    d_j = p3["k6"] - p3["k8"]
    feats, win = build_features(d)
    n = d_j.size

    SETS = {
        "hist": ["hist"],
        "gate0": ["gate0"],
        "gstat0": ["gstat0"],
        "gate0+hist": ["gate0", "hist"],
        "h0+hist": ["h0", "hist"],
        "gate8+hist": ["gate8", "hist"],
        "gate15+hist": ["gate15", "hist"],
        "ALL(l0)": ["gate0", "gstat0", "h0", "hist"],
    }

    print("=== 決定規則の達成 ΔCE（k=8 で保護する割合 f、予算 mean_k=6+2f）===")
    print("  均一 top-7（mean_k=7, f=0.5 と同予算）= +0.01449 / 均一 top-6（f=0）= +0.04981")
    print()
    F = (0.25, 0.5, 0.75)
    rows = {}
    preds = {}

    # oracle 系
    rows["oracle_cost"] = {f: decision_value(d_j, d_j, f) for f in F}
    rows["true_diff"] = {f: decision_value(nll_j, d_j, f) for f in F}
    rng = np.random.RandomState(0)
    rows["random"] = {f: decision_value(rng.rand(n), d_j, f) for f in F}

    # probe 系（CV 予測）
    for sname, keys in SETS.items():
        X = np.concatenate([feats[k] for k in keys], axis=1).astype(np.float64)
        pc = cv_predict(X, d_j, win)
        pd = cv_predict(X, nll_j, win)
        preds["cost_" + sname] = pc
        preds["diff_" + sname] = pd
        rows["probe_cost|" + sname] = {f: decision_value(pc, d_j, f) for f in F}
        rows["probe_diff|" + sname] = {f: decision_value(pd, d_j, f) for f in F}

    hdr = "%-24s %9s %9s %9s" % ("signal", "f=0.25", "f=0.50", "f=0.75")
    print(hdr)
    order = ["oracle_cost", "true_diff"]
    order += ["probe_diff|" + s for s in SETS]
    order += ["probe_cost|" + s for s in SETS]
    order += ["random"]
    for k in order:
        r = rows[k]
        print("%-24s %9.5f %9.5f %9.5f" % (k, r[0.25], r[0.5], r[0.75]))

    # probe の AUC（参考）
    print()
    print("=== 参考: probe の AUC（d_j 上位 25% / nll_j 上位 25%）===")
    print("%-14s %10s %10s" % ("features", "AUC(cost)", "AUC(diff)"))
    ybin_c = (d_j > np.quantile(d_j, 0.75)).astype(int)
    ybin_d = (nll_j > np.quantile(nll_j, 0.75)).astype(int)
    for sname in SETS:
        print("%-14s %10.4f %10.4f" % (sname, auc_score(ybin_c, preds["cost_" + sname]),
                                       auc_score(ybin_d, preds["diff_" + sname])))

    out = {"n": int(n), "f_grid": list(F),
           "uniform_top7": 0.01449, "uniform_top6": 0.04981,
           "decision_values": {k: {str(f): v for f, v in r.items()} for k, r in rows.items()}}
    with open(os.path.join(HERE, "p4_decision_results.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    np.savez_compressed(os.path.join(HERE, "p4_preds2.npz"), d_j=d_j, nll_j=nll_j,
                        win=win, pos=d["pos"], **preds)
    print("\nsaved p4_decision_results.json / p4_preds2.npz")


if __name__ == "__main__":
    main()
