# -*- coding: utf-8 -*-
"""_debug_width_gpu.py — device_map=auto で NaN が出る層を特定する（使い捨て）"""
import os
import types

import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "olmoe-1b-7b")

from transformers import AutoModelForCausalLM, AutoTokenizer

tok = AutoTokenizer.from_pretrained(MODEL)
m = AutoModelForCausalLM.from_pretrained(
    MODEL, torch_dtype=torch.bfloat16, device_map="auto",
    max_memory={0: "7.0GiB", "cpu": "8.5GiB"}).eval()

print("device_map:")
for k, v in m.hf_device_map.items():
    print("  %-28s %s" % (k, v))

z = __import__("numpy").load(os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"))
ids = torch.from_numpy(z["en_ids"][:256].astype("int64")).unsqueeze(0)

flags = {}
def hook(name):
    def f(mod, inp, out):
        o = out[0] if isinstance(out, tuple) else out
        flags[name] = bool(torch.isfinite(o).all().item())
    return f

hs = []
for i, l in enumerate(m.model.layers):
    hs.append(l.mlp.register_forward_hook(hook(i)))

with torch.no_grad():
    out = m(input_ids=ids, use_cache=False)
print("base logits finite:", torch.isfinite(out.logits).all().item())
print("base per-layer mlp finite:", all(flags.values()), [k for k, v in flags.items() if not v])

# --- 差し替え ---
def make_forward(mode, half_idx):
    def fwd(self, hidden_states, top_k_index, top_k_weights):
        final = torch.zeros_like(hidden_states)
        K = top_k_index.shape[-1]
        d_ff = self.down_proj.shape[-1]
        with torch.no_grad():
            mask = F.one_hot(top_k_index, num_classes=self.num_experts + 1).permute(2, 1, 0)
            hit = torch.greater(mask.sum(dim=(-1, -2)), 0).nonzero()
        for ei in hit:
            e = int(ei[0])
            if e == self.num_experts:
                continue
            pos, tokidx = torch.where(mask[e])
            is_r8 = (pos == K - 1)
            gu = self.gate_up_proj[e]
            dn = self.down_proj[e]
            keep = ~is_r8
            if keep.any():
                x = hidden_states[tokidx[keep]]
                g, u = F.linear(x, gu).chunk(2, dim=-1)
                hh = F.linear(self.act_fn(g) * u, dn)
                hh = hh * top_k_weights[tokidx[keep], pos[keep], None]
                final.index_add_(0, tokidx[keep], hh.to(final.dtype))
            if not is_r8.any() or mode == "skip":
                continue
            x = hidden_states[tokidx[is_r8]]
            if mode == "full":
                g, u = F.linear(x, gu).chunk(2, dim=-1)
                hh = F.linear(self.act_fn(g) * u, dn)
            else:
                hi = half_idx.to(gu.device)
                g = F.linear(x, gu[hi])
                u = F.linear(x, gu[d_ff + hi])
                hh = F.linear(self.act_fn(g) * u, dn[:, hi])
            hh = hh * top_k_weights[tokidx[is_r8], pos[is_r8], None]
            final.index_add_(0, tokidx[is_r8], hh.to(final.dtype))
        return final
    return fwd

fn = make_forward("full", torch.arange(512))
for e in [l.mlp.experts for l in m.model.layers]:
    e.forward = types.MethodType(fn, e)

flags.clear()
with torch.no_grad():
    out2 = m(input_ids=ids, use_cache=False)
print("patched logits finite:", torch.isfinite(out2.logits).all().item())
print("patched per-layer mlp finite:", all(flags.values()), [k for k, v in flags.items() if not v])

# 最初に壊れる層の重みの状態を見る
for i, l in enumerate(m.model.layers):
    gu = l.mlp.experts.gate_up_proj
    if gu.is_meta:
        print("layer %d gate_up_proj is META" % i)
print("done")
