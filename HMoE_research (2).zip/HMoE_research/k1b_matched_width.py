#!/usr/bin/env python3
"""K1b: 「幅を合わせた」対応で K1 の seed 間ばらつきが消えるかを確かめる。

動機
  K1 の ΔCE(dense161 − teacher) は −0.0379 / −0.0290 / −0.0028 と seed で 13 倍動く。
  一方、教師の実測幅は 158.2 / 168.1 / 181.7 で、**等 MACs の対応点からずれている**
  （s2 では教師の方が 5.8% 計算が多い）。つまり「幅のずれ ΔW」はノイズでなく共変量かもしれない。
  もしそうなら、seed を 28 本に増やすより、**ΔW = 0 に設計で合わせる**方が安い。

やること
  1. 既存 3 seed の (ΔW, ΔCE) を出し、傾きを当てる（n=3 なので探索的）。
  2. 教師の実測幅に合わせた dense（W = round(W_teacher)）を 3 seed ぶん訓練し、
     同一評価系列の per-sequence CE で対応差を取る。
  3. ばらつき（seed 間 se）が K1 の 0.0105 より下がるかを見る。

  教師は K1 の ckpt をそのまま使う（再訓練しない）。dense の訓練条件は K1 と同一
  （3000 系列 × 6 epoch, bs 32, lr 2e-3, 1 スレッド, 同一 seed・同一データ順）。

出力: k1b_results.json / k1b_out_utf8.txt
"""
import argparse
import json
import os
import sys

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from p13c_retrain import (  # noqa: E402
    E2DIR, make_batch, run_cond, train_dense, OL,
)

OUTDIR = os.path.join(E2DIR, "data", "k1")
LOG = os.path.join(HERE, "k1b_out_utf8.txt")
D_MODEL, N_LAYERS = 128, 4


def macs(W, E):
    return N_LAYERS * (4 * D_MODEL * D_MODEL + 2 * D_MODEL * W + D_MODEL * E)


def log(msg):
    print(msg, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(msg + "\n")


def paired(a, b):
    d = np.asarray(a, float) - np.asarray(b, float)
    return {"delta": float(d.mean()),
            "se": float(d.std(ddof=1) / np.sqrt(len(d))),
            "t": float(d.mean() / (d.std(ddof=1) / np.sqrt(len(d)))), "n": len(d)}


def mde(se, n):
    coef = {2: 5.36, 5: 3.49}.get(n - 1, 2.95)
    return coef * se


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--n_eval", type=int, default=2048)
    args = ap.parse_args()

    torch.set_num_threads(1)
    if os.path.exists(LOG):
        os.remove(LOG)

    k1 = json.load(open(os.path.join(HERE, "k1_results.json"), encoding="utf-8"))
    z = np.load(os.path.join(HERE, "k1_ce_seq.npz"))
    ev = np.random.default_rng(777)
    src, out, em, ks = make_batch(ev, args.n_eval)

    log("K1b: 教師の実測幅に合わせた dense 生徒（1 process, 1 thread）")
    log("eval n=%d edit率=%.4f" % (src.shape[0], em.mean()))
    log("")

    # --- 1) 既存 3 seed の (ΔW, ΔCE) ---
    log("== 1) 既存データの (ΔW, ΔCE)（探索的, n=3） ==")
    dw, dc = [], []
    for s in args.seeds:
        rt = k1["runs"]["teacher:s%d" % s]
        d = k1["runs"]["diff:dense161:s%d" % s]
        # ΔW = 教師の幅 − 161（正なら教師の方が計算が多い）
        dw.append(rt["width"] - 161.0)
        dc.append(d["delta"])
        log("  s%d  W_teacher %6.1f  ΔW %+5.1f  ΔCE %+.4f  (MACs 比 %.3f)"
            % (s, rt["width"], rt["width"] - 161.0, d["delta"],
               macs(rt["width"], 8) / macs(161, 1)))
    dw, dc = np.array(dw), np.array(dc)
    if len(dw) >= 3:
        b, a = np.polyfit(dw, dc, 1)
        pred = a + b * dw
        resid = dc - pred
        log("  回帰: ΔCE = %+.4f %+.5f·ΔW   残差 SD %.4f（実測の SD %.4f）"
            % (a, b, resid.std(ddof=1), dc.std(ddof=1)))
        log("  → ΔW=0 での予測 %+.4f。**ΔW を 0 にすればばらつきは %.0f%% 減る**（n=3 の探索的推定）"
            % (a, 100 * (1 - resid.std(ddof=1) / dc.std(ddof=1))))
    log("")

    # --- 2) 幅を合わせた dense を訓練 ---
    log("== 2) W = round(W_teacher) の dense を訓練 ==")
    res = {}
    deltas = []
    for s in args.seeds:
        wt = k1["runs"]["teacher:s%d" % s]["width"]
        w = int(round(wt))
        log("  s%d: W_teacher %.1f → dense W=%d（MACs 比 %.4f）"
            % (s, wt, w, macs(wt, 8) / macs(w, 1)))
        m = train_dense(w, s, args.seqs, args.epochs, 32, 2e-3)
        r = run_cond(m, src, out, em, None, 1)
        ce_s = np.array(r["ce_seq"])
        ce_t = z["teacher:s%d" % s]
        p = paired(ce_s, ce_t)
        p.update({"seed": s, "W": w, "W_teacher": wt,
                  "macs_ratio": macs(wt, 8) / macs(w, 1),
                  "ce_s": r["ce_all"], "ce_t": k1["runs"]["teacher:s%d" % s]["ce_all"],
                  "ce_copy_s": r["ce_copy"], "ce_copy_t": k1["runs"]["teacher:s%d" % s]["ce_copy"]})
        res["matched:s%d" % s] = p
        deltas.append(p["delta"])
        log("     dense%d s%d CE %.4f（教師 %.4f） ΔCE %+.4f  se %.4f  t %+.2f"
            % (w, s, r["ce_all"], p["ce_t"], p["delta"], p["se"], p["t"]))
        torch.save({k: v.detach() for k, v in m.params().items()},
                   os.path.join(OUTDIR, "ckpt_dense%d_s%d_matched.pt" % (w, s)))

    deltas = np.array(deltas)
    n = len(deltas)
    se = float(deltas.std(ddof=1) / np.sqrt(n))
    log("")
    log("== 3) 幅を合わせた対応の集計（n=%d） ==" % n)
    log("  ΔCE = %+.4f  se %.4f  t %+.2f  %d/%d で負  MDE %.4f"
        % (deltas.mean(), se, deltas.mean() / se if se > 0 else float("nan"),
           int((deltas < 0).sum()), n, mde(se, n)))
    log("  比較: K1（W=161 固定）ΔCE %+.4f, se 0.0105, MDE 0.0564"
        % k1["agg"]["dense161"]["delta_mean"])
    log("  → se が %.2f 倍（1 未満なら「ΔW が主因」を支持）"
        % (se / 0.0105))

    out = {"matched": res,
           "agg": {"delta_mean": float(deltas.mean()), "se": se,
                   "t": float(deltas.mean() / se) if se > 0 else float("nan"),
                   "n": n, "mde": mde(se, n),
                   "per_seed": deltas.tolist()},
           "k1_reference": {"delta_mean": k1["agg"]["dense161"]["delta_mean"],
                            "se": k1["agg"]["dense161"]["se"],
                            "mde": k1["agg"]["dense161"]["mde"]}}
    with open(os.path.join(HERE, "k1b_results.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=float)
    log("\n[write] k1b_results.json")
    os._exit(0)


if __name__ == "__main__":
    main()
