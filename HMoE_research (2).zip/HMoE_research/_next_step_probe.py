# -*- coding: utf-8 -*-
"""使い捨て: 「次の一手」精査用の算術。AX10 の一次 json とローカル config だけを読む。

- 確認的 P1 / P2 を検出するために必要なトークン数を MDE の定義から逆算
- モデル構成の差（層数・語彙・ablate 本数）を一次 config から数え直す
結果は _next_step_probe.json に UTF-8 で保存する。
"""
import json
import math

HERE = "."
with open("ax10_shift_avg.json", encoding="utf-8") as f:
    J = json.load(f)
with open("models/olmoe-1b-7b/config.json", encoding="utf-8") as f:
    OLMOE = json.load(f)

# HF Qwen/Qwen1.5-MoE-A2.7B/raw/main/config.json を WebFetch で確認した値（2026-11-14）
QWEN = {
    "num_hidden_layers": 24,
    "num_experts": 60,
    "num_experts_per_tok": 4,
    "vocab_size": 151936,
    "hidden_size": 2048,
    "shared_expert_intermediate_size": 5632,
    "moe_intermediate_size": 1408,
    "decoder_sparse_step": 1,
}

out = {"source": {"ax10": "ax10_shift_avg.json", "olmoe_config": "models/olmoe-1b-7b/config.json",
                  "qwen_config": "HF Qwen/Qwen1.5-MoE-A2.7B raw config.json (WebFetch 2026-11-14)"}}

c1 = J["confirmatory"]["P1_length"]
c2 = J["confirmatory"]["P2_alignment"]
n0 = J["meta"]["n_tok"]
nw = J["meta"]["windows"]
t975 = c1["mde"] / c1["se"]  # t_{0.975, 12239} を MDE/se から復元
minutes_ax10 = 110.0  # ログ「約 1 時間 50 分」

out["t975_from_mde_over_se"] = t975
out["n_now"] = n0
out["windows_now"] = nw
out["power"] = {}
for name, c in (("P1_length", c1), ("P2_alignment", c2)):
    n_need = (t975 * c["sd"] / abs(c["mean"])) ** 2
    fac = n_need / n0
    out["power"][name] = {
        "mean": c["mean"], "sd": c["sd"], "se_now": c["se"], "mde_now": c["mde"],
        "n_need_for_t_ge_t975": n_need, "factor_vs_now": fac,
        "windows_need": nw * fac, "minutes_est_if_linear": minutes_ax10 * fac,
    }

out["model_diff"] = {
    "olmoe_layers": OLMOE["num_hidden_layers"], "qwen_layers": QWEN["num_hidden_layers"],
    "olmoe_experts": OLMOE["num_experts"], "qwen_experts": QWEN["num_experts"],
    "olmoe_topk": OLMOE["num_experts_per_tok"], "qwen_topk": QWEN["num_experts_per_tok"],
    "olmoe_vocab": OLMOE["vocab_size"], "qwen_vocab": QWEN["vocab_size"],
    "vocab_ratio": QWEN["vocab_size"] / OLMOE["vocab_size"],
    "olmoe_shared_expert": None, "qwen_shared_expert_intermediate": QWEN["shared_expert_intermediate_size"],
    "ablate_forwards_olmoe_2x_layers": 2 * OLMOE["num_hidden_layers"],
    "ablate_forwards_qwen_2x_layers": 2 * QWEN["num_hidden_layers"],
    "ablate_ratio": (2 * QWEN["num_hidden_layers"]) / (2 * OLMOE["num_hidden_layers"]),
}

# コーパス ID の語彙範囲（_corpus_probe.py の実測を再掲）
out["corpus"] = {
    "file": "corpus_ids_ax3_w24_l256.npz",
    "en_ids": {"shape": [6144], "dtype": "int32", "min": 4, "max": 50276},
    "ja_ids": {"shape": [6144], "dtype": "int32", "min": 4, "max": 50169},
    "max_id_below_olmoe_vocab": 50276 < OLMOE["vocab_size"],
    "note": "同じ整数列は Qwen の語彙 151936 では別トークンを指す。再トークン化が必須。",
}

# ckpt サイズ比（AX9 設計書 §1 の 13.84 GB / 28.63 GB と、AX9 取得 80 分）
out["download"] = {
    "olmoe_instruct_gb": 13.84, "qwen_gb": 28.63,
    "size_ratio": 28.63 / 13.84,
    "ax9_minutes": 80, "qwen_minutes_if_linear": 80 * 28.63 / 13.84,
}

with open("_next_step_probe.json", "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print(json.dumps(out, ensure_ascii=False, indent=2))
