# -*- coding: utf-8 -*-
"""S1 analysis: paired prompt / ablation effects and router statistics.

Reads s1_stair_routing*.npz (written by s1_stair_routing.py) and writes
s1_analysis*.json + s1_analysis*_figure.png.

Primary endpoint
----------------
margin = log p(gold divergence token) - log p(distractor divergence token)
at the first token where the distractor differs from the gold leaf.  Both
sequences share the prompt and every token before that position, so the two
log-probs come from exactly the same model distribution (paired by token).

All tests are paired across queries.  No scipy: the two-sided t p-value is
computed from the regularized incomplete beta function.
"""

import argparse
import json
import math
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


# ---------------------------------------------------------------------------
# statistics
# ---------------------------------------------------------------------------

def _betacf(a, b, x):
    MAXIT, EPS, FPMIN = 200, 3.0e-12, 1.0e-300
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    if abs(d) < FPMIN:
        d = FPMIN
    d = 1.0 / d
    h = d
    for m in range(1, MAXIT + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN:
            d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN:
            c = FPMIN
        d = 1.0 / d
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        if abs(d) < FPMIN:
            d = FPMIN
        c = 1.0 + aa / c
        if abs(c) < FPMIN:
            c = FPMIN
        d = 1.0 / d
        de = d * c
        h *= de
        if abs(de - 1.0) < EPS:
            break
    return h


def _betai(a, b, x):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    bt = math.exp(math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
                  + a * math.log(x) + b * math.log(1.0 - x))
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * _betacf(a, b, x) / a
    return 1.0 - bt * _betacf(b, a, 1.0 - x) / b


def t_pvalue(t, df):
    """Two-sided p for a t statistic (regularized incomplete beta)."""
    if not np.isfinite(t) or df <= 0:
        return float("nan")
    return float(_betai(df / 2.0, 0.5, df / (df + t * t)))


def paired(d):
    d = np.asarray(d, dtype=np.float64)
    d = d[np.isfinite(d)]
    n = int(d.size)
    if n < 2:
        return {"mean": float(d.mean()) if n else float("nan"), "se": float("nan"),
                "t": float("nan"), "p": float("nan"), "n": n, "mde": float("nan"),
                "sd": float("nan")}
    m = float(d.mean())
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    t = m / se if se > 0 else float("nan")
    return {"mean": m, "se": se, "t": t, "p": t_pvalue(t, n - 1), "n": n,
            "mde": 2.8 * se, "sd": sd}


def pearson(x, y):
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    ok = np.isfinite(x) & np.isfinite(y)
    x, y = x[ok], y[ok]
    n = int(x.size)
    if n < 3 or x.std() == 0 or y.std() == 0:
        return {"r": float("nan"), "n": n}
    r = float(np.corrcoef(x, y)[0, 1])
    # two-sided p via t = r sqrt((n-2)/(1-r^2))
    if abs(r) >= 1.0:
        p = 0.0
    else:
        tt = r * math.sqrt((n - 2) / (1 - r * r))
        p = t_pvalue(tt, n - 2)
    return {"r": r, "p": p, "n": n}


def rankdata(v):
    v = np.asarray(v, dtype=np.float64)
    order = np.argsort(v, kind="mergesort")
    ranks = np.empty(v.size, dtype=np.float64)
    i = 0
    while i < v.size:
        j = i
        while j + 1 < v.size and v[order[j + 1]] == v[order[i]]:
            j += 1
        ranks[order[i:j + 1]] = 0.5 * (i + j) + 1.0
        i = j + 1
    return ranks


def spearman(x, y):
    x = np.asarray(x, dtype=np.float64)
    y = np.asarray(y, dtype=np.float64)
    ok = np.isfinite(x) & np.isfinite(y)
    if ok.sum() < 3:
        return {"rho": float("nan"), "n": int(ok.sum())}
    r = pearson(rankdata(x[ok]), rankdata(y[ok]))
    return {"rho": r["r"], "p": r["p"], "n": r["n"]}


# ---------------------------------------------------------------------------
# data
# ---------------------------------------------------------------------------

TYPES = ("sibling", "cousin", "far")
PROMPTS = ("toc", "toc_drop", "none", "shuffle", "toc_mis", "none_mis")
ARMS = ("g_rare", "g_freq", "g_rand", "l_rare", "l_freq", "l_rand")


def load(path):
    z = np.load(path, allow_pickle=True)
    meta = json.loads(str(z["meta"][0]))
    rows = []
    for i in range(len(z["row_domain"])):
        rows.append({
            "domain": str(z["row_domain"][i]),
            "query_id": int(z["row_query_id"][i]),
            "entry": int(z["row_entry"][i]),
            "ctype": str(z["row_cand_type"][i]),
            "is_gold": int(z["row_is_gold"][i]),
            "lca": int(z["row_lca"][i]),
            "depth": int(z["row_depth"][i]),
            "train_count": int(z["row_train_count"][i]),
            "prompt": str(z["row_prompt"][i]),
            "ablation": str(z["row_ablation"][i]),
            "logp_full": float(z["row_logp_full"][i]),
            "logp_num": float(z["row_logp_num"][i]),
            "logp_div": float(z["row_logp_div"][i]),
            "mean_full": float(z["row_mean_full"][i]),
            "mean_num": float(z["row_mean_num"][i]),
            "n_tok": int(z["row_n_tok"][i]),
            "div_idx": int(z["row_div_idx"][i]),
            "div_level": int(z["row_div_level"][i]),
            "prompt_len": int(z["row_prompt_len"][i]),
            "rare_div": float(z["row_rare_div"][i]),
            "freq_div": float(z["row_freq_div"][i]),
            "rank_div": float(z["row_rank_div"][i]),
            "ent_div": float(z["row_ent_div"][i]),
            "maxw_div": float(z["row_maxw_div"][i]),
            "rare_num": float(z["row_rare_num"][i]),
            "rare_title": float(z["row_rare_title"][i]),
            "rare_first": float(z["row_rare_first"][i]),
            "rare_last": float(z["row_rare_last"][i]),
            "ent_num": float(z["row_ent_num"][i]),
            "ent_title": float(z["row_ent_title"][i]),
        })

    gd = [str(x) for x in z["gold_domain"]]
    gq = [int(x) for x in z["gold_query_id"]]
    ge = [int(x) for x in z["gold_entry"]]
    gp = [str(x) for x in z["gold_prompt"]]
    ga = [str(x) for x in z["gold_ablation"]]
    gold_tok = {(gd[i], gq[i], gp[i], ga[i]): i for i in range(len(gd))}

    gold_row = {}
    for i, r in enumerate(rows):
        if r["is_gold"]:
            gold_row[(r["domain"], r["query_id"], r["prompt"], r["ablation"])] = i

    return z, meta, rows, gold_tok, gold_row


def attach_margins(z, rows, gold_tok, gold_row):
    """One record per distractor: margin at its divergence token."""
    out = []
    missing_gold = 0
    bad_div = 0
    for r in rows:
        if r["is_gold"]:
            continue
        key = (r["domain"], r["query_id"], r["prompt"], r["ablation"])
        if key not in gold_row or key not in gold_tok:
            missing_gold += 1
            continue
        gr = gold_row[key]
        gt = gold_tok[key]
        j = r["div_idx"]
        C = int(z["gold_len"][gt])
        if j < 0 or j >= C or not np.isfinite(r["logp_div"]):
            bad_div += 1
            glp = float("nan")
        else:
            glp = float(z["gold_logp"][gt, j])
        out.append({
            "domain": r["domain"], "query_id": r["query_id"], "entry": r["entry"],
            "ctype": r["ctype"], "lca": r["lca"], "depth": r["depth"],
            "train_count": r["train_count"], "prompt": r["prompt"],
            "ablation": r["ablation"], "div_idx": j, "div_level": r["div_level"],
            "margin": glp - r["logp_div"],
            "margin_mean": float(z["row_mean_full"][gr]) - r["mean_full"],
            "margin_full": float(z["row_logp_full"][gr]) - r["logp_full"],
            "rare_div": r["rare_div"], "freq_div": r["freq_div"],
            "ent_div": r["ent_div"], "rank_div": r["rank_div"],
            "n_tok": r["n_tok"], "prompt_len": r["prompt_len"],
        })
    return out, {"missing_gold": missing_gold, "bad_div": bad_div}


def qmap(recs, prompt, ablation, ctype=None, value="margin"):
    """Mean per (domain, query_id)."""
    acc = {}
    for r in recs:
        if r["prompt"] != prompt or r["ablation"] != ablation:
            continue
        if ctype is not None and r["ctype"] != ctype:
            continue
        k = (r["domain"], r["query_id"])
        acc.setdefault(k, []).append(r[value])
    return {k: float(np.nanmean(v)) for k, v in acc.items() if np.isfinite(v).any()}


def diff_maps(a, b):
    keys = sorted(set(a) & set(b))
    return {k: a[k] - b[k] for k in keys}


def map_stats(m):
    return paired(list(m.values()))


def did(a1, a0, b1, b0):
    """(a1-a0) - (b1-b0) on common query keys."""
    keys = sorted(set(a1) & set(a0) & set(b1) & set(b0))
    d = [(a1[k] - a0[k]) - (b1[k] - b0[k]) for k in keys]
    return paired(d)


def by_domain(m, domains):
    out = {}
    for d in domains:
        vals = [v for k, v in m.items() if k[0] == d]
        out[d] = paired(vals)
    return out


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--npz", type=str, default=os.path.join(HERE, "s1_stair_routing.npz"))
    ap.add_argument("--tag", type=str, default="s1_analysis")
    args = ap.parse_args()

    z, meta, rows, gold_tok, gold_row = load(args.npz)
    recs, sanity_margin = attach_margins(z, rows, gold_tok, gold_row)
    domains = sorted(set(r["domain"] for r in rows))
    res = {"meta": meta, "input": args.npz, "domains": domains,
           "n_rows": len(rows), "n_distractor_rows": len(recs)}

    # -- sanity --------------------------------------------------------------
    base = [r for r in recs if r["ablation"] == "base"]
    sanity = {
        "rows_by_prompt_ablation": {},
        "n_queries": len(set((r["domain"], r["query_id"]) for r in rows)),
        "candidates_by_type": {},
        "margin_finite_by_type": {},
        "mean_prompt_len": {},
        "mean_candidate_tokens_by_type": {},
        "margin": sanity_margin,
    }
    for p in PROMPTS:
        for a in ("base",) + ARMS:
            n = sum(1 for r in rows if r["prompt"] == p and r["ablation"] == a)
            if n:
                sanity["rows_by_prompt_ablation"]["%s|%s" % (p, a)] = n
    for t in TYPES:
        sub = [r for r in base if r["ctype"] == t]
        sanity["candidates_by_type"][t] = len(sub)
        sanity["margin_finite_by_type"][t] = int(sum(np.isfinite(r["margin"]) for r in sub))
        sanity["mean_candidate_tokens_by_type"][t] = float(np.mean([r["n_tok"] for r in sub])) if sub else float("nan")
    for p in PROMPTS:
        sub = [r for r in rows if r["prompt"] == p]
        sanity["mean_prompt_len"][p] = float(np.mean([r["prompt_len"] for r in sub])) if sub else float("nan")
    res["sanity"] = sanity

    # -- 1. prompt effect on margin -----------------------------------------
    prompt_margin = {}
    for p in PROMPTS:
        prompt_margin[p] = {}
        for t in TYPES:
            m = qmap(base, p, "base", t)
            if m:
                prompt_margin[p][t] = map_stats(m)
                prompt_margin[p][t]["by_domain"] = by_domain(m, domains)
    res["prompt_margin"] = prompt_margin

    prompt_diff = {}
    for p1, p0 in (("toc", "none"), ("toc", "shuffle"), ("shuffle", "none"),
                   ("toc", "toc_drop"), ("toc_drop", "none"),
                   ("toc_mis", "toc"), ("none_mis", "none")):
        prompt_diff["%s-%s" % (p1, p0)] = {}
        for t in TYPES:
            a = qmap(base, p1, "base", t)
            b = qmap(base, p0, "base", t)
            d = diff_maps(a, b)
            if d:
                prompt_diff["%s-%s" % (p1, p0)][t] = map_stats(d)
                prompt_diff["%s-%s" % (p1, p0)][t]["by_domain"] = by_domain(d, domains)
    res["prompt_diff"] = prompt_diff

    res["did_prompt"] = {}
    for p1, p0 in (("toc", "none"), ("toc", "shuffle"), ("shuffle", "none"),
                   ("toc", "toc_drop"), ("toc_drop", "none")):
        s1 = qmap(base, p1, "base", "sibling")
        s0 = qmap(base, p0, "base", "sibling")
        f1 = qmap(base, p1, "base", "far")
        f0 = qmap(base, p0, "base", "far")
        res["did_prompt"]["%s-%s|sibling-far" % (p1, p0)] = did(s1, s0, f1, f0)
        c1 = qmap(base, p1, "base", "cousin")
        c0 = qmap(base, p0, "base", "cousin")
        if c1 and c0:
            res["did_prompt"]["%s-%s|cousin-far" % (p1, p0)] = did(c1, c0, f1, f0)

    # -- 2. ablation effect --------------------------------------------------
    ablation = {}
    for p in ("toc", "none"):
        ablation[p] = {}
        bm = {t: qmap(base, p, "base", t) for t in TYPES}
        for a in ARMS:
            ablation[p][a] = {}
            am = {t: qmap(recs, p, a, t) for t in TYPES}
            for t in TYPES:
                if not am[t] or not bm[t]:
                    continue
                hurt = {k: bm[t][k] - am[t][k] for k in set(bm[t]) & set(am[t])}
                ablation[p][a][t] = map_stats(hurt)
            # arm contrasts: rare arm minus freq/rand arm (positive = rare ablation hurts more)
        for a1, a0, label in (("g_rare", "g_freq", "g_rare-g_freq"),
                              ("g_rare", "g_rand", "g_rare-g_rand"),
                              ("l_rare", "l_freq", "l_rare-l_freq"),
                              ("l_rare", "l_rand", "l_rare-l_rand")):
            if a1 not in ablation[p] or a0 not in ablation[p]:
                continue
            # contrast per query: margin(a0) - margin(a1) = hurt(a1)-hurt(a0)
            for t in TYPES:
                m1 = qmap(recs, p, a1, t)
                m0 = qmap(recs, p, a0, t)
                d = diff_maps(m0, m1)
                if d:
                    ablation[p][a1 + "-" + a0 + "|" + t] = map_stats(d)
    res["ablation"] = ablation

    res["did_ablation"] = {}
    for p in ("toc", "none"):
        # Does the ablation hurt sibling discrimination more than far?
        for a in ARMS:
            sb = qmap(base, p, "base", "sibling")
            s = qmap(recs, p, a, "sibling")
            fb = qmap(base, p, "base", "far")
            f = qmap(recs, p, a, "far")
            keys = sorted(set(sb) & set(s) & set(fb) & set(f))
            if keys:
                d = [(sb[k] - s[k]) - (fb[k] - f[k]) for k in keys]
                res["did_ablation"]["%s|%s|sibling-far_hurt" % (p, a)] = paired(d)
        # Does the same ablation hurt less when the ToC is present?
        for a in ARMS:
            for t in ("sibling", "far"):
                b1 = qmap(base, "toc", "base", t)
                a1 = qmap(recs, "toc", a, t)
                b0 = qmap(base, "none", "base", t)
                a0 = qmap(recs, "none", a, t)
                keys = sorted(set(b1) & set(a1) & set(b0) & set(a0))
                if keys:
                    d = [(b1[k] - a1[k]) - (b0[k] - a0[k]) for k in keys]
                    res["did_ablation"]["toc-none|%s|%s_hurt" % (a, t)] = paired(d)

    # -- 3. router statistics on gold rows ----------------------------------
    routing = {}
    for p in ("toc", "none"):
        vals = {}
        for f in ("rare_num", "rare_title", "rare_first", "rare_last",
                  "ent_num", "ent_title"):
            m = {}
            for r in rows:
                if r["is_gold"] and r["prompt"] == p and r["ablation"] == "base":
                    m[(r["domain"], r["query_id"])] = r[f]
            vals[f] = m
        routing[p] = {
            "rare_num": map_stats(vals["rare_num"]),
            "rare_title": map_stats(vals["rare_title"]),
            "rare_num-title": map_stats(diff_maps(vals["rare_num"], vals["rare_title"])),
            "ent_num": map_stats(vals["ent_num"]),
            "ent_title": map_stats(vals["ent_title"]),
            "ent_num-title": map_stats(diff_maps(vals["ent_num"], vals["ent_title"])),
            "rare_first-last": map_stats(diff_maps(vals["rare_first"], vals["rare_last"])),
        }
    # ToC effect on routing
    for f in ("rare_num", "rare_title", "ent_num", "ent_title"):
        a = {}
        b = {}
        for r in rows:
            if r["is_gold"] and r["ablation"] == "base":
                k = (r["domain"], r["query_id"])
                if r["prompt"] == "toc":
                    a[k] = r[f]
                elif r["prompt"] == "none":
                    b[k] = r[f]
        routing["toc-none|" + f] = map_stats(diff_maps(a, b))

    # routing at the divergence token, by type (base)
    rare_div_by_type = {}
    for t in TYPES:
        m = qmap(base, "toc", "base", t, value="rare_div")
        if m:
            rare_div_by_type["toc|" + t] = map_stats(m)
        m = qmap(base, "none", "base", t, value="rare_div")
        if m:
            rare_div_by_type["none|" + t] = map_stats(m)
    routing["rare_div_by_type"] = rare_div_by_type
    for p in ("toc", "none"):
        s = qmap(base, p, "base", "sibling", value="rare_div")
        f = qmap(base, p, "base", "far", value="rare_div")
        if s and f:
            routing["rare_div_%s|sibling-far" % p] = map_stats(diff_maps(s, f))
    res["routing"] = routing

    # -- 4. token covariates (gold rows) ------------------------------------
    # number tokens vs title tokens: token log-frequency and fragment rate
    cov = {}
    for p in ("toc", "none"):
        for f in ("tlogfreq", "tfrag"):
            num, title = [], []
            for r in rows:
                if not (r["is_gold"] and r["prompt"] == p and r["ablation"] == "base"):
                    continue
                key = (r["domain"], r["query_id"], r["prompt"], r["ablation"])
                gt = gold_tok[key]
                C = int(z["gold_len"][gt])
                a = np.asarray(z["gold_" + f][gt, :C], dtype=np.float64)
                nm = np.asarray(z["gold_isnum"][gt, :C], dtype=bool)
                if nm.any():
                    num.append(float(np.nanmean(a[nm])))
                if (~nm).any():
                    title.append(float(np.nanmean(a[~nm])))
            cov["%s|%s|num" % (p, f)] = paired(num)
            cov["%s|%s|title" % (p, f)] = paired(title)
    res["token_covariates"] = cov

    # -- 5. gold-title likelihood (teacher forced) --------------------------
    gl = {}
    for p in PROMPTS:
        for f in ("mean_full", "mean_num", "logp_full"):
            m = {}
            for r in rows:
                if r["is_gold"] and r["prompt"] == p and r["ablation"] == "base":
                    m[(r["domain"], r["query_id"])] = r[f]
            if m:
                gl["%s|%s" % (p, f)] = map_stats(m)
    for p1, p0 in (("toc", "none"), ("toc", "shuffle"), ("toc", "toc_drop"),
                   ("toc_mis", "toc")):
        for f in ("mean_full", "mean_num", "logp_full"):
            a = {}
            b = {}
            for r in rows:
                if r["is_gold"] and r["ablation"] == "base":
                    k = (r["domain"], r["query_id"])
                    if r["prompt"] == p1:
                        a[k] = r[f]
                    elif r["prompt"] == p0:
                        b[k] = r[f]
            if a and b:
                gl["%s-%s|%s" % (p1, p0, f)] = map_stats(diff_maps(a, b))
    res["gold_logp"] = gl

    # -- 6. train count -------------------------------------------------------
    # gold train count is a query-level covariate; use base toc / none margins
    tc = {}
    for p in ("toc", "none"):
        for t in TYPES:
            m = qmap(base, p, "base", t)
            if not m:
                continue
            xs, ys = [], []
            tcmap = {}
            for r in rows:
                if r["is_gold"] and r["prompt"] == p and r["ablation"] == "base":
                    tcmap[(r["domain"], r["query_id"])] = r["train_count"]
            for k, v in m.items():
                if k in tcmap:
                    xs.append(tcmap[k])
                    ys.append(v)
            tc["%s|%s" % (p, t)] = spearman(xs, ys)
            if len(xs) >= 6:
                order = np.argsort(xs)
                xs = np.asarray(xs)[order]
                ys = np.asarray(ys)[order]
                cuts = np.array_split(np.arange(len(xs)), 3)
                tc["%s|%s|buckets" % (p, t)] = [
                    {"n": int(len(ix)), "train_lo": int(xs[ix].min()),
                     "train_hi": int(xs[ix].max()), "margin": float(ys[ix].mean())}
                    for ix in cuts if len(ix)]
    res["train_count"] = tc

    # -- 6. mechanism: rare share predicts local-rare ablation hurt ---------
    mech = {}
    for p in ("toc", "none"):
        for a in ("l_rare", "g_rare"):
            for t in TYPES:
                bm = qmap(base, p, "base", t)
                am = qmap(recs, p, a, t)
                rd = qmap(base, p, "base", t, value="rare_div")
                keys = sorted(set(bm) & set(am) & set(rd))
                if len(keys) >= 3:
                    xs = [rd[k] for k in keys]
                    ys = [bm[k] - am[k] for k in keys]
                    mech["%s|%s|%s|rare_div_vs_hurt" % (p, a, t)] = spearman(xs, ys)
    res["mechanism"] = mech

    # -- save ----------------------------------------------------------------
    def clean_json(o):
        if isinstance(o, dict):
            return {str(k): clean_json(v) for k, v in o.items()}
        if isinstance(o, (list, tuple)):
            return [clean_json(v) for v in o]
        if isinstance(o, (np.floating, np.integer)):
            return float(o)
        if isinstance(o, float) and not np.isfinite(o):
            return None
        return o

    out_json = os.path.join(HERE, args.tag + ".json")
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(clean_json(res), f, ensure_ascii=False, indent=1)
    print("wrote", out_json)

    # -- figure --------------------------------------------------------------
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        plt.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "DejaVu Sans"]
        fig, axes = plt.subplots(2, 2, figsize=(12, 8))
        ax = axes[0, 0]
        width = 0.8 / max(len(TYPES), 1)
        for j, t in enumerate(TYPES):
            xs, ys, es = [], [], []
            for i, p in enumerate(("toc", "none", "shuffle")):
                st = prompt_margin.get(p, {}).get(t)
                if st and st["n"] > 0:
                    xs.append(i + (j - 1) * width)
                    ys.append(st["mean"])
                    es.append(st["se"])
            if xs:
                ax.bar(xs, ys, width, yerr=es, capsize=2, label=t)
        ax.set_xticks(range(3))
        ax.set_xticklabels(["ToC", "none", "shuffle"])
        ax.axhline(0, color="k", lw=0.6)
        ax.set_ylabel("gold - distractor logp at divergence")
        ax.set_title("Prompt effect (base)")
        ax.legend(fontsize=8)

        ax = axes[0, 1]
        for j, t in enumerate(("sibling", "far")):
            xs, ys, es = [], [], []
            for i, a in enumerate(("g_rare", "g_freq", "g_rand", "l_rare", "l_freq", "l_rand")):
                st = ablation.get("toc", {}).get(a, {}).get(t)
                if st and st["n"] > 0:
                    xs.append(i + (j - 0.5) * 0.35)
                    ys.append(st["mean"])
                    es.append(st["se"])
            if xs:
                ax.bar(xs, ys, 0.35, yerr=es, capsize=2, label=t)
        ax.set_xticks(range(6))
        ax.set_xticklabels(["g_rare", "g_freq", "g_rand", "l_rare", "l_freq", "l_rand"],
                           rotation=30, fontsize=8)
        ax.axhline(0, color="k", lw=0.6)
        ax.set_ylabel("hurt = margin(base) - margin(ablated)")
        ax.set_title("Ablation hurt (ToC)")
        ax.legend(fontsize=8)

        ax = axes[1, 0]
        labels, means, errs = [], [], []
        for p in ("toc", "none"):
            for f, lab in (("rare_num", "num"), ("rare_title", "title")):
                st = routing.get(p, {}).get(f)
                if st and st["n"] > 0:
                    labels.append("%s\n%s" % (p, lab))
                    means.append(st["mean"])
                    errs.append(st["se"])
        ax.bar(range(len(means)), means, yerr=errs, capsize=2, color="tab:green")
        ax.set_xticks(range(len(labels)))
        ax.set_xticklabels(labels, fontsize=8)
        ax.set_ylabel("rare-expert share at gold tokens")
        ax.set_title("Number vs title routing")

        ax = axes[1, 1]
        for j, t in enumerate(TYPES):
            xs, ys, es = [], [], []
            for i, (p1, p0) in enumerate((("toc", "none"), ("shuffle", "none"))):
                st = prompt_diff.get("%s-%s" % (p1, p0), {}).get(t)
                if st and st["n"] > 0:
                    xs.append(i + (j - 1) * width)
                    ys.append(st["mean"])
                    es.append(st["se"])
            if xs:
                ax.bar(xs, ys, width, yerr=es, capsize=2, label=t)
        ax.set_xticks(range(2))
        ax.set_xticklabels(["ToC-none", "shuffle-none"])
        ax.axhline(0, color="k", lw=0.6)
        ax.set_ylabel("delta margin")
        ax.set_title("Paired prompt contrasts")
        ax.legend(fontsize=8)

        fig.tight_layout()
        out_fig = os.path.join(HERE, args.tag + "_figure.png")
        fig.savefig(out_fig, dpi=150)
        print("wrote", out_fig)
    except Exception as e:
        print("figure skipped:", repr(e))


if __name__ == "__main__":
    main()
