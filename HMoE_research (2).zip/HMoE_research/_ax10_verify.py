# -*- coding: utf-8 -*-
"""AX10 Step 4: 独立再計算（ax10_shift_avg.py を import しない別経路）。

scipy.stats.ttest_rel 経路で Δ・se・t・p・Holm・MDE・上位 1% 寄与率を作り直し、
npz の生配列から分割・決定・mean_k・校正・探索的分解を再構築して
<tag>_shift_avg.json と突合する。使い方: python _ax10_verify.py [tag]
"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats as scistats

HERE = os.path.dirname(os.path.abspath(__file__))
TAG = sys.argv[1] if len(sys.argv) > 1 else "ax10"
ALPHA = 0.05
N_LAYERS = 16
SEED_BASE = 7201
AX4_NPZ = os.path.join(HERE, "ax4_sentence_bound.npz")

ITEMS, MISMATCH = [], []


def chk(name, got, exp, rtol=1e-6, atol=1e-9):
    ITEMS.append(name)
    ok = False
    if isinstance(exp, (list, tuple)):
        try:
            ok = (len(got) == len(exp) and all(
                math.isclose(float(a), float(b), rel_tol=rtol, abs_tol=atol)
                for a, b in zip(got, exp)))
        except Exception:
            ok = (list(got) == list(exp))
    elif isinstance(exp, bool) or isinstance(exp, str):
        ok = (got == exp)
    elif isinstance(exp, (int, np.integer)) and isinstance(got, (int, np.integer)):
        ok = (int(got) == int(exp))
    else:
        try:
            ok = math.isclose(float(got), float(exp), rel_tol=rtol, abs_tol=atol)
        except Exception:
            ok = False
    if not ok:
        MISMATCH.append((name, got, exp))


def rst(d, tok_per_win=255):
    """paired stats の独立実装（scipy ttest_rel 経路）。"""
    d = np.asarray(d, dtype=np.float64).ravel()
    n = d.size
    m = float(d.mean())
    t, p = scistats.ttest_rel(d, np.zeros_like(d))
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    tc975 = float(scistats.t.ppf(0.975, n - 1))
    tc95 = float(scistats.t.ppf(0.95, n - 1))
    wm = d.reshape(-1, tok_per_win).mean(axis=1)
    sew = float(wm.std(ddof=1) / math.sqrt(wm.size))
    srt = np.sort(np.abs(d))[::-1]
    k1 = max(1, int(math.ceil(0.01 * n)))
    return {"mean": m, "sd": sd, "se": se, "t": float(t), "p_two": float(p),
            "mde": tc975 * se, "ci95": [m - tc975 * se, m + tc975 * se],
            "ci90": [m - tc95 * se, m + tc95 * se],
            "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
            "median": float(np.median(d)), "se_win": sew,
            "top1_abs_share": float(srt[:k1].sum() / srt.sum())}


def holm_adj(pvals):
    ids = sorted(pvals, key=lambda k: pvals[k])
    out, run = {}, 0.0
    for i, k in enumerate(ids):
        run = max(run, (len(ids) - i) * pvals[k])
        out[k] = min(1.0, run)
    return out


def decision_indep(c8, c7, uid, n_unit):
    """np.add.at 経由（本体の np.bincount とは別経路）。"""
    cnt = np.zeros(n_unit, dtype=np.float64)
    np.add.at(cnt, uid, 1.0)
    assert cnt.min() > 0
    a = np.zeros((n_unit, N_LAYERS), dtype=np.float64)
    b = np.zeros((n_unit, N_LAYERS), dtype=np.float64)
    for L in range(N_LAYERS):
        ta = np.zeros(n_unit, dtype=np.float64)
        tb = np.zeros(n_unit, dtype=np.float64)
        np.add.at(ta, uid, c8[L])
        np.add.at(tb, uid, c7[L])
        a[:, L] = ta / cnt
        b[:, L] = tb / cnt
    cut = np.argmin(b, axis=1).astype(np.int8)
    Q = a.copy()
    Q[np.arange(n_unit), cut] = -np.inf
    prot = np.argmax(Q, axis=1).astype(np.int8)
    return cut, prot


def main():
    json_path = os.path.join(HERE, "%s_shift_avg.json" % TAG)
    npz_path = os.path.join(HERE, "%s_shift_avg.npz" % TAG)
    if not os.path.exists(json_path) or not os.path.exists(npz_path):
        print(f"Missing {json_path} or {npz_path}")
        sys.exit(1)

    with open(json_path, encoding="utf-8") as f:
        J = json.load(f)
    Z = np.load(npz_path)

    n_tok = J["meta"]["n_tok"]
    nw = J["meta"]["windows"]
    S = J["meta"]["S"]
    n_eval = n_tok // nw
    assert n_eval == 255

    u7 = Z["nll_u7"]
    uni102 = Z["nll_uni102"]
    sent4 = Z["nll_sent4"]
    uni181 = Z["nll_uni181"]
    sent2 = Z["nll_sent2"]
    c8 = Z["c8"]
    c7 = Z["c7"]

    # 1. shift average NLL の独立再構築
    shift102_nlls = [Z["nll_shift102_s%02d" % (s + 1)] for s in range(S)]
    shift181_nlls = [Z["nll_shift181_s%02d" % (s + 1)] for s in range(S)]
    shift_avg_102 = np.mean(shift102_nlls, axis=0)
    shift_avg_181 = np.mean(shift181_nlls, axis=0)

    chk("nll_shift_avg_102_maxdiff", float(np.abs(shift_avg_102 - Z["nll_shift_avg_102"]).max()), 0.0)
    chk("nll_shift_avg_181_maxdiff", float(np.abs(shift_avg_181 - Z["nll_shift_avg_181"]).max()), 0.0)

    # 2. 確認的検定 (P1, P2) の再計算
    d_p1 = uni102 - shift_avg_102
    d_p2 = shift_avg_102 - sent4
    r_p1 = rst(d_p1, n_eval)
    r_p2 = rst(d_p2, n_eval)

    for k in ("mean", "sd", "se", "t", "p_two", "mde", "n_pos", "n_neg", "median"):
        chk("P1_" + k, r_p1[k], J["confirmatory"]["P1_length"][k])
        chk("P2_" + k, r_p2[k], J["confirmatory"]["P2_alignment"][k])

    chk("P1_ci95", r_p1["ci95"], J["confirmatory"]["P1_length"]["ci95"])
    chk("P1_ci90", r_p1["ci90"], J["confirmatory"]["P1_length"]["ci90"])
    chk("P2_ci95", r_p2["ci95"], J["confirmatory"]["P2_alignment"]["ci95"])
    chk("P2_ci90", r_p2["ci90"], J["confirmatory"]["P2_alignment"]["ci90"])

    # Holm
    ph = holm_adj({"P1": r_p1["p_two"], "P2": r_p2["p_two"]})
    chk("holm_P1", ph["P1"], J["confirmatory"]["holm"]["P1"])
    chk("holm_P2", ph["P2"], J["confirmatory"]["holm"]["P2"])

    rej_p1 = bool(ph["P1"] < ALPHA)
    rej_p2 = bool(ph["P2"] < ALPHA)
    chk("reject_P1", rej_p1, J["confirmatory"]["reject"]["P1"])
    chk("reject_P2", rej_p2, J["confirmatory"]["reject"]["P2"])

    if rej_p1 and rej_p2:
        exp_case = "C"
    elif rej_p1:
        exp_case = "A"
    elif rej_p2:
        exp_case = "B"
    else:
        exp_case = "D"
    chk("case", exp_case, J["confirmatory"]["case"])

    # 3. 各腕の利得 (gains) の検算
    for prefix, N_val in (("shift102", 102), ("shift181", 181)):
        for s in range(S):
            nm = "%s_s%02d" % (prefix, s + 1)
            g = rst(u7 - Z["nll_" + nm], n_eval)
            chk("gain_%s_mean" % nm, g["mean"], J["gains"][nm]["mean"])
            chk("gain_%s_se" % nm, g["se"], J["gains"][nm]["se"])

    for ref in ("sent4", "sent2", "uni102", "uni181"):
        g = rst(u7 - Z["nll_" + ref], n_eval)
        chk("gain_%s_mean" % ref, g["mean"], J["gains"][ref]["mean"])
        chk("gain_%s_se" % ref, g["se"], J["gains"][ref]["se"])

    # 4. S-draw 統計の検算
    g102 = np.array([J["gains"]["shift102_s%02d" % (s + 1)]["mean"] for s in range(S)])
    g181 = np.array([J["gains"]["shift181_s%02d" % (s + 1)]["mean"] for s in range(S)])
    chk("draw_stats_102_mean", float(g102.mean()), J["exploratory"]["draw_stats_102"]["mean"])
    chk("draw_stats_102_sd", float(g102.std(ddof=1)), J["exploratory"]["draw_stats_102"]["sd"])
    chk("draw_stats_181_mean", float(g181.mean()), J["exploratory"]["draw_stats_181"]["mean"])
    chk("draw_stats_181_sd", float(g181.std(ddof=1)), J["exploratory"]["draw_stats_181"]["sd"])

    # 5. 分解 (decomposition) の検算
    G_shiftmean102 = float((u7 - shift_avg_102).mean())
    G_shiftmean181 = float((u7 - shift_avg_181).mean())
    chk("G_shiftmean102", G_shiftmean102, J["exploratory"]["G_shiftmean102"])
    chk("G_shiftmean181", G_shiftmean181, J["exploratory"]["G_shiftmean181"])

    d102_tot = float((u7 - sent4).mean()) - float((u7 - uni102).mean())
    d102_alg = float((u7 - sent4).mean()) - G_shiftmean102
    d102_len = G_shiftmean102 - float((u7 - uni102).mean())
    chk("decomp_102_total", d102_tot, J["exploratory"]["decomposition_N102"]["total"])
    chk("decomp_102_alignment", d102_alg, J["exploratory"]["decomposition_N102"]["alignment"])
    chk("decomp_102_length", d102_len, J["exploratory"]["decomposition_N102"]["length"])

    # 6. 校正 C1〜C7 の検算
    z4 = np.load(AX4_NPZ)
    u7_saved = z4["nll_u7_rep"][:n_tok].astype(np.float64)
    base_saved = z4["nll_base_rep"][:n_tok].astype(np.float64)
    bd = float(np.abs(Z["nll_base_rep"] - base_saved).max())
    ud = float(np.abs(Z["nll_u7_rep"] - u7_saved).max())
    chk("C1_base_maxdiff", bd, J["calib"]["C1"]["base_maxdiff"])
    chk("C1_u7_maxdiff", ud, J["calib"]["C1"]["u7_maxdiff"])
    chk("C1_tier", "A" if bd == 0.0 and ud == 0.0 else "FAIL", J["calib"]["C1"]["tier"])

    # C2 multiset check
    for prefix, N_val in (("shift102", 102), ("shift181", 181)):
        exp_unique = N_val if nw == 48 else J["gains"][prefix + "_s01"]["n_units"] if "n_units" in J["gains"][prefix + "_s01"] else len(np.unique(Z["uid_" + prefix + "_s01"]))
        for s in range(S):
            nm = "%s_s%02d" % (prefix, s + 1)
            uid = Z["uid_" + nm]
            chk("uid_%s_shape" % nm, uid.shape, (n_tok,))
            chk("uid_%s_unique" % nm, len(np.unique(uid)), exp_unique)

    # C3/C5 決定の独立再構成検算
    for prefix in ("shift102", "shift181"):
        for s in range(min(2, S)):  # 最初の2つを検査
            nm = "%s_s%02d" % (prefix, s + 1)
            uid = Z["uid_" + nm]
            c_ind, p_ind = decision_indep(c8, c7, uid, int(uid.max()) + 1)
            chk("cut_match_%s" % nm, int((c_ind == Z["cut_" + nm]).all()), 1)
            chk("prot_match_%s" % nm, int((p_ind == Z["prot_" + nm]).all()), 1)
            chk("conflict_%s" % nm, int((c_ind == p_ind).sum()), 0)

    # C6
    gr = float((u7 - Z["nll_sent_random"]).mean())
    go = float((u7 - Z["nll_tok12240"]).mean())
    chk("C6_random_gain", gr, J["calib"]["C6"]["random_gain"])
    chk("C6_oracle_gain", go, J["calib"]["C6"]["oracle_gain"])
    chk("C6_random_le_oracle", bool(gr <= go), J["calib"]["C6"]["random_le_oracle"])

    # C7
    chk("C7_sd_draw_102", float(g102.std(ddof=1)), J["calib"]["C7"]["sd_draw_102"])
    chk("C7_sd_draw_181", float(g181.std(ddof=1)), J["calib"]["C7"]["sd_draw_181"])

    print(f"Step 4 verify: {len(ITEMS)} items checked, {len(MISMATCH)} mismatches.")
    if MISMATCH:
        print("MISMATCHES:")
        for name, got, exp in MISMATCH[:10]:
            print(f"  {name}: got {got}, exp {exp}")
        sys.exit(1)
    else:
        print("ALL CHECKS PASSED (0 mismatches).")


if __name__ == "__main__":
    main()
