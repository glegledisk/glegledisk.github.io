# -*- coding: utf-8 -*-
"""p6i_position_mechanism.py — 質量効果がなぜ位置依存なのかを測る

P6d の推定: 「後半の層を削ると、質量欠落が最終 logits に直接伝わる。
前半で失った質量は後続 8 層の変換で減衰する」。
しかし P6d の測定では、前半だけ削っても後半の質量も同じだけ失われていた
（f6b8: 前半 0.0260 / 後半 0.0260）。質量の**量**では 9 倍の差を説明できない。

そこで「量」ではなく「隠れ状態の乖離」を測る:
  hdev[l] = ||h_l(cond) - h_l(base)|| / ||h_l(base)||    層 l の出力での相対乖離
  logit_std = 語彙方向の logits の標準偏差（先鋭化の尺度）
  logZ      = logsumexp（分配関数の対数）

予測:
  (a) 減衰説が正しければ、f6b8 の hdev は前半で大きく後半で小さい。
      f8b6 の hdev は後半で大きいまま。
  (b) 先鋭化説が正しければ、logit_std の増加が p_top1 の増加と対応する。

出力: p6i_position.npz / p6i_out_utf8.txt

実行:
  python p6i_position_mechanism.py --gpu-gib 7.5 --cpu-gib 12.0
"""

import argparse
import os
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


CONDS = [
    ("base", None, False),
    ("f6b8", "0-7:6,8-15:8", False),
    ("f6b8_rs", "0-7:6,8-15:8", True),
    ("f8b6", "0-7:8,8-15:6", False),
    ("f8b6_rs", "0-7:8,8-15:6", True),
]


def parse_alloc(spec, n_layers, full_k):
    ks = [full_k] * n_layers
    if not spec:
        return ks
    for part in spec.split(","):
        rng, k = part.split(":")
        k = int(k)
        if rng.strip() == "all":
            idx = range(n_layers)
        elif "-" in rng:
            a, b = rng.split("-")
            idx = range(int(a), int(b) + 1)
        else:
            idx = [int(rng)]
        for i in idx:
            ks[i] = k
    return ks


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--ids", type=str, default=os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"))
    ap.add_argument("--gpu-gib", type=float, default=7.5)
    ap.add_argument("--cpu-gib", type=float, default=12.0)
    ap.add_argument("--max-windows", type=int, default=0, help="スモーク用（0=全部）")
    args = ap.parse_args()

    import torch
    from transformers import AutoModelForCausalLM

    log("[1/3] loading %s" % args.model)
    t0 = time.time()
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      loaded in %.0f s" % (time.time() - t0))

    n_layers = int(model.config.num_hidden_layers)
    FULL_K = int(model.config.num_experts_per_tok)
    gates = [layer.mlp.gate for layer in model.model.layers]
    ORIG = [g.forward for g in gates]

    def make_rescaled(orig, full_k):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            if scores.shape[-1] < full_k:
                probs = torch.softmax(logits.float(), dim=-1)
                m_full = torch.topk(probs, full_k, dim=-1).values.sum(-1, keepdim=True)
                m_now = scores.float().sum(-1, keepdim=True).clamp_min(1e-9)
                scores = (scores.float() * (m_full / m_now)).to(scores.dtype)
            return logits, scores, idx
        return _patched

    # 層出力と最終正規化後の隠れ状態を拾う
    hs = []
    h_final = []

    def mk_layer_hook():
        def hook(module, inp, out):
            h = out[0] if isinstance(out, tuple) else out
            hs.append(h.detach().float().cpu())
        return hook

    def mk_norm_hook():
        def hook(module, inp, out):
            h_final.append(out.detach().float().cpu())
        return hook

    handles = [layer.register_forward_hook(mk_layer_hook()) for layer in model.model.layers]
    HAS_NORM = hasattr(model.model, "norm")
    if HAS_NORM:
        handles.append(model.model.norm.register_forward_hook(mk_norm_hook()))
    else:
        log("      WARNING: model.model.norm が見つからない。最終正規化の乖離は測らない")

    z = np.load(args.ids, allow_pickle=True)
    seqs = []
    for lang in ("en", "ja"):
        ids = torch.from_numpy(z["%s_ids" % lang].astype(np.int64))
        for w in range(ids.numel() // 256):
            seqs.append((lang, ids[w * 256:(w + 1) * 256]))
    if args.max_windows:
        seqs = seqs[:args.max_windows]
    log("[2/3] frozen corpus: %d windows x 256" % len(seqs))

    # 集計バッファ
    keys = ["nll", "ptop1", "top1", "logit_std", "logZ", "hnorm_last"]
    buf = {c: {k: [] for k in keys} for c, _, _ in CONDS}
    hdev = {c: [[] for _ in range(n_layers)] for c, _, _ in CONDS if c != "base"}
    hnorm = {c: [[] for _ in range(n_layers)] for c, _, _ in CONDS}
    fdev = {c: [] for c, _, _ in CONDS if c != "base"}

    log("[3/3] forward (window-major: base を先に走らせて乖離を計算)")
    t1 = time.time()
    with torch.no_grad():
        for wi, (lang, ids) in enumerate(seqs):
            x = ids.unsqueeze(0).to(model.device)
            base_h = None
            base_norm = None
            for name, spec, rescale in CONDS:
                ks = parse_alloc(spec, n_layers, FULL_K)
                for i, g in enumerate(gates):
                    g.top_k = ks[i]
                    g.forward = make_rescaled(ORIG[i], FULL_K) if rescale else ORIG[i]
                hs.clear()
                h_final.clear()
                out = model(input_ids=x, use_cache=False)
                lg = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                logZ = torch.logsumexp(lg, dim=-1)
                true_l = lg.gather(1, tgt.unsqueeze(-1)).squeeze(-1)
                rank = (lg > true_l.unsqueeze(-1)).sum(dim=-1) + 1
                top1_l, _ = lg.max(dim=-1)
                buf[name]["nll"].append((logZ - true_l).cpu().numpy())
                buf[name]["ptop1"].append(torch.exp(top1_l - logZ).cpu().numpy())
                buf[name]["top1"].append((rank == 1).float().cpu().numpy())
                buf[name]["logit_std"].append(lg.std(dim=-1).cpu().numpy())
                buf[name]["logZ"].append(logZ.cpu().numpy())
                # 層出力（t=1..L の予測位置に対応させるため末尾を落とす）
                H = [h[0, :-1] for h in hs]          # each (L-1, d)
                N = h_final[0][0, :-1] if HAS_NORM else None
                buf[name]["hnorm_last"].append(
                    (N if HAS_NORM else H[-1]).norm(dim=-1).cpu().numpy())
                for l in range(n_layers):
                    hnorm[name][l].append(H[l].norm(dim=-1).cpu().numpy())
                if name == "base":
                    base_h = [h.clone() for h in H]
                    base_norm = N.clone() if HAS_NORM else None
                else:
                    for l in range(n_layers):
                        num = (H[l] - base_h[l]).norm(dim=-1)
                        den = base_h[l].norm(dim=-1).clamp_min(1e-6)
                        hdev[name][l].append((num / den).cpu().numpy())
                    if HAS_NORM:
                        num = (N - base_norm).norm(dim=-1)
                        den = base_norm.norm(dim=-1).clamp_min(1e-6)
                        fdev[name].append((num / den).cpu().numpy())
                del out, lg, logZ, true_l, rank, H, N
                torch.cuda.empty_cache()
            if wi % 8 == 0:
                log("      window %2d/%d  (%.0f s)" % (wi + 1, len(seqs), time.time() - t1))

    for h in handles:
        h.remove()

    out = {"lang": np.array([s[0] for s in seqs])}
    for c in buf:
        for k in keys:
            out["%s_%s" % (c, k)] = np.concatenate(buf[c][k])
        for l in range(n_layers):
            out["%s_hnorm_l%d" % (c, l)] = np.concatenate(hnorm[c][l])
        if c != "base":
            for l in range(n_layers):
                out["%s_hdev_l%d" % (c, l)] = np.concatenate(hdev[c][l])
            if HAS_NORM and fdev[c]:
                out["%s_fdev" % c] = np.concatenate(fdev[c])
    np.savez_compressed(os.path.join(HERE, "p6i_position.npz"), **out)
    with open(os.path.join(HERE, "p6i_out_utf8.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(LOG))
    log("saved p6i_position.npz")
    import sys
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
