# -*- coding: utf-8 -*-
"""P17: 「答えが出たか」ベースの除去規則を設計するための再生成（全文保存）

P16 は末尾 60 文字しか保存していないため、テキストマーカー（\\boxed / "final answer" /
文末の閉じ方）を使う規則を後から評価できない。P16 と**同一 seed・同一問題・同一順序**で
add5 と mul2 を再生成し、**全文**を保存する。

再現性の担保:
  P16 は (round, level) ブロックの先頭で torch.manual_seed(seed+100+r_i) を打ち、
  さらに level ごとに打ち直す。したがって sub5 を飛ばしても add5 / mul2 の乱数状態は
  変わらない。生成が bit 同一なら pred 列が P16 と完全一致する → それを assert する。

出力: p17_runs.jsonl（全文つき）/ p17_meta.json
"""

import argparse
import json
import os
import random

import numpy as np
import torch

from p14_bestofn import score_sample, extract_value   # 計器を共有

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "qwen3-0.6b")
SYS = "You are a careful arithmetic assistant. Solve the problem and give the final answer."
ALL_LEVELS = ["add5", "sub5", "mul2"]      # 問題生成の RNG 消費順を P16 と揃えるため全部作る
RUN_LEVELS = ["add5", "mul2"]              # 実際に生成するのは 2 水準


def log(m):
    print(m, flush=True)


def make(level, n, rnd):
    out = []
    for _ in range(n):
        if level == "add5":
            a, b = rnd.randint(10001, 99999), rnd.randint(10001, 99999)
            out.append({"q": "Compute %d + %d." % (a, b), "gold": str(a + b)})
        elif level == "sub5":
            a, b = rnd.randint(50001, 99999), rnd.randint(10001, 49999)
            out.append({"q": "Compute %d - %d." % (a, b), "gold": str(a - b)})
        elif level == "mul2":
            a, b = rnd.randint(11, 99), rnd.randint(11, 99)
            out.append({"q": "Compute %d * %d." % (a, b), "gold": str(a * b)})
        else:
            raise ValueError(level)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_prob", type=int, default=20)
    ap.add_argument("--n_samp", type=int, default=8)
    ap.add_argument("--rounds", type=int, default=2)
    ap.add_argument("--seed", type=int, default=41)       # P16 と同じ
    ap.add_argument("--tag", type=str, default="p17")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer
    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    eos_id = tok.eos_token_id
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, torch_dtype=torch.bfloat16, device_map="cuda",
        attn_implementation="sdpa").eval()

    rnd = random.Random(args.seed)
    probs = {lv: make(lv, args.n_prob, rnd) for lv in ALL_LEVELS}
    prompts, prompt_ids = {}, {}
    for lv in RUN_LEVELS:
        prompts[lv] = [tok.apply_chat_template(
            [{"role": "system", "content": SYS}, {"role": "user", "content": p["q"]}],
            tokenize=False, add_generation_prompt=True, enable_thinking=False)
            for p in probs[lv]]
        prompt_ids[lv] = [tok(pr, add_special_tokens=False)["input_ids"]
                          for pr in prompts[lv]]

    recs = []
    for r_i in range(args.rounds):
        for lv in RUN_LEVELS:
            torch.manual_seed(args.seed + 100 + r_i)
            for i, p in enumerate(probs[lv]):
                enc = tok([prompts[lv][i]] * args.n_samp, return_tensors="pt",
                          padding=True, add_special_tokens=False).to(model.device)
                with torch.no_grad():
                    o = model.generate(**enc, max_new_tokens=96, do_sample=True,
                                       temperature=0.9, top_p=0.95,
                                       pad_token_id=tok.pad_token_id)
                gen = o[:, enc["input_ids"].shape[1]:]
                samples = []
                for j in range(args.n_samp):
                    ids = [t for t in gen[j].tolist() if t != tok.pad_token_id]
                    txt = tok.decode(ids, skip_special_tokens=True)
                    try:
                        sc = score_sample(model, tok, prompt_ids[lv][i], txt, eos_id,
                                          ids_gen=ids)
                    except Exception as e:                       # noqa: BLE001
                        sc = {"p_ans": None, "p_full": None, "n_ans": 0,
                              "err": str(e)[:120], "retok": None}
                    pred = extract_value(txt)
                    samples.append({
                        "pred": pred,
                        "correct": None if pred is None else (pred == p["gold"]),
                        "p_ans": sc["p_ans"], "p_full": sc["p_full"],
                        "n_ans": sc["n_ans"], "err": sc["err"], "retok": sc["retok"],
                        "ntok": len(ids), "text": txt})
                recs.append({"round": r_i, "level": lv, "q": p["q"],
                             "gold": p["gold"], "samples": samples})
            log("round %d / %s done" % (r_i, lv))

    # ---- 再現性の検査: P16 の pred 列と完全一致するか ----
    p16_path = os.path.join(HERE, "p16_difficulty.jsonl")
    det = {"compared": 0, "identical": 0, "note": ""}
    if os.path.exists(p16_path):
        p16 = {}
        with open(p16_path, encoding="utf-8") as fp:
            for line in fp:
                r = json.loads(line)
                if r.get("round") == "greedy":
                    continue
                p16[(r["round"], r["level"], r["q"])] = [s["pred"] for s in r["samples"]]
        same = 0
        for r in recs:
            k = (r["round"], r["level"], r["q"])
            if k in p16 and [s["pred"] for s in r["samples"]] == p16[k]:
                same += 1
        det = {"compared": len(recs), "identical": same,
               "note": "pred 列の完全一致（bit 同一の代理）"}
        log("determinism vs P16: %d/%d records identical" % (same, len(recs)))
        assert same == len(recs), "regeneration diverged from P16 — 規則の A/B が崩れる"

    meta = {"n_prob": args.n_prob, "levels": RUN_LEVELS, "n_samp": args.n_samp,
            "rounds": args.rounds, "seed": args.seed, "max_new_tokens": 96,
            "n_recs": len(recs), "n_samples": len(recs) * args.n_samp,
            "determinism": det,
            "note": "full text saved (P16 saved only the last 60 chars)",
            "model": MODEL}
    with open(os.path.join(HERE, "%s_runs.jsonl" % args.tag), "w", encoding="utf-8") as fp:
        for r in recs:
            fp.write(json.dumps(r, ensure_ascii=False) + "\n")
    with open(os.path.join(HERE, "%s_meta.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(meta, fp, ensure_ascii=False, indent=2)
    log(json.dumps(meta, ensure_ascii=False))
    os._exit(0)


if __name__ == "__main__":
    main()
