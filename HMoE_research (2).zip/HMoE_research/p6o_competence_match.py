# -*- coding: utf-8 -*-
"""p6o_competence_match.py — en/ja 差は「能力差（英語偏重）」で説明できるか（GPU 不要）

仮説: OLMoE は英語偏重なので ja では能力が低い。能力が低いと質量欠落の効果が出ない。
  → 能力を揃えれば en と ja の効果は一致するはず。

検証: baseline NLL（および p_top1）で en/ja をマッチングし、共通支持上で Δgap を比較する。
  - マッチ後も差が残る → 能力差では説明できない
  - マッチ後は差が消える → 能力差で説明できる

Δgap = gap(f6b8) - gap(f8b6)。負 = 後半削りの方が較正を悪化させる。
"""
import json
import math

import numpy as np

LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


def ttest(a, b=None):
    a = np.asarray(a, float)
    if b is not None:
        a = a - np.asarray(b, float)
    se = a.std(ddof=1) / math.sqrt(a.size)
    return float(a.mean()), float(a.std(ddof=1) / math.sqrt(a.size)), \
        float(a.mean() / se) if se > 0 else float("nan")


z = np.load("p6c_layer_cal.npz", allow_pickle=True)
tl = np.repeat(z["lang"], z["base_nll"].size // z["lang"].size)
gap6 = z["f6b8_ptop1"].astype(float) - z["f6b8_top1"].astype(float)
gap8 = z["f8b6_ptop1"].astype(float) - z["f8b6_top1"].astype(float)
dg = gap6 - gap8
nll = z["base_nll"].astype(float)
p1 = z["base_ptop1"].astype(float)
gap0 = z["base_ptop1"].astype(float) - z["base_top1"].astype(float)
OUT = {}

log("=== 0. 能力の水準 ===")
log("%-4s %8s %8s %10s %10s %10s" % ("lang", "n", "meanNLL", "medianNLL", "mean p1", "base gap(pt)"))
for u in ("en", "ja"):
    s = tl == u
    log("%-4s %8d %8.3f %10.3f %10.4f %+10.2f"
        % (u, s.sum(), nll[s].mean(), np.median(nll[s]), p1[s].mean(), 100 * gap0[s].mean()))
OUT["levels"] = {u: dict(n=int((tl == u).sum()), nll=float(nll[tl == u].mean()),
                         p1=float(p1[tl == u].mean()), gap0=float(100 * gap0[tl == u].mean()))
                 for u in ("en", "ja")}

log("")
log("=== 1. マッチング前 ===")
for u in ("en", "ja"):
    m, se, t = ttest(dg[tl == u])
    log("  %-4s Δgap = %+7.3f pt (se %.3f, t=%+.2f, n=%d)" % (u, 100 * m, 100 * se, t, (tl == u).sum()))
m0, _, t0 = ttest(dg[tl == "en"], dg[tl == "ja"])
log("  en − ja = %+7.3f pt (t=%+.2f)" % (100 * m0, t0))
OUT["unmatched"] = dict(diff=float(100 * m0), t=float(t0))


def match_analysis(x, name, nbins=10):
    """共通支持の上でビン別に en/ja を比べ、重み付きで集約する。"""
    e, j = x[tl == "en"], x[tl == "ja"]
    lo = max(np.percentile(e, 5), np.percentile(j, 5))
    hi = min(np.percentile(e, 95), np.percentile(j, 95))
    log("")
    log("=== 2. %s でマッチング（共通支持 [%.3f, %.3f]） ===" % (name, lo, hi))
    log("%-12s %6s %10s %6s %10s %10s" % ("bin", "n_en", "Δgap en", "n_ja", "Δgap ja", "差"))
    edges = np.linspace(lo, hi, nbins + 1)
    rows, wsum, dsum = [], 0.0, 0.0
    for i in range(nbins):
        me = (tl == "en") & (x >= edges[i]) & (x <= edges[i + 1])
        mj = (tl == "ja") & (x >= edges[i]) & (x <= edges[i + 1])
        if me.sum() < 30 or mj.sum() < 30:
            continue
        a, b = dg[me].mean(), dg[mj].mean()
        w = min(me.sum(), mj.sum())
        wsum += w
        dsum += w * (a - b)
        rows.append(dict(lo=float(edges[i]), hi=float(edges[i + 1]), n_en=int(me.sum()),
                         n_ja=int(mj.sum()), en=float(100 * a), ja=float(100 * b),
                         diff=float(100 * (a - b))))
        log("%.2f-%.2f %6d %+10.2f %6d %+10.2f %+10.2f"
            % (edges[i], edges[i + 1], me.sum(), 100 * a, mj.sum(), 100 * b, 100 * (a - b)))
    est = dsum / wsum if wsum else float("nan")
    log("  → 重み付き en − ja = %+7.3f pt（%d ビン, 有効重み %.0f）" % (100 * est, len(rows), wsum))
    OUT["match_%s" % name] = dict(est=float(est), bins=rows, lo=float(lo), hi=float(hi))
    return est


e_nll = match_analysis(nll, "NLL")
e_p1 = match_analysis(p1, "p_top1")

log("")
log("=== 3. 能力の傾き（言語内で NLL が上がると効果は強くなるか） ===")
for u in ("en", "ja"):
    s = tl == u
    q = np.percentile(nll[s], [20, 40, 60, 80])
    grp = np.digitize(nll[s], q)
    vals = [100 * dg[s][grp == i].mean() for i in range(5)]
    ns = [int((grp == i).sum()) for i in range(5)]
    log("  %-4s 五分位 Δgap: %s" % (u, " ".join("%+.2f" % v for v in vals)))
    log("       n: %s" % ns)
    OUT.setdefault("quintile", {})[u] = [float(v) for v in vals]

log("")
log("=== 5. 能力の代理指標を言語別に（logit のスケール） ===")
try:
    q = np.load("p6i_position.npz", allow_pickle=True)
    tlq = np.repeat(q["lang"], q["base_logit_std"].size // q["lang"].size)
    log("%-4s %12s %12s %12s" % ("lang", "logit_std", "logZ", "p_top1"))
    for u in ("en", "ja"):
        s = tlq == u
        log("%-4s %12.4f %12.3f %12.4f"
            % (u, q["base_logit_std"][s].mean(), q["base_logZ"][s].mean(),
               q["base_ptop1"][s].mean()))
        OUT.setdefault("scale", {})[u] = dict(std=float(q["base_logit_std"][s].mean()),
                                              logZ=float(q["base_logZ"][s].mean()))
except Exception as e:
    log("  (p6i_position.npz が読めない: %s)" % e)

log("")
log("=== 4. 判定 ===")
log("  マッチ前の差: %+.3f pt" % (100 * m0))
log("  NLL マッチ後: %+.3f pt" % (100 * e_nll))
log("  p_top1 マッチ後: %+.3f pt" % (100 * e_p1))
for name, e in (("NLL", e_nll), ("p_top1", e_p1)):
    ratio = e / m0 if m0 != 0 else float("nan")
    log("  %s マッチで差は %.0f%% 残る" % (name, 100 * ratio))
OUT["verdict"] = dict(unmatched=float(100 * m0), matched_nll=float(100 * e_nll),
                      matched_p1=float(100 * e_p1))

with open("p6o_analysis.json", "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=2)
with open("p6o_out_utf8.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(LOG))
