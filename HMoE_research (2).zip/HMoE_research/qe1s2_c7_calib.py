# -*- coding: utf-8 -*-
"""QE1S2 Step 1: 生成則 v2 の C1 / C2 / C3 / C7 校正.

設計書: `QE1S2課題設計書_初期型を系列一様にしてaの境界効果を除き3検定を収束後に走らせる_20261114.md`
        §1（生成則 v2）/ §6（校正）/ §9（Step 1）

本次の範囲
  - `qe1_make_task.py` に `init_type="zero"|"uniform"` を追加（後方互換・別 RNG ストリーム）。
  - 生成則 v1 / v2 を作り、C1 / C2 / C3 / C7 を実測する。
  - **学習・GPU・3 検定の本番は一切走らせない**（numpy のみ）。

走行前に固定した観測統計量と閾値（設計書 §6 を数値化）
  C1 v1 の全配列と Step 1 `qe1_s1_arrays.npz` の maxdiff            = 0
      v2 の `type_draw` / `tokens` / `is_syntax` / `ident_rank` / `base`  = 0
  C2 `eta2_type_pos` / `mi_type_pos_norm`                        < 1e-3
  C3 `eta2_edit_given_pos` / `mi_edit_norm`                       > 5e-2 / > 1e-1
  C6 全出力の非有限値                                              = 0
  C7 `eta2_a_pos` / `mi_a_pos_norm`                               < 1e-3（新規・本命）

C7 の定義: `eta2_a_pos` は one-hot(実効則 `a`) の位置ビン間分散比、
`mi_a_pos_norm = I(pos_bin; a)/H(a)`。Step 1 では探索的記録だった
`exploratory_eta2_a_pos = 0.001906354` が `ε_pos = 0.001` を超過していた。

出力: qe1s2_s1_metrics.json / qe1s2_s1_arrays.npz / qe1s2_s1.log（すべて UTF-8）
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
import qe1_make_task as Q  # noqa: E402

TAG = "qe1s2_s1"
EPS_POS = Q.EPS_POS                 # 1e-3（C2 を継承、C7 も同じ値を流用）
EPS_EDIT = Q.EPS_EDIT               # 5e-2
EPS_EDIT_MI = Q.EPS_EDIT_MI         # 1e-1
EPS_C7 = 1.0e-3
POS_BINS = Q.POS_BINS
N_TYPES = Q.N_TYPES

C1_FIELDS = ("type_draw", "tokens", "is_syntax", "ident_rank", "base")
ALL_FIELDS = ("type_draw", "a", "pos_bin", "copy_mask", "changed",
              "next_tok", "base", "ident_rank", "is_syntax", "tokens")


def maxdiff(a, b):
    a = np.asarray(a)
    b = np.asarray(b)
    if a.shape != b.shape:
        return float("inf")
    return int(np.max(np.abs(a.astype(np.int64) - b.astype(np.int64)))) if a.size else 0


def c7_stats(c: Q.QE1Corpus, pb: np.ndarray) -> dict:
    """C7 の 2 観測統計量（設計書 §6 の定義どおり）。"""
    e2 = Q.eta2_categorical(c.a, pb, POS_BINS, N_TYPES)
    t = Q.joint_table(pb, c.a, POS_BINS, N_TYPES)
    mi = Q.mi_over_entropy(t)
    return {
        "eta2_a_pos": float(e2),
        "mi_a_pos_norm": float(mi),
        "pass": bool(e2 < EPS_C7 and mi < EPS_C7),
    }


def corpus_arrays(c: Q.QE1Corpus, pb: np.ndarray) -> dict:
    return {
        "type_draw": c.type_draw, "a": c.a, "pos_bin": pb.astype(np.int8),
        "copy_mask": c.copy_mask, "changed": c.changed,
        "next_tok": c.next_tok.astype(np.int16), "base": c.base,
        "ident_rank": c.ident_rank.astype(np.int16), "is_syntax": c.is_syntax,
        "tokens": c.tokens.astype(np.int16),
    }


def negative_control() -> dict:
    """Step 1 と同じ手順で既存 `make_corpus` に同じ C3 統計量を適用する。"""
    from corpus_common import make_corpus  # noqa: E402
    old = make_corpus(Q.CALIB_SEED, Q.N_CALIB_SEQ, base=Q.TRAIN_SEED_BASE)
    ctr = Q.QE1Corpus(
        tokens=old.tokens, types=old.types, next_tok=old.next_tok,
        copy_mask=old.copy_mask, is_syntax=old.is_syntax,
        ident_rank=old.ident_rank, pos_corr=old.pos_corr,
        type_draw=old.types.astype(np.int8), a=old.types.astype(np.int8),
        changed=(old.next_tok != old.tokens).astype(bool),
        base=old.tokens.astype(np.int16),
    )
    return Q.calibrate(ctr, "corpus_common_make_corpus")


def main():
    s1 = np.load(HERE / "qe1_s1_arrays.npz")
    j1 = json.loads((HERE / "qe1_s1_metrics.json").read_text(encoding="utf-8"))

    v1 = Q.make_task(Q.CALIB_SEED, Q.N_CALIB_SEQ, base=Q.TRAIN_SEED_BASE,
                     freq="zipf", init_type="zero")
    v2 = Q.make_task(Q.CALIB_SEED, Q.N_CALIB_SEQ, base=Q.TRAIN_SEED_BASE,
                     freq="zipf", init_type="uniform")
    shape = v2.tokens.shape
    pb = Q.pos_bins(shape)
    a1, a2 = corpus_arrays(v1, pb), corpus_arrays(v2, pb)

    out = {
        "tag": TAG,
        "phase": "QE1S2 Step 1 (generation rule v2 + C1/C2/C3/C7 calibration)",
        "design": "QE1S2課題設計書_初期型を系列一様にしてaの境界効果を除き3検定を収束後に走らせる_20261114.md",
        "no_training": True, "no_gpu": True, "no_3tests": True,
    }
    out["prereg"] = {
        "INIT_SEED_BASE": Q.INIT_SEED_BASE,
        "CALIB_SEED": Q.CALIB_SEED, "N_CALIB_SEQ": Q.N_CALIB_SEQ,
        "TRAIN_SEED_BASE": Q.TRAIN_SEED_BASE, "SEQ_LEN": Q.SEQ_LEN,
        "POS_BINS": POS_BINS, "N_TYPES": N_TYPES,
        "EPS_POS": EPS_POS, "EPS_EDIT": EPS_EDIT, "EPS_EDIT_MI": EPS_EDIT_MI,
        "EPS_C7": EPS_C7,
        "definitions": {
            "C7_eta2_a_pos": "one-hot(a) の位置ビン間分散 / 全分散",
            "C7_mi_a_pos_norm": "I(pos_bin; a) / H(a)",
            "C3_eta2_edit_given_pos": "R2(copy_mask ~ pos_bin x a) - R2(copy_mask ~ pos_bin)",
        },
        "thresholds": {
            "C1": "v1 all fields == Step1 npz (maxdiff 0); v2 type_draw/tokens/is_syntax/ident_rank/base == Step1 (maxdiff 0)",
            "C2": "eta2_type_pos < EPS_POS and mi_type_pos_norm < EPS_POS",
            "C3": "eta2_edit_given_pos > EPS_EDIT and mi_edit_norm > EPS_EDIT_MI",
            "C7": "eta2_a_pos < EPS_C7 and mi_a_pos_norm < EPS_C7",
            "C6": "nonfinite == 0",
        },
        "note": "閾値は QE1S2 設計書 §6 の走行前固定値をそのまま数値化した。結果を見て変更しない。",
    }

    # ---- C1: 実装が Step 1 を壊していないか＋ v2 が不変と宣言した配列を動かしていないか
    c1_v1 = {k: maxdiff(a1[k], s1[k]) for k in ALL_FIELDS}
    c1_v2 = {k: maxdiff(a2[k], s1[k]) for k in C1_FIELDS}
    out["C1"] = {
        "v1_vs_step1": c1_v1,
        "v1_all_zero": bool(all(v == 0 for v in c1_v1.values())),
        "v2_unchanged_fields_vs_step1": c1_v2,
        "v2_unchanged_all_zero": bool(all(v == 0 for v in c1_v2.values())),
        "pass": bool(all(v == 0 for v in c1_v1.values())
                     and all(v == 0 for v in c1_v2.values())),
    }

    # ---- 変更量の定量化（設計書 §1 の「next_tok / copy_mask は不変」が誤りだったことの記録）
    boundary = (np.maximum.accumulate(
        np.where(v2.is_syntax,
                 np.broadcast_to(np.arange(Q.SEQ_LEN, dtype=np.int64), shape), -1),
        axis=1) < 0)
    diff = {
        "a": int((a1["a"] != a2["a"]).sum()),
        "next_tok": int((a1["next_tok"] != a2["next_tok"]).sum()),
        "copy_mask": int((a1["copy_mask"] != a2["copy_mask"]).sum()),
        "changed": int((a1["changed"] != a2["changed"]).sum()),
    }
    out["change_quantification"] = {
        "n_tokens": int(np.prod(shape)),
        "n_boundary_tokens": int(boundary.sum()),
        "boundary_frac": float(boundary.mean()),
        "n_diff": diff,
        "diff_frac": {k: v / int(np.prod(shape)) for k, v in diff.items()},
        "a_hist_boundary_v1": np.bincount(np.asarray(a1["a"])[boundary],
                                          minlength=N_TYPES).tolist(),
        "a_hist_boundary_v2": np.bincount(np.asarray(a2["a"])[boundary],
                                          minlength=N_TYPES).tolist(),
        "note": (
            "a は cue 未観測位置だけで変わるが、next_tok / copy_mask / changed は a の関数"
            "なので連動して変わる。設計書 §1 の『next_tok / copy_mask は一切変更しない』は"
            "誤りであり、本報告書と設計書の ## 追記 で訂正する。C1 の観測統計量 (§6) は"
            "type_draw / tokens / is_syntax の 3 配列なので判定自体は成立する。"
        ),
    }

    # ---- C2 / C3 / C7
    cal1, cal2 = Q.calibrate(v1, "typed_edit_v1_zero"), Q.calibrate(v2, "typed_edit_v2_uniform")
    s1p = j1["primary"]
    out["C2"] = {
        "v1": {"eta2_type_pos": cal1["C2_eta2_type_pos"],
               "mi_type_pos_norm": cal1["C2_mi_type_pos_norm"]},
        "v2": {"eta2_type_pos": cal2["C2_eta2_type_pos"],
               "mi_type_pos_norm": cal2["C2_mi_type_pos_norm"]},
        "step1": {"eta2_type_pos": s1p["C2_eta2_type_pos"],
                  "mi_type_pos_norm": s1p["C2_mi_type_pos_norm"]},
        "v2_vs_step1_maxdiff": max(
            abs(cal2["C2_eta2_type_pos"] - s1p["C2_eta2_type_pos"]),
            abs(cal2["C2_mi_type_pos_norm"] - s1p["C2_mi_type_pos_norm"])),
        "pass": bool(cal2["C2_eta2_type_pos"] < EPS_POS
                     and cal2["C2_mi_type_pos_norm"] < EPS_POS),
    }
    out["C3"] = {
        "v1": {"eta2_edit_given_pos": cal1["C3_eta2_edit_given_pos"],
               "mi_edit_norm": cal1["C3_mi_edit_norm"]},
        "v2": {"eta2_edit_given_pos": cal2["C3_eta2_edit_given_pos"],
               "mi_edit_norm": cal2["C3_mi_edit_norm"],
               "p_changed": cal2["C3_p_changed"]},
        "step1_eta2": s1p["C3_eta2_edit_given_pos"],
        "pass": bool(cal2["C3_eta2_edit_given_pos"] > EPS_EDIT
                     and cal2["C3_mi_edit_norm"] > EPS_EDIT_MI),
        "note": "Step 1 との差は探索的記録。『改善した』とは書かない（別 ID の別 estimand）。",
    }
    c7_v1, c7_v2 = c7_stats(v1, pb), c7_stats(v2, pb)
    out["C7"] = {
        "v1_zero": c7_v1, "v2_uniform": c7_v2,
        "step1_exploratory_eta2_a_pos": s1p["exploratory_eta2_a_pos"],
        "threshold": EPS_C7,
        "reduction_factor": (c7_v1["eta2_a_pos"] / c7_v2["eta2_a_pos"]
                             if c7_v2["eta2_a_pos"] > 0 else float("inf")),
        "pass": bool(c7_v2["pass"]),
    }
    out["calibration_full"] = {"v1": cal1, "v2": cal2}

    # ---- negative control（設計書 §6: Step 1 と同じ統計量で再測）
    nc = negative_control()
    out["negative_control"] = {
        "C3_eta2_edit_given_pos": nc["C3_eta2_edit_given_pos"],
        "C3_mi_edit_norm": nc["C3_mi_edit_norm"],
        "v2_over_control": (cal2["C3_eta2_edit_given_pos"]
                            / nc["C3_eta2_edit_given_pos"]),
        "step1_ratio": (s1p["C3_eta2_edit_given_pos"]
                        / j1["negative_control_existing_corpus"]["C3_eta2_edit_given_pos"]),
    }

    # ---- 判定
    checks = {
        "C1_unchanged": out["C1"]["pass"],
        "C2_position_independence": out["C2"]["pass"],
        "C3_edit_contribution": out["C3"]["pass"],
        "C7_effective_rule_position_independence": bool(c7_v2["pass"]),
    }
    out["checks"] = checks

    def scan(o, path="root"):
        bad = []
        if isinstance(o, dict):
            for k, v in o.items():
                bad += scan(v, f"{path}.{k}")
        elif isinstance(o, list):
            for i, v in enumerate(o):
                bad += scan(v, f"{path}[{i}]")
        elif isinstance(o, float) and not np.isfinite(o):
            bad.append(path)
        return bad
    nf = scan(out)
    checks["C6_all_finite"] = bool(len(nf) == 0)
    out["C6"] = {"nonfinite_paths": nf, "pass": bool(len(nf) == 0)}

    out["verdict"] = "PASS" if all(checks.values()) else "FAIL"
    out["case"] = ("C1 / C2 / C3 / C7 全合格。QE1S2 §5 のケース C は発動せず、"
                   "Step 2 の 3 検定へ進むゲートを通過（本番は未走行）"
                   if out["verdict"] == "PASS" else
                   "QE1S2 §5 ケース C: 課題設計が律速。3 検定は走らせない")

    (HERE / f"{TAG}_metrics.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    np.savez(HERE / f"{TAG}_arrays.npz", **a2)
    lines = [
        f"tag={TAG}", f"verdict={out['verdict']}",
        f"C1_v1_all_zero={out['C1']['v1_all_zero']} C1_v2_unchanged={out['C1']['v2_unchanged_all_zero']}",
        f"C2_v2={cal2['C2_eta2_type_pos']:.8f} (eps {EPS_POS})",
        f"C3_v2={cal2['C3_eta2_edit_given_pos']:.8f} (eps {EPS_EDIT})",
        f"C7_eta2_a_pos v1={c7_v1['eta2_a_pos']:.8f} v2={c7_v2['eta2_a_pos']:.8f} (eps {EPS_C7})",
        f"C7_mi_a_pos v1={c7_v1['mi_a_pos_norm']:.8f} v2={c7_v2['mi_a_pos_norm']:.8f}",
        f"C7_reduction={out['C7']['reduction_factor']:.2f}x",
        f"boundary_tokens={int(boundary.sum())} next_tok_diff={diff['next_tok']}",
        f"negative_control_ratio={out['negative_control']['v2_over_control']:.1f}x",
        f"checks={checks}", f"case={out['case']}", "",
    ]
    (HERE / f"{TAG}.log").write_text("\n".join(lines), encoding="utf-8")
    sys.stdout.write("\n".join(lines))
    sys.stdout.flush()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        sys.stderr.write(f"[qe1s2_c7_calib] ERROR {type(exc).__name__}: {exc}\n")
        sys.stderr.flush()
        raise
