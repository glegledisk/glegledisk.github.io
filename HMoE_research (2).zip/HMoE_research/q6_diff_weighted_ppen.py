#!/usr/bin/env python3
"""Q6: 難度重み付き p_pen — ペナルティが難度を知れば配分は変わるか。

背景: Q5 で「幅の配分は p_pen が作っている」ことを確認した（auxw=0 で符号が逆転、t=−8.70/+6.87）。
Q1–Q4 は「難しくしても payload は小 expert に行く」ことを示したが、これは p_pen が
**難度を知らない**からだった。p_pen = E·Σ f_i·P_i·(dims_i/mean) は使用率と幅の積だけで、
CE 勾配の大きさ（＝難度）を考慮しない。

本実験の問い: **p_pen に難度の重みを掛けたら、配分は変わるか？**
具体的には、難しいトークンの p_pen 寄与を下げる（難しいトークンが幅を買いやすくなる）。

設計: Q2 のハーネスを import。タスクは compute（ADADSDADAS, payload 80%, T=109）。
auxw = 0.05（Q5 で既に飽和する水準）。H+LB、seed 0–5 の 6 本。

3 条件:
  1. base    : 標準の p_pen（E·Σ f_i·P_i·(dims_i/mean)）— Q5 の auxw=0.05 再現
  2. dw_soft : 難度重み付き p_pen — CE(token) が高い→重み↓
               weight_j = 1 / (1 + ce_j / ce_mean)
               → 難しいトークン（CE 高）は重みが < 1 → ペナルティを受けにくい → 幅を買える
  3. dw_hard : weight_j = 0 if ce_j > median(ce) else 1
               → 上位半分（難しい方）のトークンは p_pen から完全に外す

因果性の処理: CE はまだ手に入らない（次の学習ステップの CE は不明）ので、
**前のステップ（直前ミニバッチ）の per-token CE を記憶して**使う。
初回は CE がないので均一重み（= base と同じ）にする。

事前登録:
  P1（操作チェック）: base の結果が Q5 auxw=0.05 と**構造的に一致する**
     （語彙が同じなので、Δ / width / acc がビット一致に近いはず）
  P2（主予測）: dw_soft / dw_hard で **width_payload が広がる**（base より大きい）
     → payload が幅を買えるようになる
  P3: dw_soft / dw_hard で **Δ が下がる**（0 に近づくか負に転じる）
  P4: dw_hard で **acc_payload が改善する**（ペナルティが難しいトークンを邪魔しないので）
  Kill:
     (a) base が Q5 と一致しない → ハーネスのバグ
     (b) dw_soft/hard と base の差が全て n.s. → 難度重みは p_pen の中で消えている
         （因果性の壁がここでも効いている可能性）

解釈の注意: dw は「難度情報を p_pen に入れる」実験だが、因果性の壁（P4 の結論）は
「コストの予測に必要な情報が計算の後ろにしかない」こと。ここでは前ステップの CE を
使うので**1 ステップ遅れた信号**である。効かない場合は「信号が古い」可能性と
「そもそも p_pen 内の重みでは配分が変わらない」可能性の 2 つがある。

出力: simulation_hmoe_mmlu/data/q6/H+LB_compute_{mode}_s{seed}.json / q6_results.json
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import q2_difficulty_ladder as Q2  # noqa: E402
from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS  # noqa: E402
import e2b_rewrite_routing_fixed as E2  # noqa: E402

OUTDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q6")


def usage_entropy(usage):
    """正規化エントロピー（0=1 個に集中, 1=完全一様）。"""
    u = np.asarray(usage, float)
    p = u / max(1.0, u.sum())
    p = p[p > 0]
    if len(p) <= 1:
        return 0.0
    return float(-(p * np.log(p)).sum() / np.log(len(u)))


def p_pen_weighted(model, logits_r, B, T, prev_ce, mode):
    """難度重み付き p_pen を計算する。

    標準の p_pen: E · Σ_i f_i · P_i · (dims_i / mean)
      f_i = top-1 が expert i であるトークンの割合
      P_i = softmax(router_logits) の平均

    weighted 版:
      logits_r: (B*T, E)
      トレース領域 (t >= TRACE0 - 1) のトークンのみ難度重みを考慮し、
      全体 (B*T) に埋め戻すか、またはトレース領域だけで aux を計算する。
      標準実装では B*T 全体で aux が計算される。
      prev_ce はトレース領域 (B, T - TRACE0) の per-token 損失 (B, 100)。
      位置 t のルータは t+1 の予測を担当するので、
      位置 t (TRACE0-1 .. T-2) が prev_ce (0 .. T-TRACE0-1) に対応する。

    Args:
        model: RewriteMoE
        logits_r: (BT, E) — ルータのロジット
        B: バッチサイズ
        T: 系列長 (109)
        prev_ce: (B, T - TRACE0) or None — 前ステップの per-token CE。None なら均一
        mode: "base" / "dw_soft" / "dw_hard"

    Returns:
        aux: スカラー tensor
    """
    BT = logits_r.shape[0]
    E = model.E
    dims = torch.tensor(model.dims, dtype=logits_r.dtype)

    top1 = logits_r.argmax(dim=1)
    P = torch.softmax(logits_r, dim=1).mean(0)

    if mode == "base" or prev_ce is None:
        f = torch.zeros(E, dtype=logits_r.dtype)
        f.scatter_add_(0, top1, torch.ones_like(top1, dtype=logits_r.dtype))
        f = f / BT
        return E * (f * P * (dims / dims.mean())).sum()

    # prev_ce: (B, T - TRACE0) = (B, 100)
    # B*T 各位置に重み w を設定する (既定値 1.0)
    w_mat = torch.ones((B, T), dtype=logits_r.dtype)
    ce = prev_ce.detach().clamp(min=0.0)
    ce_mean = ce.mean().clamp(min=1e-8)

    if mode == "dw_soft":
        # 難しい（CE 高い）→ weight 小 → ペナルティ弱
        # w_tok = 1 / (1 + ce / ce_mean)
        w_trace = 1.0 / (1.0 + ce / ce_mean)
    elif mode == "dw_hard":
        # 上位半分（CE > median）のトークンは weight=0
        med = ce.median()
        w_trace = (ce <= med).float()
    else:
        raise ValueError(f"Unknown mode: {mode}")

    # 位置 t in [TRACE0 - 1, T - 2] が trace 領域の予測を担当
    # w_mat の該当位置に代入
    w_mat[:, Q2.TRACE0 - 1:-1] = w_trace.to(dtype=logits_r.dtype)
    w = w_mat.reshape(-1) # (BT,)

    # w を正規化（平均が 1.0 になるようにスケーリングして元のスケール感を維持）
    w_norm = w / w.mean().clamp(min=1e-8) # (BT,)

    # weighted f_i = (1 / BT) * Σ_{j: top1_j == i} w_norm_j
    f = torch.zeros(E, dtype=logits_r.dtype)
    f.scatter_add_(0, top1, w_norm)
    f = f / BT

    # weighted P_i = (1 / BT) * Σ_j w_norm_j · softmax(logits_r_j)_i
    P_w = (w_norm.unsqueeze(1) * torch.softmax(logits_r, dim=1)).mean(0)

    return E * (f * P_w * (dims / dims.mean())).sum()


def forward_q6(model, idx, aux_mode, prev_ce=None):
    """forward with difficulty-weighted p_pen.

    Returns: logits, aux, per_token_router_logits_last_layer
    """
    p = model.p
    B, T = idx.shape
    import math
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    aux_sum = torch.zeros(())
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)

    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        logits_r = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
        topv, topi = logits_r.topk(model.k, dim=1)
        gate = torch.softmax(
            torch.full_like(logits_r, float("-inf")).scatter(1, topi, topv), dim=1)
        y = torch.zeros_like(h)
        for i in range(model.E):
            tok, _ = (topi == i).nonzero(as_tuple=True)
            if tok.numel() == 0:
                continue
            x = h[tok]
            h1 = F.relu(F.linear(x, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
            y.index_add_(0, tok,
                         F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                         * gate[tok, i].unsqueeze(1))

        # aux: weighted p_pen
        aux = p_pen_weighted(model, logits_r, B, T, prev_ce, aux_mode)
        h = h + y
        aux_sum = aux_sum + aux

    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, -1)
    return out, aux_sum / model.L


def run(arm, task, seed, mode, n_seqs, epochs, bs, lr, auxw):
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    model = RewriteMoE(WIDTHS[arm], seed=seed)
    opt = Adam(model.params(), lr=lr)
    nparam = sum(v.numel() for v in model.params().values())

    steps_per_ep = max(1, n_seqs // bs)
    t0 = time.time()
    hist = []

    # 前ステップの per-token CE を記憶する（因果性の壁の対処）
    prev_ce = None

    for ep in range(epochs):
        run_loss = 0.0
        for _ in range(steps_per_ep):
            seq, _ = Q2.make_trace_batch(rng, bs, task=task)
            x = torch.from_numpy(seq)

            logits, aux = forward_q6(model, x, aux_mode=mode, prev_ce=prev_ce)
            ce_loss = Q2.trace_loss(logits, seq)
            loss = ce_loss + auxw * aux
            loss.backward()
            opt.step(model.params())
            run_loss += float(loss.detach())

            # 次ステップ用の per-token CE を計算（detach して保存）
            # (bs, T - TRACE0) = (bs, 100)
            with torch.no_grad():
                lg = logits[:, Q2.TRACE0 - 1:-1, :len(Q2.VOCAB)]
                tgt = torch.from_numpy(seq[:, Q2.TRACE0:])
                prev_ce = F.cross_entropy(
                    lg.reshape(-1, len(Q2.VOCAB)), tgt.reshape(-1), reduction="none"
                ).reshape(bs, -1).detach()

        hist.append(run_loss / steps_per_ep)
        print(f"    [{arm} {task} {mode} s{seed}] ep{ep+1}/{epochs} "
              f"loss={hist[-1]:.4f} ({time.time()-t0:.0f}s)", flush=True)

    ev_rng = np.random.default_rng(777)
    seq, typ = Q2.make_trace_batch(ev_rng, 1024, task=task)
    conds = {"base": (None, None), "force_small": (None, Q2.SMALL)}
    ev = Q2.evaluate(model, seq, typ, conds)

    # 使用率エントロピー（collapse 検出）
    for c in ("base",):
        ev[c]["usage_entropy"] = usage_entropy(ev[c]["usage_l0"])
        u = np.asarray(ev[c]["usage_l0"], float)
        ev[c]["usage_share_max"] = float(u.max() / max(1.0, u.sum()))

    out = {"arm": arm, "seed": seed, "task": task, "mode": mode, "auxw": auxw,
           "nparam": nparam, "loss_hist": hist, "n_eval": 1024,
           "sec": round(time.time() - t0, 1), "eval": ev}
    os.makedirs(OUTDIR, exist_ok=True)
    torch.save({k: v.detach() for k, v in model.params().items()},
               os.path.join(OUTDIR, f"ckpt_{arm}_{task}_{mode}_s{seed}.pt"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", default="H+LB")
    ap.add_argument("--task", default="compute")
    ap.add_argument("--modes", nargs="+", default=["base", "dw_soft", "dw_hard"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4, 5])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--auxw", type=float, default=0.05)
    ap.add_argument("--resume", action="store_true")
    args = ap.parse_args()

    os.makedirs(OUTDIR, exist_ok=True)
    torch.set_num_threads(6)
    print(f"Q6: task={args.task} modes={args.modes} seeds={args.seeds} "
          f"T={Q2.T_LEN} payload={Q2.N_DIG}/{Q2.TPI}", flush=True)

    rows = []
    for mode in args.modes:
        for seed in args.seeds:
            p = os.path.join(OUTDIR,
                             f"{args.arm}_{args.task}_{mode}_s{seed}.json")
            if args.resume and os.path.exists(p):
                try:
                    with open(p, encoding="utf-8") as f:
                        r = json.load(f)
                    if r.get("n_eval") == 1024:
                        print(f"  [skip] {mode} s{seed}", flush=True)
                        rows.append(r)
                        continue
                except (json.JSONDecodeError, OSError):
                    pass
            r = run(args.arm, args.task, seed, mode,
                    args.seqs, args.epochs, args.bs, args.lr, args.auxw)
            rows.append(r)
            e = r["eval"]["base"]
            print(f"  -> {mode} s{seed}: "
                  f"acc pl = {e['acc_payload']:.4f} "
                  f"small st/pl = {e['small_struct']:.3f}/{e['small_payload']:.3f} "
                  f"(Δ={e['small_payload']-e['small_struct']:+.3f}) "
                  f"wid st/pl = {e['width_struct']:.1f}/{e['width_payload']:.1f} "
                  f"H(usage)={e['usage_entropy']:.3f} "
                  f"maxshare={e['usage_share_max']:.3f}", flush=True)
            with open(p, "w", encoding="utf-8") as f:
                json.dump(r, f, ensure_ascii=False, indent=2)

    with open(os.path.join(OUTDIR, "q6_results.json"), "w",
              encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
    print(f"[write] {OUTDIR}", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
