# -*- coding: utf-8 -*-
"""_fix_cjk_space.py — 行内の「CJK と CJK の間の余計な空白」を除去する。

軟改行の結合（_md_join.py）では消えない、行内の打ち間違い・貼り付け由来の空白が残る。
日本語で漢字・かなの間に空白が入るのは、ほぼ必ず事故なので除去する。

安全策
  - コードフェンス内と表の行（`|` 始まり）は触らない
  - 行頭の字下げ（全角スペース）は触らない（直前が CJK でないので自然に対象外）
  - 除去前後で **構造の指紋**（li/tr/h1..h3/ol/ul）と **強調の残存数** が変わらないことを確認し、
    変わったら差し戻す
"""
import os
import re
import sys

from markdown_it import MarkdownIt

MD = MarkdownIt("commonmark").enable("table")
CJK = r"\u3000-\u30ff\u4e00-\u9fff"
PAT = re.compile(rf"([{CJK}])[ \u3000]+([{CJK}])")


def fingerprint(src):
    html = MD.render(src)
    body = re.sub(r"<pre>.*?</pre>", "", html, flags=re.S)
    body = re.sub(r"<code>.*?</code>", "", body, flags=re.S)
    return (html.count("<li>"), html.count("<tr>"), html.count("<h1>"),
            html.count("<h2>"), html.count("<h3>"), html.count("<ol>"),
            html.count("<ul>"), len(re.findall(r"\*\*", body)))


def count_cjk(src):
    html = MD.render(src)
    return len(re.findall(rf"[{CJK}]\s+[{CJK}]", html))


def fix(src):
    out, in_fence = [], False
    for ln in src.split("\n"):
        if ln.lstrip().startswith("```"):
            in_fence = not in_fence
            out.append(ln)
            continue
        if in_fence:
            out.append(ln)
            continue
        prev = None
        while prev != ln:
            prev = ln
            ln = PAT.sub(r"\1\2", ln)
        out.append(ln)
    return "\n".join(out)


def main():
    apply = "--apply" in sys.argv
    paths = [a for a in sys.argv[1:] if not a.startswith("--")]
    done = reverted = skipped = 0
    for p in paths:
        src = open(p, encoding="utf-8").read()
        if count_cjk(src) == 0:
            skipped += 1
            continue
        new = fix(src)
        ok = fingerprint(new) == fingerprint(src)
        n0, n1 = count_cjk(src), count_cjk(new)
        if not ok:
            reverted += 1
            print(f"  差し戻し {os.path.basename(p)}  ({n0}->{n1})")
            continue
        done += 1
        print(f"  OK {n0:3d}->{n1:3d}  {os.path.basename(p)}")
        if apply and n1 < n0:
            open(p, "w", encoding="utf-8", newline="\n").write(new)
    print(f"\n適用 {done} / 差し戻し {reverted} / 変更不要 {skipped}"
          f"  ({'適用済み' if apply else 'dry-run'})")


if __name__ == "__main__":
    main()
