# -*- coding: utf-8 -*-
"""audit4_20261024.py — 大規模BPB検定の再計算（キャッシュから直接）
報告書の表1（bpt 4.170 / 2.521, tokens 7631/8191/5521/8191）と
JSON（4.139 / 2.671, 7631/8190/5209/8190）のどちらが正しいかを確定する。
"""
import os, math, json
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
out = {}

def load(key):
    d = np.load(os.path.join(HERE, f"cache_{key}.npz"))
    return d["bits"].astype(np.float64), d["bytes"].astype(np.float64)

print("=== 1. キャッシュの素性 ===")
for k in ["qwen3-0.6b_en", "smollm-135m_en", "qwen3-0.6b_ja", "smollm-135m_ja"]:
    b, n = load(k)
    print(" %-18s tokens=%5d  bytes=%6d  bpt=%.4f  bits/tok=%.3f  bpb=%.4f"
          % (k, len(b), int(n.sum()), n.sum()/len(b), b.mean(), b.sum()/n.sum()))

print("\n=== 2. 報告書 表1 の再現テスト ===")
report = {"en": {"qwen_tokens": 7631, "qwen_bpt": 4.170, "smollm_tokens": 8191, "smollm_bpt": 3.856},
          "ja": {"qwen_tokens": 5521, "qwen_bpt": 2.521, "smollm_tokens": 8191, "smollm_bpt": 1.699}}
for lang in ["en", "ja"]:
    for m in ["qwen3-0.6b", "smollm-135m"]:
        b, n = load(f"{m}_{lang}")
        r = report[lang]
        rt = r["qwen_tokens"] if m.startswith("qwen") else r["smollm_tokens"]
        rb = r["qwen_bpt"] if m.startswith("qwen") else r["smollm_bpt"]
        print(" %-3s %-12s 報告: tok=%5d bpt=%.3f | 実測: tok=%5d bpt=%.4f  -> %s"
              % (lang, m, rt, rb, len(b), n.sum()/len(b),
                 "OK" if abs(n.sum()/len(b)-rb) < 0.005 else "不一致"))
        # 報告の bpt から逆算したトークン数
        print("      報告bptから逆算したバイト数 = %.0f / 実際 = %d" % (rt*rb, int(n.sum())))

print("\n=== 3. ペア・ブロック・ブートストラップの再実行（同一手順） ===")
for lang in ["en", "ja"]:
    qb, qn = load(f"qwen3-0.6b_{lang}")
    sb, sn = load(f"smollm-135m_{lang}")
    ev = min(qn.sum(), sn.sum())
    qc, sc = np.cumsum(qn), np.cumsum(sn)
    qi, si = np.searchsorted(qc, ev), np.searchsorted(sc, ev)
    qb, qn, qc = qb[:qi], qn[:qi], qc[:qi]
    sb, sn, sc = sb[:si], sn[:si], sc[:si]
    BB = 500
    nb = int(ev // BB)
    qblk, sblk = [], []
    for k in range(nb):
        a, z = k*BB, (k+1)*BB
        m = (qc >= a) & (qc < z); qblk.append(qb[m].sum() if m.any() else 0.0)
        m = (sc >= a) & (sc < z); sblk.append(sb[m].sum() if m.any() else 0.0)
    qblk, sblk = np.array(qblk), np.array(sblk)
    rng = np.random.default_rng(123)
    tot = nb*BB
    d = []
    for _ in range(5000):
        idx = rng.choice(nb, size=nb, replace=True)
        d.append(sblk[idx].sum()/tot - qblk[idx].sum()/tot)
    d = np.array(d)
    q_bpb = qb.sum()/qn.sum(); s_bpb = sb.sum()/sn.sum()
    print(" %s: eval_bytes=%d blocks=%d | qwen bpb=%.4f smollm bpb=%.4f | Δ=%+.4f CI=[%+.4f,%+.4f] p1=%.4f"
          % (lang, ev, nb, q_bpb, s_bpb, s_bpb-q_bpb,
             np.percentile(d, 2.5), np.percentile(d, 97.5), float((d <= 0).mean())))
    # ブロック数を変えた感度
    for nbb in (100, 250, 1000, 2000):
        nb2 = int(ev // nbb); qb2, sb2 = [], []
        for k in range(nb2):
            a, z = k*nbb, (k+1)*nbb
            m = (qc >= a) & (qc < z); qb2.append(qb[m].sum() if m.any() else 0.0)
            m = (sc >= a) & (sc < z); sb2.append(sb[m].sum() if m.any() else 0.0)
        qb2, sb2 = np.array(qb2), np.array(sb2); t2 = nb2*nbb
        rng = np.random.default_rng(7); dd = []
        for _ in range(3000):
            idx = rng.choice(nb2, size=nb2, replace=True)
            dd.append(sb2[idx].sum()/t2 - qb2[idx].sum()/t2)
        dd = np.array(dd)
        print("     block=%4dB (n=%3d): CI=[%+.4f, %+.4f] width=%.4f"
              % (nbb, nb2, np.percentile(dd, 2.5), np.percentile(dd, 97.5),
                 np.percentile(dd, 97.5)-np.percentile(dd, 2.5)))
    out[lang] = {"eval_bytes": int(ev), "qwen_bpb": float(q_bpb), "smollm_bpb": float(s_bpb),
                 "diff": float(s_bpb-q_bpb), "ci": [float(np.percentile(d,2.5)), float(np.percentile(d,97.5))]}

print("\n=== 4. 感度: bpt はサンプル長でどれだけ動くか（同一ファイル先頭から） ===")
import glob
en_files = sorted(glob.glob(os.path.join(HERE, "english_version", "**", "*.md"), recursive=True))
ja_files = [f for f in sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True)) if "english_version" not in f]
from transformers import AutoTokenizer
for lang, files in [("en", en_files), ("ja", ja_files)]:
    txt = ""
    for f in files:
        txt += open(f, encoding="utf-8").read() + "\n\n"
        if len(txt.encode()) > 120000: break
    for m in ["qwen3-0.6b", "smollm-135m"]:
        tok = AutoTokenizer.from_pretrained(os.path.join(HERE, "models", m), local_files_only=True)
        row = []
        for ntok in (1536, 4096, 8192, 16384):
            ids = tok(txt, add_special_tokens=False)["input_ids"][:ntok]
            row.append("%d:%.3f" % (ntok, len(tok.decode(ids, clean_up_tokenization_spaces=False).encode())/len(ids)))
        print(" %-3s %-12s bpt by length: %s" % (lang, m, "  ".join(row)))

json.dump(out, open(os.path.join(HERE, "audit4_results.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False)
print("\nsaved audit4_results.json")
