# -*- coding: utf-8 -*-
"""P7c 作図: α 代理と実幅の差（測定とは分離）

入力: p7c_width.npz / p7d_width.npz
出力: p7c_width.png
"""

import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

matplotlib.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "MS Gothic", "sans-serif"]
matplotlib.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))
TAGS = ["p7c", "p7d"]
ALPHA_REF = {"all": 0.00327, "front": 0.00019, "back": 0.00145}   # P7
ALPHA_SE = {"all": 0.00121, "front": 0.00105, "back": 0.00078}


def load():
    nll, lang = {}, None
    for tag in TAGS:
        p = os.path.join(HERE, "%s_width.npz" % tag)
        if not os.path.exists(p):
            continue
        z = np.load(p, allow_pickle=True)
        if lang is None:
            lang = z["lang"]
        for k in z.files:
            if k.startswith("nll_"):
                nll.setdefault(k[4:], z[k])
    return nll, lang


def win(nll, a, b, nw):
    per = nll["base"].size // nw
    d = (nll[a] - nll[b]).reshape(nw, per).mean(1).astype(np.float64)
    return d.mean(), d.std(ddof=1) / np.sqrt(d.size)


def main():
    nll, lang = load()
    nw = lang.size

    fig, axes = plt.subplots(1, 2, figsize=(11.6, 4.7))

    # ---- A: α vs 実幅 ----
    ax = axes[0]
    keys = [("all", "全 16 層", "p05"), ("front", "前半 8 層", "p05f"), ("back", "後半 8 層", "p05b")]
    xs = np.arange(len(keys))
    real, real_se = [], []
    for _, _, c in keys:
        m, se = win(nll, c, "split", nw)
        real.append(m)
        real_se.append(se)
    alpha = [ALPHA_REF[k] for k, _, _ in keys]
    alpha_se = [ALPHA_SE[k] for k, _, _ in keys]
    ax.bar(xs - 0.19, alpha, 0.36, yerr=[1.96 * s for s in alpha_se], capsize=4,
           color="#7f8c8d", label="α=0.5（重みの半減）")
    ax.bar(xs + 0.19, real, 0.36, yerr=[1.96 * s for s in real_se], capsize=4,
           color="#c0392b", label="実半幅（ニューロンを刈る）")
    ax.set_xticks(xs)
    ax.set_xticklabels([k[1] for k in keys])
    ax.set_ylabel("ΔCE (nats)")
    ax.set_title("A. α は実幅のコストを過小評価する\n"
                 "全層 3.0 倍 / 前半 19 倍 / 後半 3.1 倍", fontsize=10)
    ax.legend(fontsize=9)
    ax.grid(alpha=0.3, axis="y")
    for x, a, r in zip(xs, alpha, real):
        ax.annotate("%.4f" % a, (x - 0.19, a), textcoords="offset points",
                    xytext=(0, 6), ha="center", fontsize=8, color="#4d5656")
        ax.annotate("%.4f" % r, (x + 0.19, r), textcoords="offset points",
                    xytext=(0, 6), ha="center", fontsize=8, color="#7b241c")

    # ---- B: 予算 16 の対比 ----
    ax = axes[1]
    labs = ["α 版\nh15f − u1（P7）", "実幅版\np15f − p1"]
    vals = [-0.00440, win(nll, "p15f", "p1", nw)[0]]
    ses = [0.00138, win(nll, "p15f", "p1", nw)[1]]
    cols = ["#7f8c8d", "#c0392b"]
    ax.bar([0, 1], vals, yerr=[1.96 * s for s in ses], capsize=6, color=cols, width=0.5)
    ax.axhline(0, color="k", lw=1)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(labs, fontsize=9)
    ax.set_ylabel("ΔCE（半スロット配分 − 均一） nats")
    ax.set_title("B. 実幅では符号が反転する\n"
                 "負 = 半スロット配分が勝ち（95% CI）", fontsize=10)
    ax.grid(alpha=0.3, axis="y")
    for x, v in zip([0, 1], vals):
        ax.annotate("%+.4f" % v, (x, v), textcoords="offset points",
                    xytext=(0, -16 if v > 0 else 10), ha="center", fontsize=9)

    fig.suptitle("P7c: α 代理は幅の代理にならない — OLMoE-1B-7B, n=12,240 tokens / 48 窓", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.92])
    out = os.path.join(HERE, "p7c_width.png")
    fig.savefig(out, dpi=150)
    print("saved: " + out)


if __name__ == "__main__":
    main()
