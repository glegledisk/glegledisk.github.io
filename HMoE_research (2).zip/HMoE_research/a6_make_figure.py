#!/usr/bin/env python3
"""A6 の図。冗長性の予算曲線（横軸 = FFN 幅のうち ReLU² にした割合）。"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "MS Gothic", "sans-serif"]
matplotlib.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a4")
J = json.load(open(os.path.join(D, "a6_budget.json"), encoding="utf-8"))
P = J["points"]

rows = []
for fn in ("a4_results.json", "a4_results_w.json"):
    rows += [r for r in json.load(open(os.path.join(D, fn), encoding="utf-8"))
             if "evals" in r]
base = [r for r in rows if r["arm"] == "all_relu"]
b0 = np.array([r["evals"][-1]["instr_valid"] for r in base])

fig, ax = plt.subplots(figsize=(8.6, 5.2))
main = [p for p in P if p["arm"] not in ("small_relu2",) and p["k"] in (0, 2, 4, 6, 8)]
main = sorted(main, key=lambda x: x["wshare"])
x = [p["wshare"] * 100 for p in main]
y = [p["iv"] for p in main]
lab = [f"k={p['k']}" for p in main]
ax.plot(x, y, "o-", color="#4c72b0", lw=2, ms=9, zorder=3)
for xi, yi, li in zip(x, y, lab):
    dy = 0.035 if li != "k=4" else 0.045
    ax.text(xi, yi + dy, f"{li}\n{yi:.3f}", ha="center", fontsize=8)
ax.axhline(float(b0.mean()), color="black", ls="--", lw=1.2)
ax.text(2, float(b0.mean()) + 0.02, f"ベースライン {b0.mean():.3f}", fontsize=8)
ax.axvspan(0, 75, color="#55a868", alpha=0.10)
ax.text(37, 0.30, "品質が落ちない帯", fontsize=9, ha="center", color="#2f6b45")
ax.annotate("k=4 で +0.202\n(p=0.026, 6/6)", xy=(75, 0.845), xytext=(46, 0.93),
            fontsize=9, arrowprops=dict(arrowstyle="->", color="#c44e52", lw=1.6),
            color="#c44e52")
ax.set_xlabel("FFN 幅のうち ReLU² にした割合（%）")
ax.set_ylabel("instr_valid（6 seed 平均）")
ax.set_title("幅の広い順に k 個を ReLU² にしたときの品質", fontsize=11)
ax.grid(alpha=0.3)
ax.set_ylim(0, 1.02)
ax.set_xlim(-3, 105)

plt.tight_layout()
out = os.path.join(D, "a6_figure.png")
plt.savefig(out, dpi=150)
print(f"[write] {out}")
