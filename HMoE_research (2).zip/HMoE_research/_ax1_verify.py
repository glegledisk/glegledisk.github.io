# -*- coding: utf-8 -*-
"""AX1 Step 4: INDEPENDENT recomputation.

Deliberately does NOT import ax1_axis_estimand.py. Rebuilds every array from the
original npz files, recomputes t/p with scipy.stats.ttest_rel (a different code
path from the manual t in the main script), and compares every number in
ax1_analysis.json / ax1_calib.json / ax1_delta.npz.

Output: _ax1_verify_metrics.json  (0 mismatches required)
"""
import os
import json
import numpy as np
from scipy import stats

ROOT = os.path.dirname(os.path.abspath(__file__))
N = 12240
ALPHA = 0.05
DELTA = 0.01

mismatches = []
checked = 0


def eq(label, got, want, tol=1e-9):
    global checked
    checked += 1
    g, w = float(got), float(want)
    if not np.isfinite(g) and not np.isfinite(w):
        return
    if not np.isfinite(g) or not np.isfinite(w) or abs(g - w) > tol * max(1.0, abs(w)):
        mismatches.append({"item": label, "got": g, "want": w,
                           "absdiff": abs(g - w)})


def load(fn, key):
    return np.asarray(np.load(os.path.join(ROOT, fn), allow_pickle=False)[key],
                      dtype=np.float64).ravel()


E = load("p3_topk_nll.npz", "k8")
U = load("p3_topk_nll.npz", "k7")
C6 = load("p3_topk_nll.npz", "k6")
base = load("p3b_alloc_nll.npz", "base")
u7 = load("p3b_alloc_nll.npz", "u7")
F2 = load("p3b_alloc_nll.npz", "f6b8")
B2 = load("p3b_alloc_nll.npz", "f8b6")
u6 = load("p4_adaptive_nll.npz", "uniform6")
u7p = load("p4_adaptive_nll.npz", "uniform7")
T_o = load("p4_adaptive_nll.npz", "oracle50")
T_p = load("p4_adaptive_nll.npz", "probe50")
T_r = load("p4_adaptive_nll.npz", "random50")
F1 = load("p3c8a_topk_nll.npz", "k7")
B1 = load("p3c8b_topk_nll.npz", "k7")
c8a8 = load("p3c8a_topk_nll.npz", "k8")
c8b8 = load("p3c8b_topk_nll.npz", "k8")
p24b = load("p24_layer_cost.npz", "nll_base")

with open(os.path.join(ROOT, "ax1_analysis.json"), encoding="utf-8") as f:
    A = json.load(f)
with open(os.path.join(ROOT, "ax1_calib.json"), encoding="utf-8") as f:
    C = json.load(f)
D = np.load(os.path.join(ROOT, "ax1_delta.npz"), allow_pickle=False)
S = A["statistics"]

# --- C1..C3, recomputed from raw files ------------------------------------
eq("C1.base_maxdiff", np.max(np.abs(E - base)), 0.0, 0.0)
eq("C1.c8a_k8_maxdiff", np.max(np.abs(E - c8a8)), 0.0, 0.0)
eq("C1.c8b_k8_maxdiff", np.max(np.abs(E - c8b8)), 0.0, 0.0)
eq("C2.u7_maxdiff", np.max(np.abs(U - u7)), 0.0, 0.0)
eq("C2.uniform7_maxdiff", np.max(np.abs(U - u7p)), 0.0, 0.0)
eq("C3.uniform6_maxdiff", np.max(np.abs(C6 - u6)), 0.0, 0.0)
eq("C7.p24_maxdiff", np.max(np.abs(E - p24b)),
   C["C7_p24_mismatch"]["maxdiff"], 1e-9)

# --- independent reconstruction ------------------------------------------
R_tok = (C6 + E) / 2.0
R_lay = (F2 + B2) / 2.0
cf = F1 - E
cb = B1 - E
pick_front = np.less(cf, cb)
L_o = B2.copy()
L_o[pick_front] = F2[pick_front]

d_AX = (R_tok - T_o) - (R_lay - L_o)
d_AXf = T_p - F2
S_tok_a = R_tok - T_o
S_lay_a = R_lay - L_o

for nm, arr in (("E", E), ("U", U), ("C6", C6), ("F1", F1), ("B1", B1),
                ("F2", F2), ("B2", B2), ("T_o", T_o), ("T_p", T_p),
                ("T_r", T_r), ("R_tok", R_tok), ("R_lay", R_lay),
                ("L_o", L_o), ("cf", cf), ("cb", cb),
                ("d_AX", d_AX), ("d_AX_feas", d_AXf),
                ("S_tok", S_tok_a), ("S_lay", S_lay_a)):
    eq("npz." + nm + ".count", arr.size, N, 0.0)
    eq("npz." + nm + ".maxdiff", np.max(np.abs(arr - D[nm])), 0.0, 0.0)

# --- t / p via ttest_rel (different path from the main script) -------------
def check_stat(key, arr, ref_two=None):
    st = S[key]
    tt = stats.ttest_rel(arr, np.zeros_like(arr), alternative="two-sided")
    # ttest_rel against zeros gives exactly mean / (sd/sqrt(n))
    eq(key + ".t_ttest", float(tt.statistic), st["t"], 1e-8)
    eq(key + ".p_ttest", float(tt.pvalue), st["p_two"], 1e-8)
    eq(key + ".mean", float(arr.mean()), st["mean"])
    eq(key + ".sd", float(arr.std(ddof=1)), st["sd"])
    eq(key + ".se", float(arr.std(ddof=1) / np.sqrt(N)), st["se"])
    eq(key + ".mde", float(stats.t.ppf(0.975, N - 1) * arr.std(ddof=1) / np.sqrt(N)),
       st["mde"])
    lo95, hi95 = stats.t.interval(0.95, N - 1, loc=arr.mean(),
                                  scale=arr.std(ddof=1) / np.sqrt(N))
    lo90, hi90 = stats.t.interval(0.90, N - 1, loc=arr.mean(),
                                  scale=arr.std(ddof=1) / np.sqrt(N))
    eq(key + ".ci95_lo", lo95, st["ci95"][0])
    eq(key + ".ci95_hi", hi95, st["ci95"][1])
    eq(key + ".ci90_lo", lo90, st["ci90"][0])
    eq(key + ".ci90_hi", hi90, st["ci90"][1])
    eq(key + ".n_pos", int((arr > 0).sum()), st["n_pos"], 0.0)
    eq(key + ".n_neg", int((arr < 0).sum()), st["n_neg"], 0.0)
    eq(key + ".median", float(np.median(arr)), st["median"])
    eq(key + ".min", float(arr.min()), st["min"])
    eq(key + ".max", float(arr.max()), st["max"])
    wm = arr.reshape(48, 255).mean(axis=1)
    eq(key + ".se_win", float(wm.std(ddof=1) / np.sqrt(48)), st["se_win"])
    eq(key + ".top1_abs_share",
       float(np.sort(np.abs(arr))[::-1][:123].sum() / np.abs(arr).sum()),
       st["top1_abs_share"])


pairs = {
    "AX": d_AX,
    "AX_feas": d_AXf,
    "S_tok": S_tok_a,
    "S_lay": S_lay_a,
    "G_tok_oracle": T_o - U,
    "G_tok_probe": T_p - U,
    "G_tok_random": R_tok - U,
    "G_tok_random_realized": T_r - U,
    "G_lay_oracle": L_o - U,
    "G_lay_static_best": F2 - U,
    "G_lay_worst": B2 - U,
    "G_lay_random": R_lay - U,
    "J_delta": (R_tok - U) - (R_lay - U),
    "R_tok_vs_T_r": R_tok - T_r,
    "F1_cost": cf,
    "B1_cost": cb,
    "F2_vs_B2": F2 - B2,
    "layer_additivity": (cf + cb) - (U - E),
    "AX_using_realized_random": (T_r - T_o) - (R_lay - L_o),
    "AX_feas_vs_worst": T_p - B2,
}
for k, arr in pairs.items():
    check_stat(k, arr)

# --- confirmatory family: Holm + TOST recomputed ---------------------------
p1, p2 = S["AX"]["p_two"], S["AX_feas"]["p_two"]
m, se, df = d_AXf.mean(), d_AXf.std(ddof=1) / np.sqrt(N), N - 1
pl = float(stats.t.sf((m + DELTA) / se, df))
ph = float(stats.t.cdf((m - DELTA) / se, df))
p3 = max(pl, ph)
eq("T3.p_low", pl, A["confirmatory"]["T3"]["p_low"])
eq("T3.p_high", ph, A["confirmatory"]["T3"]["p_high"])
eq("T3.p_tost", p3, A["confirmatory"]["T3"]["p_tost"])
# explicit Holm step-down (independent implementation)
order = sorted([("T1", p1), ("T2", p2), ("T3", p3)], key=lambda x: x[1])
adj = {}
running = 0.0
for i, (key, pv) in enumerate(order):
    running = max(running, (3 - i) * pv)
    adj[key] = min(1.0, running)
for key in ("T1", "T2", "T3"):
    eq("Holm." + key, adj[key], A["confirmatory"]["holm"][key], 1e-8)
    eq("Holm." + key + ".p_holm", adj[key],
       A["confirmatory"][key]["p_holm"], 1e-8)

# --- C4 published values, independently -----------------------------------
order_q = np.argsort(E, kind="stable")
q = np.array_split(order_q, 4)
qv = [float((U - E)[g].mean()) for g in q]
eq("C4.quartile_ratio", qv[3] / qv[0],
   C["C4_published_values"]["p3_quartile_ratio"]["observed"])
eq("C4.quartile_ratio_published", qv[3] / qv[0], 21.5, 0.5 / 21.5)
eq("C4.f6b8_minus_u7", float((F2 - U).mean()),
   C["C4_published_values"]["f6b8_minus_u7"]["observed"])
eq("C4.probe50_minus_u7", float((T_p - U).mean()),
   C["C4_published_values"]["probe50_minus_u7"]["observed"])
eq("C4.oracle50_minus_u7", float((T_o - U).mean()),
   C["C4_published_values"]["oracle50_minus_u7"]["observed"])
eq("C4.spearman_2slot", float(stats.spearmanr(E, C6 - E).statistic),
   A["exploratory"]["spearman_E_vs_2slot"], 1e-8)
eq("C4.layer_cost_ratio", float(cb.mean() / cf.mean()),
   A["exploratory"]["layer_cost_ratio_back_front"], 1e-8)
eq("C4.front_rate", float(pick_front.mean()),
   A["exploratory"]["L_o_front_selection_rate"], 1e-8)

# --- consistency: verdict -------------------------------------------------
calib_ok = bool(C["all_pass"])
t1_reject = bool(A["confirmatory"]["T1"]["reject"])
case = "D" if not calib_ok else ("A" if t1_reject and d_AX.mean() > 0
                                 and A["confirmatory"]["T3"]["reject"]
                                 else "B" if t1_reject and d_AX.mean() > 0
                                 else "C")
eq("verdict.case_str", 1.0 if case == A["verdict"]["case"] else 0.0, 1.0, 0.0)

out = {
    "checked": checked,
    "mismatches": mismatches,
    "n_mismatch": len(mismatches),
    "status": "PASS" if not mismatches else "FAIL",
    "calibration_all_pass": calib_ok,
    "case": case,
    "primary": {"AX_mean": float(d_AX.mean()), "AX_p": p1,
                "AX_mde": S["AX"]["mde"],
                "AX_feas_mean": float(d_AXf.mean()),
                "AX_feas_p": p2,
                "T3_p_tost": p3},
}
with open(os.path.join(ROOT, "_ax1_verify_metrics.json"), "w",
          encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print("AX1 Step4: %d items, %d mismatches -> %s" %
      (checked, len(mismatches), out["status"]))
for x in mismatches[:20]:
    print("  MISMATCH", x)
