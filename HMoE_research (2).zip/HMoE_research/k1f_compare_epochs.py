#!/usr/bin/env python3
"""K1f: 6 epoch（K1/K1c）と 16 epoch（K1e）を同一 seed で対応比較する。

見るもの
  1. 未収束 run が消えたか（CE > 0.47）
  2. ΔCE の分布（平均・中央値・SD・MDE）が締まったか
  3. 同一 seed の対応差 Δ(16ep) − Δ(6ep)（訓練を長くすると推定がどう動くか）
  4. 水準（CE_教師・CE_生徒）がどこまで下がったか

出力: k1f_out_utf8.txt / k1f_compare.json
"""
import json
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "k1f_out_utf8.txt")
lines = []


def p(s=""):
    print(s, flush=True)
    lines.append(s)


def summ(d, label):
    d = np.asarray(d, float)
    n = len(d)
    m, se = float(d.mean()), float(d.std(ddof=1) / np.sqrt(n))
    t = m / se
    crit = stats.t.ppf(0.975, df=n - 1)
    coef = crit + stats.t.ppf(0.80, df=n - 1)
    return {"label": label, "n": n, "mean": m, "median": float(np.median(d)),
            "sd": float(d.std(ddof=1)), "se": se, "t": float(t),
            "p": float(2 * stats.t.sf(abs(t), df=n - 1)),
            "ci_lo": m - crit * se, "ci_hi": m + crit * se,
            "mde": coef * se, "n_neg": int((d < 0).sum())}


def show(s):
    p("  %-16s n=%-2d 平均 %+.4f 中央値 %+.4f SD %.4f se %.4f t %+.2f p %.4f"
      % (s["label"], s["n"], s["mean"], s["median"], s["sd"], s["se"], s["t"], s["p"]))
    p("  %-16s 95%%CI [%+.4f, %+.4f]  MDE %.4f  負 %d/%d"
      % ("", s["ci_lo"], s["ci_hi"], s["mde"], s["n_neg"], s["n"]))


def main():
    a = json.load(open(os.path.join(HERE, "k1d_combined.json"), encoding="utf-8"))
    b = json.load(open(os.path.join(HERE, "k1c_results_e16.json"), encoding="utf-8"))
    A = {r["seed"]: r for r in a["rows"]}
    B = {r["seed"]: r for r in b["rows"]}
    seeds = sorted(set(A) & set(B))

    p("K1f: 6 epoch vs 16 epoch（同一 seed 対応、dense W=161）")
    p("")
    p("| seed | CE_t(6) | CE_s(6) | Δ(6) | CE_t(16) | CE_s(16) | Δ(16) | Δ(16)−Δ(6) |")
    p("|---:|---:|---:|---:|---:|---:|---:|---:|")
    for s in seeds:
        p("| %d | %.4f | %.4f | %+.4f | %.4f | %.4f | %+.4f | %+.4f |"
          % (s, A[s]["ce_t"], A[s]["ce_s"], A[s]["delta"],
             B[s]["ce_t"], B[s]["ce_s"], B[s]["delta"],
             B[s]["delta"] - A[s]["delta"]))
    p("")

    dA = np.array([A[s]["delta"] for s in seeds])
    dB = np.array([B[s]["delta"] for s in seeds])
    TH = 0.47
    fA = int(sum((A[s]["ce_t"] > TH) or (A[s]["ce_s"] > TH) for s in seeds))
    fB = int(sum((B[s]["ce_t"] > TH) or (B[s]["ce_s"] > TH) for s in seeds))

    p("== 1) 未収束（CE > %.2f） ==" % TH)
    p("  6 epoch: %d/%d 本 / 16 epoch: %d/%d 本" % (fA, len(seeds), fB, len(seeds)))
    if fB:
        p("  残った run: %s" % ", ".join(
            "s%d(t=%.3f,s=%.3f)" % (s, B[s]["ce_t"], B[s]["ce_s"]) for s in seeds
            if B[s]["ce_t"] > TH or B[s]["ce_s"] > TH))
    p("")

    p("== 2) ΔCE の分布 ==")
    sA, sB = summ(dA, "6 epoch"), summ(dB, "16 epoch")
    show(sA)
    show(sB)
    p("  → SD %.4f → %.4f（%.2f 倍）、MDE %.4f → %.4f"
      % (sA["sd"], sB["sd"], sB["sd"] / sA["sd"], sA["mde"], sB["mde"]))
    p("")

    p("== 3) 同一 seed の対応差 Δ(16) − Δ(6) ==")
    dd = dB - dA
    s = summ(dd, "Δ(16)−Δ(6)")
    show(s)
    p("  正なら「長く訓練すると Δ が上がる（生徒に不利）」、負なら「下がる（有利）」。")
    p("")

    p("== 4) 水準 ==")
    for tag, D in (("6 epoch", A), ("16 epoch", B)):
        ct = np.array([D[s]["ce_t"] for s in seeds])
        cs = np.array([D[s]["ce_s"] for s in seeds])
        p("  %-9s CE_教師 平均 %.4f (SD %.4f, 最大 %.4f) / CE_生徒 平均 %.4f (SD %.4f, 最大 %.4f)"
          % (tag, ct.mean(), ct.std(ddof=1), ct.max(), cs.mean(), cs.std(ddof=1), cs.max()))
    p("")

    p("== 5) 収束した run だけで比べる（両 epoch とも CE ≤ %.2f） ==" % TH)
    ok = [s for s in seeds if A[s]["ce_t"] <= TH and A[s]["ce_s"] <= TH
          and B[s]["ce_t"] <= TH and B[s]["ce_s"] <= TH]
    if ok:
        p("  seeds = %s" % ok)
        show(summ([A[s]["delta"] for s in ok], "6 epoch"))
        show(summ([B[s]["delta"] for s in ok], "16 epoch"))
    p("")

    out = {"seeds": seeds, "rows": [{"seed": s, "ep6": A[s], "ep16": B[s]} for s in seeds],
           "ep6": sA, "ep16": sB, "paired_diff": s,
           "n_fail": {"ep6": fA, "ep16": fB}, "ok_seeds": ok}
    with open(os.path.join(HERE, "k1f_compare.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=float)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n[write] %s" % OUT)


if __name__ == "__main__":
    main()
