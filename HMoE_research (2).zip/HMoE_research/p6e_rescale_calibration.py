# -*- coding: utf-8 -*-
"""p6e_rescale_calibration.py — p の押し上げは「質量の欠落」由来か「内容」由来か

P6/P6b で「専門家を削ると p_top1 が上がり、正解率が下がる（較正ギャップが増える）」
ことが分かった。原因の候補は 2 つ:

  (A) 質量の欠落: norm_topk_prob=False なので、k を削ると FFN 出力がその重みぶん縮む。
      → スケールの効果。
  (B) 内容: 落とした Expert が実際に寄与していた情報が消える。
      → 方向の効果。

--rescale は「保持した top-k 重みを k=8 と同じ総質量に戻す」介入なので、
  rescale で p の押し上げが消えれば (A)、残れば (B)。

条件（2x2 + base）:
  base      : 全層 top-8
  u7        : 全層 top-7
  u7_rs     : 全層 top-7 + rescale
  k6        : 全層 top-6
  k6_rs     : 全層 top-6 + rescale

出力: p6e_rescale_cal.npz / p6e_out_utf8.txt

実行:
  python p6e_rescale_calibration.py --gpu-gib 7.5 --cpu-gib 12.0
"""

import argparse
import json
import os
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


CONDS = [
    ("base", 8, False),
    ("u7", 7, False),
    ("u7_rs", 7, True),
    ("k6", 6, False),
    ("k6_rs", 6, True),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--ids", type=str, default=os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"))
    ap.add_argument("--gpu-gib", type=float, default=7.5)
    ap.add_argument("--cpu-gib", type=float, default=12.0)
    args = ap.parse_args()

    import torch
    from transformers import AutoModelForCausalLM

    log("[1/3] loading %s" % args.model)
    t0 = time.time()
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      loaded in %.0f s" % (time.time() - t0))

    FULL_K = int(model.config.num_experts_per_tok)
    gates = [layer.mlp.gate for layer in model.model.layers]
    # accelerate が forward をインスタンス属性で差し替えているので、原関数を保存して付け替える
    ORIG = [g.forward for g in gates]

    def make_rescaled(orig, full_k):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            if scores.shape[-1] < full_k:
                probs = torch.softmax(logits.float(), dim=-1)
                m_full = torch.topk(probs, full_k, dim=-1).values.sum(-1, keepdim=True)
                m_now = scores.float().sum(-1, keepdim=True).clamp_min(1e-9)
                scores = (scores.float() * (m_full / m_now)).to(scores.dtype)
            return logits, scores, idx
        return _patched

    # 保持質量（削った質量の実測用）
    kept = []
    handles = []
    for g in gates:
        def mk():
            def hook(module, inp, out):
                kept.append(out[1].detach().float().sum(-1).cpu())
            return hook
        handles.append(g.register_forward_hook(mk()))

    z = np.load(args.ids, allow_pickle=True)
    seqs = []
    for lang in ("en", "ja"):
        ids = torch.from_numpy(z["%s_ids" % lang].astype(np.int64))
        for w in range(ids.numel() // 256):
            seqs.append((lang, ids[w * 256:(w + 1) * 256]))
    lang_arr = np.array([s[0] for s in seqs])
    log("[2/3] frozen corpus: %d windows x 256 = %d tokens" % (len(seqs), len(seqs) * 256))

    store = {}
    for name, k, rescale in CONDS:
        for i, g in enumerate(gates):
            g.top_k = k
            g.forward = make_rescaled(ORIG[i], FULL_K) if rescale else ORIG[i]
        kept.clear()
        t1 = time.time()
        ch = {key: [] for key in ("nll", "ptop1", "top1", "mass5", "in5")}
        with torch.no_grad():
            for lang, ids in seqs:
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                lg = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                logZ = torch.logsumexp(lg, dim=-1)
                true_l = lg.gather(1, tgt.unsqueeze(-1)).squeeze(-1)
                rank = (lg > true_l.unsqueeze(-1)).sum(dim=-1) + 1
                top1_l, _ = lg.max(dim=-1)
                top5_l = torch.topk(lg, 5, dim=-1).values
                ch["nll"].append((logZ - true_l).cpu().numpy())
                ch["ptop1"].append(torch.exp(top1_l - logZ).cpu().numpy())
                ch["top1"].append((rank == 1).float().cpu().numpy())
                ch["mass5"].append(torch.exp(torch.logsumexp(top5_l, dim=-1) - logZ).cpu().numpy())
                ch["in5"].append((rank <= 5).float().cpu().numpy())
                del out, lg, logZ, true_l, rank, top5_l
                torch.cuda.empty_cache()
        store[name] = {kk: np.concatenate(v) for kk, v in ch.items()}
        # 層別の保持質量の平均（最後の 48 ウィンドウ分だけ使う）
        km = torch.stack(kept[-16 * len(seqs):]).numpy()      # (layers*windows, tokens)
        km = km.reshape(16, len(seqs), -1).mean(axis=(1, 2))
        store[name]["kept_mass_by_layer"] = km
        log("      %-6s k=%d rs=%d  CE %.5f  p_top1 %.4f  acc %.4f  kept_mass %.4f (%.0f s)"
            % (name, k, int(rescale), store[name]["nll"].mean(),
               store[name]["ptop1"].mean(), store[name]["top1"].mean(),
               float(km.mean()), time.time() - t1))

    for h in handles:
        h.remove()

    np.savez_compressed(
        os.path.join(HERE, "p6e_rescale_cal.npz"), lang=lang_arr,
        **{("%s_%s" % (n, kk)): store[n][kk] for n in store for kk in store[n]})
    with open(os.path.join(HERE, "p6e_out_utf8.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(LOG))
    log("saved p6e_rescale_cal.npz")
    import sys
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
