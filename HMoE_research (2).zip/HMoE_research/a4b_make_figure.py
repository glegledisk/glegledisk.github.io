#!/usr/bin/env python3
"""A4b の図。raw と gain 補正の比較 + 副産物（gain が幅とともに増える）。"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "MS Gothic", "sans-serif"]
matplotlib.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a4")
raw = [r for r in json.load(open(os.path.join(D, "a4_results.json"), encoding="utf-8"))
       if "evals" in r]
g = [r for r in json.load(open(os.path.join(D, "a4_results_g.json"), encoding="utf-8"))
     if "evals" in r]
ORDER = ["all_relu", "small_relu2", "large_relu2", "all_relu2"]
LABEL = {"all_relu": "全て ReLU", "small_relu2": "小に ReLU²",
         "large_relu2": "大に ReLU²", "all_relu2": "全て ReLU²"}

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.0, 4.8),
                               gridspec_kw={"width_ratios": [1.15, 1]})

# --- (a) raw vs gain（instr_valid と CE の二軸は避け、instr で揃える）---
xs = np.arange(len(ORDER))
w = 0.36
for k, (nm, rows, col) in enumerate((("raw", raw, "#9bb7d4"), ("gain 補正", g, "#c44e52"))):
    v = [np.mean([r["evals"][-1]["instr_valid"] for r in rows if r["arm"] == a])
         for a in ORDER]
    s = [np.std([r["evals"][-1]["instr_valid"] for r in rows if r["arm"] == a], ddof=1)
         for a in ORDER]
    ax1.bar(xs + (k - 0.5) * w, v, w, yerr=s, capsize=3, color=col,
            edgecolor="black", linewidth=0.6, label=nm)
    for x, vv in zip(xs + (k - 0.5) * w, v):
        ax1.text(x, vv + 0.03, f"{vv:.2f}", ha="center", fontsize=8)
ax1.set_xticks(xs)
ax1.set_xticklabels([LABEL[a] for a in ORDER], fontsize=9)
ax1.set_ylabel("instr_valid（平均 ± SD, n=6）")
ax1.set_title("(a) raw と gain 補正 — 結論は動かない", fontsize=11)
ax1.legend(fontsize=9)
ax1.grid(axis="y", alpha=0.3)
ax1.set_ylim(0, 1.0)

# --- (b) 副産物: gain が幅とともに増える ---
r0 = next(x for x in g if x["arm"] == "all_relu2")
be = r0["gain"]["by_expert"]
wd = r0["widths"]
ax2.plot(wd, be, "o-", color="#4c72b0", lw=2, ms=8, label="all_relu2（全 expert ReLU²）")
r1 = next(x for x in g if x["arm"] == "small_relu2")
ax2.plot([32, 32], r1["gain"]["by_expert"][:2], "s", color="#c44e52", ms=9,
         label="small_relu2（e0,e1 のみ）")
r2 = next(x for x in g if x["arm"] == "large_relu2")
ax2.plot([224, 224], r2["gain"]["by_expert"][6:], "D", color="#dd8452", ms=9,
         label="large_relu2（e6,e7 のみ）")
ax2.axhline(1.0, color="black", ls="--", lw=1)
ax2.set_xlabel("expert の幅 d_ff")
ax2.set_ylabel("校正 gain（ReLU 基準に戻す係数）")
ax2.set_title("(b) 幅が広い expert ほど強い増幅が要る", fontsize=11)
ax2.legend(fontsize=8, loc="upper left")
ax2.grid(alpha=0.3)

plt.tight_layout()
out = os.path.join(D, "a4b_figure.png")
plt.savefig(out, dpi=150)
print(f"[write] {out}")
