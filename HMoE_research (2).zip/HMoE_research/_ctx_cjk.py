import re, sys
from markdown_it import MarkdownIt
MD = MarkdownIt("commonmark").enable("table")
p = sys.argv[1]
src = open(p, encoding="utf-8").read()
html = MD.render(src)
for m in re.finditer(r"[\u3040-\u30ff\u4e00-\u9fff]\s+[\u3040-\u30ff\u4e00-\u9fff]", html):
    i = m.start()
    print("   ", repr(html[max(0,i-40):i+40]))