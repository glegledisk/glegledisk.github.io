#!/usr/bin/env python3
"""P13c の解析: バグ修正後の HMoE / 同質 MoE / dense を等 active FLOPs で比べる。

FLOPs 会計（1 トークン・1 層あたり MAC）: attention 4d^2 + router E d + expert 2 d W
  d=128, E=8, 4 層。expert 幅は全体の 4〜5 割なので、幅の比をそのまま速度比にしない。
"""
import json
import math
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
D, E, L = 128, 8, 4


def macs(W):
    return L * (4 * D * D + E * D + 2 * D * W)


def emit(s=""):
    print(s, flush=True)


def main():
    R = json.load(open(os.path.join(HERE, "p13c_results.json"), encoding="utf-8"))
    arms = ["H+LB", "U+LB"]
    seeds = [0, 1, 2]
    lines = []

    def log(s=""):
        emit(s)
        lines.append(s)

    def row(arm, s, cond):
        return R.get("%s:s%d:%s" % (arm, s, cond))

    log("=" * 80)
    log("[1] 自然な動作点（交絡なし）")
    log("%-6s %-5s %7s %8s %8s %8s %10s %10s"
        % ("arm", "cond", "W", "CE_all", "CE_copy", "copy", "MACs/tok", "params"))
    pts = {}
    for arm in arms:
        for cond in ("top1", "base", "top3", "all8"):
            rows = [row(arm, s, cond) for s in seeds if row(arm, s, cond)]
            if not rows:
                continue
            W = float(np.mean([r["width"] for r in rows]))
            pts[(arm, cond)] = {
                "W": W, "ce": float(np.mean([r["ce_all"] for r in rows])),
                "ce_copy": float(np.mean([r["ce_copy"] for r in rows])),
                "acc": float(np.mean([r["acc_copy"] for r in rows])),
                "per_seed": [r["ce_all"] for r in rows],
                "per_seed_W": [r["width"] for r in rows]}
            log("%-6s %-5s %7.1f %8.4f %8.4f %8.4f %10.0f %10d"
                % (arm, cond, W, pts[(arm, cond)]["ce"], pts[(arm, cond)]["ce_copy"],
                   pts[(arm, cond)]["acc"], macs(W), 1342653))

    Dn = [r for k, r in R.items() if r["arm"] == "dense"]
    log("%-6s %-5s %7s %8s %8s %8s %10s %10s"
        % ("dense", "k=1", "", "", "", "", "", ""))
    for w in sorted(set(int(r["width"]) for r in Dn)):
        rows = [r for r in Dn if int(r["width"]) == w]
        pts[("dense", str(w))] = {
            "W": float(w), "ce": float(np.mean([r["ce_all"] for r in rows])),
            "ce_copy": float(np.mean([r["ce_copy"] for r in rows])),
            "acc": float(np.mean([r["acc_copy"] for r in rows])),
            "per_seed": [r["ce_all"] for r in rows],
            "nparam": rows[0]["nparam"]}
        log("%-6s W=%-3d %7d %8.4f %8.4f %8.4f %10.0f %10d"
            % ("dense", w, w, pts[("dense", str(w))]["ce"],
               pts[("dense", str(w))]["ce_copy"],
               pts[("dense", str(w))]["acc"], macs(w), rows[0]["nparam"]))

    log("")
    log("[2] seed 別の系列対応 ΔCE（同一評価系列）")
    pairs = [("H+LB", "base", "U+LB", "base"),
             ("H+LB", "top1", "U+LB", "top1"),
             ("H+LB", "base", "dense", "180"),
             ("U+LB", "base", "dense", "180"),
             ("H+LB", "top1", "dense", "97"),
             ("U+LB", "top1", "dense", "97")]
    for a1, c1, a2, c2 in pairs:
        log("  %s %s vs %s %s" % (a1, c1, a2, c2))
        for s in seeds:
            x1 = row(a1, s, c1) if a1 != "dense" else R.get("dense:s%d:w%s" % (s, c2))
            x2 = row(a2, s, c2) if a2 != "dense" else R.get("dense:s%d:w%s" % (s, c2))
            if a2 == "dense":
                x2 = R.get("dense:s%d:w%s" % (s, c2))
            if a1 == "dense":
                x1 = R.get("dense:s%d:w%s" % (s, c1))
            if not x1 or not x2:
                continue
            x = np.array(x1["ce_seq"])
            y = np.array(x2["ce_seq"])
            d = x - y
            se = d.std(ddof=1) / math.sqrt(d.size)
            log("    s%d: ΔCE %+.4f  se %.4f  t %+6.1f   W %.0f vs %.0f  %s"
                % (s, d.mean(), se, d.mean() / se, x1["width"], x2["width"],
                   "左が勝ち" if d.mean() < 0 else "右が勝ち"))

    log("")
    log("[3] 小 expert（幅 32 の 2 個）はどの層で働くか — 選択されたトークンの割合")
    log("     %-6s %-3s %6s %6s %6s %6s   %s"
        % ("arm", "s", "L0", "L1", "L2", "L3", "L3−L0"))
    for arm in arms:
        for s in seeds:
            r = row(arm, s, "base")
            if not r:
                continue
            u = np.array(r["usage"])[:4]
            # usage は「その expert が選ばれた (トークン, 位置) の数 / (トークン数 * k)」ではないので
            # ここでは和を「2 個のうち何個が入ったか」として読み、2 で割って割合にする
            small = u[:, [0, 1]].sum(1) / 2.0
            log("     %-6s %-3d %6.2f %6.2f %6.2f %6.2f   %+6.2f"
                % (arm, s, small[0], small[1], small[2], small[3],
                   small[3] - small[0]))

    log("")
    log("[4] 固定部分集合の制限（ゲート再正規化 + 層の専門化を含む）")
    log("     %-6s %-4s %6s %8s %8s   %s"
        % ("arm", "cond", "W", "CE_all", "copy", "seed 別 CE"))
    for arm in arms:
        for cond in ("s1", "s2", "m2", "u2", "q4", "l2", "r2"):
            rows = [row(arm, s, cond) for s in seeds if row(arm, s, cond)]
            if not rows:
                continue
            log("     %-6s %-4s %6.0f %8.4f %8.4f   %s"
                % (arm, cond, np.mean([r["width"] for r in rows]),
                   np.mean([r["ce_all"] for r in rows]),
                   np.mean([r["acc_copy"] for r in rows]),
                   " ".join("%.3f" % r["ce_all"] for r in rows)))

    log("")
    log("[5] 小 expert だけで base の何割を回収するか（copy 正解率）")
    for arm in arms:
        b = [row(arm, s, "base")["acc_copy"] for s in seeds]
        s2 = [row(arm, s, "s2")["acc_copy"] for s in seeds]
        w2 = [row(arm, s, "s2")["width"] for s in seeds]
        wb = [row(arm, s, "base")["width"] for s in seeds]
        log("     %-6s base %.3f (W %.0f) / s2 {0,1} %.3f (W %.0f) → 回収率 %s"
            % (arm, np.mean(b), np.mean(wb), np.mean(s2), np.mean(w2),
               " ".join("%.2f" % (a / c) for a, c in zip(s2, b))))

    log("")
    log("[6] 幅あたりの効率（CE_all を幅で割らない素の比較）")
    log("     HMoE base  W=%.0f CE=%.4f / 均一 base W=256 CE=%.4f / dense180 W=180 CE=%.4f"
        % (pts[("H+LB", "base")]["W"], pts[("H+LB", "base")]["ce"],
           pts[("U+LB", "base")]["ce"], pts[("dense", "180")]["ce"]))

    out = {"points": {"%s:%s" % k: v for k, v in pts.items()}}
    with open(os.path.join(HERE, "p13c_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=float)
    with open(os.path.join(HERE, "p13c_analysis_out_utf8.txt"), "w",
              encoding="utf-8") as f:
        f.write("\n".join(lines))
    print("\nsaved: p13c_analysis.json / p13c_analysis_out_utf8.txt")


if __name__ == "__main__":
    main()
