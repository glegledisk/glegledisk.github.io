import os, time
os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
from huggingface_hub import hf_hub_download
from tokenizers import Tokenizer

cands = [
    ("NousResearch/Meta-Llama-3-8B", "tokenizer.json", {}),
    ("allenai/OLMo-2-0425-1B", "tokenizer.json", {"force_download": True}),
    ("Qwen/Qwen3-0.6B", "tokenizer.json", {"force_download": True}),
]
for repo, fn, kw in cands:
    try:
        t0 = time.time()
        p = hf_hub_download(repo_id=repo, filename=fn, **kw)
        tk = Tokenizer.from_file(p)
        print(f"[OK] {repo}  {os.path.getsize(p)/1e6:.2f} MB  vocab={tk.get_vocab_size()}  {time.time()-t0:.1f}s")
    except Exception as e:
        print(f"[FAIL] {repo}: {type(e).__name__}: {str(e)[:200]}")
