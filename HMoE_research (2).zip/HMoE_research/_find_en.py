import glob, os
rows=[]
for f in sorted(glob.glob("*.md")):
    try: t=open(f,encoding="utf-8").read()
    except: continue
    if len(t)<2000: continue
    head=t[:4000]
    ascii_ratio=sum(1 for c in head if ord(c)<128)/len(head)
    rows.append((ascii_ratio,len(t),f))
rows.sort(reverse=True)
for r in rows[:12]: print("%.3f %8d %s" % r)