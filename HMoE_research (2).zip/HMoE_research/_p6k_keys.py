import numpy as np
z = np.load("p6k_head_proj.npz", allow_pickle=True)
print("n keys:", len(z.files))
print([k for k in z.files if not k.startswith(("f6b8_","f8b6_"))])
print("sample:", [k for k in z.files if k.startswith("f6b8_")])