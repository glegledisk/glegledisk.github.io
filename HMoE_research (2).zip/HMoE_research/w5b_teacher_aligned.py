#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""W5: 棚上げされていた層出力 KD を PC4 と同一の K6 系で再開する。

事前登録: `W5課題設計書_層出力KDの棚上げ解除_20261106.md`（追記を含む）。

pc2_cut_init.py の worker は hid_w を期待するのに main が 13 要素しか渡さず
起動しない（ValueError を実測）。既存ファイルは書き換えず、本ファイルに
worker を写経して hid_mode（match / shuffle）と固定 teacher を追加する。
校正腕の数値経路は PC2.worker と完全に同一に保つ。

出力: w5_results.json / w5_delta.npz / w5_analysis.json / w5_out_utf8.txt
"""
import argparse
import json
import math
import os
import re
import sys
import time
from multiprocessing import Pool

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import k6_capacity_task as K6          # noqa: E402
import pc2_cut_init as PC2             # noqa: E402

CKPTDIR = PC2.CKPTDIR
HALF = PC2.HALF
N = 15000
PER_KEY = 2
EPOCHS = 10
BS = 64
LR = 5e-4
CLIP = 50.0
AUXW = 0.05
T_PK, T_EP = 10, 10
SEEDS = tuple(range(7))
STEPS_PER_EPOCH = max(1, (N * PER_KEY) // BS)
TOTAL_STEPS = STEPS_PER_EPOCH * EPOCHS

ARMS = (
    "half:scratch",
    "half:scratch+kd_w10.0_T1.0_clip50",
    "half:scratch+hkd_hw1.0",
    "half:scratch+hkd_hw10.0",
    "half:scratch+hkd_hw100.0",
    "half:scratch+hkd_shuf_hw10.0",
    "half:prune",
)
HKD_ARMS = ("half:scratch+hkd_hw1.0", "half:scratch+hkd_hw10.0",
            "half:scratch+hkd_hw100.0")
# pc2_results_n15k_w10.json の生値（6 桁丸めの表示値ではない）
CALIB = {
    "half:scratch": {0: 2.0404417514801025, 1: 2.0636322498321533},
    "half:scratch+kd_w10.0_T1.0_clip50": {0: 1.9739348888397217,
                                          1: 1.9652323722839355},
}


def teacher_path(seed, t_ep=T_EP, t_pk=T_PK):
    return PC2.ckpt_name("teacher", N, seed, t_ep, t_pk)


def worker(job):
    cfg, seed, N_, per_key, epochs, bs, lr, auxw, clip, kd_w, kd_T, \
        hid_w, t_pk, t_ep, hid_mode, teacher_seed = job
    import torch
    import torch.nn.functional as F
    import e2b_rewrite_routing_fixed as e2b

    torch.set_num_threads(1)
    e2b.SEQ = K6.SEQ_
    e2b.SL, e2b.OL = K6.SL_, K6.OL_
    V, SEP = e2b.V, e2b.SEP

    t0 = time.time()
    table = K6.build_table(N_, 10_000 + teacher_seed)  # W5b: 教師 ckpt とテーブルを対応させる
    _, ids_fn = K6.make_sampler(N_, "uniform", 1.0)

    arm, k = "p_pen", 2
    widths = e2b.WIDTHS["H+LB"] if cfg == "teacher" else HALF
    model = e2b.RewriteMoE(widths, seed=seed, topk=k)

    base = cfg.split(":")[1] if cfg.startswith("half:") else ""
    init_mode = "scratch" if base.startswith("scratch") else "prune"
    use_kd = "+kd" in base
    use_hkd = "+hkd" in base
    m = re.search(r"_w([0-9.]+)_T([0-9.]+)", base)
    if m:
        kd_w, kd_T = float(m.group(1)), float(m.group(2))
    mh = re.search(r"_hw([0-9.]+)", base)
    if mh:
        hid_w = float(mh.group(1))
    mc = re.search(r"_clip([0-9.]+)", base)
    if mc:
        clip = float(mc.group(1))
    ml = re.search(r"_lr([0-9.]+)", base)
    if ml:
        lr = float(ml.group(1))
    if use_kd and kd_w <= 0:
        raise SystemExit("cfg %s は KD を要求するが kd_w=%g" % (cfg, kd_w))
    if use_hkd and hid_w <= 0:
        raise SystemExit("cfg %s は hidden KD を要求するが hid_w=%g" % (cfg, hid_w))
    if hid_mode not in ("match", "shuffle"):
        raise SystemExit("unknown hid_mode: %s" % hid_mode)

    # --- 教師 ckpt（seed 0/1 を全 seed で共有）---
    teacher = None
    td = None
    if init_mode == "prune" or use_kd or use_hkd:
        tp = teacher_path(teacher_seed, t_ep, t_pk)
        if not os.path.exists(tp):
            raise SystemExit("teacher ckpt が無い: %s" % tp)
        td = torch.load(tp, map_location="cpu")
        if use_kd or use_hkd:
            teacher = e2b.RewriteMoE(e2b.WIDTHS["H+LB"], seed=seed)
            teacher.p = {kk: v for kk, v in td.items()}
            for kk in teacher.p:
                teacher.p[kk].requires_grad_(False)
    if init_mode == "prune":
        sd = {kk: v.detach().clone() for kk, v in model.params().items()}
        for kk in ["emb.w", "pos.w", "head.w", "head.b"]:
            sd[kk] = td[kk].clone()
        for l in range(model.L):
            for kk in ["q.w", "k.w", "v.w", "o.w", "r.w", "r.b"]:
                sd["l%d.%s" % (l, kk)] = td["l%d.%s" % (l, kk)].clone()
            for i, ws in enumerate(widths):
                w1 = td["l%d.e%d.w1" % (l, i)]
                b1 = td["l%d.e%d.b1" % (l, i)]
                w2 = td["l%d.e%d.w2" % (l, i)]
                b2 = td["l%d.e%d.b2" % (l, i)]
                imp = w1.norm(dim=1) * w2.norm(dim=0)
                idx = torch.topk(imp, ws).indices.sort().values
                sd["l%d.e%d.w1" % (l, i)] = w1[idx].clone()
                sd["l%d.e%d.b1" % (l, i)] = b1[idx].clone()
                sd["l%d.e%d.w2" % (l, i)] = w2[:, idx].clone()
                sd["l%d.e%d.b2" % (l, i)] = b2.clone()
        model.p = sd
    for kk in model.p:
        model.p[kk].requires_grad_(True)

    opt = e2b.Adam(model.params(), lr=lr)
    dims = torch.tensor(model.dims, dtype=torch.float64)
    ev_rng = np.random.default_rng(4242)
    n_ev = int(min(N_ * 1, 200_000))
    ev_src, ev_out, ev_ids = K6.make_batch(ev_rng, n_ev, table, ids_fn)

    def evaluate():
        ce = np.zeros((n_ev, K6.OL_), dtype=np.float32)
        hit = np.zeros((n_ev, K6.OL_), dtype=bool)
        wsum, wn = 0.0, 0
        with torch.no_grad():
            for i in range(0, n_ev, 512):
                s = slice(i, min(i + 512, n_ev))
                x = torch.from_numpy(K6.to_seq(ev_src[s], ev_out[s], SEP))
                logits, _, idxs, _ = model(x, aux_mode="none", need_idx=True)
                lg = logits[:, K6.SL_:K6.SL_ + K6.OL_, :]
                lp = F.cross_entropy(lg.reshape(-1, V),
                                     torch.from_numpy(ev_out[s]).reshape(-1),
                                     reduction="none").reshape(-1, K6.OL_)
                ce[s] = lp.numpy()
                hit[s] = (lg.argmax(-1).numpy() == ev_out[s])
                for aa in idxs:
                    wsum += float(dims[aa].sum(-1).sum())
                    wn += aa.shape[0] * aa.shape[1]
        return ce, hit, wsum / max(wn, 1)

    ce0, hit0, w0 = evaluate()
    teacher_ce = None
    if teacher is not None:
        with torch.no_grad():
            tce = []
            for i in range(0, n_ev, 512):
                s = slice(i, min(i + 512, n_ev))
                xt = torch.from_numpy(K6.to_seq(ev_src[s], ev_out[s], SEP))
                tl, _, _, _ = teacher(xt, aux_mode="none")
                lg = tl[:, K6.SL_:K6.SL_ + K6.OL_, :]
                lp = F.cross_entropy(lg.reshape(-1, V),
                                     torch.from_numpy(ev_out[s]).reshape(-1),
                                     reduction="none")
                tce.append(float(lp.mean()))
        teacher_ce = float(np.mean(tce))

    rng = np.random.default_rng(1000 + seed)
    n_tr = int(N_ * per_key)
    steps = max(1, n_tr // bs)
    need_hid = use_hkd and teacher is not None
    hist = []
    for ep in range(epochs):
        run, nclip, kdsum, hkdsum = 0.0, 0, 0.0, 0.0
        for st in range(steps):
            src, out, _ = K6.make_batch(rng, bs, table, ids_fn)
            x = torch.from_numpy(K6.to_seq(src, out, SEP))
            logits, aux, _, s_hid = model(x, aux_mode=arm,
                                          need_hiddens=need_hid)
            lg = logits[:, K6.SL_:K6.SL_ + K6.OL_, :].reshape(-1, V)
            tgt = torch.from_numpy(out).reshape(-1)
            loss = F.cross_entropy(lg, tgt) + (auxw * aux if arm != "none" else 0.0)
            if teacher is not None:
                with torch.no_grad():
                    tlogits, _, _, t_hid = teacher(x, aux_mode="none",
                                                   need_hiddens=need_hid)
                    tlg = tlogits[:, K6.SL_:K6.SL_ + K6.OL_, :].reshape(-1, V)
                if use_kd:
                    ls = F.log_softmax(lg / kd_T, dim=-1)
                    lt = F.softmax(tlg / kd_T, dim=-1)
                    kdl = (lt * (torch.log(lt.clamp_min(1e-9)) - ls)).sum(-1).mean()
                    loss = loss + kd_w * (kd_T ** 2) * kdl
                    kdsum += float(kdl.detach())
                if need_hid:
                    hkd_loss = 0.0
                    gen = None
                    if hid_mode == "shuffle":
                        gen = torch.Generator().manual_seed(
                            7000 + 1000 * seed + ep * steps + st)
                    for li, (sl, tl) in enumerate(zip(s_hid, t_hid)):
                        target = tl.detach()
                        if hid_mode == "shuffle":
                            perm = torch.randperm(target.shape[0], generator=gen)
                            target = target[perm]
                        hkd_loss = hkd_loss + F.mse_loss(sl, target)
                    hkd_loss = hkd_loss / len(s_hid)
                    loss = loss + hid_w * hkd_loss
                    hkdsum += float(hkd_loss.detach())
            loss.backward()
            if clip > 0:
                tot = 0.0
                for v in model.params().values():
                    if v.grad is not None:
                        tot += float(v.grad.pow(2).sum())
                tot = tot ** 0.5
                if tot > clip:
                    s = clip / (tot + 1e-12)
                    for v in model.params().values():
                        if v.grad is not None:
                            v.grad.mul_(s)
                    nclip += 1
            opt.step(model.params())
            run += float(loss.detach())
        ce_ep, _, w_ep = evaluate()
        hist.append({"ep": ep + 1, "loss": run / steps,
                     "ce": float(ce_ep.mean()), "w": float(w_ep),
                     "nclip": nclip,
                     "kd": (kdsum / steps) if teacher is not None else None,
                     "hkd": (hkdsum / steps) if need_hid else None})

    tail = hist[-3:] if len(hist) >= 3 else hist
    ce, hit, width_mean = evaluate()
    return {
        "cfg": cfg, "seed": seed, "N": N_, "epochs": epochs,
        "per_key": per_key, "lr": lr, "clip": clip,
        "kd_w": kd_w, "kd_T": kd_T, "hid_w": hid_w,
        "hid_mode": hid_mode, "teacher_seed": teacher_seed,
        "table_seed": int(10_000 + teacher_seed),
        "teacher_ckpt": teacher_path(teacher_seed, t_ep, t_pk),
        "teacher_ce": teacher_ce,
        "ce_init": float(ce0.mean()), "acc_init": float(hit0.mean()),
        "ce": float(np.median([h["ce"] for h in tail])),
        "ce_last": float(hist[-1]["ce"]), "ce_hist": hist,
        "acc": float(hit.mean()),
        "width_mean": float(np.median([h["w"] for h in tail])),
        "n_clip": int(sum(h["nclip"] for h in hist)),
        "hkd_first": hist[0].get("hkd"), "hkd_last": hist[-1].get("hkd"),
        "kd_first": hist[0].get("kd"), "kd_last": hist[-1].get("kd"),
        "nparam": int(sum(v.numel() for v in model.params().values())),
        "sec": round(time.time() - t0, 1),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=list(SEEDS))
    ap.add_argument("--arms", nargs="+", default=list(ARMS))
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--epochs", type=int, default=EPOCHS)
    ap.add_argument("--tag", default="w5b")
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()

    tag = args.tag
    LOG = os.path.join(HERE, f"{tag}_out_utf8.txt")
    if os.path.exists(LOG):
        os.remove(LOG)

    def log(m):
        print(m, flush=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(m + "\n")

    log(f"W5b: arms={args.arms} seeds={args.seeds} epochs={args.epochs} "
        f"N={N} per_key={PER_KEY} bs={BS} lr={LR} clip={CLIP} "
        f"workers={args.workers} smoke={args.smoke}")
    log(f"  steps/epoch={STEPS_PER_EPOCH} total={args.epochs * STEPS_PER_EPOCH} "
        f"teacher=fixed s0/s1, table=10000+teacher_seed (W5 の対応切れを修正)")

    jobs = []
    for cfg in args.arms:
        hid_mode = "shuffle" if "shuf" in cfg else "match"
        for s in args.seeds:
            jobs.append((cfg, s, N, PER_KEY, args.epochs, BS, LR, AUXW,
                         CLIP, 0.0, 1.0, 1.0, T_PK, T_EP,
                         hid_mode, s % 2))

    rows = []
    t0 = time.time()
    with Pool(processes=min(args.workers, len(jobs))) as pool:
        for r in pool.imap_unordered(worker, jobs):
            rows.append(r)
            log("  %-42s s%d  CE %.6f  acc %.4f  clip %5d/%-5d  hkd %.4f→%.4f  (%.0fs)"
                % (r["cfg"], r["seed"], r["ce"], r["acc"], r["n_clip"],
                   args.epochs * STEPS_PER_EPOCH,
                   r["hkd_first"] if r["hkd_first"] is not None else float("nan"),
                   r["hkd_last"] if r["hkd_last"] is not None else float("nan"),
                   r["sec"]))
            with open(os.path.join(HERE, f"{tag}_partial.json"), "w",
                      encoding="utf-8") as f:
                json.dump({"rows": rows}, f, ensure_ascii=False, indent=2,
                          default=float)

    # --- 校正・記録値の assert ---
    calib = []
    for cfg, refs in CALIB.items():
        for s, want in refs.items():
            got = [r for r in rows if r["cfg"] == cfg and r["seed"] == s]
            if not got:
                continue
            v = float(got[0]["ce"])
            calib.append({"cfg": cfg, "seed": s, "got": v, "want": want,
                          "abs_diff": abs(v - want),
                          "bit_match": bool(abs(v - want) < 1e-12)})
    asserts = []
    for r in rows:
        cfg = r["cfg"]
        mh = re.search(r"_hw([0-9.]+)", cfg)
        mk = re.search(r"\+kd_w([0-9.]+)_T([0-9.]+)", cfg)
        mc = re.search(r"_clip([0-9.]+)", cfg)
        exp_h = float(mh.group(1)) if mh else 1.0
        exp_k = float(mk.group(1)) if mk else 0.0
        exp_c = float(mc.group(1)) if mc else CLIP
        ok = (abs(r["hid_w"] - exp_h) < 1e-9 and
              abs(r["kd_w"] - exp_k) < 1e-9 and
              abs(r["clip"] - exp_c) < 1e-9 and
              r["N"] == N and r["per_key"] == PER_KEY and
              r["epochs"] == args.epochs and abs(r["lr"] - LR) < 1e-12)
        asserts.append({"cfg": cfg, "seed": r["seed"], "ok": bool(ok)})

    # --- 集計 ---
    by = {}
    for r in rows:
        by.setdefault(r["cfg"], {})[r["seed"]] = r
    seeds = sorted(args.seeds)
    arr = {"seeds": np.asarray(seeds), "arms": np.asarray(list(by.keys()),
                                                           dtype=object)}
    for cfg, d in by.items():
        key = cfg.replace(":", "_").replace("+", "_").replace(".", "p")
        arr["ce_" + key] = np.asarray([d[s]["ce"] for s in seeds])
        arr["clip_" + key] = np.asarray([d[s]["n_clip"] for s in seeds],
                                        dtype=np.int64)

    def paired(a, b):
        x = np.asarray([by[a][s]["ce"] for s in seeds], dtype=np.float64)
        y = np.asarray([by[b][s]["ce"] for s in seeds], dtype=np.float64)
        d = x - y
        se = float(d.std(ddof=1) / math.sqrt(len(d)))
        tt = stats.ttest_rel(x, y)
        t = float(tt.statistic) if np.isfinite(tt.statistic) else 0.0
        p = float(tt.pvalue) if np.isfinite(tt.pvalue) else 1.0
        mde = float(stats.t.ppf(0.995, len(d) - 1) * se)
        absd = np.abs(d)
        ntop = max(1, int(math.ceil(0.01 * len(absd))))
        return {"delta": float(d.mean()), "se": se, "t": t, "p": p,
                "n": int(len(d)), "mde": mde,
                "n_neg": int((d < 0).sum()),
                "per_seed": d.tolist(),
                "top1_share": float(np.sort(absd)[-ntop:].sum() /
                                    max(1e-12, absd.sum())),
                "median": float(np.median(d)), "max": float(absd.max()),
                "mean_unreliable": bool(
                    np.sort(absd)[-ntop:].sum() / max(1e-12, absd.sum()) >= 0.5)}

    comps = {cfg: paired(cfg, "half:scratch")
             for cfg in by if cfg != "half:scratch"}
    # Holm m=3（hkd 3 腕のみ）
    order = sorted([c for c in HKD_ARMS if c in comps],
                   key=lambda c: comps[c]["p"])
    run = 0.0
    holm = {}
    for rank, cfg in enumerate(order):
        run = max(run, min(1.0, (len(order) - rank) * comps[cfg]["p"]))
        holm[cfg] = {"p_raw": comps[cfg]["p"], "p_holm": float(run),
                     "rank": rank + 1, "m": len(order)}
    for cfg in comps:
        comps[cfg]["p_holm"] = holm[cfg]["p_holm"] if cfg in holm else None

    for cfg, c in comps.items():
        key = cfg.replace(":", "_").replace("+", "_").replace(".", "p")
        c["clip_rate"] = float(np.mean(arr["clip_" + key])) / (
            args.epochs * STEPS_PER_EPOCH)
        c["W5_1"] = bool(cfg in HKD_ARMS and c["delta"] <= -1.0
                         and c["p_holm"] is not None and c["p_holm"] < 0.01
                         and abs(c["delta"]) > c["mde"])
        c["W5_2"] = bool(c["clip_rate"] < 0.05)
        c["W5_3"] = bool(c["W5_1"] and c["W5_2"])
    w51_arms = [c for c in HKD_ARMS if c in comps and comps[c]["W5_3"]]
    shuffle = "half:scratch+hkd_shuf_hw10.0"
    w54 = bool(shuffle in comps and
               "half:scratch+hkd_hw10.0" in comps and
               (by["half:scratch+hkd_hw10.0"] and shuffle) and
               np.mean([by["half:scratch+hkd_hw10.0"][s]["ce"] for s in seeds]) <
               np.mean([by[shuffle][s]["ce"] for s in seeds]))

    analysis = {
        "calibration": {"items": calib, "n": len(calib),
                        "all_bit_match": bool(all(c["bit_match"] for c in calib))},
        "asserts": {"items": asserts, "n": len(asserts),
                    "all_ok": bool(all(a["ok"] for a in asserts))},
        "comparisons": comps, "holm": holm,
        "verdict": {
            "W5_1_any_arm": bool(any(comps[c]["W5_1"] for c in HKD_ARMS
                                      if c in comps)),
            "W5_3_arms": w51_arms,
            "prediction_supported": bool(len(w51_arms) > 0),
            "W5_4_signal_structure": w54,
            "calibration_ok": bool(all(c["bit_match"] for c in calib)),
        },
        "meta": {"N": N, "per_key": PER_KEY, "epochs": args.epochs, "bs": BS,
                 "lr": LR, "clip": CLIP, "auxw": AUXW, "t_pk": T_PK,
                 "t_ep": T_EP, "seeds": seeds, "arms": list(by.keys()),
                 "steps_per_epoch": STEPS_PER_EPOCH,
                 "total_steps": args.epochs * STEPS_PER_EPOCH,
                 "workers": args.workers, "n_rows": len(rows),
                 "smoke": args.smoke, "wall_min": (time.time() - t0) / 60},
    }
    with open(os.path.join(HERE, f"{tag}_results.json"), "w",
              encoding="utf-8") as f:
        json.dump({"rows": rows, "args": vars(args)}, f,
                  ensure_ascii=False, indent=2, default=float)
    np.savez_compressed(os.path.join(HERE, f"{tag}_delta.npz"), **arr)
    with open(os.path.join(HERE, f"{tag}_analysis.json"), "w",
              encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2, default=float)

    log("")
    log(f"== 校正: {sum(c['bit_match'] for c in calib)}/{len(calib)} "
        f"bit-match  all={analysis['calibration']['all_bit_match']}")
    for c in calib:
        if not c["bit_match"]:
            log(f"  MISMATCH {c['cfg']} s{c['seed']}: "
                f"got={c['got']} want={c['want']}")
    log(f"== 記録値 assert: {sum(a['ok'] for a in asserts)}/{len(asserts)}")
    log("== 各腕 − half:scratch（paired, n=%d）==" % len(seeds))
    for cfg, c in comps.items():
        ph = c["p_holm"]
        log(f"  {cfg:<42s} Δ={c['delta']:+.4f} se={c['se']:.4f} "
            f"t={c['t']:+.2f} p={c['p']:.4g} "
            f"Holm={('%.4g' % ph) if ph is not None else 'control':>8s} "
            f"MDE={c['mde']:.4f} 負{c['n_neg']}/{c['n']} "
            f"clip={c.get('clip_rate', float('nan')):.3f}")
    log(f"  W5-1={analysis['verdict']['W5_1_any_arm']} "
        f"W5-3 arms={w51_arms} "
        f"prediction_supported={analysis['verdict']['prediction_supported']} "
        f"W5-4={w54}")
    log(f"  壁時計 {analysis['meta']['wall_min']:.1f} 分")
    log(f"saved: {tag}_results.json / {tag}_delta.npz / {tag}_analysis.json")
    os._exit(0)


if __name__ == "__main__":
    main()
