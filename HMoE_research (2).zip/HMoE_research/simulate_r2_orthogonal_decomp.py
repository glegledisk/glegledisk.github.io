# -*- coding: utf-8 -*-
"""simulate_r2_orthogonal_decomp.py — R2 オフロードにおける量子化効果と階層配置効果の直交要因分解

目的:
  10/24 独立検算 (批判レビュー §2.1) で指摘された:
  1. 「1層あたり総重みの数値誤り (250MBは予算、正しくは 454.2MB = -35.5%)」の是正
  2. 転送時間短縮 (3.54倍) のうち「量子化による削減」と「アクセス頻度に応じた階層化による削減」の直交分離

検証アーム (2x2 要因配置 + 混載):
  - Arm 1: Uniform 4bit (Base)       — 均一幅, 全Expert 4bit
  - Arm 2: Uniform 2bit              — 均一幅, 全Expert 2bit (一様量子化効果)
  - Arm 3: HMoE 4bit                 — 不均一幅, 全Expert 4bit (純粋な階層配置効果)
  - Arm 4: HMoE 2bit                 — 不均一幅, 全Expert 2bit (不均一 + 低ビット)
  - Arm 5: HMoE Tiered (提案混載)    — 不均一幅, 細いExpert FP8常駐 + 太いExpert INT2退避
"""

import os
import sys
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))

def get_base_architectures():
    d_model = 4096
    num_experts = 8
    num_layers = 32
    
    # 均一MoE (Uniform: 14336 x 8, 合計幅 114,688)
    w_uniform = np.array([14336] * num_experts)
    # HMoE (不均一等差: 合計幅 114,688)
    w_hmoe = np.array([4096, 6963, 9830, 12697, 15564, 18431, 21298, 25809])
    
    # 1Expertあたりのパラメータ数 (SwiGLU: 3 * d_model * w)
    params_uniform = 3 * d_model * w_uniform # 1.762e8 params / expert
    params_hmoe = 3 * d_model * w_hmoe
    
    # トラフィック頻度 p_e
    p_uniform = np.array([1.0 / num_experts] * num_experts)
    # HMoE実測頻度 (細いExpertに集中: rho = -0.88〜-0.98)
    p_hmoe = np.array([0.34, 0.24, 0.14, 0.10, 0.07, 0.05, 0.03, 0.03])
    p_hmoe /= p_hmoe.sum()
    
    return {
        "d_model": d_model,
        "num_experts": num_experts,
        "num_layers": num_layers,
        "uniform": {"w": w_uniform, "params": params_uniform, "p": p_uniform},
        "hmoe": {"w": w_hmoe, "params": params_hmoe, "p": p_hmoe}
    }

def configure_arm_placement(arch, arm_name, layer_budget_bytes):
    """
    与えられた予算内で HBM 常駐スロットと退避スロットを決定し、重みサイズを計算。
    """
    is_hmoe = "HMoE" in arm_name
    cfg = arch["hmoe"] if is_hmoe else arch["uniform"]
    params = cfg["params"]
    num_exp = len(params)
    
    # 各Expertのビット幅設定
    if arm_name == "Uniform_4bit":
        b_res = np.array([0.5] * num_exp)  # 4bit = 0.5 byte
        b_host = np.array([0.5] * num_exp)
    elif arm_name == "Uniform_2bit":
        b_res = np.array([0.25] * num_exp) # 2bit = 0.25 byte
        b_host = np.array([0.25] * num_exp)
    elif arm_name == "HMoE_4bit":
        b_res = np.array([0.5] * num_exp)
        b_host = np.array([0.5] * num_exp)
    elif arm_name == "HMoE_2bit":
        b_res = np.array([0.25] * num_exp)
        b_host = np.array([0.25] * num_exp)
    elif arm_name == "HMoE_Tiered":
        # 提案手法: 常駐は FP8 (1.0 byte), 退避は INT2 (0.25 byte)
        b_res = np.array([1.0] * num_exp)
        b_host = np.array([0.25] * num_exp)
    else:
        raise ValueError(f"Unknown arm: {arm_name}")
        
    # 貪欲に HBM 予算に詰める (細い/頻度の高い Expert 優先)
    # 均一は一様なので index 0 から順
    resident_mask = np.zeros(num_exp, dtype=bool)
    bytes_per_exp = np.zeros(num_exp)
    curr_hbm = 0.0
    
    for i in range(num_exp):
        size_if_res = params[i] * b_res[i]
        if curr_hbm + size_if_res <= layer_budget_bytes:
            resident_mask[i] = True
            bytes_per_exp[i] = size_if_res
            curr_hbm += size_if_res
        else:
            resident_mask[i] = False
            bytes_per_exp[i] = params[i] * b_host[i]
            
    host_mask = ~resident_mask
    
    hbm_used_mb = np.sum(bytes_per_exp[resident_mask]) / 1e6
    host_used_mb = np.sum(bytes_per_exp[host_mask]) / 1e6
    total_used_mb = hbm_used_mb + host_used_mb
    
    traffic_hit = float(np.sum(cfg["p"][resident_mask]))
    
    return {
        "arm": arm_name,
        "is_hmoe": is_hmoe,
        "cfg": cfg,
        "resident_mask": resident_mask,
        "host_mask": host_mask,
        "bytes_per_exp": bytes_per_exp,
        "hbm_used_mb": hbm_used_mb,
        "host_used_mb": host_used_mb,
        "total_used_mb": total_used_mb,
        "traffic_hit": traffic_hit,
        "num_resident": int(resident_mask.sum())
    }

def simulate_pipeline(arm_info, d_model, pcie_bw_gbps=25.0, hbm_bw_gbps=1000.0, gpu_tflops=150.0, batch_sizes=[1, 2, 4, 8, 16, 32, 64], top_k=2):
    cfg = arm_info["cfg"]
    bytes_exp = arm_info["bytes_per_exp"]
    host_mask = arm_info["host_mask"]
    res_mask = arm_info["resident_mask"]
    
    results = {
        "batch_sizes": batch_sizes,
        "transfer_mb_per_batch": [],
        "transfer_mb_per_token": [],
        "transfer_time_us": [],
        "compute_time_us": [],
        "overlap_ratio": [],
        "stall_time_us": [],
        "tpot_layer_us": []
    }
    
    for B in batch_sizes:
        # 要求 Expert の Union 確率 (1層あたり)
        p_sel = np.minimum(1.0, cfg["p"] * top_k)
        p_union = 1.0 - (1.0 - p_sel)**B
        
        batch_transfer_bytes = np.sum(p_union[host_mask] * bytes_exp[host_mask])
        transfer_mb = batch_transfer_bytes / 1e6
        
        # PCIe 転送時間 (us): 帯域律速 + 起動遅延 5us
        t_trans = (batch_transfer_bytes / (pcie_bw_gbps * 1e9)) * 1e6 + 5.0
        
        # デコード計算時間 (us):
        # 1. 演算時間
        mean_active_w = np.sum(cfg["p"] * cfg["w"])
        flops = B * top_k * 2 * d_model * mean_active_w
        t_comp_flop = (flops / (gpu_tflops * 1e12)) * 1e6
        # 2. HBM 常駐重み読み出し時間
        t_comp_mem = (np.sum(bytes_exp[res_mask]) / (hbm_bw_gbps * 1e9)) * 1e6
        t_comp = max(t_comp_flop, t_comp_mem)
        
        t_stall = max(0.0, t_trans - t_comp)
        tpot = t_comp + t_stall
        ov = t_trans / max(1e-6, t_comp)
        
        results["transfer_mb_per_batch"].append(transfer_mb)
        results["transfer_mb_per_token"].append(transfer_mb / B)
        results["transfer_time_us"].append(t_trans)
        results["compute_time_us"].append(t_comp)
        results["overlap_ratio"].append(ov)
        results["stall_time_us"].append(t_stall)
        results["tpot_layer_us"].append(tpot)
        
    return results

def run_orthogonal_decomposition():
    arch = get_base_architectures()
    d_model = arch["d_model"]
    
    # 8GB HBM 予算 (32層 -> 1層あたり 250 MB)
    total_hbm_budget_gb = 8.0
    layer_budget_bytes = (total_hbm_budget_gb * 1e9) / 32 # 250,000,000 bytes
    
    arm_names = [
        "Uniform_4bit",
        "Uniform_2bit",
        "HMoE_4bit",
        "HMoE_2bit",
        "HMoE_Tiered"
    ]
    
    arm_configs = {}
    for arm in arm_names:
        arm_configs[arm] = configure_arm_placement(arch, arm, layer_budget_bytes)
        
    # 重み配置の検算表出力
    print("=" * 105)
    print(" 1層あたりExpert重み配置とメモリ使用量（検算版）")
    print("=" * 105)
    print(f"{'Arm':16s} {'Resident':10s} {'Hit Rate':>10s} {'HBM Used':>12s} {'Host Used':>12s} {'Total Used':>12s} {'vs Uni4bit':>12s}")
    print("-" * 105)
    
    base_total = arm_configs["Uniform_4bit"]["total_used_mb"]
    weight_summary = []
    
    for arm in arm_names:
        info = arm_configs[arm]
        hbm_m = info["hbm_used_mb"]
        host_m = info["host_used_mb"]
        tot_m = info["total_used_mb"]
        hit = info["traffic_hit"] * 100
        n_res = f"{info['num_resident']}/8"
        diff_pct = (tot_m - base_total) / base_total * 100
        
        print(f"{arm:16s} {n_res:10s} {hit:9.1f}% {hbm_m:10.1f} MB {host_m:10.1f} MB {tot_m:10.1f} MB {diff_pct:11.1f}%")
        weight_summary.append({
            "arm": arm,
            "num_resident": info["num_resident"],
            "traffic_hit_pct": hit,
            "hbm_used_mb": hbm_m,
            "host_used_mb": host_m,
            "total_used_mb": tot_m,
            "diff_vs_uni4bit_pct": diff_pct
        })
        
    # パイプラインシミュレーション実行 (PCIe Gen4: 25GB/s)
    pcie_bw = 25.0
    batch_sizes = [1, 2, 4, 8, 16, 32, 64]
    sim_results = {}
    
    for arm in arm_names:
        res = simulate_pipeline(arm_configs[arm], d_model, pcie_bw_gbps=pcie_bw, batch_sizes=batch_sizes)
        sim_results[arm] = res
        
    # 要因分解テーブル (B=1 と B=8 の転送量・転送時間)
    print("\n" + "=" * 105)
    print(" 転送量・転送時間の要因分解 (PCIe Gen4: 25 GB/s)")
    print("=" * 105)
    print(f"{'Arm':16s} {'B=1 Trans(MB)':>15s} {'B=1 Time(us)':>14s} {'B=1 Ov-Ratio':>14s} {'B=8 Trans(MB)':>15s} {'B=8 Time(us)':>14s} {'B=8 Ov-Ratio':>14s}")
    print("-" * 105)
    
    decomp_rows = []
    for arm in arm_names:
        r = sim_results[arm]
        mb_b1 = r["transfer_mb_per_batch"][0]
        t_b1 = r["transfer_time_us"][0]
        ov_b1 = r["overlap_ratio"][0]
        
        mb_b8 = r["transfer_mb_per_batch"][3] # index 3 is B=8
        t_b8 = r["transfer_time_us"][3]
        ov_b8 = r["overlap_ratio"][3]
        
        print(f"{arm:16s} {mb_b1:15.2f} {t_b1:14.1f} {ov_b1:14.2f} {mb_b8:15.2f} {t_b8:14.1f} {ov_b8:14.2f}")
        decomp_rows.append({
            "arm": arm,
            "mb_b1": mb_b1,
            "time_b1_us": t_b1,
            "overlap_b1": ov_b1,
            "mb_b8": mb_b8,
            "time_b8_us": t_b8,
            "overlap_b8": ov_b8
        })
        
    # 直交要因効果の定式化計算 (B=1 の転送バイト数)
    t_base = sim_results["Uniform_4bit"]["transfer_mb_per_batch"][0]
    t_u2 = sim_results["Uniform_2bit"]["transfer_mb_per_batch"][0]
    t_h4 = sim_results["HMoE_4bit"]["transfer_mb_per_batch"][0]
    t_h2 = sim_results["HMoE_2bit"]["transfer_mb_per_batch"][0]
    t_tiered = sim_results["HMoE_Tiered"]["transfer_mb_per_batch"][0]
    
    print("\n" + "=" * 105)
    print(" 直交効果の寄与度分解 (B=1 転送量削減: 132.12 MB -> 37.28 MB, 総削減 Δ = 94.84 MB)")
    print("=" * 105)
    
    # 1. 純粋な階層配置効果 (4bit固定での比較: Uniform 4bit -> HMoE 4bit)
    delta_tier_4bit = t_base - t_h4
    # 2. 純粋な量子化効果 (均一での比較: Uniform 4bit -> Uniform 2bit)
    delta_quant_uni = t_base - t_u2
    # 3. 2bit固定での階層配置効果 (Uniform 2bit -> HMoE 2bit)
    delta_tier_2bit = t_u2 - t_h2
    # 4. HMoE固定での量子化効果 (HMoE 4bit -> HMoE 2bit)
    delta_quant_hmoe = t_h4 - t_h2
    # 5. 提案 HMoE Tiered (細FP8/太INT2) の削減量
    delta_tiered = t_base - t_tiered
    
    print(f"1. 純粋階層効果 (4bit固定):   {delta_tier_4bit:6.2f} MB 削減 ({delta_tier_4bit / t_base * 100:5.1f}% 減) [Uniform 4bit -> HMoE 4bit]")
    print(f"2. 純粋量子化効果 (均一固定): {delta_quant_uni:6.2f} MB 削減 ({delta_quant_uni / t_base * 100:5.1f}% 減) [Uniform 4bit -> Uniform 2bit]")
    print(f"3. 2bit固定での階層効果:      {delta_tier_2bit:6.2f} MB 削減 ({delta_tier_2bit / t_u2 * 100:5.1f}% 減) [Uniform 2bit -> HMoE 2bit]")
    print(f"4. 提案 HMoE Tiered 総削減:   {delta_tiered:6.2f} MB 削減 ({delta_tiered / t_base * 100:5.1f}% 減) [3.54倍短縮]")
    print(f"   - そのうち階層配置 (Hit率 25% -> 58%) の寄与: 約 {delta_tier_4bit / delta_tiered * 100:5.1f}%")
    print(f"   - そのうち量子化 (INT2化) の寄与:               約 {(delta_tiered - delta_tier_4bit) / delta_tiered * 100:5.1f}%")

    # JSON および CSV 保存
    df_weight = pd.DataFrame(weight_summary)
    df_weight.to_csv(os.path.join(HERE, "r2_weight_placement_audit.csv"), index=False)
    
    df_decomp = pd.DataFrame(decomp_rows)
    df_decomp.to_csv(os.path.join(HERE, "r2_orthogonal_decomp_summary.csv"), index=False)
    
    full_export = {
        "weight_summary": weight_summary,
        "decomposition_summary": decomp_rows,
        "factor_breakdown": {
            "total_reduction_mb": delta_tiered,
            "tiering_contribution_mb": delta_tier_4bit,
            "tiering_contribution_pct": delta_tier_4bit / delta_tiered * 100,
            "quantization_contribution_mb": delta_tiered - delta_tier_4bit,
            "quantization_contribution_pct": (delta_tiered - delta_tier_4bit) / delta_tiered * 100
        },
        "simulation_details": sim_results
    }
    with open(os.path.join(HERE, "r2_orthogonal_decomposition_results.json"), "w", encoding="utf-8") as f:
        json.dump(full_export, f, indent=2)
        
    print(f"\nSaved CSVs and JSON successfully.")
    
    # 可視化プロット作成
    plot_decomposition(sim_results, batch_sizes)

def plot_decomposition(sim_results, batch_sizes):
    fig, axes = plt.subplots(1, 2, figsize=(16, 6))
    
    colors = {
        "Uniform_4bit": "#d62728", # red
        "Uniform_2bit": "#ff7f0e", # orange
        "HMoE_4bit": "#1f77b4",    # blue
        "HMoE_2bit": "#aec7e8",    # light blue
        "HMoE_Tiered": "#2ca02c"   # green
    }
    markers = {
        "Uniform_4bit": "o",
        "Uniform_2bit": "s",
        "HMoE_4bit": "^",
        "HMoE_2bit": "v",
        "HMoE_Tiered": "D"
    }
    
    # 図 1: 転送量 (MB/batch) vs Batch Size
    ax1 = axes[0]
    for arm, res in sim_results.items():
        ax1.plot(batch_sizes, res["transfer_mb_per_batch"], marker=markers[arm], color=colors[arm], label=arm, lw=2)
    ax1.set_xscale("log", base=2)
    ax1.set_xlabel("Batch Size B")
    ax1.set_ylabel("PCIe Transfer Volume per Layer (MB)")
    ax1.set_title("PCIe Transfer Volume vs Batch Size (Orthogonal Decomposition)")
    ax1.grid(True, which="both", ls="--", alpha=0.5)
    ax1.legend()
    
    # 図 2: Overlap Ratio vs Batch Size
    ax2 = axes[1]
    for arm, res in sim_results.items():
        ax2.plot(batch_sizes, res["overlap_ratio"], marker=markers[arm], color=colors[arm], label=arm, lw=2)
    ax2.axhline(1.0, color='black', linestyle='--', label="Zero-bubble Limit (1.0)")
    ax2.set_xscale("log", base=2)
    ax2.set_yscale("log")
    ax2.set_xlabel("Batch Size B")
    ax2.set_ylabel("Overlap Ratio (T_transfer / T_compute)")
    ax2.set_title("Overlap Ratio vs Batch Size (Values < 1.0 achieve Full Hiding)")
    ax2.grid(True, which="both", ls="--", alpha=0.5)
    ax2.legend()
    
    plt.tight_layout()
    out_png = os.path.join(HERE, "r2_orthogonal_decomposition_frontier.png")
    plt.savefig(out_png, dpi=200)
    print(f"Saved plot to {out_png}")

if __name__ == "__main__":
    run_orthogonal_decomposition()
