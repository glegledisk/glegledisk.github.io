#!/usr/bin/env python3
"""A4: 仮説「小 expert に ReLU² を置くのが正しい」の検証。

由来: `考察_HMoEに最適な活性化関数_20261101.md` §4 の反転（小 expert が主力・幅が最も制約・
高頻度だから死から回復できる、という 3 つの理由）。ユーザの当初案は逆（大に ReLU²）だった。

この比較の強み
  **ReLU も ReLU² も 2 行列**なので、幅・パラメータ数・MACs が**完全に同一**。
  変わるのは非線形性だけで、しかも**どの expert 群に置くか**を分離できる。
  → A1/A3 のような「パラメータ数との交絡」が原理的に無い。

設計（2×2: 小の活性化 × 大の活性化）
  arm            小 (e0,e1, w=32)   大 (e6,e7, w=224)   中 (e2..e5)
  all_relu       ReLU               ReLU                ReLU
  small_relu2    **ReLU²**          ReLU                ReLU     ← 仮説
  large_relu2    ReLU               **ReLU²**           ReLU     ← 元の案（逆）
  all_relu2      ReLU²              ReLU²               ReLU²

gain 補正はしない（raw 初期化）。A1 で `relu2`(gain 1.62) は iv 0.039、
`relu2_raw`(gain 1.0) は 0.121 だったので、**raw の方が ReLU² に有利**。
不利な設定で勝てないなら結論は頑健、という読みで片側に振る。

出力: data/a4/{arm}_s{seed}.json, a4_results{tag}.json
"""
import argparse
import json
import os
import sys
import time
import traceback

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import q1_trace_routing as Q1                        # noqa: E402
from a1_activation_ffn import (ActMoE, Adam, BASE_W, evaluate,   # noqa: E402
                               per_expert_rms)

OUTDIR = os.path.join(HERE, "data", "a4")
SMALL = (0, 1)
LARGE = (6, 7)
# 「中間を厚くする」別ベクトル（合計 1024 を保つ）。幅順 = e2..e5 > e6,e7 > e0,e1
W_MID = (32, 32, 192, 192, 192, 192, 96, 96)


def acts_for(arm):
    a = ["relu"] * len(BASE_W)
    if arm == "all_relu":
        pass
    elif arm == "small_relu2":
        for i in SMALL:
            a[i] = "relu2"
    elif arm == "large_relu2":
        for i in LARGE:
            a[i] = "relu2"
    elif arm == "all_relu2":
        a = ["relu2"] * len(BASE_W)
    elif arm.startswith("deg_e"):        # 1 個だけ劣化させる（弾性の測定用）
        a[int(arm[len("deg_e"):])] = "relu2"
    elif arm.startswith("wide"):         # 幅の広い順に k 個（冗長性の予算）
        k = int(arm[len("wide"):])
        order = sorted(range(len(BASE_W)), key=lambda i: -BASE_W[i])   # 幅の降順
        for i in order[:k]:
            a[i] = "relu2"
    elif arm == "mid_base":              # 別ベクトル（W_MID）のベースライン
        pass
    elif arm.startswith("mid_wide"):     # 別ベクトルで幅の広い順に k 個
        k = int(arm[len("mid_wide"):])
        order = sorted(range(len(W_MID)), key=lambda i: -W_MID[i])
        for i in order[:k]:
            a[i] = "relu2"
    else:
        raise ValueError(arm)
    return a


ARMS = ["all_relu", "small_relu2", "large_relu2", "all_relu2"]


def widths_of(arm, scale):
    base = W_MID if arm.startswith("mid_") else BASE_W
    return tuple(max(4, int(round(w * scale))) for w in base)


@torch.no_grad()
def routing_snapshot(model, seq, bs=128):
    """top-1 の使用率（層平均）と、小 expert の選択率。"""
    E = model.E
    tot = np.zeros(E)
    small = 0.0
    n = 0
    for i in range(0, seq.shape[0], bs):
        x = torch.from_numpy(seq[i:i + bs])
        _, _, idxs = model(x, aux_mode="none", need_idx=True)
        for ti in idxs:
            a = ti[:, :, 0].numpy().ravel()
            tot += np.bincount(a, minlength=E)
            small += float(np.isin(a, SMALL).mean())
            n += 1
    return {"usage": (tot / tot.sum()).round(4).tolist(), "small_share": small / max(n, 1)}


def run_one(arm, seed, scale, n_seqs, epochs, bs, lr, auxw, gain="raw", eval_every=1, tag="",
            widths_override=None, act_override=None, model_out=None,
            complete_gain_map=False):
    torch.set_num_threads(1)
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    # QA1S2: None なら既存挙動を 1 bit も変えない。タプル / リストが渡されたときだけ差し替える。
    widths = tuple(widths_override) if widths_override is not None else widths_of(arm, scale)
    acts = list(act_override) if act_override is not None else acts_for(arm)
    model = ActMoE(widths, "relu", seed=seed, act_i=acts)

    # --- expert ごとの gain 校正（(l,i) 単位）---
    gain_info = {"mode": gain, "n": 0, "min": 1.0, "max": 1.0}
    if gain == "matched":
        cal_rng = np.random.default_rng(999)
        cal_seq, _ = Q1.make_trace_batch(cal_rng, 128)
        ref = ActMoE(widths, "relu", seed=seed, act_i=["relu"] * len(widths))
        r_ref = per_expert_rms(ref, cal_seq)
        r_arm = per_expert_rms(model, cal_seq)
        gl = {k: r_ref[k] / max(r_arm.get(k, r_ref[k]), 1e-12) for k in r_ref}
        # QA1S4: expose all position keys while preserving the existing fallback value.
        # Summary statistics below intentionally remain based on the measured gl only.
        gl_pos = ({(l, i): gl.get((l, i), 1.0)
                   for l in range(model.L) for i in range(model.E)}
                  if complete_gain_map else gl)
        model.gain_l = gl_pos
        vals = list(gl.values())
        by_exp = [sum(gl[(l, i)] for l in range(model.L)) / model.L
                  for i in range(model.E) if all((l, i) in gl for l in range(model.L))]
        gain_info = {"mode": gain, "n": len(vals), "min": min(vals), "max": max(vals),
                     "mean": sum(vals) / len(vals),
                     "by_expert": [round(v, 4) for v in by_exp],
                     # QA1 Step 1: (l,i) の生配列を保存する（A4b は層平均だけ残していた）。
                     # キーは "l,i" の文字列。既存キーは一切変更しない（後方互換）。
                     "by_position": {f"{l},{i}": float(gl_pos[(l, i)])
                                     for l in range(model.L) for i in range(model.E)
                                     if (l, i) in gl_pos}}

    opt = Adam(model.params(), lr=lr)
    nparam = sum(v.numel() for v in model.params().values())

    steps_per_ep = max(1, n_seqs // bs)
    t0 = time.time()
    hist, evals = [], []
    ev_rng = np.random.default_rng(777)
    ev_seq, ev_typ = Q1.make_trace_batch(ev_rng, 1024)
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps_per_ep):
            seq, _ = Q1.make_trace_batch(rng, bs)
            x = torch.from_numpy(seq)
            logits, aux, _ = model(x, aux_mode="p_pen")
            loss = Q1.trace_loss(logits, seq) + auxw * aux
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        hist.append(run / steps_per_ep)
        if (ep + 1) % eval_every == 0 or ep == epochs - 1:
            ev, _ = evaluate(model, ev_seq, ev_typ)
            ev["ep"] = ep + 1
            evals.append(ev)

    snap = routing_snapshot(model, ev_seq)
    out = {"arm": arm, "seed": seed, "scale": scale, "widths": list(widths),
           "act_i": acts, "nparam": nparam, "n_mat": 2, "gain": gain_info,
           "loss_hist": hist, "evals": evals, "routing": snap,
           "sec": round(time.time() - t0, 1)}
    os.makedirs(OUTDIR, exist_ok=True)
    with open(os.path.join(OUTDIR, f"{arm}_s{seed}{tag}.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    # QA1S2 本番: 3 点対照を同一 ckpt で評価するため、呼び出し側へモデルを渡す。
    # 省略時は None で、既存の呼び出し規約・返り値は 1 bit も変わらない。
    if model_out is not None:
        model_out.append(model)
    return out


def _worker(job):
    try:
        return run_one(**job)
    except Exception:
        return {"arm": job.get("arm"), "seed": job.get("seed"),
                "error": traceback.format_exc()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", nargs="+", default=ARMS)
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4, 5])
    ap.add_argument("--scale", type=float, default=1.0)
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--auxw", type=float, default=0.05)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--gain", choices=["raw", "matched"], default="raw", help="expert ごとの分岐 RMS を ReLU に揃えるか")
    ap.add_argument("--tag", default="")
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()

    os.makedirs(OUTDIR, exist_ok=True)
    if args.smoke:
        args.arms, args.seeds, args.epochs, args.workers = ["all_relu", "small_relu2"], [0], 1, 2

    kw = dict(scale=args.scale, n_seqs=args.seqs, epochs=args.epochs, bs=args.bs,
              lr=args.lr, auxw=args.auxw, eval_every=1, gain=args.gain, tag=args.tag)
    jobs = [dict(arm=a, seed=s, **kw) for a in args.arms for s in args.seeds]
    print(f"scale={args.scale} gain={args.gain} arms={len(args.arms)} seeds={len(args.seeds)} jobs={len(jobs)}",
          flush=True)
    for a in args.arms:
        print(f"  {a:12s} {acts_for(a)}", flush=True)

    from concurrent.futures import ProcessPoolExecutor, as_completed
    rows, t0 = [], time.time()
    with ProcessPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(_worker, j): j for j in jobs}
        for k, fu in enumerate(as_completed(futs), 1):
            r = fu.result()
            if "error" in r:
                print(f"[FAIL] {r.get('arm')} s{r.get('seed')}\n{r['error']}", flush=True)
                continue
            rows.append(r)
            e = r["evals"][-1]
            print(f"[{k}/{len(jobs)}] {r['arm']:12s} s{r['seed']} CE={e['ce_all']:.4f} "
                  f"iv={e['instr_valid']:.3f} small={r['routing']['small_share']:.3f} "
                  f"({r['sec']:.0f}s, tot {time.time()-t0:.0f}s)", flush=True)

    with open(os.path.join(OUTDIR, f"a4_results{args.tag}.json"), "w", encoding="utf-8") as fh:
        json.dump(rows, fh, ensure_ascii=False, indent=2)
    print(f"\n[write] {OUTDIR} ({time.time()-t0:.0f}s)", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
