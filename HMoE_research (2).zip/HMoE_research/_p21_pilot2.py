# -*- coding: utf-8 -*-
"""P21 パイロット 2: 量子化が効いているか + 最小出力（8 token）での正解率（使い捨て）

base LM は「Answer: N」の後に延々と例を続けてしまう。max_new_tokens=8 で
数字だけ出させたときに当たるかを見る。当たらなければ best-of-N の解析は成立しない。
"""
import os
import re
import time

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "olmoe-1b-7b")
VAL_RE = re.compile(r"-?\d+")
OUT = []


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def main():
    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig
    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    bnb = BitsAndBytesConfig(load_in_4bit=True, bnb_4bit_compute_dtype=torch.bfloat16,
                             bnb_4bit_quant_type="nf4", bnb_4bit_use_double_quant=True)
    t0 = time.time()
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, quantization_config=bnb, device_map="cuda", attn_implementation="sdpa").eval()
    log("load %.0fs" % (time.time() - t0))
    # 量子化の実効を確認
    dts = {}
    for n, p in model.named_parameters():
        dts[str(p.dtype)] = dts.get(str(p.dtype), 0) + p.numel()
    log("param dtypes: %s" % {k: "%.2fB" % (v / 1e9) for k, v in dts.items()})
    log("gpu allocated=%.2fGB reserved=%.2fGB"
        % (torch.cuda.memory_allocated() / 1e9, torch.cuda.memory_reserved() / 1e9))
    try:
        import bitsandbytes as bnb_mod
        log("bitsandbytes %s" % getattr(bnb_mod, "__version__", "?"))
    except Exception as e:                                    # noqa: BLE001
        log("bnb import failed: %s" % e)

    few = ("Compute 21 + 34.\nAnswer: 55\n"
           "Compute 108 + 7.\nAnswer: 115\n"
           "Compute 4002 + 31.\nAnswer: 4033\n"
           "Compute 612 + 87.\nAnswer: 699\n")
    probs = []
    for a, b in [(12345, 67890), (48213, 5917), (30617, 45289), (71804, 2653),
                 (55019, 37264), (12093, 88071), (63428, 15907), (27651, 61348),
                 (40082, 31975), (85916, 10437)]:
        probs.append((a, b, str(a + b)))

    for mode in ["greedy", "sample"]:
        t0 = time.time()
        ntok, ok = 0, 0
        outs = []
        for a, b, gold in probs:
            pr = "%sCompute %d + %d.\nAnswer:" % (few, a, b)
            enc = tok(pr, return_tensors="pt", add_special_tokens=False).to(model.device)
            with torch.no_grad():
                o = model.generate(**enc, max_new_tokens=8,
                                   do_sample=(mode == "sample"),
                                   temperature=0.9, top_p=0.95,
                                   pad_token_id=tok.pad_token_id)
            ids = o[0, enc["input_ids"].shape[1]:].tolist()
            txt = tok.decode([t for t in ids if t != tok.pad_token_id],
                             skip_special_tokens=True)
            ntok += len(ids)
            nums = VAL_RE.findall(txt.replace(",", ""))
            pred = nums[0] if nums else None
            ok += int(pred == gold)
            outs.append((a, b, gold, pred, txt.strip()[:40]))
        dt = time.time() - t0
        log("\n[%s] %.1fs  %d tok  %.2f tok/s  correct=%d/%d"
            % (mode, dt, ntok, ntok / max(dt, 1e-9), ok, len(probs)))
        for o_ in outs:
            log("   %d + %d = %s | pred=%s | %r" % o_)

    with open(os.path.join(HERE, "_p21_pilot2_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    os._exit(0)


if __name__ == "__main__":
    main()
