fits = {
    "MI  distilled": (2.706e7, -0.407427, 0.9016),
    "EOT distilled": (2.734e7, -0.404740, 0.8983),
    "Bytes supervised": (4.467e6, -0.365844, 0.8967),
    "EOT  supervised": (3.080e6, -0.354594, 0.8891),
}
def f(k, x):
    b, a, c = fits[k]
    return b * x ** a + c

def bisect(fn, lo, hi, it=300):
    flo, fhi = fn(lo), fn(hi)
    for _ in range(it):
        mid = (lo * hi) ** 0.5
        fm = fn(mid)
        if (fm > 0) == (flo > 0):
            lo, flo = mid, fm
        else:
            hi, fhi = mid, fm
    return (lo * hi) ** 0.5

print("=== asymptotic term c decomposition ===")
dc_sup = fits["Bytes supervised"][2] - fits["EOT  supervised"][2]
dc_dis = fits["MI  distilled"][2] - fits["EOT distilled"][2]
pen_mi = fits["MI  distilled"][2] - fits["Bytes supervised"][2]
pen_eot = fits["EOT distilled"][2] - fits["EOT  supervised"][2]
print(f"supervised pair  dc = {dc_sup:+.4f}   (compute/structure only)")
print(f"distilled  pair  dc = {dc_dis:+.4f}   (compute + exactness)")
print(f"distill penalty MI  = {pen_mi:+.4f}")
print(f"distill penalty EOT = {pen_eot:+.4f}   (diff {pen_eot-pen_mi:+.4f})")
print(f"check: {-dc_sup:+.4f} + {pen_eot-pen_mi:+.4f} = {-dc_dis:+.4f}")

print("\n=== MI vs EOT(distilled) curves ===")
for x in [1e22, 1e23, 2.04e23, 1e24]:
    print(f"x={x:.2e}  MI={f('MI  distilled',x):.4f}  EOT={f('EOT distilled',x):.4f}  d={f('EOT distilled',x)-f('MI  distilled',x):+.4f}")
xc = bisect(lambda x: f("EOT distilled", x) - f("MI  distilled", x), 1e20, 1e26)
print(f"crossing x* = {xc:.3e} FLOPs")

print("\n=== compute-equivalent multiplier at fixed BPB ===")
x0 = 2.04e23
y0 = f("EOT distilled", x0)
x_mi = bisect(lambda x: f("MI  distilled", x) - y0, 1e21, 1e27)
print(f"BPB={y0:.4f}: EOT {x0:.3e} / MI {x_mi:.3e} -> MI needs {x_mi/x0:.2f}x")
print(f"EOT compute surcharge = 1.309x -> net {x_mi/x0/1.309:.2f}x")

y1 = f("EOT  supervised", x0)
x_b = bisect(lambda x: f("Bytes supervised", x) - y1, 1e21, 1e27)
print(f"supervised: BPB={y1:.4f}: EOT-sup {x0:.3e} / Bytes-sup {x_b:.3e} -> {x_b/x0:.2f}x")
