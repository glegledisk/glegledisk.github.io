# -*- coding: utf-8 -*-
"""P23: cap 4096 で thinking の完走率はどこまで上がるか（P22 の宿題）

P20/P22 は cap 2048 で打ち切り 70%（`</think>` 26/80）だった。P22 は
「被覆 0.65 は予算の関数であってモデルの性質ではない」と書いた。本測定はその予算を
2 倍にして完走率を測る。

設計の要点（厳密な延長であることの検証）:
  P20 と同一の問題列・同一 seed・同一バッチ幅（4）で生成する。自己回帰サンプリングは
  1 step ごとに同じ乱数を消費するので、**cap 4096 の生成の先頭 2048 token は
  cap 2048 の生成と一致するはず**。P20 が保存した text を接頭辞として突き合わせ、
  一致率を検査する（一致しなければ「別のサンプルを引いた」ことになり比較が崩れる）。

  問題数を 10 に減らすのは、乱数が問題ループを跨いで進むため**先頭 10 問は P20 と同一**
  になるから（seed はラウンド先頭で 1 回だけ打つ）。

出力: p23_cap4096.jsonl / p23_meta.json
"""

import argparse
import json
import os
import re

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "qwen3-0.6b")
SYS = "You are a careful arithmetic assistant. Solve the problem and give the final answer."
END = "</" + "think>"
NUM_RE = re.compile(r"\d[\d,]*")


def log(m):
    print(m, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_prob", type=int, default=10)
    ap.add_argument("--n_samp", type=int, default=4)
    ap.add_argument("--cap", type=int, default=4096)
    ap.add_argument("--seed", type=int, default=31)
    ap.add_argument("--tag", type=str, default="p23")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer
    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, torch_dtype=torch.bfloat16, device_map="cuda",
        attn_implementation="sdpa").eval()

    # P20 と同じ問題列（20 問作って先頭を使う）
    import random
    rnd = random.Random(args.seed)
    probs = []
    for _ in range(20):
        a, b = rnd.randint(10001, 99999), rnd.randint(10001, 99999)
        probs.append({"q": "Compute %d + %d." % (a, b), "gold": str(a + b)})
    probs = probs[:args.n_prob]

    prompts = [tok.apply_chat_template(
        [{"role": "system", "content": SYS}, {"role": "user", "content": p["q"]}],
        tokenize=False, add_generation_prompt=True, enable_thinking=True) for p in probs]

    # P20 の参照（接頭辞検査用）
    p20 = {}
    with open(os.path.join(HERE, "p20_think.jsonl"), encoding="utf-8") as fp:
        for line in fp:
            r = json.loads(line)
            if r.get("round") == "greedy":
                continue
            p20[r["q"]] = r["samples"]

    recs = []
    torch.manual_seed(args.seed + 100)
    for i, p in enumerate(probs):
        enc = tok([prompts[i]] * args.n_samp, return_tensors="pt",
                  padding=True, add_special_tokens=False).to(model.device)
        with torch.no_grad():
            o = model.generate(**enc, max_new_tokens=args.cap, do_sample=True,
                               temperature=0.9, top_p=0.95,
                               pad_token_id=tok.pad_token_id)
        gen = o[:, enc["input_ids"].shape[1]:]
        samples = []
        for j in range(args.n_samp):
            ids = [t for t in gen[j].tolist() if t != tok.pad_token_id]
            txt = tok.decode(ids, skip_special_tokens=True)
            has_end = END in txt
            pred = None
            if has_end:
                region = txt[txt.rfind(END) + len(END):]
                m = NUM_RE.findall(region)
                pred = m[-1].replace(",", "") if m else None
            ref = p20[p["q"]][j]
            samples.append({
                "ntok": len(ids), "finished": len(ids) < args.cap,
                "has_end": has_end, "pred_ans": pred,
                "correct_ans": None if pred is None else (pred == p["gold"]),
                "prefix_match": txt.startswith(ref["text"]),
                "ref_ntok": ref["ntok"], "ref_finished": ref["finished"],
                "text": txt})
        recs.append({"round": 0, "q": p["q"], "gold": p["gold"], "samples": samples})
        log("%d/%d done  (%s)" % (i + 1, len(probs), p["q"]))

    S = [s for r in recs for s in r["samples"]]
    meta = {"n_prob": len(probs), "n_samp": args.n_samp, "cap": args.cap,
            "seed": args.seed, "n_samples": len(S),
            "finished_rate": float(np.mean([s["finished"] for s in S])),
            "has_end_rate": float(np.mean([s["has_end"] for s in S])),
            "median_ntok": float(np.median([s["ntok"] for s in S])),
            "mean_ntok": float(np.mean([s["ntok"] for s in S])),
            "prefix_match_rate": float(np.mean([s["prefix_match"] for s in S])),
            "n_prefix_checkable": int(sum(1 for s in S if s["ref_ntok"] == 2048)),
            "note": "P20 と同一 seed・同一問題列の先頭 10 問。cap だけ 2048 -> 4096",
            "model": MODEL}
    with open(os.path.join(HERE, "%s_cap4096.jsonl" % args.tag), "w", encoding="utf-8") as fp:
        for r in recs:
            fp.write(json.dumps(r, ensure_ascii=False) + "\n")
    with open(os.path.join(HERE, "%s_meta.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(meta, fp, ensure_ascii=False, indent=2)
    log(json.dumps(meta, ensure_ascii=False))
    os._exit(0)


if __name__ == "__main__":
    main()
