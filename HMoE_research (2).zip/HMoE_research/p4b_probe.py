"""
P4b: 「このトークンに計算を割く価値があるか」を予測できるか（probe 解析）

ターゲット（未来）:
  nll_j : baseline (top-8) の per-token NLL ＝ token j+1 の予測困難度
  d_j   : top-6 に削ったときの NLL 増分 ＝ 計算を削るコスト（決定に直接効く量）

特徴量（すべて位置 j で因果的に入手可能）:
  gate_l  : 層 l のルータ logit（64 次元）
  gstat_l : その要約（max, mean, std, top8 の和＝保持質量, softmax エントロピー, 0 超えの数）
  h_l     : 隠れ状態（ランダム射影で 256 次元に落とす）
  hist    : 履歴統計（前位置の NLL・エントロピー・正解、直近 8/32/64 の平均 NLL、
            現トークンの窓内頻度、位置、窓内の累積正解率）
  tok     : 現トークン ID（h0 が事実上の埋め込みなので、ID そのものは別途 one-hot せず h0 で代替）

評価:
  窓単位の 5 分割 CV（隣接トークンの漏れを防ぐ）
  AUC（d_j 上位 25% を当てる）/ Spearman / R²
  さらに「予算 f で k=8 に保護する」決定規則としての達成 ΔCE を oracle / probe / random で比較

実行:
  python p4b_probe.py
"""

import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
N_FOLD = 5


# ---------- 基本ツール ----------

def auc_score(y, s):
    """Mann-Whitney の AUC。"""
    y = np.asarray(y, dtype=bool)
    order = np.argsort(s, kind="mergesort")
    ranks = np.empty(len(s), dtype=np.float64)
    ranks[order] = np.arange(1, len(s) + 1, dtype=np.float64)
    n1 = int(y.sum())
    n0 = len(y) - n1
    if n1 == 0 or n0 == 0:
        return float("nan")
    return (ranks[y].sum() - n1 * (n1 + 1) / 2.0) / (n1 * n0)


def spearman(a, b):
    ra = np.argsort(np.argsort(a)).astype(np.float64)
    rb = np.argsort(np.argsort(b)).astype(np.float64)
    ra -= ra.mean()
    rb -= rb.mean()
    return float((ra * rb).sum() / np.sqrt((ra ** 2).sum() * (rb ** 2).sum()))


def ridge_fit_predict(Xtr, ytr, Xte, lam=10.0):
    mu = Xtr.mean(0)
    sd = Xtr.std(0) + 1e-8
    A = (Xtr - mu) / sd
    B = (Xte - mu) / sd
    ym = ytr.mean()
    d = A.shape[1]
    if d <= A.shape[0]:
        w = np.linalg.solve(A.T @ A + lam * np.eye(d), A.T @ (ytr - ym))
    else:
        a = np.linalg.solve(A @ A.T + lam * np.eye(A.shape[0]), ytr - ym)
        w = A.T @ a
    return B @ w + ym


def cv_predict(X, y, groups, lam=10.0):
    pred = np.zeros(len(y))
    for f in range(N_FOLD):
        te = (groups % N_FOLD) == f
        tr = ~te
        pred[te] = ridge_fit_predict(X[tr], y[tr], X[te], lam)
    return pred


def randproj(n_in, n_out, seed=0):
    rng = np.random.RandomState(seed)
    return (rng.randn(n_in, n_out) / np.sqrt(n_out)).astype(np.float32)


# ---------- 特徴量 ----------

def gate_stats(G):
    """ルータ logit (n, 64) の要約。"""
    z = G.astype(np.float64)
    p = np.exp(z - z.max(1, keepdims=True))
    p /= p.sum(1, keepdims=True)
    top8 = np.sort(p, axis=1)[:, -8:]
    out = np.stack([
        z.max(1), z.mean(1), z.std(1),
        top8.sum(1),                       # 保持質量（top-8 の確率和）
        -(p * np.log(p + 1e-12)).sum(1),   # ルータのエントロピー
        (z > 0).sum(1).astype(np.float64),
        z.max(1) - np.median(z, axis=1),   # マージン
    ], axis=1)
    return out


def build_features(d):
    n = d["nll"].size
    win = d["win"]
    pos = d["pos"]
    cur = d["curid"]

    # 履歴統計（因果的: 位置 j より前だけ）
    def shift_within(x, k=1, fill=0.0):
        out = np.full_like(x, fill, dtype=np.float64)
        out[k:] = x[:-k]
        out[:k] = fill
        # 窓の先頭は埋める
        out[pos < k] = fill
        return out

    nll = d["nll"].astype(np.float64)
    ent = d["ent"].astype(np.float64)
    t1 = d["top1"].astype(np.float64)
    prev_nll = shift_within(nll, 1, nll.mean())
    prev_ent = shift_within(ent, 1, ent.mean())
    prev_t1 = shift_within(t1, 1, t1.mean())

    # 直近の移動平均（位置 j より前、窓をまたがない）
    def movavg(x, k, fill):
        out = np.empty_like(x, dtype=np.float64)
        for w in np.unique(win):
            sel = np.where(win == w)[0]
            xs = x[sel]
            c = np.concatenate([[0.0], np.cumsum(xs)])
            for i in range(len(xs)):
                lo = max(0, i - k)
                cnt = i - lo
                out[sel[i]] = (c[i] - c[lo]) / cnt if cnt > 0 else fill
        return out

    ma8 = movavg(nll, 8, nll.mean())
    ma32 = movavg(nll, 32, nll.mean())
    ma64 = movavg(nll, 64, nll.mean())

    # 現トークンの窓内頻度（因果的: j までに何回出たか）
    freq = np.zeros(n)
    for w in np.unique(win):
        sel = np.where(win == w)[0]
        ids = cur[sel]
        seen = {}
        for idx, t in zip(sel, ids):
            seen[t] = seen.get(t, 0) + 1
            freq[idx] = seen[t]
    freq = np.log1p(freq)

    hist = np.stack([prev_nll, prev_ent, prev_t1, ma8, ma32, ma64, freq,
                     pos.astype(np.float64), np.log1p(pos.astype(np.float64))], axis=1)

    feats = {"hist": hist}

    # ルータ
    for l in (0, 4, 8, 12, 15):
        G = d["gate_%d" % l]
        feats["gate%d" % l] = G.astype(np.float32)
        feats["gstat%d" % l] = gate_stats(G)

    # 隠れ状態（ランダム射影）
    for l in (0, 8, 15):
        H = d["h%d" % l].astype(np.float32)
        R = randproj(H.shape[1], 256, seed=100 + l)
        feats["h%d" % l] = (H @ R).astype(np.float32)

    return feats, win


# ---------- 主 ----------

def main():
    d = np.load(os.path.join(HERE, "p4_feats.npz"), allow_pickle=True)
    p3 = np.load(os.path.join(HERE, "p3_topk_nll.npz"))
    nll_base = p3["k8"]
    nll_k6 = p3["k6"]
    assert np.allclose(d["nll"], nll_base), "baseline NLL が P3 と一致しない"
    d_j = nll_k6 - nll_base
    nll_j = nll_base

    print("n = %d  d_j mean %+.5f  frac(d_j>0.1) = %.3f" % (nll_j.size, d_j.mean(), (d_j > 0.1).mean()))

    feats, win = build_features(d)
    print("features:", {k: v.shape for k, v in feats.items()})

    # ターゲット 2 種
    targets = {
        "nll_j": (nll_j, np.quantile(nll_j, 0.75)),   # 難易度（絶対）
        "d_j": (d_j, np.quantile(d_j, 0.75)),         # 削減コスト（決定に効く）
    }

    # 特徴量セット（因果的に入手可能なものだけ）
    sets = {
        "hist": ["hist"],
        "gate0": ["gate0"],
        "gstat0": ["gstat0"],
        "gate0+hist": ["gate0", "hist"],
        "gstat0+hist": ["gstat0", "hist"],
        "h0": ["h0"],
        "h0+hist": ["h0", "hist"],
        "h8": ["h8"],
        "h8+hist": ["h8", "hist"],
        "gate8": ["gate8"],
        "gstat8": ["gstat8"],
        "gate8+hist": ["gate8", "hist"],
        "gate15+hist": ["gate15", "hist"],
        "ALL(l0)": ["gate0", "gstat0", "h0", "hist"],
        "ALL(l8)": ["gate8", "gstat8", "h8", "hist"],
    }

    results = {}
    for tname, (y, thr) in targets.items():
        ybin = (y > thr).astype(int)
        print("\n=== target: %s  (上位 25%% を陽性, thr=%.4f, 陽性率 %.3f) ==="
              % (tname, thr, ybin.mean()))
        print("%-14s %7s %8s %8s %8s" % ("features", "AUC", "Spearman", "R2", "dim"))
        rows = {}
        for sname, keys in sets.items():
            X = np.concatenate([feats[k] for k in keys], axis=1).astype(np.float64)
            pred = cv_predict(X, y, win)
            a = auc_score(ybin, pred)
            sp = spearman(pred, y)
            ss_res = ((y - pred) ** 2).sum()
            ss_tot = ((y - y.mean()) ** 2).sum()
            r2 = 1 - ss_res / ss_tot
            rows[sname] = {"auc": a, "spearman": sp, "r2": float(r2), "dim": int(X.shape[1])}
            print("%-14s %7.4f %8.4f %8.4f %8d" % (sname, a, sp, r2, X.shape[1]))
        results[tname] = rows

    # ---------- 決定規則としての価値 ----------
    # 「f の割合のトークンだけ k=8 に保護し、残りは k=6」の達成 ΔCE
    #   ΔCE = mean(d_j over 保護されなかったトークン)
    # 予算 mean_k = 6 + 2f（均一 top-7 は mean_k=7 なので f=0.5 が同予算）
    print("\n=== 決定規則としての達成 ΔCE（k=8 で保護する割合 f）===")
    print("  参考: 均一 top-6 = +0.04981 (f=0), 均一 top-7 = +0.01449 (f=0.5 と同予算)")
    n = d_j.size
    pred_store = {}
    for tname in ("d_j",):
        X = np.concatenate([feats[k] for k in ["gate0", "gstat0", "h0", "hist"]], axis=1).astype(np.float64)
        pred = cv_predict(X, d_j, win)
        Xg = feats["gstat0"].astype(np.float64)
        pred_g = cv_predict(Xg, d_j, win)
        pred_store["probe_all"] = pred
        pred_store["probe_gstat0"] = pred_g
        print("\n  %-6s %10s %10s %10s %10s" % ("f", "oracle", "probe(ALL)", "probe(gstat0)", "random"))
        for f in (0.25, 0.5, 0.75):
            m = int(round(f * n))
            order_o = np.argsort(-d_j)
            order_p = np.argsort(-pred)
            order_g = np.argsort(-pred_g)
            keep_o = np.zeros(n, bool); keep_o[order_o[:m]] = True
            keep_p = np.zeros(n, bool); keep_p[order_p[:m]] = True
            keep_g = np.zeros(n, bool); keep_g[order_g[:m]] = True
            ce_o = d_j[~keep_o].mean()
            ce_p = d_j[~keep_p].mean()
            ce_g = d_j[~keep_g].mean()
            ce_r = d_j.mean() * (1 - f)
            print("  %-6.2f %10.5f %10.5f %10.5f %10.5f" % (f, ce_o, ce_p, ce_g, ce_r))

    np.savez_compressed(os.path.join(HERE, "p4_preds.npz"),
                        d_j=d_j, nll_j=nll_j, win=win, pos=d["pos"], **pred_store)

    out = {"n": int(n), "targets": results,
           "d_j_mean": float(d_j.mean()), "d_j_sd": float(d_j.std())}
    with open(os.path.join(HERE, "p4_probe_results.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    print("\nsaved p4_probe_results.json")


if __name__ == "__main__":
    main()
