"""H1 の幅の掃引を lr=1e-3（安定側）でやり直す。

lr=3e-3 では幅の大きいモデルが最適化不安定になることが判明したため
（cue 課題で width 4.0 が lr=3e-3 では失敗し lr=1e-3 では成功）、
H1 の「平坦」が lr の交絡だったかを確認する。
"""
import json
import os

import h1_hybrid_testbed as H

HERE = os.path.dirname(os.path.abspath(__file__))
ARMS = ["uni_s05", "uni_s075", "uni_k2", "uni_s15"]
STEPS = 1600
LR = 1e-3
out = os.path.join(HERE, "h1_sweep_lr1e3.jsonl")
if os.path.exists(out):
    os.remove(out)

for arm in ARMS:
    for seed in (0, 1, 2):
        r = H.run(arm, 16, seed, STEPS, 128, 4, 4, 256, 64, LR)
        print(f"{arm} seed={seed} val={r['val']:.4f} cost={r['cost']:.2f}", flush=True)
        with open(out, "a", encoding="utf-8") as fp:
            fp.write(json.dumps(r, ensure_ascii=False) + "\n")
print("DONE", flush=True)
os._exit(0)
