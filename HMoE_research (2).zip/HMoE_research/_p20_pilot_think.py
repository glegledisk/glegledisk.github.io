# -*- coding: utf-8 -*-
"""P20 パイロット: thinking on の生成構造とコスト（使い捨て）

見るもの: 打ち切り率 / 生成長 / 思考と解答の区切り（\u003c/think\u003e 等）/ 正解率 / tok/s
出力: _p20_pilot_out_utf8.txt
"""
import json
import os
import re
import time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "qwen3-0.6b")
SYS = "You are a careful arithmetic assistant. Solve the problem and give the final answer."
VAL_RE = re.compile(r"-?\d+")
OUT = []


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def main():
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("--cap", type=int, default=1024)
    ap.add_argument("--n_prob", type=int, default=4)
    ap.add_argument("--n_samp", type=int, default=4)
    ap.add_argument("--tag", type=str, default="_p20_pilot")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer
    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, torch_dtype=torch.bfloat16, device_map="cuda",
        attn_implementation="sdpa").eval()

    # テンプレートに thinking の区切りが入っているか
    tpl = tok.chat_template or ""
    log("chat_template length=%d  contains 'think': %s" % (len(tpl), "think" in tpl.lower()))
    for kw in ["\u003cthink\u003e", "\u003c/think\u003e", "enable_thinking"]:
        log("  contains %r: %s" % (kw, kw in tpl))

    import random
    rnd = random.Random(31)
    probs = []
    for _ in range(args.n_prob):
        a, b = rnd.randint(10001, 99999), rnd.randint(10001, 99999)
        probs.append({"q": "Compute %d + %d." % (a, b), "gold": str(a + b)})

    prompts = [tok.apply_chat_template(
        [{"role": "system", "content": SYS}, {"role": "user", "content": p["q"]}],
        tokenize=False, add_generation_prompt=True, enable_thinking=True) for p in probs]
    log("\nprompt tail (first): %r" % prompts[0][-120:])

    n_samp = args.n_samp
    t0 = time.time()
    ntok_tot = 0
    trunc = 0
    accs = []
    for i, p in enumerate(probs):
        torch.manual_seed(31)
        enc = tok([prompts[i]] * n_samp, return_tensors="pt", padding=True,
                  add_special_tokens=False).to(model.device)
        with torch.no_grad():
            o = model.generate(**enc, max_new_tokens=args.cap, do_sample=True,
                               temperature=0.9, top_p=0.95,
                               pad_token_id=tok.pad_token_id)
        gen = o[:, enc["input_ids"].shape[1]:]
        for j in range(n_samp):
            ids = [t for t in gen[j].tolist() if t != tok.pad_token_id]
            txt = tok.decode(ids, skip_special_tokens=True)
            ntok_tot += len(ids)
            trunc += int(len(ids) >= args.cap)
            nums = VAL_RE.findall(txt.replace(",", ""))
            pred = nums[-1] if nums else None
            accs.append(float(pred == p["gold"]))
            if i == 0 and j < 2:
                log("\n--- sample i=%d j=%d ntok=%d pred=%s gold=%s ---" % (i, j, len(ids), pred, p["gold"]))
                log("HEAD: %r" % txt[:200])
                log("TAIL: %r" % txt[-300:])
                log("has <｜end▁of▁thinking｜>: %s" % ("<｜end▁of▁thinking｜>" in txt))
    dt = time.time() - t0
    log("\ntime=%.0fs  tokens=%d  %.1f tok/s  trunc=%d/%d  acc=%.3f"
        % (dt, ntok_tot, ntok_tot / dt, trunc, len(accs), float(np.mean(accs))))

    with open(os.path.join(HERE, args.tag + "_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    os._exit(0)


if __name__ == "__main__":
    import traceback
    try:
        main()
    except Exception:
        with open(os.path.join(HERE, "_p20_tb.txt"), "w", encoding="utf-8") as fp:
            fp.write(traceback.format_exc())
        raise
