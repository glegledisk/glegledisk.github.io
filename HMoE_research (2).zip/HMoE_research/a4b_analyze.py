#!/usr/bin/env python3
"""A4b: A4 の gain 補正つき再走を、raw 版と突き合わせる。

A4 は「raw の方が ReLU² に有利」（A1 の 1 点）を根拠に gain 補正を省いた。
ここでは **expert ごと**（(l,i) 単位）に初期化時の分岐 RMS を ReLU 基準へ揃えて同じ 2×2 を回し、
結論が変わるかを見る。揃え方は `per_expert_rms` で実測（解析式は使わない）。

見るもの
  1. 校正が意図どおりか（all_relu は全 expert 1.0000、ReLU² の expert だけ >1）
  2. 各アームの到達点が raw からどう動いたか
  3. 主対比（小に置く / 大に置く / 全部に置く / 直接対決）が両モードで同じ結論か
  4. ルーティングの応答（small_share）が両モードで残るか
"""
import argparse
import json
import math
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a4")
ORDER = ["all_relu", "small_relu2", "large_relu2", "all_relu2"]
CONTRASTS = [("small_relu2", "all_relu", "小に置く"),
             ("large_relu2", "all_relu", "大に置く"),
             ("all_relu2", "all_relu", "全部に置く"),
             ("small_relu2", "large_relu2", "小 vs 大")]


def load(tag):
    p = os.path.join(D, f"a4_results{tag}.json")
    with open(p, encoding="utf-8") as fh:
        return [r for r in json.load(fh) if "evals" in r]


def paired(rows, a, b, key, ep=-1):
    da = {r["seed"]: r["evals"][ep][key] for r in rows if r["arm"] == a}
    db = {r["seed"]: r["evals"][ep][key] for r in rows if r["arm"] == b}
    ks = sorted(set(da) & set(db))
    if len(ks) < 3:
        return None
    x = np.array([da[i] for i in ks])
    y = np.array([db[i] for i in ks])
    d = x - y
    se = d.std(ddof=1) / math.sqrt(len(d))
    t, p = stats.ttest_rel(x, y)
    mde = (stats.t.ppf(0.975, len(d) - 1) + stats.t.ppf(0.80, len(d) - 1)) * se
    return dict(mean=float(d.mean()), se=float(se), t=float(t), p=float(p),
                pos=int((d > 0).sum()), n=len(d), mde=float(mde))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", default="a4b_analysis.json")
    args = ap.parse_args()

    raw, g = load(""), load("_g")
    arms = [a for a in ORDER if any(r["arm"] == a for r in raw)]

    print("=== 1. 校正の確認 ===")
    for a in arms:
        r = next(x for x in g if x["arm"] == a)
        gi = r["gain"]
        be = gi.get("by_expert", [])
        print(f"  {a:12s} mode={gi['mode']:8s} mean={gi.get('mean', 1):.4f} "
              f"[{gi['min']:.4f},{gi['max']:.4f}]")
        if be:
            print(f"     expert 別: {be}")
    ok_all = all(abs(v - 1.0) < 1e-9 for v in
                 next(x for x in g if x["arm"] == "all_relu")["gain"].get("by_expert", [1.0]))
    print(f"  all_relu の gain が全て 1.0000: {'✓' if ok_all else '✗'}")
    ps = {r["nparam"] for r in g}
    print(f"  params の種類: {len(ps)} {sorted(ps)}")

    def col(rows, a, key, ep=-1):
        return np.array([r["evals"][ep][key] for r in rows if r["arm"] == a])

    print("\n=== 2. 到達点: raw → matched ===")
    print(f"  {'arm':12s}{'CE raw':>9s}{'CE g':>9s}{'ΔCE':>8s}"
          f"{'iv raw':>8s}{'iv g':>8s}{'Δiv':>8s}{'share raw':>11s}{'share g':>10s}")
    for a in arms:
        c0, c1 = col(raw, a, "ce_all").mean(), col(g, a, "ce_all").mean()
        i0, i1 = col(raw, a, "instr_valid").mean(), col(g, a, "instr_valid").mean()
        s0 = np.mean([r["routing"]["small_share"] for r in raw if r["arm"] == a])
        s1 = np.mean([r["routing"]["small_share"] for r in g if r["arm"] == a])
        print(f"  {a:12s}{c0:>9.4f}{c1:>9.4f}{c1-c0:>+8.4f}"
              f"{i0:>8.3f}{i1:>8.3f}{i1-i0:>+8.3f}{s0:>11.3f}{s1:>10.3f}")

    print("\n=== 3. 主対比（seed 対応、n=6、最終 epoch）===")
    print("  仮説「小に ReLU² が正しい」が成り立つには small_relu2 − all_relu > 0 かつ")
    print("  small_relu2 − large_relu2 > 0 が必要。")
    for a, b, lab in CONTRASTS:
        if a not in arms or b not in arms:
            continue
        print(f"  [{lab}]  {a} − {b}")
        for key in ("instr_valid", "ce_all"):
            c0 = paired(raw, a, b, key)
            c1 = paired(g, a, b, key)
            if not c0 or not c1:
                continue
            s0 = " *" if c0["p"] < 0.05 else "  "
            s1 = " *" if c1["p"] < 0.05 else "  "
            print(f"    {key:11s} raw   Δ={c0['mean']:+.4f} p={c0['p']:.4f}{s0} "
                  f"{c0['pos']}/{c0['n']} MDE={c0['mde']:.3f}")
            print(f"    {key:11s} gain  Δ={c1['mean']:+.4f} p={c1['p']:.4f}{s1} "
                  f"{c1['pos']}/{c1['n']} MDE={c1['mde']:.3f}")

    print("\n=== 4. ルーティングの応答（small_share、最終 epoch）===")
    for a, b, lab in CONTRASTS[:3]:
        if a not in arms or b not in arms:
            continue
        for nm, rows in (("raw", raw), ("gain", g)):
            da = {r["seed"]: r["routing"]["small_share"] for r in rows if r["arm"] == a}
            db = {r["seed"]: r["routing"]["small_share"] for r in rows if r["arm"] == b}
            ks = sorted(set(da) & set(db))
            d = np.array([da[i] - db[i] for i in ks])
            se = d.std(ddof=1) / math.sqrt(len(d))
            t, p = stats.ttest_rel([da[i] for i in ks], [db[i] for i in ks])
            print(f"  {a:12s}− {b:10s} [{nm:4s}] Δ={d.mean():+.4f} se={se:.4f} "
                  f"t={t:+.2f} p={p:.4f} {int((d < 0).sum())}/{len(d)} が負")

    print("\n=== 5. 結論は変わるか ===")
    chk = []
    for nm, rows in (("raw", raw), ("gain", g)):
        c_s = paired(rows, "small_relu2", "all_relu", "instr_valid")
        c_l = paired(rows, "large_relu2", "all_relu", "instr_valid")
        c_a = paired(rows, "all_relu2", "all_relu", "instr_valid")
        c_d = paired(rows, "small_relu2", "large_relu2", "instr_valid")
        verdict = ("支持" if (c_s["mean"] > 0 and c_d["mean"] > 0 and
                            (c_s["p"] < 0.05 or c_d["p"] < 0.05)) else "不支持")
        chk.append((nm, c_s["mean"], c_l["mean"], c_a["mean"], c_d["mean"], verdict))
        print(f"  {nm:5s}: 小={c_s['mean']:+.3f} 大={c_l['mean']:+.3f} "
              f"全部={c_a['mean']:+.3f} 小vs大={c_d['mean']:+.3f}  → **{verdict}**")
    same = len({c[-1] for c in chk}) == 1
    print(f"  2 つのモードで判定が一致: {'✓ 結論は gain 補正に依存しない' if same else '✗ 依存する'}")

    agg = {}
    for a in arms:
        agg[a] = dict(
            raw=dict(ce=float(col(raw, a, "ce_all").mean()),
                     iv=float(col(raw, a, "instr_valid").mean()),
                     share=float(np.mean([r["routing"]["small_share"]
                                          for r in raw if r["arm"] == a]))),
            gain=dict(ce=float(col(g, a, "ce_all").mean()),
                      iv=float(col(g, a, "instr_valid").mean()),
                      share=float(np.mean([r["routing"]["small_share"]
                                           for r in g if r["arm"] == a]))),
            nparam=next(x for x in g if x["arm"] == a)["nparam"])
    out = {"aggregate": agg, "verdict_same": bool(same)}
    with open(os.path.join(D, args.json), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(f"\n[write] {os.path.join(D, args.json)}")


if __name__ == "__main__":
    main()
