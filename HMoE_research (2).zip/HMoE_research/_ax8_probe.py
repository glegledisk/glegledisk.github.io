#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX8 走行前調査（モデル不要）

- 新コーパス corpus_ids_ax6_w24_l256.npz に AX4 の実文境界定義を適用した統計
- 文 ID の健全性（連続・窓またぎなし・最小文長）
- AX3 / AX6 の 8-gram 非重複の再確認
- AX4 / AX6 保存 NLL から参照利得を再計算（記憶から書かない）
- 保存配列と新規 forward のトークン順の対応（AX7 の罠の確認）

出力: _ax8_probe.json
"""
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
AX3_CORPUS = os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz")
AX6_CORPUS = os.path.join(HERE, "corpus_ids_ax6_w24_l256.npz")
AX4_NPZ = os.path.join(HERE, "ax4_sentence_bound.npz")
AX6_NPZ = os.path.join(HERE, "ax6_transfer.npz")

N_LAYERS = 16
LN = 256
N_EVAL = 255
N_WIN = 24
NW = 2 * N_WIN
N_TOK = NW * N_EVAL
MIN_SENT = 8
BOUND_PERIOD = (2, 15, 32, 4340)


def build_sent_ids(ids, bset, n_win, ln, minlen=MIN_SENT):
    """AX4 と同一: 窓内完結・境界トークンを文末に含める・窓末端数は直前の文へマージ。"""
    n = len(ids)
    sent = np.zeros(n, dtype=np.int32)
    sid, lens, n_merged = 0, [], 0
    for w in range(n_win):
        seg = ids[w * ln:(w + 1) * ln]
        ends = np.where(np.isin(seg, list(bset)))[0]
        cuts, start = [], 0
        for e in ends:
            if e + 1 - start >= minlen:
                cuts.append([start, e + 1])
                start = e + 1
        if start < ln:
            if cuts:
                cuts[-1][1] = ln
                n_merged += 1
            else:
                cuts.append([0, ln])
        for a, b in cuts:
            sent[w * ln + a:w * ln + b] = sid
            lens.append(b - a)
            sid += 1
    lens = np.array(lens)
    assert sent.shape == (n,) and np.array_equal(np.unique(sent), np.arange(sid))
    assert lens.min() >= minlen
    return sent, lens, n_merged


def sent_ids_tok(sent, n_win, n_eval):
    """文 ID (窓トークン列 256) → 評価トークン列 255 へ変換（AX4 と同一）。"""
    out = np.zeros(n_win * n_eval, dtype=np.int32)
    for w in range(n_win):
        out[w * n_eval:(w + 1) * n_eval] = sent[w * 256:w * 256 + n_eval]
    return out


def grams8(x):
    return set(tuple(int(v) for v in x[i:i + 8]) for i in range(len(x) - 7))


def overlap8(a, b):
    gb = grams8(b)
    return float(np.mean([tuple(int(v) for v in a[i:i + 8]) in gb
                         for i in range(len(a) - 7)]))


def main():
    out = {"meta": {"n_win": N_WIN, "ln": LN, "n_eval": N_EVAL, "n_tok": N_TOK,
                    "bound_period": list(BOUND_PERIOD), "min_sent": MIN_SENT}}

    # ---- 1. 新コーパスの文境界 ----
    z6 = np.load(AX6_CORPUS, allow_pickle=True)
    z3 = np.load(AX3_CORPUS, allow_pickle=True)
    stats, sent_all, bound_counts = {}, [], {}
    for lg in ("en", "ja"):
        ids = z6[lg + "_ids"].astype(np.int64)[:N_WIN * LN]
        assert ids.size == N_WIN * LN
        bound_counts[lg] = {int(t): int((ids[:N_WIN * LN] == t).sum())
                            for t in BOUND_PERIOD}
        s, lens, nm = build_sent_ids(ids, BOUND_PERIOD, N_WIN, LN)
        sent_all.append(sent_ids_tok(s, N_WIN, N_EVAL))
        stats[lg] = {"n_sent": int(lens.size), "mean_len": float(lens.mean()),
                     "median_len": float(np.median(lens)), "min_len": int(lens.min()),
                     "max_len": int(lens.max()), "p90_len": float(np.percentile(lens, 90)),
                     "n_merged": int(nm)}
    off = int(sent_all[0].max()) + 1
    sent = np.concatenate([sent_all[0], sent_all[1] + off]).astype(np.int32)
    n_sent = int(sent.max()) + 1
    assert n_sent == stats["en"]["n_sent"] + stats["ja"]["n_sent"]

    # 健全性
    uniq = np.unique(sent)
    ok_contiguity = bool(sent.shape == (N_TOK,)
                         and np.array_equal(uniq, np.arange(n_sent))
                         and np.bincount(sent).min() >= 1)
    seen, no_cross = set(), True
    for w in range(NW):
        sw = set(np.unique(sent[w * N_EVAL:(w + 1) * N_EVAL]).tolist())
        if sw & seen:
            no_cross = False
        seen |= sw
    out["corpus_ax6"] = {"stats": stats, "n_sent_total": n_sent,
                         "bound_token_counts": bound_counts,
                         "ok_contiguity": ok_contiguity,
                         "no_cross_window": bool(no_cross),
                         "ax4_n_sent_reference": 340}
    assert ok_contiguity and no_cross

    # ---- 2. 8-gram 非重複（AX6 設計書 C2 の再確認）----
    out["overlap8"] = {lg: overlap8(z3[lg + "_ids"], z6[lg + "_ids"])
                       for lg in ("en", "ja")}

    # ---- 3. AX4 / AX6 保存 NLL から参照利得を再計算 ----
    z4 = np.load(AX4_NPZ)
    u4 = z4["nll_u7_rep"].astype(np.float64)
    out["ax4_reference"] = {
        "G_sent_probe": float((u4 - z4["nll_sent_probe"].astype(np.float64)).mean()),
        "G_sent_oracle": float((u4 - z4["nll_sent_oracle"].astype(np.float64)).mean()),
        "G_sent_random": float((u4 - z4["nll_sent_random"].astype(np.float64)).mean()),
        "gap_oracle_minus_probe": float(
            (z4["nll_sent_probe"].astype(np.float64)
             - z4["nll_sent_oracle"].astype(np.float64)).mean()),
    }
    za = np.load(AX6_NPZ)
    u6 = za["nll_u7"].astype(np.float64)
    out["ax6_reference"] = {
        nm: float((u6 - za["nll_" + nm].astype(np.float64)).mean())
        for nm in ("uni48", "uni102", "uni181", "uni340", "uni630",
                   "uni1224", "tok12240", "rand340", "global1")
    }
    out["ax6_arrays"] = {"c8_shape": list(za["c8"].shape),
                         "c7_shape": list(za["c7"].shape),
                         "nll_u7_shape": list(u6.shape),
                         "c8_mean": float(za["c8"].mean()),
                         "c7_mean": float(za["c7"].mean()),
                         "base_eq_base_rep": bool(np.array_equal(
                             za["nll_base"], za["nll_base_rep"]))}

    # ---- 4. トークン順の対応（AX7 の罠）----
    # AX6 の load_ax6(24, 256) は en 24 窓 → ja 24 窓。
    # よって保存 nll の先頭 6*255 = 1530 トークンは en の窓 0〜5。
    # スモークは en のみ 6 窓にすれば保存配列の先頭と完全一致する。
    out["token_order"] = {
        "ax6_window_order": "en[0..23] then ja[0..23]",
        "saved_head_1530": "en windows 0..5",
        "smoke_prescription": "en_only=True, n_lg=2*n_win=6 windows",
        "full_prescription": "en_only=False, 24+24 windows",
    }

    with open(os.path.join(HERE, "_ax8_probe.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2, allow_nan=False)
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
