import numpy as np, math
z = np.load("p6c_layer_cal.npz", allow_pickle=True)
lang = z["lang"]; n = z["base_nll"].size
tl = np.repeat(lang, n // lang.size)
def t(a,b):
    d = np.asarray(a,float)-np.asarray(b,float); se=d.std(ddof=1)/math.sqrt(d.size)
    return d.mean(), se, d.mean()/se
print("n=%d en=%d ja=%d" % (n,(tl=="en").sum(),(tl=="ja").sum()))
print()
print("=== P6b の層非対称性（f6b8 - f8b6）を言語別に ===")
for k,lab in (("nll","CE"),("ptop1","p_top1"),("top1","acc")):
    a = z["f6b8_%s" % k].astype(float); b = z["f8b6_%s" % k].astype(float)
    m,se,tt = t(a,b); print("  %-8s 全体   Δ=%+10.5f (t=%+7.2f)" % (lab,m,tt))
    for u in ("en","ja"):
        s = tl==u; m,se,tt = t(a[s],b[s]); print("  %-8s %-4s  Δ=%+10.5f (t=%+7.2f)" % (lab,u,m,tt))
print()
print("=== 較正ギャップ（p - acc）の非対称性 ===")
g6 = z["f6b8_ptop1"].astype(float)-z["f6b8_top1"].astype(float)
g8 = z["f8b6_ptop1"].astype(float)-z["f8b6_top1"].astype(float)
m,se,tt = t(g6,g8); print("  全体   Δ=%+10.5f (t=%+7.2f)" % (m,tt))
for u in ("en","ja"):
    s = tl==u; m,se,tt = t(g6[s],g8[s]); print("  %-4s   Δ=%+10.5f (t=%+7.2f)" % (u,m,tt))