# -*- coding: utf-8 -*-
"""使い捨て: _md_check.py が検出した CJK 間空白の箇所を特定する。"""
import re
import sys
from markdown_it import MarkdownIt

path = sys.argv[1]
with open(path, encoding="utf-8") as f:
    lines = f.read().split("\n")

html = MarkdownIt("commonmark").enable("table").render("\n".join(lines))
body = re.sub(r"<pre>.*?</pre>", "", html, flags=re.S)
body = re.sub(r"<code>.*?</code>", "<code>X</code>", body, flags=re.S)
for m in re.finditer(r"[\u3040-\u30ff\u4e00-\u9fff]\s+[\u3040-\u30ff\u4e00-\u9fff]", body):
    a = max(0, m.start() - 70)
    b = min(len(body), m.end() + 70)
    print("---")
    print(repr(body[a:b]))
