# -*- coding: utf-8 -*-
import json
with open(r"C:\Users\gochu\WorkBuddy AI\不均一MoE\ax7_plateau.json", encoding="utf-8") as f:
    d = json.load(f)
for k in ("P1_length","P2_alignment","P3_flat"):
    v = d["confirmatory"][k]
    print(f'{k}: mean={v["mean"]:+.8f} se={v["se"]:.8f} t={v["t"]:+.4f} p={v["p_two"]:.6g} mde={v["mde"]:.8f}')
print()
for nm in ("shift102","shift102b","shift181","shift181b","uni102","uni181","sent4","sent2"):
    g = d["gains"].get(nm, {})
    if g:
        print(f'G_{nm}: {g["mean"]:+.10f}  se={g.get("se",0):.10f}')
print()
c7 = d["calib"]["C7"]
print(f'noise102={c7["noise102"]:.10f}  noise181={c7["noise181"]:.10f}')
print()
for k in ("decomposition_N102","decomposition_N181"):
    print(k, d["exploratory"][k])
print()
# forward timing: how many new forwards, total time
print(f'n_new_forwards={d["meta"]["n_new_forwards"]}')
# shift stats
for nm in ("shift102","shift102b","shift181","shift181b"):
    s = d["exploratory"]["split_stats"].get(nm, {})
    print(f'{nm}: N={s.get("N")} cv={s.get("cv"):.4f}')
