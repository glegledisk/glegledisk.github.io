#!/usr/bin/env python3
"""Q10 の解析: 2 本平均は必要か。

FLOPs は **トークン比で重み付け**する（struct 20% / payload 80%）。
  FFN(1 expert) = 2·d·w、attention = 4·d²、d=128。
  Q9 の表は payload だけの値を全トークンに当てていたので、static は 1.65× ではなく 1.42×。
"""
import json
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q10")
OUT = []
def w(s=""):
    print(s)
    OUT.append(s)


def st(x):
    x = np.asarray(x, float)
    n = len(x)
    m = x.mean()
    se = x.std(ddof=1) / np.sqrt(n)
    t = m / se if se > 0 else 0.0
    p = 2 * stats.t.sf(abs(t), df=n - 1) if se > 0 else 1.0
    return m, se, t, p, int((x > 0).sum()), int((x < 0).sum())


MODES = ["dynamic_lb", "static_type", "static_e6", "static_1x"]
D = 128
ATT = 4 * D * D
SH_STRUCT, SH_PAYLOAD = 0.2, 0.8

# 各条件の (struct プール幅のリスト, payload プール幅のリスト)
POOLW = {
    "dynamic_lb": None,                      # 実測の平均幅から出す
    "static_type": ([32, 32], [224, 224]),
    "static_e6": ([32, 32], [224]),
    "static_1x": ([32], [224]),
}


def ffn_flops(ws, wp):
    return SH_STRUCT * sum(2 * D * x for x in ws) + SH_PAYLOAD * sum(2 * D * x for x in wp)


def load(task, mode):
    rows = []
    for s in range(6):
        p = os.path.join(DATA, f"H+LB_{task}_{mode}_s{s}.json")
        with open(p, encoding="utf-8") as f:
            rows.append(json.load(f))
    e = [r["eval"]["base"] for r in rows]
    return {
        "iv": np.array([x["instr_valid"] for x in e]),
        "acc": np.array([x["acc_payload"] for x in e]),
        "ce": np.array([x["ce_payload"] for x in e]),
        "wst": np.array([x["width_struct"] for x in e]),
        "wpl": np.array([x["width_payload"] for x in e]),
        "sec": np.array([r["sec"] for r in rows]),
    }


for task in ["hard"]:
    d = {m: load(task, m) for m in MODES}

    w("=" * 82)
    w(f"{task.upper()}  (n=6)")
    w("=" * 82)

    w("\n[1] 水準と計算量")
    w(f"  {'mode':<13} {'iv':>7} {'se':>6} {'acc_pl':>8} {'ce_pl':>8} "
      f"{'w_st':>6} {'w_pl':>6} {'FFN':>8} {'総FLOPs':>8}")
    ref = None
    for m in MODES:
        v = d[m]
        if POOLW[m] is None:
            ffn = 4 * D * v["wpl"].mean() * SH_PAYLOAD + 4 * D * v["wst"].mean() * SH_STRUCT
        else:
            ws, wp = POOLW[m]
            ffn = ffn_flops(ws, wp)
        tot = ATT + ffn
        if ref is None:
            ref = tot
        w(f"  {m:<13} {v['iv'].mean():7.3f} {st(v['iv'])[1]:6.3f} {v['acc'].mean():8.4f} "
          f"{v['ce'].mean():8.4f} {v['wst'].mean():6.1f} {v['wpl'].mean():6.1f} "
          f"{ffn:8.0f} {tot/ref:7.2f}×")

    w("\n[2] per-seed instr_valid")
    for m in MODES:
        w(f"  {m:<13} " + ", ".join(f"{x:.3f}" for x in d[m]["iv"]))

    w("\n[3] 対応差（同一 seed, df=5）")
    for a, b in [("static_e6", "static_type"), ("static_1x", "static_e6"),
                 ("static_1x", "static_type"), ("static_e6", "dynamic_lb"),
                 ("static_1x", "dynamic_lb"), ("static_type", "dynamic_lb")]:
        w(f"  --- {a} − {b} ---")
        for k, lab in [("iv", "instr_valid"), ("acc", "acc_payload"), ("ce", "ce_payload")]:
            diff = d[a][k] - d[b][k]
            m, se, t, p, npos, nneg = st(diff)
            w(f"    {lab:<14} {m:+.4f}  se {se:.4f}  t {t:+.2f}  p {p:.4f}  "
              f"正{npos}/負{nneg}")

    w("\n[4] 判定")
    m, se, t, p, npos, nneg = st(d["static_e6"]["iv"] - d["static_type"]["iv"])
    w(f"  static_e6 − static_type（payload の 0.5 平均を外す）: {m:+.3f}, "
      f"se {se:.3f}, p={p:.4f}, 正{npos}/6")
    if p < 0.05 and m < 0:
        w("  → **2 本平均は必要**（外すと落ちる）。0.5 平均そのものが効いている")
    elif p < 0.05 and m > 0:
        w("  → **2 本平均は害**。単独の方が良い")
    else:
        w("  → **2 本平均は不要**（区別できない）。**FLOPs を約半分にできる**")

    m2, se2, t2, p2, npos2, _ = st(d["static_1x"]["iv"] - d["static_type"]["iv"])
    w(f"  （参考）static_1x − static_type（全部単独）: {m2:+.3f}, se {se2:.3f}, p={p2:.4f}")

    w("\n[5] MDE（n=6, df=5, alpha=.05, power=.80 → 3.49×se）")
    for a, b in [("static_e6", "static_type"), ("static_e6", "dynamic_lb")]:
        se = st(d[a]["iv"] - d[b]["iv"])[1]
        w(f"  {a}−{b}: se {se:.3f} → MDE {3.49*se:.3f}")

with open(os.path.join(HERE, "q10_analysis_out_utf8.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(OUT) + "\n")
print("\n[written] q10_analysis_out_utf8.txt")
