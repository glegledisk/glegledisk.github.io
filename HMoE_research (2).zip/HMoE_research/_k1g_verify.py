#!/usr/bin/env python3
"""K1g の独立検算。json の集計値を使わず、npz の per-sequence CE から全部やり直す。

確認項目
  1. 各 seed の ΔCE（matched / w256）を npz から再計算し、json と一致するか
  2. t を再計算（Δ / (sd/√n)）
  3. 復元した教師の CE が k1c_results_e16.json と一致するか（較正）
  4. MACs 会計が P13 の 3 点を再現するか
  5. 幅のドリフト（6ep 160.9 → 16ep 188.1）と、それが MAC 比に与える影響
  6. 傾き（nats / MAC 比）と、P13 の 1.226 への外挿
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TAG = sys.argv[1] if len(sys.argv) > 1 else "e16w"
OUT = os.path.join(HERE, "k1g_verify_out_utf8.txt")
D, L, E = 128, 4, 8


def macs(W):
    return L * (4 * D * D + 2 * D * W + D * E)


def p(msg):
    print(msg)
    with open(OUT, "a", encoding="utf-8") as f:
        f.write(msg + "\n")


def main():
    if os.path.exists(OUT):
        os.remove(OUT)
    suf = ("_" + TAG) if TAG else ""
    res = json.load(open(os.path.join(HERE, "k1g_results%s.json" % suf), encoding="utf-8"))
    z = np.load(os.path.join(HERE, "k1g_ce_seq%s.npz" % suf))
    ref = json.load(open(os.path.join(HERE, "k1c_results_e16.json"), encoding="utf-8"))
    ref_t = {r["seed"]: r["ce_t"] for r in ref["rows"]}

    p("== 4) MACs 会計の較正（P13 の 3 点を再現するか） ==")
    for W, want in ((97, 365568), (180, 450560), (256, 528384)):
        p("  macs(%3d) = %7d  期待 %7d  差 %+d" % (W, macs(W), want, macs(W) - want))

    p("")
    p("== 3) 復元した教師の CE（k1c_results_e16.json との一致） ==")
    bad = 0
    for r in res["rows"]:
        s = r["seed"]
        ce_t = z["teacher:s%d" % s].astype(np.float64)
        d = ce_t.mean() - ref_t[s]
        flag = "" if abs(d) < 1e-4 else "  ← 不一致"
        bad += abs(d) >= 1e-4
        p("  s%-2d npz %.6f  K1e %.6f  差 %+.2e%s" % (s, ce_t.mean(), ref_t[s], d, flag))
    p("  不一致 %d 件（0 なら reload は忠実）" % bad)

    p("")
    p("== 1-2) ΔCE の再計算（npz の per-sequence CE から） ==")
    p("  %-3s %-8s %5s %9s %9s %9s %8s %7s %s"
      % ("s", "key", "W", "CE_t", "CE_s", "Δ", "se", "t", "json との差"))
    rows = {}
    for r in res["rows"]:
        s = r["seed"]
        ce_t = z["teacher:s%d" % s].astype(np.float64)
        for key in ("matched", "w256"):
            if key not in r["widths"]:
                continue
            w = r["widths"][key]["w"]
            ce_s = z["dense%d:s%d" % (w, s)].astype(np.float64)
            d = ce_s - ce_t
            se = d.std(ddof=1) / np.sqrt(len(d))
            t = d.mean() / se
            dj = r["widths"][key]["delta"]
            p("  %-3d %-8s %5d %9.4f %9.4f %+9.4f %8.4f %+7.2f %+.2e"
              % (s, key, w, ce_t.mean(), ce_s.mean(), d.mean(), se, t, d.mean() - dj))
            rows.setdefault(key, []).append(
                {"seed": s, "w": w, "ce_t": ce_t.mean(), "ce_s": ce_s.mean(),
                 "delta": d.mean(), "se_seq": se, "t_seq": t,
                 "ratio": macs(w) / macs(r["w_teacher"]), "w_t": r["w_teacher"]})

    p("")
    p("== 集計（npz から独立に） ==")
    agg = {}
    for key, rs in rows.items():
        d = np.array([x["delta"] for x in rs])
        n = len(d)
        se = d.std(ddof=1) / np.sqrt(n)
        coef = {2: 5.36, 5: 3.49}.get(n - 1, 2.95 if n < 12 else 2.85)
        ratio = np.array([x["ratio"] for x in rs])
        agg[key] = {"n": n, "delta": float(d.mean()), "se": float(se),
                    "t": float(d.mean() / se), "mde": float(coef * se),
                    "n_neg": int((d < 0).sum()),
                    "ratio": float(ratio.mean()),
                    "ce_t": float(np.mean([x["ce_t"] for x in rs])),
                    "ce_s": float(np.mean([x["ce_s"] for x in rs]))}
        p("  %-8s n=%d  MAC 比 %.3f  CE_t %.4f / CE_s %.4f  Δ %+.4f  se %.4f  t %+.2f  "
          "%d/%d 負  MDE %.4f"
          % (key, n, ratio.mean(), agg[key]["ce_t"], agg[key]["ce_s"],
             d.mean(), se, d.mean() / se, int((d < 0).sum()), n, coef * se))

    p("")
    p("== 5) 幅のドリフト（6 epoch → 16 epoch） ==")
    w16 = np.array([r["w_teacher"] for r in res["rows"]])
    p("  6ep（P13）: 160.9   16ep（ここ）: %.1f ± %.1f（%.1f〜%.1f）"
      % (w16.mean(), w16.std(ddof=1), w16.min(), w16.max()))
    p("  → 等計算量の dense 幅は 161 ではなく **%.0f**。K1e の dense161 は MACs %d で、"
      % (round(w16.mean()), macs(161)))
    p("    教師（%.0f）の %d の **%.1f%%**。つまり「等計算量」ではなく 6%% 少ない点だった。"
      % (round(w16.mean()), macs(w16.mean()), 100 * macs(161) / macs(w16.mean())))
    p("  幅比（均一 MoE W=256 に対して）: 6ep 160.9/256 = %.3f → 16ep %.1f/256 = %.3f"
      % (160.9 / 256, w16.mean(), w16.mean() / 256))
    p("  MAC 比（同上）: %.3f → %.3f"
      % (macs(160.9) / macs(256), macs(w16.mean()) / macs(256)))

    p("")
    p("== 6) 傾き（nats / MAC 比）と P13 の 1.226 への外挿 ==")
    if "matched" in agg and "w256" in agg:
        d0, r0 = agg["matched"]["delta"], agg["matched"]["ratio"]
        d1, r1 = agg["w256"]["delta"], agg["w256"]["ratio"]
        slope = (d1 - d0) / (r1 - r0)
        p("  matched: Δ %+.4f @ 比 %.3f   /   w256: Δ %+.4f @ 比 %.3f"
          % (d0, r0, d1, r1))
        p("  傾き = (%+.4f − %+.4f) / (%.3f − %.3f) = **%+.4f nats / MAC 比**"
          % (d1, d0, r1, r0, slope))
        p("  1.226 への外挿: %+.4f + %+.4f×(1.226 − %.3f) = **%+.4f**"
          % (d0, slope, r0, d0 + slope * (1.226 - r0)))
        p("  P13（6ep/6t）の実測: +0.0723")
        p("  → 差 %+.4f。**プロトコルが違う（1t vs 6t）ので絶対値の比較ではなく、"
          % ((d0 + slope * (1.226 - r0)) - 0.0723))
        p("     同じ 16 epoch 内で閉じた傾きとして読む。**")

    p("")
    p("== 判定 ==")
    if "matched" in agg:
        a = agg["matched"]
        p("  等計算量（ΔW=0）: Δ %+.4f, MDE %.4f → %s"
          % (a["delta"], a["mde"],
             "差を検出できず（アーキテクチャ差ゼロ）" if abs(a["t"]) < 2.26
             else "差あり（★ K1e の結論が崩れる）"))
    if "w256" in agg:
        b = agg["w256"]
        p("  1.15 倍: Δ %+.4f, MDE %.4f → %s"
          % (b["delta"], b["mde"],
             "有意" if abs(b["t"]) > 2.26 else "検出できず"))

    with open(os.path.join(HERE, "k1g_verify%s.json" % suf), "w", encoding="utf-8") as f:
        json.dump({"agg": agg, "rows": rows,
                   "w16_mean": float(w16.mean()), "w16_sd": float(w16.std(ddof=1)),
                   "calib_bad": bad}, f, ensure_ascii=False, indent=2, default=float)
    p("")
    p("[write] k1g_verify%s.json" % suf)


if __name__ == "__main__":
    main()
