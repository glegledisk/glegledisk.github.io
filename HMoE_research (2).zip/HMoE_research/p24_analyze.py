#!/usr/bin/env python3
"""P24 の解析: 4 分割の層別コストから条件式 c_b/c_f > 1+ρ を判定する。

入力: p24_layer_cost.npz（条件ごとの per-token NLL, 48 窓 × 255）
出力: p24_analysis.json / 標準出力

統計: 窓クラスタ（独立単位は 48 窓）。窓ごとの平均 ΔCE を出し、その 48 個で se を取る。
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
NPZ = os.path.join(HERE, "p24_layer_cost.npz")
OUT = os.path.join(HERE, "p24_analysis.json")

GROUPS = {"G0": "0-3", "G1": "4-7", "G2": "8-11", "G3": "12-15"}
LEVELS = {"h": 0.5, "s": 1.0, "t": 2.0}
N_WIN = 48
WIN = 255


def load():
    z = np.load(NPZ, allow_pickle=True)
    return {k: z[k] for k in z.files}


def stat(x):
    a = np.asarray(x, float)
    return float(a.mean()), float(a.std(ddof=1) / np.sqrt(len(a)))


def main():
    z = load()
    base = z["nll_base"]
    assert base.size == N_WIN * WIN, f"n_tokens {base.size} != {N_WIN*WIN}"
    base_w = base.reshape(N_WIN, WIN).mean(1)

    # 各条件の ΔCE（窓クラスタ）
    res = {}
    for g in GROUPS:
        for lv, m in LEVELS.items():
            c = f"{g}{lv}"
            nll = z[f"nll_{c}"]
            d = (nll - base).astype(np.float64)
            d_w = d.reshape(N_WIN, WIN).mean(1)
            mean, se = stat(d_w)
            # トークン単位の se も参考に出す（過大になる）
            _, se_tok = stat(d)
            res[c] = {"m": m, "dce": mean, "se": se, "se_tok": se_tok,
                      "t": mean / se if se > 0 else float("nan")}
    res["base"] = {"m": 0.0, "dce": 0.0, "se": 0.0, "se_tok": 0.0, "t": 0.0}

    print("=== 各群のコスト曲線（ΔCE, 窓クラスタ se） ===")
    print(f"{'群':>4} {'層':>7} {'C(0.5)':>10} {'C(1)':>10} {'C(2)':>10} "
          f"{'c(1)':>10} {'c(2)':>10} {'ρ':>7}")
    c1, c2, rho = {}, {}, {}
    for g, lyr in GROUPS.items():
        a = res[f"{g}h"]
        b = res[f"{g}s"]
        c = res[f"{g}t"]
        c1[g] = b["dce"]
        c2[g] = c["dce"] - b["dce"]
        rho[g] = c2[g] / c1[g] if c1[g] > 0 else float("nan")
        print(f"{g:>4} {lyr:>7} {a['dce']:>+10.5f} {b['dce']:>+10.5f} "
              f"{c['dce']:>+10.5f} {c1[g]:>+10.5f} {c2[g]:>+10.5f} {rho[g]:>7.2f}")

    print("\n=== 非対称性と条件式 ===")
    print("  移動の判定: 群 j の 1 本を群 i へ移す（i に 2 本, j に 0 本）と得か")
    print("    得 ⟺ c_i(2) < c_j(1)   ⟺   A_ji = c_j/c_i > ρ_i")
    print(f"  {'i':>3} {'j':>3} {'A=c_j/c_i':>10} {'ρ_i':>6} {'1+ρ_i':>7} "
          f"{'A>ρ_i':>7} {'A>1+ρ_i':>8} {'c_i(2)':>9} {'c_j(1)':>9} {'得か':>5}")
    pairs = []
    for i in GROUPS:
        for j in GROUPS:
            if i == j:
                continue
            A = c1[j] / c1[i] if c1[i] > 0 else float("nan")
            gt_rho = A > rho[i]
            gt_1prho = A > (1 + rho[i])
            win = c2[i] < c1[j]
            pairs.append({"i": i, "j": j, "A": A, "rho_i": rho[i],
                          "gt_rho": bool(gt_rho), "gt_1prho": bool(gt_1prho),
                          "win": bool(win)})
            print(f"  {i:>3} {j:>3} {A:>10.2f} {rho[i]:>6.2f} {1+rho[i]:>7.2f} "
                  f"{str(gt_rho):>7} {str(gt_1prho):>8} {c2[i]:>+9.5f} {c1[j]:>+9.5f} "
                  f"{str(win):>5}")

    # 全体判定
    any_win = [p for p in pairs if p["win"]]
    any_1prho = [p for p in pairs if p["gt_1prho"]]
    print(f"\n=== 判定 ===")
    print(f"  条件式 A > 1+ρ を満たす組: {len(any_1prho)} / {len(pairs)}")
    print(f"  直接判定（c_i(2) < c_j(1)）で得になる組: {len(any_win)} / {len(pairs)}")
    if any_1prho:
        print("  → " + ", ".join(f"{p['i']}←{p['j']}" for p in any_1prho))
    print(f"  ρ の範囲: {min(rho.values()):.2f} 〜 {max(rho.values()):.2f}")
    print(f"  c(1) の範囲: {min(c1.values()):+.5f} 〜 {max(c1.values()):+.5f}"
          f"（比 {max(c1.values())/min(c1.values()):.2f}）")

    with open(OUT, "w", encoding="utf-8") as f:
        json.dump({"res": res, "c1": c1, "c2": c2, "rho": rho,
                   "pairs": pairs, "n_win": N_WIN}, f, ensure_ascii=False, indent=2)
    print(f"\n[write] {OUT}")


if __name__ == "__main__":
    main()
    sys.exit(0)
