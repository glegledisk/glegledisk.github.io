# -*- coding: utf-8 -*-
"""p20_think.jsonl に思考終端マーカーが残っているか（使い捨て）"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
END = "</" + "think>"
START = "<" + "think>"

rows = [json.loads(l) for l in open(os.path.join(HERE, "p20_think.jsonl"),
                                    encoding="utf-8") if l.strip()]
S = [s for r in rows if r.get("round") != "greedy" for s in r["samples"]]
print("n=%d" % len(S))
print("contains END marker: %d" % sum(1 for s in S if END in s["text"]))
print("contains START marker: %d" % sum(1 for s in S if START in s["text"]))
print("finished but no END: %d"
      % sum(1 for s in S if s["finished"] and END not in s["text"]))
print("truncated but has END: %d"
      % sum(1 for s in S if (not s["finished"]) and END in s["text"]))
for s in S[:3]:
    t = s["text"]
    print("\n--- ntok=%d finished=%s END=%s ---" % (s["ntok"], s["finished"], END in t))
    print("HEAD %r" % t[:60])
    if END in t:
        i = t.index(END)
        print("AROUND END %r" % t[max(0, i - 40):i + 60])
    print("TAIL %r" % t[-80:])
