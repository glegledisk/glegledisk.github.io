#!/usr/bin/env python3
"""PC2: 生徒 HMoE の条件 A（切り出し初期化のみ）を K6 の容量課題で測る。

条件（同一 seed で対応を取る）
  teacher      : H+LB（幅 32/32/96/96/160/160/224/224, W=1024）を K6 のレシピで訓練し ckpt を保存
  half:prune   : 幅を 0.5 倍（16/16/48/48/80/80/112/112, W=512）にし、**教師の expert を重要度で切り出す**
  half:first   : 同じ幅にし、**先頭 w_s 個をそのまま残す**（選択基準の対照）
  half:scratch : 同じ幅のランダム初期化（初期化そのものの対照）
  attention / embedding / head / router は教師から引き継ぐ（切り出し初期化の定義）。

測るもの
  ce_init : 訓練前の CE（切り出しが情報を運んでいるかの直接証拠）
  ce      : 最終 3 epoch の中央値（K6 と同じ）
出力: pc2_results_<tag>.json / pc2_out_utf8_<tag>.txt / data/k6ckpt/*.pt
"""
import argparse
import json
import os
import re
import sys
import time
from multiprocessing import Pool

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import k6_capacity_task as K6  # noqa: E402

CKPTDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "k6ckpt")
HALF = tuple(w // 2 for w in (32, 32, 96, 96, 160, 160, 224, 224))


def ckpt_name(cfg, N, seed, epochs, per_key):
    """N・epoch・per_key をファイル名に入れる（別条件の ckpt を上書きしないため）。"""
    return os.path.join(CKPTDIR, "ckpt_%s_N%d_e%d_pk%d_s%d.pt"
                        % (cfg.replace(":", "_"), N, epochs, per_key, seed))


def worker(job):
    cfg, seed, N, per_key, epochs, bs, lr, auxw, clip, kd_w, kd_T, hid_w, t_pk, t_ep = job
    import torch
    import torch.nn.functional as F
    import e2b_rewrite_routing_fixed as e2b

    torch.set_num_threads(1)
    e2b.SEQ = K6.SEQ_
    e2b.SL, e2b.OL = K6.SL_, K6.OL_
    V, SEP = e2b.V, e2b.SEP

    t0 = time.time()
    table = K6.build_table(N, 10_000 + seed)
    _, ids_fn = K6.make_sampler(N, "uniform", 1.0)

    arm = "p_pen"
    k = 2
    if cfg == "teacher":
        widths = e2b.WIDTHS["H+LB"]
    else:
        widths = HALF
    model = e2b.RewriteMoE(widths, seed=seed, topk=k)

    # --- 条件の分解 ---
    base = cfg.split(":")[1] if cfg.startswith("half:") else ""
    init_mode = "scratch" if base.startswith("scratch") else "prune"
    use_kd = "+kd" in base
    use_hkd = "+hkd" in base
    m = re.search(r"_w([0-9.]+)_T([0-9.]+)", base)
    if m:                       # 腕ごとに kd_w / T を指定できる（例: half:scratch+kd_w0.3_T2.0）
        kd_w = float(m.group(1))
        kd_T = float(m.group(2))
    mh = re.search(r"_hw([0-9.]+)", base)
    if mh:                      # 腕ごとに hid_w を指定できる（例: half:scratch+hkd_hw1.0）
        hid_w = float(mh.group(1))
    mc = re.search(r"_clip([0-9.]+)", base)
    if mc:                      # 腕ごとに clip も指定できる（w を上げたときの交絡を切る）
        clip = float(mc.group(1))
    ml = re.search(r"_lr([0-9.]+)", base)
    if ml:                      # 腕ごとに lr も指定できる（clip × lr の 2×2 用）
        lr = float(ml.group(1))
    if use_kd and kd_w <= 0:
        raise SystemExit("cfg %s は KD を要求するが kd_w=%g。--kd_w を指定せよ"
                         % (cfg, kd_w))
    if use_hkd and hid_w <= 0:
        raise SystemExit("cfg %s は hidden KD を要求するが hid_w=%g。--hid_w を指定せよ"
                         % (cfg, hid_w))

    # --- 切り出し初期化（教師 ckpt は t_pk / t_ep のものを使う）---
    teacher = None
    if init_mode == "prune" or use_kd or use_hkd:
        tp = ckpt_name("teacher", N, seed, t_ep, t_pk)
        td = torch.load(tp, map_location="cpu")
        if use_kd or use_hkd:
            teacher = e2b.RewriteMoE(e2b.WIDTHS["H+LB"], seed=seed)
            teacher.p = {kk: v for kk, v in td.items()}
            for kk in teacher.p:
                teacher.p[kk].requires_grad_(False)
    if init_mode == "prune":
        sd = {}
        for kk, v in model.params().items():
            sd[kk] = v.detach().clone()
        for kk in ["emb.w", "pos.w", "head.w", "head.b"]:
            sd[kk] = td[kk].clone()
        for l in range(model.L):
            for kk in ["q.w", "k.w", "v.w", "o.w", "r.w", "r.b"]:
                sd["l%d.%s" % (l, kk)] = td["l%d.%s" % (l, kk)].clone()
            for i, ws in enumerate(widths):
                w1 = td["l%d.e%d.w1" % (l, i)]
                b1 = td["l%d.e%d.b1" % (l, i)]
                w2 = td["l%d.e%d.w2" % (l, i)]
                b2 = td["l%d.e%d.b2" % (l, i)]
                imp = w1.norm(dim=1) * w2.norm(dim=0)
                idx = torch.topk(imp, ws).indices.sort().values
                sd["l%d.e%d.w1" % (l, i)] = w1[idx].clone()
                sd["l%d.e%d.b1" % (l, i)] = b1[idx].clone()
                sd["l%d.e%d.w2" % (l, i)] = w2[:, idx].clone()
                sd["l%d.e%d.b2" % (l, i)] = b2.clone()
        model.p = sd
    for kk in model.p:
        model.p[kk].requires_grad_(True)

    opt = e2b.Adam(model.params(), lr=lr)
    dims = torch.tensor(model.dims, dtype=torch.float64)

    ev_rng = np.random.default_rng(4242)
    n_ev = int(min(N * 1, 200_000))
    ev_src, ev_out, ev_ids = K6.make_batch(ev_rng, n_ev, table, ids_fn)

    def evaluate():
        ce = np.zeros((n_ev, K6.OL_), dtype=np.float32)
        hit = np.zeros((n_ev, K6.OL_), dtype=bool)
        wsum, wn = 0.0, 0
        with torch.no_grad():
            for i in range(0, n_ev, 512):
                s = slice(i, min(i + 512, n_ev))
                x = torch.from_numpy(K6.to_seq(ev_src[s], ev_out[s], SEP))
                logits, _, idxs, _ = model(x, aux_mode="none", need_idx=True)
                lg = logits[:, K6.SL_:K6.SL_ + K6.OL_, :]
                lp = F.cross_entropy(lg.reshape(-1, V),
                                     torch.from_numpy(ev_out[s]).reshape(-1),
                                     reduction="none").reshape(-1, K6.OL_)
                ce[s] = lp.numpy()
                hit[s] = (lg.argmax(-1).numpy() == ev_out[s])
                for aa in idxs:
                    wsum += float(dims[aa].sum(-1).sum())
                    wn += aa.shape[0] * aa.shape[1]
        return ce, hit, wsum / max(wn, 1)

    ce0, hit0, w0 = evaluate()
    print("    [%s s%d N=%d] init CE=%.4f acc=%.4f w=%.1f"
          % (cfg, seed, N, ce0.mean(), hit0.mean(), w0), flush=True)

    teacher_ce = None
    if teacher is not None:
        with torch.no_grad():
            tce = []
            for i in range(0, n_ev, 512):
                s = slice(i, min(i + 512, n_ev))
                xt = torch.from_numpy(K6.to_seq(ev_src[s], ev_out[s], SEP))
                tl, _, _, _ = teacher(xt, aux_mode="none")
                lg = tl[:, K6.SL_:K6.SL_ + K6.OL_, :]
                lp = F.cross_entropy(lg.reshape(-1, V),
                                     torch.from_numpy(ev_out[s]).reshape(-1),
                                     reduction="none")
                tce.append(float(lp.mean()))
        teacher_ce = float(np.mean(tce))
        print("    [%s s%d N=%d] 教師 CE %.4f"
              % (cfg, seed, N, teacher_ce), flush=True)

    rng = np.random.default_rng(1000 + seed)
    n_tr = int(N * per_key)
    steps = max(1, n_tr // bs)
    need_hid = use_hkd and teacher is not None
    hist = []
    for ep in range(epochs):
        run, nclip, kdsum, hkdsum = 0.0, 0, 0.0, 0.0
        for _ in range(steps):
            src, out, _ = K6.make_batch(rng, bs, table, ids_fn)
            x = torch.from_numpy(K6.to_seq(src, out, SEP))
            logits, aux, _, s_hid = model(x, aux_mode=arm,
                                          need_hiddens=need_hid)
            lg = logits[:, K6.SL_:K6.SL_ + K6.OL_, :].reshape(-1, V)
            tgt = torch.from_numpy(out).reshape(-1)
            loss = F.cross_entropy(lg, tgt) + (auxw * aux if arm != "none" else 0.0)
            if teacher is not None:
                with torch.no_grad():
                    tlogits, _, _, t_hid = teacher(x, aux_mode="none",
                                                   need_hiddens=need_hid)
                    tlg = tlogits[:, K6.SL_:K6.SL_ + K6.OL_, :].reshape(-1, V)
                if use_kd:
                    ls = F.log_softmax(lg / kd_T, dim=-1)
                    lt = F.softmax(tlg / kd_T, dim=-1)
                    kdl = (lt * (torch.log(lt.clamp_min(1e-9)) - ls)).sum(-1).mean()
                    loss = loss + kd_w * (kd_T ** 2) * kdl
                    kdsum += float(kdl.detach())
                if need_hid:
                    # MSE on layer outputs (both are d=128)
                    hkd_loss = 0.0
                    for sl, tl in zip(s_hid, t_hid):
                        hkd_loss = hkd_loss + F.mse_loss(sl, tl.detach())
                    hkd_loss = hkd_loss / len(s_hid)  # average over layers
                    loss = loss + hid_w * hkd_loss
                    hkdsum += float(hkd_loss.detach() if hasattr(hkd_loss, 'detach') else hkd_loss)
            loss.backward()
            if clip > 0:
                tot = 0.0
                for v in model.params().values():
                    if v.grad is not None:
                        tot += float(v.grad.pow(2).sum())
                tot = tot ** 0.5
                if tot > clip:
                    s = clip / (tot + 1e-12)
                    for v in model.params().values():
                        if v.grad is not None:
                            v.grad.mul_(s)
                    nclip += 1
            opt.step(model.params())
            run += float(loss.detach())
        ce_ep, _, w_ep = evaluate()
        hist.append({"ep": ep + 1, "loss": run / steps, "ce": float(ce_ep.mean()),
                     "w": float(w_ep), "nclip": nclip,
                     "kd": (kdsum / steps) if teacher is not None else None,
                     "hkd": (hkdsum / steps) if need_hid else None})
        print("    [%s s%d N=%d] ep%d/%d loss=%.4f CE=%.4f w=%.1f clip=%d (%.0fs)"
              % (cfg, seed, N, ep + 1, epochs, run / steps, ce_ep.mean(), w_ep,
                 nclip, time.time() - t0), flush=True)

    tail = hist[-3:] if len(hist) >= 3 else hist
    ce, hit, width_mean = evaluate()
    if cfg == "teacher":
        os.makedirs(CKPTDIR, exist_ok=True)
        torch.save({kk: v.detach().clone() for kk, v in model.params().items()},
                   ckpt_name("teacher", N, seed, epochs, per_key))

    return {
        "cfg": cfg, "seed": seed, "N": N, "epochs": epochs,
        "per_key": per_key, "lr": lr, "clip": clip,
        "kd_w": kd_w, "kd_T": kd_T, "hid_w": hid_w,
        "teacher_ckpt": (ckpt_name("teacher", N, seed, t_ep, t_pk)
                          if (init_mode == "prune" or use_kd or use_hkd) else None),
        "teacher_ce": teacher_ce,
        "ce_init": float(ce0.mean()), "acc_init": float(hit0.mean()),
        "w_init": float(w0),
        "ce": float(np.median([h["ce"] for h in tail])),
        "ce_last": float(hist[-1]["ce"]),
        "ce_hist": hist,
        "acc": float(hit.mean()),
        "width_mean": float(np.median([h["w"] for h in tail])),
        "macs": float(4 * (4 * 128 * 128 + 2 * 128 * width_mean + 128 * model.E)),
        "nparam": int(sum(v.numel() for v in model.params().values())),
        "nparam_ffn": int(sum(v.numel() for kk, v in model.params().items()
                              if kk.startswith("l") and ".e" in kk)),
        "n_clip": int(sum(h["nclip"] for h in hist)),
        "sec": round(time.time() - t0, 1),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", nargs="+",
                    default=["teacher", "half:prune", "half:scratch"])
    ap.add_argument("--N", type=int, default=3000)
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4, 5])
    ap.add_argument("--per_key", type=int, default=10)
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--clip", type=float, default=5.0)
    ap.add_argument("--auxw", type=float, default=0.05)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--tag", type=str, default="n3k")
    ap.add_argument("--reuse_teacher", action="store_true",
                    help="教師 ckpt が揃っていれば prune も第 1 バッチで走らせる")
    ap.add_argument("--kd_w", type=float, default=0.0, help="logits KD の重み（0 で無効）")
    ap.add_argument("--kd_T", type=float, default=1.0, help="KD の温度")
    ap.add_argument("--hid_w", type=float, default=0.0, help="層出力 KD（MSE）の重み（0 で無効）")
    ap.add_argument("--teacher_pk", type=int, default=None,
                    help="教師 ckpt の per_key（省略時は生徒と同じ）")
    ap.add_argument("--teacher_epochs", type=int, default=None,
                    help="教師 ckpt の epoch 数（省略時は生徒と同じ）")
    args = ap.parse_args()
    t_pk = args.teacher_pk if args.teacher_pk is not None else args.per_key
    t_ep = args.teacher_epochs if args.teacher_epochs is not None else args.epochs

    LOG = os.path.join(HERE, "pc2_out_utf8_%s.txt" % args.tag)
    if os.path.exists(LOG):
        os.remove(LOG)

    def log(msg):
        print(msg, flush=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")

    log("PC2: 条件 A（切り出し初期化のみ）  N=%d seeds=%s epochs=%d lr=%g clip=%g"
        % (args.N, args.seeds, args.epochs, args.lr, args.clip))
    log("teacher W=%d / half W=%d" % (sum((32, 32, 96, 96, 160, 160, 224, 224)), sum(HALF)))

    # teacher を先に走らせる（ckpt が要る）。teacher に依存しない条件は同じプールに入れる
    order = ["teacher"] + [c for c in args.configs if c != "teacher"]
    need = [c for c in order if c.startswith("half:") and not c.startswith("half:scratch")]
    have = all(os.path.exists(ckpt_name("teacher", args.N, s, t_ep, t_pk))
               for s in args.seeds)
    if args.reuse_teacher and have:
        batches = [[c for c in order if c != "teacher"] or ["teacher"]]
        if "teacher" in args.configs:
            batches = [order]
        log("  教師 ckpt を再利用（prune も第 1 バッチ）")
    else:
        batches = [[c for c in order if c not in need]]
        if need:
            batches.append(need)
    t0 = time.time()
    rows = []
    part = os.path.join(HERE, "pc2_partial_%s.json" % args.tag)
    for bi, batch in enumerate(batches):
        jobs = [(cfg, s, args.N, args.per_key, args.epochs, args.bs, args.lr,
                 args.auxw, args.clip, args.kd_w, args.kd_T, t_pk, t_ep)
                for cfg in batch for s in args.seeds]
        with Pool(processes=min(args.workers, len(jobs))) as pool:
            for r in pool.imap_unordered(worker, jobs):
                rows.append(r)
                log("  %-14s N=%-6d s%d  init CE %.4f -> CE %.4f  acc %.4f  幅 %6.1f  (%.0fs)"
                    % (r["cfg"], r["N"], r["seed"], r["ce_init"], r["ce"],
                       r["acc"], r["width_mean"], r["sec"]))
                with open(part, "w", encoding="utf-8") as f:
                    json.dump(K6._clean({"rows": rows}), f, ensure_ascii=False, indent=2)
        log("  --- batch %d (%s) 完了 (%.0f 分経過) ---"
            % (bi + 1, "+".join(batch), (time.time() - t0) / 60))

    log("")
    log("== 集計（seed 平均）==")
    by = {}
    for r in rows:
        by.setdefault(r["cfg"], []).append(r)
    for cfg, rs in by.items():
        ce = np.array([r["ce"] for r in rs])
        ci = np.array([r["ce_init"] for r in rs])
        log("  %-14s n=%d  init CE %.4f  CE %.4f (sd %.4f)  acc %.4f  幅 %.1f  param %d"
            % (cfg, len(rs), ci.mean(), ce.mean(), ce.std(ddof=1),
               np.mean([r["acc"] for r in rs]), np.mean([r["width_mean"] for r in rs]),
               rs[0]["nparam"]))
    # 対応差
    def paired(a, b, key="ce"):
        A = {r["seed"]: r[key] for r in by.get(a, [])}
        B = {r["seed"]: r[key] for r in by.get(b, [])}
        ks = sorted(set(A) & set(B))
        if len(ks) < 2:
            return None
        d = np.array([A[k] - B[k] for k in ks])
        se = d.std(ddof=1) / np.sqrt(len(d))
        t = d.mean() / se if se > 0 else float("nan")
        return (d.mean(), se, t, len(ks), int((d < 0).sum()))

    log("")
    log("== 対応差（負 = 前者が良い）==")
    for a, b in [("half:prune+kd", "half:prune"),
                 ("half:scratch+kd", "half:scratch"),
                 ("half:prune+kd", "half:scratch+kd"),
                 ("half:prune", "half:scratch"),
                 ("teacher", "half:prune"), ("teacher", "half:scratch")]:
        r = paired(a, b)
        if r:
            log("  %-14s - %-14s  ΔCE %+0.4f  se %.4f  t %+0.2f  n %d  負 %d"
                % (a, b, r[0], r[1], r[2], r[3], r[4]))
        r = paired(a, b, "ce_init")
        if r:
            log("  %-14s - %-14s  ΔCE_init %+0.4f  se %.4f  t %+0.2f  n %d  負 %d"
                % (a, b, r[0], r[1], r[2], r[3], r[4]))

    log("")
    log("  壁時計 %.0f 分" % ((time.time() - t0) / 60))
    with open(os.path.join(HERE, "pc2_results_%s.json" % args.tag), "w",
              encoding="utf-8") as f:
        json.dump(K6._clean({"rows": rows, "args": vars(args)}), f,
                  ensure_ascii=False, indent=2)
    log("[write] pc2_results_%s.json" % args.tag)
    os._exit(0)


if __name__ == "__main__":
    main()
