#!/usr/bin/env python3
"""Q4: Q2 の U 字の底を狙う — ×4 / ×5 / ×6 で「acc ≈ 0.8」の帯を作る。

背景: Q3 §6 の予測「payload の正解率を 0.8 前後まで落とせば、CE 側に幅を買う余地が生まれて
Δ が負に転じる」。Q2 のラダーは copy 0.998 / hard(×3) 0.993 / compute 0.966 / harder(×7) 0.329 で、
**0.966 と 0.329 の間に点が無い**。ここを埋めるのが本スクリプト。

方針: **Q2 のハーネスをそのまま使う**（`q2_difficulty_ladder` を import して定数だけ差し替える）。
レイアウト（payload 80%、T=109）、訓練条件、評価 seed 777、RNG 消費順がすべて Q2 と同一なので、
結果は Q2 のラダーに直接つながる。

追加する op（Q2 の語彙 "0123456789ASDMK=:" に追記）:
  N = ×4 / P = ×5 / R = ×6      （既存: D=×2, M=×3, K=×7, A=+1, S=-1）
タスク: mul4 = "NNNNNNNNNN" / mul5 = "PPPPPPPPPP" / mul6 = "RRRRRRRRRR"

予測（事前登録）
  P1: acc_payload は ×3 (0.993) と ×7 (0.329) の間に来る。どこかで 0.8 前後を踏む
  P2: acc ≈ 0.8 の点で Δ が最小になる（Q2 の U 字の底）。0 を跨ぐ可能性
  P3: 幅で見ると payload の幅が最大になり、struct との差が最小になる
  Kill: acc 0.7–0.9 の点が 1 つも作れない（崖）→ 「幅で解けるか」の二値分割が支持される

出力: simulation_hmoe_mmlu/data/q4/{arm}_{task}_s{seed}.json / summary_{task}.csv / run_*.log
"""
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import q2_difficulty_ladder as Q2  # noqa: E402

# ---------------------------------------------------------------------------
# 語彙と op の拡張（Q2 のモジュール定数を書き換える）
# ---------------------------------------------------------------------------
NEW_OPS = {"N": 4, "P": 5, "R": 6}

Q2.VOCAB = Q2.VOCAB + "".join(NEW_OPS)
Q2.C2I = {c: i for i, c in enumerate(Q2.VOCAB)}
Q2.OP_ID = {ch: Q2.C2I[ch] for ch in Q2.OPS + "".join(NEW_OPS)}

Q2.TASKS.update({
    "mul4": "N" * Q2.P_STEPS,
    "mul5": "P" * Q2.P_STEPS,
    "mul6": "R" * Q2.P_STEPS,
})

_orig_apply = Q2.apply_op


def apply_op(v, ch):
    """Q2 の実装を拡張。新しい op だけ横取りする。"""
    if ch in NEW_OPS:
        return (v * NEW_OPS[ch]) % Q2.MOD
    return _orig_apply(v, ch)


Q2.apply_op = apply_op


if __name__ == "__main__":
    # main() は argparse の choices を TASKS から作るので、パッチ後に呼べば新タスクが通る
    Q2.main()
