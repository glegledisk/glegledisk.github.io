"""H8 の解析: expert-choice が二峰性と崩壊を同時に避けられるか。

seed は条件間で共通（同じデータ順・同じ初期化順）なので paired で比較する。
"""
import json
import os
from collections import defaultdict

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SUCCESS = 0.5
ORDER = ["tok_uni_k2", "tok_het_aux", "ec_uni", "ec_het"]


def load():
    rows = []
    with open(os.path.join(HERE, "h8_results.jsonl"), encoding="utf-8") as fp:
        for line in fp:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def paired(a, b):
    """a - b の paired 統計。"""
    d = np.asarray(a, float) - np.asarray(b, float)
    n = d.size
    if n < 2:
        return d.mean() if n else float("nan"), float("nan"), float("nan"), n
    se = d.std(ddof=1) / np.sqrt(n)
    t = d.mean() / se if se > 0 else float("inf")
    return d.mean(), se, t, n


def main():
    rows = load()
    if not rows:
        print("no data")
        return
    by = defaultdict(dict)
    for r in rows:
        by[r["cond"]][r["seed"]] = r

    conds = [c for c in ORDER if c in by]
    seeds = sorted(set.intersection(*[set(by[c]) for c in conds]))

    print("=== 条件別（seed %d 本、平均 ± SD）===" % len(seeds))
    print("%-12s %7s %7s %7s %7s %7s %7s %6s %6s" %
          ("cond", "val", "sd", "cost", "d1", "d1_sd", "share", "成功", "死"))
    for c in conds:
        rs = [by[c][s] for s in seeds]
        v = np.array([r["val"] for r in rs])
        cost = np.array([r["cost"] for r in rs])
        d1 = np.array([r["cells"]["depth1"] for r in rs])
        sh = np.array([r["diag"]["depth1"]["top1_share"] for r in rs])
        dead = np.array([r["diag"]["_dead"] for r in rs])
        print("%-12s %7.3f %7.3f %7.3f %7.3f %7.3f %7.3f %6s %6.1f" %
              (c, v.mean(), v.std(ddof=1), cost.mean(), d1.mean(), d1.std(ddof=1),
               sh.mean(), f"{int((d1 < SUCCESS).sum())}/{len(d1)}", dead.mean()))

    print("\n=== depth1 CE の paired 比較（負なら前者が良い）===")
    print("%-28s %8s %8s %8s %4s" % ("比較", "Δ", "se", "t", "n"))
    for a, b in [("ec_het", "tok_het_aux"), ("ec_het", "tok_uni_k2"),
                 ("ec_uni", "tok_uni_k2"), ("ec_het", "ec_uni")]:
        if a in by and b in by:
            xa = [by[a][s]["cells"]["depth1"] for s in seeds]
            xb = [by[b][s]["cells"]["depth1"] for s in seeds]
            m, se, t, n = paired(xa, xb)
            print("%-28s %8.3f %8.3f %8.2f %4d" % (f"{a} - {b}", m, se, t, n))

    print("\n=== val の paired 比較 ===")
    print("%-28s %8s %8s %8s %4s" % ("比較", "Δ", "se", "t", "n"))
    for a, b in [("ec_het", "tok_het_aux"), ("ec_het", "tok_uni_k2"),
                 ("ec_uni", "tok_uni_k2"), ("ec_het", "ec_uni")]:
        if a in by and b in by:
            xa = [by[a][s]["val"] for s in seeds]
            xb = [by[b][s]["val"] for s in seeds]
            m, se, t, n = paired(xa, xb)
            print("%-28s %8.3f %8.3f %8.2f %4d" % (f"{a} - {b}", m, se, t, n))

    print("\n=== per-expert 使用率（seed 平均）===")
    print("%-12s %s" % ("cond", "usage (8 experts)"))
    for c in conds:
        u = np.mean([by[c][s]["diag"]["_usage"] for s in seeds], axis=0)
        print("%-12s %s" % (c, " ".join("%.2f" % x for x in u)))

    print("\n=== depth 別の活性幅と集中度（seed 平均）===")
    print("%-12s %s" % ("cond", "d1 / d2 / d3 の幅  と  share"))
    for c in conds:
        rs = [by[c][s] for s in seeds]
        w = [np.mean([r["diag"][k]["width"] for r in rs]) for k in ("depth1", "depth2", "depth3")]
        sh = [np.mean([r["diag"][k]["top1_share"] for r in rs]) for k in ("depth1", "depth2", "depth3")]
        print("%-12s w=%.2f/%.2f/%.2f  share=%.2f/%.2f/%.2f" %
              (c, *w, *sh))

    print("\n=== 個別 seed の depth1 CE ===")
    print("%-12s %s" % ("cond", " ".join(f"s{s}" for s in seeds)))
    for c in conds:
        print("%-12s %s" % (c, " ".join("%5.3f" % by[c][s]["cells"]["depth1"] for s in seeds)))


if __name__ == "__main__":
    main()
