import os, time, urllib.request
os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"
os.environ["HF_HUB_DISABLE_XET"] = "1"

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tok_cache")
os.makedirs(OUT, exist_ok=True)

urls = {
    "llama3": "https://huggingface.co/NousResearch/Meta-Llama-3-8B/resolve/main/tokenizer.json",
    "olmo2": "https://huggingface.co/allenai/OLMo-2-0425-1B/resolve/main/tokenizer.json",
    "qwen3": "https://huggingface.co/Qwen/Qwen3-0.6B/resolve/main/tokenizer.json",
}

for key, url in urls.items():
    dst = os.path.join(OUT, key + ".json")
    if os.path.exists(dst) and os.path.getsize(dst) > 1e6:
        print(f"[cached] {key} {os.path.getsize(dst)/1e6:.2f} MB")
        continue
    try:
        t0 = time.time()
        req = urllib.request.Request(url, headers={"User-Agent": "curl/8"})
        with urllib.request.urlopen(req, timeout=180) as r, open(dst, "wb") as f:
            data = r.read()
            f.write(data)
        print(f"[DL OK] {key} {len(data)/1e6:.2f} MB {time.time()-t0:.1f}s")
    except Exception as e:
        print(f"[FAIL] {key}: {type(e).__name__}: {str(e)[:160]}")

from tokenizers import Tokenizer
for key in urls:
    p = os.path.join(OUT, key + ".json")
    try:
        tk = Tokenizer.from_file(p)
        print(f"[LOAD OK] {key} vocab={tk.get_vocab_size()}")
    except Exception as e:
        print(f"[LOAD NG] {key}: {type(e).__name__}: {str(e)[:160]}")
