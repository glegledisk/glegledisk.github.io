#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX9: 別 ckpt（OLMoE-1B-7B-0924-Instruct）で AX8 の確認的検定を再走する

設計書: AX9課題設計書_別ckptでAX8のfeasible等価とギャップが再現するかを検証する_20261114.md
（走行前にコーパス・文境界・probe 定義・確認的家族・δ・校正を凍結）

動かすのはモデルの重みのみ。c8 / c7 は新 ckpt で 32 本の ablate forward から測り直す。
新規 forward 45 本 = base_cap / base_rep / u7 / u7_rep / ab7_L*16 / ab6_L*16 /
  sent_oracle / sent_random / sent_random_s2 / sent_random_s3 / sent_probe /
  uni48_probe / uni340_probe / uni48_oracle / uni340_oracle

確認的（Holm m=2, alpha=0.05, 両側）
  S1（主）: G_sent_probe = 0
  S2      : G_sent_oracle - G_sent_probe = 0
TOST delta=0.005 は Holm 家族の外で独立報告。

実行:
  python ax9_cross_ckpt.py --dry-run
  python ax9_cross_ckpt.py --smoke --tag ax9smoke
  python ax9_cross_ckpt.py --tag ax9
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ax2_layer_cost import (  # noqa: E402  純関数のみ
    paired, tost, holm, spearman, gate_stats, randproj,
)
from ax8_feasible_probe import (  # noqa: E402  純関数のみ（main は import しない）
    N_LAYERS, H_STRATA, ALPHA, LAM, DELTA_TOST, MIN_SENT, BOUND_PERIOD,
    RAND_SEED, PERM_SEED, NPERM,
    build_sent_ids, sent_ids_tok, unit_targets, unit_decision,
    kmat_from_units, to_windows, ridge_loo, safe_max_abs_rho,
    grams8, overlap8, assert_finite,
)

AX6_CORPUS = os.path.join(HERE, "corpus_ids_ax6_w24_l256.npz")
AX3_CORPUS = os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz")
AX4_NPZ = os.path.join(HERE, "ax4_sentence_bound.npz")
AX8_NPZ = os.path.join(HERE, "ax8_feasible_probe.npz")
DESIGN = "AX9課題設計書_別ckptでAX8のfeasible等価とギャップが再現するかを検証する_20261114.md"
MODEL_DEFAULT = os.path.join(HERE, "models", "olmoe-1b-7b-instruct")
SEED_EXTRA = (1202, 1203)

TEE = None


def log(msg):
    print(msg, flush=True)
    if TEE is not None:
        TEE.write(msg + "\n")
        TEE.flush()


def uniform_lengths(n_unit, total):
    q, r = divmod(total, n_unit)
    ls = np.full(n_unit, q, dtype=np.int64)
    ls[:r] += 1
    return ls


def lengths_to_uid(ls):
    return np.repeat(np.arange(len(ls), dtype=np.int32), ls).astype(np.int32)


def random_decision(seed, n_unit):
    rng = np.random.RandomState(seed)
    cut = rng.randint(0, N_LAYERS, size=n_unit).astype(np.int8)
    draw = rng.randint(0, N_LAYERS - 1, size=n_unit)
    prot = (draw + (draw >= cut)).astype(np.int8)
    assert (cut != prot).all()
    return cut, prot


def load_corpus(n_win, ln, en_only):
    """AX6 / AX8 と同じ窓順。smoke は en の先頭 2*n_win 窓だけを使う。"""
    z = np.load(AX6_CORPUS, allow_pickle=True)
    langs = ("en",) if en_only else ("en", "ja")
    n_lg = 2 * n_win if en_only else n_win
    seqs = []
    for lg in langs:
        ids = z[lg + "_ids"].astype(np.int64)[:n_lg * ln]
        assert ids.size >= n_lg * ln
        for w in range(n_lg):
            seqs.append((lg, torch.from_numpy(ids[w * ln:(w + 1) * ln])))
    return seqs, z, n_lg


# ---------------------------------------------------------------- main
def main():
    global TEE
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=MODEL_DEFAULT)
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--tag", type=str, default="ax9")
    args = ap.parse_args()
    tag = args.tag
    TEE = open(os.path.join(HERE, "%s_out_utf8.txt" % tag), "w", encoding="utf-8")

    n_win = 3 if args.smoke else args.windows
    ln, n_eval = args.len, args.len - 1
    nw, n_tok = 2 * n_win, 2 * n_win * n_eval

    log("[1] corpus / partitions")
    seqs, zc, n_lg = load_corpus(n_win, ln, en_only=args.smoke)
    assert len(seqs) == nw, (len(seqs), nw)
    z3 = np.load(AX3_CORPUS, allow_pickle=True)

    sent_all, bstats = [], {}
    for lg in (("en",) if args.smoke else ("en", "ja")):
        ids = zc[lg + "_ids"].astype(np.int64)[:n_lg * ln]
        s, lens, nm = build_sent_ids(ids, BOUND_PERIOD, n_lg, ln)
        sent_all.append(sent_ids_tok(s, n_lg, n_eval))
        bstats[lg] = {"n_sent": int(lens.size), "mean_len": float(lens.mean()),
                      "median_len": float(np.median(lens)), "min_len": int(lens.min()),
                      "max_len": int(lens.max()), "n_merged": int(nm)}
        log("    %s n_sent %d mean %.1f max %d merged %d"
            % (lg, lens.size, lens.mean(), lens.max(), nm))
    off, joined = 0, []
    for x in sent_all:
        joined.append(x + off)
        off = int(x.max()) + 1
    sent = np.concatenate(joined).astype(np.int32)
    n_sent = int(sent.max()) + 1
    split_tok = n_lg * n_eval if not args.smoke else n_tok
    log("    total n_sent %d (en %d)  tokens %d  windows %d"
        % (n_sent, bstats["en"]["n_sent"], n_tok, nw))

    parts = {"sent": sent,
             "uni48": np.repeat(np.arange(nw, dtype=np.int32), n_eval),
             "uni340": lengths_to_uid(uniform_lengths(340, n_tok))}
    n_cnt = {}
    for nm, uid in parts.items():
        assert uid.shape == (n_tok,), (nm, uid.shape)
        assert np.array_equal(np.unique(uid), np.arange(uid.max() + 1)), nm
        assert np.bincount(uid).min() >= 1, nm
        a = int(uid[:split_tok].max()) + 1
        n_cnt[nm] = a
        if split_tok < n_tok:
            assert int(uid[split_tok:].min()) >= a, (nm, a)
    log("    n_en_units sent %d / uni48 %d / uni340 %d"
        % (n_cnt["sent"], n_cnt["uni48"], n_cnt["uni340"]))

    ov = {lg: overlap8(z3[lg + "_ids"], zc[lg + "_ids"]) for lg in ("en", "ja")}
    c2_pass = bool(ov["en"] < 0.05 and ov["ja"] < 0.20)
    log("    overlap8 en %.6f ja %.6f  pass %s" % (ov["en"], ov["ja"], c2_pass))

    seen, no_cross = set(), True
    for w in range(nw):
        sw = set(np.unique(sent[w * n_eval:(w + 1) * n_eval]).tolist())
        if sw & seen:
            no_cross = False
        seen |= sw
    assert no_cross, "文が窓をまたいでいる"

    if args.dry_run:
        # c8 / c7 は未測定なので、ゼロ配列で決定規則と予算会計の機構だけを確認する
        c8d = np.zeros((N_LAYERS, n_tok), dtype=np.float64)
        c7d = np.zeros((N_LAYERS, n_tok), dtype=np.float64)
        for nm, uid in parts.items():
            Yd = unit_targets(c8d, c7d, uid, int(uid.max()) + 1)
            cd, pd = unit_decision(Yd)
            km = kmat_from_units(uid, cd, pd, n_tok)
            assert np.all(km.sum(0) == 112), nm
            kmw = to_windows(km, nw, n_eval, ln, 7)
            assert abs(float(kmw.mean()) - 7.0) < 1e-9, (nm, kmw.mean())
        log("    dry-run OK (no model, no forward): parts=%s" % list(parts))
        TEE.close()
        return

    # ---------------------------------------------------------------- モデル
    log("[2] load model: %s" % args.model)
    t0 = time.time()
    from transformers import AutoModelForCausalLM, AutoTokenizer
    AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    d_model = int(model.config.hidden_size)
    full_k = int(model.config.num_experts_per_tok)
    assert full_k == 8 and int(model.config.num_hidden_layers) == N_LAYERS
    assert int(getattr(model.config, "num_experts", 64)) == 64
    gates = [l.mlp.gate for l in model.model.layers]
    gate_fwd = [g.forward for g in gates]
    log("    %.0f s  (%d windows, top_k=%d, d_model=%d)"
        % (time.time() - t0, nw, full_k, d_model))

    STATE = {"kmat": None}

    def make_masked(orig, li):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            km = STATE["kmat"]
            if km is not None and scores.shape[-1] == full_k:
                kk = km[li]
                if kk.numel() == scores.shape[0]:
                    ar = torch.arange(scores.shape[-1], device=scores.device, dtype=torch.float32)
                    scores = scores * (ar[None, :] < kk[:, None]).to(scores.dtype)
            return logits, scores, idx
        return _patched

    for i, g in enumerate(gates):
        g.forward = make_masked(gate_fwd[i], i)

    CAP = {"on": False, "g": None, "h": None}

    def gate_hook(li):
        def fn(module, inp, out):
            if CAP["on"]:
                CAP["g"][li] = out[0].detach().float().cpu()
        return fn

    def mlp_hook(s):
        def fn(module, inp, out):
            if CAP["on"]:
                CAP["h"][s] = inp[0].detach().float().cpu()[0]
        return fn

    for i, g in enumerate(gates):
        g.register_forward_hook(gate_hook(i))
    for s in H_STRATA:
        model.model.layers[s].mlp.register_forward_hook(mlp_hook(s))
    Rs = {s: torch.from_numpy(randproj(d_model, 256, seed=100 + s)) for s in H_STRATA}

    cache_dir = os.path.join(HERE, "_ax9_cache_%s" % tag)
    os.makedirs(cache_dir, exist_ok=True)

    def run_eval(name, native_topks=None, capture=False, kmat_windows=None):
        cf = os.path.join(cache_dir, name + ".npz")
        if os.path.exists(cf):
            c = np.load(cf)
            log("    %-18s CACHED CE %.5f" % (name, float(c["nll"].mean())))
            r = {"nll": c["nll"], "acc1": c["acc1"]}
            if capture:
                r.update({"G": c["G"], "H": c["H"], "ent": c["ent"]})
            return r
        t1 = time.time()
        if kmat_windows is not None:
            for g in gates:
                g.top_k = full_k
        else:
            STATE["kmat"] = None
            tk = full_k if native_topks is None else native_topks
            for i, g in enumerate(gates):
                g.top_k = int(tk[i] if not np.isscalar(tk) else tk)
        nll_c, a1_c, ent_c = [], [], []
        capG = [None] * N_LAYERS
        capH = {s: None for s in H_STRATA}
        G_big = np.zeros((N_LAYERS, n_tok, 64), dtype=np.float32) if capture else None
        H_big = np.zeros((len(H_STRATA), n_tok, 256), dtype=np.float32) if capture else None
        CAP["on"] = capture
        CAP["g"], CAP["h"] = capG, capH
        with torch.no_grad():
            for wi, (lg, ids) in enumerate(seqs):
                if kmat_windows is not None:
                    STATE["kmat"] = torch.from_numpy(
                        kmat_windows[:, wi * ln:(wi + 1) * ln].astype(np.float32)
                    ).to(model.device)
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                logit = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(logit, tgt, reduction="none")
                true_l = logit.gather(1, tgt.unsqueeze(-1))
                a1_c.append(((logit > true_l).sum(-1) == 0).float().cpu().numpy())
                nll_c.append(nll.cpu().numpy())
                if capture:
                    p = torch.softmax(logit, dim=-1)
                    ent_c.append(-(p * torch.log(p + 1e-12)).sum(-1).cpu().numpy())
                    ssl = slice(wi * n_eval, (wi + 1) * n_eval)
                    for i in range(N_LAYERS):
                        G_big[i, ssl] = capG[i].numpy()[:n_eval]
                    for si, s in enumerate(H_STRATA):
                        H_big[si, ssl] = capH[s].numpy()[:n_eval] @ Rs[s].numpy()
                del out, logit
        STATE["kmat"] = None
        CAP["on"] = False
        nll = np.concatenate(nll_c).astype(np.float32)
        a1 = np.concatenate(a1_c).astype(np.float32)
        r = {"nll": nll, "acc1": a1}
        if capture:
            r.update({"G": G_big, "H": H_big, "ent": np.concatenate(ent_c)})
        save = {"nll": nll, "acc1": a1}
        if capture:
            save.update({"G": G_big, "H": H_big, "ent": r["ent"]})
        np.savez_compressed(cf, **save)
        log("    %-18s CE %.5f  top1 %.4f  (%.0f s)"
            % (name, nll.mean(), a1.mean(), time.time() - t1))
        return r

    # ---------------------------------------------------------------- native 36 本
    log("[3] native forwards (36)")
    res, native = {}, []
    native.append(("base_cap", [full_k] * N_LAYERS, True))
    native.append(("base_rep", [full_k] * N_LAYERS, False))
    native.append(("u7", [7] * N_LAYERS, False))
    native.append(("u7_rep", [7] * N_LAYERS, False))
    for L in range(N_LAYERS):
        native.append(("ab7_%02d" % L, [7 if i == L else full_k for i in range(N_LAYERS)], False))
    for L in range(N_LAYERS):
        native.append(("ab6_%02d" % L, [6 if i == L else full_k for i in range(N_LAYERS)], False))
    for nm, tk, cap in native:
        res[nm] = run_eval(nm, native_topks=tk, capture=cap)

    N = {k: v["nll"].astype(np.float64) for k, v in res.items()}
    c1 = {"base_maxdiff": float(np.abs(N["base_cap"] - N["base_rep"]).max()),
          "u7_maxdiff": float(np.abs(N["u7"] - N["u7_rep"]).max()),
          "scope": "smoke_en6" if args.smoke else "full_48"}
    c1["tier"] = "A" if (c1["base_maxdiff"] == 0.0 and c1["u7_maxdiff"] == 0.0) else "B"
    log("    C1 %s  base %.3e  u7 %.3e  scope %s"
        % (c1["tier"], c1["base_maxdiff"], c1["u7_maxdiff"], c1["scope"]))
    assert c1["tier"] == "A", "C1 FAIL: 同一プロセス内の eval がビット安定でない"

    c8 = np.stack([N["ab7_%02d" % L] - N["base_cap"] for L in range(N_LAYERS)])
    c7 = np.stack([N["ab6_%02d" % L] - N["ab7_%02d" % L] for L in range(N_LAYERS)])
    log("    c8 mean %.6f  c7 mean %.6f" % (c8.mean(), c7.mean()))

    # ---------------------------------------------------------------- 124 列特徴 S
    log("[4] unit features / probes")
    r_base = res["base_cap"]
    G_big, ent = r_base["G"], r_base["ent"].astype(np.float64)
    nll_b = r_base["nll"].astype(np.float64)
    a1_b = r_base["acc1"].astype(np.float64)

    def make_S(uid, nm):
        n_unit = int(uid.max()) + 1
        cnt = np.bincount(uid, minlength=n_unit).astype(np.float64)
        cols = []
        for L in range(N_LAYERS):
            gs = gate_stats(G_big[L]).astype(np.float64)
            cols.append(np.stack([np.bincount(uid, weights=gs[:, j], minlength=n_unit) / cnt
                                  for j in range(7)], axis=1))
        S_gstat = np.concatenate(cols, axis=1)
        S_stat = []
        for u in range(n_unit):
            m = (uid == u)
            nb, eb, ab = nll_b[m], ent[m], a1_b[m]
            S_stat.append([nb.mean(), nb.std(), np.percentile(nb, 90), nb.max(), np.median(nb),
                           eb.mean(), eb.std(), ab.mean(), ab.std(),
                           float(np.abs(np.diff(nb)).mean()) if nb.size > 1 else 0.0])
        S_stat = np.array(S_stat)
        a = n_cnt[nm]
        S_pos = np.stack([np.arange(n_unit) % max(1, a),
                          np.concatenate([np.zeros(a), np.ones(n_unit - a)])], axis=1)
        S = np.concatenate([S_gstat, S_stat, S_pos], axis=1)
        assert S.shape[1] == 124, S.shape
        return S

    Y = {nm: unit_targets(c8, c7, uid, int(uid.max()) + 1)
         for nm, uid in parts.items()}
    DEC_ORACLE = {nm: unit_decision(Y[nm]) for nm in parts}
    probe_dec, probe_quality, S_all, pred_all = {}, {}, {}, {}
    for nm in ("uni48", "sent", "uni340"):
        t1 = time.time()
        S = make_S(parts[nm], nm)
        pred = ridge_loo(S, Y[nm])
        probe_dec[nm] = unit_decision(pred)
        S_all[nm], pred_all[nm] = S, pred
        probe_quality[nm] = {
            "n_unit": int(Y[nm].shape[0]),
            "r2": 1.0 - float(((Y[nm] - pred) ** 2).sum()
                              / ((Y[nm] - Y[nm].mean(0)) ** 2).sum()),
            "max_abs_rho": safe_max_abs_rho(Y[nm], pred),
        }
        log("    %-10s S %s  R2 %+.4f  rho %.4f  (%.0f s)"
            % (nm, S.shape, probe_quality[nm]["r2"],
               probe_quality[nm]["max_abs_rho"], time.time() - t1))

    log("    C7 permutation (%d)" % NPERM)
    rng = np.random.RandomState(PERM_SEED)
    null, S_sent, Y_sent = [], S_all["sent"], Y["sent"]
    for it in range(NPERM):
        p = rng.permutation(Y_sent.shape[0])
        Yp = Y_sent[p]
        pr = ridge_loo(S_sent, Yp)
        null.append(safe_max_abs_rho(Yp, pr))
        if (it + 1) % 25 == 0:
            log("      perm %d/%d" % (it + 1, NPERM))
    null = np.array(null)
    c7cal = {"observed_statistic": "max_j abs(Spearman(Y_sent[:,j], pred_loo[:,j]))",
             "observed": probe_quality["sent"]["max_abs_rho"],
             "n_perm": NPERM, "null_mean": float(null.mean()),
             "null_p95": float(np.percentile(null, 95)), "null_max": float(null.max()),
             "judgement": "record_only"}

    # ---------------------------------------------------------------- mask 7 本
    log("[5] mask forwards (9)")
    n_s = Y["sent"].shape[0]
    rnd = {"sent_random": random_decision(RAND_SEED, n_s)}
    for i, sd in enumerate(SEED_EXTRA, start=2):
        rnd["sent_random_s%d" % i] = random_decision(sd, n_s)

    def km_of(part, cut, prot):
        return to_windows(kmat_from_units(parts[part], cut, prot, n_tok),
                          nw, n_eval, ln, 7)

    arms = [("sent_oracle", "sent", DEC_ORACLE["sent"]),
            ("sent_random", "sent", rnd["sent_random"]),
            ("sent_random_s2", "sent", rnd["sent_random_s2"]),
            ("sent_random_s3", "sent", rnd["sent_random_s3"]),
            ("sent_probe", "sent", probe_dec["sent"]),
            ("uni48_probe", "uni48", probe_dec["uni48"]),
            ("uni340_probe", "uni340", probe_dec["uni340"]),
            ("uni48_oracle", "uni48", DEC_ORACLE["uni48"]),
            ("uni340_oracle", "uni340", DEC_ORACLE["uni340"])]
    for nm, part, (cut, prot) in arms:
        km = km_of(part, cut, prot)
        assert abs(float(km.mean()) - 7.0) < 1e-9, (nm, km.mean())
        N[nm] = run_eval(nm, kmat_windows=km)["nll"].astype(np.float64)

    # ---------------------------------------------------------------- 統計
    log("[6] stats / calibration")
    u7 = N["u7"]
    gain_names = [nm for nm, _, _ in arms]
    gains = {nm: paired(u7 - N[nm], nw, n_eval) for nm in gain_names}
    st1 = gains["sent_probe"]
    st2 = paired(N["sent_probe"] - N["sent_oracle"], nw, n_eval)
    ph = holm({"S1": st1["p_two"], "S2": st2["p_two"]})
    rej = {k: bool(ph[k] < ALPHA) for k in ph}
    eq = tost(st1, DELTA_TOST)
    if rej["S1"] and st1["mean"] > 0:
        case = "A"
    elif rej["S1"] and st1["mean"] < 0:
        case = "D"
    elif not rej["S1"] and rej["S2"]:
        case = "B"
    else:
        case = "C"

    # 独立 ckpt の参照（保存 NLL から再計算・点推定のみ）
    z4 = np.load(AX4_NPZ)
    u4 = z4["nll_u7_rep"].astype(np.float64)
    ax4_ref = {"G_sent_probe": float((u4 - z4["nll_sent_probe"].astype(np.float64)).mean()),
               "G_sent_oracle": float((u4 - z4["nll_sent_oracle"].astype(np.float64)).mean()),
               "gap": float((z4["nll_sent_probe"].astype(np.float64)
                             - z4["nll_sent_oracle"].astype(np.float64)).mean())}
    z8 = np.load(AX8_NPZ)
    u8 = z8["nll_u7_rep"].astype(np.float64)
    ax8_ref = {"G_sent_probe": float((u8 - z8["nll_sent_probe"].astype(np.float64)).mean()),
               "G_sent_oracle": float((u8 - z8["nll_sent_oracle"].astype(np.float64)).mean()),
               "gap": float((z8["nll_sent_probe"].astype(np.float64)
                             - z8["nll_sent_oracle"].astype(np.float64)).mean()),
               "G_uni48_probe": float((u8 - z8["nll_uni48_probe"].astype(np.float64)).mean()),
               "G_uni340_probe": float((u8 - z8["nll_uni340_probe"].astype(np.float64)).mean())}

    # 校正
    dec_all = {nm: DEC_ORACLE[nm] for nm in parts}
    dec_all.update({nm + "_probe": probe_dec[nm] for nm in probe_dec})
    dec_all.update(rnd)
    replay = {nm: Y[nm] for nm in parts}
    replay.update({nm + "_probe": pred_all[nm] for nm in pred_all})
    c3 = {"decision_replay": {}, "mean_k": {}, "n_bad": 0}
    c4 = {"slots_per_token": 112, "n_bad": 0}
    c5 = {"conflicts": {}, "tie_min": 0}
    for nm, (cut, prot) in dec_all.items():
        base_nm = nm.replace("_probe", "").replace("_random_s2", "").replace("_random_s3", "")
        base_nm = base_nm.replace("_random", "")
        if nm in replay:
            rc, rp = unit_decision(replay[nm])
            ok = int(np.array_equal(cut, rc) and np.array_equal(prot, rp))
        else:
            ok = 1
        km = kmat_from_units(parts[base_nm], cut, prot, n_tok)
        c3["decision_replay"][nm] = ok
        c3["mean_k"][nm] = float(km.mean())
        c5["conflicts"][nm] = int((cut == prot).sum())
        if abs(float(km.mean()) - 7.0) >= 1e-9 or not ok:
            c3["n_bad"] += 1
        if not np.all(km.sum(0) == 112):
            c4["n_bad"] += 1
    c5["cut_hist_sent"] = np.bincount(
        DEC_ORACLE["sent"][0].astype(int), minlength=N_LAYERS).tolist()
    c6 = {"uniform": "u7", "random": "sent_random", "oracle": "sent_oracle",
          "probe": "sent_probe",
          "random_gain": gains["sent_random"]["mean"],
          "oracle_gain": gains["sent_oracle"]["mean"],
          "probe_gain": gains["sent_probe"]["mean"],
          "random_le_oracle": bool(gains["sent_random"]["mean"]
                                   <= gains["sent_oracle"]["mean"])}
    calib = {"C1": c1,
             "C2": {"overlap_en": ov["en"], "overlap_ja": ov["ja"], "pass": c2_pass},
             "C3": {"sent_contiguity": True, "no_cross_window": bool(no_cross),
                    "n_sent": n_sent, "n_sent_en": bstats["en"]["n_sent"],
                    "min_len_ok": bool(bstats["en"]["min_len"] >= MIN_SENT), **c3},
             "C4": c4, "C5": c5, "C6": c6, "C7": c7cal}

    rnd_gains = [gains["sent_random"]["mean"], gains["sent_random_s2"]["mean"],
                 gains["sent_random_s3"]["mean"]]
    out = {
        "meta": {"tag": tag, "smoke": bool(args.smoke), "windows": nw, "len": ln,
                 "n_tok": int(n_tok), "n_new_forwards": 45, "n_sent": n_sent,
                 "model": os.path.relpath(args.model, HERE).replace("\\", "/"),
                 "seed_rand": RAND_SEED, "seed_rand_extra": list(SEED_EXTRA),
                 "seed_perm": PERM_SEED, "lam": LAM, "delta_tost": DELTA_TOST,
                 "design": DESIGN},
        "confirmatory": {"S1_probe": st1, "S2_gap": st2, "holm": ph,
                         "reject": rej, "tost": eq, "case": case},
        "calib": calib, "gains": gains,
        "exploratory": {
            "sentence_stats": bstats,
            "probe_quality": probe_quality,
            "feasible_curve": {nm: gains[nm]["mean"] for nm in
                               ("uni48_probe", "sent_probe", "uni340_probe")},
            "oracle_curve": {nm: gains[nm]["mean"] for nm in
                             ("uni48_oracle", "sent_oracle", "uni340_oracle")
                             if nm in gains},
            "random_seed_gains": rnd_gains,
            "random_seed_spread": float(max(rnd_gains) - min(rnd_gains)),
            "ax4_reference": ax4_ref, "ax8_reference": ax8_ref,
            "boundary_probe_diff": gains["sent_probe"]["mean"] - gains["uni340_probe"]["mean"],
            "granularity_probe_diff": gains["sent_probe"]["mean"] - gains["uni48_probe"]["mean"],
        },
    }
    bad = assert_finite(out)
    assert not bad, "非有限値が JSON に混入: %s" % bad[:8]

    log("[7] save")
    with open(os.path.join(HERE, "%s_cross_ckpt.json" % tag), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2, allow_nan=False)
    save = {("nll_" + k): v for k, v in N.items()}
    save.update({"c8": c8, "c7": c7, "sent": sent})
    for nm in parts:
        save["Y_" + nm] = Y[nm]
    for nm in pred_all:
        save["S_" + nm] = S_all[nm]
        save["pred_" + nm] = pred_all[nm]
    for nm, uid in parts.items():
        save["uid_" + nm] = uid
    for nm, (cut, prot) in dec_all.items():
        save["cut_" + nm], save["prot_" + nm] = cut, prot
    for k, v in save.items():
        assert isinstance(v, np.ndarray) and v.dtype.kind in "fiu", \
            "npz に非数値が混入: %s (%s)" % (k, type(v))
    np.savez_compressed(os.path.join(HERE, "%s_cross_ckpt.npz" % tag), **save)

    log("")
    log("== confirmatory (Holm m=2, alpha=%.2f) ==" % ALPHA)
    log("S1 G_sent_probe  %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
        % (st1["mean"], st1["t"], st1["p_two"], ph["S1"], st1["mde"]))
    log("S2 gap           %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
        % (st2["mean"], st2["t"], st2["p_two"], ph["S2"], st2["mde"]))
    log("TOST delta %.3f  p_tost %.6g  equivalent %s" % (DELTA_TOST, eq["p_tost"], eq["equivalent"]))
    log("case = %s   (AX4 %+.8f / AX8 %+.8f / gap AX4 %+.8f AX8 %+.8f)"
        % (case, ax4_ref["G_sent_probe"], ax8_ref["G_sent_probe"],
           ax4_ref["gap"], ax8_ref["gap"]))
    log("feasible: uni48 %+.8f  sent %+.8f  uni340 %+.8f"
        % (gains["uni48_probe"]["mean"], gains["sent_probe"]["mean"],
           gains["uni340_probe"]["mean"]))
    log("calib C1 %s (%s)  C2 %s  C3 bad %d  C4 bad %d  C6 %s  C7 p95 %.4f"
        % (c1["tier"], c1["scope"], c2_pass, c3["n_bad"], c4["n_bad"],
           c6["random_le_oracle"], c7cal["null_p95"]))
    log("saved: %s_cross_ckpt.npz / .json  (non-finite check OK)" % tag)
    TEE.close()
    os._exit(0)


if __name__ == "__main__":
    main()
