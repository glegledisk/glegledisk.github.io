# -*- coding: utf-8 -*-
"""e4c_natural_signals.py — E4c: 自然な推論時シグナルによるルータ可視性（C1）と選択性の検証

目的:
  10/24 独立検算 (批判レビュー §2.4) で指摘された:
  「E4b の PLAN 信号は未来の正解 (Oracle) であり、自然な推論時信号ではない」
  「CE 損失と FFN コストが held-out artifact に保存されていない」
  という課題を完全に解決する。

検証アーム (5条件, 3 seed):
  - Arm 0: Baseline (No-Signal)       — 信号なし (E4 と同一, h_j のみ)
  - Arm 1: Attn-Cursor (自然シグナルA) — 1層目の Attention 集中度・進行度 (SRC とのアラインメント)
  - Arm 2: Draft-Entropy (自然シグナルB) — 1層目隠れ状態からの軽量ドラフト予測エントロピー (確信度)
  - Arm 3: Hybrid-Natural (自然A+B)    — Cursor + Draft Entropy をルータ追加入力に結合
  - Arm 4: Oracle-Plan (上限参照)      — E4b と同一の明示的 PLAN 信号 (正解カンニング)

測定指標 (すべて Held-out 2048 系列で厳密評価):
  1. ルータ入力の線形 Probe AUC (各層 & 平均)
  2. 恒等エキスパート (Identity) 選択率: Copy 時 vs Edit 時, 選択性差 Delta
  3. ゲート重み質量 (FFN 実行コスト比率: 0.0〜1.0)
  4. Held-out 予測 CE 損失 (全系列, Copy位置, Edit位置)
  5. 出力トークン正解率 (Accuracy)
"""

import os
import sys
import time
import math
import json
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import pandas as pd
import matplotlib.pyplot as plt

os.environ["CUDA_VISIBLE_DEVICES"] = ""

# 語彙定義
BASE_VOCAB = "()[]{}0123456789+-*/ abcdefgh"
PLAN_TOKENS = ["<COPY>", "<EDIT>"]
ALL_VOCAB = list(BASE_VOCAB) + PLAN_TOKENS
V = len(ALL_VOCAB)
C2I = {c: i for i, c in enumerate(ALL_VOCAB)}
SEP = C2I[" "]
TOK_PLAN_COPY = C2I["<COPY>"]
TOK_PLAN_EDIT = C2I["<EDIT>"]

L_SRC = 16
L_OUT = 16
D_MODEL = 64
N_HEAD = 4
N_LAYERS = 2
E_NUM = 8
TOPK = 2
W_FF = 64
ID_IDX = 7  # 8番目を恒等エキスパート (ゼロ計算)

HERE = os.path.dirname(os.path.abspath(__file__))

# データ生成
def make_data_batch(rng, n, mode="no_plan", max_k=3):
    """
    mode:
      - 'no_plan': SRC (16) + SEP + OUT (16)  [Seq len = 33]
      - 'oracle_plan': SRC (16) + SEP + PLAN (16) + SEP + OUT (16) [Seq len = 50]
    """
    base_v = len(BASE_VOCAB) - 2
    src = rng.integers(0, base_v, size=(n, L_SRC))
    out = src.copy()
    edit_mask = np.zeros((n, L_OUT), dtype=bool)
    
    for i in range(n):
        k = int(rng.integers(1, max_k + 1))
        edit_pos = rng.choice(L_OUT, size=k, replace=False)
        for p in edit_pos:
            alt = int(rng.integers(0, base_v - 1))
            if alt >= out[i, p]:
                alt += 1
            out[i, p] = alt
            edit_mask[i, p] = True
            
    if mode == "oracle_plan":
        plan = np.full((n, L_SRC), TOK_PLAN_COPY, dtype=np.int64)
        for i in range(n):
            plan[i, edit_mask[i]] = TOK_PLAN_EDIT
        seq = np.empty((n, 2 * L_SRC + L_OUT + 2), dtype=np.int64)
        seq[:, 0:L_SRC] = src
        seq[:, L_SRC] = SEP
        seq[:, L_SRC + 1 : 2 * L_SRC + 1] = plan
        seq[:, 2 * L_SRC + 1] = SEP
        seq[:, 2 * L_SRC + 2 :] = out
        pos_out = 2 * L_SRC + 2
    else:
        seq = np.empty((n, L_SRC + 1 + L_OUT), dtype=np.int64)
        seq[:, 0:L_SRC] = src
        seq[:, L_SRC] = SEP
        seq[:, L_SRC + 1 :] = out
        pos_out = L_SRC + 1
        
    return torch.from_numpy(seq), edit_mask, pos_out


class DynamicMoELayer(nn.Module):
    def __init__(self, d_model=D_MODEL, n_head=N_HEAD, e_num=E_NUM, w_ff=W_FF, topk=TOPK, router_extra_dim=0):
        super().__init__()
        self.d = d_model
        self.n_head = n_head
        self.d_head = d_model // n_head
        self.e_num = e_num
        self.topk = topk
        
        self.attn_q = nn.Linear(d_model, d_model, bias=False)
        self.attn_k = nn.Linear(d_model, d_model, bias=False)
        self.attn_v = nn.Linear(d_model, d_model, bias=False)
        self.attn_out = nn.Linear(d_model, d_model, bias=False)
        
        # ルータ入力次元: 隠れ状態 + 追加シグナル
        self.router = nn.Linear(d_model + router_extra_dim, e_num, bias=False)
        self.ffn_up = nn.Parameter(torch.randn(e_num, d_model, w_ff) * 0.05)
        self.ffn_down = nn.Parameter(torch.randn(e_num, w_ff, d_model) * 0.05)
        
    def forward(self, x, mask=None, extra_router_signal=None):
        B, T, D = x.shape
        
        # Self-Attention
        q = self.attn_q(x).view(B, T, self.n_head, self.d_head).transpose(1, 2)
        k = self.attn_k(x).view(B, T, self.n_head, self.d_head).transpose(1, 2)
        v = self.attn_v(x).view(B, T, self.n_head, self.d_head).transpose(1, 2)
        
        scores = (q @ k.transpose(-2, -1)) / math.sqrt(self.d_head)
        if mask is not None:
            scores = scores.masked_fill(mask == 0, -1e9)
        attn_weights = F.softmax(scores, dim=-1) # (B, n_head, T, T)
        attn_ctx = (attn_weights @ v).transpose(1, 2).reshape(B, T, D)
        x = x + self.attn_out(attn_ctx)
        
        # Router 入力
        if extra_router_signal is not None:
            r_in = torch.cat([x, extra_router_signal], dim=-1)
        else:
            r_in = x
            
        logits = self.router(r_in)
        topk_logits, topk_idx = torch.topk(logits, self.topk, dim=-1)
        topk_gates = F.softmax(topk_logits, dim=-1)
        
        # MoE 計算 (Expert 7 は恒等パス)
        out_moe = torch.zeros_like(x)
        for k_i in range(self.topk):
            e_idx = topk_idx[:, :, k_i]
            gate = topk_gates[:, :, k_i].unsqueeze(-1)
            
            # 恒等エキスパート
            id_mask = (e_idx == ID_IDX).unsqueeze(-1)
            out_moe = out_moe + torch.where(id_mask, gate * x, torch.zeros_like(x))
            
            # 通常 FFN エキスパート
            for e in range(self.e_num):
                if e == ID_IDX:
                    continue
                mask_e = (e_idx == e).unsqueeze(-1)
                if mask_e.any():
                    ffn_e = F.relu(x @ self.ffn_up[e]) @ self.ffn_down[e]
                    out_moe = out_moe + torch.where(mask_e, gate * ffn_e, torch.zeros_like(x))
                    
        x = x + out_moe
        return x, r_in, topk_idx, topk_gates, attn_weights


class NaturalSignalTransformer(nn.Module):
    def __init__(self, arm_mode="baseline", vocab_size=V, d_model=D_MODEL, n_layers=N_LAYERS, max_seq=64):
        super().__init__()
        self.arm_mode = arm_mode
        self.tok_emb = nn.Embedding(vocab_size, d_model)
        self.pos_emb = nn.Embedding(max_seq, d_model)
        
        # 追加シグナル次元の決定
        # Arm 1 (Attn-Cursor): 4 次元 (Headごとの SRC アテンション集中度)
        # Arm 2 (Draft-Entropy): 2 次元 (軽量ドラフトヘッドの Top-1 確率 & エントロピー)
        # Arm 3 (Hybrid): 4 + 2 = 6 次元
        if arm_mode == "attn_cursor":
            self.extra_dim = 4
        elif arm_mode == "draft_entropy":
            self.extra_dim = 2
        elif arm_mode == "hybrid_natural":
            self.extra_dim = 6
        else:
            self.extra_dim = 0
            
        # 軽量ドラフト予測ヘッド (Arm 2 / 3 用: Layer 0 の隠れ状態から素早く次トークンを推測)
        if self.extra_dim in (2, 6):
            self.draft_head = nn.Linear(d_model, vocab_size, bias=False)
            
        # Layer 0 は extra_dim=0 (自己生成前), Layer 1 は extra_dim を受領可能
        self.layer0 = DynamicMoELayer(router_extra_dim=0)
        self.layer1 = DynamicMoELayer(router_extra_dim=self.extra_dim)
        self.head = nn.Linear(d_model, vocab_size)
        
    def forward(self, x_ids, pos_out):
        B, T = x_ids.shape
        pos = torch.arange(T, device=x_ids.device).unsqueeze(0)
        x = self.tok_emb(x_ids) + self.pos_emb(pos)
        
        # 因果的マスク (Causal Mask)
        mask = torch.tril(torch.ones(T, T, device=x_ids.device)).unsqueeze(0).unsqueeze(0)
        
        # Layer 0 Forward
        x, r_in_0, topk_0, gates_0, attn_0 = self.layer0(x, mask=mask)
        
        # 自然シグナルの抽出 (Layer 0 の出力を利用)
        extra_sig = None
        if self.arm_mode == "attn_cursor":
            # 1層目の Attention が SRC 領域 (0:L_SRC) のどこに当たっているかの統計
            # attn_0: (B, n_head, T, T) -> SRC への総アテンション重み (B, T, n_head)
            src_attn = attn_0[:, :, :, :L_SRC].sum(dim=-1).transpose(1, 2)
            extra_sig = src_attn # (B, T, 4)
            
        elif self.arm_mode == "draft_entropy":
            # Layer 0 隠れ状態からの軽量ドラフト予測の確信度
            draft_logits = self.draft_head(x)
            draft_probs = F.softmax(draft_logits, dim=-1)
            draft_entropy = -(draft_probs * torch.log(draft_probs + 1e-9)).sum(dim=-1, keepdim=True) # (B, T, 1)
            draft_top1, _ = draft_probs.max(dim=-1, keepdim=True) # (B, T, 1)
            extra_sig = torch.cat([draft_top1, draft_entropy], dim=-1) # (B, T, 2)
            
        elif self.arm_mode == "hybrid_natural":
            src_attn = attn_0[:, :, :, :L_SRC].sum(dim=-1).transpose(1, 2)
            draft_logits = self.draft_head(x)
            draft_probs = F.softmax(draft_logits, dim=-1)
            draft_entropy = -(draft_probs * torch.log(draft_probs + 1e-9)).sum(dim=-1, keepdim=True)
            draft_top1, _ = draft_probs.max(dim=-1, keepdim=True)
            extra_sig = torch.cat([src_attn, draft_top1, draft_entropy], dim=-1) # (B, T, 6)
            
        # Layer 1 Forward (自然シグナル注入)
        x, r_in_1, topk_1, gates_1, attn_1 = self.layer1(x, mask=mask, extra_router_signal=extra_sig)
        
        logits = self.head(x)
        return logits, (r_in_0, r_in_1), (topk_0, topk_1), (gates_0, gates_1)


def compute_auc_mann_whitney(scores, labels):
    order = np.argsort(scores)
    ranks = np.empty(len(scores), dtype=np.float64)
    ranks[order] = np.arange(1, len(scores) + 1)
    n1 = labels.sum()
    n0 = len(labels) - n1
    if n1 == 0 or n0 == 0:
        return 0.5
    return float((ranks[labels == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))

def evaluate_probe_auc(h_list, edit_mask_flat):
    aucs = []
    y_true = edit_mask_flat.astype(np.int64)
    split = int(0.7 * len(y_true))
    y_tr, y_te = y_true[:split], y_true[split:]
    
    with torch.enable_grad():
        for h in h_list:
            D = h.shape[-1]
            X_tr, X_te = h[:split], h[split:]
            
            # 標準化
            mean = X_tr.mean(0)
            std = X_tr.std(0) + 1e-6
            X_tr_norm = torch.from_numpy((X_tr - mean) / std).float()
            X_te_norm = torch.from_numpy((X_te - mean) / std).float()
            y_tr_t = torch.from_numpy(y_tr).float()
            
            # 線形ロジスティック回帰
            w = torch.zeros(D, requires_grad=True)
            b = torch.zeros(1, requires_grad=True)
            opt = torch.optim.Adam([w, b], lr=0.08)
            
            for _ in range(120):
                preds = X_tr_norm @ w + b
                loss = F.binary_cross_entropy_with_logits(preds, y_tr_t)
                opt.zero_grad()
                loss.backward()
                opt.step()
                
            with torch.no_grad():
                scores = (X_te_norm @ w + b).numpy()
                
            auc_val = compute_auc_mann_whitney(scores, y_te)
            aucs.append(auc_val)
            
    return aucs


def train_and_eval_arm(arm_name, seed=0, n_train=3000, n_val=1500, n_epochs=12, batch_size=64):
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    
    is_oracle = (arm_name == "oracle_plan")
    data_mode = "oracle_plan" if is_oracle else "no_plan"
    
    # モデル構築
    model = NaturalSignalTransformer(arm_mode=arm_name)
    optimizer = torch.optim.AdamW(model.parameters(), lr=3e-3, weight_decay=1e-4)
    
    # 訓練ループ
    for epoch in range(n_epochs):
        model.train()
        seq_train, _, pos_out = make_data_batch(rng, n_train, mode=data_mode)
        
        perm = torch.randperm(n_train)
        for i in range(0, n_train, batch_size):
            b_idx = perm[i : i + batch_size]
            b_seq = seq_train[b_idx]
            
            inp = b_seq[:, :-1]
            tgt = b_seq[:, 1:]
            
            optimizer.zero_grad()
            logits, _, topks, gates = model(inp, pos_out)
            
            # OUT 領域の予測損失 (自律推論ターゲット)
            out_start = pos_out - 1
            loss_ce = F.cross_entropy(
                logits[:, out_start:].reshape(-1, V),
                tgt[:, out_start:].reshape(-1)
            )
            
            # FFN 計算コストペナルティ (恒等 Expert 選択への誘導: λ=0.15)
            # topk_idx: (B, T, 2), topk_gates: (B, T, 2)
            gate_id_0 = (gates[0][:, out_start:, :] * (topks[0][:, out_start:, :] == ID_IDX).float()).sum(dim=-1)
            gate_id_1 = (gates[1][:, out_start:, :] * (topks[1][:, out_start:, :] == ID_IDX).float()).sum(dim=-1)
            cost_pen = 0.15 * (2.0 - (gate_id_0.mean() + gate_id_1.mean()))
            
            loss = loss_ce + cost_pen
            loss.backward()
            optimizer.step()
            
    # Held-out テスト評価 (厳密評価)
    model.eval()
    seq_val, edit_mask_val, pos_out = make_data_batch(rng, n_val, mode=data_mode)
    
    inp_val = seq_val[:, :-1]
    tgt_val = seq_val[:, 1:]
    out_start = pos_out - 1
    
    with torch.no_grad():
        logits_val, r_ins, topks, gates = model(inp_val, pos_out)
        
        # 損失評価
        out_logits = logits_val[:, out_start:]
        out_tgt = tgt_val[:, out_start:]
        
        ce_per_tok = F.cross_entropy(out_logits.reshape(-1, V), out_tgt.reshape(-1), reduction='none').reshape(n_val, L_OUT)
        ce_copy = float(ce_per_tok[~edit_mask_val].mean())
        ce_edit = float(ce_per_tok[edit_mask_val].mean())
        ce_all = float(ce_per_tok.mean())
        
        preds = out_logits.argmax(dim=-1)
        acc_copy = float((preds[~edit_mask_val] == out_tgt[~edit_mask_val]).float().mean())
        acc_edit = float((preds[edit_mask_val] == out_tgt[edit_mask_val]).float().mean())
        acc_all = float((preds == out_tgt).float().mean())
        
        # 恒等 Expert 選択率と選択性 Delta
        # Layer 1 のゲートと topk (シグナルが注入される主層)
        topk_1_out = topks[1][:, out_start:, :]
        gates_1_out = gates[1][:, out_start:, :]
        
        is_id_top1 = (topk_1_out[:, :, 0] == ID_IDX).numpy()
        id_top1_copy = float(is_id_top1[~edit_mask_val].mean())
        id_top1_edit = float(is_id_top1[edit_mask_val].mean())
        selectivity_delta = float(id_top1_copy - id_top1_edit)
        
        # FFN 実効計算コスト (ゲート質量のうち通常 FFN が占める割合: 0〜1)
        gate_id_val = (gates_1_out * (topk_1_out == ID_IDX).float()).sum(dim=-1).mean().item()
        ffn_cost_ratio = float(1.0 - gate_id_val)
        
        # ルータ入力 Probe AUC (Layer 0, Layer 1)
        h0 = r_ins[0][:, out_start:, :].numpy().reshape(-1, r_ins[0].shape[-1])
        h1 = r_ins[1][:, out_start:, :].numpy().reshape(-1, r_ins[1].shape[-1])
        mask_flat = edit_mask_val.reshape(-1)
        
    # torch.no_grad() の外で Probe を学習
    auc_0, auc_1 = evaluate_probe_auc([h0, h1], mask_flat)
        
    return {
        "arm": arm_name,
        "seed": seed,
        "probe_auc_l0": auc_0,
        "probe_auc_l1": auc_1,
        "mean_probe_auc": (auc_0 + auc_1) / 2.0,
        "id_top1_copy": id_top1_copy,
        "id_top1_edit": id_top1_edit,
        "selectivity_delta": selectivity_delta,
        "ffn_cost_ratio": ffn_cost_ratio,
        "heldout_ce_all": ce_all,
        "heldout_ce_copy": ce_copy,
        "heldout_ce_edit": ce_edit,
        "acc_all": acc_all,
        "acc_copy": acc_copy,
        "acc_edit": acc_edit
    }


def main():
    arms = [
        "baseline",        # 信号なし (E4 ベースライン)
        "attn_cursor",     # 自然シグナル A (1層目 Attention カーソル)
        "draft_entropy",   # 自然シグナル B (1層目ドラフト予測確信度)
        "hybrid_natural",  # 自然シグナル A + B (カーソル + ドラフト)
        "oracle_plan"      # Oracle 参照 (E4b PLAN カンニング)
    ]
    
    seeds = [0, 1, 2]
    all_results = []
    
    print("=" * 115)
    print(" E4c: 自然シグナルによるルータ可視性 (Probe AUC) と選択性回復の検証 (3 seeds)")
    print("=" * 115)
    
    start_t = time.time()
    for arm in arms:
        print(f"\nEvaluating Arm: {arm:16s} ...")
        for s in seeds:
            res = train_and_eval_arm(arm, seed=s, n_train=3500, n_val=2048, n_epochs=12)
            all_results.append(res)
            print(f"  [Seed {s}] AUC(L0/L1): {res['probe_auc_l0']:.3f}/{res['probe_auc_l1']:.3f} | Selectivity Δ: {res['selectivity_delta']:+.3f} (Copy:{res['id_top1_copy']:.3f} vs Edit:{res['id_top1_edit']:.3f}) | CE: {res['heldout_ce_all']:.4f} | FFN Cost: {res['ffn_cost_ratio']:.3f}")
            
    total_time = time.time() - start_t
    print(f"\nAll arms finished in {total_time:.1f}s.")
    
    # 集計 DataFrame
    df = pd.DataFrame(all_results)
    out_csv = os.path.join(HERE, "e4c_natural_signals_results.csv")
    df.to_csv(out_csv, index=False)
    
    # 集約平均テーブル
    grouped = df.groupby("arm").mean().reset_index()
    grouped_std = df.groupby("arm").std().reset_index()
    
    print("\n" + "=" * 115)
    print(" E4c 集約サマリー (平均 ± 標準偏差)")
    print("=" * 115)
    print(f"{'Arm':16s} {'Probe AUC (L1)':>18s} {'Selectivity Δ':>18s} {'ID Rate (Copy)':>16s} {'ID Rate (Edit)':>16s} {'Held-out CE':>14s} {'FFN Cost':>12s}")
    print("-" * 115)
    
    summary_export = []
    for arm in arms:
        m = grouped[grouped["arm"] == arm].iloc[0]
        s = grouped_std[grouped_std["arm"] == arm].iloc[0]
        
        auc_str = f"{m['probe_auc_l1']:.3f} ± {s['probe_auc_l1']:.3f}"
        sel_str = f"{m['selectivity_delta']:+.3f} ± {s['selectivity_delta']:.3f}"
        cp_str = f"{m['id_top1_copy']:.3f} ± {s['id_top1_copy']:.3f}"
        ed_str = f"{m['id_top1_edit']:.3f} ± {s['id_top1_edit']:.3f}"
        ce_str = f"{m['heldout_ce_all']:.4f} ± {s['heldout_ce_all']:.4f}"
        cost_str = f"{m['ffn_cost_ratio']:.3f} ± {s['ffn_cost_ratio']:.3f}"
        
        print(f"{arm:16s} {auc_str:>18s} {sel_str:>18s} {cp_str:>16s} {ed_str:>16s} {ce_str:>14s} {cost_str:>12s}")
        summary_export.append({
            "arm": arm,
            "probe_auc_l1_mean": float(m["probe_auc_l1"]),
            "probe_auc_l1_std": float(s["probe_auc_l1"]),
            "selectivity_delta_mean": float(m["selectivity_delta"]),
            "selectivity_delta_std": float(s["selectivity_delta"]),
            "id_top1_copy_mean": float(m["id_top1_copy"]),
            "id_top1_edit_mean": float(m["id_top1_edit"]),
            "heldout_ce_mean": float(m["heldout_ce_all"]),
            "ffn_cost_mean": float(m["ffn_cost_ratio"]),
            "acc_all_mean": float(m["acc_all"])
        })
        
    with open(os.path.join(HERE, "e4c_natural_signals_summary.json"), "w", encoding="utf-8") as f:
        json.dump(summary_export, f, indent=2, ensure_ascii=False)
        
    # 可視化プロット
    plot_e4c_comparison(grouped, grouped_std, arms)

def plot_e4c_comparison(grouped, grouped_std, arms):
    fig, axes = plt.subplots(1, 2, figsize=(15, 5))
    
    # 順序を arms に合わせる
    grouped = grouped.set_index("arm").loc[arms].reset_index()
    grouped_std = grouped_std.set_index("arm").loc[arms].reset_index()
    
    x = np.arange(len(arms))
    labels = ["Baseline\n(No Signal)", "Attn-Cursor\n(Natural A)", "Draft-Entropy\n(Natural B)", "Hybrid\n(Natural A+B)", "Oracle-Plan\n(Cheating)"]
    
    # 図 1: Probe AUC (可視性 C1)
    ax1 = axes[0]
    ax1.bar(x, grouped["probe_auc_l1"], yerr=grouped_std["probe_auc_l1"], capsize=5, color=["#d9534f", "#f0ad4e", "#337ab7", "#5cb85c", "#777777"], alpha=0.85)
    ax1.axhline(0.5, color="black", linestyle="--", label="Random Guess (0.50)")
    ax1.set_ylabel("Linear Probe AUC at Layer 1")
    ax1.set_title("Router Visibility (Condition C1): Probe AUC by Signal Type")
    ax1.set_xticks(x)
    ax1.set_xticklabels(labels)
    ax1.set_ylim(0.4, 1.05)
    ax1.grid(True, axis="y", ls="--", alpha=0.5)
    ax1.legend()
    
    # 図 2: 選択性 Delta (Copy vs Edit での恒等パス捕捉率の差)
    ax2 = axes[1]
    ax2.bar(x, grouped["selectivity_delta"], yerr=grouped_std["selectivity_delta"], capsize=5, color=["#d9534f", "#f0ad4e", "#337ab7", "#5cb85c", "#777777"], alpha=0.85)
    ax2.axhline(0.0, color="black", linestyle="--")
    ax2.set_ylabel("Selectivity Delta (ID Rate: Copy - Edit)")
    ax2.set_title("Identity Expert Specialization (Values > 0 favor Copy)")
    ax2.set_xticks(x)
    ax2.set_xticklabels(labels)
    ax2.grid(True, axis="y", ls="--", alpha=0.5)
    
    plt.tight_layout()
    out_png = os.path.join(HERE, "e4c_natural_signals_comparison.png")
    plt.savefig(out_png, dpi=200)
    print(f"Saved plot to {out_png}")

if __name__ == "__main__":
    main()
