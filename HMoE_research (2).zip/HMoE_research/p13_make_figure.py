#!/usr/bin/env python3
"""P13c の作図。測定は p13c_retrain.py、解析は p13c_analyze.py。"""
import json
import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

matplotlib.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "MS Gothic", "sans-serif"]
matplotlib.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))
D, E, L = 128, 8, 4


def macs(W):
    return L * (4 * D * D + E * D + 2 * D * W) / 1e5      # 10^5 MAC


def main():
    R = json.load(open(os.path.join(HERE, "p13c_results.json"), encoding="utf-8"))
    seeds = [0, 1, 2]

    def rows(arm, cond):
        return [R["%s:s%d:%s" % (arm, s, cond)] for s in seeds
                if "%s:s%d:%s" % (arm, s, cond) in R]

    fig, axes = plt.subplots(1, 3, figsize=(16.5, 5.0))

    # ---------------- (a) CE vs active width ----------------
    ax = axes[0]
    series = {
        "HMoE（不均一, top-k）": ("H+LB", ["top1", "base"], "#c0392b", "o"),
        "均一 MoE（top-k）": ("U+LB", ["top1", "base"], "#2471a3", "s"),
    }
    for name, (arm, conds, col, mk) in series.items():
        xs, ys, es = [], [], []
        for c in conds:
            rr = rows(arm, c)
            xs.append(np.mean([r["width"] for r in rr]))
            ys.append(np.mean([r["ce_all"] for r in rr]))
            es.append(np.std([r["ce_all"] for r in rr], ddof=1) / np.sqrt(len(rr)))
        ax.errorbar(xs, ys, yerr=es, marker=mk, color=col, capsize=4, lw=1.6,
                    label=name, ms=7)
        for x, y, c in zip(xs, ys, conds):
            ax.annotate(c, (x, y), textcoords="offset points", xytext=(6, 6),
                        fontsize=8, color=col)

    dn = [r for r in R.values() if r["arm"] == "dense"]
    xs, ys, es = [], [], []
    for w in sorted(set(int(r["width"]) for r in dn)):
        rr = [r for r in dn if int(r["width"]) == w]
        xs.append(w)
        ys.append(np.mean([r["ce_all"] for r in rr]))
        es.append(np.std([r["ce_all"] for r in rr], ddof=1) / np.sqrt(len(rr)))
    ax.errorbar(xs, ys, yerr=es, marker="^", color="#1e8449", capsize=4, lw=1.6,
                label="dense（同一手順で訓練）", ms=8)
    ax.annotate("W=180 (467k params)", (180, ys[1]), textcoords="offset points",
                xytext=(6, 12), fontsize=8, color="#1e8449")

    ax.set_xlabel("active width（expert 幅の合計 / トークン）")
    ax.set_ylabel("CE（OUT 区間, 3 seed 平均）")
    ax.set_title("(a) 等 active 幅の前線 — dense が最も低い", fontsize=11)
    ax.legend(fontsize=8.5, loc="upper right")
    ax.grid(alpha=0.25)
    ax.set_xlim(20, 300)

    # ---------------- (b) layer-wise small-expert usage ----------------
    ax = axes[1]
    for arm, col, lab in (("H+LB", "#c0392b", "HMoE（幅 32 の 2 個）"),
                          ("U+LB", "#2471a3", "均一 MoE（expert 0,1）")):
        M = []
        for s in seeds:
            u = np.array(R["%s:s%d:base" % (arm, s)]["usage"])[:4]
            M.append(u[:, [0, 1]].sum(1) / 2.0)
        M = np.array(M)
        ax.plot(range(4), M.mean(0), marker="o", color=col, label=lab, lw=1.8, ms=7)
        ax.fill_between(range(4), M.mean(0) - M.std(0, ddof=1),
                        M.mean(0) + M.std(0, ddof=1), color=col, alpha=0.15)
    ax.set_xticks(range(4))
    ax.set_xticklabels(["層 0", "層 1", "層 2", "層 3"])
    ax.set_ylabel("小 expert の平均選択率")
    ax.set_ylim(0, 1)
    ax.set_title("(b) 幅の層別配分 — HMoE だけが後半層で狭くなる", fontsize=11)
    ax.legend(fontsize=8.5, loc="upper left")
    ax.grid(alpha=0.25)
    ax.annotate("3/3 seed で単調増加", (1.5, 0.9), fontsize=8.5, color="#c0392b")

    # ---------------- (c) forced-subset recovery ----------------
    ax = axes[2]
    labels = ["{0,1}\n最小 2 個", "{0,1,2,3}", "ランダム 2 個", "{2,3}", "{6,7}\n最大 2 個"]
    conds = ["s2", "q4", "r2", "u2", "l2"]
    w_h = [np.mean([r["width"] for r in rows("H+LB", c)]) for c in conds]
    a_h = [np.mean([r["acc_copy"] for r in rows("H+LB", c)]) for c in conds]
    a_u = [np.mean([r["acc_copy"] for r in rows("U+LB", c)]) for c in conds]
    x = np.arange(len(conds))
    ax.bar(x - 0.2, a_h, 0.4, color="#c0392b", label="HMoE")
    ax.bar(x + 0.2, a_u, 0.4, color="#2471a3", label="均一 MoE")
    base_h = np.mean([r["acc_copy"] for r in rows("H+LB", "base")])
    ax.axhline(base_h, color="#c0392b", ls="--", lw=1.2)
    ax.annotate("HMoE base %.2f" % base_h, (2.45, base_h + 0.025), fontsize=8,
                color="#c0392b")
    for i, (wh, ah) in enumerate(zip(w_h, a_h)):
        ax.annotate("W=%d" % wh, (i - 0.2, ah + 0.02), ha="center", fontsize=7.5,
                    color="#c0392b")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=8)
    ax.set_ylabel("copy 正解率（全層をその集合に固定）")
    ax.set_ylim(0, 1.08)
    ax.set_title("(c) 小 expert だけで base の 56〜75% を回収", fontsize=11)
    ax.legend(fontsize=8.5, loc="upper right")
    ax.grid(axis="y", alpha=0.25)

    fig.suptitle("P13: ゲート添字バグ修正後の HMoE — 幅の層別配分は本物、品質の優位は dense に負ける",
                 fontsize=12.5, y=1.00)
    fig.tight_layout()
    out = os.path.join(HERE, "p13_hmoe_path.png")
    fig.savefig(out, dpi=150, bbox_inches="tight")
    print("saved:", out)


if __name__ == "__main__":
    main()
