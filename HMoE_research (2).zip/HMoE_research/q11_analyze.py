#!/usr/bin/env python3
"""Q11 の解析: 型の割り当ては効いているか。

判定:
  static_swapped（payload→幅 32）が static_type と同等 → **割り当ては無関係。分離だけが効く**
  static_swapped が崩壊 → **payload に大きな expert を割り当てる必要がある**
"""
import json
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q11")
OUT = []
def w(s=""):
    print(s)
    OUT.append(s)


def st(x):
    x = np.asarray(x, float)
    n = len(x)
    m = x.mean()
    se = x.std(ddof=1) / np.sqrt(n)
    t = m / se if se > 0 else 0.0
    p = 2 * stats.t.sf(abs(t), df=n - 1) if se > 0 else 1.0
    return m, se, t, p, int((x > 0).sum()), int((x < 0).sum())


MODES = ["dynamic_lb", "static_type", "static_1x", "static_swapped"]
POOLW = {"static_type": ([32, 32], [224, 224]),
         "static_1x": ([32], [224]),
         "static_swapped": ([224, 224], [32, 32])}
D, ATT, SH_S, SH_P = 128, 4 * 128 * 128, 0.2, 0.8

vals = {}
for m in MODES:
    rows = []
    for s in range(6):
        p = os.path.join(DATA, f"H+LB_hard_{m}_s{s}.json")
        with open(p, encoding="utf-8") as f:
            rows.append(json.load(f))
    e = [r["eval"]["base"] for r in rows]
    vals[m] = {k: np.array([x[k] for x in e])
               for k in ("instr_valid", "acc_payload", "ce_payload",
                         "acc_struct", "width_struct", "width_payload")}
    vals[m]["sec"] = np.array([r["sec"] for r in rows])

w("=" * 84)
w("HARD  (n=6)")
w("=" * 84)

w("\n[1] 水準と計算量")
w(f"  {'mode':<15} {'iv':>7} {'se':>6} {'acc_pl':>8} {'ce_pl':>8} "
  f"{'w_st':>6} {'w_pl':>6} {'FFN':>8} {'総':>9}")
ref = None
for m in MODES:
    v = vals[m]
    if m in POOLW:
        ws, wp = POOLW[m]
        ffn = SH_S * sum(2 * D * x for x in ws) + SH_P * sum(2 * D * x for x in wp)
    else:
        ffn = (SH_S * 4 * D * v["width_struct"].mean()
               + SH_P * 4 * D * v["width_payload"].mean())
    tot = ATT + ffn
    if ref is None:
        ref = tot
    w(f"  {m:<15} {v['instr_valid'].mean():7.3f} {st(v['instr_valid'])[1]:6.3f} "
      f"{v['acc_payload'].mean():8.4f} {v['ce_payload'].mean():8.4f} "
      f"{v['width_struct'].mean():6.1f} {v['width_payload'].mean():6.1f} "
      f"{ffn:8.0f} {tot/ref:8.2f}×")

w("\n[2] per-seed instr_valid")
for m in MODES:
    w(f"  {m:<15} " + ", ".join(f"{x:.3f}" for x in vals[m]["instr_valid"]))

w("\n[3] 対応差（同一 seed, df=5）")
for a, b in [("static_swapped", "static_type"), ("static_swapped", "static_1x"),
             ("static_1x", "static_type"), ("static_type", "dynamic_lb"),
             ("static_swapped", "dynamic_lb")]:
    w(f"  --- {a} − {b} ---")
    for k, lab in [("instr_valid", "instr_valid"), ("acc_payload", "acc_payload"),
                   ("ce_payload", "ce_payload")]:
        d = vals[a][k] - vals[b][k]
        m, se, t, p, npos, nneg = st(d)
        w(f"    {lab:<14} {m:+.4f}  se {se:.4f}  t {t:+.2f}  p {p:.4f}  "
          f"正{npos}/負{nneg}  MDE {3.49*se:.3f}")

w("\n[4] 判定")
m, se, t, p, npos, nneg = st(vals["static_swapped"]["instr_valid"]
                             - vals["static_type"]["instr_valid"])
w(f"  static_swapped − static_type: {m:+.3f}, se {se:.3f}, p={p:.4f}, 正{npos}/6")
if p < 0.05 and m < 0:
    w("  → **割り当ては効いている**。payload に大きな expert が必要（分離だけでは足りない）")
elif p < 0.05 and m > 0:
    w("  → **逆割り当ての方が良い**（予想外）")
else:
    w("  → 区別できない。MDE を確認すること")

w("\n[5] payload の幅と token 精度（機構の確認）")
for m in MODES:
    v = vals[m]
    w(f"  {m:<15} width_pl {v['width_payload'].mean():6.1f}  "
      f"acc_pl {v['acc_payload'].mean():.4f}  ce_pl {v['ce_payload'].mean():.4f}")

with open(os.path.join(HERE, "q11_analysis_out_utf8.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(OUT) + "\n")
print("\n[written] q11_analysis_out_utf8.txt")
