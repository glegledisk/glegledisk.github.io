"""スモークテスト用の极小 OlmoeForCausalLM を作る（p1 パイプラインの検証）。"""
import os
import shutil
import torch
from transformers import OlmoeConfig, OlmoeForCausalLM

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "models", "_smoke_olmoe")
os.makedirs(OUT, exist_ok=True)

torch.manual_seed(0)
cfg = OlmoeConfig(
    vocab_size=49152,
    hidden_size=64,
    intermediate_size=128,
    num_hidden_layers=2,
    num_attention_heads=4,
    num_key_value_heads=2,
    num_local_experts=8,
    num_experts_per_tok=2,
    max_position_embeddings=512,
    hidden_act="silu",
    initializer_range=0.02,
    rms_norm_eps=1e-6,
    tie_word_embeddings=False,
)
model = OlmoeForCausalLM(cfg)
n = sum(p.numel() for p in model.parameters())
print("params:", n, "experts:", cfg.num_local_experts, "top_k:", cfg.num_experts_per_tok)
model.save_pretrained(OUT)

# トークナイザは SmolLM-135M のものを流用（ids は vocab_size 内に収まる）
src = os.path.join(HERE, "models", "smollm-135m")
for f in ["tokenizer.json", "tokenizer_config.json", "special_tokens_map.json"]:
    s = os.path.join(src, f)
    if os.path.exists(s):
        shutil.copy(s, os.path.join(OUT, f))
print("saved to", OUT)
