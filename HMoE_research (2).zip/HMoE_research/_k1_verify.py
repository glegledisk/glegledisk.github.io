#!/usr/bin/env python3
"""K1 の検算: k1_results.json の要約値を、k1_ce_seq.npz の生配列から再計算して照合する。

AGENTS.md §3 Step 4 の要求:
  - ΔCE を .npz からもう一度計算し、ログの値と一致するか
  - t を再計算する
  - 件数を数え直す
  - baseline が既存報告書とビット一致するか（ここでは MACs 会計を P13 の 3 点で校正）
  - 平均が裾に支配されていないか（per-sequence Δ の分位点）

出力: k1_verify_out_utf8.txt
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "k1_verify_out_utf8.txt")
lines = []


def p(s=""):
    print(s, flush=True)
    lines.append(s)


def tstat(d):
    d = np.asarray(d, dtype=np.float64)
    n = len(d)
    se = d.std(ddof=1) / np.sqrt(n)
    return d.mean(), se, d.mean() / se if se > 0 else float("nan"), n


def main():
    res = json.load(open(os.path.join(HERE, "k1_results.json"), encoding="utf-8"))
    z = np.load(os.path.join(HERE, "k1_ce_seq.npz"))
    p("keys: %s" % sorted(z.files))
    p("")

    # 1) MACs 会計の校正（P13 の 3 点を再現できるか）
    p("== 1) MACs 会計の校正 ==")
    p("式: MACs/tok = L*(4*d^2 + 2*d*W + d*E), L=4, d=128, E=8（P13 と同じ会計）")
    for W, ref in ((97, 365568), (180, 450560), (256, 528384)):
        mine = 4 * (4 * 128 * 128 + 2 * 128 * W + 128 * 8)
        p("  W=%3d  計算 %d  P13 %d  差 %+d  %s"
          % (W, mine, ref, mine - ref, "一致" if mine == ref else "不一致"))
    p("")

    # 2) 実行条件の件数
    p("== 2) 件数 ==")
    n_eval = None
    for k in sorted(z.files):
        a = z[k]
        n_eval = a.shape[0] if n_eval is None else n_eval
        assert a.shape[0] == n_eval, (k, a.shape)
    p("  ce_seq の長さ: %d（全 %d 配列で一致）" % (n_eval, len(z.files)))
    p("  n_eval(meta) = %d" % res["meta"]["n_eval"])
    p("  threads = %d / wall = %.0f min" % (res["meta"]["threads"], res["meta"]["wall_sec"] / 60))
    p("")

    # 3) 対応差の再計算（seed 内）と、seed 単位の集計
    p("== 3) ΔCE(student − teacher) の再計算 ==")
    seeds = res["args"]["seeds"] if "args" in res else [0, 1, 2]
    widths = res["args"]["widths"] if "args" in res else [128, 161, 180]
    p("  seeds=%s widths=%s" % (seeds, widths))
    agg = {}
    for w in widths:
        ds = []
        p("  -- dense%d --" % w)
        for s in seeds:
            a = z["dense%d:s%d" % (w, s)]
            b = z["teacher:s%d" % s]
            m, se, t, n = tstat(a - b)
            ds.append(m)
            r = res["runs"]["diff:dense%d:s%d" % (w, s)]
            ok = (abs(m - r["delta"]) < 1e-9 and abs(se - r["se"]) < 1e-9
                  and abs(t - r["t"]) < 1e-6)
            # 裾の確認
            d = a - b
            q = np.percentile(d, [1, 25, 50, 75, 99])
            p("     s%d  Δ %+.4f  se %.4f  t %+.2f  n %d  %s | p1 %+.3f p25 %+.3f "
              "med %+.3f p75 %+.3f p99 %+.3f | 負の割合 %.3f"
              % (s, m, se, t, n, "一致" if ok else "不一致", q[0], q[1], q[2], q[3], q[4],
                 float((d < 0).mean())))
        ds = np.array(ds)
        m, se, t, n = tstat(ds)
        r = res["agg"]["dense%d" % w]
        ok = abs(m - r["delta_mean"]) < 1e-9 and abs(se - r["se"]) < 1e-9
        p("     seed 集計: Δ %+.4f  se %.4f  t %+.2f  n %d  %d/%d で負  MDE %.4f  %s"
          % (m, se, t, n, int((ds < 0).sum()), n, r["mde"], "一致" if ok else "不一致"))
        agg[w] = (m, se, t)
    p("")

    # 4) 絶対 CE の再計算
    p("== 4) 絶対 CE（seed 平均） ==")
    for cond, key in (("teacher", "teacher"), ("dense128", "dense128"),
                      ("dense161", "dense161"), ("dense180", "dense180")):
        vals = [float(z["%s:s%d" % (key, s)].mean()) for s in seeds]
        p("  %-9s %s  mean %.4f  sd %.4f" % (cond, " ".join("%.4f" % v for v in vals),
                                             np.mean(vals), np.std(vals, ddof=1)))
    p("")

    # 5) 型別 CE（copy / edit）と、教師の幅・MACs
    p("== 5) 型別 CE と教師の幅 ==")
    for s in seeds:
        rt = res["runs"]["teacher:s%d" % s]
        macs = 4 * (4 * 128 * 128 + 2 * 128 * rt["width"] + 128 * 8)
        p("  s%d teacher  CE_all %.4f  CE_copy %.4f  CE_edit %.4f  width %.1f  MACs %d"
          % (s, rt["ce_all"], rt["ce_copy"], rt["ce_edit"], rt["width"], macs))
        for w in widths:
            rs = res["runs"]["dense%d:s%d" % (w, s)]
            p("     dense%-3d CE_all %.4f  CE_copy %.4f  CE_edit %.4f  MACs %d  比 %.3f"
              % (w, rs["ce_all"], rs["ce_copy"], rs["ce_edit"],
                 4 * (4 * 128 * 128 + 2 * 128 * w + 128 * 1),
                 (4 * (4 * 128 * 128 + 2 * 128 * rt["width"] + 128 * 8))
                 / (4 * (4 * 128 * 128 + 2 * 128 * w + 128 * 1))))
    p("")

    # 6) 教師の幅が seed で動くことの帰結
    p("== 6) 等 MACs の成立度 ==")
    for s in seeds:
        rt = res["runs"]["teacher:s%d" % s]
        mt = 4 * (4 * 128 * 128 + 2 * 128 * rt["width"] + 128 * 8)
        md = 4 * (4 * 128 * 128 + 2 * 128 * 161 + 128 * 1)
        p("  s%d: teacher W=%.1f → %d MACs / dense161 → %d MACs（教師/生徒 = %.3f）"
          % (s, rt["width"], mt, md, mt / md))
    p("")

    # 7) 参考: dense180 と dense161 の差（幅の効き）
    p("== 7) dense180 − dense161（同一 seed 内） ==")
    for s in seeds:
        m, se, t, n = tstat(z["dense180:s%d" % s] - z["dense161:s%d" % s])
        p("  s%d  Δ %+.4f  se %.4f  t %+.2f" % (s, m, se, t))
    p("")

    # 8) 判定の材料: 3/3 の符号検定
    p("== 8) 符号検定（両側, n=3） ==")
    p("  3/3 同符号の両側 p = 0.25（3/3 は「一貫」だが単独では有意でない）")
    p("  t の臨界値（df=2, 両側 5%%）= 4.303")
    for w in widths:
        m, se, t = agg[w]
        p("  dense%-3d t=%+.2f  → %s" % (w, t, "有意" if abs(t) > 4.303 else "n.s."))
    p("")

    # 9) CE_all の分解（copy / edit）
    p("== 9) CE_all は何で出来ているか（edit 率 0.0437） ==")
    E_RATE = 0.0437
    for s in seeds:
        for tag in ["teacher"] + ["dense%d" % w for w in widths]:
            r = res["runs"]["%s:s%d" % (tag, s)]
            share_edit = E_RATE * r["ce_edit"] / r["ce_all"]
            p("  s%d %-9s CE_all %.4f = copy寄与 %.4f + edit寄与 %.4f（edit が %.1f%%）"
              % (s, tag, r["ce_all"], (1 - E_RATE) * r["ce_copy"],
                 E_RATE * r["ce_edit"], 100 * share_edit))
    p("")
    p("  ΔCE の分解（dense − teacher、s0）:")
    for w in widths:
        a = res["runs"]["dense%d:s0" % w]
        b = res["runs"]["teacher:s0"]
        dc = (1 - E_RATE) * (a["ce_copy"] - b["ce_copy"])
        de = E_RATE * (a["ce_edit"] - b["ce_edit"])
        p("    dense%-3d Δ_all %+.4f = copy %+.4f (%.0f%%) + edit %+.4f (%.0f%%)"
          % (w, a["ce_all"] - b["ce_all"], dc, 100 * dc / (a["ce_all"] - b["ce_all"]),
             de, 100 * de / (a["ce_all"] - b["ce_all"])))
    p("")

    # 10) 6 スレッド対照（同一 seed 0）との比較
    p("== 10) スレッド数の効果（同一 seed 0、別プロセス） ==")
    t6p = os.path.join(HERE, "k1_results_t6.json")
    if os.path.exists(t6p):
        r6 = json.load(open(t6p, encoding="utf-8"))
        for tag in ["teacher", "dense161", "dense180"]:
            a = res["runs"]["%s:s0" % tag]["ce_all"]
            b = r6["runs"]["%s:s0" % tag]["ce_all"]
            p("  %-9s 1 thread %.4f / 6 threads %.4f  Δ(6t−1t) %+.4f" % (tag, a, b, b - a))
        for w in (161, 180):
            a = res["runs"]["diff:dense%d:s0" % w]["delta"]
            b = r6["runs"]["diff:dense%d:s0" % w]["delta"]
            p("  ΔCE dense%-3d  1t %+.4f / 6t %+.4f  （符号 %s）"
              % (w, a, b, "同じ" if a * b > 0 else "反転"))
        p("  ※ 1 seed・別プロセスの 1 draw。Q9 のとおり 6 スレッドはプロセス間で再現しない。")
    else:
        p("  (k1_results_t6.json なし)")

    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n[write] %s" % OUT)


if __name__ == "__main__":
    main()
