# -*- coding: utf-8 -*-
"""_ax4_probe.py — AX4 の文境界実現可能性調査（使い捨て・read-only）。

OLMoE tokenizer で境界候補トークンを同定し、AX3 凍結コーパスの
en / ja それぞれで文数・文長分布・最小文長マージの効果を測る。
AX3 保存 npz の再利用可能なキーも一覧する。
"""
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "olmoe-1b-7b")


def main():
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(MODEL)
    print("vocab", len(tok))
    cands = ["。", "．", ".", ".\n", ". ", "! ", "? ", "\n", "\n\n", "!", "?"]
    for s in cands:
        ids = tok(s, add_special_tokens=False).input_ids
        print("  cand %-6r -> %s  decoded=%r" % (s, ids, [tok.decode([i]) for i in ids]))

    z = np.load(os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz"), allow_pickle=True)
    print("\nAX3 corpus keys:", sorted(z.files))
    z3 = np.load(os.path.join(HERE, "ax3_transfer.npz"))
    print("AX3 transfer keys:", sorted(z3.files)[:12], "... n=", len(z3.files))
    for k in ("nll_u7", "nll_base", "nll_lay_win_oracle", "nll_lay_tok_oracle",
              "nll_lay_win_mlp", "c8", "c7", "d_j", "win_mlp", "Y", "W", "lang", "wi"):
        if k in z3.files:
            print("   %-22s %s %s" % (k, z3[k].shape, z3[k].dtype))

    # 境界トークンの ID（単一トークンになるものだけ）
    boundary = set()
    for s in ("。", "．", ".", "!", "?", "\n"):
        ids = tok(s, add_special_tokens=False).input_ids
        if len(ids) == 1:
            boundary.add(int(ids[0]))
    print("\nboundary single-token ids:", sorted(boundary))

    for lang in ("en", "ja"):
        ids = z[lang + "_ids"].astype(np.int64)
        print("\n%s: n=%d" % (lang, ids.size))
        for bid in sorted(boundary):
            print("   id %-6d (%r) count %d" % (bid, tok.decode([bid]), int((ids == bid).sum())))
        # 境界で切った場合の文長分布（境界トークンは文末に含める）
        isb = np.isin(ids, list(boundary))
        ends = np.where(isb)[0]
        print("   boundary positions %d" % ends.size)
        for minlen in (1, 4, 8, 16):
            cuts, start = [], 0
            for e in ends:
                if e + 1 - start >= minlen:
                    cuts.append((start, e + 1))
                    start = e + 1
            if start < ids.size:
                cuts.append((start, ids.size))
            lens = np.array([b - a for a, b in cuts])
            print("   minlen %2d -> n_sent %4d  mean %6.1f  median %5.1f  min %3d  max %4d  p10 %5.1f"
                  % (minlen, len(cuts), lens.mean(), np.median(lens), lens.min(),
                     lens.max(), np.percentile(lens, 10)))


    # --- AX4 本命: 終端句点のみ / 句点＋改行。窓内完結・最小文長 8 ---
    def build_sent(ids, bset, minlen=8, n_win=24, ln=256):
        sent = np.zeros(len(ids), dtype=np.int32)
        sid, lens, n_merged = 0, [], 0
        for w in range(n_win):
            seg = ids[w * ln:(w + 1) * ln]
            ends = np.where(np.isin(seg, list(bset)))[0]
            cuts, start = [], 0
            for e in ends:
                if e + 1 - start >= minlen:
                    cuts.append([start, e + 1])
                    start = e + 1
            if start < ln:
                if cuts:
                    cuts[-1][1] = ln          # 窓末の端数は直前の文へマージ
                    n_merged += 1
                else:
                    cuts.append([0, ln])
            for a, b in cuts:
                sent[w * ln + a:w * ln + b] = sid
                lens.append(b - a)
                sid += 1
        assert np.all(np.diff(np.where(np.diff(sent) != 0)[0]) >= 0)
        return sent, np.array(lens), n_merged

    print("\n=== AX4 文境界候補（窓内完結・minlen=8）===")
    for name, bset in (("period_only", {2, 15, 32, 4340}),
                       ("period_newline", {2, 15, 32, 187, 4340})):
        all_lens, all_sents = [], []
        for lang in ("en", "ja"):
            sent, lens, nm = build_sent(z[lang + "_ids"].astype(np.int64), bset)
            uniq = np.unique(sent)
            assert sent.size == 6144 and uniq.size == len(lens) \
                and np.array_equal(uniq, np.arange(len(lens))), "文 ID の連続性 NG"
            all_lens.append(lens)
            all_sents.append(sent)
            print("  %-16s %s n_sent %4d  mean %6.1f  median %5.1f  min %3d  max %4d  n_merged %d"
                  % (name, lang, len(lens), lens.mean(), np.median(lens),
                     lens.min(), lens.max(), nm))
        L = np.concatenate(all_lens)
        print("  %-16s TOTAL n_sent %4d  mean %6.1f  median %5.1f  p10 %5.1f  p90 %6.1f"
              % (name, L.size, L.mean(), np.median(L), np.percentile(L, 10),
                 np.percentile(L, 90)))
        print("     window=48 (AX3) ratio=%.2f   per-token=%d ratio=%.2f"
              % (L.size / 48, 12240, 12240 / L.size))


if __name__ == "__main__":
    main()
