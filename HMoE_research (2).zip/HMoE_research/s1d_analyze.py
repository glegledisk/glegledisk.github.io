# -*- coding: utf-8 -*-
"""S1d analysis: A/B per book across the 3 social-sciences books.

A = margin(toc) - margin(toc_drop)          gold row removed
B = margin(toc) - margin(distractor_drop)   sibling row removed
A + B = asymmetry (0 = pure relative visibility)

Compares the across-book spread to the across-domain spread from S1b.
"""
import json
import math
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
BOOKS = ["auralskills", "behavioralecon", "compgov"]
LINES = []


def w(s=""):
    LINES.append(str(s))
    print(s, flush=True)


def paired(d, name=""):
    d = np.asarray(d, float)
    d = d[np.isfinite(d)]
    n = d.size
    if n < 3:
        return dict(name=name, n=int(n), mean=float("nan"))
    m = float(d.mean())
    se = float(d.std(ddof=1)) / math.sqrt(n)
    t = m / se
    p = float(stats.t.sf(abs(t), n - 1) * 2)
    a = np.sort(np.abs(d))[::-1]
    k = max(1, int(math.ceil(0.01 * n)))
    return dict(name=name, n=int(n), mean=m, se=se, t=t, p=p, mde=2.8 * se,
                median=float(np.median(d)), top1=float(a[:k].sum() / (np.abs(d).sum() + 1e-30)),
                mn=float(d.min()), mx=float(d.max()))


def show(tag, s):
    if "se" not in s:
        w("%-30s n=%d (too few)" % (tag, s["n"]))
        return
    w("%-30s %+0.4f (se %0.4f, t=%+0.2f, p=%.4f, n=%d, MDE %.3f, med %+0.3f)"
      % (tag, s["mean"], s["se"], s["t"], s["p"], s["n"], s["mde"], s["median"]))


out = {"books": {}}
for bid in BOOKS:
    path = os.path.join(HERE, "s1d_%s.npz" % bid)
    if not os.path.exists(path):
        w("MISSING %s" % path)
        continue
    z = np.load(path, allow_pickle=True)
    meta = json.loads(str(z["meta"][0]))
    qidx = z["row_query_idx"].astype(int)
    cond = np.array([str(x) for x in z["row_condition"]], dtype=object)
    ctype = np.array([str(x) for x in z["row_cand_type"]], dtype=object)
    div = z["row_div_idx"].astype(int)
    logp = z["row_logp_div"].astype(float)
    gq = z["gold_query_idx"].astype(int)
    gc = np.array([str(x) for x in z["gold_condition"]], dtype=object)
    glen = z["gold_len"].astype(int)

    grow = {}
    for i in range(len(gq)):
        grow[(int(gq[i]), gc[i])] = i

    margins = {}  # (query, condition, ctype) -> margin
    for i in range(len(qidx)):
        k = (int(qidx[i]), cond[i], ctype[i])
        g = grow.get((int(qidx[i]), cond[i]))
        if g is None:
            continue
        j = div[i]
        if 0 <= j < int(glen[g]) and np.isfinite(logp[i]):
            margins[k] = float(z["gold_logp"][g, j]) - logp[i]

    qs = sorted(set(q for (q, c, t) in margins))
    A, B, F = [], [], []
    for q in qs:
        ts = margins.get((q, "toc", "sibling"))
        td = margins.get((q, "toc_drop", "sibling"))
        dd = margins.get((q, "distractor_drop", "sibling"))
        tf = margins.get((q, "toc", "far"))
        df = margins.get((q, "distractor_drop", "far"))
        if ts is not None and td is not None and dd is not None:
            A.append(ts - td)
            B.append(ts - dd)
        if tf is not None and df is not None:
            F.append(tf - df)
    A, B, F = np.array(A), np.array(B), np.array(F)

    w("\n== %s (%s) ==" % (bid, meta["book"]))
    w("  n_entries=%d n_fwd=%d mean_fwd=%.2fs head=%.5f"
      % (meta["n_entries"], meta["n_fwd"], meta["mean_fwd_s"], meta["head_err"]))
    show("  A = toc - toc_drop", paired(A))
    show("  B = toc - distractor_drop", paired(B))
    show("  A + B", paired(A + B))
    show("  far placebo (toc - dd)", paired(F))
    w("  A positive %d / negative %d ; B positive %d / negative %d"
      % (int((A > 0).sum()), int((A < 0).sum()), int((B > 0).sum()), int((B < 0).sum())))

    out["books"][bid] = {
        "book": meta["book"], "n": int(len(A)),
        "A": paired(A), "B": paired(B), "A_plus_B": paired(A + B),
        "far_placebo": paired(F),
        "mean_A": float(A.mean()), "mean_B": float(B.mean()),
    }

# ---- across-book spread vs across-domain spread ----
w("\n== across-book spread (social_sciences, 3 books) ==")
As = [out["books"][b]["mean_A"] for b in BOOKS if b in out["books"]]
Bs = [out["books"][b]["mean_B"] for b in BOOKS if b in out["books"]]
w("  A: " + " ".join("%+.3f" % x for x in As) + "   range %.3f" % (max(As) - min(As)))
w("  B: " + " ".join("%+.3f" % x for x in Bs) + "   range %.3f" % (max(Bs) - min(Bs)))
if len(As) >= 3:
    w("  corr(A, B) across books = %+.3f" % float(np.corrcoef(As, Bs)[0, 1]))

with open(os.path.join(HERE, "s1b_analysis.json"), encoding="utf-8") as f:
    s1b = json.load(f)
w("\n== reference: across-domain spread (S1b, 5 domains) ==")
domA = [s1b["by_domain"][d]["A"]["mean"] for d in s1b["by_domain"]]
domB = [s1b["by_domain"][d]["B"]["mean"] for d in s1b["by_domain"]]
w("  A: " + " ".join("%+.3f" % x for x in domA) + "   range %.3f" % (max(domA) - min(domA)))
w("  B: " + " ".join("%+.3f" % x for x in domB) + "   range %.3f" % (max(domB) - min(domB)))
w("  corr(A, B) across domains = %+.3f" % float(np.corrcoef(domA, domB)[0, 1]))

w("\n== ratio of spreads ==")
w("  A: across-book range / across-domain range = %.2f" % ((max(As) - min(As)) / (max(domA) - min(domA))))
w("  B: across-book range / across-domain range = %.2f" % ((max(Bs) - min(Bs)) / (max(domB) - min(domB))))

with open(os.path.join(HERE, "s1d_analysis.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1, default=float)
with open(os.path.join(HERE, "s1d_analysis_out_utf8.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(LINES))
print("wrote s1d_analysis.json")
