"""P4 の図: (a) 予測可能性の解離、(b) 厳密測定した決定規則、(c) 難易度とコストは別物。"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "Noto Sans JP", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))
res = json.load(open(os.path.join(HERE, "p4_probe_results.json"), encoding="utf-8"))
ad = json.load(open(os.path.join(HERE, "p4_adaptive_results.json"), encoding="utf-8"))
pr = np.load(os.path.join(HERE, "p4_preds2.npz"))

BASE_CE = 2.60047  # 均一 top-8（P3 とビット一致）

fig = plt.figure(figsize=(14, 4.4))

# (a) AUC: cost vs difficulty
ax = fig.add_subplot(1, 3, 1)
sets = ["hist", "gate0", "gstat0", "gate0+hist", "h0+hist", "gate8+hist", "gate15+hist", "ALL(l0)"]
auc_c = [res["targets"]["d_j"][s]["auc"] for s in sets]
auc_d = [res["targets"]["nll_j"][s]["auc"] for s in sets]
x = np.arange(len(sets))
w = 0.38
ax.bar(x - w / 2, auc_d, w, label="難易度 $nll_j$", color="#2980b9")
ax.bar(x + w / 2, auc_c, w, label="削減コスト $d_j$", color="#c0392b")
ax.axhline(0.5, color="gray", ls="--", lw=1)
ax.set_xticks(x)
ax.set_xticklabels(sets, rotation=35, ha="right", fontsize=8)
ax.set_ylabel("AUC（上位 25% を当てる）")
ax.set_title("(a) 難易度は読めるが、コストは読めない", fontsize=11)
ax.legend(fontsize=8, loc="upper left")
ax.set_ylim(0.45, 0.86)
ax.grid(alpha=0.3, axis="y")

# (b) 厳密測定した決定規則
ax = fig.add_subplot(1, 3, 2)
order = ["uniform6", "uniform7", "probe50", "random50", "oracle50"]
labels = ["均一 top-6\n(mean_k 6)", "均一 top-7\n(mean_k 7)", "probe 50%\n(mean_k 7)",
          "ランダム 50%\n(mean_k 7)", "oracle 50%\n(mean_k 7)"]
colors = ["#95a5a6", "#2c3e50", "#c0392b", "#7f8c8d", "#8e44ad"]
vals = [ad["results"][k]["ce"] - BASE_CE for k in order]
errs = [0 if k == "uniform7" else 1.96 * ad["results"][k]["se"] for k in order]
bars = ax.bar(range(len(order)), vals, 0.66, color=colors, yerr=errs, capsize=4)
for i, (v, k) in enumerate(zip(vals, order)):
    ax.annotate("%+.4f" % v, (i, v), textcoords="offset points", xytext=(0, 6),
                ha="center", fontsize=8)
ax.axhline(0, color="black", lw=1)
ax.axhline(ad["results"]["uniform7"]["ce"] - BASE_CE, color="#2c3e50", ls="--", lw=1.2)
ax.set_xticks(range(len(order)))
ax.set_xticklabels(labels, fontsize=7.5)
ax.set_ylabel(r"$\Delta$CE vs 均一 top-8 (nats/token)")
ax.set_title("(b) 実測: probe は均一配分に届かない", fontsize=11)
ax.grid(alpha=0.3, axis="y")

# (c) 難易度 vs コスト
ax = fig.add_subplot(1, 3, 3)
nll = pr["nll_j"]
d_j = pr["d_j"]
ax.hexbin(np.log(nll + 1e-3), d_j, gridsize=45, cmap="magma", bins="log", mincnt=1)
ax.axhline(0, color="w", lw=0.8)
ax.set_xlabel(r"$\log$ 難易度 $nll_j$")
ax.set_ylabel(r"削減コスト $d_j$")
ax.set_title("(c) 難易度とコストは別物（Spearman 0.094）", fontsize=11)
ax.set_ylim(-2.0, 2.5)

fig.tight_layout()
out = os.path.join(HERE, "p4_probe_figure.png")
fig.savefig(out, dpi=140)
print("saved", out)
for k in order:
    print("  %-9s CE %.5f  dCE(base) %+.5f  top1 %.4f  mean_k %.3f"
          % (k, ad["results"][k]["ce"], ad["results"][k]["ce"] - BASE_CE,
             ad["results"][k]["top1"], ad["results"][k]["mean_k"]))
