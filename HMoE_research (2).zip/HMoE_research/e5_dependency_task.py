# -*- coding: utf-8 -*-
"""e5_dependency_task.py — E5: 依存構造を持つ編集課題（Lag-3 Dependent Transform）

## なぜ新しい課題が必要か
E4/E4b/E4c/E4d/E4e の共通の欠陥は 2 つあった:
  (1) FFN がほぼ冗長（全恒等でも CE +0.008 nats）→ 配分の善し悪しが品質に出ない
  (2) 編集位置が内容と独立に抽選 → 内容ベースの信号は原理的に当てられない
     （任意の因果信号の AUC 上限 = (j,r) の 0.6209）

E5 はこの 2 つを設計で潰す。

## 課題定義
系列: SRC[0..L-1] + SEP + OUT[0..L-1]

生成規則（src のみで決定的）:
  1. src[i] ~ Uniform{0..A-1}
  2. 「アンカー」= src[i] ∈ anchor_vals の位置
  3. 左から順に:
       if i >= lag and src[i-lag] ∈ anchor_vals:
           out[i] = out[i-lag]                      # 依存位置（前の出力のコピー）
           role[i] = DEP
       elif src[i] ∈ anchor_vals:
           out[i] = (src[i] + src[i-1]) mod A       # アンカー（非線形な 2 トークン関数）
           role[i] = ANCHOR
       else:
           out[i] = src[i]                          # コピー
           role[i] = COPY

## 設計の根拠
- **アンカーの出力を非線形にする**のが要点。単なる置換 σ(src[i]) は one-hot 空間で線形
  （置換行列）なので、恒等パス＋出力ヘッドで実現できてしまい FFN が不要になる。
  (a + b) mod A は 2 トークンの結合と「繰り上がり」を含むため、ReLU なしでは実現できない。
- **依存位置を入れる**ことで、ルーティング判断が「src[i] がアンカーか」だけでは決まらなくなる。
  src[i] がアンカー条件を満たしていても、i-lag がアンカーなら依存位置（コピー）になる。
  この優先順位は入力から学習可能で、かつ (j, r) の計数統計では表せない。
- **信号は内容ベースで完全に予測可能**（src の関数）。E4e の「原理的上限 0.62」を突破できる。

## 役割ごとの要求計算量
  ANCHOR   : 2 トークンの非線形結合 → FFN 必須
  DEP      : 前の出力のコピー       → Attention + 恒等で足りる可能性
  COPY     : 自分の src のコピー    → Attention + 恒等で足りる可能性

したがって「アンカーだけ FFN、他は恒等」という配分が最適になりうる。
これが HMoE の品質側テーゼを検証できる最小の構造。
"""
import os, math, json, time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

COPY, ANCHOR, DEP = 0, 1, 2
ROLE_NAME = {COPY: "copy", ANCHOR: "anchor", DEP: "dep"}


def make_dep_batch(rng, n, L=16, A=8, lag=3, anchor_vals=(0,), mode="no_plan"):
    """E5 の系列を生成。(seq, role, pos_out) を返す。role は (n, L) の int8。"""
    av = np.asarray(anchor_vals)
    src = rng.integers(0, A, size=(n, L))
    out = src.copy()
    role = np.zeros((n, L), dtype=np.int8)
    is_anchor_src = np.isin(src, av)                     # (n, L) bool
    for i in range(L):
        prev = src[:, i - 1] if i >= 1 else src[:, i]
        hard = (src[:, i] + prev) % A                    # 非線形な 2 トークン関数
        if i >= lag:
            dep = is_anchor_src[:, i - lag]
            out[:, i] = np.where(dep, out[:, i - lag],
                                 np.where(is_anchor_src[:, i], hard, src[:, i]))
            role[:, i] = np.where(dep, DEP, np.where(is_anchor_src[:, i], ANCHOR, COPY))
        else:
            out[:, i] = np.where(is_anchor_src[:, i], hard, src[:, i])
            role[:, i] = np.where(is_anchor_src[:, i], ANCHOR, COPY)

    SEP = A
    if mode == "oracle_plan":
        # PLAN 列: ANCHOR を EDIT、それ以外を COPY（専用トークン。記号と衝突させない）
        PLAN_COPY, PLAN_EDIT = A + 1, A + 2
        plan = np.where(role == ANCHOR, PLAN_EDIT, PLAN_COPY).astype(np.int64)
        seq = np.empty((n, 2 * L + L + 2), dtype=np.int64)
        seq[:, 0:L] = src
        seq[:, L] = SEP
        seq[:, L + 1:2 * L + 1] = plan
        seq[:, 2 * L + 1] = SEP
        seq[:, 2 * L + 2:] = out
        pos_out = 2 * L + 2
    else:
        seq = np.empty((n, 2 * L + 1), dtype=np.int64)
        seq[:, 0:L] = src
        seq[:, L] = SEP
        seq[:, L + 1:] = out
        pos_out = L + 1
    return torch.from_numpy(seq), role, pos_out


# ---------------- モデル ----------------
class MoELayer(nn.Module):
    def __init__(self, V, L, route_mode="free", extra_dim=0, d=64, n_head=4, e_num=8, topk=2, w_ff=64, id_idx=7):
        super().__init__()
        self.d, self.n_head, self.d_head = d, n_head, d // n_head
        self.e_num, self.topk, self.id_idx, self.route_mode = e_num, topk, id_idx, route_mode
        self.q = nn.Linear(d, d, bias=False); self.k = nn.Linear(d, d, bias=False)
        self.v = nn.Linear(d, d, bias=False); self.o = nn.Linear(d, d, bias=False)
        self.router = nn.Linear(d + extra_dim, e_num, bias=False)
        self.up = nn.Parameter(torch.randn(e_num, d, w_ff) * 0.05)
        self.down = nn.Parameter(torch.randn(e_num, w_ff, d) * 0.05)

    def forward(self, x, mask, extra=None, force_id=None, id_bias=0.0, id_bias_amt=None,
                return_logits=False):
        B, T, _ = x.shape
        q = self.q(x).view(B, T, self.n_head, self.d_head).transpose(1, 2)
        k = self.k(x).view(B, T, self.n_head, self.d_head).transpose(1, 2)
        v = self.v(x).view(B, T, self.n_head, self.d_head).transpose(1, 2)
        s = (q @ k.transpose(-2, -1)) / math.sqrt(self.d_head)
        s = s.masked_fill(mask == 0, -1e9)
        a = F.softmax(s, dim=-1)
        x = x + self.o((a @ v).transpose(1, 2).reshape(B, T, self.d))
        r_in = x if extra is None else torch.cat([x, extra], dim=-1)
        if self.route_mode == "identity":
            ti = torch.full((B, T, self.topk), self.id_idx, dtype=torch.long, device=x.device)
            tg = torch.full((B, T, self.topk), 1.0 / self.topk, device=x.device)
            lg = None
        else:
            lg = self.router(r_in)
            if id_bias != 0.0 or id_bias_amt is not None:
                # top-k dead zone 検証用: identity logit にバイアス（定数 and/or 位置別 (B,T)）
                lg = lg.clone()
                lg[..., self.id_idx] = lg[..., self.id_idx] + id_bias
                if id_bias_amt is not None:
                    lg[..., self.id_idx] = lg[..., self.id_idx] + id_bias_amt
            if self.route_mode == "ffn_only":
                lg = lg.clone(); lg[..., self.id_idx] = -1e9
            tl, ti = torch.topk(lg, self.topk, dim=-1)
            tg = F.softmax(tl, dim=-1)
        if force_id is not None:
            # H-B ウォームアップ用: force_id が True の位置は強制的に恒等パス
            # （ti の全 slot を恒等 index、tg を均等に）。省略時は既存動作と同一。
            fi = force_id.unsqueeze(-1)
            ti = torch.where(fi, torch.full_like(ti, self.id_idx), ti)
            tg = torch.where(fi, torch.full_like(tg, 1.0 / self.topk), tg)
        out = torch.zeros_like(x)
        for ki in range(self.topk):
            ei, g = ti[:, :, ki], tg[:, :, ki].unsqueeze(-1)
            out = out + torch.where((ei == self.id_idx).unsqueeze(-1), g * x, torch.zeros_like(x))
            for e in range(self.e_num):
                if e == self.id_idx:
                    continue
                m = (ei == e).unsqueeze(-1)
                if m.any():
                    f = F.relu(x @ self.up[e]) @ self.down[e]
                    out = out + torch.where(m, g * f, torch.zeros_like(x))
        if return_logits:
            return x + out, ti, tg, lg
        return x + out, ti, tg


class Net(nn.Module):
    def __init__(self, V, L, arm="free", route_mode="free", d=64):
        super().__init__()
        self.arm = arm
        self.sidecar = (arm == "sidecar")
        extra = 2 if self.sidecar else 0
        self.tok = nn.Embedding(V, d)
        self.pos = nn.Embedding(3 * L + 4, d)   # no_plan: 2L+1 / oracle: 3L+2
        self.l0 = MoELayer(V, L, route_mode, 0, d=d)
        self.l1 = MoELayer(V, L, route_mode, extra, d=d)
        self.head = nn.Linear(d, V)

    def forward(self, ids, pos_out, sidecar=None, force_id=None, id_bias=0.0, id_bias_amt=None,
                return_logits=False):
        B, T = ids.shape
        x = self.tok(ids) + self.pos(torch.arange(T, device=ids.device).unsqueeze(0))
        mask = torch.tril(torch.ones(T, T, device=ids.device)).unsqueeze(0).unsqueeze(0)
        o0 = self.l0(x, mask, force_id=force_id, id_bias=id_bias, id_bias_amt=id_bias_amt,
                     return_logits=return_logits)
        x, ti0, tg0 = o0[0], o0[1], o0[2]
        extra = None
        if self.sidecar and sidecar is not None:
            extra = sidecar
        o1 = self.l1(x, mask, extra, force_id=force_id, id_bias=id_bias, id_bias_amt=id_bias_amt,
                     return_logits=return_logits)
        x, ti1, tg1 = o1[0], o1[1], o1[2]
        if return_logits:
            return self.head(x), (ti0, ti1), (tg0, tg1), o1[3]
        return self.head(x), (ti0, ti1), (tg0, tg1)


def sidecar_feats(role, L, T, pos_out):
    """入力から計算できる依存構造の明示特徴（アンカー条件・依存条件）2 次元。"""
    anc = (role == ANCHOR).astype(np.float32)
    dep = (role == DEP).astype(np.float32)
    f = torch.from_numpy(np.stack([anc, dep], axis=-1))      # (B, L, 2)
    pad = torch.zeros(f.shape[0], T - L, 2)
    return torch.cat([pad, f], dim=1)


# ---------------- 学習・評価 ----------------
def run(arm, seed, L=16, A=8, lag=3, anchor_vals=(0,), n_train=3500, n_val=2048,
        epochs=12, bs=64, lam_cost=0.15, d=64, make_batch_fn=None):
    make_batch_fn = make_batch_fn or make_dep_batch
    rng = np.random.default_rng(seed); torch.manual_seed(seed)
    V = A + 3 if arm == "oracle" else A + 1   # oracle は PLAN 専用トークン 2 個を追加
    route = {"free": "free", "sidecar": "free", "frozen_ffn": "ffn_only",
             "frozen_identity": "identity", "oracle": "free"}[arm]
    mode = "oracle_plan" if arm == "oracle" else "no_plan"
    net = Net(V, L, arm=arm, route_mode=route, d=d)
    opt = torch.optim.AdamW(net.parameters(), lr=3e-3, weight_decay=1e-4)
    pos_out = (2 * L + 2) if mode == "oracle_plan" else (L + 1)
    os_ = pos_out - 1

    for ep in range(epochs):
        net.train()
        seq, role, _ = make_batch_fn(rng, n_train, L, A, lag, anchor_vals, mode)
        sc = sidecar_feats(role, L, seq.shape[1] - 1, pos_out) if arm == "sidecar" else None
        perm = torch.randperm(n_train)
        for i in range(0, n_train, bs):
            idx = perm[i:i + bs]
            b = seq[idx]; inp, tgt = b[:, :-1], b[:, 1:]
            opt.zero_grad()
            logits, (ti0, ti1), (tg0, tg1) = net(inp, pos_out, None if sc is None else sc[idx])
            ce = F.cross_entropy(logits[:, os_:].reshape(-1, V), tgt[:, os_:].reshape(-1))
            g0 = (tg0[:, os_:] * (ti0[:, os_:] == 7).float()).sum(-1).mean()
            g1 = (tg1[:, os_:] * (ti1[:, os_:] == 7).float()).sum(-1).mean()
            loss = ce + lam_cost * (2.0 - (g0 + g1))
            loss.backward(); opt.step()

    net.eval()
    vs, vr, _ = make_batch_fn(rng, n_val, L, A, lag, anchor_vals, mode)
    sc = sidecar_feats(vr, L, vs.shape[1] - 1, pos_out) if arm == "sidecar" else None
    with torch.no_grad():
        logits, (ti0, ti1), (tg0, tg1) = net(vs[:, :-1], pos_out, sc)
        tgt = vs[:, 1:]
        lo, lt = logits[:, os_:], tgt[:, os_:]
        ce_tok = F.cross_entropy(lo.reshape(-1, V), lt.reshape(-1), reduction="none").reshape(n_val, L)
        pred = lo.argmax(-1)
        acc = (pred == lt)
        gate_id = (tg1[:, os_:] * (ti1[:, os_:] == 7).float()).sum(-1).mean().item()
        res = {"arm": arm, "seed": seed, "L": L, "A": A, "lag": lag,
               "n_anchor": float((vr == ANCHOR).mean()), "n_dep": float((vr == DEP).mean()),
               "ce_all": float(ce_tok.mean()), "acc_all": float(acc.float().mean()),
               "ffn_cost": float(1.0 - gate_id)}
        for r, nm in ROLE_NAME.items():
            m = (vr == r)
            if m.sum() > 0:
                res[f"ce_{nm}"] = float(ce_tok[m].mean())
                res[f"acc_{nm}"] = float(acc[m].float().mean())
        # アンカーで恒等を選んだ割合（ルーティングの当否）
        is_id = (ti1[:, os_:, 0] == 7).numpy()
        for r, nm in ROLE_NAME.items():
            m = (vr == r)
            if m.sum() > 0:
                res[f"id_rate_{nm}"] = float(is_id[m].mean())
    return res


CONFIGS = [
    # (A, anchor_vals) でアンカー率と変換の難しさを変える
    dict(name="A8_r12", L=16, A=8, anchor_vals=(0,)),          # アンカー ~11%, mod 8
    dict(name="A8_r25", L=16, A=8, anchor_vals=(0, 1)),        # アンカー ~22%, mod 8
    dict(name="A16_r25", L=16, A=16, anchor_vals=(0, 1, 2, 3)),  # アンカー ~22%, mod 16
]


def main():
    seeds = [0, 1]
    rows = []
    t0 = time.time()
    for cfg in CONFIGS:
        for arm in ("frozen_ffn", "frozen_identity"):
            for s in seeds:
                r = run(arm, s, L=cfg["L"], A=cfg["A"], anchor_vals=cfg["anchor_vals"])
                r["config"] = cfg["name"]
                rows.append(r)
                print(f"  {cfg['name']:8s} {arm:16s} s{s} | acc {r['acc_all']:.4f} "
                      f"(copy {r.get('acc_copy',float('nan')):.3f} / anchor {r.get('acc_anchor',float('nan')):.3f} "
                      f"/ dep {r.get('acc_dep',float('nan')):.3f}) | CE {r['ce_all']:.3f} "
                      f"| FFN {r['ffn_cost']:.3f} | anchor率 {r['n_anchor']:.3f}", flush=True)
        print(f"    ({time.time()-t0:.0f}s)", flush=True)

    import pandas as pd
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           "e5_dependency_headroom.csv"), index=False)
    print("\n=== ヘッドルーム確認（2 seeds 平均） ===")
    print(f"{'config':9s} {'arm':16s} {'acc':>7s} {'acc copy':>9s} {'acc anchor':>11s} "
          f"{'acc dep':>8s} {'CE':>7s} {'FFN':>6s}")
    for cfg in CONFIGS:
        for arm in ("frozen_ffn", "frozen_identity"):
            d = df[(df.config == cfg["name"]) & (df.arm == arm)]
            print(f"{cfg['name']:9s} {arm:16s} {d['acc_all'].mean():7.4f} "
                  f"{d['acc_copy'].mean():9.4f} {d['acc_anchor'].mean():11.4f} "
                  f"{d['acc_dep'].mean():8.4f} {d['ce_all'].mean():7.3f} {d['ffn_cost'].mean():6.3f}")
        d1 = df[(df.config == cfg["name"]) & (df.arm == "frozen_ffn")]
        d0 = df[(df.config == cfg["name"]) & (df.arm == "frozen_identity")]
        print(f"          -> FFN の寄与 ΔCE = {d0['ce_all'].mean() - d1['ce_all'].mean():+.3f} nats")
    print("\nsaved e5_dependency_headroom.csv")


if __name__ == "__main__":
    main()
