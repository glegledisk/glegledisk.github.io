# -*- coding: utf-8 -*-
"""_probe_oldfwd.py — experts._old_forward を差し替えられるか（使い捨て）"""
import os
import types

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "olmoe-1b-7b")

from transformers import AutoModelForCausalLM

m = AutoModelForCausalLM.from_pretrained(
    MODEL, torch_dtype=torch.bfloat16, device_map="auto",
    max_memory={0: "7.0GiB", "cpu": "8.5GiB"}).eval()

e = m.model.layers[10].mlp.experts
print("has _old_forward:", hasattr(e, "_old_forward"))
print("forward is wrapper:", e.forward.__name__ if hasattr(e.forward, "__name__") else type(e.forward))
if hasattr(e, "_old_forward"):
    print("old_forward name:", getattr(e._old_forward, "__name__", type(e._old_forward)))

z = np.load(os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"))
ids = torch.from_numpy(z["en_ids"][:256].astype("int64")).unsqueeze(0)

with torch.no_grad():
    ref = m(input_ids=ids, use_cache=False).logits.clone()
print("ref CE finite:", bool(torch.isfinite(ref).all()))

# _old_forward を差し替えて、重みが実体か確認
if hasattr(e, "_old_forward"):
    orig = e._old_forward

    def patched(self, hidden_states, top_k_index, top_k_weights):
        if not hasattr(self, "_seen"):
            self._seen = True
            print("  inside: gu meta=%s dev=%s hidden dev=%s"
                  % (self.gate_up_proj.is_meta, self.gate_up_proj.device, hidden_states.device))
        return orig(hidden_states, top_k_index, top_k_weights)

    e._old_forward = types.MethodType(patched, e)
    with torch.no_grad():
        out = m(input_ids=ids, use_cache=False).logits
    print("patched CE finite:", bool(torch.isfinite(out).all()),
          "maxdiff vs ref:", float((out - ref).abs().max()))
