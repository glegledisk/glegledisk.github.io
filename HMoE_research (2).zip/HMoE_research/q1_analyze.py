#!/usr/bin/env python3
"""Q1 の解析: 種別（struct/payload）× expert サイズ、k 削減、強制部分集合。

入力: simulation_hmoe_mmlu/data/q1/{arm}_{task}_s{seed}.json
出力: data/q1/q1_analysis.json / 標準出力に表
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
QDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q1")

CONFIGS = [("H+LB", "compute"), ("H+LB", "copy"), ("U+LB", "compute")]
SEEDS = [0, 1, 2]


def load(arm, task, seed):
    p = os.path.join(QDIR, f"{arm}_{task}_s{seed}.json")
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def stat(xs):
    a = np.asarray(xs, dtype=float)
    n = len(a)
    m = float(a.mean())
    sd = float(a.std(ddof=1)) if n > 1 else float("nan")
    se = sd / np.sqrt(n) if n > 1 else float("nan")
    t = m / se if se and se > 0 else float("nan")
    return m, sd, se, t


def main():
    out = {}
    for arm, task in CONFIGS:
        rows = [load(arm, task, s) for s in SEEDS]
        if any(r is None for r in rows):
            print(f"[skip] {arm} {task}: 欠けている seed がある")
            continue
        base = [r["eval"]["base"] for r in rows]
        d = [b["small_payload"] - b["small_struct"] for b in base]
        dw = [b["width_payload"] - b["width_struct"] for b in base]
        m, sd, se, t = stat(d)
        rec = {
            "arm": arm, "task": task, "n_seed": len(rows),
            "acc_struct": [b["acc_struct"] for b in base],
            "acc_payload": [b["acc_payload"] for b in base],
            "ce_all": [b["ce_all"] for b in base],
            "small_struct": [b["small_struct"] for b in base],
            "small_payload": [b["small_payload"] for b in base],
            "width_struct": [b["width_struct"] for b in base],
            "width_payload": [b["width_payload"] for b in base],
            "d_small": d, "d_width": dw,
            "d_small_mean": m, "d_small_sd": sd, "d_small_se": se, "d_small_t": t,
            "d_width_mean": float(np.mean(dw)),
            "sign_positive": int(sum(x > 0 for x in d)),
            "small_struct_l": [b["small_struct_l"] for b in base],
            "small_payload_l": [b["small_payload_l"] for b in base],
            "instr_valid": {c: [r["eval"][c]["instr_valid"] for r in rows]
                            for c in ("base", "k1", "f1", "b1", "force_small")},
            "payload_acc_cond": {c: [r["eval"][c]["acc_payload"] for r in rows]
                                 for c in ("base", "k1", "f1", "b1", "force_small")},
            "seq_valid": {c: [r["eval"][c]["seq_valid"] for r in rows]
                          for c in ("base", "k1", "f1", "b1", "force_small")},
            "sec": [r["sec"] for r in rows],
        }
        out[f"{arm}_{task}"] = rec

    # compute と copy の対比（同一 seed で対応を取る）
    if "H+LB_compute" in out and "H+LB_copy" in out:
        dc = np.array(out["H+LB_compute"]["d_small"])
        dp = np.array(out["H+LB_copy"]["d_small"])
        diff = dc - dp
        m, sd, se, t = stat(diff)
        out["paired_compute_minus_copy"] = {
            "diff": diff.tolist(), "mean": m, "sd": sd, "se": se, "t": t,
            "n_negative": int((diff < 0).sum()), "n": int(len(diff)),
        }

    with open(os.path.join(QDIR, "q1_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    for k, r in out.items():
        if "n_seed" not in r:
            continue
        print(f"\n=== {k}  (n_seed={r['n_seed']}) ===")
        print(f"  acc  struct {np.mean(r['acc_struct']):.4f}  payload {np.mean(r['acc_payload']):.4f}"
              f"  CE {np.mean(r['ce_all']):.4f}")
        print(f"  small share  struct {np.mean(r['small_struct']):.3f}  "
              f"payload {np.mean(r['small_payload']):.3f}  "
              f"Δ {r['d_small_mean']:+.3f} (se {r['d_small_se']:.3f}, t {r['d_small_t']:+.2f}, "
              f"正 {r['sign_positive']}/{r['n_seed']})")
        print(f"  width        struct {np.mean(r['width_struct']):.1f}  "
              f"payload {np.mean(r['width_payload']):.1f}  Δ {r['d_width_mean']:+.1f}")
        for c in ("base", "k1", "f1", "b1", "force_small"):
            iv = r["instr_valid"][c]
            pa = r["payload_acc_cond"][c]
            print(f"  {c:12s} instr_valid {np.mean(iv):.3f}  payload_acc {np.mean(pa):.3f}"
                  f"  ({', '.join(f'{x:.2f}' for x in iv)})")
        print("  layer small share struct : " +
              " ".join(f"{np.mean([l[i] for l in r['small_struct_l']]):.2f}"
                       for i in range(len(r['small_struct_l'][0]))))
        print("  layer small share payload: " +
              " ".join(f"{np.mean([l[i] for l in r['small_payload_l']]):.2f}"
                       for i in range(len(r['small_payload_l'][0]))))

    pc = out.get("paired_compute_minus_copy")
    if pc:
        print(f"\n=== compute − copy（同一 seed 対応, n={pc['n']}） ===")
        print(f"  diff {', '.join(f'{x:+.3f}' for x in pc['diff'])}")
        print(f"  mean {pc['mean']:+.3f}  se {pc['se']:.3f}  t {pc['t']:+.2f}  "
              f"負 {pc['n_negative']}/{pc['n']}")


if __name__ == "__main__":
    main()
    sys.exit(0)
