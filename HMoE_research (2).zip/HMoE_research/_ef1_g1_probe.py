# -*- coding: utf-8 -*-
"""EF1 G1 走行前調査: 再トークン化の実測（GPU / 28.63 GB ckpt は使わない）。

AX3 コーパスは OLMoE の ID 列なので、OLMoE tokenizer で文字列へ戻し、
Qwen1.5-MoE-A2.7B の tokenizer.json だけで再エンコードして、
トークン数・語彙 ID 範囲・境界ヒューリスティックの変化を測る。
結果は _ef1_g1_probe.json に UTF-8 で保存する。
"""
import json
import os
import urllib.request

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
CORPUS = os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz")
OLMOE_TOK = os.path.join(HERE, "models", "olmoe-1b-7b", "tokenizer.json")
QWEN_URL = "https://huggingface.co/Qwen/Qwen1.5-MoE-A2.7B/resolve/main/tokenizer.json"
QWEN_LOCAL = os.path.join(HERE, "_ef1_qwen_tokenizer.json")

out = {
    "purpose": "EF1 G1: 載せ直し可能性の走行前調査",
    "gpu_used": False,
    "ckpt_28gb_used": False,
}

z = np.load(CORPUS)
en = z["en_ids"].astype(np.int64)
ja = z["ja_ids"].astype(np.int64)
meta = str(z["meta"][0])
out["corpus"] = {
    "keys": list(z.files),
    "en_ids": {"shape": list(en.shape), "min": int(en.min()), "max": int(en.max())},
    "ja_ids": {"shape": list(ja.shape), "min": int(ja.min()), "max": int(ja.max())},
    "meta_head": meta[:500],
}

try:
    from tokenizers import Tokenizer
    out["tokenizers_lib"] = "available"
except Exception as e:
    out["tokenizers_lib"] = "missing: %r" % (e,)
    Tokenizer = None

if Tokenizer is not None:
    ot = Tokenizer.from_file(OLMOE_TOK)
    text_en = ot.decode(en.tolist(), skip_special_tokens=False)
    text_ja = ot.decode(ja.tolist(), skip_special_tokens=False)
    out["decode_by_olmoe"] = {
        "en_chars": len(text_en), "ja_chars": len(text_ja),
        "en_head": text_en[:120], "ja_head": text_ja[:120],
    }

    # Qwen の tokenizer.json のみ取得（safetensors は取得しない）
    if not os.path.exists(QWEN_LOCAL):
        try:
            req = urllib.request.Request(QWEN_URL, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=90) as r:
                data = r.read()
            with open(QWEN_LOCAL, "wb") as f:
                f.write(data)
            out["download"] = {"ok": True, "bytes": len(data)}
        except Exception as e:
            out["download"] = {"ok": False, "error": repr(e)}
    else:
        out["download"] = {"ok": True, "bytes": os.path.getsize(QWEN_LOCAL), "cached": True}

    if out["download"]["ok"]:
        qt = Tokenizer.from_file(QWEN_LOCAL)
        q_en = np.asarray(qt.encode(text_en, add_special_tokens=False).ids, dtype=np.int64)
        q_ja = np.asarray(qt.encode(text_ja, add_special_tokens=False).ids, dtype=np.int64)
        n_total = int(q_en.size + q_ja.size)
        out["retokenize"] = {
            "olmoe_total_ids": int(en.size + ja.size),
            "qwen_total_ids": n_total,
            "ratio": n_total / (en.size + ja.size),
            "en": {"n": int(q_en.size), "min": int(q_en.min()), "max": int(q_en.max())},
            "ja": {"n": int(q_ja.size), "min": int(q_ja.min()), "max": int(q_ja.max())},
            "48x256_windows_of_256": n_total // 256,
            "note": "同じ文字列でも ID 列も長さも変わる。48 窓 x 256 は切り直せば作れるが別テキストになる。",
        }

        # 境界ヒューリスティック（近似）: ax4_sentence_bound.py の bset は
        # 境界トークン ID の集合で、tokenizer ごとに作り直す必要がある。
        probes = [".", " .", ".\n", "。", "!", "?", "\n", ". "]

        def bid(tok):
            s = set()
            for p in probes:
                s.update(tok.encode(p, add_special_tokens=False).ids)
            return s

        bo, bq = bid(ot), bid(qt)
        out["boundary_probe"] = {
            "method": "近似。境界記号の token ID 集合を各 tokenizer で作り、列中の出現数を数える",
            "olmoe_boundary_ids": sorted(bo),
            "qwen_boundary_ids": sorted(bq),
            "olmoe_hits": int(np.isin(en, list(bo)).sum() + np.isin(ja, list(bo)).sum()),
            "qwen_hits": int(np.isin(q_en, list(bq)).sum() + np.isin(q_ja, list(bq)).sum()),
            "note": "bset は ax4_sentence_bound.py の build_sent_ids(ids, bset, ...) に渡される外部定義。ID が変わるため作り直しが必須。",
        }

with open(os.path.join(HERE, "_ef1_g1_probe.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print(json.dumps(out, ensure_ascii=False, indent=2))
