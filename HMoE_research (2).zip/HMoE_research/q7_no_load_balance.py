#!/usr/bin/env python3
"""Q7: 負荷分散損失（p_pen）を全面的に切る実験（崩壊リスクの追跡）。

背景:
Q5 で「p_pen を切る（auxw=0）と payload 幅が +50 上がる」ことを見出したが、
Q5 は compute 単一タスク・6 epoch・固定の 6 seed での観測だった。
負荷分散損失を切ることの真のリスクは「ルータ崩壊（collapse）」である。
特に:
1. 複数タスク（copy / compute / hard / harder）に渡って切ったとき、崩壊は起きるのか？
2. 崩壊が起きる場合、どう崩壊するのか？（全トークンが 1 つの巨大 expert に集中？小 expert が完全飢餓？）
3. 均一 MoE（U: switch auxを切る）でも同じ崩壊が起きるのか、それとも HMoE（幅不均一）固有の崩壊様式があるのか？
4. 長期学習（エポック伸長）で崩壊が不可逆的に進行するのか？

設計:
- アーム: H+LB（可変幅 32..224） vs U+LB（均一幅 128x8）
- 損失設定:
    aw0    : auxw = 0.0（負荷分散損失なし）
    aw_base: auxw = 0.05（標準対照）
- タスク:
    compute : 標準タスク（A/S/D 混在、Q1/Q5 共通）
    hard    : ×3 連鎖（難度高、Q2）
- シード: 0..5（6 本）
- 測定項目:
    - 各 expert の使用率ベクトル（全層 L0..L3）
    - 正規化使用率エントロピー H（0=1点集中、1=一様）
    - 最大 expert シェア（maxshare: 1.0 なら完全崩壊）
    - dead expert 数（使用率 < 1% の expert 数）
    - トークン種別（struct / payload）ごとの平均幅と small expert 選択率
    - 達成精度（acc_payload, instr_valid, seq_valid）

事前登録:
  P1（崩壊仮説）: auxw=0 では auxw=0.05 に比べてエントロピー H が有意に低下し、
     maxshare が上昇する。少なくとも一部の seed で dead expert（死滅）が発生する。
  P2（幅配分仮説）: auxw=0 では HMoE において payload 幅が struct 幅を上回る（非対称の逆転）。
     崩壊が軽微な seed では精度が維持または向上する。
  P3（構造間比較）: HMoE（幅不均一）の方が U+LB（均一）よりも特定 expert（最大幅 224）への
     引力が働き、崩壊度合い（maxshare）が大きくなる。
  Kill 条件: auxw=0 で全 seed が完全崩壊（H < 0.2, maxshare > 0.9）し、学習が破綻した場合、
     「auxw=0 は実用不能な無効レジーム」と確定。

出力: simulation_hmoe_mmlu/data/q7/{arm}_{task}_aw{auxw}_s{seed}.json / q7_results.json
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import q2_difficulty_ladder as Q2  # noqa: E402
from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS  # noqa: E402
import e2b_rewrite_routing_fixed as E2  # noqa: E402

OUTDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q7")


def usage_entropy(u):
    """u: 1D 配列。正規化エントロピー。"""
    p = np.asarray(u, float)
    p = p / max(1.0, p.sum())
    p = p[p > 0]
    if len(p) <= 1:
        return 0.0
    return float(-(p * np.log(p)).sum() / np.log(len(u)))


@torch.no_grad()
def evaluate_q7(model, seq, typ, conds, bs=128):
    """Q2.evaluate を拡張し、全層の使用率・dead expert 数を精密記録する。"""
    n = seq.shape[0]
    dims = np.array(model.dims, dtype=np.float32)
    res = {}

    for cname, (kbl, allow) in conds.items():
        ce = np.zeros((n, Q2.T_LEN - Q2.TRACE0), dtype=np.float32)
        hit = np.zeros((n, Q2.T_LEN - Q2.TRACE0), dtype=bool)
        wid = np.zeros((n, Q2.T_LEN - Q2.TRACE0), dtype=np.float32)
        top1_l = np.zeros((model.L, n, Q2.T_LEN - Q2.TRACE0), dtype=np.int64)
        wid_l = np.zeros((model.L, n, Q2.T_LEN - Q2.TRACE0), dtype=np.float32)

        for i in range(0, n, bs):
            s = slice(i, min(i + bs, n))
            x = torch.from_numpy(seq[s])
            logits, idx_l = Q2.forward_q(model, x, k_by_layer=kbl, allow=allow, need_idx=True)
            lg = logits[:, Q2.TRACE0 - 1:-1, :len(Q2.VOCAB)]
            tgt = torch.from_numpy(seq[s, Q2.TRACE0:])
            lp = F.cross_entropy(lg.reshape(-1, len(Q2.VOCAB)), tgt.reshape(-1),
                                 reduction="none").reshape(-1, Q2.T_LEN - Q2.TRACE0)
            ce[s] = lp.numpy()
            hit[s] = (lg.argmax(-1).numpy() == tgt.numpy())

            for l, ti in enumerate(idx_l):
                a = ti.numpy()[:, Q2.TRACE0 - 1:-1, :]
                wid_l[l][s] = dims[a].mean(-1)
                top1_l[l][s] = a[:, :, 0]
                wid[s] += dims[a].mean(-1) / model.L

        ty = typ[:, Q2.TRACE0:]
        m_st, m_pl = (ty == Q2.TYP_STRUCT), (ty == Q2.TYP_PAYLOAD)

        # 全層の使用率集計
        layer_usages = []
        layer_entropies = []
        layer_maxshares = []
        layer_dead_experts = []

        for l in range(model.L):
            u_l = np.bincount(top1_l[l].reshape(-1), minlength=model.E)
            layer_usages.append(u_l.tolist())
            layer_entropies.append(usage_entropy(u_l))
            layer_maxshares.append(float(u_l.max() / max(1.0, u_l.sum())))
            # 1% 未満の使用率の expert を dead と定義
            dead_cnt = int(np.sum((u_l / max(1.0, u_l.sum())) < 0.01))
            layer_dead_experts.append(dead_cnt)

        # struct / payload ごとの expert 分布
        st_usage_l0 = np.bincount(top1_l[0][:, m_st[0]].reshape(-1), minlength=model.E).tolist()
        pl_usage_l0 = np.bincount(top1_l[0][:, m_pl[0]].reshape(-1), minlength=model.E).tolist()

        out = {
            "ce_all": float(ce.mean()),
            "ce_struct": float(ce[m_st].mean()),
            "ce_payload": float(ce[m_pl].mean()),
            "acc_struct": float(hit[m_st].mean()),
            "acc_payload": float(hit[m_pl].mean()),
            "width_struct": float(wid[m_st].mean()),
            "width_payload": float(wid[m_pl].mean()),
            "small_struct": float(np.isin(top1_l[-1][m_st], Q2.SMALL).mean()),
            "small_payload": float(np.isin(top1_l[-1][m_pl], Q2.SMALL).mean()),
            "usage_l0": layer_usages[0],
            "layer_usages": layer_usages,
            "layer_entropies": layer_entropies,
            "layer_maxshares": layer_maxshares,
            "layer_dead_experts": layer_dead_experts,
            "st_usage_l0": st_usage_l0,
            "pl_usage_l0": pl_usage_l0,
            "usage_entropy": layer_entropies[0],
            "usage_share_max": layer_maxshares[0],
            "dead_experts": layer_dead_experts[0],
        }

        hp = hit.reshape(n, Q2.P_STEPS, Q2.TPI)[:, :, 2:]
        instr_ok = hp.all(-1)
        out["instr_valid"] = float(instr_ok.all(-1).mean())
        out["instr_acc"] = float(instr_ok.mean())
        out["payload_token_acc"] = float(hp.mean())
        first = np.where(~instr_ok, np.arange(Q2.P_STEPS)[None, :], 10 ** 6).min(-1)
        out["seq_valid"] = float((first >= 10 ** 6).mean())

        res[cname] = out
    return res


def run(arm, task, seed, auxw, n_seqs, epochs, bs, lr):
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    aux_mode = "p_pen" if arm.startswith("H") else "switch"
    model = RewriteMoE(WIDTHS[arm], seed=seed)
    opt = Adam(model.params(), lr=lr)
    nparam = sum(v.numel() for v in model.params().values())

    steps_per_ep = max(1, n_seqs // bs)
    t0 = time.time()
    hist = []

    for ep in range(epochs):
        run_loss = 0.0
        for _ in range(steps_per_ep):
            seq, _ = Q2.make_trace_batch(rng, bs, task=task)
            x = torch.from_numpy(seq)
            logits, aux, _ = model(x, aux_mode=aux_mode)
            loss = Q2.trace_loss(logits, seq) + auxw * aux
            loss.backward()
            opt.step(model.params())
            run_loss += float(loss.detach())
        hist.append(run_loss / steps_per_ep)
        print(f"    [{arm} {task} aw{auxw} s{seed}] ep{ep+1}/{epochs} "
              f"loss={hist[-1]:.4f} ({time.time()-t0:.0f}s)", flush=True)

    ev_rng = np.random.default_rng(777)
    seq, typ = Q2.make_trace_batch(ev_rng, 1024, task=task)
    conds = {"base": (None, None), "force_small": (None, Q2.SMALL)}
    ev = evaluate_q7(model, seq, typ, conds)

    out = {"arm": arm, "seed": seed, "task": task, "auxw": auxw, "nparam": nparam,
           "loss_hist": hist, "n_eval": 1024, "sec": round(time.time() - t0, 1),
           "eval": ev}
    os.makedirs(OUTDIR, exist_ok=True)
    torch.save({k: v.detach() for k, v in model.params().items()},
               os.path.join(OUTDIR, f"ckpt_{arm}_{task}_aw{auxw}_s{seed}.pt"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", nargs="+", default=["H+LB", "U+LB"])
    ap.add_argument("--tasks", nargs="+", default=["compute", "hard"])
    ap.add_argument("--auxw", nargs="+", type=float, default=[0.0, 0.05])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4, 5])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--resume", action="store_true")
    args = ap.parse_args()

    os.makedirs(OUTDIR, exist_ok=True)
    torch.set_num_threads(6)
    print(f"Q7: arms={args.arms} tasks={args.tasks} auxw={args.auxw} seeds={args.seeds}", flush=True)

    rows = []
    for arm in args.arms:
        for task in args.tasks:
            for aw in args.auxw:
                tag = f"{aw:g}"
                for seed in args.seeds:
                    p = os.path.join(OUTDIR, f"{arm}_{task}_aw{tag}_s{seed}.json")
                    if args.resume and os.path.exists(p):
                        try:
                            with open(p, encoding="utf-8") as f:
                                r = json.load(f)
                            if r.get("n_eval") == 1024:
                                print(f"  [skip] {arm} {task} aw{tag} s{seed}", flush=True)
                                rows.append(r)
                                continue
                        except (json.JSONDecodeError, OSError):
                            pass
                    r = run(arm, task, seed, aw, args.seqs, args.epochs, args.bs, args.lr)
                    rows.append(r)
                    e = r["eval"]["base"]
                    d = e["small_payload"] - e["small_struct"]
                    print(f"  -> {arm} {task} aw{tag} s{seed}: "
                          f"acc pl={e['acc_payload']:.4f} iv={e['instr_valid']:.3f} "
                          f"Δ={d:+.3f} w_st/pl={e['width_struct']:.1f}/{e['width_payload']:.1f} "
                          f"H={e['usage_entropy']:.3f} maxshare={e['usage_share_max']:.3f} "
                          f"dead={e['dead_experts']}/8", flush=True)
                    with open(p, "w", encoding="utf-8") as f:
                        json.dump(r, f, ensure_ascii=False, indent=2)

    with open(os.path.join(OUTDIR, "q7_results.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
    print(f"[write] {OUTDIR}", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
