# -*- coding: utf-8 -*-
"""_fix_layout.py — レイアウト系の崩れを直す（意味を変えないものだけ）。

対象
  1. 連続空行（`\\n\\n\\n` 以上）→ 1 つに畳む
  2. 表の直前に空行が無い → 空行を入れる（入れないと表として描画されない）

**触らない**
  - 行末の空白: 2 個の行末空白は Markdown の強制改行（<br>）なので、消すと文がつながる
  - 見出し階層飛び: 描画は壊れない（cosmetic）
"""
import os
import re
import sys


def fix(src):
    lines = src.split("\n")
    out = []
    for ln in lines:
        # 1. 連続空行を畳む
        if ln.strip() == "" and out and out[-1].strip() == "":
            continue
        # 2. 表の直前に空行を入れる
        if ln.lstrip().startswith("|") and out and out[-1].strip() \
                and not out[-1].lstrip().startswith("|"):
            out.append("")
        out.append(ln)
    new = "\n".join(out)
    if not new.endswith("\n"):
        new += "\n"
    return new


def main():
    apply = "--apply" in sys.argv
    paths = [a for a in sys.argv[1:] if not a.startswith("--")]
    changed = 0
    for p in paths:
        src = open(p, encoding="utf-8").read()
        new = fix(src)
        if new == src:
            continue
        changed += 1
        d = len(src.split("\n")) - len(new.split("\n"))
        print(f"  {'OK' if d >= 0 else 'OK'} 行数 {len(src.split(chr(10)))} -> "
              f"{len(new.split(chr(10)))}   {os.path.basename(p)}")
        if apply:
            open(p, "w", encoding="utf-8", newline="\n").write(new)
    print(f"\n変更 {changed} 本 ({'適用済み' if apply else 'dry-run'})")


if __name__ == "__main__":
    main()
