# -*- coding: utf-8 -*-
"""_ax4_diag.py — AX4 の C6 校正不合格の原因を切り分ける事後診断（探索的）。

設計書 §6 の C6 は「100 回 permutation の max 絶対 rho 帰無分布の p95 未満なら
合格」と手続きを定めたが、**「観測値」を何にするかを明示しなかった**。
実装は観測値を「permute なしの Y と LOO 予測の max 絶対 rho」（＝予測性能）に
してしまったため、リーク検査ではなく予測性能の有意検定になっていた。

ここでは
  (1) null 分布を独立再計算し json と突合
  (2) 観測値の正体が予測性能であることを確認
  (3) AX3 と同型のリーク検査（S の行シャッフル）を実施
  (4) permute 後の 1 回統計量が null p95 未満かを確認
  (5) probe の R2 と実利得から実用上の意味を評価
ことで「リークか／設計意図と観測統計量の定義不良か」を判定する。

**C6 は不合格のまま記録し、この診断は確認的結論（V1/V2/V3/case）に一切使わない。**
使い方: python _ax4_diag.py
"""
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
PERM_SEED = 4400
NPERM = 100
WSHUF_SEED = 4400 + 9999
LAM = 10.0
OUT_JSON = os.path.join(HERE, "_ax4_diag.json")
OUT_TXT = os.path.join(HERE, "_ax4_diag_out_utf8.txt")


def spearman(a, b):
    ra = np.argsort(np.argsort(a)).astype(np.float64)
    rb = np.argsort(np.argsort(b)).astype(np.float64)
    ra -= ra.mean()
    rb -= rb.mean()
    den = np.sqrt((ra ** 2).sum() * (rb ** 2).sum())
    return float((ra * rb).sum() / den) if den > 0 else float("nan")


def ridge_loo(W, Y, lam=LAM):
    n = W.shape[0]
    pred = np.zeros_like(Y, dtype=np.float64)
    for f in range(n):
        tr = np.arange(n) != f
        Xtr, Xte = W[tr], W[f:f + 1]
        mu, sd = Xtr.mean(0), Xtr.std(0) + 1e-8
        A, B = (Xtr - mu) / sd, (Xte - mu) / sd
        ym = Y[tr].mean(0)
        d = A.shape[1]
        if d <= A.shape[0]:
            w = np.linalg.solve(A.T @ A + lam * np.eye(d), A.T @ (Y[tr] - ym))
        else:
            a = np.linalg.solve(A @ A.T + lam * np.eye(A.shape[0]), Y[tr] - ym)
            w = A.T @ a
        pred[f] = (B @ w + ym)[0]
    return pred


def maxrho(Y, pred):
    return float(max(abs(spearman(Y[:, j], pred[:, j])) for j in range(Y.shape[1])))


def r2(Y, pred):
    return 1.0 - float(((Y - pred) ** 2).sum() / ((Y - Y.mean(0)) ** 2).sum())


def main():
    z = np.load(os.path.join(HERE, "ax4_sentence_bound.npz"))
    with open(os.path.join(HERE, "ax4_sentence_bound.json"), encoding="utf-8") as fp:
        J = json.load(fp)
    S, Y, pred = z["S"].astype(np.float64), z["Y_sent"].astype(np.float64), \
        z["pred_sent"].astype(np.float64)
    n = Y.shape[0]
    c6 = J["calib"]["C6"]

    # (2) 観測値の正体
    obs = maxrho(Y, pred)
    pred_re = ridge_loo(S, Y)
    chk_pred = float(np.abs(pred_re - pred).max())

    # (1) null 分布の独立再計算
    rng = np.random.RandomState(PERM_SEED)
    null = []
    for it in range(NPERM):
        p = rng.permutation(n)
        Yp = Y[p]
        null.append(maxrho(Yp, ridge_loo(S, Yp)))
    null = np.array(null)
    p95 = float(np.percentile(null, 95))
    emp_p = float((1 + (null >= obs).sum()) / (NPERM + 1))
    pct = float((null < obs).mean() * 100.0)

    # (3) AX3 と同型のリーク検査: S の行だけをシャッフル
    rw = np.random.RandomState(WSHUF_SEED)
    pw = rw.permutation(n)
    pred_w = ridge_loo(S[pw], Y)
    wshuf = {"max_abs_rho": maxrho(Y, pred_w), "r2": r2(Y, pred_w)}

    # (4) permute 後の 1 回統計量（AX3 が本来期待していた observand）
    p1 = np.random.RandomState(WSHUF_SEED + 1).permutation(n)
    Y1 = Y[p1]
    perm1 = maxrho(Y1, ridge_loo(S, Y1))

    # (5) 実用上の意味
    gain_probe = J["exploratory"]["gains"]["sent_probe"]

    out = {
        "note": "事後診断・探索的。C6 は不合格のまま記録し、確認的結論には使わない。",
        "n": int(n), "n_perm": NPERM,
        "observed_in_json": c6["observed"],
        "observed_recomputed": obs,
        "observed_identity": "permute なしの Y と LOO 予測の max 絶対 rho ＝ 予測性能そのもの",
        "pred_recompute_maxdiff": chk_pred,
        "null_mean": float(null.mean()), "null_sd": float(null.std(ddof=1)),
        "null_p95": p95, "null_max": float(null.max()),
        "empirical_p_of_observed": emp_p,
        "observed_percentile": pct,
        "r2_unpermuted": r2(Y, pred),
        "S_shuffle_control": wshuf,
        "one_permutation_statistic": perm1,
        "one_permutation_below_p95": bool(perm1 < p95),
        "probe_gain_mean": gain_probe["mean"], "probe_gain_p": gain_probe["p_two"],
        "null_distribution": null.tolist(),
    }
    if wshuf["r2"] < 0 and perm1 < p95 and chk_pred == 0.0:
        verdict = ("リークの証拠はない。C6 不合格の原因は、設計書が「観測値」を明示せず "
                   "実装が予測性能を permutation 帰無分布と比較したことによる定義不良。"
                   "予測性能は偶然より高いが R2 は負で利得も n.s. のため実用上の意味はない")
    else:
        verdict = "リークの可能性を否定できない。要調査"
    out["verdict"] = verdict

    with open(OUT_JSON, "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    lines = [
        "AX4 C6 事後診断（探索的・確認的結論には使わない）",
        "観測 %.6f（json %.6f） ＞ null p95 %.6f → C6 は不合格のまま" % (obs, c6["observed"], p95),
        "観測値の正体: %s" % out["observed_identity"],
        "null n=%d  mean %.4f  sd %.4f  p95 %.4f  max %.4f"
        % (NPERM, null.mean(), null.std(ddof=1), p95, null.max()),
        "観測値の分位 %.1f パーセンタイル  empirical p = %.4f" % (pct, emp_p),
        "R2（permute なし） %.4f ／ probe 利得 %+.6f (p %.4g)"
        % (out["r2_unpermuted"], gain_probe["mean"], gain_probe["p_two"]),
        "S シャッフル対照: max|rho| %.4f  R2 %.4f" % (wshuf["max_abs_rho"], wshuf["r2"]),
        "permute 後 1 回統計量 %.4f  p95 未満 = %s" % (perm1, out["one_permutation_below_p95"]),
        "LOO 予測の再計算 maxdiff %.1f" % chk_pred,
        "判定: %s" % verdict,
    ]
    txt = "\n".join(lines)
    print(txt)
    with open(OUT_TXT, "w", encoding="utf-8") as fp:
        fp.write(txt + "\n")


if __name__ == "__main__":
    main()
