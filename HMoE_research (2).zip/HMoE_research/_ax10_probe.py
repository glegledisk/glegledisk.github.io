# -*- coding: utf-8 -*-
"""AX10 事前調査: AX7 の既存データから shift102/shift102b を再利用できるかを確認し、
S=20 の分割構築と C2 assert を走らせる。"""
import json, os, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
AX4_NPZ = os.path.join(HERE, "ax4_sentence_bound.npz")
AX5_NPZ = os.path.join(HERE, "ax5_granularity_mech.npz")
AX7_NPZ = os.path.join(HERE, "ax7_plateau.npz")
AX3_CORPUS = os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz")

N_LAYERS = 16
S = 20
SEED_BASE = 7201  # seed 7201..7220

def group_units(sid, k, n_win, n_eval):
    out = np.zeros_like(sid)
    off = 0
    for w in range(n_win):
        sl = slice(w * n_eval, (w + 1) * n_eval)
        sw = sid[sl]
        lo = sw - sw.min()
        out[sl] = off + lo // k
        off = int(out[sl].max()) + 1
    return out

def lengths_to_uid(lens):
    return np.repeat(np.arange(len(lens), dtype=np.int32), lens).astype(np.int32)

def uniform_lengths(n_unit, total):
    q, r = divmod(total, n_unit)
    ls = np.full(n_unit, q, dtype=np.int64)
    ls[:r] += 1
    return ls

def main():
    out = {}

    # Load saved data
    z4 = np.load(AX4_NPZ)
    z5 = np.load(AX5_NPZ)
    z7 = np.load(AX7_NPZ)

    nw = 48
    n_eval = 255
    n_tok = nw * n_eval
    assert n_tok == 12240

    c8 = z4["c8"][:, :n_tok].astype(np.float64)
    c7 = z4["c7"][:, :n_tok].astype(np.float64)
    sent = z4["sent"].astype(np.int64)[:n_tok].copy()
    _, sent = np.unique(sent, return_inverse=True)
    sent = sent.astype(np.int64)

    u7 = z4["nll_u7_rep"][:n_tok].astype(np.float64)
    base = z4["nll_base_rep"][:n_tok].astype(np.float64)

    # Check AX7 npz has shift102 / shift102b
    for nm in ("nll_shift102", "nll_shift102b", "nll_shift181", "nll_shift181b"):
        if nm in z7:
            print(f"  AX7 has {nm}: shape={z7[nm].shape}, mean={z7[nm][:n_tok].mean():.8f}")
        else:
            print(f"  AX7 MISSING {nm}")

    # Check AX4/AX7 u7 match
    u7_ax7 = z7["nll_u7"][:n_tok].astype(np.float64)
    maxdiff = float(np.abs(u7 - u7_ax7).max())
    print(f"\n  u7 maxdiff (AX4 vs AX7): {maxdiff}")
    out["u7_maxdiff_ax4_ax7"] = maxdiff

    # Build the 20 partitions for N=102 and N=181
    sent4 = group_units(sent, 4, nw, n_eval).astype(np.int32)
    sent2 = group_units(sent, 2, nw, n_eval).astype(np.int32)
    uni102 = lengths_to_uid(uniform_lengths(102, n_tok))
    uni181 = lengths_to_uid(uniform_lengths(181, n_tok))

    multi_102 = np.bincount(sent4)
    multi_181 = np.bincount(sent2)
    sorted_102 = np.sort(multi_102)
    sorted_181 = np.sort(multi_181)

    all_ok = True
    for s in range(S):
        seed = SEED_BASE + s
        for N, multi_sorted, prefix in ((102, sorted_102, "shift102"),
                                         (181, sorted_181, "shift181")):
            src = multi_102 if N == 102 else multi_181
            ls = np.random.default_rng(seed).permutation(src)
            ok = np.array_equal(np.sort(ls), multi_sorted)
            uid = lengths_to_uid(ls)
            assert uid.shape == (n_tok,), f"{prefix}_s{s+1:02d}"
            assert np.array_equal(np.unique(uid), np.arange(uid.max() + 1))
            assert np.bincount(uid).min() >= 1
            if not ok:
                print(f"  C2 FAIL: {prefix}_s{s+1:02d} multiset mismatch")
                all_ok = False

    out["C2_multiset_check"] = "PASS" if all_ok else "FAIL"
    out["n_partitions_102"] = S
    out["n_partitions_181"] = S
    out["total_new_forwards"] = 2 + (S - 2) * 2  # 2 校正 + (S-2)*2 新規shift (seed 7203..7220 × 2帯)
    out["total_new_forwards_detail"] = f"2 (base_rep+u7_rep) + {(S-2)*2} (shift 7203-7220 × 2N) = {2 + (S-2)*2}, plus 4 from AX7 cache = {2 + (S-2)*2 + 4} total evals"

    # Verify AX7 seeds match
    # AX7 used seed_a=7201, seed_b=7202
    ls_7201 = np.random.default_rng(7201).permutation(multi_102)
    uid_7201 = lengths_to_uid(ls_7201)
    uid_ax7 = z7["uid_shift102"][:n_tok].astype(np.int32)
    match_uid = np.array_equal(uid_7201, uid_ax7)
    print(f"\n  AX7 shift102 uid match (seed 7201): {match_uid}")
    out["ax7_uid_match_102"] = match_uid

    ls_7202 = np.random.default_rng(7202).permutation(multi_102)
    uid_7202 = lengths_to_uid(ls_7202)
    uid_ax7b = z7["uid_shift102b"][:n_tok].astype(np.int32)
    match_uidb = np.array_equal(uid_7202, uid_ax7b)
    print(f"  AX7 shift102b uid match (seed 7202): {match_uidb}")
    out["ax7_uid_match_102b"] = match_uidb

    # Similarly for 181
    ls_7201_181 = np.random.default_rng(7201).permutation(multi_181)
    uid_7201_181 = lengths_to_uid(ls_7201_181)
    uid_ax7_181 = z7["uid_shift181"][:n_tok].astype(np.int32)
    match_181 = np.array_equal(uid_7201_181, uid_ax7_181)
    print(f"  AX7 shift181 uid match (seed 7201): {match_181}")
    out["ax7_uid_match_181"] = match_181

    ls_7202_181 = np.random.default_rng(7202).permutation(multi_181)
    uid_7202_181 = lengths_to_uid(ls_7202_181)
    uid_ax7b_181 = z7["uid_shift181b"][:n_tok].astype(np.int32)
    match_181b = np.array_equal(uid_7202_181, uid_ax7b_181)
    print(f"  AX7 shift181b uid match (seed 7202): {match_181b}")
    out["ax7_uid_match_181b"] = match_181b

    # Check that we can reuse NLL from AX7
    for nm in ("shift102", "shift102b", "shift181", "shift181b"):
        nll_key = "nll_" + nm
        if nll_key in z7:
            nll = z7[nll_key][:n_tok].astype(np.float64)
            g = float((u7 - nll).mean())
            print(f"  Reusable G_{nm}: {g:+.10f}")
    
    # Estimate per-draw sigma from AX7
    g102a = float((u7 - z7["nll_shift102"][:n_tok].astype(np.float64)).mean())
    g102b = float((u7 - z7["nll_shift102b"][:n_tok].astype(np.float64)).mean())
    g181a = float((u7 - z7["nll_shift181"][:n_tok].astype(np.float64)).mean())
    g181b = float((u7 - z7["nll_shift181b"][:n_tok].astype(np.float64)).mean())
    sigma_102 = abs(g102a - g102b) / np.sqrt(2)
    sigma_181 = abs(g181a - g181b) / np.sqrt(2)
    out["sigma_draw_102_from_2pts"] = sigma_102
    out["sigma_draw_181_from_2pts"] = sigma_181
    out["se_shiftmean_102_S20"] = sigma_102 / np.sqrt(S)
    out["se_shiftmean_181_S20"] = sigma_181 / np.sqrt(S)

    print(f"\n  sigma_draw_102 (2-pt estimate): {sigma_102:.6f}")
    print(f"  sigma_draw_181 (2-pt estimate): {sigma_181:.6f}")
    print(f"  se_shiftmean_102 (S=20): {sigma_102/np.sqrt(S):.6f}")
    print(f"  se_shiftmean_181 (S=20): {sigma_181/np.sqrt(S):.6f}")

    with open(os.path.join(HERE, "_ax10_probe.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)
    print("\nSaved _ax10_probe.json")

if __name__ == "__main__":
    main()
