"""H6 の解析: 同一活性幅での Δ_b と交互作用、およびルータの配分。

Δ_b(c) = val_uni(c) − val_het(c)   （同一活性幅 c での損失差。正なら不均一が良い）
交互作用 = Δ_16(c) − Δ_1(c)
"""
import json
import os
from collections import defaultdict

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
UNI = {"uni_k1": 1.0, "uni_k2": 2.0}
HET = ["het_l005", "het_l01"]


def load():
    rows = []
    p = os.path.join(HERE, "h6_results.jsonl")
    with open(p, encoding="utf-8") as fp:
        for line in fp:
            if line.strip():
                rows.append(json.loads(line))
    return rows


def interp(xs, ys, x):
    o = np.argsort(xs)
    xs, ys = np.asarray(xs, dtype=float)[o], np.asarray(ys, dtype=float)[o]
    if x < xs[0] - 1e-9 or x > xs[-1] + 1e-9:
        return None
    return float(np.interp(x, xs, ys))


def main():
    rows = load()
    if not rows:
        print("no data")
        return
    by = defaultdict(list)
    for r in rows:
        by[(r["b"], r["arm"])].append(r)

    print("=== 生データ（seed 平均 ± SD）===")
    print("%4s %-10s %8s %8s %8s %8s %8s %8s" %
          ("b", "arm", "val", "sd", "cost", "d1", "d2", "d3"))
    for b in sorted({r["b"] for r in rows}):
        for arm in sorted({r["arm"] for r in rows}):
            rs = by.get((b, arm), [])
            if not rs:
                continue
            v = np.array([r["val"] for r in rs])
            c = np.array([r["cost"] for r in rs])
            d = {k: np.mean([r["cells"].get(k, np.nan) for r in rs]) for k in ("depth1", "depth2", "depth3")}
            print("%4d %-10s %8.4f %8.4f %8.3f %8.3f %8.3f %8.3f" %
                  (b, arm, v.mean(), v.std(ddof=1) if len(v) > 1 else 0, c.mean(),
                   d["depth1"], d["depth2"], d["depth3"]))
        print()

    seeds = sorted({r["seed"] for r in rows})
    print("=== 同一活性幅 c での Δ = val_uni(c) − val_het(c) ===")
    for c in (1.2, 1.4, 1.6, 1.8):
        print(f"\n-- c = {c} --")
        print("%4s %10s %10s %10s" % ("b", "Δ mean", "Δ sd", "n"))
        deltas = {}
        for b in sorted({r["b"] for r in rows}):
            ds = []
            for s in seeds:
                uy, ux = [], []
                for a, cc in UNI.items():
                    rr = [r for r in by.get((b, a), []) if r["seed"] == s]
                    if rr:
                        ux.append(cc)
                        uy.append(rr[0]["val"])
                hx, hy = [], []
                for a in HET:
                    rr = [r for r in by.get((b, a), []) if r["seed"] == s]
                    if rr:
                        hx.append(rr[0]["cost"])
                        hy.append(rr[0]["val"])
                if len(ux) < 2 or len(hx) < 2:
                    continue
                uv, hv = interp(ux, uy, c), interp(hx, hy, c)
                if uv is not None and hv is not None:
                    ds.append(uv - hv)
            if ds:
                deltas[b] = (float(np.mean(ds)), float(np.std(ds, ddof=1)) if len(ds) > 1 else 0.0, len(ds))
                print("%4d %10.4f %10.4f %10d" % (b, deltas[b][0], deltas[b][1], deltas[b][2]))
        if 1 in deltas and 16 in deltas:
            print(f"  交互作用 Δ16 − Δ1 = {deltas[16][0] - deltas[1][0]:+.4f}")

    print("\n=== ルータの配分（depth 別の平均活性幅、b=16）===")
    print("%-10s %8s %8s %8s %10s" % ("arm", "depth1", "depth2", "depth3", "d1-d23"))
    for arm in ("uni_k1", "uni_k2") + tuple(HET):
        rs = by.get((16, arm), [])
        if not rs:
            continue
        d1 = np.mean([r["diag"]["depth1"] for r in rs])
        d2 = np.mean([r["diag"]["depth2"] for r in rs])
        d3 = np.mean([r["diag"]["depth3"] for r in rs])
        print("%-10s %8.3f %8.3f %8.3f %+10.3f" % (arm, d1, d2, d3, d1 - (d2 + d3) / 2))

    print("\n=== ルータの配分（b 別、depth1 − depth2/3）===")
    for arm in HET:
        line = []
        for b in sorted({r["b"] for r in rows}):
            rs = by.get((b, arm), [])
            if rs:
                d1 = np.mean([r["diag"]["depth1"] for r in rs])
                d2 = np.mean([(r["diag"]["depth2"] + r["diag"]["depth3"]) / 2 for r in rs])
                line.append(f"b={b}: {d1 - d2:+.3f}")
        if line:
            print("%-10s %s" % (arm, "   ".join(line)))


if __name__ == "__main__":
    main()
