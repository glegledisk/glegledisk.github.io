"""P4b の図: (a) 決定価値の深さ依存、(b) 損失関数の効果、(c) 厳密測定の裾。"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "Noto Sans JP", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))
leg = json.load(open(os.path.join(HERE, "p4_legal_results.json"), encoding="utf-8"))
mlp1 = json.load(open(os.path.join(HERE, "p4_mlp_results.json"), encoding="utf-8"))
mlp2 = json.load(open(os.path.join(HERE, "p4_mlp2_results.json"), encoding="utf-8"))
p3 = np.load(os.path.join(HERE, "p3_topk_nll.npz"))
base = p3["k8"]
ex = np.load(os.path.join(HERE, "p4_adaptive_nll_ALL_l15___bce.npz"))["probe50"]
rnd = np.load(os.path.join(HERE, "p4_adaptive_nll.npz"))["random50"]
NW, L = 48, 255

UNIFORM = 0.01449
RANDOM = 0.02511

fig = plt.figure(figsize=(15.5, 4.3))

# (a) dv vs 決定に使う層（一次評価）
ax = fig.add_subplot(1, 3, 1)
groups = {0: ["gate0", "h0+hist", "ALL(l0)"], 8: ["gate8+mech8+hist"], 15: ["ALL(l15)"]}
for Lr, names in groups.items():
    ys = [leg["rows"][n]["dv50"] for n in names]
    causal = leg["rows"][names[0]]["causal"] == "yes"
    ax.scatter([Lr] * len(ys), ys, s=110,
               facecolor=("#c0392b" if causal else "none"),
               edgecolor="#c0392b", linewidths=1.8, zorder=3)
    for n, y in zip(names, ys):
        ax.annotate("%s\nAUC %.2f" % (n.replace("+mech8+hist", "").replace("+mech", ""),
                                      leg["rows"][n]["auc"]),
                    (Lr, y), textcoords="offset points", xytext=(9, 4), fontsize=6.8)
ax.axhline(UNIFORM, color="black", ls="--", lw=1.8, label="均一 top-7（同予算）")
ax.axhline(RANDOM, color="#7f8c8d", ls=":", lw=1.5, label="ランダム 50%")
ax.set_xticks([0, 8, 15])
ax.set_xlabel("決定に使う信号の層")
ax.set_ylabel(r"達成 $\Delta$CE（一次評価, nats/token）")
ax.set_title("(a) 情報は「計算の後ろ」にしかない", fontsize=11)
ax.legend(fontsize=8, loc="upper right")
ax.grid(alpha=0.3, axis="y")
ax.set_xlim(-1.5, 19)
ax.annotate("塗りつぶし = 因果的に合法\n白抜き = その層まで走らないと得られない",
            (0.03, 0.03), xycoords="axes fraction", fontsize=7.5,
            bbox=dict(boxstyle="round", fc="white", ec="#999999"))

# (b) 損失関数の効果
ax = fig.add_subplot(1, 3, 2)
sets = ["gate15", "mech_L15+hist", "gate15+mech+hist", "gate0+gate15", "ALL(l15)"]
ridge = [mlp1["table"][s]["auc_ridge"] for s in sets]
mse = [mlp1["table"][s]["auc_mlp"] for s in sets]
bce = [mlp2["rows"][s + "|bce"]["auc"] for s in sets]
x = np.arange(len(sets))
w = 0.26
ax.bar(x - w, ridge, w, label="ridge（線形）", color="#7f8c8d")
ax.bar(x, mse, w, label="MLP・MSE 回帰", color="#e67e22")
ax.bar(x + w, bce, w, label="MLP・BCE（上位25%分類）", color="#c0392b")
ax.axhline(0.5, color="gray", ls="--", lw=1)
ax.axhline(0.65, color="#8e44ad", ls=":", lw=1.5)
ax.annotate("逆転ライン ≈ 0.65", (4.45, 0.653), fontsize=7.5, color="#8e44ad", ha="right")
ax.set_xticks(x)
ax.set_xticklabels([s.replace("mech_L15+hist", "mech+hist") for s in sets],
                   fontsize=7, rotation=18)
ax.set_ylabel("AUC（$d_j$ 上位 25% の識別）")
ax.set_title("(b) 非線形より「損失関数」が効く", fontsize=11)
ax.legend(fontsize=7.5, loc="lower right")
ax.set_ylim(0.45, 0.70)
ax.grid(alpha=0.3, axis="y")

# (c) 厳密測定の裾（窓別）
ax = fig.add_subplot(1, 3, 3)
e = (ex - base).reshape(NW, L).mean(1)
er = (rnd - base).reshape(NW, L).mean(1)
order = np.argsort(-e)
ax.bar(np.arange(NW), e[order], color="#c0392b", label="probe(ALL l15)")
ax.plot(np.arange(NW), er[order], "o", color="#7f8c8d", ms=3, label="ランダム 50%")
ax.axhline(0, color="black", lw=0.8)
ax.set_xlabel("窓（コストの大きい順）")
ax.set_ylabel(r"窓ごとの平均 $\Delta$CE")
ax.set_title("(c) 厳密測定: 1/48 の窓が全コストの 87%", fontsize=11)
ax.legend(fontsize=8)
ax.grid(alpha=0.3, axis="y")
ax.annotate("反復領域でパターンが壊れ、\n以降のトークンが連鎖的に悪化",
            (6, e[order][1] * 0.75), fontsize=7.5,
            bbox=dict(boxstyle="round", fc="#fdf2e9", ec="#e67e22"))

fig.tight_layout()
out = os.path.join(HERE, "p4b_probe_figure.png")
fig.savefig(out, dpi=140)
print("saved", out)
print("median window e_j: %.4f  mean %.4f  max %.4f" % (np.median(e), e.mean(), e.max()))
