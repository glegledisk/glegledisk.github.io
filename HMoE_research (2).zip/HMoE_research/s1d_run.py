# -*- coding: utf-8 -*-
"""S1d: 3-condition measurement on the 3 social-sciences books.

Conditions per query: toc / toc_drop (gold row removed) / distractor_drop
(sibling row removed).  Same teacher-forced margin as S1/S1b.

Writes s1d_<book>.npz + s1d_<book>.json + s1d_<book>_out_utf8.txt
"""
import argparse
import json
import os
import time

import numpy as np
import torch

import s1_stair_routing as S

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--manifest", type=str, default=os.path.join(HERE, "s1d_manifest.json"))
    ap.add_argument("--gpu-gib", type=float, default=7.5)
    ap.add_argument("--cpu-gib", type=float, default=12.0)
    ap.add_argument("--books", type=str, default="all")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--tag", type=str, default="s1d")
    args = ap.parse_args()

    t_start = time.time()
    with open(args.manifest, encoding="utf-8") as f:
        man = json.load(f)
    books = list(man["domains"].keys()) if args.books == "all" else [b.strip() for b in args.books.split(",")]

    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[1/3] loading %s" % args.model)
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()

    Wsrc = model.lm_head.weight
    if Wsrc.is_meta:
        hook = getattr(model.lm_head, "_hf_hook", None)
        wm = getattr(hook, "weights_map", None) if hook is not None else None
        real = wm["weight"] if wm is not None else None
        if real is None or getattr(real, "is_meta", False):
            raise RuntimeError("lm_head real weight not found")
    else:
        real = Wsrc
    Whead = real.detach().float().cpu()

    chk = tok("The quick brown fox jumps over the lazy dog.", return_tensors="pt",
              add_special_tokens=False).input_ids.to(model.device)
    with torch.no_grad():
        h = model.model(input_ids=chk, use_cache=False).last_hidden_state[:, -1:, :]
        lg = h.float().cpu() @ Whead.t()
        ref = model(input_ids=chk, use_cache=False).logits[:, -1:, :].float().cpu()
    head_err = float((lg - ref).abs().max())
    log("      head check = %.5f" % head_err)
    if head_err > 0.5:
        raise RuntimeError("head check failed")

    log("[2/3] forward")
    for bid in books:
        d = man["domains"][bid]
        book = d["book"]
        toc = d["toc"]
        toc_lines = ["%s %s" % (r["id"], r["title"]) for r in toc]
        line_by_id = {r["id"]: "%s %s" % (r["id"], r["title"]) for r in toc}
        entries = d["entries"]
        if args.limit:
            entries = entries[:args.limit]

        rows, gold_tok = [], []
        n_fwd, t_fwd = 0, 0.0
        for ei, e in enumerate(entries):
            g_cd = S.tokenize_suffix(tok, e["gold"])
            s_cd = S.tokenize_suffix(tok, e["sibling"])
            f_cd = S.tokenize_suffix(tok, e["far"]) if e.get("far") else None
            gd = g_cd
            div_s, lvl_s = S.divergence(gd, s_cd)
            div_f, lvl_f = S.divergence(gd, f_cd) if f_cd is not None else (-1, -1)

            conds = {
                "toc": "\n".join(toc_lines),
                "toc_drop": "\n".join(l for l in toc_lines if l != line_by_id[e["gold_id"]]),
                "distractor_drop": "\n".join(l for l in toc_lines if l != line_by_id[e["sibling_id"]]),
            }

            gold_ids = gd["ids"]
            C = len(gold_ids)
            for cond, text in conds.items():
                prompt = S.build_prompt(book, e["query"], text, True)
                prompt_ids = tok(prompt, add_special_tokens=False)["input_ids"]
                P = len(prompt_ids)
                if P + C + 10 > int(model.config.max_position_embeddings):
                    log("      SKIP %s %s: prompt too long %d" % (bid, cond, P))
                    continue
                seq = prompt_ids + gold_ids
                ids = torch.tensor([seq], dtype=torch.long, device=model.device)
                t1 = time.time()
                with torch.no_grad():
                    out = model.model(input_ids=ids, use_cache=False)
                    h = out.last_hidden_state[:, P - 1:P - 1 + C, :]
                    lg = h.float().cpu() @ Whead.t()
                t_fwd += time.time() - t1
                n_fwd += 1
                lsm = torch.log_softmax(lg, dim=-1)

                gtgt = torch.tensor(gold_ids, dtype=torch.long, device=lsm.device)
                gvals = lsm[0, torch.arange(C, device=lsm.device), gtgt].cpu().numpy()

                def cand_logp(cd, div):
                    if cd is None or div < 0 or div >= C or div >= len(cd["ids"]):
                        return float("nan")
                    return float(lsm[0, div, cd["ids"][div]])

                for typ, cd, div, lvl in (("sibling", s_cd, div_s, lvl_s), ("far", f_cd, div_f, lvl_f)):
                    rows.append({
                        "book_id": bid, "query_idx": ei, "condition": cond,
                        "cand_type": typ, "div_idx": int(div), "div_level": int(lvl),
                        "logp_div": cand_logp(cd, div), "prompt_len": P,
                        "n_tok": len(cd["ids"]) if cd is not None else -1,
                    })
                gold_tok.append({
                    "book_id": bid, "query_idx": ei, "condition": cond,
                    "ids": np.asarray(gold_ids), "len": C, "logp": np.asarray(gvals, dtype=np.float32),
                    "isnum": np.asarray(gd["num_mask"], dtype=bool), "prompt_len": P,
                })
            log("      %-16s %2d/%d  P=%d C=%d  %.2fs  (elapsed %.0fs)"
                % (bid, ei + 1, len(entries), P, C, time.time() - t1, time.time() - t_start))

        # save
        maxC = max(g["len"] for g in gold_tok) if gold_tok else 0
        gl = np.full((len(gold_tok), maxC), np.nan)
        gi = np.full((len(gold_tok), maxC), False, dtype=bool)
        for i, g in enumerate(gold_tok):
            gl[i, :g["len"]] = g["logp"]
            gi[i, :g["len"]] = g["isnum"]
        meta = {"book_id": bid, "book": book, "n_entries": len(entries), "n_fwd": n_fwd,
                "mean_fwd_s": t_fwd / max(n_fwd, 1), "elapsed_s": time.time() - t_start,
                "head_err": head_err, "n_toc": len(toc)}
        out = os.path.join(HERE, "%s_%s.npz" % (args.tag, bid))
        np.savez_compressed(
            out,
            meta=np.asarray([json.dumps(meta, ensure_ascii=False)], dtype=object),
            row_book=np.asarray([r["book_id"] for r in rows], dtype=object),
            row_query_idx=np.asarray([r["query_idx"] for r in rows], dtype=np.int64),
            row_condition=np.asarray([r["condition"] for r in rows], dtype=object),
            row_cand_type=np.asarray([r["cand_type"] for r in rows], dtype=object),
            row_div_idx=np.asarray([r["div_idx"] for r in rows], dtype=np.int64),
            row_div_level=np.asarray([r["div_level"] for r in rows], dtype=np.int64),
            row_logp_div=np.asarray([r["logp_div"] for r in rows], dtype=float),
            row_prompt_len=np.asarray([r["prompt_len"] for r in rows], dtype=np.int64),
            row_n_tok=np.asarray([r["n_tok"] for r in rows], dtype=np.int64),
            gold_logp=gl, gold_isnum=gi,
            gold_query_idx=np.asarray([g["query_idx"] for g in gold_tok], dtype=np.int64),
            gold_condition=np.asarray([g["condition"] for g in gold_tok], dtype=object),
            gold_len=np.asarray([g["len"] for g in gold_tok], dtype=np.int64),
            gold_prompt_len=np.asarray([g["prompt_len"] for g in gold_tok], dtype=np.int64),
        )
        with open(os.path.join(HERE, "%s_%s.json" % (args.tag, bid)), "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False, indent=1)
        log("      wrote %s (%d rows)" % (out, len(rows)))

    with open(os.path.join(HERE, args.tag + "_out_utf8.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(LOG))
    log("[3/3] done")
    os._exit(0)


if __name__ == "__main__":
    main()
