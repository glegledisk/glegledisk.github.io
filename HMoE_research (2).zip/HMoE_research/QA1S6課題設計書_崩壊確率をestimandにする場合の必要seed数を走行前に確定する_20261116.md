# QA1S6 課題設計書: 崩壊確率を estimand にする場合の必要 seed 数を走行前に確定する

- 日付: 2026-11-16（`検証報告_QA1S5S1_..._20261116.md` §3 と `STATE.md` 16:15 追記の次の一手）
- ステータス: **設計確定・本設計書は新規学習を含まない**。Step 1 は検出力計算のみ。本番 54+ run はユーザー指示まで起動しない
- 区分: **QA1S6**。QA1S5 が「崩壊確率を estimand にするなら seed 数を増やす別 ID が必要」と記録した次の一手。estimand を変更するならこの別 ID で走行前に固定する
- 関連: `QA1S5課題設計書_床runを学習崩壊と収束途中に分離する_20261116.md` §3、`検証報告_QA1S5S1_..._20261116.md`、`qa1s4_metrics.json`、`qa1s5_step1_metrics.json`、`_s6_power_probe.py`、`AGENTS.md` §2 / §3 / §7
- 出力: 本設計書、Step 1 の検出力計算成果物（本番学習成果物は今回なし）

---

## 0. 問いと前提

QA1S5 は 21 run（7 seed × 3 腕）の床を `COLLAPSE = [w_mid_s2]`（1 run）、`TRANSIENT = [w_ref_s0]`（1 run）、`HEALTHY = 19` に分離した。主指標 `Δ_iv`（paired 連続値）は C5-P6 停止で確認的判定を出していない。本次は、**「崩壊確率」を新たな estimand に昇格させる場合に必要な seed 数**を、新規学習なしの検出力計算で走行前に確定する。

観測された崩壊は `w_mid` で `1/7`、`w_ref` で `0/7`。同一 seed の腕間で対応する二値事象なので、検定は McNemar の exact binomial（discordant pair の片側 b 対他側 c）が自然である。Paired t 検定（`Δ_iv`）とは estimand も検定も別で、両者を混ぜない。

---

## 1. 走行前に固定する estimand と検定

| 項目 | 定義 |
|---|---|
| 崩壊ラベル | QA1S5 §2 の固定規則（`COLLAPSE`）をそのまま使う。閾値 `COLLAPSE_CE = 0.5` は変更しない |
| estimand | `Δ_collapse = P(COLLAPSE \| w_mid) − P(COLLAPSE \| w_ref)`（同一 seed 対応） |
| 帰無 | `Δ_collapse = 0`（対称な discordant pair） |
| 検定 | McNemar exact binomial、両側 `α = 0.05`、`b + c ≥ 1`。`b`/`c` は discordant pair 数 |
| 効果量 | `b / n` と `c / n`、`Δ_collapse` の点推定 |
| 検出力目標 | `P(b ≥ 6 \| n, q) ≥ 0.80`（`c = 0` と仮定。b=6, c=0 で exact p = 0.03125 < 0.05） |

`q` は `w_mid` の真の崩壊確率。観測 `1/7 = 0.1429` は 1 seed の点推定で母数として確定できないので、`q ∈ {0.1429, 0.20, 0.25}` の感度を併記する。

---

## 2. Step 1 検出力計算（新規学習なし・事前固定）

`_s6_power_probe.py` の計算結果を一次ソースとして再計算し、必要 seed 数を確定する。

| 想定 q | 必要 n (`P(b≥6) ≥ 0.80`) | `E[discordant] = n·q` | 到達確率 |
|---:|---:|---:|---:|
| 0.1429（観測 1/7） | **54** | 7.71 | 0.8022 |
| 0.20 | 39 | 7.80 | 0.8200 |
| 0.25 | 31 | 7.75 | 0.8236 |

McNemar exact の片側 p 値: `b=1 → 1.0`、`b=3 → 0.25`、`b=5 → 0.0625`、`b=6 → 0.03125`。したがって 7 seed（観測 b=1）では detecting power がなく、**54 seed を最小設計とする**。走行時間は 21 run が 5,679 秒（QA1S4）なので、54 seed × 2 腕 = 108 run は約 8 時間（単独換算）、6 並列でも数時間の見積りになる。**本次では走らせない**。

---

## 3. 本番（別途指示があった場合のみ）

54 seed × 2 腕（`w_ref` / `w_mid`）＝ 108 run、`w_flat` は探索的のみで確認的家族に入れない。学習条件・幅・gain 補完・random 非復元・eval 系列数は QA1S4 と同一。崩壊ラベルは QA1S5 §2 の固定規則を使う。`Δ_collapse` の棄却時も「AMD の崩壊確率が幅条件で高い」という 1 testbed の観測として扱い、Q-A の一般解や保留 1 の解消を主張しない。

---

## 4. 限界

1. `q = 1/7` は 1 seed の点推定であり、54 seed はこの点推定を母数とした設計値。真の q が 0.10 なら必要 n はさらに増える。
2. `c = 0`（w_ref が崩壊しない）と仮定している。w_ref も崩壊する場合は discordant が相殺し必要 n が増える。
3. 崩壊ラベルは経験閾値（`COLLAPSE_CE = 0.5`）に依存する。別 testbed では再校正が必要。
4. 新規学習を 1 本も走らせていないので、54 seed 設計の実現可能性（時間・メモリ）は見積りのみ。
5. 1 testbed・1 ハーネス。保留 1 と Z1 §4 規則 3 は維持する。QE1S6 とは estimand もハーネスも別でまとめない。

---

## 5. 再現

```powershell
$p = "C:\Users\gochu\.workbuddy-ai\binaries\python\envs\gpu\Scripts\python.exe"
$wd = "C:\Users\gochu\WorkBuddy AI\不均一MoE"
$env:PYTHONIOENCODING = "utf-8"
Set-Location $wd
& $p "_s6_power_probe.py"
& $p "_md_check.py" "$wd\QA1S6課題設計書_崩壊確率をestimandにする場合の必要seed数を走行前に確定する_20261116.md"
```

**実装メモ**: `scipy.stats.binomtest(b, b+c, 0.5, alternative="two-sided")` で McNemar exact p を計算する。 discordant pair が 1 では p=1.0 で、7 seed の観測だけでは「崩壊確率に差がある」とは言えない。q の感度は 0.1429 / 0.20 / 0.25 の 3 点に固定し、結果を見て追加しない。

---

## 追記（2026-11-16）: Step 1 検出力計算完了 — 54 seed 必要、本番は未起動

- `_s6_power_probe.py` で必要 seed 数を計算。`q=1/7` で **n=54**（`P(b≥6)=0.8022`）、`q=0.20` で 39、`q=0.25` で 31。McNemar exact は `b=6, c=0` で初めて `p=0.03125 < 0.05`（`b=5` は 0.0625）。
- 独立検算 `_qa1s6_verify.py` は 10 項目・0 不一致。`Δ_collapse` は `Δ_iv`（連続値 paired t）とは別 estimand で、QA1S4 の非棄却から推論しない。
- **54 seed × 2 腕 = 108 run の本番は起動していない**。走行時間は 21 run=5,679 秒からの外挿で約 8 時間（単独）だが実測ではない。起動はユーザー判断に委ねる。
- 詳細は `検証報告_QA1S6S1_崩壊確率の検定には54seed必要で7seedの観測は検出力不足_20261116.md`。

---

## 追記（2026-11-16）: 本番途中経過 — w_ref の崩壊を 1 run 観測、検出力設計の前提が崩れた

- 本番 108 run の初回起動は runner の 7-seed 前提（QA1S2 baseline を必須で読む）で全 run が失敗したため停止。runner を修正し、seed≥7 では C1 比較をスキップして再起動した。**学習条件・estimand・崩壊ラベル・seed 範囲は変更していない**。
- 2 回目の走行は 50/108 run 完了時点でユーザーにより中断された。cache に 50 run（w_ref 0..42、w_mid 0..6）が保存済みで、再開可能。
- **★ `w_ref s39` が COLLAPSE**（`spike=True`, `final_iv=0`, `final_ce=1.1902`）。Step 1 の検出力計算は `c=0`（w_ref は崩壊しない）を仮定していたが、この仮定は実測で成立しなかった。54 seed 必要という数値は `q_ref=0` 前提のまま参考値として残し、完了後に `c≥1` を織り込んだ discordant pair 数（b と c の差）で再判定する。**c を 0 に戻すための seed 除外・ラベル変更はしない**。
- Step 1 の感度表（`q=0.20 → 39 seed`, `q=0.25 → 31 seed`）は `c=0` 前提のまま有効。w_ref の崩壊率は部分標本で 1/43 だが、完了後に実測 q_ref を記録する。
- 部分標本（7 paired seed）では `b=1, c=0` で QA1S4 と同じ。検出力不足の結論は不変。

---

## 追記（2026-11-16）: 108 run 完了 — 崩壊確率は非棄却、w_ref の崩壊 2 回で c=0 仮定が崩れた

- cache 50 run を再利用して残り 58 run を再開し、全 108 run が完了（総走行 7,377 秒）。独立検算 236 項目・0 不一致、`verdict = PASS`。
- **結果**: `q_mid = 1/54 = 0.018519`、`q_ref = 2/54 = 0.037037`、`Δ_collapse = −0.018519`。discordant `b=1`（mid のみ s2）、`c=2`（ref のみ s39/s50）、`both=0`、`neither=51`。McNemar exact `p = 1.000000` で非棄却。
- **Step 1 の `c=0` 仮定は実測で崩れた**。54 seed は `q_ref=0` 前提の設計値で、実測後は b と c の差で判定するという本設計書の追記どおりに扱った。seed 除外・ラベル変更・閾値変更はしていない。
- `w_ref s51` は `final_iv=0` だが spike が無く NOT_COLLAPSE（QA1S5 の TRANSIENT 相当）。崩壊と床を混同しない固定規則を維持した。
- 連続値 estimand は参考記録 `Δ_iv = +0.030527`, `se 0.050228`, `t 0.6078`, `p 0.545945`, `n 54`, `MDE 0.122904`（QA1S4 の `−0.073940` と符号が反転）。確認的家族へは混ぜない。
- 詳細は `検証報告_QA1S6S1_54seedで崩壊確率は非棄却_w_refの崩壊がw_midを上回り各方面仮定は崩れた_20261116.md`。
