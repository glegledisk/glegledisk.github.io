# -*- coding: utf-8 -*-
"""P20 解析: thinking on で best-of-N の較正はどうなるか

nothink（P14: cap 96, s1 0.725 / maj 0.900 / pass@8 1.000）との対比で、
  (1) thinking は精度を上げるか（同じ 20 問・N=4）
  (2) 打ち切りが支配的になると、どの適格性規則が要るか（P17 の box 規則）
  (3) argmax の反選択は再現するか
を見る。

出力: p20_analysis.json / p20_analysis_out_utf8.txt
"""
import json
import os
import re
from collections import Counter

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = []


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def auroc(scores, labels):
    s = np.asarray(scores, float)
    y = np.asarray(labels, bool)
    ok = np.isfinite(s)
    s, y = s[ok], y[ok]
    pos, neg = s[y], s[~y]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    d = (pos[:, None] > neg[None, :]).sum() + 0.5 * (pos[:, None] == neg[None, :]).sum()
    return float(d / (len(pos) * len(neg)))


def paired(a):
    a = np.asarray(a, float)
    a = a[np.isfinite(a)]
    sd = float(np.std(a, ddof=1))
    se = sd / np.sqrt(len(a))
    t, p = stats.ttest_1samp(a, 0.0) if sd > 0 else (float("nan"), float("nan"))
    return {"mean": float(np.mean(a)), "se": float(se), "t": float(t), "p": float(p),
            "n": int(len(a))}


def majority(vals):
    c = Counter([v for v in vals if v is not None])
    if not c:
        return None, 0
    best = max(c.values())
    for v in vals:
        if v is not None and c[v] == best:
            return v, best
    return None, 0


POOLS = {
    "all": lambda s: True,
    "fin": lambda s: s["finished"],                     # 完走（P15/P16 の trunc 規則）
    "box": lambda s: s["boxed"] or s["final_phr"],      # P17 の規則（全文に適用）
    "bx": lambda s: s["boxed"],                         # \boxed のみ（思考中の "final answer" を拾わない）
    "fin_bx": lambda s: s["finished"] or s["boxed"],    # 完走 or \boxed
}


def pick(sub, pool, key):
    cand = [(j, s) for j, s in enumerate(sub)
            if s[key] is not None and pool(s)]
    if not cand:
        return None
    return max(cand, key=lambda t: (t[1][key], -t[0]))[1]


def main():
    rows = [json.loads(l) for l in open(os.path.join(HERE, "p20_think.jsonl"),
                                        encoding="utf-8") if l.strip()]
    recs = [r for r in rows if r.get("round") != "greedy"]
    greedy = [r for r in rows if r.get("round") == "greedy"]
    log("recs=%d greedy=%d" % (len(recs), len(greedy)))

    S = [s for r in recs for s in r["samples"]]
    n = len(S)
    y = np.array([bool(s["correct"]) for s in S])
    yb = np.array([bool(s["box_correct"]) if s["box_correct"] is not None else False for s in S])
    fin = np.array([s["finished"] for s in S])
    box = np.array([s["boxed"] or s["final_phr"] for s in S])
    ntok = np.array([s["ntok"] for s in S], float)

    log("\n[1] 生成の構造 (n=%d, cap=%d)" % (n, 2048))
    log("  完走率 %.3f (%d) / 打ち切り %.3f / 中央 ntok %.0f / 平均 ntok %.0f"
        % (fin.mean(), int(fin.sum()), 1 - fin.mean(), np.median(ntok), ntok.mean()))
    log("  \\boxed あり %.3f / final 句あり %.3f / どちらか %.3f"
        % (np.mean([s["boxed"] for s in S]), np.mean([s["final_phr"] for s in S]), box.mean()))
    log("  正解率（最後の数字列）%.4f / （\\boxed の値）%.4f"
        % (y.mean(), np.mean([s["box_correct"] is True for s in S])))
    for lab, m in [("完走", fin), ("打ち切り", ~fin), ("box 適格", box), ("box 不適格", ~box)]:
        if m.sum():
            log("    %-10s n=%-3d 正解率=%.4f  平均 ntok=%.0f"
                % (lab, int(m.sum()), y[m].mean(), ntok[m].mean()))

    # 打ち切り × box のクロス
    log("\n  完走×box クロス（正解率）")
    for a, b, lab in [(True, True, "完走 & box"), (True, False, "完走 & not box"),
                      (False, True, "打切 & box"), (False, False, "打切 & not box")]:
        m = (fin == a) & (box == b)
        if m.sum():
            log("    %-14s n=%-3d 正解率=%.4f" % (lab, int(m.sum()), y[m].mean()))

    # ---- 適格性規則ごとの被覆と精度 ----
    log("\n[2] 適格性規則（ペア数=%d, N=%d）" % (len(recs), len(recs[0]["samples"])))
    log("  %-5s %8s %9s %9s %9s %9s" %
        ("pool", "cover", "mean|p|", "pool acc", "confmax", "maj"))
    tb = {}
    for pname, pool in POOLS.items():
        sizes, pacc, cm, mj, orc = [], [], [], [], []
        for r in recs:
            sub = r["samples"]
            c = [s for s in sub if pool(s)]
            sizes.append(len(c))
            if not c:
                continue
            pacc.append(np.mean([bool(s["correct"]) for s in c]))
            cm.append(float(pick(sub, pool, "p_ans")["correct"]))
            mp, _ = majority([s["pred"] for s in c])
            mj.append(float(mp == r["gold"]))
            orc.append(float(any(s["correct"] for s in c)))
        tb[pname] = {"cover": float(np.mean([1 if k else 0 for k in sizes])),
                     "mean_pool": float(np.mean(sizes)),
                     "pool_acc": float(np.mean(pacc)), "confmax": float(np.mean(cm)),
                     "maj": float(np.mean(mj)), "oracle": float(np.mean(orc)),
                     "n": len(cm)}
        log("  %-5s %8.3f %9.2f %9.4f %9.4f %9.4f  (oracle %.4f, n=%d)"
            % (pname, tb[pname]["cover"], tb[pname]["mean_pool"], tb[pname]["pool_acc"],
               tb[pname]["confmax"], tb[pname]["maj"], tb[pname]["oracle"], tb[pname]["n"]))

    # s1 基準
    s1 = np.array([float(r["samples"][0]["correct"]) for r in recs])
    log("\n  s1（1 本目）正解率 = %.4f  /  pass@4 = %.4f"
        % (s1.mean(), np.mean([float(any(s["correct"] for s in r["samples"])) for r in recs])))

    # ---- 対応差 ----
    log("\n[3] 対応差（vs s1, n=%d）" % len(recs))
    tests = []
    for pname, pool in POOLS.items():
        cm, mj = [], []
        for i, r in enumerate(recs):
            sub = r["samples"]
            if not any(pool(s) for s in sub):
                continue
            cm.append(float(pick(sub, pool, "p_ans")["correct"]) - s1[i])
            mp, _ = majority([s["pred"] for s in sub if pool(s)])
            mj.append(float(mp == r["gold"]) - s1[i])
        for lab, arr in [("confmax", cm), ("maj", mj)]:
            t_ = {"pool": pname, "rule": lab, "diff": paired(arr)}
            tests.append(t_)
            log("  %-5s %-8s dAcc=%+.4f (t=%+.2f, p=%.3g, n=%d)"
                % (pname, lab, t_["diff"]["mean"], t_["diff"]["t"], t_["diff"]["p"],
                   t_["diff"]["n"]))

    # ---- サンプル単位 AUROC ----
    log("\n[4] サンプル単位 AUROC（正誤 vs 確信度）")
    for key in ["p_ans", "p_full"]:
        v = [s[key] for s in S]
        log("  %-7s 全 %d: AUC=%.3f" % (key, n, auroc(v, y)))
        if fin.sum():
            log("  %-7s 完走 %d: AUC=%.3f"
                % (key, int(fin.sum()),
                   auroc([S[i][key] for i in np.where(fin)[0]], y[fin])))
        if box.sum():
            log("  %-7s box 適格 %d: AUC=%.3f"
                % (key, int(box.sum()),
                   auroc([S[i][key] for i in np.where(box)[0]], y[box])))

    # ---- nothink との対比 ----
    log("\n[5] nothink（P14, cap 96）との対比")
    log("  thinking : s1=%.4f  maj(fin)=%.4f  pass@4=%.4f  平均 ntok=%.0f"
        % (s1.mean(), tb["fin"]["maj"], np.mean([float(any(s["correct"] for s in r["samples"]))
                                                 for r in recs]), ntok.mean()))
    log("  nothink  : s1=0.7250  maj=0.9000  pass@8=1.0000  平均 ntok≈70（P14）")
    log("  トークン比 %.1f 倍" % (ntok.mean() / 70.0))

    # greedy slack
    sl = [g["slack"] for g in greedy if g.get("slack") is not None]
    if sl:
        log("\n[検算] greedy argmax-slack mean=%.6f max=%.6f n=%d"
            % (float(np.mean(sl)), float(np.max(sl)), len(sl)))

    out = {"n_samples": n, "fin_rate": float(fin.mean()), "box_rate": float(box.mean()),
           "acc_last": float(y.mean()), "acc_box": float(yb.mean()),
           "mean_ntok": float(ntok.mean()), "median_ntok": float(np.median(ntok)),
           "table": tb, "tests": tests, "s1": float(s1.mean()),
           "pass4": float(np.mean([float(any(s["correct"] for s in r["samples"])) for r in recs])),
           "slack": {"mean": float(np.mean(sl)), "max": float(np.max(sl))} if sl else None}
    with open(os.path.join(HERE, "p20_analysis.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    with open(os.path.join(HERE, "p20_analysis_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    log("saved: p20_analysis.json")
    os._exit(0)


if __name__ == "__main__":
    main()
