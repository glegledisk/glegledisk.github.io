"""
P4e: 機構的特徴のスキャン — 何が「削るコスト d_j」を予測するのか

動機:
  P4 では「ルータ logit の線形 probe で d_j は AUC 0.55」だった。
  しかしルータの中には **コストに直結する量** が既にある:
    p8        : 落とされる 8 位 Expert の確率（＝その Expert の寄与の大きさ）
    p7+p8     : top-6 に削るときに失う確率質量そのもの
    z8 - z9   : 8 位と 9 位の logit 差（近ければ「代わりがいる」）
    mass      : top-8 の確率和（FFN 出力のスケール）
  これらが d_j をどれだけ説明するかを、モデルを当てる前に見る。

出力: 標準出力（表）+ p4_mech_features.npz
"""

import os

import numpy as np

from p4b_probe import auc_score, spearman

HERE = os.path.dirname(os.path.abspath(__file__))


def layer_feats(G, k_drop=2):
    """ルータ logit (n, E) から機構的特徴を作る。k_drop=2 は top-8 -> top-6。"""
    z = G.astype(np.float64)
    n, E = z.shape
    order = np.argsort(-z, axis=1)
    zs = np.take_along_axis(z, order, axis=1)           # 降順 logit
    p = np.exp(z - z.max(1, keepdims=True))
    p /= p.sum(1, keepdims=True)
    ps = np.take_along_axis(p, order, axis=1)           # 降順確率

    p1 = ps[:, 0]
    p7 = ps[:, 6]
    p8 = ps[:, 7]
    p9 = ps[:, 8]
    keep = 8 - k_drop                                    # 6
    feats = {
        "p1": p1,
        "p7": p7,
        "p8": p8,
        "p9": p9,
        "p7p8": p7 + p8,                                 # 失う質量（2 本）
        "p8_over_p1": p8 / np.maximum(p1, 1e-12),
        "p9_over_p8": p9 / np.maximum(p8, 1e-12),
        "z8_z9": zs[:, 7] - zs[:, 8],                    # 8 位と 9 位の差
        "z6_z9": zs[:, keep - 1] - zs[:, 8],             # 6 位と 9 位の差
        "mass8": ps[:, :8].sum(1),
        "mass6": ps[:, :keep].sum(1),
        "lost_mass": ps[:, keep:8].sum(1),               # まさに失う質量
        "ent": -(p * np.log(p + 1e-12)).sum(1),
        "zmax": zs[:, 0],
        "zstd": z.std(1),
        "zmean": z.mean(1),
        "npos": (z > 0).sum(1).astype(np.float64),
    }
    return feats


def main():
    d = np.load(os.path.join(HERE, "p4_feats.npz"), allow_pickle=True)
    p3 = np.load(os.path.join(HERE, "p3_topk_nll.npz"))
    nll_j = p3["k8"]
    d_j = p3["k6"] - p3["k8"]
    ybin = (d_j > np.quantile(d_j, 0.75)).astype(int)
    n = d_j.size
    print("n = %d  d_j mean %+.5f" % (n, d_j.mean()))

    # 全層平均の機構的特徴（層ごとの値も保存）
    per_layer = {}
    for l in range(16):
        per_layer[l] = layer_feats(d["gate_%d" % l])
    names = list(per_layer[0].keys())

    print("\n=== 単一特徴の予測力（層ごと、d_j 上位 25% の AUC / Spearman）===")
    print("%-11s" % "feature", end="")
    for l in (0, 4, 8, 12, 15):
        print("  L%-2d AUC  rho" % l, end="")
    print()
    rows = {}
    for nm in names:
        line = "%-11s" % nm
        rows[nm] = {}
        for l in (0, 4, 8, 12, 15):
            v = per_layer[l][nm]
            a = auc_score(ybin, v)
            r = spearman(v, d_j)
            # 符号は「値が大きいほどコスト大」に揃える
            if r < 0:
                a = 1 - a
                r = -r
            rows[nm][l] = (a, r)
            line += "  %.3f %+.2f" % (a, r)
        print(line)

    print("\n=== 全層平均した特徴の予測力 ===")
    print("%-11s %8s %8s" % ("feature", "AUC", "Spearman"))
    avg = {}
    for nm in names:
        v = np.mean([per_layer[l][nm] for l in range(16)], axis=0)
        avg[nm] = v
        a = auc_score(ybin, v)
        r = spearman(v, d_j)
        if r < 0:
            a = 1 - a
            r = -r
        print("%-11s %8.3f %8.3f" % (nm, a, r))

    np.savez_compressed(os.path.join(HERE, "p4_mech_features.npz"),
                        **{("L%d_%s" % (l, nm)): per_layer[l][nm]
                           for l in range(16) for nm in names},
                        **{("avg_" + nm): avg[nm] for nm in names},
                        d_j=d_j, nll_j=nll_j, win=d["win"], pos=d["pos"])


if __name__ == "__main__":
    main()
