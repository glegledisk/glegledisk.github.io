#!/usr/bin/env python3
"""K1d: K1（seed 0-2）と K1c（seed 3-9）の 10 seed を合わせて ΔCE を推定する。

**主眼は平均ではなく分布。** 10 seed のうち 3 本は「片方が収束していない」run で、
Δ の分布は 2 つの母集団の混合になる。平均・中央値・符号・収束後の部分集合を並べる。

出力: k1d_combined.json / k1d_out_utf8.txt
"""
import json
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "k1d_out_utf8.txt")
lines = []


def p(s=""):
    print(s, flush=True)
    lines.append(s)


def summ(d, label=""):
    d = np.asarray(d, float)
    n = len(d)
    m, se = float(d.mean()), float(d.std(ddof=1) / np.sqrt(n))
    t = m / se
    pv = 2 * stats.t.sf(abs(t), df=n - 1)
    crit = stats.t.ppf(0.975, df=n - 1)
    coef = crit + stats.t.ppf(0.80, df=n - 1)
    return {"label": label, "n": n, "mean": m, "median": float(np.median(d)),
            "sd": float(d.std(ddof=1)), "se": se, "t": float(t), "p": float(pv),
            "ci_lo": m - crit * se, "ci_hi": m + crit * se,
            "mde": coef * se, "n_neg": int((d < 0).sum())}


def show(s, d):
    p("  %-22s n=%-2d  平均 %+.4f  中央値 %+.4f  SD %.4f  se %.4f  t %+.2f  p %.4f"
      % (s["label"], s["n"], s["mean"], s["median"], s["sd"], s["se"], s["t"], s["p"]))
    p("  %-22s 95%%CI [%+.4f, %+.4f]  MDE %.4f  負 %d/%d"
      % ("", s["ci_lo"], s["ci_hi"], s["mde"], s["n_neg"], s["n"]))
    p("")


def main():
    k1 = json.load(open(os.path.join(HERE, "k1_results.json"), encoding="utf-8"))
    rows = []
    for s in (0, 1, 2):
        rows.append({"seed": s, "src": "K1",
                     "ce_t": k1["runs"]["teacher:s%d" % s]["ce_all"],
                     "ce_s": k1["runs"]["dense161:s%d" % s]["ce_all"],
                     "delta": k1["runs"]["diff:dense161:s%d" % s]["delta"],
                     "w_t": k1["runs"]["teacher:s%d" % s]["width"]})
    kc = json.load(open(os.path.join(HERE, "k1c_results.json"), encoding="utf-8"))
    for r in kc["rows"]:
        rows.append({"seed": r["seed"], "src": "K1c", "ce_t": r["ce_t"],
                     "ce_s": r["ce_s"], "delta": r["delta"], "w_t": r["w_teacher"]})
    rows.sort(key=lambda r: r["seed"])

    p("K1d: 等 active 計算量（dense W=161 vs HMoE top-2）の ΔCE を seed 10 本で推定")
    p("ΔCE = CE(生徒) − CE(教師)。負なら生徒が良い。")
    p("")
    p("| seed | 出所 | CE_教師 | CE_生徒 | ΔCE | 教師幅 |")
    p("|---:|---|---:|---:|---:|---:|")
    for r in rows:
        p("| %d | %s | %.4f | %.4f | %+.4f | %.1f |"
          % (r["seed"], r["src"], r["ce_t"], r["ce_s"], r["delta"], r["w_t"]))
    p("")

    d = np.array([r["delta"] for r in rows])
    ce_t = np.array([r["ce_t"] for r in rows])
    ce_s = np.array([r["ce_s"] for r in rows])

    p("== 1) 全 10 seed（失敗込み） ==")
    a = summ(d, "全 10 seed")
    show(a, d)
    p("  ★ **平均 %+.4f と中央値 %+.4f は符号が逆**。平均は s9 の +0.6955 が作っている。"
      % (a["mean"], a["median"]))
    p("")

    p("== 2) 分布の形（外れ値の分離） ==")
    p("  CE_教師: %s" % " ".join("%.3f" % x for x in np.sort(ce_t)))
    p("  CE_生徒: %s" % " ".join("%.3f" % x for x in np.sort(ce_s)))
    p("  健康な run の CE は 0.35〜0.45。**0.45〜0.50 のどこに閾値を置いても同じ 3 本が落ちる**")
    p("  （0.4434 → 0.5067 に 0.063 の空白、0.5067 → 0.6298 に 0.123、0.6298 → 1.0517 に 0.42）")
    p("")

    TH = 0.47
    fail = [(r["seed"], r["ce_t"] > TH, r["ce_s"] > TH) for r in rows]
    ok_rows = [r for r in rows if r["ce_t"] <= TH and r["ce_s"] <= TH]
    bad_rows = [r for r in rows if not (r["ce_t"] <= TH and r["ce_s"] <= TH)]
    p("== 3) 収束した run だけ（判定: CE ≤ %.2f） ==" % TH)
    p("  落ちた run: %s" % ", ".join(
        "s%d(%s)" % (s, "教師" if ft else "生徒") for s, ft, fs in fail if ft or fs))
    p("  → **3/10 が「片方が収束していない」**（教師 1 本、生徒 2 本）")
    d_ok = np.array([r["delta"] for r in ok_rows])
    b = summ(d_ok, "収束した %d seed" % len(ok_rows))
    show(b, d_ok)
    p("  ※ **この除外は事後**。閾値は Δ ではなく各モデル自身の CE に置いた（比較を見ていない）が、")
    p("    「除外して有意になった」と読まれても仕方ない。**主結果は §1（全 10）で、これは副次**。")
    p("")

    p("== 4) 累積（seed を足したときの MDE） ==")
    p("| n | 平均 | se | MDE | 負の数 |")
    p("|---:|---:|---:|---:|---:|")
    cum = []
    for k in range(2, len(d) + 1):
        s = summ(d[:k])
        cum.append(s)
        p("| %d | %+.4f | %.4f | %.4f | %d |" % (k, s["mean"], s["se"], s["mde"], s["n_neg"]))
    p("")
    p("  **MDE は n とともに単調に縮まない**（s9 を足した時点で SD が 0.05 → 0.25 に跳ねる）。")
    p("  「MDE 0.02 には 9 本」は **SD 0.018 を前提にした計算**で、その SD は K1 の 3 本が")
    p("  たまたま揃っていたことの産物だった。")
    p("")

    p("== 5) どちらが不安定か ==")
    p("  CE_教師: 平均 %.4f  SD %.4f  最大 %.4f" % (ce_t.mean(), ce_t.std(ddof=1), ce_t.max()))
    p("  CE_生徒: 平均 %.4f  SD %.4f  最大 %.4f" % (ce_s.mean(), ce_s.std(ddof=1), ce_s.max()))
    p("  健康な run だけ: CE_教師 SD %.4f / CE_生徒 SD %.4f"
      % (np.std([r["ce_t"] for r in ok_rows], ddof=1),
         np.std([r["ce_s"] for r in ok_rows], ddof=1)))
    p("")

    p("== 6) 1 本の影響（drop-one） ==")
    for i, r in enumerate(rows):
        m = np.delete(d, i).mean()
        p("  s%d を除くと平均 %+.4f（全体 %+.4f、差 %+.4f）" % (r["seed"], m, d.mean(), m - d.mean()))
    p("")

    if os.path.exists(os.path.join(HERE, "k1b_results.json")):
        kb = json.load(open(os.path.join(HERE, "k1b_results.json"), encoding="utf-8"))
        dd = [v["delta"] for v in kb["matched"].values()]
        p("== 7) 参考: 幅を合わせた対応（K1b, n=%d） ==" % len(dd))
        p("  ΔCE = %+.4f（per-seed %s）" % (np.mean(dd), ", ".join("%+.4f" % x for x in dd)))
        p("  → 固定 W=161 の 3 seed（%+.4f）より**小さい**。"
          "「幅のずれが seed 間ばらつきの主因」は支持されない。" % np.mean(d[:3]))
        p("")

    out = {"rows": rows, "all": a, "converged": b, "cumulative": cum,
           "threshold": TH,
           "ce_sd": {"teacher": float(ce_t.std(ddof=1)),
                     "student": float(ce_s.std(ddof=1))},
           "drop_one": [{"seed": r["seed"], "mean_without": float(np.delete(d, i).mean())}
                        for i, r in enumerate(rows)]}
    with open(os.path.join(HERE, "k1d_combined.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n[write] %s" % OUT)


if __name__ == "__main__":
    main()
