# -*- coding: utf-8 -*-
import re
from markdown_it import MarkdownIt

path = "検証報告_P13d_P13第4節のCEはビット一致し条件Dの寄与はMDE以下_20261105.md"
with open(path, encoding="utf-8") as fh:
    src = fh.read()
html = MarkdownIt("commonmark").enable("table").render(src)
body = re.sub(r"<pre>.*?</pre>", "", html, flags=re.S)
body = re.sub(r"<code>.*?</code>", "<code>X</code>", body, flags=re.S)

out = []
for m in re.finditer(r"\*\*", body):
    out.append("STAR: ..." + body[max(0, m.start() - 100):m.end() + 100].replace("\n", " ") + "...")

with open("_p13d_md_probe_out.txt", "w", encoding="utf-8") as fh:
    fh.write("\n".join(out) + "\n")
print("done", len(out))
