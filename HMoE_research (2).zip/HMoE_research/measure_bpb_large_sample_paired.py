# -*- coding: utf-8 -*-
"""measure_bpb_large_sample_paired.py — 大規模サンプル & 同一バイト区間対応ペア・ブートストラップによる日英BPB有意差検定

目的:
  10/24 独立検算 (audit3 / 批判レビュー §2.5) で指摘された:
  「英語側での Qwen vs SmolLM の BPB 差が 95%CI で 0 を跨ぎ、統計的非有意であった」
  という課題を解決する。

改善点:
  1. 評価サンプル規模を約 5 倍 (8192 トークン相当, 約 32KB〜40KB の長文テキスト) に拡大
  2. 同一のテキスト（生バイト列）に対する「バイト位置対応ペア・ブートストラップ」を導入
     (同一のバイトブロックに対して両モデルの損失を比較することで、テキスト難易度の交絡を相殺)
  3. ブロック長 500 バイト、反復 5000 回の移動ブロック・ブートストラップによる厳密な 95%CI と p 値の算出
"""

import os
import sys
import glob
import math
import json
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM
import pandas as pd
import matplotlib.pyplot as plt

os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["TOKENIZERS_PARALLELISM"] = "false"
HERE = os.path.dirname(os.path.abspath(__file__))

def get_corpus(max_bytes=40000):
    # 英語コーパス
    en_files = sorted(glob.glob(os.path.join(HERE, "english_version", "**", "*.md"), recursive=True))
    en_text = ""
    for f in en_files:
        en_text += open(f, encoding="utf-8").read() + "\n\n"
        if len(en_text.encode("utf-8")) > max_bytes:
            break
    en_bytes = en_text.encode("utf-8")[:max_bytes]
    en_text_clean = en_bytes.decode("utf-8", "ignore")
    
    # 日本語コーパス
    ja_files = [f for f in sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True)) if "english_version" not in f]
    ja_text = ""
    for f in ja_files:
        ja_text += open(f, encoding="utf-8").read() + "\n\n"
        if len(ja_text.encode("utf-8")) > max_bytes:
            break
    ja_bytes = ja_text.encode("utf-8")[:max_bytes]
    ja_text_clean = ja_bytes.decode("utf-8", "ignore")
    
    return {"en": en_text_clean, "ja": ja_text_clean}

def _b2u():
    bs = (list(range(ord("!"), ord("~")+1)) + list(range(ord("\u00a1"), ord("\u00ac")+1))
          + list(range(ord("\u00ae"), ord("\u00ff")+1)))
    cs = bs[:]
    n = 0
    for b in range(256):
        if b not in bs:
            bs.append(b)
            cs.append(256 + n)
            n += 1
    return {chr(c): b for b, c in zip(bs, cs)}

U2B = _b2u()

def raw_tok_bytes(s):
    o = bytearray()
    for ch in s:
        b = U2B.get(ch)
        if b is None:
            return s.encode("utf-8", "ignore")
        o.append(b)
    return bytes(o)

def extract_token_stream(model_dir, text, max_tokens=8192, chunk_size=512, cache_key=""):
    cache_path = os.path.join(HERE, f"cache_{cache_key}.npz")
    if os.path.exists(cache_path):
        print(f"Loading cached stream from {cache_path}...")
        data = np.load(cache_path)
        return data["bits"], data["bytes"]
        
    print(f"Loading {os.path.basename(model_dir)}...")
    tok = AutoTokenizer.from_pretrained(model_dir, local_files_only=True)
    mdl = AutoModelForCausalLM.from_pretrained(
        model_dir, local_files_only=True, dtype=torch.float32, low_cpu_mem_usage=True
    )
    mdl.eval()
    
    # トークン化
    enc = tok(text, add_special_tokens=False)
    ids = enc["input_ids"][:max_tokens]
    
    token_bits = []
    token_bytes = []
    
    print(f"  Encoding {len(ids)} tokens (chunk={chunk_size})...")
    with torch.no_grad():
        for s in range(0, len(ids) - 1, chunk_size):
            c = ids[s:s + chunk_size + 1]
            if len(c) < 2:
                break
            inp = torch.tensor([c[:-1]])
            tgt = torch.tensor([c[1:]])
            logits = mdl(inp).logits
            lp = torch.log_softmax(logits, dim=-1)
            v = -lp[0, torch.arange(len(c) - 1), tgt[0]].numpy()
            bits = v / math.log(2.0)
            token_bits.extend(bits.tolist())
            
            for t in c[1:]:
                # バイト数
                b_len = len(raw_tok_bytes(tok.convert_ids_to_tokens(t)))
                token_bytes.append(max(1, b_len))
                
    bits_arr = np.array(token_bits, dtype=np.float64)
    bytes_arr = np.array(token_bytes, dtype=np.float64)
    np.savez(cache_path, bits=bits_arr, bytes=bytes_arr)
    return bits_arr, bytes_arr

def run_large_sample_evaluation():
    corpus = get_corpus(max_bytes=45000)
    models = {
        "qwen3-0.6b": os.path.join(HERE, "models", "qwen3-0.6b"),
        "smollm-135m": os.path.join(HERE, "models", "smollm-135m")
    }
    
    results = {}
    
    for lang in ["en", "ja"]:
        text = corpus[lang]
        text_bytes_len = len(text.encode("utf-8"))
        print("\n" + "=" * 90)
        print(f" Language: {lang.upper()} (Corpus raw bytes: {text_bytes_len:,} bytes)")
        print("=" * 90)
        
        streams = {}
        for mname, mpath in models.items():
            bits, nbytes = extract_token_stream(mpath, text, max_tokens=8192, chunk_size=512, cache_key=f"{mname}_{lang}")
            streams[mname] = {"bits": bits, "bytes": nbytes}
            
            bpb = float(bits.sum() / nbytes.sum())
            bpt = float(nbytes.sum() / len(bits))
            bptok = float(bits.mean())
            print(f"  [{mname:12s}] Tokens: {len(bits):5d} | Sum Bytes: {int(nbytes.sum()):5d} | bpt: {bpt:.3f} | bits/tok: {bptok:.3f} | bpb: {bpb:.4f}")
            
        results[lang] = streams

    # 統計的ブートストラップ検定 (Moving Block Bootstrap)
    print("\n" + "=" * 90)
    print(" 統計的ブートストラップ検定 (Block size = 100 tokens, 5000 iterations)")
    print("=" * 90)
    
    summary_rows = []
    
    for lang in ["en", "ja"]:
        q_bits = results[lang]["qwen3-0.6b"]["bits"]
        q_bytes = results[lang]["qwen3-0.6b"]["bytes"]
        s_bits = results[lang]["smollm-135m"]["bits"]
        s_bytes = results[lang]["smollm-135m"]["bytes"]
        
        # 共通の最小評価バイト数に合わせる
        eval_bytes = min(q_bytes.sum(), s_bytes.sum())
        q_cum = np.cumsum(q_bytes)
        s_cum = np.cumsum(s_bytes)
        
        q_cut = np.searchsorted(q_cum, eval_bytes)
        s_cut = np.searchsorted(s_cum, eval_bytes)
        
        q_bits = q_bits[:q_cut]
        q_bytes = q_bytes[:q_cut]
        q_cum = q_cum[:q_cut]
        
        s_bits = s_bits[:s_cut]
        s_bytes = s_bytes[:s_cut]
        s_cum = s_cum[:s_cut]
        
        # Qwen と SmolLM 単体の 95% CI
        def moving_block_bootstrap(bits, nbytes, B=50, n_boot=5000):
            L = len(bits)
            n_blocks = int(np.ceil(L / B))
            rng = np.random.default_rng(42)
            boot_bpb = []
            for _ in range(n_boot):
                starts = rng.integers(0, L - B + 1, n_blocks)
                idx = (starts[:, None] + np.arange(B)[None, :]).ravel()
                idx = idx[idx < L]
                boot_bpb.append(bits[idx].sum() / nbytes[idx].sum())
            return np.array(boot_bpb)
            
        q_boot = moving_block_bootstrap(q_bits, q_bytes, B=100)
        s_boot = moving_block_bootstrap(s_bits, s_bytes, B=100)
        
        q_mean = float(q_bits.sum() / q_bytes.sum())
        q_ci = [float(np.percentile(q_boot, 2.5)), float(np.percentile(q_boot, 97.5))]
        
        s_mean = float(s_bits.sum() / s_bytes.sum())
        s_ci = [float(np.percentile(s_boot, 2.5)), float(np.percentile(s_boot, 97.5))]
        
        # 差のブートストラップ (正規化バイトブロックに基づくペア差分推定)
        # 各ブロック区間 (例: 500 バイト区間) ごとの BPB をペア化
        block_bytes = 500
        n_byte_blocks = int(eval_bytes // block_bytes)
        
        q_block_bits = []
        s_block_bits = []
        
        for blk in range(n_byte_blocks):
            b_start = blk * block_bytes
            b_end = (blk + 1) * block_bytes
            
            # Qwen
            q_mask = (q_cum >= b_start) & (q_cum < b_end)
            if np.any(q_mask):
                q_block_bits.append(q_bits[q_mask].sum())
            else:
                q_block_bits.append(0.0)
                
            # SmolLM
            s_mask = (s_cum >= b_start) & (s_cum < b_end)
            if np.any(s_mask):
                s_block_bits.append(s_bits[s_mask].sum())
            else:
                s_block_bits.append(0.0)
                
        q_block_bits = np.array(q_block_bits)
        s_block_bits = np.array(s_block_bits)
        
        rng = np.random.default_rng(123)
        diff_boots = []
        for _ in range(5000):
            sample_idx = rng.choice(n_byte_blocks, size=n_byte_blocks, replace=True)
            tot_b = n_byte_blocks * block_bytes
            q_bpb_b = q_block_bits[sample_idx].sum() / tot_b
            s_bpb_b = s_block_bits[sample_idx].sum() / tot_b
            diff_boots.append(s_bpb_b - q_bpb_b)
            
        diff_boots = np.array(diff_boots)
        mean_diff = float(s_mean - q_mean)
        diff_ci = [float(np.percentile(diff_boots, 2.5)), float(np.percentile(diff_boots, 97.5))]
        p_val = float(np.mean(diff_boots <= 0))
        
        print(f"\n[{lang.upper()}] 評価バイト数: {int(eval_bytes):,d} bytes")
        print(f"  Qwen3-0.6B:   BPB = {q_mean:.4f} (95% CI: [{q_ci[0]:.4f}, {q_ci[1]:.4f}])")
        print(f"  SmolLM-135M:  BPB = {s_mean:.4f} (95% CI: [{s_ci[0]:.4f}, {s_ci[1]:.4f}])")
        print(f"  Diff (SmolLM - Qwen): Delta BPB = {mean_diff:+.4f} (95% CI: [{diff_ci[0]:+.4f}, {diff_ci[1]:+.4f}]) | P(Delta <= 0) = {p_val:.4f}")
        
        sig_str = "Statistically Significant (p < 0.05)" if diff_ci[0] > 0 else "Not Significant (includes 0)"
        print(f"  Verdict: {sig_str}")
        
        summary_rows.append({
            "lang": lang,
            "eval_bytes": int(eval_bytes),
            "qwen_tokens": len(q_bits),
            "smollm_tokens": len(s_bits),
            "qwen_bpt": float(q_bytes.sum() / len(q_bits)),
            "smollm_bpt": float(s_bytes.sum() / len(s_bits)),
            "bpt_ratio": float((q_bytes.sum() / len(q_bits)) / (s_bytes.sum() / len(s_bits))),
            "qwen_bpb": q_mean,
            "qwen_bpb_ci_lo": q_ci[0],
            "qwen_bpb_ci_hi": q_ci[1],
            "smollm_bpb": s_mean,
            "smollm_bpb_ci_lo": s_ci[0],
            "smollm_bpb_ci_hi": s_ci[1],
            "diff_bpb": mean_diff,
            "diff_ci_lo": diff_ci[0],
            "diff_ci_hi": diff_ci[1],
            "p_val": p_val,
            "is_significant": bool(diff_ci[0] > 0)
        })

    df = pd.DataFrame(summary_rows)
    out_csv = os.path.join(HERE, "bpb_large_sample_ci_results.csv")
    df.to_csv(out_csv, index=False)
    
    with open(os.path.join(HERE, "bpb_large_sample_ci_results.json"), "w", encoding="utf-8") as f:
        json.dump(summary_rows, f, indent=2, ensure_ascii=False)
        
    print(f"\nSaved results to {out_csv} and JSON.")
    
    # 可視化プロット生成
    plot_bpb_ci(summary_rows)

def plot_bpb_ci(summary_rows):
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    # 図 1: モデル別 BPB と 95% CI
    ax1 = axes[0]
    x = np.arange(2)
    w = 0.35
    
    en_q = [r for r in summary_rows if r["lang"] == "en"][0]
    ja_q = [r for r in summary_rows if r["lang"] == "ja"][0]
    
    q_vals = [en_q["qwen_bpb"], ja_q["qwen_bpb"]]
    q_errs = [
        [en_q["qwen_bpb"] - en_q["qwen_bpb_ci_lo"], ja_q["qwen_bpb"] - ja_q["qwen_bpb_ci_lo"]],
        [en_q["qwen_bpb_ci_hi"] - en_q["qwen_bpb"], ja_q["qwen_bpb_ci_hi"] - ja_q["qwen_bpb"]]
    ]
    
    s_vals = [en_q["smollm_bpb"], ja_q["smollm_bpb"]]
    s_errs = [
        [en_q["smollm_bpb"] - en_q["smollm_bpb_ci_lo"], ja_q["smollm_bpb"] - ja_q["smollm_bpb_ci_lo"]],
        [en_q["smollm_bpb_ci_hi"] - en_q["smollm_bpb"], ja_q["smollm_bpb_ci_hi"] - ja_q["smollm_bpb"]]
    ]
    
    ax1.bar(x - w/2, q_vals, w, yerr=q_errs, capsize=5, label="Qwen3-0.6B (151k Vocab)", color="#1f77b4", alpha=0.85)
    ax1.bar(x + w/2, s_vals, w, yerr=s_errs, capsize=5, label="SmolLM-135M (49k Vocab)", color="#ff7f0e", alpha=0.85)
    
    ax1.set_ylabel("Bits Per Byte (BPB) [Lower is Better]")
    ax1.set_title("BPB by Model and Language with 95% Bootstrap CI")
    ax1.set_xticks(x)
    ax1.set_xticklabels(["English", "Japanese"])
    ax1.grid(True, axis="y", ls="--", alpha=0.5)
    ax1.legend()
    
    # 図 2: 差分 ΔBPB (SmolLM - Qwen) と 95% CI
    ax2 = axes[1]
    diffs = [en_q["diff_bpb"], ja_q["diff_bpb"]]
    diff_errs = [
        [en_q["diff_bpb"] - en_q["diff_ci_lo"], ja_q["diff_bpb"] - ja_q["diff_ci_lo"]],
        [en_q["diff_ci_hi"] - en_q["diff_bpb"], ja_q["diff_ci_hi"] - ja_q["diff_bpb"]]
    ]
    
    colors = ["#2ca02c" if d > 0 and lo > 0 else "#7f7f7f" for d, lo in zip(diffs, [en_q["diff_ci_lo"], ja_q["diff_ci_lo"]])]
    ax2.bar(x, diffs, width=0.5, yerr=diff_errs, capsize=6, color=colors, alpha=0.85)
    ax2.axhline(0, color="black", linestyle="--", alpha=0.7)
    
    ax2.set_ylabel("ΔBPB (SmolLM - Qwen3)")
    ax2.set_title("Paired Difference ΔBPB with 95% CI (Values > 0 favor Qwen)")
    ax2.set_xticks(x)
    ax2.set_xticklabels([f"English (p={en_q['p_val']:.3f})", f"Japanese (p={ja_q['p_val']:.3f})"])
    ax2.grid(True, axis="y", ls="--", alpha=0.5)
    
    plt.tight_layout()
    out_png = os.path.join(HERE, "bpb_large_sample_paired_frontier.png")
    plt.savefig(out_png, dpi=200)
    print(f"Saved plot to {out_png}")

if __name__ == "__main__":
    run_large_sample_evaluation()
