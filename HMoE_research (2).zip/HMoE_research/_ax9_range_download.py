#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX9: 別 ckpt の重みを 128 MB の Range リクエストで分割取得する。

snapshot_download(Xet) は 0 バイトで、hf_hub_download(HTTPS) は 2 GB でハングした。
HF CDN は Range 206 を返すことを実測確認したので、1 リクエストを短く切って
再開可能に取得する。設定・tokenizer 6 ファイルは取得済み。
"""
import json
import os
import time
import urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = "allenai/OLMoE-1B-7B-0924-Instruct"
DST = os.path.join(HERE, "models", "olmoe-1b-7b-instruct")
BASE = "https://huggingface.co/%s/resolve/main/" % REPO
WEIGHTS = ["model-00001-of-00003.safetensors",
           "model-00002-of-00003.safetensors",
           "model-00003-of-00003.safetensors"]
SMALL = ["config.json", "generation_config.json", "tokenizer.json",
         "tokenizer_config.json", "special_tokens_map.json",
         "model.safetensors.index.json"]
CHUNK = 128 * 1024 * 1024
TIMEOUT = 180


def head_size(url):
    req = urllib.request.Request(url, method="HEAD")
    with urllib.request.urlopen(req, timeout=60) as r:
        assert r.status == 200, r.status
        return int(r.headers["Content-Length"])


def fetch_range(url, start, end):
    req = urllib.request.Request(url, headers={"Range": "bytes=%d-%d" % (start, end)})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as r:
        assert r.status == 206, (r.status, r.headers.get("Content-Range"))
        return r.read()


def download(name):
    url = BASE + name
    dst = os.path.join(DST, name)
    total = head_size(url)
    cur = os.path.getsize(dst) if os.path.isfile(dst) else 0
    assert cur <= total, (name, cur, total)
    print("%s  total %.2f GB  start %.2f GB" % (name, total / 1e9, cur / 1e9),
          flush=True)
    t0 = time.time()
    mode = "ab" if cur > 0 else "wb"
    with open(dst, mode) as fp:
        while cur < total:
            end = min(cur + CHUNK, total) - 1
            want = end - cur + 1
            for attempt in range(4):
                try:
                    buf = fetch_range(url, cur, end)
                    assert len(buf) == want, (len(buf), want)
                    fp.write(buf)
                    fp.flush()
                    cur += len(buf)
                    break
                except Exception as e:
                    if attempt == 3:
                        raise
                    print("  retry %d at %.2f GB: %s" %
                          (attempt + 1, cur / 1e9, str(e)[:100]), flush=True)
                    time.sleep(3)
            if (cur // CHUNK) % 4 == 0 or cur >= total:
                print("  %.2f / %.2f GB  (%.0f s)" %
                      (cur / 1e9, total / 1e9, time.time() - t0), flush=True)
    assert os.path.getsize(dst) == total, (name, os.path.getsize(dst), total)
    print("  DONE %s %.2f GB in %.0f s" %
          (name, total / 1e9, time.time() - t0), flush=True)
    return total


def main():
    os.makedirs(DST, exist_ok=True)
    for f in SMALL:
        assert os.path.isfile(os.path.join(DST, f)), "missing small file: " + f
    sizes = {f: os.path.getsize(os.path.join(DST, f)) for f in SMALL}
    for name in WEIGHTS:
        sizes[name] = download(name)
    cfg = json.load(open(os.path.join(DST, "config.json"), encoding="utf-8"))
    out = {"repo": REPO, "local_dir": DST,
           "method": "urllib_range_128MB_resumable",
           "config": {k: cfg.get(k) for k in
                      ("model_type", "num_hidden_layers", "num_experts",
                       "num_experts_per_tok", "hidden_size", "vocab_size",
                       "architectures")},
           "files": [{"name": k, "bytes": v} for k, v in sizes.items()],
           "total_bytes": sum(sizes.values())}
    with open(os.path.join(HERE, "_ax9_download.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    print("done: %.2f GB in %d files" % (out["total_bytes"] / 1e9, len(sizes)))
    print("config %s" % out["config"])


if __name__ == "__main__":
    main()
