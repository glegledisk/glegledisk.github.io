# -*- coding: utf-8 -*-
"""_md_check.py — Markdown の構文崩れを機械的に検出する。

このプロジェクトで以前踏んだ崩れ（表の列数不一致 / 連続空行 / タブ / 末尾空白 /
blockquote 内の表 / 閉じない強調記号）を一括で見る。
"""
import re
import sys

path = sys.argv[1]
with open(path, encoding="utf-8") as fh:
    lines = fh.read().split("\n")

problems = []

# --- 1. 表の列数一致 ---
i = 0
in_fence = False
while i < len(lines):
    ln = lines[i]
    if ln.strip().startswith("```"):
        in_fence = not in_fence
        i += 1
        continue
    if in_fence:
        i += 1
        continue
    if ln.lstrip().startswith("|") and i + 1 < len(lines) and re.match(
            r"^\s*\|[\s:|-]+\|\s*$", lines[i + 1]):
        sep = lines[i + 1]
        ncol = len(sep.strip().strip("|").split("|"))
        if not re.match(r"^\s*\|[\s:|-]+\|\s*$", sep):
            problems.append((i + 1, "区切り行が表の形でない", sep))
        j = i + 2
        while j < len(lines) and lines[j].lstrip().startswith("|"):
            # セル内の `\|` は区切りではない（表のセルに | を書きたいときの正しい書き方）
            body = lines[j].strip().replace("\\|", "\x00")
            n = len(body.strip("|").split("|"))
            if n != ncol:
                problems.append((j + 1, f"列数 {n} != ヘッダ {ncol}", lines[j]))
            j += 1
        i = j
        continue
    i += 1

# --- 2. 表の直前に空行があるか ---
for i, ln in enumerate(lines):
    if ln.lstrip().startswith("|") and i > 0:
        prev = lines[i - 1]
        if prev.strip() and not prev.lstrip().startswith("|"):
            problems.append((i + 1, "表の直前に空行が無い", prev[:40]))

# --- 3. 連続空行 / タブ / 末尾空白 ---
for i in range(1, len(lines)):
    if lines[i] == "" and lines[i - 1] == "":
        problems.append((i + 1, "連続空行", ""))
for i, ln in enumerate(lines):
    if "\t" in ln:
        problems.append((i + 1, "タブ", ln[:40]))
    if ln != ln.rstrip():
        problems.append((i + 1, "行末空白", ln[:40]))

# --- 4. 強調記号の対応 ---
# 行単位の偶奇チェックは**廃止**した。CommonMark では強調は複数行にまたがってよく、
# 行ごとに数えると正しい文書を大量に誤検出する（109 本中 60 本が NG になった）。
# 実際の崩れは §8 のレンダリング検査で捕まえる。


# --- 5. blockquote 内の表 ---
# `>` の後ろが `|` で始まるときだけ表の疑い。本文中の `|`（数式・記号）は誤検知。
for i, ln in enumerate(lines):
    if re.match(r"^\s*>\s*\|", ln):
        problems.append((i + 1, "blockquote 内に表", ln[:50]))

# --- 6. 見出しの階層飛び ---
prev_lv = 0
for i, ln in enumerate(lines):
    m = re.match(r"^(#{1,6})\s", ln)
    if m:
        lv = len(m.group(1))
        if prev_lv and lv > prev_lv + 1:
            problems.append((i + 1, f"見出し階層飛び h{prev_lv}->h{lv}", ln[:40]))
        prev_lv = lv

# --- 7. 末尾 ---
if lines and lines[-1] != "":
    problems.append((len(lines), "末尾に改行が無い", lines[-1][:40]))

# --- 8. レンダリング後に ** が残っていないか（強調が解釈されていない）---
# CommonMark では「閉じ括弧の直後の ** 」は閉じ記号になれない（例: 」**である）。
# ソース上の対応が取れていても、レンダリングすると記号がそのまま出る。
# ここは実際に HTML にして数えるのが唯一確実。
try:
    from markdown_it import MarkdownIt
    html = MarkdownIt("commonmark").enable("table").render("\n".join(lines))
    body = re.sub(r"<pre>.*?</pre>", "", html, flags=re.S)
    # インラインコードは**中身だけ**伏せる（タグを残す）。削除すると前後の空白が
    # CJK に隣接して偽陽性になる（A1 で 15 件出た）。
    body = re.sub(r"<code>.*?</code>", "<code>X</code>", body, flags=re.S)
    n = len(re.findall(r"\*\*", body))
    if n:
        problems.append((0, f"レンダリング後に ** が {n} 個残存", ""))
    # 日本語の軟改行が空白になっていないか。コードブロック内の整列は正常なので除く。
    cjk = re.findall(r"[\u3040-\u30ff\u4e00-\u9fff]\s+[\u3040-\u30ff\u4e00-\u9fff]", body)
    if cjk:
        problems.append((0, f"CJK 間に余計な空白が {len(cjk)} 箇所", ""))
except ImportError:
    pass

if problems:
    for ln, what, txt in problems:
        print(f"  L{ln}: {what}   | {txt}")
    print(f"\n{len(problems)} 件")
    sys.exit(1)
print(f"OK: {path} — 表の列数・空行・タブ・強調・見出しすべて整合")
