# -*- coding: utf-8 -*-
"""残った ** と CJK 空白の位置を出す。"""
import re
import sys

from markdown_it import MarkdownIt

path = sys.argv[1]
lines = open(path, encoding="utf-8").read().split("\n")
html = MarkdownIt("commonmark").enable("table").render("\n".join(lines))
body = re.sub(r"<pre>.*?</pre>", "", html, flags=re.S)
body = re.sub(r"<code>.*?</code>", "<code>X</code>", body, flags=re.S)
for m in re.finditer(r"\*\*", body):
    print("REMNANT ...%s..." % body[max(0, m.start() - 90):m.start() + 40].replace("\n", "\\n"))
for m in re.finditer(r"[\u3040-\u30ff\u4e00-\u9fff]\s+[\u3040-\u30ff\u4e00-\u9fff]", body):
    print("CJKSPACE ...%s..." % body[max(0, m.start() - 90):m.start() + 40].replace("\n", "\\n"))
