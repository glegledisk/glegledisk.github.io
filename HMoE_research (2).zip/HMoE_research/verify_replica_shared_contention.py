"""verify_replica_shared_contention.py — 細いExpertの shared/レプリカ化による競合 I の緩和検証

背景:
  HMoE では細い Expert ほど激しくトラフィックを吸う (rho(p,w) = -0.88〜-0.98)。
  その結果、計算の偏り度・競合度 I = N_slots * max(p_e * w_e) / w_bar が跳ね上がり、
  系全体の飽和スループット上限 (1/I) が律速される (H+noLB で I=4.12, ceiling=0.24)。

検証内容:
1. 既存トレース (U+LB, U+noLB, H+LB, H+noLB, H+shared) の競合度 I, ボトルネック, 飽和上限 1/I の比較
2. ホットな細いExpertの「レプリカ化 (1x, 2x, 4x)」による競合 I の緩和効果
   - レプリカ数 R_e により、スロット e の実効負荷は (p_e * w_e) / R_e となる。
3. Shared Expert化 (H+shared) によるトラフィック吸収と競合緩和の実測効果
4. M/D/1 待ち行列シミュレーションによる平均遅延・P99遅延の評価
"""

import os
import sys
import glob
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
SIM_DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
TR = os.path.join(SIM_DIR, "data", "cache_traces")

E = 8
W_MAP = {
    "U+LB": [256] * 8,
    "U+noLB": [256] * 8,
    "H+LB": [64, 64, 192, 192, 320, 320, 448, 448],
    "H+noLB": [64, 64, 192, 192, 320, 320, 448, 448],
    "H+shared": [64, 64, 192, 192, 320, 320, 448, 448], # 別途 shared_width = 256
}

def load_traces(arm, seed, task="task0"):
    fpath = os.path.join(TR, f"{arm}_s{seed}_{task}.npy")
    if not os.path.exists(fpath):
        return None
    return np.load(fpath).astype(np.int32)

def get_slot_frequencies(arm):
    ws = np.asarray(W_MAP[arm], dtype=float)
    all_hits = None
    count = 0
    
    for seed in (0, 1, 2):
        for task in ("task0", "task1", "task2"):
            tr = load_traces(arm, seed, task)
            if tr is None:
                continue
            L = tr.shape[0]
            layers = np.arange(L, dtype=np.int32) * E
            # (L, tokens, topk) -> slot ID = token + layer * E
            slot = tr + layers.reshape(-1, 1, 1)
            slot_seq = np.transpose(slot, (1, 0, 2)).reshape(-1)
            
            if all_hits is None:
                all_hits = np.zeros(L * E, dtype=np.float64)
            all_hits += np.bincount(slot_seq, minlength=L * E)
            count += 1
            
    if all_hits is None or all_hits.sum() == 0:
        return None, None
        
    p = all_hits / all_hits.sum()
    w_slot = np.tile(ws, len(p) // E)
    return p, w_slot


def evaluate_contention_and_replicas():
    arms = ["U+LB", "U+noLB", "H+LB", "H+noLB", "H+shared"]
    summary_rows = []
    
    print("=========================================================================================")
    print(f"{'Arm':10s} {'Replica':8s} {'I (競合度)':>10s} {'Ceiling 1/I':>12s} {'Bottleneck Slot':>16s} {'Slot Width':>12s} {'Traffic p':>10s}")
    print("=========================================================================================")
    
    detailed_results = {}
    
    for arm in arms:
        p, w_slot = get_slot_frequencies(arm)
        if p is None:
            print(f"Skipping {arm} (no trace)")
            continue
            
        N_slots = len(p)
        base_load = p * w_slot
        wbar = float(base_load.sum())
        
        # 1. ベースライン (レプリカなし R=1)
        I_base = N_slots * base_load.max() / wbar
        b_slot = int(np.argmax(base_load))
        ceiling_base = 1.0 / I_base
        
        summary_rows.append({
            "arm": arm,
            "policy": "Baseline (1x)",
            "replicas_hot": 1,
            "I": I_base,
            "ceiling_1_over_I": ceiling_base,
            "bottleneck_slot": b_slot,
            "bottleneck_w": int(w_slot[b_slot]),
            "bottleneck_p": float(p[b_slot]),
            "wbar": wbar
        })
        
        print(f"{arm:10s} {'1x (base)':8s} {I_base:10.3f} {ceiling_base:12.3f} {b_slot:16d} {int(w_slot[b_slot]):12d} {p[b_slot]:10.3f}")
        
        # 2. ホットExpert（負荷上位スロット）のレプリカ化 (2x, 4x)
        # 上位 2〜4 個の過負荷スロットにレプリカを割り振る
        for R in [2, 4]:
            # 最も負荷の高いスロットにレプリカ R を配置 (負荷を R で分割)
            # 複数スロット (上位2スロット) をレプリカ化
            load_rep = base_load.copy()
            top_slots = np.argsort(-load_rep)[:2] # 上位2スロット
            load_rep[top_slots] /= R
            
            I_rep = N_slots * load_rep.max() / wbar
            b_rep = int(np.argmax(load_rep))
            ceiling_rep = 1.0 / I_rep
            
            summary_rows.append({
                "arm": arm,
                "policy": f"Replica ({R}x)",
                "replicas_hot": R,
                "I": I_rep,
                "ceiling_1_over_I": ceiling_rep,
                "bottleneck_slot": b_rep,
                "bottleneck_w": int(w_slot[b_rep]),
                "bottleneck_p": float(p[b_rep]),
                "wbar": wbar
            })
            print(f"{arm:10s} {f'{R}x hot':8s} {I_rep:10.3f} {ceiling_rep:12.3f} {b_rep:16d} {int(w_slot[b_rep]):12d} {p[b_rep]:10.3f}")
            
        detailed_results[arm] = {
            "p": p.tolist(),
            "w_slot": w_slot.tolist(),
            "wbar": wbar
        }
        
    df = pd.DataFrame(summary_rows)
    out_csv = os.path.join(HERE, "contention_replica_mitigation_results.csv")
    df.to_csv(out_csv, index=False)
    print(f"\nSaved summary to {out_csv}")
    
    # M/D/1 待ち行列遅延シミュレーション
    # 到着率 lambda / mu を振ったときの平均待ち時間 (W_q = u / (2 * (1 - u)) * service_time)
    print("\n=========================================================================================")
    print("M/D/1 平均待ち時間 (ボトルネックスロット, サービス時間単位) vs 全体利用率 u")
    print("=========================================================================================")
    print(f"{'Arm':10s} {'Policy':12s} " + " ".join(f"u={u:<5.2f}" for u in [0.2, 0.4, 0.6, 0.7, 0.8]))
    
    wait_rows = []
    for r in summary_rows:
        arm = r["arm"]
        pol = r["policy"]
        I_val = r["I"]
        w_b = r["bottleneck_w"]
        
        # ボトルネックスロットの局所利用率は u_b = u * I_val
        # したがって u < 1/I_val でないと発散する
        waits = []
        for u in [0.2, 0.4, 0.6, 0.7, 0.8]:
            u_local = u * (I_val / len(W_MAP[arm])) # スロット平均に対する局所比
            # 局所利用率が 0.95 を超えたら飽和・発散
            if u * I_val >= 1.0:
                waits.append("SATURATED")
            else:
                u_eff = u * I_val
                w_q = (u_eff / (2.0 * (1.0 - u_eff))) * (w_b / 64.0) # 基準幅64単位
                waits.append(f"{w_q:6.2f}")
                
        print(f"{arm:10s} {pol:12s} " + " ".join(f"{w:>8s}" for w in waits))
        wait_rows.append({"arm": arm, "policy": pol, "waits": waits})
        
    # 可視化プロット生成
    plot_contention_comparison(df)


def plot_contention_comparison(df):
    plt.figure(figsize=(10, 6))
    
    arms = ["U+LB", "U+noLB", "H+LB", "H+noLB", "H+shared"]
    x = np.arange(len(arms))
    width = 0.25
    
    # 1x, 2x, 4x
    df_1x = df[df["policy"] == "Baseline (1x)"]
    df_2x = df[df["policy"] == "Replica (2x)"]
    df_4x = df[df["policy"] == "Replica (4x)"]
    
    # 各アームの順序を揃える
    i_1x = [df_1x[df_1x["arm"] == a]["I"].values[0] for a in arms]
    i_2x = [df_2x[df_2x["arm"] == a]["I"].values[0] for a in arms]
    i_4x = [df_4x[df_4x["arm"] == a]["I"].values[0] for a in arms]
    
    plt.bar(x - width, i_1x, width, label="1x Base (レプリカなし)", color="#d9534f", alpha=0.9)
    plt.bar(x, i_2x, width, label="2x Replica (ホット2スロット複製)", color="#f0ad4e", alpha=0.9)
    plt.bar(x + width, i_4x, width, label="4x Replica (ホット2スロット4複製)", color="#5cb85c", alpha=0.9)
    
    plt.axhline(1.0, color='black', linestyle='--', label="完全均等負荷 (I=1.0)")
    plt.ylabel("計算競合度 I (大きいほどホットExpertが全体を律速)")
    plt.title("不均一MoEにおける細いExpertのレプリカ化・Shared化による競合 I の緩和")
    plt.xticks(x, arms)
    plt.grid(True, axis='y', ls="--", alpha=0.5)
    plt.legend()
    
    plt.tight_layout()
    fig_path = os.path.join(HERE, "contention_mitigation_replica_shared.png")
    plt.savefig(fig_path, dpi=200)
    print(f"Plot saved to {fig_path}")

if __name__ == "__main__":
    evaluate_contention_and_replicas()
