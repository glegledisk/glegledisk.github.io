# -*- coding: utf-8 -*-
"""p6m_mass_by_lang.py — 質量欠落量そのものが言語で違うか

仮説（整理_P6k並行検証との関係 §追記の最有力候補）:
    ja ではルーティングが分散的で、同じ k 削減でも失う質量が小さい。
    だから ja では較正への効果が小さい。

測るもの: 各条件・各層・各トークンの「保持質量」= 選択された top-k 重みの和。
条件は base / f6b8 / f8b6 の 3 つ（rescale 条件は構成上 base と同量に戻るので不要）。

出力: p6m_mass.npz / p6m_out_utf8.txt

実行:
  python p6m_mass_by_lang.py --gpu-gib 7.5 --cpu-gib 12.0
"""

import argparse
import os
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


CONDS = [
    ("base", None),
    ("f6b8", "0-7:6,8-15:8"),
    ("f8b6", "0-7:8,8-15:6"),
]


def parse_alloc(spec, n_layers, full_k):
    ks = [full_k] * n_layers
    if not spec:
        return ks
    for part in spec.split(","):
        rng, k = part.split(":")
        k = int(k)
        if rng.strip() == "all":
            idx = range(n_layers)
        elif "-" in rng:
            a, b = rng.split("-")
            idx = range(int(a), int(b) + 1)
        else:
            idx = [int(rng)]
        for i in idx:
            ks[i] = k
    return ks


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--ids", type=str, default=os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"))
    ap.add_argument("--gpu-gib", type=float, default=7.5)
    ap.add_argument("--cpu-gib", type=float, default=12.0)
    ap.add_argument("--max-windows", type=int, default=0)
    args = ap.parse_args()

    import torch
    from transformers import AutoModelForCausalLM

    log("[1/3] loading %s" % args.model)
    t0 = time.time()
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      loaded in %.0f s" % (time.time() - t0))

    n_layers = int(model.config.num_hidden_layers)
    FULL_K = int(model.config.num_experts_per_tok)
    gates = [layer.mlp.gate for layer in model.model.layers]

    kept = []

    def mk_hook():
        def hook(module, inp, out):
            kept.append(out[1].detach().float().sum(-1).cpu())
        return hook

    handles = [g.register_forward_hook(mk_hook()) for g in gates]

    z = np.load(args.ids, allow_pickle=True)
    seqs = []
    for lang in ("en", "ja"):
        ids = torch.from_numpy(z["%s_ids" % lang].astype(np.int64))
        for w in range(ids.numel() // 256):
            seqs.append((lang, ids[w * 256:(w + 1) * 256]))
    if args.max_windows:
        seqs = seqs[:args.max_windows]
    log("[2/3] frozen corpus: %d windows x 256" % len(seqs))

    store = {}
    log("[3/3] forward")
    t1 = time.time()
    for name, spec in CONDS:
        ks = parse_alloc(spec, n_layers, FULL_K)
        for i, g in enumerate(gates):
            g.top_k = ks[i]
        kept.clear()
        with torch.no_grad():
            for lang, ids in seqs:
                x = ids.unsqueeze(0).to(model.device)
                model(input_ids=x, use_cache=False)
                torch.cuda.empty_cache()
        K = torch.stack(kept[-n_layers * len(seqs):]).numpy()   # (windows*layers, T)
        # kept はウィンドウ順に 16 層ずつ積まれる（window-major）
        K = K.reshape(len(seqs), n_layers, -1)                  # (windows, layers, T)
        store[name] = K
        log("      %-5s ks=%s  kept_mass 全体 %.4f  (%.0f s)"
            % (name, "".join(str(k) for k in ks), float(K.mean()), time.time() - t1))

    for h in handles:
        h.remove()

    # (windows, layers, T) -> (layers, tokens)
    out = {"lang": np.array([s[0] for s in seqs])}
    for name in store:
        K = store[name].transpose(1, 0, 2).reshape(n_layers, -1)
        out[name] = K.astype(np.float32)
    np.savez_compressed(os.path.join(HERE, "p6m_mass.npz"), **out)
    with open(os.path.join(HERE, "p6m_out_utf8.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(LOG))
    log("saved p6m_mass.npz  shape=(layers, tokens)")
    import sys
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
