# QA1S4 課題設計書: 補完 gain と重複なし random で幅実験を再走する

- 日付: 2026-11-16（`検証報告_QA1S3S1_未選択キー補完は無侵襲で21run全て32個に確定しrandom発散はtopi重複に絞れた_20261115.md` §3〜§4 と `.workbuddy-ai/memory/2026-11-15.md` の次の一手）
- ステータス: **走行前設計確定**。校正・実装比較に合格した場合だけ 21 run を起動する
- 区分: **QA1S4**。QA1S3 のケース I を受けた別 ID。QA1S2 の既存報告は書き換えない
- 関連: QA1S3 / QA1S2 の設計書・報告書、`qa1s2_run.py`、`qa1s2_policy.py`、`a4_small_expert_act.py`、`a1_activation_ffn.py`、`AGENTS.md` §3 / §7 / §8
- 出力: 本設計書、校正成果物、21 run の再測定成果物と別報告書

---

## 0. 問い

QA1S3 は既存 `gain.by_position` の欠損 1 キーを既定値 `1.0` で補完しても実効 gain が変わらず、`random` の `topi` 重複率 `0.124839` が理論値 `1/8` と一致すると報告した。本次ではこの2点を新 ID の走行前修正として実装し、QA1S2 と同一の幅 estimand を再測定する。

## 1. 走行前に固定する変更と不変量

1. `a4_small_expert_act.run_one` の `gain="matched"` で作った `gl` を、学習開始前に `gl_full[(l,i)] = gl.get((l,i), 1.0)`（全 4×8=32 key）へ明示展開する。`model.gain_l` と `gain_info.by_position` に適用する。`n/min/max/mean/by_expert` は既存の `gl` から計算し、学習時の実効値は従来 `.get(key,1.0)` と同一にする。
2. random policy は各 token で E=8 から k=2 個を**非復元抽出**する。iid score の行ごとの argsort 上位 k を使い、`topi` の重複を禁止する。選択 expert の router weight は従来 `gate_of` で計算し、random は評価時のみ。
3. 幅・活性化・学習・主 estimand は QA1S2 と同一: `w_ref=(32,32,96,96,160,160,224,224)`、`w_mid=(96,96,96,96,160,160,160,160)`、`w_flat=(128,)*8`、`relu2`、matched gain、seed `0..6`、6 epoch、`lr=0.002`、`bs=32`、`auxw=0.05`、3,000 train sequences。
4. 確認的 estimand は `Δ_iv = mean_seed[iv(w_mid) − iv(w_ref)]`。腕ごとの `iv` は学習内 eval の末尾 3 epoch 中央値。`ttest_rel`、両側 `α=0.05`、Holm `m=1`、`n=7`、`MDE=t.ppf(.975,6)×se`、90% CI。`w_flat` は探索的比較として保存する。
5. eval は既定 seed 777 の 1,024 系列。同一 checkpoint / 同一 token で learned, uniform, random, oracle を再評価する。P4 の random expert 使用率偏差は N=1,024 で測る。

## 2. 実行前 gate

### C1〜C6（QA1S2 の再固定値）

| ID | 観測 | 合格条件 |
|---|---|---|
| C1 | `all_relu2` gain 集計と A4b 保存 `all_relu2_s0_g.json`、既定 `run_one` 挙動 | maxdiff `<1e-9`、既存 evals は bit-identical |
| C2 | 各 run の `gain.by_position` key 数・有限性・欠損 | 21 run 全て 32 key、非有限 0、欠損 0 |
| C3 | 腕ごとの幅和 | すべて 1024、w_ref / w_mid 差 0 |
| C4 | 腕位置の対称差・収束分類 | 対称差 0、T±×E± 分類漏れ 0、除外 0 |
| C5 | 学習後 3 点対照の `instr_valid(random) ≤ instr_valid(oracle)` | 全 run で成立。ただし P1〜P6 が有情報なことも確認 |
| C6 | 全出力の有限性 | 非有限 0、JSON `allow_nan=False` |

### C5 の情報量校正 P1〜P6（QA1S3 から継承）

| ID | 観測 | 合格条件 |
|---|---|---|
| P1 | 3 policy 間 `first_logits` pair maxdiff | すべて `>0` |
| P2 | oracle の型・expert 割当一致 | `1.0` |
| P3 | uniform の expert coverage | 8/8 |
| P4 | random 使用率最大相対偏差（1,024 系列） | `<0.05` |
| P5 | policy 別 `ce_all` | 全 finite、`≤10×ln(17)=28.332` |
| P6 | 全 policy の床 / 天井張り付き | 全て張り付きなら `uninformative=true` とし合格扱いしない |

P1〜P6 のどれかが不合格、または 21 run のいずれかで P5 が不合格なら confirmatory verdict を停止し、数値は参考記録に限る。P4 の閾値は系列数を増やす設計を走行前に固定した値である。

## 3. 同一 checkpoint 評価の切り分け（C7）

QA1S3 が挙げた `iv_main=0` と learned 再評価の非床を、末尾 3 epoch の中央値と最終 checkpoint の混同から分離する。各 run で次を同じ seed 777 / 1,024 系列に対して比較する。

- 学習内 epoch 6 の `evaluate` 指標と、同じ最終 `model.p` を `PolicyActMoE(policy="learned")` で再評価した `ce_all` / `instr_valid`。
- `max_abs_diff(ce_all, instr_valid) ≤ 1e-6` を C7 合格条件とする。あわせて末尾 3 epoch 中央値 `iv_main` と epoch 6 の値を別々に保存する。
- C7 が不合格なら原因を `evaluate` / policy forward / 入力 batch のどれかに切り分けるまで主検定の判定を保留する。中央値と最終値の差だけなら実装差と呼ばない。

## 4. 分析と停止条件

主検定は一つだけで多重性補正不要（Holm m=1）。NPZ から paired 差を再計算し、`Δ / se / t / p / n / MDE / 90% CI`、seed ごとの差、中央値、最大絶対差、上位 1% 寄与率を報告する。平均差を「改善」と呼ぶのは検定条件を満たす場合だけ。

学習後 C5 で停止となった場合も 21 run 全てを保存し、confirmatory 判定は出さない。床モードの腕間比率検定は追加しない。QA1S2 の `Δ_iv` は本次の主判定と混ぜず、再走の再現性を調べる参照値に限る。

## 5. 出力・制約

- `qa1s4_metrics.json` / `qa1s4_delta.npz` / `qa1s4.log` / `data/a4/*_qa1s4prod.json` / `_qa1s4_verify.json`。
- `qa1s2_*` / `qa1s3_*` 既存成果物を上書きしない。
- 7 seed・1 testbed・1 model / harness。P5 の CE 上限は実装破損を見つける桁の閾値で、policy の優位性を保証しない。
- 保留 1 と Z1 §4 規則 3 は維持。既存 `.md` は書き換えず、状態は `## 追記` で残す。

## 6. 実行順

1. `run_one` gain 補完・random 非復元抽出を S4 で実装する。
2. 1 run smoke で 32 key / 無侵襲 gain / random duplicate 0 / eval 経路一致を確認する。
3. C1〜C7 が通った場合だけ 21 run を順次実行する。
4. 独立 verifier で JSON / NPZ から主統計と C1〜C7 を再計算し、報告書・memory に記録する。

## 7. 再現

```powershell
$p = "C:\Users\gochu\.workbuddy-ai\binaries\python\envs\gpu\Scripts\python.exe"
$wd = "C:\Users\gochu\WorkBuddy AI\不均一MoE"
$env:PYTHONIOENCODING = "utf-8"
Set-Location $wd
& $p "qa1s4_run.py"
& $p "_qa1s4_verify.py"
& $p "_md_check.py" "$wd\検証報告_QA1S4S1_補完gainと重複なしrandomの再走でC1-C7を判定_20261116.md"
```

**実装メモ**: `gl_full` の summary は補完前の `gl` から計算し、by_position だけ 32 key にする。random は各 token 別に iid score を作って行ごとに rank 付けし、`replace=False` を実装する。最後の epoch 指標と tail3 median は別の配列として保存する。

## 追記（2026-11-16）: 長時間 run の中断再開

QA1S4 smoke は 1 run 277.5 秒だった（`qa1s4_s1_smoke_metrics.json` / `.log`）。21 run の逐次実行が長時間になるため、本番 runner は各完了 run の JSON / NPZ を `qa1s4_cache/` に保存し、学習条件を含む署名が一致した run だけ再利用する。`qa1s4_partial_metrics.json` は進捗確認用で、最終解析は全 21 run の一次出力から作り直す。estimand・閾値・seed・学習条件は変更しない。

## 追記（2026-11-16）: 21 run 完了、C5-P6 で確認的判定を停止

- smoke は C1〜C7 pass。production は 3 arm × 7 seed = 21 run を完了し、C1〜C4・C6・C7 pass、C5 の P6 のみ `w_mid seed=2` で fail（4 policy とも `instr_valid=0`）。確認的 verdict は停止。
- paired 主 estimand の再計算値は `Δ=-0.07393973`, `se=0.21085650`, `t=-0.35066375`, `p=0.73782398`, `n=7`, `MDE=0.51594728`, 90% CI `[-0.48367193,+0.33579247]`。C5 fail のため参考値として扱う。上位 1% の寄与は 34.94%、最大絶対 seed 差は 0.921875。
- gain map は 21 run 全て 32 key、random duplicate rate は 0、P4 最大相対偏差は 0.02730791。C7 の final eval / learned policy 再評価差は CE / IV とも最大 0。
- `_qa1s4_verify.py` の初回実行は primary delta を別 archive から読む箇所で KeyError になった。`qa1s4_delta.npz` を参照するよう修正し再実行、主統計・配列の不一致 0。verifier 全体の `FAIL` は予定どおり C5 gate fail による。
- 詳細は `検証報告_QA1S4S1_補完gainと重複なしrandomは再現したがC5がseed2の床張り付きで停止_20261116.md`。
