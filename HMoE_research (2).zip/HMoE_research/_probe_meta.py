# -*- coding: utf-8 -*-
"""_probe_meta.py — どこが meta に落ちたかの確認（使い捨て）"""
import os
import sys

import torch
from transformers import AutoModelForCausalLM

M = os.path.join(os.path.dirname(os.path.abspath(__file__)), "models", "olmoe-1b-7b")
model = AutoModelForCausalLM.from_pretrained(
    M, torch_dtype=torch.bfloat16, device_map="auto",
    max_memory={0: "7.5GiB", "cpu": "8.0GiB"},
).eval()

def stat(name, t):
    print("%s: device=%s meta=%s" % (name, t.device, t.is_meta))

stat("lm_head.weight", model.lm_head.weight)
stat("embed_tokens.weight", model.model.embed_tokens.weight)
logits_ok = str(model.lm_head).count("tied") if False else None

n_meta = 0
n_mod = 0
for name, mod in model.named_modules():
    n_mod += 1
    for pn, p in mod.named_parameters(recurse=False):
        if p.is_meta:
            n_meta += 1
            print("  META: %s.%s" % (name, pn))
print("modules=%d meta_params=%d" % (n_mod, n_meta))

# forward 1 回で logits が本物か確認
x = torch.tensor([[1, 2, 3]]).to(model.device)
with torch.no_grad():
    out = model(input_ids=x, use_cache=False)
print("logits.shape=%s finite=%s" % (tuple(out.logits.shape), bool(out.logits.isfinite().all())))
print("tied=%s" % getattr(model.config, "tie_word_embeddings", None))
sys.stdout.flush()
os._exit(0)
