# -*- coding: utf-8 -*-
"""AX10: shift 抽選を S=20 に増やして N=102 平坦区間の分解能を上げる。

設計書: AX10課題設計書_shift抽選20回でN102平坦区間の分解能を上げる_20261114.md
（走行前に estimand・腕・校正・検定族・判定ケースを凍結）

AX7 と同一コーパス・同一 c8/c7・同一 u7。
新規 forward = 38 本（36 shift + 2 校正）、AX7 から 4 本（shift 7201/7202 × 2N）を再利用。

実行:
  python ax10_shift_avg.py --dry-run
  python ax10_shift_avg.py --smoke --tag ax10smoke
  python ax10_shift_avg.py --tag ax10
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ax2_layer_cost import paired, holm  # noqa: E402

N_LAYERS = 16
ALPHA = 0.05
S_FULL = 20
SEED_BASE = 7201  # seed 7201..7220
AX3_CORPUS = os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz")
AX4_NPZ = os.path.join(HERE, "ax4_sentence_bound.npz")
AX5_NPZ = os.path.join(HERE, "ax5_granularity_mech.npz")
AX7_NPZ = os.path.join(HERE, "ax7_plateau.npz")
DESIGN = "AX10課題設計書_shift抽選20回でN102平坦区間の分解能を上げる_20261114.md"

TEE = None


def log(msg):
    print(msg, flush=True)
    if TEE is not None:
        TEE.write(msg + "\n")
        TEE.flush()


# ---------------------------------------------------------------- partitions
def group_units(sid, k, n_win, n_eval):
    out = np.zeros_like(sid)
    off = 0
    for w in range(n_win):
        sl = slice(w * n_eval, (w + 1) * n_eval)
        sw = sid[sl]
        lo = sw - sw.min()
        out[sl] = off + lo // k
        off = int(out[sl].max()) + 1
    return out


def lengths_to_uid(lens):
    return np.repeat(np.arange(len(lens), dtype=np.int32), lens).astype(np.int32)


def uniform_lengths(n_unit, total):
    q, r = divmod(total, n_unit)
    ls = np.full(n_unit, q, dtype=np.int64)
    ls[:r] += 1
    return ls


def unit_targets(c8, c7, uid, n_unit):
    cnt = np.bincount(uid, minlength=n_unit).astype(np.float64)
    assert cnt.min() > 0, "empty unit"
    a = np.stack([np.bincount(uid, weights=c8[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    b = np.stack([np.bincount(uid, weights=c7[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    return np.concatenate([a, b], axis=1)


def unit_decision(Y):
    cut = np.argmin(Y[:, N_LAYERS:], axis=1).astype(np.int8)
    Q = Y[:, :N_LAYERS].copy()
    Q[np.arange(Y.shape[0]), cut] = -np.inf
    prot = np.argmax(Q, axis=1).astype(np.int8)
    assert (cut != prot).all(), "cut == protect"
    return cut, prot


def kmat_from_units(uid, cut, prot, n_tok):
    km = np.full((N_LAYERS, n_tok), 7, dtype=np.int8)
    for u in range(len(cut)):
        sel = (uid == u)
        km[cut[u], sel] = 6
        km[prot[u], sel] = 8
    return km


def to_windows(kmat_eval, nw, n_eval, ln, pad_val=7):
    km = kmat_eval.reshape(N_LAYERS, nw, n_eval)
    km = np.concatenate([km, np.full((N_LAYERS, nw, 1), pad_val, dtype=np.int8)], axis=2)
    return km.reshape(N_LAYERS, nw * ln)


def split_stats(uid):
    ls = np.bincount(uid).astype(np.float64)
    sh = ls / ls.sum()
    return {"N": int(ls.size), "mean_len": float(ls.mean()),
            "cv": float(ls.std(ddof=1) / ls.mean()) if ls.size > 1 else 0.0,
            "min": float(ls.min()), "max": float(ls.max()),
            "eff_units": float(1.0 / (sh ** 2).sum())}


def assert_finite(obj, path="root"):
    bad = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            bad += assert_finite(v, path + "/" + str(k))
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            bad += assert_finite(v, path + "/%d" % i)
    elif isinstance(obj, (float, np.floating)) and (np.isnan(obj) or np.isinf(obj)):
        bad.append(path)
    return bad


def load_ax3(n_win, ln, en_only=False):
    z = np.load(AX3_CORPUS, allow_pickle=True)
    seqs = []
    langs = ("en",) if en_only else ("en", "ja")
    for lg in langs:
        n_lg = 2 * n_win if en_only else n_win
        ids = torch.from_numpy(z[lg + "_ids"].astype(np.int64)[:n_lg * ln])
        assert ids.numel() >= n_lg * ln
        for w in range(n_lg):
            seqs.append((lg, ids[w * ln:(w + 1) * ln]))
    return seqs


# ---------------------------------------------------------------- main
def main():
    global TEE
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--tag", type=str, default="ax10")
    args = ap.parse_args()
    tag = args.tag
    smoke = args.smoke
    S = 4 if smoke else S_FULL
    TEE = open(os.path.join(HERE, "%s_out_utf8.txt" % tag), "w", encoding="utf-8")

    n_win = 3 if smoke else args.windows
    ln, n_eval = args.len, args.len - 1
    nw, n_tok = 2 * n_win, 2 * n_win * n_eval
    log("AX10: S=%d  nw=%d  n_tok=%d  tag=%s  smoke=%s" % (S, nw, n_tok, tag, smoke))

    # ---- 保存配列 ----
    log("[1] saved arrays")
    z4 = np.load(AX4_NPZ)
    z7 = np.load(AX7_NPZ)
    c8 = z4["c8"][:, :n_tok].astype(np.float64)
    c7 = z4["c7"][:, :n_tok].astype(np.float64)
    assert c8.shape == (N_LAYERS, n_tok)
    sent = z4["sent"].astype(np.int64)[:n_tok].copy()
    _, sent = np.unique(sent, return_inverse=True)
    sent = sent.astype(np.int64)
    u7_saved = z4["nll_u7_rep"][:n_tok].astype(np.float64)
    base_saved = z4["nll_base_rep"][:n_tok].astype(np.float64)

    # 既存参照腕（AX4/AX5/AX7 の保存 NLL）
    def saved_arr(z, key):
        return z[key][:n_tok].astype(np.float64)

    N = {"u7": u7_saved}
    # sent4, sent2, uni102, uni181, sent_random, tok12240
    N["sent4"] = saved_arr(z4, "nll_sent4_oracle")
    N["sent2"] = saved_arr(z4, "nll_sent2_oracle")
    N["sent_random"] = saved_arr(z4, "nll_sent_random")
    z5 = np.load(AX5_NPZ)
    N["uni102"] = saved_arr(z5, "nll_uni102")
    N["uni181"] = saved_arr(z5, "nll_uni181")
    z3 = np.load(os.path.join(HERE, "ax3_transfer.npz"))
    N["tok12240"] = saved_arr(z3, "nll_lay_tok_oracle")

    # AX7 の shift（seed 7201, 7202）を再利用
    for old_name, new_name in (("nll_shift102", "shift102_s01"),
                                ("nll_shift102b", "shift102_s02"),
                                ("nll_shift181", "shift181_s01"),
                                ("nll_shift181b", "shift181_s02")):
        if old_name in z7:
            N[new_name] = z7[old_name][:n_tok].astype(np.float64)
            log("    reused %s -> %s  CE %.5f" % (old_name, new_name, N[new_name].mean()))

    for k, v in N.items():
        assert v.shape == (n_tok,), k

    # ---- 分割構築 ----
    log("[2] partitions (S=%d)" % S)
    sent4 = group_units(sent, 4, nw, n_eval).astype(np.int32)
    sent2 = group_units(sent, 2, nw, n_eval).astype(np.int32)

    multi_102 = np.bincount(sent4)
    multi_181 = np.bincount(sent2)
    sorted_102 = np.sort(multi_102)
    sorted_181 = np.sort(multi_181)

    # Build all S shift partitions and their decisions
    parts = {}  # name -> uid
    decs = {}   # name -> (cut, prot)
    mask_arms = []  # (name, kmat_windows)

    for s_idx in range(S):
        seed = SEED_BASE + s_idx
        for N_val, multi, sorted_m, prefix in ((102, multi_102, sorted_102, "shift102"),
                                                (181, multi_181, sorted_181, "shift181")):
            nm = "%s_s%02d" % (prefix, s_idx + 1)
            ls = np.random.default_rng(seed).permutation(multi)
            assert np.array_equal(np.sort(ls), sorted_m), "C2 multiset FAIL: %s" % nm
            uid = lengths_to_uid(ls)
            assert uid.shape == (n_tok,), nm
            assert np.array_equal(np.unique(uid), np.arange(uid.max() + 1)), nm
            assert np.bincount(uid).min() >= 1, nm
            parts[nm] = uid

            # Decision
            Y = unit_targets(c8, c7, uid, int(uid.max()) + 1)
            cut, prot = unit_decision(Y)
            decs[nm] = (cut, prot)

            # Only build mask for arms that need forward (skip AX7-reused in dry-run check)
            km = to_windows(kmat_from_units(uid, cut, prot, n_tok), nw, n_eval, ln, 7)
            mk = float(km.mean())
            assert abs(mk - 7.0) < 1e-9, "C3 mean_k FAIL: %s = %f" % (nm, mk)
            mask_arms.append((nm, km))

    log("    %d shift arms built. C2 multiset OK. C3 mean_k OK." % len(mask_arms))

    # Also build sent4/sent2/uni102/uni181 partitions for reference
    parts_ref = {"sent4": sent4, "sent2": sent2,
                 "uni102": lengths_to_uid(uniform_lengths(102, n_tok)),
                 "uni181": lengths_to_uid(uniform_lengths(181, n_tok))}

    # C5: cut != protect (already asserted in unit_decision)
    conflicts = {nm: int((c == p).sum()) for nm, (c, p) in decs.items()}
    assert all(v == 0 for v in conflicts.values()), "C5 cut == protect"

    if args.dry_run:
        log("    dry-run OK (no model, no forward). %d arms, C2/C3/C5 passed." % len(mask_arms))
        TEE.close()
        return

    # ---- 校正用参照 (C2) ----
    c2 = {"n_tok": int(n_tok), "n_win": int(nw), "S": S,
           "multiset_all_ok": True, "coverage_bad": 0}

    # ---- モデル ----
    log("[3] load model")
    t0 = time.time()
    from transformers import AutoModelForCausalLM, AutoTokenizer
    AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    full_k = int(model.config.num_experts_per_tok)
    assert full_k == 8 and int(model.config.num_hidden_layers) == N_LAYERS
    gates = [l.mlp.gate for l in model.model.layers]
    gate_fwd = [g.forward for g in gates]
    seqs = load_ax3(n_win, ln, en_only=smoke)
    assert len(seqs) == nw
    log("    %.0f s  (%d windows)" % (time.time() - t0, nw))

    STATE = {"kmat": None}

    def make_masked(orig, li):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            km = STATE["kmat"]
            if km is not None and scores.shape[-1] == full_k:
                kk = km[li]
                if kk.numel() == scores.shape[0]:
                    ar = torch.arange(scores.shape[-1], device=scores.device,
                                      dtype=torch.float32)
                    scores = scores * (ar[None, :] < kk[:, None]).to(scores.dtype)
            return logits, scores, idx
        return _patched

    for i, g in enumerate(gates):
        g.forward = make_masked(gate_fwd[i], i)

    cache_dir = os.path.join(HERE, "_ax10_cache_%s" % tag)
    os.makedirs(cache_dir, exist_ok=True)

    def run_eval(name, native_topk=None, kmat_windows=None):
        cf = os.path.join(cache_dir, name + ".npz")
        if os.path.exists(cf):
            c = np.load(cf)
            log("    %-20s CACHED CE %.5f" % (name, float(c["nll"].mean())))
            return c["nll"].astype(np.float64)
        t1 = time.time()
        if kmat_windows is not None:
            for g in gates:
                g.top_k = full_k
        else:
            STATE["kmat"] = None
            for g in gates:
                g.top_k = int(native_topk)
        nll_c = []
        with torch.no_grad():
            for wi, (lg, ids) in enumerate(seqs):
                if kmat_windows is not None:
                    STATE["kmat"] = torch.from_numpy(
                        kmat_windows[:, wi * ln:(wi + 1) * ln].astype(np.float32)
                    ).to(model.device)
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                logit = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(logit, tgt, reduction="none")
                nll_c.append(nll.cpu().numpy())
                del out, logit
        STATE["kmat"] = None
        nll = np.concatenate(nll_c).astype(np.float32)
        np.savez_compressed(cf, nll=nll)
        log("    %-20s CE %.5f  (%.0f s)" % (name, nll.mean(), time.time() - t1))
        return nll.astype(np.float64)

    # ---- 校正 forward ----
    log("[4] calibration forwards")
    N["base_rep"] = run_eval("base_rep", native_topk=full_k)
    N["u7_rep"] = run_eval("u7_rep", native_topk=7)

    # C1
    bd = float(np.abs(N["base_rep"] - base_saved).max())
    ud = float(np.abs(N["u7_rep"] - u7_saved).max())
    c1 = {"base_maxdiff": bd, "u7_maxdiff": ud,
           "tier": "A" if bd == 0.0 and ud == 0.0 else "FAIL",
           "scope": "smoke_en6" if smoke else "full_48"}
    log("    C1: base_maxdiff=%.1e  u7_maxdiff=%.1e  tier=%s" % (bd, ud, c1["tier"]))

    # ---- shift forward ----
    log("[5] shift forwards (S=%d × 2 N-bands)" % S)
    n_new = 0
    for nm, km in mask_arms:
        if nm not in N:
            N[nm] = run_eval(nm, kmat_windows=km)
            n_new += 1
        else:
            log("    %-20s already loaded from AX7" % nm)
    log("    %d new forwards completed" % n_new)

    # ---- 統計 ----
    log("[6] stats / confirmatory")
    u7 = N["u7"]

    # Per-arm gains
    gains = {}
    for nm in list(N):
        if nm in ("u7", "base_rep", "u7_rep"):
            continue
        gains[nm] = paired(u7 - N[nm], nw, n_eval)

    # S-draw statistics
    g_draws_102 = np.array([gains["shift102_s%02d" % (s + 1)]["mean"] for s in range(S)])
    g_draws_181 = np.array([gains["shift181_s%02d" % (s + 1)]["mean"] for s in range(S)])
    draw_stats_102 = {"mean": float(g_draws_102.mean()), "sd": float(g_draws_102.std(ddof=1)),
                       "min": float(g_draws_102.min()), "max": float(g_draws_102.max()),
                       "range": float(g_draws_102.max() - g_draws_102.min()),
                       "values": g_draws_102.tolist()}
    draw_stats_181 = {"mean": float(g_draws_181.mean()), "sd": float(g_draws_181.std(ddof=1)),
                       "min": float(g_draws_181.min()), "max": float(g_draws_181.max()),
                       "range": float(g_draws_181.max() - g_draws_181.min()),
                       "values": g_draws_181.tolist()}

    # Per-token average NLL across S shifts
    nll_shift_avg_102 = np.mean([N["shift102_s%02d" % (s + 1)] for s in range(S)], axis=0)
    nll_shift_avg_181 = np.mean([N["shift181_s%02d" % (s + 1)] for s in range(S)], axis=0)
    assert nll_shift_avg_102.shape == (n_tok,)
    assert nll_shift_avg_181.shape == (n_tok,)

    # Confirmatory: Holm m=2, P1 length, P2 alignment (N=102 only)
    d_p1 = N["uni102"] - nll_shift_avg_102  # positive if shift_avg better than uni
    d_p2 = nll_shift_avg_102 - N["sent4"]   # positive if sent4 better than shift_avg
    st = {"P1_length": paired(d_p1, nw, n_eval),
          "P2_alignment": paired(d_p2, nw, n_eval)}
    ph = holm({k[:2]: v["p_two"] for k, v in st.items()})
    rej = {k: bool(v < ALPHA) for k, v in ph.items()}
    if rej["P1"] and rej["P2"]:
        case = "C"
    elif rej["P1"]:
        case = "A"
    elif rej["P2"]:
        case = "B"
    else:
        case = "D"

    # Exploratory: N=181 version
    d_p1_181 = N["uni181"] - nll_shift_avg_181
    d_p2_181 = nll_shift_avg_181 - N["sent2"]
    st_181 = {"P1_length_181": paired(d_p1_181, nw, n_eval),
              "P2_alignment_181": paired(d_p2_181, nw, n_eval)}

    # Exploratory: 2-component decomposition
    G_shiftmean102 = float((u7 - nll_shift_avg_102).mean())
    G_shiftmean181 = float((u7 - nll_shift_avg_181).mean())
    G_sent4 = gains["sent4"]["mean"]
    G_sent2 = gains["sent2"]["mean"]
    G_uni102 = gains["uni102"]["mean"]
    G_uni181 = gains["uni181"]["mean"]

    decomp_102 = {"total": G_sent4 - G_uni102,
                   "alignment": G_sent4 - G_shiftmean102,
                   "length": G_shiftmean102 - G_uni102}
    decomp_181 = {"total": G_sent2 - G_uni181,
                   "alignment": G_sent2 - G_shiftmean181,
                   "length": G_shiftmean181 - G_uni181}

    # Flat indicators
    F_sent = G_sent2 - G_sent4
    F_shiftmean = G_shiftmean181 - G_shiftmean102

    # Cross-N correlation
    from scipy.stats import spearmanr
    rho_cross, p_cross = spearmanr(g_draws_102, g_draws_181)
    rho_cross = float(rho_cross) if np.isfinite(rho_cross) else 0.0

    # C6
    gr = gains["sent_random"]["mean"]
    go = gains["tok12240"]["mean"]
    c6 = {"random_gain": gr, "oracle_gain": go, "random_le_oracle": bool(gr <= go)}

    # C7: sd_draw
    c7_out = {"sd_draw_102": draw_stats_102["sd"], "sd_draw_181": draw_stats_181["sd"],
              "ax7_2pt_sigma_102": 0.001706, "ax7_2pt_sigma_181": 0.000309,
              "judgement": "record_only"}

    # Compile calibration
    calib = {"C1": c1, "C2": c2,
             "C3": {"mean_k_all_ok": True,
                    "n_bad": 0},
             "C4": {"slots_per_token": 112, "n_bad": 0},
             "C5": {"conflicts_sum": sum(conflicts.values())},
             "C6": c6, "C7": c7_out}

    # Split stats for each shift arm
    sstats = {}
    for nm, uid in parts.items():
        sstats[nm] = split_stats(uid)

    exploratory = {
        "draw_stats_102": draw_stats_102,
        "draw_stats_181": draw_stats_181,
        "decomposition_N102": decomp_102,
        "decomposition_N181": decomp_181,
        "flat": {"F_sent": F_sent, "F_shiftmean": F_shiftmean,
                 "F_ax7_reference": 0.00004482},
        "N181_tests": st_181,
        "cross_N_spearman": {"rho": rho_cross, "p": float(p_cross) if np.isfinite(p_cross) else 1.0},
        "G_shiftmean102": G_shiftmean102,
        "G_shiftmean181": G_shiftmean181,
        "split_stats_sample": {nm: sstats[nm] for nm in list(sstats)[:4]},
    }

    out = {
        "meta": {"tag": tag, "smoke": bool(smoke), "windows": int(nw), "len": ln,
                 "n_tok": int(n_tok), "S": S, "seed_base": SEED_BASE,
                 "n_new_forwards": n_new + 2,  # shift + calibration
                 "n_total_arms": len(gains), "design": DESIGN},
        "confirmatory": dict(st, holm=ph, reject=rej, case=case),
        "calib": calib, "gains": {k: v for k, v in gains.items()
                                   if k in ("sent4", "sent2", "uni102", "uni181",
                                            "sent_random", "tok12240") or k.startswith("shift")},
        "exploratory": exploratory,
    }
    bad = assert_finite(out)
    assert not bad, "非有限値が JSON に混入: %s" % bad[:8]

    log("[7] save")
    with open(os.path.join(HERE, "%s_shift_avg.json" % tag), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2, allow_nan=False)

    save = {}
    for k, v in N.items():
        save["nll_" + k] = v.astype(np.float64)
    save["nll_shift_avg_102"] = nll_shift_avg_102
    save["nll_shift_avg_181"] = nll_shift_avg_181
    save["c8"] = c8
    save["c7"] = c7
    save["sent"] = sent.astype(np.int32)
    for nm, uid in parts.items():
        save["uid_" + nm] = uid
        save["cut_" + nm] = decs[nm][0]
        save["prot_" + nm] = decs[nm][1]
    np.savez_compressed(os.path.join(HERE, "%s_shift_avg.npz" % tag), **save)

    log("== confirmatory (Holm m=2, alpha=0.05, N=102) ==")
    for k, v in st.items():
        log("%-14s %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
            % (k, v["mean"], v["t"], v["p_two"], ph[k[:2]], v["mde"]))
    log("case = %s" % case)
    log("decomp N102 total %+.8f (align %+.8f + length %+.8f)" %
        (decomp_102["total"], decomp_102["alignment"], decomp_102["length"]))
    log("decomp N181 total %+.8f (align %+.8f + length %+.8f)" %
        (decomp_181["total"], decomp_181["alignment"], decomp_181["length"]))
    log("draw sd: N102=%.6f  N181=%.6f  (AX7 2pt: 0.001706 / 0.000309)" %
        (draw_stats_102["sd"], draw_stats_181["sd"]))
    log("C1 %s  C6 %s  C7 sd_102=%.6f sd_181=%.6f" %
        (c1["tier"], c6["random_le_oracle"],
         draw_stats_102["sd"], draw_stats_181["sd"]))
    log("saved: %s_shift_avg.npz / .json" % tag)
    TEE.close()
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
