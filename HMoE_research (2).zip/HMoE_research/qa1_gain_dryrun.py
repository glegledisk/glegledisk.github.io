# -*- coding: utf-8 -*-
"""QA1 Step 1: `gain[(l, i)]` の保存と C1〜C4 / C6 の dry-run.

設計書: `QA1課題設計書_保留8は二重に消化済みで残る位置固定幅操作1腕でQA同一性を検定する_20261114.md`
        §4（腕）/ §6（校正）/ §9（Step 1）

本次の範囲
  - `a4_small_expert_act.py --gain matched` に `gain.by_position` を 1 項目足した（後方互換）。
  - 3 腕の `gain[(l, i)]` を実測して保存し、C1〜C4 / C6 を校正する。
  - **本番学習（6 epoch × 7 seed）は一切走らせない**。校正用 forward と `epochs=0` の
    `run_one` 1 回だけ。確認的検定 `Δ_iv` も 3 点対照（C5）も未実施。

走行前に固定する観測統計量と閾値（設計書 §6 を数値化）
  C1a `all_relu` の gain と 1.0 の maxdiff            < 1e-9
  C1b 本次 `all_relu2` の gain 集計と A4b 保存値      < 1e-9（by_expert は 4 桁丸めで 5e-5）
  C1c A4 raw と A4b gain-matched の `evals` maxdiff    < 1e-9
  C2  `gain[(l,i)]` が 32 個・すべて有限かつ正        n == 32、非有限 0
  C3  3 腕の位置キー集合の対称差                      == 0
  C4  3 腕の合計幅                                    すべて 1024 で等しい
  C6  全出力の非有限値                                0（allow_nan=False）

腕の幅ベクトル（設計書 §4 は e0 / e6 だけを指定していたため、本次で解釈を固定する）
  `w_ref  = (32, 32, 96, 96, 160, 160, 224, 224)`  = A4b の `BASE_W`。合計 1024
  `w_mid  = (96, 96, 96, 96, 160, 160, 160, 160)`  e0/e1 → 96、e6/e7 → 160。合計 1024
  `w_flat = (128,) * 8`                              合計 1024
  すなわち e0 群 (e0,e1) と e6 群 (e6,e7) をペアで動かし、合計幅を保つ。
  位置 `(l, i)` は 4 層 × 8 expert の 32 個で、3 腕まったく同じ。

出力: qa1_s1_metrics.json / qa1_s1_gain.npz / qa1_s1.log（すべて UTF-8）
"""
from __future__ import annotations

import json
import math
import os
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
for _p in (str(HERE), str(HERE / "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import q1_trace_routing as Q1                                   # noqa: E402
from a1_activation_ffn import ActMoE, BASE_W, per_expert_rms  # noqa: E402
import a4_small_expert_act as A4                               # noqa: E402

# =====================================================================
# 走行前固定（結果を見て変更しない）
# =====================================================================
TAG = "qa1_s1"
W_REF = tuple(int(w) for w in BASE_W)
W_MID = (96, 96, 96, 96, 160, 160, 160, 160)
W_FLAT = (128,) * 8
ARMS = {"w_ref": W_REF, "w_mid": W_MID, "w_flat": W_FLAT}
WIDTH_TOTAL = 1024
N_LAYERS = 4
N_EXPERTS = 8
N_POS = N_LAYERS * N_EXPERTS            # 32

CAL_SEED = 0
CAL_RNG_SEED = 999
CAL_N = 128
EPS_C1 = 1.0e-9
EPS_ROUND = 5.0e-5                      # by_expert は round(v, 4)
EPS_WIDTH_SUM = 0                      # 合計幅は完全一致

# 校正対象の活性化: A4b の `all_relu2`（全 expert ReLU²）を踏襲し、
# 参照は同じ seed・同じ重みの全 ReLU モデル（A4b §1 / §7-2）。
ARM_ACT = ["relu2"] * N_EXPERTS
REF_ACT = ["relu"] * N_EXPERTS


def compute_gain(widths, act_i, seed=CAL_SEED):
    """`a4_small_expert_act.run_one` の gain 校正と同一手順で `(l,i)` の生配列を返す。

    顺序も合わせる: model → cal_seq → ref → r_ref → r_arm。
    `RewriteMoE.__init__` は `torch.Generator().manual_seed(seed)` なので
    グローバル RNG を消費せず、model と ref は同じ重みになる（A4b §7-2）。
    """
    torch.set_num_threads(1)
    torch.manual_seed(seed)
    model = ActMoE(widths, "relu", seed=seed, act_i=list(act_i))
    cal_rng = np.random.default_rng(CAL_RNG_SEED)
    cal_seq, _ = Q1.make_trace_batch(cal_rng, CAL_N)
    ref = ActMoE(widths, "relu", seed=seed, act_i=list(REF_ACT))
    r_ref = per_expert_rms(ref, cal_seq)
    r_arm = per_expert_rms(model, cal_seq)
    gl = {k: r_ref[k] / max(r_arm.get(k, r_ref[k]), 1e-12) for k in r_ref}
    return gl, int(model.L), int(model.E)


def expected_keys(L, E):
    return {(l, i) for l in range(L) for i in range(E)}


def flatten_numeric(o, path="root"):
    out = {}
    if isinstance(o, dict):
        for k, v in o.items():
            out.update(flatten_numeric(v, f"{path}.{k}"))
    elif isinstance(o, list):
        for j, v in enumerate(o):
            out.update(flatten_numeric(v, f"{path}[{j}]"))
    elif isinstance(o, (int, float)) and not isinstance(o, bool):
        out[path] = float(o)
    return out


def maxdiff_dict(a, b):
    fa, fb = flatten_numeric(a), flatten_numeric(b)
    keys = set(fa) | set(fb)
    missing = [k for k in keys if k not in fa or k not in fb]
    diffs = [abs(fa[k] - fb[k]) for k in keys if k in fa and k in fb]
    return (max(diffs) if diffs else 0.0), len(keys), missing


def r2_group(y, codes, n_groups):
    y = np.asarray(y, dtype=np.float64).ravel()
    codes = np.asarray(codes, dtype=np.int64).ravel()
    cnt = np.bincount(codes, minlength=n_groups).astype(np.float64)
    tot = np.bincount(codes, weights=y, minlength=n_groups)
    mu = tot / np.maximum(cnt, 1.0)
    return float((cnt * (mu - y.mean()) ** 2).sum() / ((y - y.mean()) ** 2).sum())


def main():
    out = {
        "tag": TAG,
        "phase": "QA1 Step 1 (gain[(l,i)] save + C1-C4/C6 dry-run)",
        "design": "QA1課題設計書_保留8は二重に消化済みで残る位置固定幅操作1腕でQA同一性を検定する_20261114.md",
        "no_training": True,
        "no_confirmatory_test": True,
    }
    out["prereg"] = {
        "W_REF": list(W_REF), "W_MID": list(W_MID), "W_FLAT": list(W_FLAT),
        "WIDTH_TOTAL": WIDTH_TOTAL, "N_LAYERS": N_LAYERS, "N_EXPERTS": N_EXPERTS,
        "N_POS": N_POS, "CAL_SEED": CAL_SEED, "CAL_RNG_SEED": CAL_RNG_SEED,
        "CAL_N": CAL_N, "ARM_ACT": ARM_ACT, "REF_ACT": REF_ACT,
        "EPS_C1": EPS_C1, "EPS_ROUND": EPS_ROUND, "EPS_WIDTH_SUM": EPS_WIDTH_SUM,
        "thresholds": {
            "C1a": "maxdiff(gain_all_relu, 1.0) < EPS_C1",
            "C1b": "maxdiff(recomputed gain summary, A4b saved) < EPS_C1; by_expert < EPS_ROUND",
            "C1c": "maxdiff(A4 raw evals, A4b gain-matched evals) < EPS_C1",
            "C2": "n_positions == N_POS and nonfinite == 0 and all(gain > 0)",
            "C3": "symmetric difference of position key sets == 0",
            "C4": "all(sum(widths) == WIDTH_TOTAL)",
            "C6": "nonfinite paths == 0",
        },
        "interpretation_note": (
            "設計書 §4 は e0 / e6 の幅だけを指定し e1 / e7 を書いていなかった。"
            "本次は e0/e1 と e6/e7 をペアで動かして合計幅 1024 を保つ解釈を"
            "走行前に固定した。結果を見て変更していない。"
        ),
        "C5_note": "3 点対照 random <= oracle は本番走行を要するため Step 1 の対象外",
    }

    # ---- 腕ごとの gain 実測
    gains, summaries, arrays = {}, {}, {}
    for name, widths in ARMS.items():
        gl, L, E = compute_gain(widths, ARM_ACT, seed=CAL_SEED)
        keys = set(gl.keys())
        exp = expected_keys(L, E)
        vals = np.array([gl[k] for k in sorted(keys)], dtype=np.float64)
        grid = np.full((L, E), np.nan, dtype=np.float64)
        for (l, i), v in gl.items():
            grid[l, i] = v
        by_exp = [float(grid[:, i].mean()) for i in range(E)]
        gains[name] = gl
        arrays[f"gain_{name}"] = grid
        summaries[name] = {
            "widths": list(widths),
            "width_sum": int(sum(widths)),
            "n_positions": len(keys),
            "key_set_complete": bool(keys == exp),
            "missing_keys": sorted(f"{l},{i}" for (l, i) in exp - keys),
            "extra_keys": sorted(f"{l},{i}" for (l, i) in keys - exp),
            "min": float(vals.min()), "max": float(vals.max()),
            "mean": float(vals.mean()),
            "by_expert": [round(v, 4) for v in by_exp],
            "by_position": {f"{l},{i}": float(gl[(l, i)])
                            for l in range(L) for i in range(E) if (l, i) in gl},
            "finite": bool(np.isfinite(vals).all()),
            "all_positive": bool((vals > 0).all()),
        }
    out["arms"] = summaries

    # ---- C1a: all_relu の gain は全 1.0（参照と同一）
    gl_ref, L, E = compute_gain(W_REF, REF_ACT, seed=CAL_SEED)
    ref_vals = np.array(list(gl_ref.values()), dtype=np.float64)
    c1a = float(np.max(np.abs(ref_vals - 1.0))) if ref_vals.size else float("inf")
    out["C1a"] = {
        "maxdiff_vs_one": c1a, "n": int(ref_vals.size),
        "pass": bool(c1a < EPS_C1),
        "note": "all_relu は参照そのものなので gain が全て 1.0 になる（A4b §1 の校正を継承）",
    }

    # ---- C1b: 本次 all_relu2 (W_REF, seed 0) の gain 集計 vs A4b 保存値
    saved_path = HERE / "data" / "a4" / "all_relu2_s0_g.json"
    saved = json.loads(saved_path.read_text(encoding="utf-8"))["gain"]
    s = summaries["w_ref"]
    d_min = abs(s["min"] - float(saved["min"]))
    d_max = abs(s["max"] - float(saved["max"]))
    d_mean = abs(s["mean"] - float(saved["mean"]))
    d_by = max(abs(a - b) for a, b in zip(s["by_expert"], saved["by_expert"]))
    out["C1b"] = {
        "reference": str(saved_path.relative_to(HERE)),
        "n_recomputed": s["n_positions"], "n_saved": int(saved["n"]),
        "diff_min": d_min, "diff_max": d_max, "diff_mean": d_mean,
        "diff_by_expert": d_by,
        "pass": bool(s["n_positions"] == int(saved["n"])
                     and max(d_min, d_max, d_mean) < EPS_C1 and d_by < EPS_ROUND),
    }

    # ---- C1c: A4 raw と A4b gain-matched の all_relu の evals が seed 別に一致
    c1c_rows = []
    for seed in range(6):
        raw_p = HERE / "data" / "a4" / f"all_relu_s{seed}.json"
        g_p = HERE / "data" / "a4" / f"all_relu_s{seed}_g.json"
        if not (raw_p.exists() and g_p.exists()):
            c1c_rows.append({"seed": seed, "status": "missing"})
            continue
        raw = json.loads(raw_p.read_text(encoding="utf-8"))
        g = json.loads(g_p.read_text(encoding="utf-8"))
        d, nk, miss = maxdiff_dict(raw.get("evals", []), g.get("evals", []))
        c1c_rows.append({"seed": seed, "maxdiff": d, "n_numeric": nk,
                         "n_missing_keys": len(miss), "status": "ok"})
    c1c = max((r["maxdiff"] for r in c1c_rows if r["status"] == "ok"), default=float("inf"))
    out["C1c"] = {
        "per_seed": c1c_rows, "maxdiff_all": c1c,
        "pass": bool(all(r["status"] == "ok" and r["n_missing_keys"] == 0
                         for r in c1c_rows) and c1c < EPS_C1),
        "note": "A4b 報告書 §1 の「A1 の relu と seed 別に完全一致」を既存 json から再検算",
    }

    # ---- C1 統合 / C2 / C3 / C4 / C6
    checks = {
        "C1_a_reference_identity": out["C1a"]["pass"],
        "C1_b_gain_summary_reproduced": out["C1b"]["pass"],
        "C1_c_raw_vs_matched_evals": out["C1c"]["pass"],
        "C2_gain_positions_saved": bool(all(
            s["n_positions"] == N_POS and s["finite"] and s["all_positive"]
            and s["key_set_complete"] for s in summaries.values())),
        "C3_position_keys_identical": bool(all(
            set(gains[n].keys()) == set(gains["w_ref"].keys()) for n in ARMS)),
        "C4_width_sum_equal": bool(all(
            s["width_sum"] == WIDTH_TOTAL for s in summaries.values())),
    }
    out["checks"] = checks

    # ---- 探索的: 保存した 32 個で「幅か層位置か」を分離（A4b §7 限界 3 の難所）
    grid = arrays["gain_w_ref"]
    wid_codes = np.zeros((N_LAYERS, N_EXPERTS), dtype=np.int64)
    group_of_width = {w: k for k, w in enumerate(sorted(set(W_REF)))}
    for i, w in enumerate(W_REF):
        wid_codes[:, i] = group_of_width[w]
    lay_codes = np.broadcast_to(np.arange(N_LAYERS)[:, None], (N_LAYERS, N_EXPERTS))
    y = grid.ravel()
    width_groups = [f"{w}" for w in sorted(set(W_REF))]
    out["exploratory_width_vs_layer"] = {
        "eta2_width": r2_group(y, wid_codes.ravel(), len(width_groups)),
        "eta2_layer": r2_group(y, lay_codes.ravel(), N_LAYERS),
        "gain_by_width": {w: float(y[wid_codes.ravel() == group_of_width[w]].mean())
                          for w in sorted(set(W_REF))},
        "gain_by_layer": {str(l): float(grid[l].mean()) for l in range(N_LAYERS)},
        "a4b_reported_by_width": {"32": 1.31, "96": 1.70, "160": 1.81, "224": 1.96},
        "note": (
            "A4b 報告書 §7 限界 3 は「層別 gain を保存していないため幅か層位置かを"
            "分離できない」とした。本次の 32 個で初めて分離可能になった。"
            "ただし 1 seed の探索的記録で、確認的家族 m=1 には入れない（設計書 §8 限界 4）。"
        ),
    }

    # ---- `a4_small_expert_act.py --gain matched` の by_position 保存を実証
    # epochs=0 なので学習は 0 ステップ。routing_snapshot の forward だけ。
    probe = A4.run_one(arm="all_relu", seed=CAL_SEED, scale=1.0, n_seqs=128,
                       epochs=0, bs=32, lr=2e-3, auxw=0.05,
                       gain="matched", eval_every=1, tag="_qa1dry")
    probe_bp = probe["gain"].get("by_position", {})
    out["save_probe"] = {
        "script": "a4_small_expert_act.py", "gain_mode": "matched",
        "epochs": 0, "tag": "_qa1dry",
        "written_file": "data/a4/all_relu_s0_qa1dry.json",
        "existing_keys_present": all(k in probe["gain"] for k in
                                     ("mode", "n", "min", "max", "mean", "by_expert")),
        "by_position_count": len(probe_bp),
        "by_position_all_finite": bool(all(math.isfinite(v) for v in probe_bp.values())),
        "pass": bool(len(probe_bp) == N_POS
                     and all(math.isfinite(v) for v in probe_bp.values())),
    }
    checks["C2_save_probe_by_position"] = out["save_probe"]["pass"]

    # ---- C6: 全出力の非有限値
    def scan(o, path="root"):
        bad = []
        if isinstance(o, dict):
            for k, v in o.items():
                bad += scan(v, f"{path}.{k}")
        elif isinstance(o, list):
            for j, v in enumerate(o):
                bad += scan(v, f"{path}[{j}]")
        elif isinstance(o, float) and not np.isfinite(o):
            bad.append(path)
        return bad
    nonfinite = scan(out)
    checks["C6_all_finite"] = bool(len(nonfinite) == 0)
    out["C6"] = {"nonfinite_paths": nonfinite, "pass": bool(len(nonfinite) == 0)}

    out["verdict"] = "PASS" if all(checks.values()) else "FAIL"
    out["case"] = ("全校正合格。Step 2 の本番走行設計書へ進める（確認的検定・3 点対照は未実施）"
                   if out["verdict"] == "PASS" else
                   "校正不合格。本番を起動せず、設計書 §6 の観測統計量を再固定する")

    jp = HERE / f"{TAG}_metrics.json"
    jp.write_text(json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False),
                  encoding="utf-8")
    np.savez(HERE / f"{TAG}_gain.npz", **arrays)
    lines = [
        f"tag={TAG}", f"verdict={out['verdict']}",
        f"C1a={c1a:.3e} C1b_min={d_min:.3e} C1b_by={d_by:.3e} C1c={c1c:.3e}",
        f"C2_n_positions={{}}".format({n: s["n_positions"] for n, s in summaries.items()}),
        f"C3_keys_identical={checks['C3_position_keys_identical']}",
        f"C4_width_sums={{}}".format({n: s["width_sum"] for n, s in summaries.items()}),
        f"save_probe_by_position={len(probe_bp)}",
        f"eta2_width={out['exploratory_width_vs_layer']['eta2_width']:.6f} "
        f"eta2_layer={out['exploratory_width_vs_layer']['eta2_layer']:.6f}",
        f"checks={checks}", f"case={out['case']}", "",
    ]
    (HERE / f"{TAG}.log").write_text("\n".join(lines), encoding="utf-8")
    sys.stdout.write("\n".join(lines))
    sys.stdout.flush()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        sys.stderr.write(f"[qa1_gain_dryrun] ERROR {type(exc).__name__}: {exc}\n")
        sys.stderr.flush()
        raise
