# -*- coding: utf-8 -*-
"""p6p_corpus_control.py — 言語を固定してコーパスだけ振る（en-wiki vs en-doc）

問い: en/ja の差は「言語」か「コーパス（ジャンル）」か。
  en-wiki : wikitext-2 test（英語・百科事典）      … 既存
  en-doc  : transformers の docstring（英語・技術文書）… 本スクリプトで新規
  ja-md   : プロジェクトの md（日本語・技術文書）    … 既存

en-wiki と en-doc は**言語が同じでコーパスが違う**。ここで層の非対称性が再現すれば
「コーパス/ジャンル」が原因、再現しなければ「言語」が原因。

条件は base / f6b8 / f8b6 の 3 つ。

出力: p6p_<corpus>.npz / p6p_<corpus>_out.txt

実行:
  python p6p_corpus_control.py --corpus doc --gpu-gib 7.5 --cpu-gib 12.0
"""

import argparse
import ast
import glob
import os
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = []
SP = r"C:\Users\gochu\.workbuddy-ai\binaries\python\envs\gpu\Lib\site-packages\transformers"

CONDS = [("base", None), ("f6b8", "0-7:6,8-15:8"), ("f8b6", "0-7:8,8-15:6")]


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


def parse_alloc(spec, n_layers, full_k):
    ks = [full_k] * n_layers
    if not spec:
        return ks
    for part in spec.split(","):
        rng, k = part.split(":")
        k = int(k)
        if rng.strip() == "all":
            idx = range(n_layers)
        elif "-" in rng:
            a, b = rng.split("-")
            idx = range(int(a), int(b) + 1)
        else:
            idx = [int(rng)]
        for i in idx:
            ks[i] = k
    return ks


def build_doc_corpus(max_chars=900000):
    """transformers の docstring を集めた英語技術文書コーパス（決定的）。"""
    files = sorted(glob.glob(os.path.join(SP, "**", "*.py"), recursive=True))
    parts, total = [], 0
    for f in files:
        try:
            tree = ast.parse(open(f, encoding="utf-8").read())
        except Exception:
            continue
        for node in ast.walk(tree):
            if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef,
                                 ast.AsyncFunctionDef)):
                d = ast.get_docstring(node)
                if d and len(d) > 80:
                    parts.append(d)
                    total += len(d)
        if total > max_chars:
            break
    return "\n\n".join(parts)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--corpus", type=str, default="doc", choices=["doc", "wiki"])
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--offset", type=int, default=10000)
    ap.add_argument("--gpu-gib", type=float, default=7.5)
    ap.add_argument("--cpu-gib", type=float, default=12.0)
    ap.add_argument("--max-windows", type=int, default=0)
    args = ap.parse_args()

    import torch
    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[1/3] loading %s" % args.model)
    t0 = time.time()
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      loaded in %.0f s" % (time.time() - t0))

    n_layers = int(model.config.num_hidden_layers)
    FULL_K = int(model.config.num_experts_per_tok)
    gates = [layer.mlp.gate for layer in model.model.layers]
    kept = []

    def mk_hook():
        def hook(module, inp, out):
            kept.append(out[1].detach().float().sum(-1).cpu())
        return hook

    handles = [g.register_forward_hook(mk_hook()) for g in gates]

    log("[2/3] building corpus: %s" % args.corpus)
    if args.corpus == "doc":
        txt = build_doc_corpus()
    else:
        with open(os.path.join(HERE, "wikitext2_test.txt"), encoding="utf-8") as f:
            txt = f.read()
    ids = tok(txt, return_tensors="pt", add_special_tokens=False).input_ids[0]
    need = args.windows * args.len
    start = min(args.offset, max(0, ids.numel() - need))
    block = ids[start:start + need]
    log("      chars=%d  tokens=%d  slice=[%d, %d)" % (len(txt), ids.numel(), start, start + need))
    seqs = [block[w * args.len:(w + 1) * args.len] for w in range(args.windows)]
    if args.max_windows:
        seqs = seqs[:args.max_windows]

    store = {}
    log("[3/3] forward")
    t1 = time.time()
    for name, spec in CONDS:
        ks = parse_alloc(spec, n_layers, FULL_K)
        for i, g in enumerate(gates):
            g.top_k = ks[i]
        kept.clear()
        ch = {k: [] for k in ("nll", "ptop1", "top1")}
        with torch.no_grad():
            for ids_w in seqs:
                x = ids_w.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                lg = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                logZ = torch.logsumexp(lg, dim=-1)
                true_l = lg.gather(1, tgt.unsqueeze(-1)).squeeze(-1)
                rank = (lg > true_l.unsqueeze(-1)).sum(dim=-1) + 1
                top1_l, _ = lg.max(dim=-1)
                ch["nll"].append((logZ - true_l).cpu().numpy())
                ch["ptop1"].append(torch.exp(top1_l - logZ).cpu().numpy())
                ch["top1"].append((rank == 1).float().cpu().numpy())
                del out, lg, logZ, true_l, rank
                torch.cuda.empty_cache()
        K = torch.stack(kept[-n_layers * len(seqs):]).numpy()
        K = K.reshape(len(seqs), n_layers, -1)[:, :, :args.len - 1]
        store[name] = {k: np.concatenate(v) for k, v in ch.items()}
        store[name]["mass"] = K.reshape(n_layers, -1).astype(np.float32)
        g0 = store[name]["ptop1"] - store[name]["top1"]
        log("      %-5s CE %.5f  p_top1 %.4f  acc %.4f  gap %+.2f pt  mass %.4f  (%.0f s)"
            % (name, store[name]["nll"].mean(), store[name]["ptop1"].mean(),
               store[name]["top1"].mean(), 100 * g0.mean(),
               float(store[name]["mass"].mean()), time.time() - t1))

    for h in handles:
        h.remove()

    np.savez_compressed(os.path.join(HERE, "p6p_%s.npz" % args.corpus),
                        **{("%s_%s" % (n, k)): store[n][k] for n in store for k in store[n]})
    with open(os.path.join(HERE, "p6p_%s_out.txt" % args.corpus), "w", encoding="utf-8") as f:
        f.write("\n".join(LOG))
    log("saved p6p_%s.npz" % args.corpus)
    import sys
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
