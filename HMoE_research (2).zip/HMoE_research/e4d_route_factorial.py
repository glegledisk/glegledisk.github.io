# -*- coding: utf-8 -*-
"""e4d_route_factorial.py — PLAN の条件付け効果とルーティング効果の直接分離

E4d では λ を経由して近似した（oracle λ=0.8 で全恒等）。ここではルーティングを
**構造的に固定**した 2x2 要因配置で、より clean に分離する。

  要因 A: PLAN トークンの有無      (none / plan)
  要因 B: ルーティング（計算配分） (frozen_FFN / frozen_identity)

  frozen_FFN      : 恒等パスを選択不可にし、top-2 を 7 個の FFN から選ぶ（計算量は常に最大）
  frozen_identity : 全スロットを恒等パスに固定（FFN を一切使わない）

  参考として「自由ルーティング」の 4 点（既存 E4d の結果）を併記する。

これにより
  - 条件付け効果 = CE(none,FFN) - CE(plan,FFN)      … ルーティングを FFN に固定したまま PLAN だけ変える
  - ルーティング効果 = CE(plan,FFN) - CE(plan,free)  … PLAN を固定したまま配分だけ変える
を直接読める。
"""
import os, json, time
import numpy as np
import pandas as pd
from e4d_prefix_stats import run_arm

HERE = os.path.dirname(os.path.abspath(__file__))
SEEDS = [0, 1, 2]

CELLS = [
    ("none", "ffn_only", "baseline"),
    ("plan", "ffn_only", "oracle"),
    ("none", "identity", "baseline"),
    ("plan", "identity", "oracle"),
]

rows = []
t0 = time.time()
for plan, route, arm in CELLS:
    for s in SEEDS:
        r = run_arm(arm, s, lam_cost=0.0, route_mode=route)
        r["plan"] = plan
        r["route"] = route
        rows.append(r)
        print(f"  plan={plan:4s} route={route:9s} s{s} | FFN {r['ffn_cost']:.3f} | "
              f"CE {r['ce_all']:.4f} (copy {r['ce_copy']:.4f} / edit {r['ce_edit']:.4f}) | "
              f"acc {r['acc_all']:.4f}", flush=True)
    print(f"    ({time.time()-t0:.0f}s)", flush=True)

df = pd.DataFrame(rows)
df.to_csv(os.path.join(HERE, "e4d_route_factorial_results.csv"), index=False)

print("\n=== 2x2 要因配置（3 seeds 平均±SD） ===")
print(f"{'plan':5s} {'route':9s} {'FFN cost':>16s} {'CE all':>16s} {'CE copy':>9s} {'CE edit':>9s} {'acc':>8s}")
cell = {}
for plan, route, _ in CELLS:
    d = df[(df.plan == plan) & (df.route == route)]
    cell[(plan, route)] = (d["ce_all"].mean(), d["ce_all"].std())
    print(f"{plan:5s} {route:9s} {d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f}  "
          f"{d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"{d['ce_copy'].mean():.4f}  {d['ce_edit'].mean():.4f}  {d['acc_all'].mean():.4f}")

print("\n=== 効果の分解 ===")
ce_nf = cell[("none", "ffn_only")][0]
ce_pf = cell[("plan", "ffn_only")][0]
ce_ni = cell[("none", "identity")][0]
ce_pi = cell[("plan", "identity")][0]

print(f" 条件付け効果（FFN 固定）  : {ce_nf:.4f} -> {ce_pf:.4f} = {ce_nf-ce_pf:+.4f} nats")
print(f" 条件付け効果（恒等固定）  : {ce_ni:.4f} -> {ce_pi:.4f} = {ce_ni-ce_pi:+.4f} nats")
print(f" ルーティング効果（PLAN なし）: {ce_nf:.4f} -> {ce_ni:.4f} = {ce_nf-ce_ni:+.4f} nats")
print(f" ルーティング効果（PLAN あり）: {ce_pf:.4f} -> {ce_pi:.4f} = {ce_pf-ce_pi:+.4f} nats")

# 自由ルーティングの参照点（既存 E4d）
base = pd.read_csv(os.path.join(HERE, "e4d_prefix_stats_results.csv"))
b_free = base[base.arm == "baseline"]["ce_all"].mean()
o_free = base[base.arm == "oracle"]["ce_all"].mean()
lam = pd.read_csv(os.path.join(HERE, "e4d_lambda_sweep_results.csv"))
b_id = lam[(lam.arm == "baseline") & (lam.lam == 1.6)]["ce_all"].mean()
ol = pd.read_csv(os.path.join(HERE, "e4d_oracle_lambda_results.csv"))
o_id = ol[ol.lam == 0.8]["ce_all"].mean()

print("\n=== 参照点（自由ルーティング、既存 E4d） ===")
print(f" (none, free)  = {b_free:.4f}")
print(f" (plan, free)  = {o_free:.4f}   ← 選択的ルーティング（λ=0.15）")
print(f" (none, free→identity) = {b_id:.4f}  （λ=1.6、全恒等に収束）")
print(f" (plan, free→identity) = {o_id:.4f}  （λ=0.8、全恒等に収束）")

print("\n=== 最終分解（総改善 {:.4f} nats） ===".format(b_free - o_free))
tot = b_free - o_free
cond = b_free - ce_pf
rout = ce_pf - o_free
print(f" PLAN の条件付け（FFN 固定で測る） : {cond:+.4f} nats ({100*cond/tot:.1f}%)")
print(f" ルーティング（PLAN ありで測る）   : {rout:+.4f} nats ({100*rout/tot:.1f}%)")

json.dump({"cells": {f"{p}|{r}": {"ce_mean": float(cell[(p, r)][0]),
                                   "ce_std": float(cell[(p, r)][1])} for p, r, _ in CELLS},
           "reference_free": {"none_free": float(b_free), "plan_free": float(o_free),
                              "none_identity_free": float(b_id), "plan_identity_free": float(o_id)},
           "decomposition": {"total": float(tot), "conditioning": float(cond), "routing": float(rout)},
           "raw": rows},
          open(os.path.join(HERE, "e4d_route_factorial.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e4d_route_factorial_results.csv / .json")
