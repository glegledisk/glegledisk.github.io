#!/usr/bin/env python3
"""K1e の異常値（s3 の生徒 CE 1.6069、訓練損失は 0.3651）を ckpt から再評価して確認する。

疑う点
  16 epoch の s3 生徒は最終 epoch の学習損失が 0.3651（他と同水準）なのに、
  評価 CE が 1.6069。**終盤スパイクなら epoch 平均は動かないまま重みだけ壊れる**。
  まず「記録ミス・ckpt 破損・並列実行の取り違え」を排除する。

出力: k1e_verify_out_utf8.txt
"""
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from p13c_retrain import (  # noqa: E402
    E2DIR, make_batch, to_seq, forward_forced, RewriteMoE, WIDTHS, SL, OL, V,
)

OUT = os.path.join(HERE, "k1e_verify_out_utf8.txt")
lines = []


def p(s=""):
    print(s, flush=True)
    lines.append(s)


def load(widths, seed, path, topk):
    m = RewriteMoE(widths, seed=seed, topk=topk)
    sd = torch.load(path, map_location="cpu")
    for k, v in sd.items():
        assert m.p[k].shape == v.shape, (k, m.p[k].shape, v.shape)
        with torch.no_grad():
            m.p[k].copy_(v)
    return m


@torch.no_grad()
def ce_all(model, src, out, k, bs=128):
    n = src.shape[0]
    tot = np.zeros((n, OL), dtype=np.float32)
    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = to_seq(src[s], out[s])
        logits, _ = forward_forced(model, x, force=None, k=k)
        lg = logits[:, SL:SL + OL, :]
        tgt = torch.from_numpy(out[s])
        tot[s] = F.cross_entropy(lg.reshape(-1, V), tgt.reshape(-1),
                                 reduction="none").reshape(-1, OL).numpy()
    return float(tot.mean()), tot


def main():
    torch.set_num_threads(1)
    ev = np.random.default_rng(777)
    src, out, em, ks = make_batch(ev, 2048)
    p("eval n=%d edit率=%.4f" % (src.shape[0], em.mean()))
    p("")
    d = os.path.join(E2DIR, "data", "k1")
    p("== s3 の再評価（16 epoch, tag=_e16） ==")
    mt = load(WIDTHS["H+LB"], 3, os.path.join(d, "ckpt_teacher_s3_e16.pt"), 2)
    c1, _ = ce_all(mt, src, out, 2)
    p("  teacher s3: CE %.4f（記録 0.3463）" % c1)
    ms = load([161], 3, os.path.join(d, "ckpt_dense161_s3_e16.pt"), 1)
    c2, tok = ce_all(ms, src, out, 1)
    p("  dense161 s3: CE %.4f（記録 1.6069）" % c2)
    p("")
    p("  トークン別の内訳: CE_copy %.4f / CE_edit %.4f"
      % (tok[~em].mean(), tok[em].mean()))
    p("  CE の分位: p1 %.3f / p50 %.3f / p99 %.3f / max %.3f"
      % tuple(np.percentile(tok, [1, 50, 99, 100])))
    p("  系列別 CE の分位: p10 %.3f / p50 %.3f / p90 %.3f"
      % tuple(np.percentile(tok.mean(1), [10, 50, 90])))
    p("")
    p("== 参考: 正常な seed 0（16 epoch） ==")
    ms0 = load([161], 0, os.path.join(d, "ckpt_dense161_s0_e16.pt"), 1)
    c3, tok0 = ce_all(ms0, src, out, 1)
    p("  dense161 s0: CE %.4f（記録 0.3458）/ CE_copy %.4f / CE_edit %.4f"
      % (c3, tok0[~em].mean(), tok0[em].mean()))
    p("  系列別 CE の分位: p10 %.3f / p50 %.3f / p90 %.3f"
      % tuple(np.percentile(tok0.mean(1), [10, 50, 90])))

    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n[write] %s" % OUT)


if __name__ == "__main__":
    main()
