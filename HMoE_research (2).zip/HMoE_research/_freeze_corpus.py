# -*- coding: utf-8 -*-
"""_freeze_corpus.py — コーパスのトークン ID を凍結する（再発防止）

p3/p6a の ja コーパスはプロジェクト内 *.md を sorted glob しているため、
新しい .md が増えるとスライス内容が変わる（P6 で発覚: baseline CE が
2.60047 -> 2.68932 に動いた）。ここで ID を保存し、以後はこれを読む。

出力: corpus_ids_seed11_w24_l256.npz  (en_ids / ja_ids / meta)
"""
import glob
import json
import os
import re

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SEED, WIN, LEN = 11, 24, 256


def load_corpus(lang, max_chars=400000):
    if lang == "en":
        with open(os.path.join(HERE, "wikitext2_test.txt"), "r", encoding="utf-8") as fp:
            return fp.read()
    files = [f for f in sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True))
             if "english_version" not in f]
    parts = []
    for f in files:
        try:
            with open(f, "r", encoding="utf-8") as fp:
                txt = fp.read()
        except Exception:
            continue
        txt = re.sub(r"```.*?```", " ", txt, flags=re.S)
        txt = re.sub(r"<!--.*?-->", " ", txt, flags=re.S)
        txt = re.sub(r"^\s*\|[-: ]+\|.*$", " ", txt, flags=re.M)
        parts.append(txt)
        if sum(len(p) for p in parts) >= max_chars:
            break
    return "\n\n".join(parts)


def main():
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(os.path.join(HERE, "models", "olmoe-1b-7b"))
    rng = np.random.RandomState(SEED)
    out = {}
    meta = {"seed": SEED, "windows": WIN, "len": LEN, "files": {}}
    for lang in ("en", "ja"):
        txt = load_corpus(lang)
        ids = tok(txt, return_tensors="pt", add_special_tokens=False).input_ids[0]
        need = WIN * LEN
        start = 0 if ids.numel() < need else int(rng.randint(0, ids.numel() - need))
        out["%s_ids" % lang] = ids[start:start + need].numpy().astype(np.int32)
        meta["files"][lang] = {"corpus_tokens": int(ids.numel()), "start": int(start),
                               "n": int(need)}
        print("%s: corpus=%d start=%d n=%d" % (lang, ids.numel(), start, need))
    meta["note"] = ("ja はプロジェクト内 *.md の glob。この ID を以後の基準に使う。"
                    "再生成すると .md の増減で内容が変わる。")
    np.savez_compressed(os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"),
                        **out, meta=np.array([json.dumps(meta, ensure_ascii=False)]))
    print("saved corpus_ids_seed11_w24_l256.npz")


if __name__ == "__main__":
    main()
