"""
P4i: 因果的に合法な範囲での MLP probe（決定は層 0 の情報のみ）

P4g で ALL(l15)|bce が dv 0.01144 と均一 top-7（0.01449）を下回った。
しかし **層 15 の隠れ状態は層 0–14 を走らせた後にしか得られない**ので、
全層の k を決めるのには使えない（因果違反）。

ここでは「層 0 で入手できる情報だけ」で MLP を組み、合法な上限を測る。
  gate0, gstat0, h0（＝埋め込み）, hist  → すべて位置 j・層 0 で入手可能

比較のため、層 8 / 層 15 の情報を使う版も並べる（因果的には使えないが、
「情報がどこにあるか」を示す診断値として）。
"""

import json
import os

import numpy as np

from p4b_probe import auc_score, build_features, spearman
from p4e_mech import layer_feats
from p4f_mlp import mlp_cv

HERE = os.path.dirname(os.path.abspath(__file__))
MECH = ["p1", "p7", "p8", "p9", "p7p8", "p8_over_p1", "p9_over_p8",
        "z8_z9", "z6_z9", "mass8", "mass6", "lost_mass", "ent",
        "zmax", "zstd", "zmean", "npos"]


def dv(score, d_j, f=0.5):
    n = d_j.size
    m = int(round(f * n))
    keep = np.zeros(n, bool)
    keep[np.argsort(-score)[:m]] = True
    return float(d_j[~keep].sum() / n)


def main():
    d = np.load(os.path.join(HERE, "p4_feats.npz"), allow_pickle=True)
    p3 = np.load(os.path.join(HERE, "p3_topk_nll.npz"))
    nll_j = p3["k8"]
    d_j = p3["k6"] - p3["k8"]
    win = d["win"]
    ybin = (d_j > np.quantile(d_j, 0.75)).astype(np.float64)
    feats, _ = build_features(d)

    mech = {}
    for l in (0, 8, 15):
        m = layer_feats(d["gate_%d" % l])
        mech[l] = np.stack([m[nm] for nm in MECH], 1)

    # 因果的に合法（層 0 で入手可能）
    LEGAL = {
        "gate0": feats["gate0"].astype(np.float64),
        "h0+hist": np.concatenate([feats["h0"], feats["hist"]], 1).astype(np.float64),
        "gate0+hist": np.concatenate([feats["gate0"], feats["hist"]], 1).astype(np.float64),
        "ALL(l0)": np.concatenate([feats["gate0"], feats["gstat0"], feats["h0"], feats["hist"]], 1).astype(np.float64),
        "gate0+mech0+hist": np.concatenate([feats["gate0"], mech[0], feats["hist"]], 1).astype(np.float64),
    }
    # 因果的に違法（診断用）
    ILLEGAL = {
        "gate8+mech8+hist": np.concatenate([feats["gate8"], mech[8], feats["hist"]], 1).astype(np.float64),
        "ALL(l15)": np.concatenate([feats["gate15"], mech[15], feats["h15"], feats["hist"]], 1).astype(np.float64),
    }

    print("=== MLP(bce) の AUC と決定価値（f=0.5, 予算 mean_k=7）===")
    print("  均一 top-7 +0.01449 / ランダム +0.02511 / oracle −0.03803（実測）")
    print("%-22s %-8s %8s %8s %10s" % ("features", "causal", "AUC", "rho", "dv(f=0.5)"))
    rows, preds = {}, {}
    for tag, group, legal in [("LEGAL", LEGAL, "yes"), ("ILLEGAL", ILLEGAL, "NO")]:
        print("-- %s --" % tag)
        for name, X in group.items():
            m, _ = mlp_cv(X, ybin, win, hidden=(64, 32), epochs=250, lr=3e-3,
                          wd=1e-4, loss="bce", patience=40, seed=5)
            a = auc_score(ybin, m)
            r = spearman(m, d_j)
            v = dv(m, d_j)
            rows[name] = {"causal": legal, "auc": a, "spearman": r, "dv50": v, "dim": int(X.shape[1])}
            preds[name] = m
            print("%-22s %-8s %8.4f %8.4f %10.5f" % (name, legal, a, r, v))

    legal_best = min([k for k in rows if rows[k]["causal"] == "yes"], key=lambda k: rows[k]["dv50"])
    print("\n合法な最良: %s  dv=%.5f  AUC=%.4f  → 均一 top-7 に %s"
          % (legal_best, rows[legal_best]["dv50"], rows[legal_best]["auc"],
             "勝つ" if rows[legal_best]["dv50"] < 0.01449 else "負ける"))

    with open(os.path.join(HERE, "p4_legal_results.json"), "w", encoding="utf-8") as fp:
        json.dump({"rows": rows, "legal_best": legal_best}, fp, ensure_ascii=False, indent=2)
    np.savez_compressed(os.path.join(HERE, "p4_legal_preds.npz"),
                        **{k.replace("+", "_").replace("(", "").replace(")", ""): v
                           for k, v in preds.items()},
                        d_j=d_j, nll_j=nll_j, win=win)
    print("saved p4_legal_results.json / p4_legal_preds.npz")


if __name__ == "__main__":
    main()
