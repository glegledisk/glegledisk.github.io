# -*- coding: utf-8 -*-
"""p6j_position_analysis.py — 質量効果がなぜ位置依存かを判定（GPU 不要）

見るもの:
  1. 層別の相対乖離 hdev[l] = ||h_l(cond)-h_l(base)|| / ||h_l(base)||
     予測（減衰説）: f6b8 は前半で上がって後半で下がる。f8b6 は後半で上がったまま。
  2. 最終 logits の分散 logit_std（先鋭化の尺度）と p_top1 の対応
  3. 最終正規化後の乖離 fdev と Δp の対応
出力: p6j_analysis.json / p6j_out_utf8.txt / p6j_mechanism.png
"""
import json
import math

import numpy as np

LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


def ttest(a, b):
    d = np.asarray(a, float) - np.asarray(b, float)
    n = d.size
    se = d.std(ddof=1) / math.sqrt(n)
    return float(d.mean()), float(se), float(d.mean() / se) if se > 0 else float("nan")


z = np.load("p6i_position.npz", allow_pickle=True)
CONDS = ["base", "f6b8", "f6b8_rs", "f8b6", "f8b6_rs"]
NL = sum(1 for k in z.files if k.startswith("base_hnorm_l") and k[len("base_hnorm_l"):].isdigit())
OUT = {"n_tokens": int(z["base_nll"].size), "n_layers": NL}

log("tokens=%d  layers=%d" % (z["base_nll"].size, NL))
log("")
log("=== 1. 水準（P6d と一致するか） ===")
log("%-9s %9s %9s %9s %10s %10s %10s" %
    ("cond", "CE", "p_top1", "acc", "logit_std", "logZ", "d_maxlogit"))
tab = {}
for c in CONDS:
    p = z["%s_ptop1" % c].astype(float)
    y = z["%s_top1" % c].astype(float)
    # 最大 logit の変化 = Δlog p + ΔlogZ（p = exp(max - logZ) より）
    dmax = (np.log(p) - np.log(z["base_ptop1"].astype(float))
            + z["%s_logZ" % c].astype(float) - z["base_logZ"].astype(float))
    tab[c] = dict(ce=float(z["%s_nll" % c].astype(float).mean()), p=float(p.mean()),
                  acc=float(y.mean()), std=float(z["%s_logit_std" % c].astype(float).mean()),
                  logZ=float(z["%s_logZ" % c].astype(float).mean()),
                  dmax=float(dmax.mean()))
    log("%-9s %9.5f %9.4f %9.4f %10.4f %10.3f %+10.5f"
        % (c, tab[c]["ce"], tab[c]["p"], tab[c]["acc"], tab[c]["std"], tab[c]["logZ"],
           tab[c]["dmax"]))
OUT["levels"] = tab

log("")
log("=== 2. 層別の相対乖離 hdev[l] (%) と、乖離の向き（cos） ===")
log("  cos は法余弦則から: cos = (|h|^2 + |h'|^2 - |dh|^2) / (2|h||h'|)")
log("  cos≈1 なら「長さだけ」のずれ（最終 RMSNorm で消える）。cos<1 なら「向き」のずれ（残る）。")
log("  L |" + "".join(" %16s" % c for c in CONDS[1:]))
log("    |" + "".join(" %8s %7s" % ("hdev%", "cos") for _ in CONDS[1:]))
prof, cosi = {}, {}
for l in range(NL):
    vals, cs = [], []
    for c in CONDS[1:]:
        hb = z["base_hnorm_l%d" % l].astype(float)
        hc = z["%s_hnorm_l%d" % (c, l)].astype(float)
        dev = z["%s_hdev_l%d" % (c, l)].astype(float)     # |dh| / |h_base|
        dh = dev * hb
        cos = (hb ** 2 + hc ** 2 - dh ** 2) / (2 * hb * hc)
        vals.append(100 * dev.mean())
        cs.append(float(np.clip(cos, -1, 1).mean()))
    prof[l] = vals
    cosi[l] = cs
    log("%3d |" % l + "".join(" %8.3f %7.4f" % (v, cc) for v, cc in zip(vals, cs)))
OUT["hdev_profile"] = prof
OUT["cos_profile"] = cosi

log("")
log("=== 3. 減衰説の検定: 前半で上がった乖離は後半で減るか ===")
for c in ("f6b8", "f6b8_rs"):
    h7 = z["%s_hdev_l7" % c].astype(float)
    h15 = z["%s_hdev_l15" % c].astype(float)
    m, se, t = ttest(h15, h7)
    log("  %-8s hdev(l7)=%.4f -> hdev(l15)=%.4f  差 %+.4f (t=%+.2f, n=%d)"
        % (c, h7.mean(), h15.mean(), m, t, h7.size))
    OUT["decay_%s" % c] = dict(h7=float(h7.mean()), h15=float(h15.mean()), d=m, t=t)
for c in ("f8b6", "f8b6_rs"):
    h7 = z["%s_hdev_l7" % c].astype(float)
    h15 = z["%s_hdev_l15" % c].astype(float)
    log("  %-8s hdev(l7)=%.4f（前半は base と同一なので 0）-> hdev(l15)=%.4f"
        % (c, h7.mean(), h15.mean()))
    OUT["decay_%s" % c] = dict(h7=float(h7.mean()), h15=float(h15.mean()))

log("")
log("=== 4. 最終層での乖離と p の効果 ===")
log("%-9s %10s %10s %10s %12s" % ("cond", "hdev_l15", "fdev", "dp_top1", "fdev/|dp|"))
rel = {}
for c in CONDS[1:]:
    h15 = z["%s_hdev_l15" % c].astype(float).mean()
    fdv = z["%s_fdev" % c].astype(float).mean() if ("%s_fdev" % c) in z.files else float("nan")
    dp = tab[c]["p"] - tab["base"]["p"]
    rel[c] = dict(hdev15=float(h15), fdev=float(fdv), dp=float(dp))
    log("%-9s %10.4f %10.4f %+10.5f %12.2f" % (c, h15, fdv, dp, fdv / abs(dp) if dp else float("nan")))
OUT["final_dev"] = rel

log("")
log("=== 5. 先鋭化説: logit_std と p_top1 ===")
log("%-9s %10s %10s %10s" % ("cond", "logit_std", "dp_top1", "d_std"))
for c in CONDS:
    log("%-9s %10.4f %+10.5f %+10.4f"
        % (c, tab[c]["std"], tab[c]["p"] - tab["base"]["p"], tab[c]["std"] - tab["base"]["std"]))
# 条件平均での相関（5 点）
xs = np.array([tab[c]["std"] for c in CONDS])
ys = np.array([tab[c]["p"] for c in CONDS])
log("  条件平均の相関 corr(logit_std, p_top1) = %.3f (n=5)" % float(np.corrcoef(xs, ys)[0, 1]))
# トークン単位（全条件を混ぜる）
XS = np.concatenate([z["%s_logit_std" % c].astype(float) for c in CONDS])
YS = np.concatenate([z["%s_ptop1" % c].astype(float) for c in CONDS])
log("  トークン単位の相関 = %.3f (n=%d)" % (float(np.corrcoef(XS, YS)[0, 1]), XS.size))
OUT["sharpening"] = dict(corr_cond=float(np.corrcoef(xs, ys)[0, 1]),
                         corr_tok=float(np.corrcoef(XS, YS)[0, 1]))

log("")
log("=== 6. トークン単位: 最終乖離が p の変化を説明するか ===")
for c in CONDS[1:]:
    fdv = z["%s_fdev" % c].astype(float)
    dp = z["%s_ptop1" % c].astype(float) - z["base_ptop1"].astype(float)
    log("  %-9s corr(fdev, dp) = %+.3f   E[dp | fdev 上位10%%] = %+.5f  E[dp | 下位10%%] = %+.5f"
        % (c, float(np.corrcoef(fdv, dp)[0, 1]),
           float(dp[fdv >= np.percentile(fdv, 90)].mean()),
           float(dp[fdv <= np.percentile(fdv, 10)].mean())))
    OUT.setdefault("tok_corr", {})[c] = float(np.corrcoef(fdv, dp)[0, 1])

with open("p6j_analysis.json", "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=2)
with open("p6j_out_utf8.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(LOG))

# ---------------------------------------------------------------- 図
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.3), dpi=140)
    for c, col, ls in (("f6b8", "C2", "--"), ("f6b8_rs", "C2", "-"),
                       ("f8b6", "C3", "--"), ("f8b6_rs", "C3", "-")):
        ys = [100 * np.mean(z["%s_hdev_l%d" % (c, l)].astype(float)) for l in range(NL)]
        ax[0].plot(range(NL), ys, ls, color=col, marker="o", ms=3, lw=1.4, label=c)
    ax[0].axvline(7.5, color="k", ls=":", lw=0.8)
    ax[0].set_xlabel("layer")
    ax[0].set_ylabel("relative hidden-state deviation (%)")
    ax[0].set_title("Where the deviation appears and whether it decays")
    ax[0].legend(fontsize=8)
    ax[0].grid(alpha=0.3)

    for c, col in zip(CONDS, ["gray", "C2", "C2", "C3", "C3"]):
        ax[1].scatter(tab[c]["std"], tab[c]["p"], s=70, color=col,
                      marker=("s" if "rs" in c else "o"), label=c, zorder=3)
    for c in CONDS:
        ax[1].annotate(c, (tab[c]["std"], tab[c]["p"]), textcoords="offset points",
                       xytext=(6, -3), fontsize=8)
    ax[1].set_xlabel("logit std (sharpening)")
    ax[1].set_ylabel("p_top1")
    ax[1].set_title("Sharpening vs confidence (5 conditions)")
    ax[1].grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig("p6j_mechanism.png")
    log("\nsaved p6j_mechanism.png")
except Exception as e:
    log("figure failed: %s" % e)
