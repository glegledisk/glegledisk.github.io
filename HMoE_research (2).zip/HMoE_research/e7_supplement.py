# -*- coding: utf-8 -*-
"""e7_supplement.py — E7 本実験の追加解析（sidecar vs free の paired 検定・seed 別詳細）"""
import numpy as np
import pandas as pd

df = pd.read_csv("e7_routing_7seed.csv")
df["obj015"] = df["ce_all"] + 0.15 * df["ffn_cost"]
ARMS = ["frozen_ffn", "frozen_identity", "free", "sidecar"]

print("=== 全アームの per-seed CE / FFN ===")
piv = df.pivot_table(index="seed", columns="arm", values=["ce_all", "ffn_cost", "obj015", "acc_all"])
print(piv.round(4).to_string())

print("\n=== sidecar vs free（seed 対応） ===")
for k in ("obj015", "ce_all", "ffn_cost", "acc_all"):
    d = (piv[k]["sidecar"] - piv[k]["free"]).dropna()
    m, sd = d.mean(), d.std(ddof=1)
    t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
    rng = np.random.default_rng(2)
    boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(20000)])
    lo, hi = np.percentile(boot, [2.5, 97.5])
    wins = int((d < 0).sum())
    print(f" {k:9s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {wins}/{len(d)}")

print("\n=== 役割別 acc（アーム平均） ===")
print(f"{'arm':16s} " + " ".join(f"{'acc '+nm:>10s} {'ce '+nm:>10s}" for nm in ["ff", "fr", "rr"]))
for a in ARMS:
    d = df[df.arm == a]
    print(f"{a:16s} " + " ".join(f"{d['acc_'+nm].mean():10.4f} {d['ce_'+nm].mean():10.4f}" for nm in ["ff", "fr", "rr"]))

print("\n=== ルータの seed 別 id_rate（free / sidecar） ===")
p2 = df.pivot_table(index="seed", columns="arm", values=["id_rate_ff", "id_rate_fr", "id_rate_rr"])
for a in ["free", "sidecar"]:
    print(f" {a}:")
    for nm in ["ff", "fr", "rr"]:
        v = p2[f"id_rate_{nm}"][a]
        print(f"   id_{nm}: " + " ".join(f"{x:.3f}" for x in v) + f"   平均 {v.mean():.3f}")

print("\n=== free の seed 別: FFN cost と id_rate_rr の関係 ===")
for a in ["free", "sidecar"]:
    d = df[df.arm == a]
    print(f" {a}: FFN " + " ".join(f"{x:.3f}" for x in d.sort_values('seed')["ffn_cost"]))
    print(f" {'':8s} idRR" + " ".join(f"{x:.3f}" for x in d.sort_values('seed')["id_rate_rr"]))
    print(f" {'':8s} CE  " + " ".join(f"{x:.3f}" for x in d.sort_values('seed')["ce_all"]))

# E6 との効果量比較
print("\n=== E6  vs E7 効果量 ===")
print(f"{'指標':28s} {'E6':>10s} {'E7':>10s}")
print(f"{'FFN 寄与 ΔCE':28s} {'0.2894':>10s} {'0.6439':>10s}")
print(f"{'free CE 差':28s} {'-0.0320':>10s} {'-0.0188':>10s}")
print(f"{'free FFN cost':28s} {'0.207':>10s} {'0.904':>10s}")
print(f"{'free obj 差 (λ=.15)':28s} {'-0.1509':>10s} {'-0.0333':>10s}")
print(f"{'crossover λ* (free)':28s} {'-0.0404':>10s} {'-0.1959':>10s}")
