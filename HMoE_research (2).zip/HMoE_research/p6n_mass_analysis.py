# -*- coding: utf-8 -*-
"""p6n_mass_analysis.py — 質量欠落量の言語差が en/ja 差を説明するか（GPU 不要）

p6m_mass.npz: (layers, tokens) の保持質量。
p6c_layer_cal.npz: 較正ギャップの per-token 値（f6b8 / f8b6）。

判定:
  (A) ja の質量欠落が en より小さければ → 「入力が小さい」だけで説明できる
  (B) 質量欠落が同じなのに gap が動かないなら → 機構そのものが言語で壊れている
  (C) gap 変化 / 質量欠落 の比が言語で同じなら → 機構は同一、入力差だけ
"""
import json
import math

import numpy as np

LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


def ttest(a, b=None):
    a = np.asarray(a, float)
    if b is not None:
        a = a - np.asarray(b, float)
    se = a.std(ddof=1) / math.sqrt(a.size)
    return float(a.mean()), float(se), float(a.mean() / se) if se > 0 else float("nan")


m = np.load("p6m_mass.npz", allow_pickle=True)
lang = m["lang"]
NL, NTraw = m["base"].shape
NWIN = int(lang.size)
TOKLEN = NTraw // NWIN                     # 256（予測対象は末尾を落として 255）
# 予測対象に合わせる: 各窓の最後の位置を落とす
mass = {}
for c in ("base", "f6b8", "f8b6"):
    v = m[c].astype(float).reshape(NL, NWIN, TOKLEN)[:, :, :TOKLEN - 1]
    mass[c] = v.reshape(NL, -1)
NT = mass["base"].shape[1]
tok_lang = np.repeat(lang, NT // NWIN)
OUT = {"n_tokens": int(NT), "n_layers": int(NL)}

log("kept mass: shape=(%d layers, %d tokens)  en=%d ja=%d"
    % (NL, NT, (tok_lang == "en").sum(), (tok_lang == "ja").sum()))

# ---------------------------------------------------------------- 1. 質量の水準
log("")
log("=== 1. 保持質量（16 層平均） ===")
log("%-6s %-4s %10s %10s %10s %12s" % ("cond", "lang", "kept", "loss vs base", "前半損失", "後半損失"))
rows = {}
for c in ("base", "f6b8", "f8b6"):
    for u in ("全部", "en", "ja"):
        sel = np.ones(NT, bool) if u == "全部" else (tok_lang == u)
        k = mass[c][:, sel].mean()
        kl = mass[c][:, sel].mean(axis=1)                  # 層ごと
        base_kl = mass["base"][:, sel].mean(axis=1)
        lf = base_kl[:8].mean() - kl[:8].mean()
        lb = base_kl[8:].mean() - kl[8:].mean()
        loss = mass["base"][:, sel].mean() - k
        rows["%s_%s" % (c, u)] = dict(kept=float(k), loss=float(loss),
                                      loss_front=float(lf), loss_back=float(lb))
        log("%-6s %-4s %10.4f %10.4f %12.4f %10.4f" % (c, u, k, loss, lf, lb))
OUT["levels"] = rows

# ---------------------------------------------------------------- 2. 言語差の検定
log("")
log("=== 2. 質量欠落の言語差（per-token, 16 層合計） ===")
tot = {c: mass[c].sum(axis=0) for c in mass}     # (tokens,) 層和
log("%-6s %12s %12s %12s %10s" % ("cond", "loss 全体", "loss en", "loss ja", "en-ja"))
for c in ("f6b8", "f8b6"):
    d = tot["base"] - tot[c]
    mm, se, t = ttest(d)
    de = d[tok_lang == "en"]
    dj = d[tok_lang == "ja"]
    md, sed, td = ttest(de, dj)
    log("%-6s %12.4f %12.4f %12.4f %+10.4f (t=%+.1f)" %
        (c, mm, de.mean(), dj.mean(), md, td))
    OUT.setdefault("loss_lang", {})[c] = dict(all=float(mm), en=float(de.mean()),
                                              ja=float(dj.mean()), d_en_ja=float(md), t=float(td))

# ---------------------------------------------------------------- 3. gap 変化との比
log("")
log("=== 3. 較正ギャップ変化 / 質量欠落 ===")
c2 = np.load("p6c_layer_cal.npz", allow_pickle=True)
tl2 = np.repeat(c2["lang"], c2["base_nll"].size // c2["lang"].size)
gap6 = c2["f6b8_ptop1"].astype(float) - c2["f6b8_top1"].astype(float)
gap8 = c2["f8b6_ptop1"].astype(float) - c2["f8b6_top1"].astype(float)
dg = gap6 - gap8                                   # 負 = 後半削りが悪い
log("%-4s %14s %14s %16s" % ("lang", "Δgap(pt)", "質量欠落差", "Δgap / 質量差"))
for u in ("en", "ja"):
    s = tl2 == u
    a, _, t2 = ttest(dg[s])
    d = tot["base"] - tot["f8b6"]
    dmass = d[s].mean() - (tot["base"] - tot["f6b8"])[s].mean()   # f8b6 の余分な欠落
    log("%-4s %+14.3f %14.4f %16.2f   (t=%+.2f)" % (u, 100 * a, dmass, 100 * a / dmass, t2))
    OUT.setdefault("ratio", {})[u] = dict(dgap=100 * a, dmass=float(dmass),
                                          ratio=100 * a / dmass, t=t2)

# ---------------------------------------------------------------- 4. トークン単位の対応
log("")
log("=== 4. トークン単位: 質量欠落が gap 変化を説明するか ===")
for u in ("en", "ja"):
    s = tl2 == u
    dm = (tot["base"] - tot["f8b6"])[s]
    d = dg[s]
    log("  %s: corr(質量欠落, Δgap) = %+.3f   E[Δgap | 欠落 上位10%%] = %+.3f 下位10%% = %+.3f"
        % (u, float(np.corrcoef(dm, d)[0, 1]),
           100 * d[dm >= np.percentile(dm, 90)].mean(),
           100 * d[dm <= np.percentile(dm, 10)].mean()))

with open("p6n_analysis.json", "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=2)
with open("p6n_out_utf8.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(LOG))
