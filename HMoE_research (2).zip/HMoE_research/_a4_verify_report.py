# -*- coding: utf-8 -*-
"""_a4_verify_report.py — 検証報告_A4 の数値を一次データから引き直して突合する。"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a4")
ok, bad = [], []


def chk(name, got, want, tol=5e-3):
    if abs(got - want) <= tol * max(1.0, abs(want)):
        ok.append(f"  OK  {name}: {got:.6g} (report {want})")
    else:
        bad.append(f"  NG  {name}: {got:.6g} != report {want}")


rows = [r for r in json.load(open(os.path.join(D, "a4_results.json"), encoding="utf-8"))
        if "evals" in r]
an = json.load(open(os.path.join(D, "a4_analysis.json"), encoding="utf-8"))

# --- 1. 全アーム同一 params ---
ps = {r["nparam"] for r in rows}
chk("params の種類数", len(ps), 1, tol=0)
chk("params", ps.pop(), 1346877, tol=0)

# --- 2. 到達点 ---
TAB = {"all_relu": (0.0219, 0.643, 0.9932, 0.565),
       "small_relu2": (0.0211, 0.632, 0.9932, 0.396),
       "large_relu2": (0.0206, 0.688, 0.9938, 0.567),
       "all_relu2": (0.0651, 0.121, 0.9745, 0.540)}
for a, (ce, iv, ap, sh) in TAB.items():
    rs = [x for x in rows if x["arm"] == a]
    chk(f"CE {a}", float(np.mean([x["evals"][-1]["ce_all"] for x in rs])), ce, tol=5e-3)
    chk(f"instr {a}", float(np.mean([x["evals"][-1]["instr_valid"] for x in rs])), iv, tol=1e-2)
    chk(f"acc_pl {a}", float(np.mean([x["evals"][-1]["acc_payload"] for x in rs])), ap, tol=5e-3)
    chk(f"share {a}", float(np.mean([x["routing"]["small_share"] for x in rs])), sh, tol=5e-3)

# --- 3. 品質の対比 ---
got = {(c["a"], c["b"], c["metric"]): c for c in an["contrasts"]}
WANT = {("small_relu2", "all_relu", "instr_valid"): (-0.011, 0.905, 3),
        ("large_relu2", "all_relu", "instr_valid"): (+0.045, 0.744, 5),
        ("all_relu2", "all_relu", "instr_valid"): (-0.522, 0.0005, 0),
        ("small_relu2", "large_relu2", "instr_valid"): (-0.056, 0.635, 3),
        ("small_relu2", "all_relu", "ce_all"): (-0.0008, 0.869, 3),
        ("all_relu2", "all_relu", "ce_all"): (+0.0432, 0.011, 6),
        ("small_relu2", "large_relu2", "ce_all"): (+0.0006, 0.946, 3)}
for k, (m, p, pos) in WANT.items():
    c = got.get(k)
    if c is None:
        bad.append(f"  NG  対比が無い: {k}")
        continue
    chk(f"{k[0]}-{k[1]} {k[2]} mean", c["mean"], m, tol=1e-2)
    if p >= 0.01:
        chk(f"{k[0]}-{k[1]} {k[2]} p", c["p"], p, tol=5e-2)
    chk(f"{k[0]}-{k[1]} {k[2]} pos", c["pos"], pos, tol=0)

# --- 4. ルーティングの対応差（独立に再計算）---
ROUTE = {("small_relu2", "all_relu"): (-0.1693, 0.0010, 6),
         ("large_relu2", "all_relu"): (+0.0022, 0.817, 3),
         ("all_relu2", "all_relu"): (-0.0254, 0.410, 4)}
for (a, b), (m, p, nneg) in ROUTE.items():
    da = {r["seed"]: r["routing"]["small_share"] for r in rows if r["arm"] == a}
    db = {r["seed"]: r["routing"]["small_share"] for r in rows if r["arm"] == b}
    ks = sorted(set(da) & set(db))
    d = np.array([da[i] - db[i] for i in ks])
    t, pv = stats.ttest_rel([da[i] for i in ks], [db[i] for i in ks])
    chk(f"routing {a}-{b} Δ", float(d.mean()), m, tol=1e-2)
    chk(f"routing {a}-{b} p", float(pv), p, tol=1e-2)
    chk(f"routing {a}-{b} 負の seed", int((d < 0).sum()), nneg, tol=0)

# --- 5. 派生した主張 ---
chk("全部 vs 小だけ の比 0.522/0.011", 0.522 / 0.011, 47.5, tol=1e-1)

# --- 6. A1 との一致（測定器の校正）---
a1 = json.load(open(os.path.join(HERE, "data", "a1", "a1_results.json"), encoding="utf-8"))
a1relu = {r["seed"]: r["evals"][-1]["ce_all"] for r in a1 if r["arm"] == "relu"}
for r in rows:
    if r["arm"] != "all_relu":
        continue
    if abs(r["evals"][-1]["ce_all"] - a1relu[r["seed"]]) > 1e-9:
        bad.append(f"  NG  A1 の relu と不一致 seed{r['seed']}")
if not any("A1" in b for b in bad):
    ok.append("  OK  all_relu は A1 の relu と seed 別に完全一致（Δ < 1e-9）")

print("\n".join(ok))
if bad:
    print("\n".join(bad))
    print(f"\nFAIL: {len(bad)} 件")
    sys.exit(1)
print(f"\nPASS: {len(ok)} 件すべて報告書と一致")
