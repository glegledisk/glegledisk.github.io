# -*- coding: utf-8 -*-
"""e7_weaksep_task.py — E7: 易しい／難しいの分離が弱い課題（全位置ルックアップ＋頻度スキュー）

## 動機（セッション総括 2026-10-24 の A1 / E6 報告書 §8-1）
E6 では「易しい（コピー 50%・依存 25%）→ 恒等パス、難しい（ランダム表 25%）→ FFN」という
**明確なカテゴリ分離**があり、free ルーティングが全 FFN 固定を Pareto 支配した
（CE 0.0392 < 0.0712、FFN コスト 21%、7/7 seed、crossover λ* = −0.040）。
しかし実 LM では全トークンが FFN を必要とし、この分離は存在しない。

E7 は分離を弱めた課題:

  - **全位置がランダム表 π(src[i], src[i-1]) を参照する**（COPY・DEP は存在しない）
  - **頻度だけが違う**: src の distribution を歪め、頻繁なトークン（F, 16 語, 総質量 75%）と
    稀なトークン（R, 48 語, 25%）に分ける
  - 組 (a, b) の出現頻度は p_a・p_b で決まる:

      ff 組（両方頻繁）: p = (0.75/16)^2 ≈ 0.0022 → 位置の 56%、1 epoch に ~123 回
      fr 組（片方頻繁）: p ≈ 0.00049            → 位置の 37%、~14 回
      rr 組（両方稀有） : p ≈ 2.7e-5             → 位置の 6%、~1.5 回

  - したがって「易しい」=「訓練でよくサンプルされる」、「難しい」=「ほとんど見ない」。
    **カテゴリ的な境界はない**（頻度の連続的な勾配）。どの位置も表の参照＝FFN 仕事を要する。

## E6 との対応（「同じ実験」のための固定要素）
- 同じ表 π（固定シード 12345、4096 エントリ）、同じ A=64、L=16、d=64、60 epoch、λ=0.15、
  n_train=3500、bs=64、seeds 0〜6、4 アーム（frozen_ffn / frozen_identity / free / sidecar）
- E6 の「アンカー条件 src[i] ∈ 0..15」は、E7 では「頻度条件 src[i] ∈ F」に対応
- E6 の COPY/DEP（75%、Attention が自力で解読できる易しい位置）は E7 には存在しない

## 役割（分析用のタグ。モデルからは見えない）
  ff : src[i], src[i-1] がともに頻繁トークン（表の参照頻度が高い＝易しい）
  fr : 片方が頻繁、片方が稀なトークン
  rr : どちらも稀なトークン（ほとんど訓練に現れない＝難しい）
  （i=0 は prev=src[0] の対角。トークンが頻繁なら ff、稀なら rr としてタグする。

## 検証したいこと
E6 の Pareto 支配は「易しい位置を恒等パスに逃がし、Expert を表の記憶に専念させる」機構で
起きた。E7 ではどの位置も表の参照を要するので、この機構はそのままでは使えない。
ルーティングはまだ効くか。

  - 効く（free が全 FFN を Pareto 支配）→ E6 の結論は易難分離の強さに依存しない。
    HMoE の品質側テーゼが実モデルへ外挿できる。
  - 効かない（trade-off に戻る／効果なし）→ E6 の結果は「明確な易難分離」に依存する。
    実 LM では使えないという重要な否定的結論。

## 実装ノート
- 学習ループは e5_dependency_task.run() と同一（optimizer・lr・loss・λ・データ生成の流れ）。
  変更点は ①系列生成関数 ②sidecar 特徴（頻度条件 2 次元） ③役割名（ff/fr/rr） ④device 対応のみ。
- e5_dependency_task.py の Net.forward に device 対応の最小修正を入れている
  （torch.arange / torch.ones に device=ids.device）。CPU 上ではビット単位で同一動作＝E6 再現性は不変。
"""
import os, math, json, time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from e5_dependency_task import MoELayer, Net

# E7 の役割コード（E5 の COPY/ANCHOR/DEP とは別体）
FF, FR, RR = 0, 1, 2
ROLE_NAME = {FF: "ff", FR: "fr", RR: "rr"}

ID_IDX = 7  # 恒等 Expert の index（e5 の既定と同一）


def make_lookup_table(A, seed=12345):
    """固定シードでランダムな関数 π: (a,b) -> c を作る。全 run・train/test で共通（E6 と同一）。"""
    rng = np.random.default_rng(seed)
    return rng.integers(0, A, size=(A, A))


def make_weaksep_batch(rng, n, L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)),
                       table=None):
    """E7 の系列生成。**全位置が π(src[i], src[i-1]) を参照する**（i=0 は対角 π(src[0], src[0])）。

    src[i] は歪んだ分布: 確率 w_freq で freq_vals から一様、残り for 他のトークンから一様。
     → 頻繁トークン 1 語あたり w_freq/16、稀なトークン 1 語あたり (1-w_freq)/48。
    役割は組の頻度でタグ: ff（両方頻繁）/ fr（混在）/ rr（両方稀有）。
    """
    if table is None:
        table = make_lookup_table(A)
    fv = np.asarray(freq_vals)
    rv = np.setdiff1d(np.arange(A), fv)
    u = rng.random((n, L)) < w_freq
    fi = rng.integers(0, len(fv), size=(n, L))
    ri = rng.integers(0, len(rv), size=(n, L))
    src = np.where(u, fv[fi], rv[ri])
    prev = np.concatenate([src[:, :1], src[:, :-1]], axis=1)   # i=0 は prev=src[0]（対角）
    out = table[src, prev]                                      # 全位置ルックアップ
    is_f = np.isin(src, fv)
    is_fp = np.isin(prev, fv)
    role = np.where(is_f & is_fp, FF, np.where(is_f | is_fp, FR, RR)).astype(np.int8)

    SEP = A
    seq = np.empty((n, 2 * L + 1), dtype=np.int64)
    seq[:, 0:L] = src
    seq[:, L] = SEP
    seq[:, L + 1:] = out
    pos_out = L + 1
    return torch.from_numpy(seq), role, pos_out


def sidecar_feats_e7(seq, L, T, freq_vals):
    """E7 の明示特徴（sidecar アーム用）: [src[i] が頻繁トークンか, src[i-1] が頻繁トークンか]。

    入力系列だけから計算できる（出力情報は使わない）。e5 の sidecar_feats と同じく
    出力部の L 位置に合わせ、前方を 0 でパディングする。
    """
    fv = np.asarray(freq_vals)
    src = seq[:, :L].numpy()
    prev = np.concatenate([src[:, :1], src[:, :-1]], axis=1)
    f = np.stack([np.isin(src, fv), np.isin(prev, fv)], axis=-1).astype(np.float32)
    pad = np.zeros((f.shape[0], T - L, 2), dtype=np.float32)
    return torch.from_numpy(np.concatenate([pad, f], axis=1))


def run(arm, seed, L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)), n_train=3500,
        n_val=2048, epochs=60, bs=64, lam_cost=0.15, d=64, table=None, device=None):
    """E7 の 1 ラン。学習ループは e5_dependency_task.run() と同一（device 対応を追加）。"""
    if table is None:
        table = make_lookup_table(A)
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    V = A + 1
    route = {"free": "free", "sidecar": "free", "frozen_ffn": "ffn_only",
             "frozen_identity": "identity"}[arm]
    net = Net(V, L, arm=arm, route_mode=route, d=d).to(device)
    opt = torch.optim.AdamW(net.parameters(), lr=3e-3, weight_decay=1e-4)
    pos_out = L + 1
    os_ = pos_out - 1

    def gen(n):
        return make_weaksep_batch(rng, n, L, A, w_freq, freq_vals, table=table)

    for ep in range(epochs):
        net.train()
        seq, role, _ = gen(n_train)
        T = seq.shape[1] - 1
        sc = sidecar_feats_e7(seq, L, T, freq_vals).to(device) if arm == "sidecar" else None
        seq = seq.to(device)
        perm = torch.randperm(n_train)
        for i in range(0, n_train, bs):
            idx = perm[i:i + bs].to(device)
            b = seq[idx]
            inp, tgt = b[:, :-1], b[:, 1:]
            opt.zero_grad()
            logits, (ti0, ti1), (tg0, tg1) = net(inp, pos_out, None if sc is None else sc[idx])
            ce = F.cross_entropy(logits[:, os_:].reshape(-1, V), tgt[:, os_:].reshape(-1))
            g0 = (tg0[:, os_:] * (ti0[:, os_:] == ID_IDX).float()).sum(-1).mean()
            g1 = (tg1[:, os_:] * (ti1[:, os_:] == ID_IDX).float()).sum(-1).mean()
            loss = ce + lam_cost * (2.0 - (g0 + g1))
            loss.backward()
            opt.step()

    net.eval()
    vs, vr, _ = gen(n_val)
    sc = sidecar_feats_e7(vs, L, vs.shape[1] - 1, freq_vals).to(device) if arm == "sidecar" else None
    vs = vs.to(device)
    with torch.no_grad():
        logits, (ti0, ti1), (tg0, tg1) = net(vs[:, :-1], pos_out, sc)
        tgt = vs[:, 1:]
        lo, lt = logits[:, os_:], tgt[:, os_:]
        ce_tok = F.cross_entropy(lo.reshape(-1, V), lt.reshape(-1), reduction="none").reshape(n_val, L)
        pred = lo.argmax(-1)
        acc = (pred == lt)
        gate_id = (tg1[:, os_:] * (ti1[:, os_:] == ID_IDX).float()).sum(-1).mean().item()
        res = {"arm": arm, "seed": seed, "L": L, "A": A, "w_freq": w_freq,
               "ce_all": float(ce_tok.mean()), "acc_all": float(acc.float().mean()),
               "ffn_cost": float(1.0 - gate_id)}
        for r, nm in ROLE_NAME.items():
            m = (vr == r)
            if m.sum() > 0:
                mt = torch.from_numpy(m).to(ce_tok.device)
                res[f"n_{nm}"] = float(m.mean())
                res[f"ce_{nm}"] = float(ce_tok[mt].mean())
                res[f"acc_{nm}"] = float(acc[mt].float().mean())
        # 恒等パスを選た割合（ルーティングの当否・グループ判別の診断）
        is_id = (ti1[:, os_:, 0] == ID_IDX).cpu().numpy()
        for r, nm in ROLE_NAME.items():
            m = (vr == r)
            if m.sum() > 0:
                res[f"id_rate_{nm}"] = float(is_id[m].mean())
    return res


if __name__ == "__main__":
    CFG = dict(L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)))
    tab = make_lookup_table(64)
    print("表サイズ:", tab.shape, "エントリ数:", tab.size, "（E6 と同一の固定シード 12345）")

    rng = np.random.default_rng(0)
    seq, role, po = make_weaksep_batch(rng, 20000, table=tab)
    rl = np.asarray(role)
    print("\n役割分布: " + "  ".join(f"{nm}={100*(rl==r).mean():.1f}%" for r, nm in ROLE_NAME.items()))

    src = seq[:, :16].numpy()
    out = seq[:, 17:].numpy()
    prev = np.concatenate([src[:, :1], src[:, :-1]], axis=1)
    print("生成規則の整合（全位置が table[src, prev]）:", bool((tab[src, prev] == out).all()))

    # 頻度構造の理論値
    w, nf, nr = 0.75, 16, 48
    p_f, p_r = w / nf, (1 - w) / nr
    pos_per_epoch = 3500 * 16
    print("\n=== 頻度構造（理論値） ===")
    print(f"頻繁なトークン 1 語: p={p_f:.4f}  稀なトークン 1 語: p={p_r:.5f}  （比 {p_f/p_r:.1f} 倍）")
    tot = nf*nf*p_f**2 + 2*nf*nr*p_f*p_r + nr*nr*p_r**2
    for nm, npairs, p in [("ff", nf*nf, p_f**2), ("fr", 2*nf*nr, 2*p_f*p_r), ("rr", nr*nr, p_r**2)]:
        print(f" {nm}: 組の数 {npairs:5d}  位置の質量 {100*npairs*p/tot:5.1f}%  "
              f"1 epoch あたり {p*pos_per_epoch:7.1f} 回/組（60 epoch で {p*pos_per_epoch*60:7.0f} 回）")

    # 実測の組頻度（出現度数で重みづけ）
    pairs = src[:, 1:] * 64 + prev[:, 1:]
    uq, cnt = np.unique(pairs, return_counts=True)
    a, b = uq // 64, uq % 64
    ff_m = np.isin(a, range(16)) & np.isin(b, range(16))
    fr_m = np.isin(a, range(16)) ^ np.isin(b, range(16))
    rr_m = ~np.isin(a, range(16)) & ~np.isin(b, range(16))
    print(f"\n実測（i>=1, {len(pairs.ravel())} 位置）: 出現した組の数 {len(uq)} / 4096")
    for nm, m in [("ff", ff_m), ("fr", fr_m), ("rr", rr_m)]:
        print(f"  {nm}: 組の出現質量 {100*cnt[m].sum()/cnt.sum():5.1f}%  組の数 {m.sum():5d}  "
              f"1 組あたり平均 {cnt[m].mean():6.1f} 回（20k 系列中）")

    print("\n例（先頭 5 位置の ff/fr/rr）:")
    shown = {FF: 0, FR: 0, RR: 0}
    for i in range(20000):
        for j in range(16):
            r = rl[i, j]
            if shown[r] < 2:
                print(f"  [{ROLE_NAME[r]}] src[{j}]={src[i,j]:2d} src[{j-1}]={prev[i,j]:2d} "
                      f"-> out={out[i,j]:2d} (表 {tab[src[i,j], prev[i,j]]})")
                shown[r] += 1
        if all(v >= 2 for v in shown.values()):
            break
    print("\n予想 CE（表を完全に記憶できなかった場合）: log(64) =", round(np.log(64), 3))
    print(" frozen_identity は全位置で表の参照を要するので、CE は E6 より大幅に悪化する見込み")
