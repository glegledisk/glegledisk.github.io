#!/usr/bin/env python3
"""Q10: 2 本平均は必要か — payload → e6 単独（0.5 平均なし）。

Q9a の結果:
  static_type (struct→e0/e1 0.5, payload→e6/e7 0.5)  iv 0.588
  dense224x2  (全→e6/e7 0.5)                          iv 0.149
  dense224    (全→e6 1.0)                             iv 0.262
  dynamic_lb                                          iv 0.656
  → 型分離の効果は本物だが、2 本平均が必要かは未分離。

本実験の条件（すべて hard、同一プロセス・同一 seed）:
  dynamic_lb  : 学習ルータ（参照）
  static_type : struct→e0+e1(0.5), payload→e6+e7(0.5)   ← Q8 の設計
  static_e6   : struct→e0+e1(0.5), payload→**e6 単独**(1.0)
                → payload の 0.5 平均だけを外す。**FFN FLOPs は static の約半分**
  static_1x   : struct→**e0 単独**(1.0), payload→**e6 単独**(1.0)
                → 2 本平均を全部外す。**8 expert のうち 2 個だけ使う**

判定:
  static_e6 が static_type と同等 → 2 本目は不要（FLOPs 半減できる）
  static_e6 が負ける            → 0.5 平均そのものが効いている（アンサンブル/容量）
"""
import argparse
import json
import math
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import q2_difficulty_ladder as Q2  # noqa: E402
from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS  # noqa: E402
import q8_static_dispatch as Q8  # noqa: E402

OUTDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q10")

# (struct のプール, payload のプール)。各要素は (expert 添字, gate)
POOLS = {
    "static_e6": ([(0, 0.5), (1, 0.5)], [(6, 1.0)]),
    "static_1x": ([(0, 1.0)], [(6, 1.0)]),
}


def forward_pool(model, idx, typ, struct_pool, payload_pool):
    """型ごとに固定プールへディスパッチする。attention は Q8 と同一。"""
    p = model.p
    B, T = idx.shape
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)

    # 位置 t は t+1 の予測を担当するので、t のルータは typ[:, t+1] を見る（Q1 の教訓）
    target_typ = torch.zeros_like(typ)
    target_typ[:, :-1] = typ[:, 1:]
    target_typ[:, -1] = typ[:, -1]
    is_payload = (target_typ.reshape(-1) == Q2.TYP_PAYLOAD)

    topi = torch.zeros((B * T, 2), dtype=torch.int64)
    for mask, pool in ((~is_payload, struct_pool), (is_payload, payload_pool)):
        idxs = mask.nonzero(as_tuple=True)[0]
        if idxs.numel() == 0:
            continue
        topi[idxs, 0] = pool[0][0]
        topi[idxs, 1] = pool[1][0] if len(pool) > 1 else pool[0][0]

    gate = torch.zeros((B * T, model.E), dtype=h.dtype)
    for mask, pool in ((~is_payload, struct_pool), (is_payload, payload_pool)):
        idxs = mask.nonzero(as_tuple=True)[0]
        for e, g in pool:
            gate[idxs, e] = g

    idx_l = []
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        y = torch.zeros_like(h)
        for mask, pool in ((~is_payload, struct_pool), (is_payload, payload_pool)):
            idxs = mask.nonzero(as_tuple=True)[0]
            if idxs.numel() == 0:
                continue
            x = h[idxs]
            for e, g in pool:
                h1 = F.relu(F.linear(x, p[f"l{l}.e{e}.w1"], p[f"l{l}.e{e}.b1"]))
                y.index_add_(0, idxs,
                             F.linear(h1, p[f"l{l}.e{e}.w2"], p[f"l{l}.e{e}.b2"]) * g)
        h = h + y
        idx_l.append(topi.reshape(B, T, 2))

    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, -1)
    return out, torch.zeros(()), idx_l


_orig_forward = Q8.forward_dispatch


def patched_forward(model, idx, typ=None, mode="dynamic_lb"):
    if mode in POOLS:
        sp, pp = POOLS[mode]
        return forward_pool(model, idx, typ, sp, pp)
    return _orig_forward(model, idx, typ=typ, mode=mode)


Q8.forward_dispatch = patched_forward
Q8.OUTDIR = OUTDIR


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", nargs="+", default=["hard"])
    ap.add_argument("--modes", nargs="+",
                    default=["dynamic_lb", "static_type", "static_e6", "static_1x"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4, 5])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--threads", type=int, default=6)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--outdir", default=None)
    args = ap.parse_args()

    global OUTDIR
    if args.outdir:
        OUTDIR = os.path.join(HERE, args.outdir)
        Q8.OUTDIR = OUTDIR
    os.makedirs(OUTDIR, exist_ok=True)
    torch.set_num_threads(args.threads)
    print(f"Q10: tasks={args.tasks} modes={args.modes} seeds={args.seeds}", flush=True)

    rows = []
    for task in args.tasks:
        for mode in args.modes:
            for seed in args.seeds:
                p = os.path.join(OUTDIR, f"H+LB_{task}_{mode}_s{seed}.json")
                if args.resume and os.path.exists(p):
                    with open(p, encoding="utf-8") as f:
                        r = json.load(f)
                    if r.get("n_eval") == 1024:
                        print(f"  [skip] {task} {mode} s{seed}", flush=True)
                        rows.append(r)
                        continue
                r = Q8.run(task, mode, seed, args.seqs, args.epochs, args.bs, args.lr)
                rows.append(r)
                e = r["eval"]["base"]
                print(f"  -> {task} {mode} s{seed}: "
                      f"acc pl={e['acc_payload']:.4f} iv={e['instr_valid']:.3f} "
                      f"ce pl={e['ce_payload']:.4f} "
                      f"w_st/pl={e['width_struct']:.1f}/{e['width_payload']:.1f}", flush=True)
                with open(p, "w", encoding="utf-8") as f:
                    json.dump(r, f, ensure_ascii=False, indent=2)

    with open(os.path.join(OUTDIR, "q10_results.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
    print(f"[write] {OUTDIR}", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
