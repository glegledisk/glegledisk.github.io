# QE1S5 課題設計書: copy 統計を揃えた sqrt 圧縮支持で T3 を再検定する

- 日付: 2026-11-16（`検証報告_QE1S4S1_エントロピー一致でもcopy再出現gate未達のためT3本番を停止_20261116.md` §2 / §3 と `STATE.md` 15:52 追記の次の一手）
- ステータス: **設計確定・本設計書は新規確認測定を含まない**。Step 1 の生成校正に合格したときだけ Step 2 の学習へ進む
- 区分: **QE1S5**。QE1S4 の C4 未達（K=180 一様で `P_rule(copy)=0.0881<0.10`）を受けた別 ID。QE1S4 の `K`・閾値・seed は事後変更しない
- 関連: `QE1S4課題設計書_エントロピーを揃えた一様頻度対照でT3を再検定する_20261116.md` §1〜§4、`検証報告_QE1S3S1_..._20261115.md` §3、`qe1_make_task.py`、`AGENTS.md` §0-6 / §2 / §3 / §7
- 出力: 本設計書、Step 1 校正成果物、Step 2 の学習成果物（別報告書）

---

## 0. なぜ「一様」をやめるのか

QE1S4 は `K=180` の一様支持で `H_emp` を zipf と一致させた（`ΔH = +0.00002872`）。しかし C4 の `P_rule(copy)` は `0.08814225 < 0.10` で停止した。この 0.088 は偶然ではなく、`COPY_WINDOW = 32` の窓で ident が再出現する確率が `32 / 180 ≈ 0.178` 帯に留まり、`copy_mask &= ~next_syntax` と type 割当を通すと約 0.088 になる**構造的**な値である。K を下げれば再出現率は上がるが `H_emp ≈ ln K` が下がる（事前調査 `K=120` で `H = 4.79`、zipf より `−0.40`）。Q-D の誤設定を避けるには、**エントロピーと copy 再出現を独立に動かす 2 パラメータ**が要る。より本質的に、zipf 自身は `H_emp = 5.193` と `P_rule(copy) = 0.2259` を同時に満たすので、比較対象も「一様」である必要はない。必要なのは**同じ copy 統計を持ち、裾の重さだけが違う分布**である。

事前調査（`_s5_tailmatch_probe.py`、探索的・設計入力のみ）で、zipf ランク `r` を支持 `K` へ
`floor(sqrt(r) · K / sqrt(V_IDENT))` で圧縮する写像が `K = 2048` のとき
`ΔH = −0.0739`、`ΔP_copy = +0.0013` となり、両方を同帯に揃えられることを確認した。
`clip` は裾を切るほどエントロピーが崩れ、`mod` は `K = 2048` でも `ΔH = −0.26` で届かない。
よって **sqrt 圧縮**を本次の対照として走行前に固定する。

---

## 1. 動かす量と固定する量

- **動かす量**: ident の頻度写像だけ。基準 `zipf` は QE1S4 の paired stream（`paired_frequency=True`）と同一、対照 `sqrt2048` は同じ一様 variate `u` を `searchsorted(zipf_cdf(), u)` でランク化し、上式で `0..2047` へ圧縮する。`inc` 演算の modular も `V_IDENT = 12000` ではなく `K = 2048` にする。
- **固定する量**: `K = 2048`、`SCALE = "sqrt"`、生成則 v2、`INIT_TYPE = "uniform"`、`type_draw` / `is_syntax` / syntax ID / 初期型の stream（すべて QE1S4 と同一）、`COPY_WINDOW = 32`、`VOCAB = 12288`、`SEQ_LEN = 256`、系列数、学習条件、T3 の estimand、Holm `m = 1`、全閾値。**すべて走行前に固定**。
- **本次が測る条件**: `AGENTS.md` §2 のうち**異質性**（copy 則位置の内容信号）と**冗長性**（ident 再出現）。予測可能性は測らない。

---

## 2. Step 1 校正ゲート（事前固定）

`seed = 0`、`n_seq = 4000`（各条件 1,024,000 token）、学習 0 epoch・GPU なし。

| ID | 観測統計量 | 合格条件 |
|---|---|---|
| C1 | 既定 `make_task` の 10 配列と QE1S3 archive の maxdiff | すべて 0（既存経路の非侵襲性） |
| C2 | 両条件の `type_draw` / `is_syntax` / `a` の maxdiff、syntax ID 一致 | すべて 0 |
| C3 | `abs(H_emp(sqrt2048) − H_emp(zipf))` | `≤ 0.10 nat`（QE1S4 と同じ閾値を流用） |
| **C4（改）** | `abs(P_rule(copy,sqrt2048) − P_rule(copy,zipf))` と下限 | `≤ 0.02` **かつ** `sqrt2048 ≥ 0.10`。QE1S4 の `≥ 0.10` は維持し、zipf との差も新たに要求する |
| C5 | 両条件の type-pos / a-pos 分散比・正規化 MI | `η² < 0.001` かつ `MI/H < 0.001` |
| C6 | 両条件の edit 信号 | `η²_edit > 0.05`、`MI_edit_norm > 0.10` |
| C7 | `copy_mask` 定義の直接再計算 | `P_re = 1.0`、`N_syn = 0` |
| C8 | 全出力の非有限値 | 0（`allow_nan=False`） |

C4 を「zipf との差 ≤ 0.02」へ変更するのは QE1S4 の結果を見た事後変更に見えないよう、本次は**別 ID の新設計**として固定する（EF1G1 / QE1S4 と同じ扱い）。QE1S4 の絶対下限 `0.10` は緩めず、そのうえで一致条件を足すだけである。C1〜C8 のいずれかが不合格なら Step 2 を起動しない。

---

## 3. Step 2 の測定と判定（Step 1 合格時のみ）

13 seed × 2 条件 = 26 学習 run、40 epoch、幅 `WIDTH_LADDER[-1] = 224`、学習条件は QE1S2 / QE1S4 と同一。estimand は
`d_s = top1_abs_share_s(zipf) − top1_abs_share_s(sqrt2048)`、
主指標 `mean(d_s)`、`ttest_rel` 両側 `α = 0.05`、Holm `m = 1`、`MDE = t.ppf(.975,12) × se`、90% CI。
`Δ / se / t / p / n / MDE / CI` に加え、per-seed 差の中央値・最大絶対差・上位 1% 寄与率を記録する。

解釈は次に限定する。棄却された場合は「この testbed で copy 統計を揃えた後も `top1_abs_share` に差が残った」とし、**裾の形状の効果**として読む。非棄却なら `n.s.` と MDE を書く。いずれ也具有一般性・Q-E の解決・QE1S2 T3 の再解釈を主張しない（QE1S4 §3 を継承）。

---

## 4. 限界

1. `sqrt` 写像は支持集合も変える（12,000 → 2,048）。通過しても「純粋な頻度分布の効果」ではなく、**支持と裾形状の合成効果**である。
2. `H_emp` は copy 位置の `next_tok` の周辺経験分布のエントロピーで、真の条件付きエントロピーでも性能下限でもない。
3. 事前調査は `seed = 0`・`n_seq = 1000` の探索的計算であり、Step 1 の 4,000 系列・校正 gate の結果ではない。設計入力に使うが確認的判定には混ぜない。
4. C3 / C5 / C6 は線形分散分解で交互作用を測らない。
5. 1 testbed・1 課題・13 seed（Step 2 実行時）。保留 1 と Z1 §4 規則 3 は維持する。
6. QE1S4 の K=180 / C4 を事後変更しない。QE1S4 の停止は妥当だったとして扱う。

---

## 5. 再現

```powershell
$p = "C:\Users\gochu\.workbuddy-ai\binaries\python\envs\gpu\Scripts\python.exe"
$wd = "C:\Users\gochu\WorkBuddy AI\不均一MoE"
$env:PYTHONIOENCODING = "utf-8"
Set-Location $wd
& $p "_md_check.py" "$wd\QE1S5課題設計書_copy統計を揃えたsqrt圧縮支持でT3を再検定する_20261116.md"
```

**実装メモ**: `qe1_make_task.py` の既定経路は 1 行も書き換えない。`sqrt` 写像は `qe1s5_step1.py` 側で ident 配列を作り、既存 `QE1Corpus` へ渡すか、New ID の generator option として追加する。いずれにせよ既定の `make_task` 出力は QE1S3 / QE1S4 の保存配列と `maxdiff 0` を C1 で確認する。

---

## 追記（2026-11-16）: Step 1 は C3 未達で停止、C4 は達成

- `qe1s5_step1.py` を `seed=0`, 両条件 4,000 系列で実行。`P_rule(copy)` は zipf `0.22360523` 対 sqrt2048 `0.22460240`（差 `+0.00099717`）で C4 pass。一方 `H_emp` は `5.19269781` 対 `5.08016359`、`ΔH = −0.11253422` が許容 `0.10` を超過し C3 fail。C1 / C2 / C5 / C6 / C7 / C8 は pass。
- 独立検算 `_qe1s5_verify.py` は 34 項目・0 不一致。走行前停止規則どおり Step 2 の 26 run と T3 確認的検定は実行しない。
- 初期実装で ident / syntax の RNG 定数をハードコードし C2 が落ちたが、QE1S4 の `QE1S4_IDENT_STREAM_OFFSET = 11000` / `QE1S4_SYNR_STREAM_OFFSET = 12000` を import して修正した。設計の stream 定義は変更していない。
- 詳細は `検証報告_QE1S5S1_copy統計は揃ったがエントロピー差0.113が閾値超過でT3停止_20261116.md`。K=2048 は事後変更していない。
