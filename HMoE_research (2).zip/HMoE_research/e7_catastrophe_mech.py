# -*- coding: utf-8 -*-
"""e7_catastrophe_mech.py — 壊したステップの所在（どのモジュールが動いたか）。

診断で「壊滅は最終 epoch の 1 ステップ」と分かった。本スクリプトは per-group の
パラメータ更新量を測り、破壊が
  - 記憶（ffn / emb / head）
  - 経路（router / attn）
のどちらで起きるかを特定する。

ラン: wb3_s7（壊滅・再現確認込み）と wb3_s0（健全コントロール）の 2 本。
"""
import json
import os
import time

import torch

from e7_stabilize_task import run, make_lookup_table

HERE = os.path.dirname(os.path.abspath(__file__))
DEV = "cuda" if torch.cuda.is_available() else "cpu"
tab = make_lookup_table(64)
CFG = dict(L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)), d=64, epochs=60)
SPEC_FREE = dict(route="free", router="linear", stab="entropy", extra="tokid")

RUNS = {"wb3_s7": (7, 3.0), "wb3_s0": (0, 3.0)}
out = {}
t0 = time.time()
for name, (seed, wb) in RUNS.items():
    r = run("sp_wb3_w10", seed, table=tab, device=DEV, spec=SPEC_FREE,
            lam_cost=0.15, ent_beta=0.05, warmup=10, warm_bias=wb, lam_post=0.15,
            trace=True, **CFG)
    tr = json.loads(r["trace"])
    out[name] = {"result": {k: v for k, v in r.items() if k not in ("trace", "probe_log")},
                 "trace": tr}
    print(f"[{name}] CE {r['ce_all']:.4f}  FFN {r['ffn_cost']:.3f}  ({time.time()-t0:.0f}s)",
          flush=True)

json.dump(out, open(os.path.join(HERE, "e7_catastrophe_mech.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)

COLS = ["val_ce", "ce_rr", "dparam_l2", "dparam_max", "d_emb", "d_attn", "d_router", "d_ffn",
        "d_head", "gnorm_router"]
for name, d in out.items():
    print(f"\n-- {name} --  ep " + " ".join(f"{c[:10]:>10s}" for c in COLS))
    for rec in d["trace"]:
        if rec["epoch"] >= 45:
            print(f"      {rec['epoch']:3d} " + " ".join(
                "      None" if rec.get(c) is None else f"{rec[c]:10.4f}" for c in COLS))

print("\n=== 更新量の比（epoch 末の 1 epoch 分, ep50 以降の平均） ===")
for name, d in out.items():
    tr = [x for x in d["trace"] if x["epoch"] >= 50 and x.get("d_ffn") is not None]
    tot = {k: sum(x[f"d_{k}"] for x in tr) / len(tr) for k in ("emb", "attn", "router", "ffn", "head")}
    print(f" {name}: " + "  ".join(f"{k} {v:.2f}" for k, v in tot.items()))
