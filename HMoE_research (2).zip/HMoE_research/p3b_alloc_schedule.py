"""
P3b: 層ごとに削減率を変える（非一様配分）— HMoE の「不均一」を推論時スケジューリングに落とす

問い:
  P3 で「後半 8 層 (8-15) の top-7 は前半 8 層 (0-7) の 1.66 倍高くつく」と分かった。
  ならば **同じ計算予算（削る Expert スロット数の合計）で、前半を深く・後半を浅く削る**方が
  品質が良いはず。それを直接測る。

予算の単位:
  Expert の FLOPs は層あたり k × 2 × 3 × d × d_ff に比例し、d と d_ff は全層で同じ。
  よって **1 トークンあたりの「削ったスロット数」の合計** が計算予算そのもの。
  uniform top-7 = 16 スロット削減。前半 top-6 / 後半 top-8 = 8×2 + 8×0 = 16 スロット。同予算。

出力:
  p3b_alloc_summary.json / p3b_alloc_by_lang.csv / p3b_alloc_pareto.png

実行:
  python p3b_alloc_schedule.py --windows 24 --len 256
"""

import argparse
import json
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

from p3_topk_quality_olmoe import load_corpus

HERE = os.path.dirname(os.path.abspath(__file__))


def log(msg):
    print(msg, flush=True)


def parse_range(s, n_layers):
    s = s.strip()
    if s in ("all", "*"):
        return list(range(n_layers))
    out = []
    for part in s.split("+"):
        part = part.strip()
        if "-" in part:
            a, b = part.split("-")
            out.extend(range(int(a), int(b) + 1))
        elif part:
            out.append(int(part))
    return out


def parse_alloc(spec, n_layers, full_k):
    """'0-7:6,8-15:8' -> {layer: k}。書かれていない層は full_k。"""
    d = {i: full_k for i in range(n_layers)}
    for part in spec.split(","):
        part = part.strip()
        if not part:
            continue
        rng, kk = part.split(":")
        for i in parse_range(rng, n_layers):
            if 0 <= i < n_layers:
                d[i] = int(kk)
    return d


def paired_stats(a, b):
    d = np.asarray(a, dtype=np.float64) - np.asarray(b, dtype=np.float64)
    n = d.size
    m = float(d.mean())
    sd = float(d.std(ddof=1)) if n > 1 else float("nan")
    se = sd / np.sqrt(n) if n > 1 else float("nan")
    return {"mean": m, "se": se, "t": m / se if se and se > 0 else float("nan"),
            "n": int(n), "ci95": [m - 1.96 * se, m + 1.96 * se] if se and se > 0 else None}


# 比較する配分（すべて 1 トークンあたりの削減スロット数で予算を揃えてある）
DEFAULT_ALLOCS = [
    ("base", "all:8", "uniform top-8（基準）"),
    ("u7", "all:7", "uniform top-7（予算 16）"),
    ("f6b8", "0-7:6,8-15:8", "前半 top-6 / 後半 top-8（予算 16・前重み）"),
    ("f8b6", "0-7:8,8-15:6", "前半 top-8 / 後半 top-6（予算 16・後重み＝対照）"),
    ("f7b8", "0-7:7,8-15:8", "前半 top-7 / 後半 top-8（予算 8）"),
    ("f8b7", "0-7:8,8-15:7", "前半 top-8 / 後半 top-7（予算 8・対照）"),
    ("f6b7", "0-7:6,8-15:7", "前半 top-6 / 後半 top-7（予算 24・前重み）"),
    ("f7b6", "0-7:7,8-15:6", "前半 top-7 / 後半 top-6（予算 24・対照）"),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--seed", type=int, default=11, help="P3 と同じスライスを使う")
    ap.add_argument("--allocs", type=str, default=None,
                    help="';' 区切りの 'label=spec' で上書き（例 'a=all:7;b=0-7:6,8-15:8'）")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    args = ap.parse_args()

    if args.allocs:
        allocs = []
        for item in args.allocs.split(";"):
            item = item.strip()
            if not item:
                continue
            lab, spec = item.split("=", 1)
            allocs.append((lab.strip(), spec.strip(), spec.strip()))
    else:
        allocs = DEFAULT_ALLOCS
    if args.smoke:
        allocs = allocs[:3]
        args.windows = 1

    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[1/5] loading model")
    t0 = time.time()
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      loaded in %.0f s" % (time.time() - t0))

    n_layers = int(model.config.num_hidden_layers)
    full_k = int(model.config.num_experts_per_tok)
    d_model = int(model.config.hidden_size)
    d_ff = int(model.config.intermediate_size)
    gates = [layer.mlp.gate for layer in model.model.layers]
    log("      layers=%d full_k=%d d=%d d_ff=%d" % (n_layers, full_k, d_model, d_ff))

    log("[2/5] corpus")
    rng = np.random.RandomState(args.seed)
    seqs, lang_of = [], []
    for lang in ("en", "ja"):
        txt = load_corpus(lang)
        ids = tok(txt, return_tensors="pt", add_special_tokens=False).input_ids[0]
        need = args.windows * args.len
        start = 0 if ids.numel() < need else int(rng.randint(0, ids.numel() - need))
        block = ids[start:start + need]
        for w in range(args.windows):
            seqs.append(block[w * args.len:(w + 1) * args.len])
            lang_of.append(lang)
        log("      %s: using [%d, %d)" % (lang, start, start + need))
    lang_arr = np.array(lang_of)
    log("      %d windows x %d tokens" % (len(seqs), args.len))

    def run_alloc(alloc):
        for i, g in enumerate(gates):
            g.top_k = alloc[i]
        nll_c, a1_c = [], []
        t_start = time.time()
        with torch.no_grad():
            for ids in seqs:
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                lg = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll_c.append(F.cross_entropy(lg, tgt, reduction="none").float().cpu().numpy())
                rank = (lg > lg.gather(1, tgt.unsqueeze(-1))).sum(dim=-1) + 1
                a1_c.append((rank == 1).float().cpu().numpy())
                del out, lg, rank
        return np.concatenate(nll_c), np.concatenate(a1_c), time.time() - t_start

    log("[3/5] running allocations")
    res = {}
    for lab, spec, desc in allocs:
        alloc = parse_alloc(spec, n_layers, full_k)
        nll, a1, dt = run_alloc(alloc)
        res[lab] = {"nll": nll, "acc1": a1, "alloc": alloc, "spec": spec, "desc": desc}
        mean_k = float(np.mean(list(alloc.values())))
        slots = (full_k - mean_k) * n_layers
        log("      %-6s CE %.5f  top1 %.4f  mean_k %.3f  slots_saved %.1f  (%.0f s)"
            % (lab, nll.mean(), a1.mean(), mean_k, slots, dt))

    log("[4/5] paired statistics")
    base = res["base"]["nll"] if "base" in res else res[allocs[0][0]]["nll"]
    base_a1 = res["base"]["acc1"] if "base" in res else res[allocs[0][0]]["acc1"]
    out = {"model": args.model, "seed": args.seed, "windows": args.windows,
           "window_len": args.len, "n_tokens": int(base.size),
           "full_k": full_k, "n_layers": n_layers, "results": {}}
    for lab, spec, desc in allocs:
        r = res[lab]
        alloc = r["alloc"]
        mean_k = float(np.mean(list(alloc.values())))
        row = {
            "desc": desc, "spec": spec, "alloc": {str(k): v for k, v in sorted(alloc.items())},
            "ce": float(r["nll"].mean()), "ppl": float(np.exp(r["nll"].mean())),
            "top1": float(r["acc1"].mean()),
            "mean_k": mean_k, "slots_saved": (full_k - mean_k) * n_layers,
            "flops_saved_frac": 1.0 - (mean_k * 3 * d_model * d_ff + 16.78e6 + 64 * d_model) /
                                     (full_k * 3 * d_model * d_ff + 16.78e6 + 64 * d_model),
            "per_lang": {},
        }
        for lang in ("en", "ja"):
            sel = (lang_arr == lang)
            ce_l = float(r["nll"].reshape(len(seqs), -1)[sel].mean())
            row["per_lang"][lang] = {"ce": ce_l, "ppl": float(np.exp(ce_l))}
        if lab != "base":
            row["delta_ce"] = paired_stats(r["nll"], base)
            row["ppl_ratio"] = float(np.exp(row["delta_ce"]["mean"]))
            row["delta_top1"] = paired_stats(r["acc1"], base_a1)
        out["results"][lab] = row

    with open(os.path.join(HERE, "p3b_alloc_summary.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    np.savez_compressed(os.path.join(HERE, "p3b_alloc_nll.npz"),
                        **{lab: res[lab]["nll"] for lab, _, _ in allocs},
                        **{lab + "_top1": res[lab]["acc1"] for lab, _, _ in allocs},
                        lang=lang_arr)
    with open(os.path.join(HERE, "p3b_alloc_by_lang.csv"), "w", encoding="utf-8") as fp:
        fp.write("label,spec,mean_k,slots_saved,ce,ppl,delta_ce,delta_se,delta_t,top1,dtop1,ce_en,ce_ja\n")
        for lab, spec, desc in allocs:
            r = out["results"][lab]
            d = r.get("delta_ce", {})
            dt1 = r.get("delta_top1", {})
            fp.write("%s,\"%s\",%.3f,%.1f,%.6f,%.4f,%s,%s,%s,%.5f,%s,%.6f,%.6f\n" % (
                lab, spec, r["mean_k"], r["slots_saved"], r["ce"], r["ppl"],
                ("%.6f" % d["mean"]) if d else "",
                ("%.6f" % d["se"]) if d else "",
                ("%.2f" % d["t"]) if d else "",
                r["top1"], ("%+.5f" % dt1["mean"]) if dt1 else "",
                r["per_lang"]["en"]["ce"], r["per_lang"]["ja"]["ce"]))

    log("")
    log("=== ALLOCATION COMPARISON (baseline CE %.5f, %d tokens) ===" % (base.mean(), base.size))
    log("%-7s %6s %6s %9s %8s %9s %8s  %s" % ("label", "mean_k", "slots", "CE", "dCE", "t", "top1", "desc"))
    for lab, spec, desc in allocs:
        r = out["results"][lab]
        d = r.get("delta_ce", {})
        log("%-7s %6.3f %6.1f %9.5f %8s %9s %8.4f  %s" % (
            lab, r["mean_k"], r["slots_saved"], r["ce"],
            ("%+.5f" % d["mean"]) if d else "  (base)",
            ("%+.1f" % d["t"]) if d else "", r["top1"], desc))
    log("")
    log("saved: p3b_alloc_summary.json / p3b_alloc_by_lang.csv")


if __name__ == "__main__":
    main()
