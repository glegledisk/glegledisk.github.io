# 不均一MoE・all-to-all・RLHW調査とシミュレーションまとめ

作成日: 2026-10-14  
対象: 不均一MoE専用チップ構想の技術批評から、HMoE-3B × MMLU の配置シミュレーションと追加感度分析まで

## 1. 要約

MoEの専門家ゲート計算そのものより、選ばれたexpertへtoken activationを運び、結果を戻すdispatch/combine通信、expert間の負荷偏り、expert重みの配置容量が大きな設計課題になる。したがって、チップ内NoCの改善だけでは、複数GPU・複数ノードのExpert Parallelism（EP）で生じるall-to-all通信を解消したとは言えない。

RLHW（ハードウェア認識ルーティング学習）は、通信・計算・負荷・電力などを考慮してrouter policyを学ぶ研究方向として有望である。ただしrouterを変えると品質とtoken経路も変わるため、品質制約つきの実推論が必要である。expert配置だけを変える段階では、routerと演算を保つ限り、品質は目的値ではなく維持条件として扱う。

今回の配置シミュレーションは実HMoE推論ではなく、**HMoE-3Bの1 MoE層を模した合成負荷**による探索である。基本モデルで50/50配置はイベント単位の通信パスコストを2.389%下げたが、実機のall-to-all時間やMMLUスコアの改善を示すものではない。さらに、同じGPUにある複数expertへのactivation転送を1回にまとめるかexpertごとに複製するかで、通信のみ最小解の計算偏りが大きく変わった。通信費用を実測していない段階では、配置の最終順位も確定できない。

**研究上の主な結論:** 最初に実モデルtraceと通信実装の粒度を確定し、実トポロジーでリンク別の実効帯域・起動遅延・競合を測る。その後、routerを固定した配置探索で物理的な効果を切り分け、最後にMMLU品質を制約としてRLHWと配置を共同探索する。

## 2. 問題設定と技術的背景

### 2.1 all-to-allが論点になる理由

MoE層では、routerがtokenごとにexpertを選ぶ。一般的なexpert-parallel実装では概ね次の通信が発生する。

1. **dispatch:** tokenのactivationを選択expertのrankへ送る。
2. **expert計算:** expertごとのFFNを実行する。
3. **combine:** expertの出力を元のtoken rankへ戻し、選択重みを反映して結合する。

複数rankが同時に送受信し、全rankが次段へ進むには遅いrankの完了を待つため、通信量の単純な合計だけではレイテンシを表せない。送信元・宛先、共有リンク、ノード間bisection帯域、起動遅延、競合、同期点、計算とのoverlapが効く。DeepSeek-V3の技術報告も、同社のGPU/NVLink/InfiniBand構成においてcross-node all-to-allと計算・通信overlapを扱っている。そこに示されるリンク比は特定構成の値であり、他環境へ一般化できない。

### 2.2 チップ構想への含意

添付の批評文書が挙げる欠落点のうち、本調査では次を焦点にした。

- **チップ内NoCとクラスタ通信の分離:** チップ上の配線・ルーターを高速化しても、GPU間・ノード間のEP通信が残る。単一チップ内MoEとクラスタ上MoEを同じ通信モデルで論じない。
- **ゲート計算とデータ移動の分離:** gateのスコア計算を速くしても、選択後のactivation移動、宛先expertの待ち、combineの同期が支配的ならend-to-end性能は大きく変わらない。
- **容量・計算・通信の共同設計:** 不均一expertはFFN計算量と重み容量を変える。配置では、GPUごとの重み容量、expert処理時間、token負荷、通信先の局所性を同時に見る必要がある。
- **RLHWの環境依存性:** 特定トポロジー向けに学習したrouterは別GPU配置へそのまま移植できない可能性がある。品質を保つ制約と、別トポロジーでの再評価が必要。

### 2.3 HMoE-3BとMMLU

HMoE論文の3B構成は12 Transformer blocks、各MoE層に8 experts、1層あたりのexpert hidden width合計32,768で、expert幅は等差数列で構成される。従って、全モデルには12×8=96個のlayer-expert instanceがある。今回の初期探索はそのうち**1層の8 expertsを配置テンプレートとして切り出したもの**で、96 instanceの共同配置ではない。[HMoE論文](https://aclanthology.org/2025.emnlp-main.1115.pdf)

同論文はHMoE-3BのMMLUを24.57、比較対象のMoE-3Bを24.00と報告する一方、計算予算の小ささに伴う評価の変動にも注意を促している。24.57は論文の報告値であり、今回の合成シミュレーションで再評価した値ではない。MMLUは57分野を含む多肢選択ベンチマークだが、実際のtoken数・MoE呼び出し数はfew-shot設定、評価ハーネス、選択肢の尤度評価か生成評価かに依存する。[MMLU論文](https://arxiv.org/abs/2009.03300)

## 3. RLHWとトポロジーエンジニアリング

### 3.1 配置だけを変える段階

router、expert重み、精度、結果を結合する演算が保たれるなら、expert配置は主に実行時間・メモリ位置を変える。理想的な数値同値を仮定すればMMLUスコアは配置間で同じになるため、精度を最大化する目的だけでは配置を選べない。配置探索は、品質を保つ条件の下でレイテンシやthroughputを最適化する。

ただし、実カーネルで演算順・精度・overflow挙動が変われば、境界的な多肢選択回答が変わる可能性は残る。配置だけでも、候補解の品質を同一評価設定で確認する。

### 3.2 RLHWと配置を共同探索する段階

router policyを変更すると、どのexpertがどのtokenを処理するか自体が変わる。従って、配置コストを低くするだけのrewardでは不十分で、品質を制約に置く。

```text
minimize   measured_latency(placement p, router policy π)
subject to MMLU57(p, π) >= S_ref - δ
           per-GPU expert weights and runtime memory <= available memory
```

`S_ref`は同一checkpoint・同一MMLU評価ハーネスで得たローカル基準値。`δ`は許容する品質差と測定誤差に基づいて事前に定める。論文値24.57を別checkpoint・別評価環境の制約値として流用しない。品質判定では57分野の平均だけでなく分野別退行も見て、探索データと最終確認データを分ける。

routerを変えた後の層別経路は、もとのtraceを並べ替えるだけでは再現できない場合がある。前段のrouter変更でhidden stateが変わり、後段のrouter判断も変わり得るため、最終品質確認には候補policyを実際に推論する必要がある。

### 3.3 HMoE特有のトポロジー目的

配置問題はexpertをGPUへ割り当てるだけでなく、MMLU subjectや推論phaseごとのルート頻度を使った重み付きハイパーグラフ分割として定式化できる。

- **expertのノード間局所性:** 同時選択・高頻度のexpert群を同じノード内へ置き、遠隔通信を抑える。ただし通信実装がexpertごとにactivationを複製するか、rank宛てにまとめるかを反映する。
- **GPU内の負荷・容量制約:** expert幅はFFN計算量と重み容量に関係する。重みを置けることだけでなく、各microbatchでの実測expert処理時間と待ち時間を均す。
- **階層最適化:** まずexpertをノードへ割り当て、次に各ノード内のGPUへ割り当てる。実際のNVLink/PCIe/NIC/スイッチ結線、GPU/NIC親和性、ノード間bisection帯域をグラフとして扱う。
- **負荷変動への対応:** MMLU全体平均だけでなく、分野別・prefill/decode別・batch size別にルート分布を評価し、ある分野やhot expertが一つのrankに集中する配置を避ける。

## 4. 初期シミュレーションの仕様

| 項目 | 設定 | 意味・制限 |
|---|---|---|
| 対象 | HMoE-3Bの1 MoE層、8 experts | 12層・96 layer-expert全体の最適化ではない |
| expert幅 | 2304, 2816, 3328, 3840, 4352, 4864, 5376, 5888 | 合計32,768。論文構成をもとにした幅テンプレート |
| topology | 4 GPU、2ノード。GPU0/1とGPU2/3がそれぞれ同一ノード | 実機のpeer間リンク行列やNIC競合は未測定 |
| event数 | 57分野×4合成batch×32 event = 7,296 event/layer | MMLUの設問数・実token数・実router traceではない |
| route数 | easy/medium/hardで1/2/3 expertsを固定選択 | Top-P風の合成仮定。実HMoE gateの挙動ではない |
| expert選択 | 難易度ごとに幅選好を設定 | 学習済みrouterの分野別分布ではない |
| source GPU | 基本ケースでは4 GPUへ一様分布 | source rank局在を再現した実traceではない |
| 容量 | 9,000 expert-width units/GPU/layer | 実VRAM byte数ではない |
| 通信コスト | 同一GPU=0、同一ノード別GPU=1、ノード間=3.2 | 相対コスト係数。起動遅延や実効帯域ではない |
| 計算偏り | 合成batch内のGPU別FFN幅仕事量のp95/完全均等時 | 幅に比例する仕事量proxy。実測GPU処理時間ではない |
| score | 全配置を公表MMLU 24.57に固定 | score不変という仮定。MMLUを実行していない |

4 GPUへの8 expert割り当て65,536通りを列挙し、容量制約を満たした192通りを比較した。目的は、LPT容量均衡配置を基準として、通信パスコストとp95計算偏りをそれぞれ基準値で正規化した加重和を最小化するものだった。

乱数seedは`20261014`で、生成されたroute eventのactive-expert setは92種類。これらは再現可能な合成値であり、学習済みHMoE routerのroute traceではない。

```text
J_w(p) = w * C_path(p) / C_path(LPT)
       + (1 - w) * I_p95(p) / I_p95(LPT)
```

ここで`C_path`はイベント単位のpeer転送コストproxyであってbytesや通信時間ではない。`w=0.5`も物理単位から校正した値ではない。

## 5. 初期結果とPareto分析

### 5.1 主結果

| 配置方針 | p95計算偏り（理想=1） | パス単位/event/layer | LPT比のパス削減 | LPT比のp95変化 |
|---|---:|---:|---:|---:|
| LPT容量均衡 | 1.452827 | 6.801425 | — | — |
| 50/50通信・計算 | 1.452827 | 6.638925 | 2.389% | 0.0% |
| 通信のみ最小 | 1.526347 | 6.625768 | 2.583% | +5.061% |

50/50配置では通信コストを少し下げても、この合成設定ではLPTと同じp95計算偏りを保てた。通信のみ最小化による追加削減は小さい一方、幅ベースのp95偏りが増えた。

50/50選択配置のexpert割り当て:

```text
GPU0/N0 = E2(3328), E5(4864)
GPU1/N0 = E3(3840), E4(4352)
GPU2/N1 = E1(2816), E6(5376)
GPU3/N1 = E0(2304), E7(5888)
```

比較用の配置テンプレートは次のとおり。

| 方針 | GPU0/N0 | GPU1/N0 | GPU2/N1 | GPU3/N1 |
|---|---|---|---|---|
| LPT | E0, E7 | E1, E6 | E2, E5 | E3, E4 |
| 50/50 | E2, E5 | E3, E4 | E1, E6 | E0, E7 |
| 通信のみ最小 | E3, E5 | E0, E4 | E1, E7 | E2, E6 |

LPTと50/50は各GPU幅8,192 unitsで均等。通信のみ最小ではGPU幅使用量が8,704 / 6,656 / 8,704 / 8,704となり、幅ベースの偏り増加と整合する。

HMoE-3Bは12 MoE層のため、全層が同じ負荷・配置を持つと仮定すれば数値を12倍できる。しかし、得られるのは仮定上のpath unitsであり時間ではない。層別traceも層間のGPUメモリ共有制約も本探索に含まれていない。

### 5.2 通信削減の内訳

50/50配置のイベントあたり往復peer transfer proxyは、ノード内が0.912829→0.911732（-0.12%）、ノード間が1.840186→1.789748（-2.74%）。ノード間係数3.2の設定では、パスコスト削減のほぼ全てがノード間項から来た。remote nodeに触れるeventの比率自体は74.12%→73.56%と0.56ポイント低下したに過ぎない。

### 5.3 非劣解

192配置を通信パスproxyとp95計算偏りでPareto選別すると、3つの非劣解が残った。

| 配置 | 通信/LPT | p95計算偏り/LPT | 解釈 |
|---|---:|---:|---|
| 50/50選択配置 | 0.976108 | 1.000000 | 計算側の最小偏りを保って通信2.389%減 |
| 中間配置 | 0.975786 | 1.007914 | 通信2.421%減、p95偏り+0.791% |
| 通信のみ最小 | 0.974173 | 1.050605 | 通信2.583%減、p95偏り+5.061% |

25%、50%、75%の通信重みで同じ配置が選ばれた。この結果は192個という離散候補と合成traceに限られる。重みは実機レイテンシから校正していないため、一般的な運用優先度を示すものではない。

![通信パスproxyとp95計算偏りのPareto比較](<C:/Users/gochu/WorkBuddy AI/不均一MoE/simulation_hmoe_mmlu/communication_pareto.png>)

## 6. 感度分析

### 6.1 ノード間相対コスト

ノード間/ノード内相対コストを1〜10へ変えても、50/50配置のイベントパス削減は1.872〜2.617%だった。通信のみ最小化では2.240〜2.733%削減したが、p95計算偏りは3.369〜5.060%悪化する条件があった。これは3.2一点だけへの過適合を弱めるが、帯域のみの係数なので起動遅延・競合を含む実レイテンシ順位の頑健性は示さない。

### 6.2 workload・source・幅容量

- 合成難易度比をeasy-heavy（24/6/2）からhard-heavy（2/6/24）へ変えると、50/50通信削減は1.847%から1.237%へ低下した。
- expert幅への選択バイアスを外すと削減は1.063%。全難易度で小expert寄りとすると、50/50選択ではパスコストが0.034%増え、計算偏り改善を選ぶケースがあった。
- source GPUを偏らせると削減は1.197%または0.267%となり、一様source前提の利得がほぼ消えるケースがあった。
- 合成幅容量を8,192から12,000へ緩めると実行可能配置は24から11,256へ増加。通信だけの最小削減は2.389%から9.491%へ増える一方、p95偏り悪化は最大24.080%になった。容量値はVRAM容量ではない。

難易度別の1/2/3 expert固定選択はrouter実測ではない。論文で報告されたARC-Easy/ARC-Challengeの平均activated-parameter ratioは20.23%/21.09%で、その差は0.86ポイント。今回の難易度proxyから実HMoEの選択数やMMLU挙動は推定できない。[HMoE論文](https://aclanthology.org/2025.emnlp-main.1115.pdf)

### 6.3 同一GPU宛て転送をまとめる仮定

現行proxyは、複数の選択expertが同じGPUにある場合、そのGPUへのactivation transferを一度にまとめる。expert単位にtokenを展開して送る代表的なdispatcher方式では、同じGPU内の二つのexpertへ別々のactivation copyを運ぶことがあり得る。NVIDIA Megatron-LMのdispatcher実装はexpertごとのrouting mapからtoken数を準備し、dispatchとcombineでall-to-allを行う例を示す。ただしHMoEの実際のdispatcherがこの方式だと確認したわけではない。[Megatron-LM token dispatcher](https://github.com/NVIDIA/Megatron-LM/blob/main/megatron/core/transformer/moe/token_dispatcher.py)

同じ合成traceを、GPU宛てdedupとexpertごとactivation copyの2通りで再評価した。

| 通信モデル | LPTパス単位/event | 50/50削減 | 通信のみ最小削減 | 通信のみ最小p95悪化 | Pareto解数 |
|---|---:|---:|---:|---:|---:|
| GPU宛てdedup（現行proxy） | 6.801425 | 2.389% | 2.583% | +5.061% | 3 |
| expertごとactivation copy | 7.493860 | 2.304% | 2.318% | +0.791% | 2 |

従って、50/50配置の通信削減率は2.3〜2.4%程度で近い一方、通信のみ最小配置の計算偏りは転送粒度の仮定で大きく変わった。両方ともevent-level route-transfer proxyで、bytes・collective起動数・実時間を測っていない。

## 7. 実時間モデルへ進むために必要な計測

### 7.1 通信指標の置き換え

実装とmicrobatchごとに、source rank `s`からdestination rank `d`へ送られるroute token数`n(s,d)`、payload bytes、active peer、送信回数、dispatch/combine時間を計測する。bytesはhidden size、dtype、expert routeの複製方法、padding/packing仕様に合わせて算出する。expertのFFN幅は主に計算量と重み容量を変える一方、activation payloadは通常、モデルhidden size・dtype・token数・route multiplicityに依存するため、expert幅をそのままnetwork bytesに置き換えない。

レイテンシproxyは少なくとも次の形にする。

```text
T_A2A ≈ max_rank critical_time(
    {n(src,dst), bytes(src,dst)},
    startup α, effective bandwidth B_eff,
    physical topology, link contention, queue wait
)
```

`α`をpeerごとに課すかcollectiveごとに課すかはdispatcher/NCCL等の実装に合わせる。all-to-allは全rankが完了するまでのcritical pathであり、peer転送費用を単純合計した値を通信時間とみなさない。microbatch payload size、fan-out、同時rank数を振って`α`と`B_eff`を測り、通信とexpert計算のoverlap後に残る時間も測る。

### 7.2 MMLU traceと品質評価

記録単位は問題単位だけでなく、少なくともsubject・問題ID・評価phase・microbatch・layer・source rank・router logits/probabilities・selected expert IDs・選択数・expertごとのtoken数・dispatch/combine bytes・expert処理時間を結び付ける。実際の評価ハーネス、few-shot prompt、選択肢スコア方式、batchingを固定する。router policyを変える候補は実推論を行い、元traceの再生だけでscore維持を主張しない。

## 8. 推奨する実験順序

1. **基準を固定:** HMoE-3B Top-P checkpointとMMLU評価コードを固定し、同一条件で`S_ref`、57分野別score、token/layer router traceを記録する。
2. **通信を校正:** 使用予定の複数GPU・複数ノードでtopologyを記録。payload/fan-outごとにpeer帯域・起動遅延を測り、同時all-to-allの競合と完了時間を測る。
3. **router固定で配置探索:** LPT、node-aware、trace-aware配置を比較し、scoreが維持されることを確認。ここで配置だけの効果を因果的に切り分ける。
4. **RLHWを追加:** 固定router baselineを超える候補を、`MMLU57 >= S_ref - δ`とメモリ制約の下で探索する。最終評価は探索に使っていない問題/分割でも行う。
5. **実サービス指標で判定:** p50/p95 latency、throughput、per-rank load、A2A bytes/time、GPU利用率、電力が必要なら電力、全体と分野別品質を報告する。

## 9. 実験実施状況と限界

2026-10-14時点の環境確認では、このworkspaceと既知のHugging Face/Torch cache、DownloadsにHMoE-3B checkpointが見つからなかった。利用可能なGPUはRTX 4060が1基（報告メモリ8,188 MiB）、PyTorchは`2.14.0+cpu`で、複数GPU/ノード間all-to-allを測る構成ではなかった。そのため、ここまでに実行できたのは合成配置シミュレーションとその感度比較までである。実trace、実効帯域`B_eff`、起動遅延`α`、MMLU再評価、RLHW共同探索は未実施。

今回の数値から言える範囲:

- 指定した1層合成設定では、expert配置の変更でevent-level通信パスproxyを約2.3〜2.4%減らす解があった。
- 通信だけの最小化は計算偏りとのtradeoffを作る。ただしtradeoffの大きさはactivation転送粒度の仮定に依存した。
- source GPU分布、expert選択相関、GPU間/ノード間比、容量制約を実データへ置き換えない限り、実際の勝ち配置は特定できない。
- 実時間改善、MMLU score向上、消費電力、全12層の最適配置を示したものではない。

## 10. 生成した関連ファイル

- 詳細考察: [simulation_deep_dive.md](<C:/Users/gochu/WorkBuddy AI/不均一MoE/simulation_hmoe_mmlu/simulation_deep_dive.md>)
- 初期配置結果: [simulation_report.md](<C:/Users/gochu/WorkBuddy AI/不均一MoE/simulation_hmoe_mmlu/simulation_report.md>)
- 配置別CSV: [placement_scenarios.csv](<C:/Users/gochu/WorkBuddy AI/不均一MoE/simulation_hmoe_mmlu/placement_scenarios.csv>)
- 感度分析CSV: [sensitivity_results.csv](<C:/Users/gochu/WorkBuddy AI/不均一MoE/simulation_hmoe_mmlu/sensitivity_results.csv>)
- 転送粒度比較CSV: [communication_model_sensitivity.csv](<C:/Users/gochu/WorkBuddy AI/不均一MoE/simulation_hmoe_mmlu/communication_model_sensitivity.csv>)
- 転送粒度比較スクリプト: [communication_model_sensitivity.py](<C:/Users/gochu/WorkBuddy AI/不均一MoE/simulation_hmoe_mmlu/communication_model_sensitivity.py>)
- tradeoff図: [communication_pareto.png](<C:/Users/gochu/WorkBuddy AI/不均一MoE/simulation_hmoe_mmlu/communication_pareto.png>)
- 実験準備状況: [next_experiment_readiness.md](<C:/Users/gochu/WorkBuddy AI/不均一MoE/simulation_hmoe_mmlu/next_experiment_readiness.md>)
- 元の批評文書: [critical_review_不均一MoE専用チップ構想.md](<C:/Users/gochu/WorkBuddy AI/不均一MoE/critical_review_不均一MoE専用チップ構想.md>)

## 参考資料

1. Wang et al., [HMoE: Heterogeneous Mixture of Experts for Language Modeling](https://aclanthology.org/2025.emnlp-main.1115.pdf), EMNLP 2025.
2. Hendrycks et al., [Measuring Massive Multitask Language Understanding](https://arxiv.org/abs/2009.03300), ICLR 2021.
3. NVIDIA, [Megatron-LM MoE token dispatcher implementation](https://github.com/NVIDIA/Megatron-LM/blob/main/megatron/core/transformer/moe/token_dispatcher.py). Expert-parallel all-to-all実装の一例。HMoE実装と同一とは限らない。
4. DeepSeek-AI, [DeepSeek-V3 Technical Report](https://arxiv.org/abs/2412.19437). cross-node MoE通信と同社hardware topologyの実例。通信倍率を一般化する根拠には使わない。
5. Luo et al., [HEXA-MoE: Efficient and Heterogeneous-aware MoE Acceleration with ZERO Computation Redundancy](https://arxiv.org/abs/2411.01288). ソフトウェア側の不均一expert最適化に関する関連研究。
