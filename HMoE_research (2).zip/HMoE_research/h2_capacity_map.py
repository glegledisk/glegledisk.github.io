"""H2: 「容量の限界価値」の 2 次元マップ（マスク率 t × 位置の難易度）。

文書 §2.2 仮説 1「確信度の高い位置は小さい expert で済ませる」が成立するには、
 (i) 容量を増やしたときの利得が (t, 位置) で大きく変動し（＝配分の余地がある）、
 (ii) その変動が t から読める（＝exogenous な信号がある）
の両方が要る。P4 は (ii) を隠れ状態について否定した。ここでは (i) を測る。

方法: 一様幅 s の expert で訓練したモデルを 4 本作り、CE を (t ビン × 難易度) の
セルごとに測る。セルごとの dCE/dwidth が「容量の限界価値」。

  dCE/dwidth(cell) が セル間で大きく違う → 配分の余地が大きい
  どのセルでも同じ → 配分しても得しない（均等配分が最適）
"""
import argparse
import json
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

import h1_hybrid_testbed as H

HERE = os.path.dirname(os.path.abspath(__file__))
BUCKETS = [(0.0, 0.25), (0.25, 0.5), (0.5, 0.75), (0.75, 1.01)]


def train(s, b, seed, steps, d=128, nh=4, nlay=4, d_ff=256, bs=64, lr=3e-3):
    torch.manual_seed(seed)
    np.random.seed(seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    T1, T2 = H.make_task()
    T1c, T2c = T1, T2
    T1, T2 = T1.to(dev), T2.to(dev)

    model = H.Net(d, nh, nlay, d_ff, [s] * 8, 2, 0.0).to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda k: min(1.0, k / max(1, steps * 0.05)))
    am = ~H.block_mask(H.SEQ, b).to(dev)
    gen = torch.Generator(device="cpu").manual_seed(seed * 77 + 1)

    for _ in range(steps):
        x = H.gen_batch(bs, T1c, T2c, gen).to(dev)
        loss, cost, aux = H.diff_loss(model, x, am, gen)
        opt.zero_grad(set_to_none=True)
        (loss + 0.01 * aux).backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()

    xv = H.gen_batch(512, T1c, T2c, torch.Generator().manual_seed(7)).to(dev)
    return model, xv, am


@torch.no_grad()
def ce_map(model, xs, am):
    g = torch.Generator().manual_seed(31337)
    hard = torch.tensor([(t % H.HARD_EVERY == 0 and t >= 2) for t in range(H.SEQ)]).to(xs.device)
    acc = {}
    for _ in range(8):
        t = 0.1 + 0.9 * torch.rand(xs.shape[0], 1, generator=g)
        m = torch.rand(xs.shape[0], H.SEQ, generator=g) < t
        m[:, -1] = True
        m, tt = m.to(xs.device), t.to(xs.device)
        inp = torch.where(m, torch.full_like(xs, H.MASK_ID), xs)
        logits, _, _, _, _ = model(inp, am)
        ce = F.cross_entropy(logits.reshape(-1, H.V), xs.reshape(-1),
                             reduction="none").view(-1, H.SEQ)
        for bi, (lo, hi) in enumerate(BUCKETS):
            mb = m & (tt >= lo) & (tt < hi)
            for kind, sp in (("hard", hard), ("easy", ~hard)):
                sel = mb & sp.unsqueeze(0)
                if sel.any():
                    acc.setdefault(f"{lo:.2f}|{kind}", []).append(float(ce[sel].mean()))
    return {k: float(np.mean(v)) for k, v in acc.items()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--b", type=int, default=16)
    ap.add_argument("--steps", type=int, default=2000)
    ap.add_argument("--widths", default="0.5,0.75,1.0,1.5")
    ap.add_argument("--seeds", default="0,1")
    ap.add_argument("--out", default="h2_capacity_map.jsonl")
    a = ap.parse_args()

    out = os.path.join(HERE, a.out)
    if os.path.exists(out):
        os.remove(out)
    for s in [float(x) for x in a.widths.split(",")]:
        for seed in [int(x) for x in a.seeds.split(",")]:
            t0 = time.time()
            model, xv, am = train(s, a.b, seed, a.steps)
            m = ce_map(model, xv, am)
            rec = dict(width=2 * s, s=s, b=a.b, seed=seed, steps=a.steps, ce=m,
                       sec=time.time() - t0)
            print(json.dumps(rec, ensure_ascii=False), flush=True)
            with open(out, "a", encoding="utf-8") as fp:
                fp.write(json.dumps(rec, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
