#!/usr/bin/env python3
"""K5: 「収束しても解けない課題」を作り、教師 HMoE と等計算量 dense の差が出るかを見る。

なぜ 2 仮説を同時に試すか
  K1〜K4 で、書き換え課題もトレース課題も 16 epoch で飽和し、収束後は教師と生徒が一致した。
  難度のノブとして「訓練予算」と「Bayes 余裕」は否定済み。残る候補は 2 つで、機構が違う:

    A. 1 トークンあたりの計算を深くする（lag-2 漸化式: v_s = op(v_{s-1} + v_{s-2})）
       → 4 層で届かない「深さ」を作る。**幅ではなく深さ**の話。
    B. 隠れプログラムを K 個持たせる（プログラム ID だけ与え、op 列は見せない）
       → 1 つの dense FFN が K 個の写像を共有する必要がある。**容量**の話。
       MoE の前提（パラメータを増やすと多くの知識を保持できる）を直接突くのはこちら。

タスク（両仮説を同じ生成器で）
  pos 0                : プログラム ID（0..K-1）— **op 列は見せない**
  pos 1..ndig          : v0 の桁
  pos 1+ndig..         : v1 の桁（lag=2 のみ）
  pos 1+ndig*lag       : ':' 区切り
  以降 steps × (1+ndig): '=' + 値の桁

  lag=1: v_s = op_s(v_{s-1})
  lag=2: v_s = op_s(v_{s-1} + v_{s-2})
  op はプログラム ID で決まる（A=+1 / S=-1 / D=×2 / M=×3、mod 10^ndig）

  **op トークンを見せないのが要点。** 見せるとモデルは直前の op を読むだけでよく、
  「どのプログラムか」を保持する必要がない（＝容量を測れない）。

出力: k5_results_<tag>.json / k5_out_utf8_<tag>.txt
"""
import argparse
import json
import os
import sys
import time
from multiprocessing import Pool

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import e2b_rewrite_routing_fixed as E2  # noqa: E402
# T=108（lag=2, 8 桁, 10 命令）が入るよう位置埋め込みを広げる。
# 95 → 128 で pos.w が +33×128 = 4,224 パラメータ増える（両アーム共通なので比較は公平）。
E2.SEQ = 128

LOG = os.path.join(HERE, "k5_out_utf8.txt")
D_MODEL, N_LAYERS = 128, 4

DIG = "0123456789"
VOCAB = DIG + "=:" + "ABCDEFGHIJKLMNOP"     # 28 文字（モデルの head は 29）
C2I = {c: i for i, c in enumerate(VOCAB)}
NV = len(VOCAB)
ID_EQ, ID_SEP = C2I["="], C2I[":"]
ID_PROG0 = C2I["A"]                          # プログラム ID は A..P の 16 枠


def log(msg):
    print(msg, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(msg + "\n")


def macs(W, E):
    return N_LAYERS * (4 * D_MODEL * D_MODEL + 2 * D_MODEL * W + D_MODEL * E)


def make_programs(nprog, steps, seed=12345):
    """(nprog, steps) の op コード列。0=A(+1) 1=S(-1) 2=D(x2) 3=M(x3)。"""
    rng = np.random.default_rng(seed)
    return rng.integers(0, 4, size=(nprog, steps)).astype(np.int64)


def apply_op(v, code):
    return np.where(code == 0, v + 1,
                    np.where(code == 1, v - 1,
                             np.where(code == 2, v * 2, v * 3)))


def make_batch(rng, n, lag, nprog, steps, ndig, progs):
    MOD = 10 ** ndig
    T0 = 1 + ndig * lag + 1
    T = T0 + steps * (1 + ndig)
    seq = np.zeros((n, T), dtype=np.int64)
    typ = np.zeros((n, T), dtype=np.int64)
    pid = rng.integers(0, nprog, size=n) if nprog > 1 else np.zeros(n, dtype=np.int64)
    seq[:, 0] = ID_PROG0 + pid
    typ[:, 0] = 1
    v = [rng.integers(0, MOD, size=n).astype(np.int64) for _ in range(lag)]
    for j in range(lag):
        base = 1 + ndig * j
        for k in range(ndig):
            seq[:, base + k] = (v[j] // (10 ** (ndig - 1 - k))) % 10
    seq[:, 1 + ndig * lag] = ID_SEP
    typ[:, 1 + ndig * lag] = 1
    cur = v[-1]
    for s in range(steps):
        base = T0 + s * (1 + ndig)
        op = progs[pid, s]
        if lag == 1:
            cur = apply_op(cur, op) % MOD
        else:
            cur = apply_op((cur + v[-2]) % MOD, op) % MOD
            v = [v[-1], cur]
        seq[:, base] = ID_EQ
        typ[:, base] = 1
        for k in range(ndig):
            seq[:, base + 1 + k] = (cur // (10 ** (ndig - 1 - k))) % 10
            typ[:, base + 1 + k] = 2
    return seq, typ, T0


def worker(job):
    seed, lag, nprog, steps, ndig, seqs, epochs, n_eval, suf = job
    import torch
    import torch.nn.functional as F
    from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS

    torch.set_num_threads(1)
    t0 = time.time()
    progs = make_programs(nprog, steps)
    MOD = 10 ** ndig

    def loss_fn(logits, seq, T0):
        lg = logits[:, T0 - 1:-1, :NV].reshape(-1, NV)
        tgt = torch.from_numpy(seq[:, T0:]).reshape(-1)
        return F.cross_entropy(lg, tgt)

    @torch.no_grad()
    def ev(model, seq, typ, T0, bs=128):
        n = seq.shape[0]
        L = seq.shape[1] - T0
        ce = np.zeros((n, L), dtype=np.float32)
        hit = np.zeros((n, L), dtype=bool)
        wid = np.zeros((n, L), dtype=np.float32)
        dims = np.array(model.dims, float)
        for i in range(0, n, bs):
            s = slice(i, min(i + bs, n))
            x = torch.from_numpy(seq[s])
            logits, _aux, idx_l = model(x, aux_mode="none", need_idx=True)
            lg = logits[:, T0 - 1:-1, :NV]
            tgt = torch.from_numpy(seq[s, T0:])
            lp = F.cross_entropy(lg.reshape(-1, NV), tgt.reshape(-1),
                                 reduction="none").reshape(-1, L)
            ce[s] = lp.numpy()
            hit[s] = (lg.argmax(-1).numpy() == tgt.numpy())
            acc = np.zeros((s.stop - s.start, L), dtype=np.float32)
            for ti in idx_l:
                a = ti.numpy()[:, T0 - 1:-1, :]
                acc += dims[a].mean(-1)
            wid[s] = acc / len(idx_l)
        ty = typ[:, T0:]
        m_pl = (ty == 2)
        # 命令単位: 1 命令 = '=' + ndig 桁 → '=' を落として ndig 桁
        hp = hit.reshape(n, steps, 1 + ndig)[:, :, 1:]
        instr_ok = hp.all(-1)
        return {"ce_all": float(ce.mean()), "ce_payload": float(ce[m_pl].mean()),
                "acc_payload": float(hit[m_pl].mean()),
                "instr_acc": float(instr_ok.mean()),
                "instr_valid": float(instr_ok.all(-1).mean()),
                "width": float(wid.mean()),
                "ce_seq": ce.mean(1).astype(np.float64)}

    def train(model, aux_mode, auxw):
        torch.manual_seed(seed)
        rng = np.random.default_rng(2000 + seed)
        opt = Adam(model.params(), lr=2e-3)
        steps_n = max(1, seqs // 32)
        hist = []
        for ep in range(epochs):
            run = 0.0
            for _ in range(steps_n):
                s, _t, T0 = make_batch(rng, 32, lag, nprog, steps, ndig, progs)
                x = torch.from_numpy(s)
                logits, aux, _ = model(x, aux_mode=aux_mode)
                loss = loss_fn(logits, s, T0) + auxw * aux
                loss.backward()
                opt.step(model.params())
                run += float(loss.detach())
            hist.append(run / steps_n)
        return hist

    ev_rng = np.random.default_rng(777)
    seq, typ, T0 = make_batch(ev_rng, n_eval, lag, nprog, steps, ndig, progs)

    torch.manual_seed(seed)
    tm = RewriteMoE(WIDTHS["H+LB"], seed=seed)
    train(tm, "p_pen", 0.05)
    rt = ev(tm, seq, typ, T0)

    W = int(round(rt["width"]))
    torch.manual_seed(seed)
    sm = RewriteMoE([W], seed=seed, topk=1)
    train(sm, "none", 0.0)
    rs = ev(sm, seq, typ, T0)

    d = np.asarray(rs["ce_seq"]) - np.asarray(rt["ce_seq"])
    return {
        "seed": seed, "lag": lag, "nprog": nprog, "steps": steps, "ndig": ndig,
        "T": int(seq.shape[1]), "W_student": W,
        "teacher": {k: v for k, v in rt.items() if k != "ce_seq"},
        "student": {k: v for k, v in rs.items() if k != "ce_seq"},
        "macs_ratio": macs(rt["width"], 8) / macs(W, 1),
        "delta": float(d.mean()),
        "se_seq": float(d.std(ddof=1) / np.sqrt(len(d))),
        "t_seq": float(d.mean() / (d.std(ddof=1) / np.sqrt(len(d)))),
        "sec": round(time.time() - t0, 1),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", nargs="+", default=["lag2_k1", "lag1_k8"],
                    help="lag2_k1 / lag1_k8 / lag2_k8 など")
    ap.add_argument("--seeds", nargs="+", type=int, default=[0])
    ap.add_argument("--steps", type=int, default=10)
    ap.add_argument("--ndig", type=int, default=8)
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=16)
    ap.add_argument("--n_eval", type=int, default=2048)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--tag", type=str, default="pilot")
    args = ap.parse_args()

    suf = "_" + args.tag if args.tag else ""
    global LOG
    LOG = os.path.join(HERE, "k5_out_utf8%s.txt" % suf)
    if os.path.exists(LOG):
        os.remove(LOG)

    def parse(c):
        lag = int(c.split("_")[0].replace("lag", ""))
        k = int(c.split("_")[1].replace("k", ""))
        return lag, k

    jobs = []
    for c in args.configs:
        lag, k = parse(c)
        for s in args.seeds:
            jobs.append((s, lag, k, args.steps, args.ndig, args.seqs,
                         args.epochs, args.n_eval, suf))
    log("K5: 難度の 2 仮説（A=lag-2 で深く / B=隠れプログラム K 個で容量を圧迫）")
    log("configs=%s seeds=%s steps=%d ndig=%d epochs=%d"
        % (args.configs, args.seeds, args.steps, args.ndig, args.epochs))
    t0 = time.time()

    rows = []
    with Pool(processes=args.workers) as pool:
        for r in pool.imap_unordered(worker, jobs):
            rows.append(r)
            log("  lag%d k%-2d s%-2d T=%3d W=%3d  CE_t %.4f / CE_s %.4f  Δ %+.4f  "
                "instr_acc %.3f / %.3f  instr_valid %.3f / %.3f  (%.0fs)"
                % (r["lag"], r["nprog"], r["seed"], r["T"], r["W_student"],
                   r["teacher"]["ce_all"], r["student"]["ce_all"], r["delta"],
                   r["teacher"]["instr_acc"], r["student"]["instr_acc"],
                   r["teacher"]["instr_valid"], r["student"]["instr_valid"], r["sec"]))
            with open(os.path.join(HERE, "k5_partial%s.json" % suf), "w",
                      encoding="utf-8") as f:
                json.dump({"rows": rows}, f, ensure_ascii=False, indent=2, default=float)
    rows.sort(key=lambda r: (r["lag"], r["nprog"], r["seed"]))

    log("")
    log("== 難度の判定（教師の CE_payload が 0.03〜0.3 なら「余裕のある動作点」） ==")
    for r in rows:
        log("  lag%d k%-2d s%d: CE_payload %.4f  instr_acc %.3f  instr_valid %.3f  %s"
            % (r["lag"], r["nprog"], r["seed"], r["teacher"]["ce_payload"],
               r["teacher"]["instr_acc"], r["teacher"]["instr_valid"],
               "適正" if 0.03 <= r["teacher"]["ce_payload"] <= 0.3 else
               ("解けすぎ" if r["teacher"]["ce_payload"] < 0.03 else "難しすぎ")))
    log("  壁時計 %.0f 分" % ((time.time() - t0) / 60))

    with open(os.path.join(HERE, "k5_results%s.json" % suf), "w", encoding="utf-8") as f:
        json.dump({"rows": rows, "args": vars(args)}, f,
                  ensure_ascii=False, indent=2, default=float)
    log("[write] k5_results%s.json" % suf)
    os._exit(0)


if __name__ == "__main__":
    main()
