# -*- coding: utf-8 -*-
"""P12 解析: 振り分けの予測可能性（surface と model を分ける）

入力: p12_routing.jsonl
出力: p12_analysis.json / p12_analysis_out_utf8.txt

見るもの:
  (1) 各特徴の AUC（ブートストラップ CI 付き）
  (2) surface だけ / model だけ / 組み合わせ の振り分け曲線
  (3) oracle 回収率 = (予測器 − ランダム) / (oracle − ランダム)
"""

import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
RNG = np.random.RandomState(3)


def auroc(score, label):
    score = np.asarray(score, np.float64)
    label = np.asarray(label, bool)
    npos, nneg = int(label.sum()), label.size - int(label.sum())
    if npos == 0 or nneg == 0:
        return float("nan")
    order = np.argsort(score, kind="mergesort")
    ranks = np.empty(score.size, np.float64)
    ranks[order] = np.arange(1, score.size + 1)
    s = score[order]
    i = 0
    while i < s.size:
        j = i
        while j + 1 < s.size and s[j + 1] == s[i]:
            j += 1
        if j > i:
            ranks[order[i:j + 1]] = (i + j + 2) / 2.0
        i = j + 1
    return float((ranks[label].sum() - npos * (npos + 1) / 2) / (npos * nneg))


def boot_auc(x, y, n=2000):
    vals = []
    for _ in range(n):
        idx = RNG.randint(0, len(y), len(y))
        if len(np.unique(y[idx])) < 2:
            continue
        vals.append(auroc(x[idx], y[idx]))
    v = np.array(vals)
    return float(np.percentile(v, 2.5)), float(np.percentile(v, 97.5))


def main():
    probs = [json.loads(l) for l in open(os.path.join(HERE, "p12_routing.jsonl"), encoding="utf-8")]
    y = np.array([p["correct"] for p in probs], bool)
    n = y.size

    def z(v):
        v = np.asarray(v, float)
        return (v - v.mean()) / (v.std() + 1e-9)

    surface = (z(-np.array([p["ndigits"] for p in probs], float)) +
               z(-np.array([p["nprod"] for p in probs], float))) / 2
    model = (z(-np.array([p["H_last"] for p in probs])) +
             z(np.array([p["p_last"] for p in probs]))) / 2
    comb = (surface + model) / 2

    lines = []
    def emit(s=""):
        lines.append(s)
        print(s, flush=True)

    emit("=== P12 振り分けの予測可能性（n=%d, 乗算, thinking off）===" % n)
    emit("正解率 %.3f" % y.mean())
    emit("")
    out = {"n": int(n), "acc": float(y.mean())}

    emit("[0] 水準別の正解率")
    for lv in sorted(set(p["level"] for p in probs)):
        sel = np.array([p["level"] == lv for p in probs])
        emit("    %-5s n=%3d  acc=%.3f" % (lv, sel.sum(), y[sel].mean()))
        out.setdefault("per_level", {})[lv] = {"n": int(sel.sum()), "acc": float(y[sel].mean())}
    emit("")

    emit("[1] AUC（ブートストラップ 95% CI）")
    emit("%-38s %7s %18s" % ("特徴", "AUC", "95% CI"))
    feats = {
        "ndigits（桁数・小さいほど易）": -np.array([p["ndigits"] for p in probs], float),
        "nprod（部分積の数・少ないほど易）": -np.array([p["nprod"] for p in probs], float),
        "H_last（エントロピー・低いほど易）": -np.array([p["H_last"] for p in probs]),
        "H_mean（プロンプト平均・低いほど易）": -np.array([p["H_mean"] for p in probs]),
        "p_last（最後の p_top1・高いほど易）": np.array([p["p_last"] for p in probs]),
        "surface（2 特徴の z 平均）": surface,
        "model（2 特徴の z 平均）": model,
        "comb（4 特徴）": comb,
    }
    out["auc"] = {}
    for k, v in feats.items():
        a = auroc(v, y)
        lo, hi = boot_auc(v, y)
        emit("%-38s %7.3f [%6.3f,%6.3f]" % (k, a, lo, hi))
        out["auc"][k] = {"auc": a, "ci": [lo, hi]}
    emit("")

    emit("[2] 振り分け曲線（スコア上位 k% を高速経路へ）")
    emit("%6s %10s %10s %10s %10s %10s" %
         ("上位%", "surface", "model", "comb", "ランダム", "oracle回収率"))
    out["routing"] = {}
    for frac in (0.2, 0.3, 0.5, 0.75, 1.0):
        m = int(round(frac * n))
        row = {}
        for name, sc in (("surface", surface), ("model", model), ("comb", comb)):
            sel = np.argsort(-sc)[:m]
            row[name] = float(y[sel].mean())
        base = float(y.mean())
        # oracle: 易しい順に並べたときの上位 m の正解率（= 1.0 に近い）
        orc = float(np.sort(y.astype(int))[::-1][:m].mean())
        rec = (row["comb"] - base) / (orc - base) if orc > base else float("nan")
        emit("%6d %10.3f %10.3f %10.3f %10.3f %10.3f"
             % (int(frac * 100), row["surface"], row["model"], row["comb"], base, rec))
        row["random"] = base
        row["oracle"] = orc
        row["recovery"] = rec
        out["routing"]["%d" % int(frac * 100)] = row
    emit("")

    emit("[3] 参考: P4b の per-token コスト予測は AUC 0.55")
    emit("    予測 3 の閾値は AUC > 0.75。model 単独が届くかが見どころ。")

    with open(os.path.join(HERE, "p12_analysis.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2, default=float)
    with open(os.path.join(HERE, "p12_analysis_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(lines) + "\n")
    print("saved: p12_analysis.json / p12_analysis_out_utf8.txt")


if __name__ == "__main__":
    main()
