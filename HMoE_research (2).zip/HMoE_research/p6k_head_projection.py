# -*- coding: utf-8 -*-
"""p6k_head_projection.py — 乖離は LM head 方向に乗っているか

P6e で「位置依存は乖離の大きさでも向きでも先鋭化でもない」ことを示した。
残った本命の仮説:
    後半を削ると、隠れ状態の乖離が **LM head の読み出し方向に整列**する。
    前半を削ると、乖離は後続層で読み出しと無関係な部分空間へ回される。

測るもの（各トークン、各条件）:
  dh      = N_cond - N_base        （N は最終 RMSNorm 後、head 直前）
  p1      = <dh, w_{top1(base)}>   → base の top-1 トークンの logit 変化（予測）
  a1      = |p1| / (||dh|| ||w||)  → 読み出し方向への整列度（0〜1）
  q10     = ||{<dh, ŵ_i>}_{i in top10}|| / ||dh||  → 上位 10 本が張る部分空間への射影ノルム比
  dlogit  = logit_cond[top1_base] - logit_base[top1_base]  （実測。p1 と一致するはず）

出力: p6k_head_proj.npz / p6k_out_utf8.txt

実行:
  python p6k_head_projection.py --gpu-gib 7.5 --cpu-gib 12.0
"""

import argparse
import os
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


CONDS = [
    ("base", None, False),
    ("f6b8", "0-7:6,8-15:8", False),
    ("f6b8_rs", "0-7:6,8-15:8", True),
    ("f8b6", "0-7:8,8-15:6", False),
    ("f8b6_rs", "0-7:8,8-15:6", True),
]


def parse_alloc(spec, n_layers, full_k):
    ks = [full_k] * n_layers
    if not spec:
        return ks
    for part in spec.split(","):
        rng, k = part.split(":")
        k = int(k)
        if rng.strip() == "all":
            idx = range(n_layers)
        elif "-" in rng:
            a, b = rng.split("-")
            idx = range(int(a), int(b) + 1)
        else:
            idx = [int(rng)]
        for i in idx:
            ks[i] = k
    return ks


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--ids", type=str, default=os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"))
    ap.add_argument("--gpu-gib", type=float, default=7.5)
    ap.add_argument("--cpu-gib", type=float, default=12.0)
    ap.add_argument("--max-windows", type=int, default=0)
    args = ap.parse_args()

    import torch
    from transformers import AutoModelForCausalLM

    log("[1/3] loading %s" % args.model)
    t0 = time.time()
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      loaded in %.0f s" % (time.time() - t0))

    n_layers = int(model.config.num_hidden_layers)
    FULL_K = int(model.config.num_experts_per_tok)
    gates = [layer.mlp.gate for layer in model.model.layers]
    ORIG = [g.forward for g in gates]
    # 罠: max_memory で CPU offload されると lm_head.weight は .is_meta のプレースホルダになる
    # （実体は _hf_hook.weights_map["weight"]）。embed_tokens は head と tie 無しなので代用禁止。
    src = model.lm_head.weight
    if src.is_meta:
        hook = getattr(model.lm_head, "_hf_hook", None)
        wm = getattr(hook, "weights_map", None) if hook is not None else None
        try:
            real = wm["weight"] if wm is not None else None
        except Exception:
            real = None
        if real is None or getattr(real, "is_meta", False):
            raise RuntimeError("lm_head 実体を取り出せない（weights_map に weight が無い）")
    else:
        real = src
    W = real.detach().float().cpu()              # (V, d) CPU fp32
    log("      lm_head: %s  bias=%s  W(cv).device=%s meta=%s" % (
        tuple(real.shape), getattr(model.lm_head, "bias", None) is not None, W.device, W.is_meta))

    def make_rescaled(orig, full_k):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            if scores.shape[-1] < full_k:
                probs = torch.softmax(logits.float(), dim=-1)
                m_full = torch.topk(probs, full_k, dim=-1).values.sum(-1, keepdim=True)
                m_now = scores.float().sum(-1, keepdim=True).clamp_min(1e-9)
                scores = (scores.float() * (m_full / m_now)).to(scores.dtype)
            return logits, scores, idx
        return _patched

    h_final = []

    def mk_norm_hook():
        def hook(module, inp, out):
            h_final.append(out.detach().float().cpu())
        return hook

    handles = [model.model.norm.register_forward_hook(mk_norm_hook())]

    z = np.load(args.ids, allow_pickle=True)
    seqs = []
    for lang in ("en", "ja"):
        ids = torch.from_numpy(z["%s_ids" % lang].astype(np.int64))
        for w in range(ids.numel() // 256):
            seqs.append((lang, ids[w * 256:(w + 1) * 256]))
    if args.max_windows:
        seqs = seqs[:args.max_windows]
    log("[2/3] frozen corpus: %d windows x 256" % len(seqs))

    keys = ["nll", "ptop1", "top1", "dlogit", "p1", "dh_norm", "a1", "q10", "cos_dh"]
    buf = {c: {k: [] for k in keys} for c, _, _ in CONDS}

    log("[3/3] forward")
    t1 = time.time()
    with torch.no_grad():
        for wi, (lang, ids) in enumerate(seqs):
            x = ids.unsqueeze(0).to(model.device)
            baseN = None
            base_top1 = None
            base_logit = None
            Wtop = None
            Wtop_n = None
            for name, spec, rescale in CONDS:
                ks = parse_alloc(spec, n_layers, FULL_K)
                for i, g in enumerate(gates):
                    g.top_k = ks[i]
                    g.forward = make_rescaled(ORIG[i], FULL_K) if rescale else ORIG[i]
                h_final.clear()
                out = model(input_ids=x, use_cache=False)
                lg = out.logits[0, :-1].float()          # (T, V)
                tgt = x[0, 1:]
                logZ = torch.logsumexp(lg, dim=-1)
                true_l = lg.gather(1, tgt.unsqueeze(-1)).squeeze(-1)
                rank = (lg > true_l.unsqueeze(-1)).sum(dim=-1) + 1
                top1_l, top1_i = lg.max(dim=-1)
                N = h_final[0][0, :-1].float()           # (T, d) 最終正規化後

                buf[name]["nll"].append((logZ - true_l).cpu().numpy())
                buf[name]["ptop1"].append(torch.exp(top1_l - logZ).cpu().numpy())
                buf[name]["top1"].append((rank == 1).float().cpu().numpy())

                if name == "base":
                    baseN = N.clone()
                    base_top1 = top1_i.clone()
                    base_logit = top1_l.clone()
                    # base の上位 10 本の head 行（位置ごとに gather）。W は CPU なので gather も CPU 側へ
                    _, top10 = torch.topk(lg, 10, dim=-1)          # (T, 10)
                    top10_cpu = top10.cpu()
                    Wtop = W[top10_cpu.reshape(-1)].reshape(N.size(0), 10, -1).float()
                    Wtop_n = Wtop / Wtop.norm(dim=-1, keepdim=True).clamp_min(1e-9)
                    if wi == 0:
                        # 検算: 物化した W が本当に head か（N @ W.T が出力 logits と一致するか）
                        chk = (N @ W.t()) - lg.cpu()
                        emax = chk.abs().max().item()
                        log("      head check(1win): max|N@W.T - logits| = %.5f" % emax)
                        if emax > 0.5:
                            #期待値は bf16 丸めで ~0.06。embed_tokens（別テンソル）を拾うと ~25 になる
                            raise RuntimeError("W の物化が不正（head と一致しない）。打ち切る")
                    buf[name]["dlogit"].append(np.zeros(N.size(0), np.float32))
                    buf[name]["p1"].append(np.zeros(N.size(0), np.float32))
                    buf[name]["dh_norm"].append(np.zeros(N.size(0), np.float32))
                    buf[name]["a1"].append(np.zeros(N.size(0), np.float32))
                    buf[name]["q10"].append(np.zeros(N.size(0), np.float32))
                    buf[name]["cos_dh"].append(np.zeros(N.size(0), np.float32))
                else:
                    dh = N - baseN                                   # (T, d)
                    dnorm = dh.norm(dim=-1).clamp_min(1e-9)
                    w1 = Wtop_n[:, 0, :]                             # base top-1 の方向
                    p1 = (dh * w1).sum(-1)                           # 予測 logit 変化
                    a1 = p1.abs() / dnorm
                    proj = (dh.unsqueeze(1) * Wtop_n).sum(-1)        # (T, 10)
                    q10 = proj.norm(dim=-1) / dnorm
                    dlogit = lg.gather(1, base_top1.unsqueeze(-1)).squeeze(-1) - base_logit
                    cos_dh = (dh * baseN).sum(-1) / (dnorm * baseN.norm(dim=-1).clamp_min(1e-9))
                    buf[name]["dlogit"].append(dlogit.cpu().numpy())
                    buf[name]["p1"].append(p1.cpu().numpy())
                    buf[name]["dh_norm"].append(dnorm.cpu().numpy())
                    buf[name]["a1"].append(a1.cpu().numpy())
                    buf[name]["q10"].append(q10.cpu().numpy())
                    buf[name]["cos_dh"].append(cos_dh.cpu().numpy())
                del out, lg, logZ, true_l, rank, N
                torch.cuda.empty_cache()
            if wi % 8 == 0:
                log("      window %2d/%d  (%.0f s)" % (wi + 1, len(seqs), time.time() - t1))

    for h in handles:
        h.remove()

    out = {"lang": np.array([s[0] for s in seqs])}
    for c in buf:
        for k in keys:
            out["%s_%s" % (c, k)] = np.concatenate(buf[c][k])
    np.savez_compressed(os.path.join(HERE, "p6k_head_proj.npz"), **out)
    with open(os.path.join(HERE, "p6k_out_utf8.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(LOG))
    log("saved p6k_head_proj.npz")
    import sys
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
