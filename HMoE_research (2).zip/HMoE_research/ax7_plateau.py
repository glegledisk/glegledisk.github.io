# -*- coding: utf-8 -*-
"""AX7: N=102 / 181 平坦区間の機構解析。

設計書: AX7課題設計書_N102-181平坦区間の機構解析_20261113.md
（走行前に estimand・腕・校正・検定族・判定ケースを凍結）

AX4 / AX5 と同一コーパス・同一 c8/c7・同一 u7 を使い、
長さ分布 / 境界整合 / 窓内完結の 3 要因を N=102・181 で操作する。
新規 forward 10 本、残りは AX3 / AX4 / AX5 の保存 NLL を再利用。

実行:
  python ax7_plateau.py --dry-run
  python ax7_plateau.py --smoke --tag ax7smoke
  python ax7_plateau.py --tag ax7
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ax2_layer_cost import paired, holm  # noqa: E402  純関数のみ

N_LAYERS = 16
ALPHA = 0.05
SEED_A, SEED_B = 7201, 7202
AX5_C7 = 0.00132332
AX3_CORPUS = os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz")
AX3_NPZ = os.path.join(HERE, "ax3_transfer.npz")
AX4_NPZ = os.path.join(HERE, "ax4_sentence_bound.npz")
AX5_NPZ = os.path.join(HERE, "ax5_granularity_mech.npz")
DESIGN = "AX7課題設計書_N102-181平坦区間の機構解析_20261113.md"

TEE = None


def log(msg):
    print(msg, flush=True)
    if TEE is not None:
        TEE.write(msg + "\n")
        TEE.flush()


# ---------------------------------------------------------------- 分割・決定
def group_units(sid, k, n_win, n_eval):
    """AX4 と同一: 窓内ローカル文 ID を k 個まとめる（窓をまたがない）。"""
    out = np.zeros_like(sid)
    off = 0
    for w in range(n_win):
        sl = slice(w * n_eval, (w + 1) * n_eval)
        sw = sid[sl]
        lo = sw - sw.min()
        out[sl] = off + lo // k
        off = int(out[sl].max()) + 1
    return out


def uniform_lengths(n_unit, total):
    q, r = divmod(total, n_unit)
    ls = np.full(n_unit, q, dtype=np.int64)
    ls[:r] += 1
    return ls


def lengths_to_uid(lens):
    return np.repeat(np.arange(len(lens), dtype=np.int32), lens).astype(np.int32)


def window_uniform(grouped, n_win, n_eval):
    """各窓を group_units と同じ単位数 m_w で均等分割（窓内完結の均一長）。"""
    uid = np.zeros(n_win * n_eval, dtype=np.int32)
    off = 0
    for w in range(n_win):
        sl = slice(w * n_eval, (w + 1) * n_eval)
        m = int(grouped[sl].max() - grouped[sl].min() + 1)
        q, r = divmod(n_eval, m)
        ls = np.full(m, q, dtype=np.int64)
        ls[:r] += 1
        uid[sl] = np.repeat(np.arange(off, off + m, dtype=np.int32), ls)
        off += m
    return uid


def unit_targets(c8, c7, uid, n_unit):
    cnt = np.bincount(uid, minlength=n_unit).astype(np.float64)
    assert cnt.min() > 0, "empty unit"
    a = np.stack([np.bincount(uid, weights=c8[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    b = np.stack([np.bincount(uid, weights=c7[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    return np.concatenate([a, b], axis=1)


def unit_decision(Y):
    cut = np.argmin(Y[:, N_LAYERS:], axis=1).astype(np.int8)
    Q = Y[:, :N_LAYERS].copy()
    Q[np.arange(Y.shape[0]), cut] = -np.inf
    prot = np.argmax(Q, axis=1).astype(np.int8)
    assert (cut != prot).all(), "cut == protect"
    return cut, prot


def kmat_from_units(uid, cut, prot, n_tok):
    km = np.full((N_LAYERS, n_tok), 7, dtype=np.int8)
    for u in range(len(cut)):
        sel = (uid == u)
        km[cut[u], sel] = 6
        km[prot[u], sel] = 8
    return km


def to_windows(kmat_eval, nw, n_eval, ln, pad_val=7):
    km = kmat_eval.reshape(N_LAYERS, nw, n_eval)
    km = np.concatenate([km, np.full((N_LAYERS, nw, 1), pad_val, dtype=np.int8)], axis=2)
    return km.reshape(N_LAYERS, nw * ln)


def split_stats(uid, k=None, n_win=48, n_eval=255, sent=None):
    ls = np.bincount(uid).astype(np.float64)
    sh = ls / ls.sum()
    d = {"N": int(ls.size), "mean": float(ls.mean()), "cv": float(ls.std(ddof=1) / ls.mean()),
         "min": float(ls.min()), "max": float(ls.max()),
         "eff_units": float(1.0 / (sh ** 2).sum()),
         "short_le20_share": float((ls <= 20).mean()),
         "short_le40_share": float((ls <= 40).mean())}
    if k is not None and sent is not None and k > 1:
        # 端数単位 = 所属文数が k 未満
        per = {}
        for w in range(n_win):
            sl = slice(w * n_eval, (w + 1) * n_eval)
            u, s = uid[sl], sent[sl]
            for x in np.unique(u):
                per.setdefault(int(x), set()).update(np.unique(s[u == x]).tolist())
        d["partial_share"] = float(sum(1 for v in per.values() if len(v) < k) / len(per))
    return d


def assert_finite(obj, path="root"):
    bad = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            bad += assert_finite(v, path + "/" + str(k))
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            bad += assert_finite(v, path + "/%d" % i)
    elif isinstance(obj, (float, np.floating)) and (np.isnan(obj) or np.isinf(obj)):
        bad.append(path)
    return bad


def load_ax3(n_win, ln, en_only=False):
    """AX4 / AX5 と同じ窓順。smoke だけ en の先頭 2*n_win 窓を使い、
    AX4 保存配列の先頭 n_tok トークンと完全一致させる（走行前追記 13:20）。"""
    z = np.load(AX3_CORPUS, allow_pickle=True)
    seqs = []
    langs = ("en",) if en_only else ("en", "ja")
    for lg in langs:
        n_lg = 2 * n_win if en_only else n_win
        ids = torch.from_numpy(z[lg + "_ids"].astype(np.int64)[:n_lg * ln])
        assert ids.numel() >= n_lg * ln
        for w in range(n_lg):
            seqs.append((lg, ids[w * ln:(w + 1) * ln]))
    return seqs


def build_parts(sent, n_tok, nw, n_eval):
    parts = {}
    parts["sent340"] = sent.astype(np.int32)
    parts["sent2"] = group_units(sent, 2, nw, n_eval).astype(np.int32)
    parts["sent4"] = group_units(sent, 4, nw, n_eval).astype(np.int32)
    parts["uni102"] = lengths_to_uid(uniform_lengths(102, n_tok))
    parts["uni181"] = lengths_to_uid(uniform_lengths(181, n_tok))
    multi = {}
    for k, N in ((4, 102), (2, 181)):
        src = parts["sent4"] if k == 4 else parts["sent2"]
        ls = np.bincount(src)
        multi[N] = ls
        for suffix, seed in (("", SEED_A), ("b", SEED_B)):
            ls2 = np.random.default_rng(seed).permutation(ls)
            assert np.array_equal(np.sort(ls), np.sort(ls2))
            parts["shift%d%s" % (N, suffix)] = lengths_to_uid(ls2)
    parts["glob4"] = (sent // 4).astype(np.int32)
    parts["glob2"] = (sent // 2).astype(np.int32)
    parts["uni102w"] = window_uniform(parts["sent4"], nw, n_eval)
    parts["uni181w"] = window_uniform(parts["sent2"], nw, n_eval)
    for nm, uid in parts.items():
        assert uid.shape == (n_tok,), nm
        assert np.array_equal(np.unique(uid), np.arange(uid.max() + 1)), nm
        assert np.bincount(uid).min() >= 1, nm
    return parts, multi


# ---------------------------------------------------------------- main
def main():
    global TEE
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--tag", type=str, default="ax7")
    args = ap.parse_args()
    tag = args.tag
    TEE = open(os.path.join(HERE, "%s_plateau_out_utf8.txt" % tag), "w", encoding="utf-8")

    n_win = 3 if args.smoke else args.windows
    ln, n_eval = args.len, args.len - 1
    nw, n_tok = 2 * n_win, 2 * n_win * n_eval

    log("[1] saved arrays / partitions")
    z3 = np.load(AX3_NPZ)
    z4 = np.load(AX4_NPZ)
    z5 = np.load(AX5_NPZ)
    c8 = z4["c8"][:, :n_tok].astype(np.float64)
    c7 = z4["c7"][:, :n_tok].astype(np.float64)
    assert c8.shape == (N_LAYERS, n_tok)
    sent = z4["sent"].astype(np.int64)[:n_tok].copy()
    # 先頭スライスでも ID を 0.. の連番へ詰める
    _, sent = np.unique(sent, return_inverse=True)
    sent = sent.astype(np.int64)
    u7_saved = z4["nll_u7_rep"][:n_tok].astype(np.float64)
    base_saved = z4["nll_base_rep"][:n_tok].astype(np.float64)

    parts, multi = build_parts(sent, n_tok, nw, n_eval)
    log("    parts: " + "  ".join("%s=%d" % (k, int(v.max()) + 1) for k, v in parts.items()))

    # C2: 被覆・多重集合
    c2 = {"n_tok": int(n_tok), "n_win": int(nw),
          "multiset_shift102": bool(all(np.array_equal(np.sort(multi[102]),
                                                       np.sort(np.bincount(parts[nm])))
                                       for nm in ("shift102", "shift102b"))),
          "multiset_shift181": bool(all(np.array_equal(np.sort(multi[181]),
                                                       np.sort(np.bincount(parts[nm])))
                                       for nm in ("shift181", "shift181b"))),
          "coverage_bad": 0}
    assert c2["multiset_shift102"] and c2["multiset_shift181"], "C2 多重集合不一致"

    # 決定（全腕で c8 / c7 から再計算）
    log("[2] decisions")
    dec = {}
    for nm, uid in parts.items():
        dec[nm] = unit_decision(unit_targets(c8, c7, uid, int(uid.max()) + 1))
    replay = {}
    for nm, uid in parts.items():
        c_re, p_re = unit_decision(unit_targets(c8, c7, uid, int(uid.max()) + 1))
        replay[nm] = int(bool((dec[nm][0] == c_re).all() and (dec[nm][1] == p_re).all()))
    conflicts = {nm: int((c == p).sum()) for nm, (c, p) in dec.items()}
    mean_k = {}
    mask_arms = []
    for nm in ("shift102", "shift102b", "shift181", "shift181b",
               "glob4", "glob2", "uni102w", "uni181w"):
        km = to_windows(kmat_from_units(parts[nm], *dec[nm], n_tok), nw, n_eval, ln, 7)
        mask_arms.append((nm, km))
        mean_k[nm] = float(km.mean())
    mk_bad = {k: v for k, v in mean_k.items() if abs(v - 7.0) > 1e-9}
    assert not mk_bad, "C3 mean_k 不良: %s" % mk_bad
    assert all(v == 0 for v in conflicts.values()), "C5 cut == protect"

    stats = {}
    for nm, uid in parts.items():
        k = 4 if nm == "sent4" else (2 if nm == "sent2" else None)
        stats[nm] = split_stats(uid, k, nw, n_eval, sent)

    if args.dry_run:
        log("    dry-run OK (no model, no forward). C2 %s  C3 bad %d  C5 %d"
            % (c2["multiset_shift102"] and c2["multiset_shift181"],
               len(mk_bad), sum(conflicts.values())))
        TEE.close()
        return

    # ---- 既存保存 NLL（新規 forward 0） ----
    def saved(z, key):
        return z[key][:n_tok].astype(np.float64)

    N = {"u7": u7_saved,
         "sent340": saved(z4, "nll_sent_oracle"),
         "sent2": saved(z4, "nll_sent2_oracle"),
         "sent4": saved(z4, "nll_sent4_oracle"),
         "sent_random": saved(z4, "nll_sent_random"),
         "sent_nl": saved(z4, "nll_sent_nl_oracle"),
         "uni102": saved(z5, "nll_uni102"),
         "uni181": saved(z5, "nll_uni181"),
         "uni340": saved(z5, "nll_uni340"),
         "shift340": saved(z5, "nll_shift340"),
         "shift340b": saved(z5, "nll_shift340b"),
         "tok12240": saved(z3, "nll_lay_tok_oracle")}
    for k, v in N.items():
        assert v.shape == (n_tok,), k

    log("[3] load model")
    t0 = time.time()
    from transformers import AutoModelForCausalLM, AutoTokenizer
    AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    full_k = int(model.config.num_experts_per_tok)
    assert full_k == 8 and int(model.config.num_hidden_layers) == N_LAYERS
    gates = [l.mlp.gate for l in model.model.layers]
    gate_fwd = [g.forward for g in gates]
    seqs = load_ax3(n_win, ln, en_only=args.smoke)
    assert len(seqs) == nw
    log("    %.0f s  (%d windows)" % (time.time() - t0, nw))

    STATE = {"kmat": None}

    def make_masked(orig, li):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            km = STATE["kmat"]
            if km is not None and scores.shape[-1] == full_k:
                kk = km[li]
                if kk.numel() == scores.shape[0]:
                    ar = torch.arange(scores.shape[-1], device=scores.device,
                                      dtype=torch.float32)
                    scores = scores * (ar[None, :] < kk[:, None]).to(scores.dtype)
            return logits, scores, idx
        return _patched

    for i, g in enumerate(gates):
        g.forward = make_masked(gate_fwd[i], i)

    cache_dir = os.path.join(HERE, "_ax7_cache_%s" % tag)
    os.makedirs(cache_dir, exist_ok=True)

    def run_eval(name, native_topk=None, kmat_windows=None):
        cf = os.path.join(cache_dir, name + ".npz")
        if os.path.exists(cf):
            c = np.load(cf)
            log("    %-14s CACHED CE %.5f" % (name, float(c["nll"].mean())))
            return c["nll"].astype(np.float64), c["acc1"].astype(np.float64)
        t1 = time.time()
        if kmat_windows is not None:
            for g in gates:
                g.top_k = full_k
        else:
            STATE["kmat"] = None
            for g in gates:
                g.top_k = int(native_topk)
        nll_c, a1_c = [], []
        with torch.no_grad():
            for wi, (lg, ids) in enumerate(seqs):
                if kmat_windows is not None:
                    STATE["kmat"] = torch.from_numpy(
                        kmat_windows[:, wi * ln:(wi + 1) * ln].astype(np.float32)
                    ).to(model.device)
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                logit = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(logit, tgt, reduction="none")
                true_l = logit.gather(1, tgt.unsqueeze(-1))
                a1_c.append(((logit > true_l).sum(-1) == 0).float().cpu().numpy())
                nll_c.append(nll.cpu().numpy())
                del out, logit
        STATE["kmat"] = None
        nll = np.concatenate(nll_c).astype(np.float32)
        a1 = np.concatenate(a1_c).astype(np.float32)
        np.savez_compressed(cf, nll=nll, acc1=a1)
        log("    %-14s CE %.5f  top1 %.4f  (%.0f s)"
            % (name, nll.mean(), a1.mean(), time.time() - t1))
        return nll.astype(np.float64), a1.astype(np.float64)

    log("[4] native forwards (2)")
    N["base_rep"], _ = run_eval("base_rep", native_topk=full_k)
    N["u7_rep"], _ = run_eval("u7_rep", native_topk=7)

    log("[5] mask forwards (8)")
    for nm, km in mask_arms:
        N[nm], _ = run_eval(nm, kmat_windows=km)

    # ---- 統計 ----
    log("[6] stats / calibration")
    u7 = N["u7"]
    gains = {}
    for nm in list(N):
        if nm in ("u7", "base_rep", "u7_rep"):
            continue
        gains[nm] = paired(u7 - N[nm], nw, n_eval)

    # 確認的 Holm m = 3（すべて per-token paired t）
    d1 = 0.5 * ((N["uni102"] - N["shift102"]) + (N["uni181"] - N["shift181"]))
    d2 = 0.5 * ((N["shift102"] - N["sent4"]) + (N["shift181"] - N["sent2"]))
    d3 = (N["sent4"] - N["sent2"]) - (N["uni102"] - N["uni181"])
    st = {"P1_length": paired(d1, nw, n_eval),
          "P2_alignment": paired(d2, nw, n_eval),
          "P3_flat": paired(d3, nw, n_eval)}
    ph = holm({k[:2]: v["p_two"] for k, v in st.items()})
    rej = {k: bool(v < ALPHA) for k, v in ph.items()}
    if rej["P1"]:
        case = "A"
    elif rej["P2"]:
        case = "B"
    elif rej["P3"]:
        case = "C"
    else:
        case = "D"

    # 校正
    calib = {}
    bd = float(np.abs(N["base_rep"] - base_saved).max())
    ud = float(np.abs(N["u7_rep"] - u7_saved).max())
    calib["C1"] = {"base_maxdiff": bd, "u7_maxdiff": ud,
                   "tier": "A" if bd == 0.0 and ud == 0.0 else "FAIL",
                   "scope": "smoke_en6" if args.smoke else "full_48"}
    calib["C2"] = c2
    calib["C3"] = {"decision_replay": replay, "mean_k": mean_k,
                   "n_bad": len(mk_bad)}
    calib["C4"] = {"n_bad": len(mk_bad), "slots_per_token": 112}
    y4 = unit_targets(c8, c7, parts["sent4"], int(parts["sent4"].max()) + 1)
    c7u = y4[:, N_LAYERS:]
    tie_min = int(((c7u == c7u.min(axis=1, keepdims=True)).sum(axis=1) > 1).sum())
    calib["C5"] = {"conflicts": conflicts,
                   "cut_hist_sent4": np.bincount(dec["sent4"][0], minlength=N_LAYERS).tolist(),
                   "tie_min_sent4": tie_min}
    gr = gains["sent_random"]["mean"]
    go = gains["tok12240"]["mean"]
    calib["C6"] = {"uniform": "u7", "random": "sent_random", "oracle": "tok12240",
                   "random_gain": gr, "oracle_gain": go,
                   "random_le_oracle": bool(gr <= go)}
    noise102 = abs(gains["shift102"]["mean"] - gains["shift102b"]["mean"])
    noise181 = abs(gains["shift181"]["mean"] - gains["shift181b"]["mean"])
    calib["C7"] = {"observed_statistic": "abs(G_shiftN - G_shiftNb) for N=102,181",
                   "noise102": noise102, "noise181": noise181,
                   "ax5_c7_reference": AX5_C7, "judgement": "record_only"}

    # 探索的: 2 項分解・窓内完結・平坦・記述的対応
    dec102 = {"total": gains["sent4"]["mean"] - gains["uni102"]["mean"],
              "alignment": gains["sent4"]["mean"] - gains["shift102"]["mean"],
              "length": gains["shift102"]["mean"] - gains["uni102"]["mean"]}
    dec181 = {"total": gains["sent2"]["mean"] - gains["uni181"]["mean"],
              "alignment": gains["sent2"]["mean"] - gains["shift181"]["mean"],
              "length": gains["shift181"]["mean"] - gains["uni181"]["mean"]}
    F_sent = gains["sent2"]["mean"] - gains["sent4"]["mean"]
    F_uni = gains["uni181"]["mean"] - gains["uni102"]["mean"]
    F_shift = gains["shift181"]["mean"] - gains["shift102"]["mean"]
    from scipy.stats import spearmanr
    keys = [nm for nm in parts if nm in gains]
    rho_cv, _ = spearmanr([stats[k]["cv"] for k in keys], [gains[k]["mean"] for k in keys])
    rho_eff, _ = spearmanr([stats[k]["eff_units"] for k in keys], [gains[k]["mean"] for k in keys])
    rc = float(rho_cv) if np.isfinite(rho_cv) else 0.0
    re = float(rho_eff) if np.isfinite(rho_eff) else 0.0
    exploratory = {
        "decomposition_N102": dec102, "decomposition_N181": dec181,
        "window_effect": {"sent4_minus_glob4": gains["sent4"]["mean"] - gains["glob4"]["mean"],
                          "sent2_minus_glob2": gains["sent2"]["mean"] - gains["glob2"]["mean"],
                          "uni102w_minus_uni102": gains["uni102w"]["mean"] - gains["uni102"]["mean"],
                          "uni181w_minus_uni181": gains["uni181w"]["mean"] - gains["uni181"]["mean"]},
        "flat": {"F_sent_ax4": F_sent, "F_uni_ax5": F_uni, "F_shift": F_shift,
                 "F_ax4_reference": 0.00004482, "F_uni_ax5_reference": 0.00166435,
                 "F_ax6_uni_reference": 0.00151359},
        "descriptive": {"spearman_cv_vs_G": rc,
                        "spearman_eff_units_vs_G": re, "n_arms": len(keys)},
        "split_stats": stats,
        "top1_abs_share": {k: st[k]["top1_abs_share"] for k in st},
    }

    out = {
        "meta": {"tag": tag, "smoke": bool(args.smoke), "windows": int(nw), "len": ln,
                 "n_tok": int(n_tok), "n_new_forwards": 10, "n_arms": len(gains),
                 "seed_shift_a": SEED_A, "seed_shift_b": SEED_B, "design": DESIGN},
        "confirmatory": dict(st, holm=ph, reject=rej, case=case),
        "calib": calib, "gains": gains, "exploratory": exploratory,
    }
    bad = assert_finite(out)
    assert not bad, "非有限値が JSON に混入: %s" % bad[:8]

    log("[7] save")
    with open(os.path.join(HERE, "%s_plateau.json" % tag), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2, allow_nan=False)
    save = {("nll_" + k): v.astype(np.float64) for k, v in N.items()}
    save.update({"c8": c8, "c7": c7, "sent": sent.astype(np.int32)})
    for nm, uid in parts.items():
        save["uid_" + nm] = uid.astype(np.int32)
        save["cut_" + nm] = dec[nm][0]
        save["prot_" + nm] = dec[nm][1]
    np.savez_compressed(os.path.join(HERE, "%s_plateau.npz" % tag), **save)

    log("== confirmatory (Holm m=3, alpha=0.05) ==")
    for k, v in st.items():
        log("%-14s %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
            % (k, v["mean"], v["t"], v["p_two"], ph[k[:2]], v["mde"]))
    log("case = %s" % case)
    log("decomp N102 total %+.8f (align %+.8f + length %+.8f)" %
        (dec102["total"], dec102["alignment"], dec102["length"]))
    log("decomp N181 total %+.8f (align %+.8f + length %+.8f)" %
        (dec181["total"], dec181["alignment"], dec181["length"]))
    log("calib C1 %s  C3 bad %d  C5 %d  C6 %s  C7 noise %.6f / %.6f" %
        (calib["C1"]["tier"], len(mk_bad), sum(conflicts.values()),
         calib["C6"]["random_le_oracle"], noise102, noise181))
    log("saved: %s_plateau.npz / .json" % tag)
    TEE.close()
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
