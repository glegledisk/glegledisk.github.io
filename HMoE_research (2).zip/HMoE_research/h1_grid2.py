"""H1 本番グリッド（in-process 版）。

サブプロセス方式だと CUDA コンテキストを持つ子が残留して GPU を食い潰すため、
1 プロセス内で run() を順に呼ぶ。各 run の終了ごとに jsonl へ追記し、
既存の (arm,b,seed) はスキップする（中断しても再開できる）。
"""
import json
import os
import sys
import time

import torch

import h1_hybrid_testbed as H

HERE = os.path.dirname(os.path.abspath(__file__))
STEPS = int(os.environ.get("H1_STEPS", "1600"))

BS = [1, 4, 16]
ARMS = ["uni_k1", "uni_k2", "het_l005", "het_l02"]
SEEDS = [0, 1, 2]
SWEEP = ["uni_s05", "uni_s075", "uni_s15"]

jobs = [(a, b, s) for b in BS for a in ARMS for s in SEEDS]
jobs += [(a, 16, s) for a in SWEEP for s in SEEDS]

out = os.path.join(HERE, "h1_results.jsonl")
done = set()
if os.path.exists(out):
    with open(out, encoding="utf-8") as fp:
        for line in fp:
            if line.strip():
                d = json.loads(line)
                done.add((d["arm"], d["b"], d["seed"]))
print(f"resume: {len(done)} already done, {len(jobs)} total", flush=True)

t0 = time.time()
n_new = 0
for i, (arm, b, seed) in enumerate(jobs, 1):
    if (arm, b, seed) in done:
        continue
    el = (time.time() - t0) / 60
    print(f"[{i}/{len(jobs)}] {arm} b={b} seed={seed}  elapsed={el:.1f}m", flush=True)
    try:
        r = H.run(arm, b, seed, STEPS, 128, 4, 4, 256, 64, 3e-3)
    except Exception as e:                                   # noqa: BLE001
        print(f"  FAIL {type(e).__name__}: {e}", flush=True)
        torch.cuda.empty_cache()
        continue
    with open(out, "a", encoding="utf-8") as fp:
        fp.write(json.dumps(r, ensure_ascii=False) + "\n")
    n_new += 1
    print(f"  val={r['val']:.4f} cost={r['cost']:.3f} sec={r['sec']:.0f}", flush=True)

print(f"DONE new={n_new} total_elapsed={(time.time()-t0)/60:.1f}m", flush=True)
sys.stdout.flush()
os._exit(0)          # CUDA の終了時ハングを避ける
