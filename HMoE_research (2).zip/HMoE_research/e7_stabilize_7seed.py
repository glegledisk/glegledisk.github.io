# -*- coding: utf-8 -*-
"""e7_stabilize_7seed.py — A4: ルータ安定化介入の 7 seed 比較実験

目的:
  E7 で free ルーティングの効果が E6 の 1/8 に縮小した。原因の診断:
    H-A（シグナル）: free router は残留 x から「両トークンが頻繁（ff）」を線形に復号できない
    H-B（局所最適）: router が ff を逃がさない→恒等パスが ff を学習しない→勾配機が湧かない（鶏と卵）
  4 介入を E7 課題・同 seed で測り、E7 の free（既存 7 seed）と比較する:

    free_entropy : gate エントロピー報酬（β=0.05）—— 退化防止（安定化）
    free_balance : Switch -style load-balancing（β=0.1）—— Expert を遊ばせない（安定化）
    free_tokid   : router 入力に src[i], src[i-1] の one-hot—— 信号を直接付与（H-A の検証）
    free_mlp     : 2 層 MLP router —— x からの非線形復号（H-A の検証）

  判定: 最適方針は「ff → 恒等、fr/rr → FFN」（FFN コスト ≈ 0.425、ff の恒等劣化は 0.057 nats/位置）。
  介入が効けば FFN コストが 0.90 → 0.43 近傍に向かい、合成目的の改善が E6 スケールに戻る。

構成: 4 バリアント × 7 seed（不足分のみ実行・逐次保存・再開可能）
      baseline は e7_routing_7seed.csv の frozen_ffn / free（同 seed・同課題）
"""
import os, json, time
import numpy as np
import pandas as pd
import torch
from e7_stabilize_task import run, make_lookup_table, ROLE_NAME, VARIANTS

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)), d=64, epochs=60)
SEEDS = list(range(7))
OUT = os.path.join(HERE, "e7_stabilize_7seed.csv")
BASE = os.path.join(HERE, "e7_routing_7seed.csv")   # E7 の frozen_ffn / free（baseline）
LAMS = [0.03, 0.05, 0.08, 0.15, 0.30]
DEV = "cuda" if torch.cuda.is_available() else "cpu"
tab = make_lookup_table(64)

rows = []
if os.path.exists(OUT):
    rows = pd.read_csv(OUT).to_dict("records")
have = {(r["variant"], int(r["seed"])) for r in rows}
print(f"device: {DEV}  既存 {len(have)} 件")

todo = [(v, s) for v in VARIANTS for s in SEEDS if (v, s) not in have]
print(f"追加実行 {len(todo)} 件")

t0 = time.time()
for i, (v, s) in enumerate(todo, 1):
    r = run(v, s, table=tab, device=DEV, **CFG)
    rows.append(r)
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"  [{i}/{len(todo)}] {v:14s} s{s} | CE {r['ce_all']:.4f} | FFN {r['ffn_cost']:.3f} "
          f"| acc {r['acc_all']:.4f} (ff {r['acc_ff']:.3f} / fr {r['acc_fr']:.3f} / rr {r['acc_rr']:.3f}) "
          f"| {time.time()-t0:.0f}s", flush=True)

df = pd.DataFrame(rows)
df["obj015"] = df["ce_all"] + 0.15 * df["ffn_cost"]
df = df.sort_values(["variant", "seed"]).reset_index(drop=True)
df.to_csv(OUT, index=False)

# E7 baseline（frozen_ffn / free）を読み込み、同じ列構造に合わせる
b = pd.read_csv(BASE)
b["obj015"] = b["ce_all"] + 0.15 * b["ffn_cost"]
base_ffn = b[b.arm == "frozen_ffn"].set_index("seed")
base_free = b[b.arm == "free"].set_index("seed")

print("\n=== A4 介入の比較（60 epoch・7 seed, d=64, E7 課題, λ=0.15） ===")
print(f"{'variant':16s} {'CE':>16s} {'FFN':>14s} {'obj(λ=.15)':>16s} {'acc':>16s} "
      + " ".join(f"{'acc '+nm:>10s}" for nm in ROLE_NAME.values()))
print(f"{'[E7] frozen_ffn':16s} {base_ffn['ce_all'].mean():.4f}±{base_ffn['ce_all'].std():.4f}  "
      f"{base_ffn['ffn_cost'].mean():.3f}±{base_ffn['ffn_cost'].std():.3f}  "
      f"{base_ffn['obj015'].mean():.4f}±{base_ffn['obj015'].std():.4f}  "
      f"{base_ffn['acc_all'].mean():.4f}±{base_ffn['acc_all'].std():.4f}  "
      + " ".join(f"{base_ffn['acc_'+nm].mean():10.4f}" for nm in ROLE_NAME.values()))
print(f"{'[E7] free':16s} {base_free['ce_all'].mean():.4f}±{base_free['ce_all'].std():.4f}  "
      f"{base_free['ffn_cost'].mean():.3f}±{base_free['ffn_cost'].std():.3f}  "
      f"{base_free['obj015'].mean():.4f}±{base_free['obj015'].std():.4f}  "
      f"{base_free['acc_all'].mean():.4f}±{base_free['acc_all'].std():.4f}  "
      + " ".join(f"{base_free['acc_'+nm].mean():10.4f}" for nm in ROLE_NAME.values()))
for v in VARIANTS:
    d = df[df.variant == v]
    print(f"{v:16s} {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f}  "
          f"{d['obj015'].mean():.4f}±{d['obj015'].std():.4f}  "
          f"{d['acc_all'].mean():.4f}±{d['acc_all'].std():.4f}  "
          + " ".join(f"{d['acc_'+nm].mean():10.4f}" for nm in ROLE_NAME.values()))

# 参考: 最適方針（ff → 恒等、fr/rr → FFN）の FFN コスト
nff = float(base_ffn["n_ff"].mean())
print(f"\n最適方針の FFN コスト（fr+rr の質量）≈ {1 - nff:.3f}（ff の質量 {nff:.3f}）")


def paired(d_new, d_base, key):
    d = (d_new[key] - d_base[key]).dropna()
    m, sd = d.mean(), d.std(ddof=1)
    t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
    rng = np.random.default_rng(0)
    boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(20000)])
    lo, hi = np.percentile(boot, [2.5, 97.5])
    return m, lo, hi, t, int((d < 0).sum()), len(d)


print("\n=== seed 対応検定（各バリアント − frozen_ffn） ===")
res = {}
for v in VARIANTS:
    dv = df[df.variant == v].set_index("seed")
    for k in ("obj015", "ce_all", "ffn_cost"):
        m, lo, hi, t, w, n = paired(dv, base_ffn, k)
        res[f"{v}_vs_ffn_{k}"] = {"mean": float(m), "ci": [float(lo), float(hi)], "t": float(t), "wins": w}
        print(f" {v:14s} {k:9s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {w}/{n}")

print("\n=== seed 対応検定（各バリアント − E7 free）: 介入の効果 ===")
res2 = {}
for v in VARIANTS:
    dv = df[df.variant == v].set_index("seed")
    for k in ("obj015", "ce_all", "ffn_cost"):
        m, lo, hi, t, w, n = paired(dv, base_free, k)
        res2[f"{v}_vs_free_{k}"] = {"mean": float(m), "ci": [float(lo), float(hi)], "t": float(t), "wins": w}
        print(f" {v:14s} {k:9s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {w}/{n}")

print("\n=== ルータの役割別 id_rate（恒等へ逃がした割合） ===")
print(f"{'variant':16s} " + " ".join(f"{'id '+nm:>10s}" for nm in ROLE_NAME.values()) + f" {'FFN cost':>10s}")
print(f"{'[E7] free':16s} " + " ".join(f"{base_free['id_rate_'+nm].mean():10.3f}" for nm in ROLE_NAME.values())
      + f" {base_free['ffn_cost'].mean():10.3f}")
route_res = {}
for v in VARIANTS:
    d = df[df.variant == v]
    print(f"{v:16s} " + " ".join(f"{d['id_rate_'+nm].mean():10.3f}" for nm in ROLE_NAME.values())
          + f" {d['ffn_cost'].mean():10.3f}")
    route_res[v] = {nm: float(d['id_rate_'+nm].mean()) for nm in ROLE_NAME.values()}
# ff/rr 判別の有無（seed 対応）
print("\n=== ff/rr 判別（id_rate_rr − id_rate_ff、seed 対応）と FFN cost の seed 間分散 ===")
stab_res = {}
for v in VARIANTS:
    dv = df[df.variant == v].set_index("seed")
    diff = (dv["id_rate_rr"] - dv["id_rate_ff"]).dropna()
    m, sd = diff.mean(), diff.std(ddof=1)
    t = m / (sd / np.sqrt(len(diff))) if sd > 0 else float("nan")
    fc = df[df.variant == v]["ffn_cost"]
    stab_res[v] = {"id_rr_minus_ff": float(m), "t": float(t),
                   "ffn_cost_mean": float(fc.mean()), "ffn_cost_sd": float(fc.std())}
    print(f" {v:14s} 判別差 {m:+.3f} (t={t:+.2f})  FFN cost {fc.mean():.3f}±{fc.std():.3f} "
          f"（E7 free: {base_free['ffn_cost'].mean():.3f}±{base_free['ffn_cost'].std():.3f}）")
dv = base_free
diff = (dv["id_rate_rr"] - dv["id_rate_ff"]).dropna()
print(f" {'[E7] free':16s} 判別差 {diff.mean():+.3f}  FFN cost "
      f"{base_free['ffn_cost'].mean():.3f}±{base_free['ffn_cost'].std():.3f}")

print("\n=== λ 感度（合成目的。最良アーム） ===")
print(f"{'λ':>5s} {'frozen_ffn':>12s} " + "".join(f"{v:>15s}" for v in VARIANTS))
lam_tab = {}
for lam in LAMS:
    vals = {"frozen_ffn": base_ffn["ce_all"].mean() + lam * base_ffn["ffn_cost"].mean()}
    for v in VARIANTS:
        d = df[df.variant == v]
        vals[v] = d["ce_all"].mean() + lam * d["ffn_cost"].mean()
    best = min(vals, key=vals.get)
    lam_tab[str(lam)] = {"vals": {k: float(x) for k, x in vals.items()}, "best": best}
    print(f"{lam:5.2f} {vals['frozen_ffn']:12.4f} " + "".join(f"{vals[v]:15.4f}" for v in VARIANTS)
          + f"   {best}")

print("\n=== crossover λ*（各バリアント vs 全FFN） ===")
ce_f = base_ffn["ce_all"].mean()
for v in VARIANTS:
    d = df[df.variant == v]
    ce_r, ff_r = d["ce_all"].mean(), d["ffn_cost"].mean()
    if ff_r < 1.0:
        lam_s = (ce_r - ce_f) / (1.0 - ff_r)
        print(f" {v:14s} λ* = {lam_s:+.4f}  ({'Pareto 方向（λ=0 でも勝つ）' if lam_s < 0 else 'trade-off（品質は落ちる）'})")

print("\n=== seed 別（FFN cost / CE） ===")
for v in VARIANTS:
    d = df[df.variant == v].sort_values("seed")
    print(f" {v:14s} FFN " + " ".join(f"{x:.3f}" for x in d["ffn_cost"]))
    print(f" {'':16s} CE  " + " ".join(f"{x:.3f}" for x in d["ce_all"]))
    print(f" {'':16s} idRR" + " ".join(f"{x:.3f}" for x in d["id_rate_rr"]))

json.dump({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in CFG.items()},
           "device": DEV, "ent_beta": 0.05, "bal_beta": 0.1,
           "summary": {v: {k: float(df[df.variant == v][k].mean()) for k in
                           ["ce_all", "ffn_cost", "obj015", "acc_all", "acc_ff", "acc_fr", "acc_rr",
                            "ce_ff", "ce_fr", "ce_rr", "id_rate_ff", "id_rate_fr", "id_rate_rr"]}
                       for v in VARIANTS},
           "baseline_e7": {"frozen_ffn": {k: float(base_ffn[k].mean()) for k in
                                          ["ce_all", "ffn_cost", "obj015", "acc_all"]},
                           "free": {k: float(base_free[k].mean()) for k in
                                    ["ce_all", "ffn_cost", "obj015", "acc_all"]}},
           "paired_vs_ffn": res, "paired_vs_e7free": res2,
           "router_id_rates": route_res, "stability": stab_res,
           "lambda_sensitivity": lam_tab, "raw": rows},
          open(os.path.join(HERE, "e7_stabilize_7seed.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e7_stabilize_7seed.csv / .json")
