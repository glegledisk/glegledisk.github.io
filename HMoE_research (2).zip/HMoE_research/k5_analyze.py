#!/usr/bin/env python3
"""K5 解析: 難度ラダー（1 seed）と K=4 の追試（5 seed）をまとめる。

出力: k5_analysis_out_utf8.txt / k5_analysis.json
"""
import json
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "k5_analysis_out_utf8.txt")
lines = []


def p(s=""):
    print(s, flush=True)
    lines.append(s)


def main():
    lad = json.load(open(os.path.join(HERE, "k5_results_ladder.json"), encoding="utf-8"))["rows"]
    rep = json.load(open(os.path.join(HERE, "k5_results_k4rep.json"), encoding="utf-8"))["rows"]
    lad = sorted(lad, key=lambda r: (r["lag"], r["nprog"]))

    p("K5: 難度の 2 仮説（A=lag-2 で深く / B=隠れプログラム K 個で容量を圧迫）")
    p("")
    p("== 1) 難度ラダー（1 seed ずつ、16 epoch） ==")
    p("| 設定 | T | 生徒W | CE_教師 | CE_生徒 | ΔCE | instr_acc 教師/生徒 | instr_valid 教師/生徒 |")
    p("|---|---:|---:|---:|---:|---:|---:|---:|")
    for r in lad:
        p("| lag%d k%d | %d | %d | %.4f | %.4f | %+.4f | %.3f / %.3f | %.3f / %.3f |"
          % (r["lag"], r["nprog"], r["T"], r["W_student"],
             r["teacher"]["ce_all"], r["student"]["ce_all"], r["delta"],
             r["teacher"]["instr_acc"], r["student"]["instr_acc"],
             r["teacher"]["instr_valid"], r["student"]["instr_valid"]))
    p("")
    p("  容量軸（lag=1, K=1/4/8/16）: CE_教師 0.0036 / 0.0828 / 0.0043 / 0.0121。")
    p("  **K を 16 倍にしても難度はほぼ上がらない**（K=1 と K=16 で instr_acc 0.991 vs 0.969）。")
    p("  深さ軸（lag=2, K=1）: CE_教師 **1.8132**、instr_acc **0.000**。**崖を越えて解けない。**")
    p("")

    p("== 2) K=4 の追試（5 seed、同一のプログラム集合） ==")
    rep = sorted(rep, key=lambda r: r["seed"])
    p("| seed | 生徒W | CE_教師 | CE_生徒 | ΔCE | instr_acc 教師/生徒 | instr_valid 教師/生徒 |")
    p("|---:|---:|---:|---:|---:|---:|---:|")
    for r in rep:
        p("| %d | %d | %.4f | %.4f | %+.4f | %.3f / %.3f | %.3f / %.3f |"
          % (r["seed"], r["W_student"], r["teacher"]["ce_all"], r["student"]["ce_all"],
             r["delta"], r["teacher"]["instr_acc"], r["student"]["instr_acc"],
             r["teacher"]["instr_valid"], r["student"]["instr_valid"]))
    p("")

    ct = np.array([r["teacher"]["ce_all"] for r in rep])
    cs = np.array([r["student"]["ce_all"] for r in rep])
    it = np.array([r["teacher"]["instr_valid"] for r in rep])
    is_ = np.array([r["student"]["instr_valid"] for r in rep])
    at = np.array([r["teacher"]["instr_acc"] for r in rep])
    as_ = np.array([r["student"]["instr_acc"] for r in rep])
    d = cs - ct

    def tt(a, b):
        x = np.asarray(a) - np.asarray(b)
        n = len(x)
        se = x.std(ddof=1) / np.sqrt(n)
        t = x.mean() / se
        return x.mean(), se, t, 2 * stats.t.sf(abs(t), df=n - 1)

    p("  平均（n=5）:")
    p("    CE:        教師 %.4f ± %.4f / 生徒 %.4f ± %.4f" % (ct.mean(), ct.std(ddof=1), cs.mean(), cs.std(ddof=1)))
    p("    instr_acc: 教師 %.3f ± %.3f / 生徒 %.3f ± %.3f" % (at.mean(), at.std(ddof=1), as_.mean(), as_.std(ddof=1)))
    p("    instr_valid: 教師 %.3f ± %.3f / 生徒 %.3f ± %.3f" % (it.mean(), it.std(ddof=1), is_.mean(), is_.std(ddof=1)))
    m, se, t, pv = tt(cs, ct)
    p("    ΔCE = %+.4f（se %.4f, t %+.2f, p %.3f, %d/5 負）" % (m, se, t, pv, int((d < 0).sum())))
    m, se, t, pv = tt(is_, it)
    p("    Δinstr_valid = %+.3f（se %.3f, t %+.2f, p %.3f）" % (m, se, t, pv))
    p("")
    F = (ct.std(ddof=1) / cs.std(ddof=1)) ** 2
    pvF = 2 * min(stats.f.sf(F, 4, 4), stats.f.cdf(F, 4, 4))
    p("  **分散の比（教師/生徒）**:")
    p("    CE の SD %.4f vs %.4f → F = %.1f（p %.4f）" % (ct.std(ddof=1), cs.std(ddof=1), F, pvF))
    p("    instr_valid の SD %.3f vs %.3f → F = %.1f"
      % (it.std(ddof=1), is_.std(ddof=1), (it.std(ddof=1) / is_.std(ddof=1)) ** 2))
    p("    **教師の方がばらつく**（CE で %.0f 倍、instr_valid で %.0f 倍）"
      % ((ct.std(ddof=1) / cs.std(ddof=1)) ** 2, (it.std(ddof=1) / is_.std(ddof=1)) ** 2))
    p("")

    p("== 3) 容量は本当に縛っているか（情報量で見る） ==")
    p("  課題の「知識」= プログラム列だけ。K 個 × steps 10 × log2(4) = K×20 bit。")
    p("  K=16 でも **320 bit**。生徒の FFN パラメータは W=107 で約 1.1e5 個 ≈ 3.5e6 bit。")
    p("  → **知識はパラメータの 0.01%。容量は縛りようがない。**")
    p("  縛るには K ≈ 1e4〜1e5（数百万 bit）が要る。それは「多数のプログラムの暗記」で、別の課題。")

    out = {"ladder": lad, "k4rep": rep,
           "k4_stats": {"ce_t": [float(ct.mean()), float(ct.std(ddof=1))],
                        "ce_s": [float(cs.mean()), float(cs.std(ddof=1))],
                        "iv_t": [float(it.mean()), float(it.std(ddof=1))],
                        "iv_s": [float(is_.mean()), float(is_.std(ddof=1))],
                        "delta_ce": [float(d.mean()), float(d.std(ddof=1) / np.sqrt(5))],
                        "F_ce": float(F), "p_F": float(pvF)}}
    with open(os.path.join(HERE, "k5_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=float)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n[write] %s" % OUT)


if __name__ == "__main__":
    main()
