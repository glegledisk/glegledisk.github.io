# -*- coding: utf-8 -*-
"""_a7_verify_report.py — 検証報告_A7 の数値を一次データから引き直して突合する。"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a4")
ok, bad = [], []


def chk(name, got, want, tol=5e-3):
    if abs(got - want) <= tol * max(1.0, abs(want)):
        ok.append(f"  OK  {name}: {got:.6g} (report {want})")
    else:
        bad.append(f"  NG  {name}: {got:.6g} != report {want}")


def load(fn):
    return [r for r in json.load(open(os.path.join(D, fn), encoding="utf-8"))
            if "evals" in r]


mid = load("a4_results_m.json")
base = load("a4_results.json")
wide = load("a4_results_w.json")

# --- 1. 構成 ---
mb = [r for r in mid if r["arm"] == "mid_base"]
mw = [r for r in mid if r["arm"] == "mid_wide4"]
chk("W_MID の合計", sum(mb[0]["widths"]), 1024, tol=0)
chk("W_MID の中身", 0, 0, tol=0)
if tuple(mb[0]["widths"]) != (32, 32, 192, 192, 192, 192, 96, 96):
    bad.append(f"  NG  W_MID が違う: {mb[0]['widths']}")
else:
    ok.append("  OK  W_MID = (32,32,192,192,192,192,96,96)")
chk("n mid_base", len(mb), 6, tol=0)
chk("n mid_wide4", len(mw), 6, tol=0)
_acts = [i for i, v in enumerate(mw[0]["act_i"]) if v == "relu2"]
if _acts != [2, 3, 4, 5]:
    bad.append(f"  NG  mid_wide4 の ReLU² expert: {_acts}")
else:
    ok.append("  OK  mid_wide4 の ReLU² expert = [2, 3, 4, 5]")

# --- 2. w×share の不変性 ---
CASES = [("BASE_W all_relu", base, "all_relu",
          [9.4, 8.7, 11.9, 10.9, 10.0, 9.8, 7.5, 8.9], 0.131),
         ("BASE_W wide4", wide, "wide4",
          [8.9, 8.8, 14.3, 13.3, 7.8, 7.0, 7.8, 7.2], 0.282),
         ("W_MID mid_base", mid, "mid_base",
          [9.2, 7.2, 10.5, 9.0, 10.2, 9.4, 14.2, 13.0], 0.205),
         ("W_MID mid_wide4", mid, "mid_wide4",
          [9.4, 8.3, 7.7, 7.1, 8.2, 7.1, 13.3, 14.7], 0.288)]
for nm, rows, arm, vals, cv in CASES:
    rs = [r for r in rows if r["arm"] == arm]
    u = np.array([r["routing"]["usage"] for r in rs]).mean(0)
    w = np.array(rs[0]["widths"], dtype=float)
    prod = w * u
    for i, v in enumerate(vals):
        chk(f"{nm} w×share e{i}", float(prod[i]), v, tol=2e-2)
    chk(f"{nm} CV", float(prod.std() / prod.mean()), cv, tol=5e-2)

# --- 3. 使用率の順位 ---
u = np.array([r["routing"]["usage"] for r in mb]).mean(0)
SH = {0: 0.2883, 1: 0.2247, 6: 0.1482, 7: 0.1350, 2: 0.0547, 4: 0.0533,
      5: 0.0491, 3: 0.0466}
for i, v in SH.items():
    chk(f"usage e{i}", float(u[i]), v, tol=5e-3)
W = mb[0]["widths"]
order_w = set(sorted(range(len(W)), key=lambda i: -W[i])[:4])
order_u = set(int(i) for i in np.argsort(u)[:4])
chk("幅順と使用率順が一致", int(order_w == order_u), 1, tol=0)

# --- 4. 再現の検定 ---
def paired(rows, a, b, key="instr_valid"):
    da = {r["seed"]: r["evals"][-1][key] for r in rows if r["arm"] == a}
    db = {r["seed"]: r["evals"][-1][key] for r in rows if r["arm"] == b}
    ks = sorted(set(da) & set(db))
    x = np.array([da[i] for i in ks])
    y = np.array([db[i] for i in ks])
    d = x - y
    se = d.std(ddof=1) / math.sqrt(len(d))
    t, p = stats.ttest_rel(x, y)
    mde = (stats.t.ppf(0.975, len(d) - 1) + stats.t.ppf(0.80, len(d) - 1)) * se
    return float(d.mean()), float(se), float(t), float(p), int((d > 0).sum()), float(mde), d


m, se, t, p, pos, mde, d = paired(mid, "mid_wide4", "mid_base")
chk("mid Δ", m, -0.1180, tol=1e-2)
chk("mid se", se, 0.1109, tol=2e-2)
chk("mid t", t, -1.06, tol=3e-2)
chk("mid p", p, 0.336, tol=5e-2)
chk("mid 正の seed", pos, 3, tol=0)
chk("mid MDE", mde, 0.387, tol=2e-2)
for v, want in zip(d, [-0.315, -0.192, 0.044, 0.189, 0.088, -0.520]):
    chk("mid seed Δ", float(v), want, tol=5e-2)

m0, se0, t0, p0, pos0, mde0, _ = paired(base + wide, "wide4", "all_relu")
chk("BASE_W wide4 Δ", m0, 0.2017, tol=5e-3)
chk("BASE_W wide4 p", p0, 0.026, tol=5e-2)
chk("BASE_W wide4 正の seed", pos0, 6, tol=0)
chk("BASE_W wide4 MDE", mde0, 0.224, tol=2e-2)
chk("符号が逆", int(np.sign(m0) != np.sign(m)), 1, tol=0)

m2, _, _, p2, _, _, _ = paired(mid + base, "mid_base", "all_relu")
chk("mid_base − all_relu", m2, 0.0887, tol=2e-2)
chk("mid_base − all_relu p", p2, 0.361, tol=5e-2)

# --- 5. 平均の到達点 ---
chk("mid_base iv", float(np.mean([r["evals"][-1]["instr_valid"] for r in mb])), 0.732, tol=5e-3)
chk("mid_wide4 iv", float(np.mean([r["evals"][-1]["instr_valid"] for r in mw])), 0.614, tol=5e-3)

# --- 6. 2 つの推定の中間 ---
chk("2 推定の中間", (m0 + m) / 2, 0.042, tol=5e-2)

print("\n".join(ok))
if bad:
    print("\n".join(bad))
    print(f"\nFAIL: {len(bad)} 件")
    sys.exit(1)
print(f"\nPASS: {len(ok)} 件すべて報告書と一致")
