# -*- coding: utf-8 -*-
"""AX7 事前調査（モデル不要）。

目的: AX4 の N=102 / 181 平坦区間が「窓内完結の端数単位」で説明できるかを、
      走行前に分割統計だけで見積もる。数値は _ax7_probe.json へ。
"""
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
N_WIN, LEN, N_EVAL = 48, 256, 255
N_TOK = N_WIN * N_EVAL
N_LAYERS = 16

z4 = np.load(os.path.join(HERE, "ax4_sentence_bound.npz"))
z5 = np.load(os.path.join(HERE, "ax5_granularity_mech.npz"))
sent = z4["sent"].astype(np.int64)
c8 = z4["c8"].astype(np.float64)
c7 = z4["c7"].astype(np.float64)
assert sent.shape == (N_TOK,)
assert c8.shape == (N_LAYERS, N_TOK) and c7.shape == (N_LAYERS, N_TOK)
n_sent = int(sent.max()) + 1


def group_units(sid, k, n_win=N_WIN, n_eval=N_EVAL):
    """AX4 と同一: 窓内ローカル文 ID を k 個まとめる（窓をまたがない）。"""
    out = np.zeros_like(sid)
    off = 0
    for w in range(n_win):
        sl = slice(w * n_eval, (w + 1) * n_eval)
        sw = sid[sl]
        lo = sw - sw.min()
        out[sl] = off + lo // k
        off = int(out[sl].max()) + 1
    return out


def global_group(sid, k):
    """窓境界をまたぐ大域まとめ。端数単位は全体で 1 つだけ。"""
    return sid // k


def lengths(uid):
    return np.bincount(uid).astype(np.int64)


def desc(lens):
    share = lens / lens.sum()
    return {
        "N": int(lens.size),
        "mean": float(lens.mean()),
        "sd": float(lens.std(ddof=1)),
        "cv": float(lens.std(ddof=1) / lens.mean()),
        "min": int(lens.min()),
        "p10": float(np.percentile(lens, 10)),
        "median": float(np.median(lens)),
        "p90": float(np.percentile(lens, 90)),
        "max": int(lens.max()),
        "eff_units": float(1.0 / (share ** 2).sum()),  # Simpson の逆数＝実効単位数
        "n_short_le20": int((lens <= 20).sum()),
        "short_le20_share": float((lens <= 20).mean()),
        "n_short_le40": int((lens <= 40).sum()),
        "short_le40_share": float((lens <= 40).mean()),
    }


out = {"n_sent": n_sent, "n_tok": N_TOK, "splits": {}, "calib": {}, "gains": {}}

# ---- 1. 窓内完結 / 大域まとめの k 系列 ----
for k in (1, 2, 3, 4, 6, 8):
    w = group_units(sent, k)
    g = global_group(sent, k)
    out["splits"]["win_k%d" % k] = desc(lengths(w))
    out["splits"]["glob_k%d" % k] = desc(lengths(g))
    # 端数単位 = 所属文数が k 未満。窓内完結では各窓に 1 つ生じうる
    cnt_sent_per_unit = {}
    for w_ in range(N_WIN):
        sl = slice(w_ * N_EVAL, (w_ + 1) * N_EVAL)
        u = w[sl]
        lo = sent[sl] - sent[sl].min()
        for uid in np.unique(u):
            cnt_sent_per_unit.setdefault(int(uid), set()).update(
                set(np.unique(lo[u == uid]).tolist()))
    partial = sum(1 for v in cnt_sent_per_unit.values() if len(v) < k)
    out["splits"]["win_k%d" % k]["n_partial"] = partial
    out["splits"]["win_k%d" % k]["partial_share"] = float(partial / len(cnt_sent_per_unit))

# ---- 2. 均一長（AX5 と同型）と、実文長の多重集合を shuffle した分割 ----
def uniform_parts(N):
    q, r = divmod(N_TOK, N)
    ls = np.full(N, q, dtype=np.int64)
    ls[:r] += 1
    assert ls.sum() == N_TOK
    return np.repeat(np.arange(N, dtype=np.int64), ls)


def shuffled_parts(src_uid, seed):
    ls = lengths(src_uid)
    rng = np.random.default_rng(seed)
    ls2 = rng.permutation(ls)
    assert ls2.sum() == N_TOK and np.array_equal(np.sort(ls), np.sort(ls2))
    return np.repeat(np.arange(ls2.size, dtype=np.int64), ls2)


for N in (102, 181):
    out["splits"]["uni%d" % N] = desc(lengths(uniform_parts(N)))
for k, tag in ((4, 102), (2, 181)):
    src = group_units(sent, k)
    for seed in (7201, 7202):
        out["splits"]["shift%d_s%d" % (tag, seed)] = desc(lengths(shuffled_parts(src, seed)))
    # 窓内完結の均一長（各窓を m_w 個へ均等分割）
    m_per_win = []
    uid = np.zeros(N_TOK, dtype=np.int64)
    off = 0
    for w_ in range(N_WIN):
        sl = slice(w_ * N_EVAL, (w_ + 1) * N_EVAL)
        m = int(group_units(sent, k)[sl].max() - group_units(sent, k)[sl].min() + 1)
        m_per_win.append(m)
        q, r = divmod(N_EVAL, m)
        ls = np.full(m, q, dtype=np.int64)
        ls[:r] += 1
        uid[sl] = np.repeat(np.arange(off, off + m, dtype=np.int64), ls)
        off += m
    out["splits"]["uni%dw" % tag] = desc(lengths(uid))

# ---- 3. 校正: 既存保存配列の整合 ----
u7_4 = z4["nll_u7_rep"].astype(np.float64)
u7_5 = z5["nll_u7_rep"].astype(np.float64)
b_4 = z4["nll_base_rep"].astype(np.float64)
out["calib"]["u7_ax4_vs_ax5_maxdiff"] = float(np.abs(u7_4 - u7_5).max())
out["calib"]["c8_ax4_vs_ax5_maxdiff"] = float(np.abs(c8 - z5["c8"]).max())
out["calib"]["c7_ax4_vs_ax5_maxdiff"] = float(np.abs(c7 - z5["c7"]).max())
out["calib"]["base_ce"] = float(b_4.mean())
out["calib"]["u7_ce"] = float(u7_4.mean())

# ---- 4. 既存腕の利得を引き直す（G = mean(nll_u7 - nll_arm)） ----
arms4 = {"sent_oracle": "sent340", "sent2_oracle": "sent2", "sent4_oracle": "sent4",
         "sent_nl_oracle": "sent_nl", "sent_random": "sent_random"}
arms5 = {"uni102": "uni102", "uni181": "uni181", "uni340": "uni340",
         "shift340": "shift340", "shift340b": "shift340b", "global1": "global1",
         "sent340_rep": "sent340_rep"}
for src, mapping in ((z4, arms4), (z5, arms5)):
    for key, nm in mapping.items():
        k = "nll_" + key
        if k not in src.files:
            continue
        out["gains"][nm] = float((u7_4 - src[k].astype(np.float64)).mean())

G = out["gains"]
for a, b in (("sent340", "sent340_rep"),):
    if a in G and b in G:
        out["calib"]["G_%s_minus_%s" % (a, b)] = G[a] - G[b]
out["calib"]["flat_ax4_sent2_minus_sent4"] = G.get("sent2", float("nan")) - G.get("sent4", float("nan"))
out["calib"]["flat_ax5_uni181_minus_uni102"] = G.get("uni181", float("nan")) - G.get("uni102", float("nan"))
out["calib"]["shift_N102_minus_uni102"] = G.get("sent4", float("nan")) - G.get("uni102", float("nan"))
out["calib"]["shift_N181_minus_uni181"] = G.get("sent2", float("nan")) - G.get("uni181", float("nan"))

with open(os.path.join(HERE, "_ax7_probe.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2, ensure_ascii=False, allow_nan=False)

print("n_sent=%d  n_tok=%d" % (n_sent, N_TOK))
print("calib u7 ax4/ax5 maxdiff %.3g  c8 %.3g  c7 %.3g" %
      (out["calib"]["u7_ax4_vs_ax5_maxdiff"],
       out["calib"]["c8_ax4_vs_ax5_maxdiff"],
       out["calib"]["c7_ax4_vs_ax5_maxdiff"]))
print("G sent340 %.8f  sent340_rep %.8f  (diff %.3g)" %
      (G.get("sent340", float("nan")), G.get("sent340_rep", float("nan")),
       out["calib"].get("G_sent340_minus_sent340_rep", float("nan"))))
print("flat AX4 sent2-sent4 %+.8f   AX5 uni181-uni102 %+.8f" %
      (out["calib"]["flat_ax4_sent2_minus_sent4"],
       out["calib"]["flat_ax5_uni181_minus_uni102"]))
print("N=102 sent4 - uni102 %+.8f    N=181 sent2 - uni181 %+.8f" %
      (out["calib"]["shift_N102_minus_uni102"],
       out["calib"]["shift_N181_minus_uni181"]))
print()
print("%-22s %5s %7s %7s %6s %6s %8s %8s" %
      ("split", "N", "mean", "cv", "min", "p90", "eff_U", "partial"))
for nm, d in out["splits"].items():
    print("%-22s %5d %7.2f %7.3f %6d %6.0f %8.2f %8s" %
          (nm, d["N"], d["mean"], d["cv"], d["min"], d["p90"],
           d["eff_units"], ("%.3f" % d["partial_share"]) if "partial_share" in d else "-"))
