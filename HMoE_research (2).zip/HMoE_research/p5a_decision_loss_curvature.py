# -*- coding: utf-8 -*-
"""
p5a: 損失関数を変えると配分の不等式はどう動くか（二次解析・追加の forward なし）

既存の per-token NLL だけを使い、P3/P3b の「凸性比 ρ」「非対称性 c_b/c_f」
「Jensen ペナルティ」を 2 つの損失で再計算する。

  CE  : l_j(k) = NLL_j(k)                       （P3 の主目的関数）
  0-1 : L_j(k) = 1 - exp(-NLL_j(k)) = 1 - p_true （モデル自身の分布に対する期待 0-1 損失）

さらに「実測 0-1」（top-1 が外れたら 1）も併記する（低検出力だが仮定なし）。

出力: p5a_decision_loss.json / p5a_out_utf8.txt / p5a_decision_loss_figure.png
"""
import json
import math
import numpy as np

# scipy はこの venv に無い。paired t は定義どおり手計算し、
# p 値は df=12239 で正規近似（誤差 < 1e-4）。
class _T:
    def __init__(self, a, b):
        d = np.asarray(a, float) - np.asarray(b, float)
        nn = d.size
        self.statistic = float(d.mean() / (d.std(ddof=1) / math.sqrt(nn)))
        self.pvalue = float(math.erfc(abs(self.statistic) / math.sqrt(2)))


class stats:
    ttest_rel = staticmethod(_T)


OUT = {}
LOG = []


def p(*a):
    s = " ".join(str(x) for x in a)
    LOG.append(s)
    print(s)


# ---------------------------------------------------------------- data
d3 = np.load("p3_topk_nll.npz", allow_pickle=True)
nll = {k: d3[k].astype(np.float64) for k in ["k8", "k7", "k6", "k4", "k2", "k1"]}
d3b = np.load("p3b_alloc_nll.npz", allow_pickle=True)
alloc = {k: d3b[k].astype(np.float64) for k in
         ["base", "u7", "f6b8", "f8b6", "base_top1", "u7_top1", "f6b8_top1", "f8b6_top1"]}
n = nll["k8"].size
p(f"tokens = {n}")
p(f"baseline CE(k=8) = {nll['k8'].mean():.5f}   (P3 報告値 2.60047)")
p(f"baseline CE(base) = {alloc['base'].mean():.5f}  (P3b 報告値 2.60047)")

# 損失の定義
def L01(x):
    return 1.0 - np.exp(-x)


CE = {k: v for k, v in nll.items()}
O1 = {k: L01(v) for k, v in nll.items()}
CEa = {k: alloc[k] for k in ["base", "u7", "f6b8", "f8b6"]}
O1a = {k: L01(alloc[k]) for k in ["base", "u7", "f6b8", "f8b6"]}

# ---------------------------------------------------------------- 1. 均一曲線と凸性
slots = {"k8": 0, "k7": 16, "k6": 32, "k4": 64, "k2": 96, "k1": 112}
p("\n=== 1. 均一曲線（層全体で一様に k を削る） ===")
p(f"{'k':>3} {'slots':>6} {'CE':>9} {'dCE':>9} {'0-1':>9} {'d0-1':>9}")
curve = {}
for k in ["k8", "k7", "k6", "k4", "k2", "k1"]:
    curve[k] = dict(slots=slots[k], ce=float(CE[k].mean()), o1=float(O1[k].mean()))
    p(f"{k:>3} {slots[k]:>6} {CE[k].mean():9.5f} {CE[k].mean()-CE['k8'].mean():+9.5f} "
      f"{O1[k].mean():9.5f} {O1[k].mean()-O1['k8'].mean():+9.5f}")

# 限界コスト / スロット（P3b と同じ区間）
def marginal(cur, a, b):
    return (cur[b] - cur[a]) / (slots[b] - slots[a])


p("\n--- 限界コスト / スロット ---")
marg = {}
for loss_name, cur in [("CE", {k: v["ce"] for k, v in curve.items()}),
                       ("0-1", {k: v["o1"] for k, v in curve.items()})]:
    m1 = marginal(cur, "k8", "k7")
    m2 = marginal(cur, "k7", "k6")
    m3 = marginal(cur, "k6", "k4")
    marg[loss_name] = dict(m1=m1, m2=m2, m3=m3, rho=m2 / m1, rho3=m3 / m1)
    p(f"{loss_name:>4}: m1={m1:.6f}  m2={m2:.6f}  m3={m3:.6f}   "
      f"rho=m2/m1={m2/m1:.3f}   m3/m1={m3/m1:.3f}")
OUT["marginal"] = marg

# ---------------------------------------------------------------- 2. 層の非対称性
p("\n=== 2. 層方向（P3b の 6 配分のうち per-token がある 4 本） ===")
for name, cur in [("CE", CEa), ("0-1", O1a)]:
    p(f"[{name}]")
    for k in ["base", "u7", "f6b8", "f8b6"]:
        p(f"  {k:>5}: {cur[k].mean():.6f}  d={cur[k].mean()-cur['base'].mean():+.6f}")
    dif = cur["f6b8"] - cur["u7"]
    t = stats.ttest_rel(cur["f6b8"], cur["u7"])
    p(f"  f6b8 - u7 = {dif.mean():+.6f}  se={dif.std(ddof=1)/np.sqrt(n):.6f}  t={t.statistic:+.2f}")
    dif2 = cur["f6b8"] - cur["f8b6"]
    t2 = stats.ttest_rel(cur["f6b8"], cur["f8b6"])
    p(f"  f6b8 - f8b6 = {dif2.mean():+.6f}  t={t2.statistic:+.2f}  (層の非対称性)")
    OUT[f"layer_{name}"] = dict(
        base=float(cur["base"].mean()), u7=float(cur["u7"].mean()),
        f6b8=float(cur["f6b8"].mean()), f8b6=float(cur["f8b6"].mean()),
        f6b8_minus_u7=float(dif.mean()), t_vs_u7=float(t.statistic),
        f6b8_minus_f8b6=float(dif2.mean()), t_asym=float(t2.statistic))

# c_f, c_b（8 層ぶんの合計）と ρ から不等式を判定
p("\n--- 配分の不等式: 1 + rho < c_b/c_f か ---")
ineq = {}
for name, cur, rho in [("CE", CEa, marg["CE"]["rho"]), ("0-1", O1a, marg["0-1"]["rho"])]:
    d_u7 = cur["u7"].mean() - cur["base"].mean()
    d_f6 = cur["f6b8"].mean() - cur["base"].mean()
    d_f8 = cur["f8b6"].mean() - cur["base"].mean()
    cf = d_u7 / 16.0            # 1 層 1 本目のコスト（均一から）
    cb = d_f8 / (8.0 * (1.0 + rho))  # 後半 1 本目（f8b6 = 8*cb*(1+rho)）
    ratio = cb / cf
    lhs = 1.0 + rho
    ineq[name] = dict(cf=float(cf), cb=float(cb), cb_over_cf=float(ratio),
                      one_plus_rho=float(lhs), holds=bool(lhs < ratio),
                      needed_rho=float(ratio - 1.0),
                      predicted_f6b8=float(8 * cf * (1 + rho)),
                      actual_f6b8=float(d_f6))
    p(f"{name:>4}: c_f={cf:.6f} c_b={cb:.6f} c_b/c_f={ratio:.3f}  1+rho={lhs:.3f} "
      f"-> {'成立' if lhs < ratio else '不成立'} (必要 rho < {ratio-1:.3f})")
    p(f"      予測 f6b8={8*cf*(1+rho):+.6f} vs 実測 {d_f6:+.6f}")
OUT["inequality"] = ineq

# ---------------------------------------------------------------- 3. Jensen ペナルティ
p("\n=== 3. Jensen ペナルティ（{6,8} 混合 vs 均一 7） ===")
jens = {}
for name, cur in [("CE", CE), ("0-1", O1)]:
    j68 = 0.5 * (cur["k6"].mean() + cur["k8"].mean()) - cur["k7"].mean()
    j78 = 0.25 * j68           # 等間隔 2 次差分より J{7,8} = J{6,8}/4
    scale = cur["k8"].mean()
    jens[name] = dict(j68=float(j68), j78=float(j78), scale=float(scale),
                      rel68=float(j68 / scale), rel78=float(j78 / scale))
    p(f"{name:>4}: J{{6,8}}={j68:+.6f}  J{{7,8}}={j78:+.6f}   損失スケール={scale:.4f}  "
      f"相対 J{{6,8}}={100*j68/scale:.3f}%")
p(f"相対 Jensen の縮小率: {jens['CE']['rel68']/jens['0-1']['rel68']:.2f} 倍")
OUT["jensen"] = jens

# ---------------------------------------------------------------- 4. トークン方向の不均一
p("\n=== 4. トークン方向の不均一（k=7 -> k=8 の削減コスト） ===")
dCE_tok = CE["k7"] - CE["k8"]
dO1_tok = O1["k7"] - O1["k8"]
p(f"mean dCE={dCE_tok.mean():+.6f}  mean dL01={dO1_tok.mean():+.6f}")
p(f"dCE  : p50={np.median(dCE_tok):+.6f}  p99={np.percentile(dCE_tok,99):.4f}  max={dCE_tok.max():.4f}")
p(f"dL01 : p50={np.median(dO1_tok):+.6f}  p99={np.percentile(dO1_tok,99):.4f}  max={dO1_tok.max():.4f}")

# 難易度（baseline NLL）の四分位で切る
q = np.percentile(CE["k8"], [25, 50, 75])
grp = np.digitize(CE["k8"], q)
p("\n難易度四分位（baseline NLL 昇順）ごとの平均:")
p(f"{'Q':>3} {'n':>6} {'NLL8':>8} {'dCE':>9} {'dL01':>9} {'dCE/dCE_Q1':>11} {'dL01/dL01_Q1':>13}")
tab = []
for g in range(4):
    m = grp == g
    tab.append(dict(q=g + 1, n=int(m.sum()), nll8=float(CE["k8"][m].mean()),
                    dce=float(dCE_tok[m].mean()), d01=float(dO1_tok[m].mean())))
r_ce = tab[3]["dce"] / tab[0]["dce"]
r_01 = tab[3]["d01"] / tab[0]["d01"]
for row in tab:
    p(f"{row['q']:>3} {row['n']:>6} {row['nll8']:8.4f} {row['dce']:+9.5f} {row['d01']:+9.6f} "
      f"{row['dce']/tab[0]['dce']:>11.2f} {row['d01']/tab[0]['d01']:>13.2f}")
p(f"Q4/Q1 比:  dCE {r_ce:.2f} 倍   dL01 {r_01:.2f} 倍")
OUT["quartile"] = dict(rows=tab, ratio_ce=float(r_ce), ratio_01=float(r_01))

# 裾の集中度
def top_share(x, frac=0.01):
    k = max(1, int(round(frac * x.size)))
    idx = np.argsort(-x)[:k]
    return float(x[idx].sum() / x.sum())


def top_share_abs(x, frac=0.01):
    k = max(1, int(round(frac * x.size)))
    idx = np.argsort(-np.abs(x))[:k]
    return float(np.abs(x[idx]).sum() / np.abs(x).sum())


p("\n上位 1% のトークンが総コストに占める割合:")
p(f"  dCE : {100*top_share(dCE_tok):.1f}%  (|dCE| で {100*top_share_abs(dCE_tok):.1f}%)")
p(f"  dL01: 総和が {dO1_tok.sum():+.4f} で符号が反転しているため比は定義できない。"
  f"|dL01| で {100*top_share_abs(dO1_tok):.1f}%")
p(f"  正の寄与の総和 {dO1_tok[dO1_tok>0].sum():+.4f} / 負の寄与の総和 "
  f"{dO1_tok[dO1_tok<0].sum():+.4f}")
OUT["tail_share"] = dict(ce=top_share(dCE_tok), ce_abs=top_share_abs(dCE_tok),
                         o1_abs=top_share_abs(dO1_tok),
                         o1_pos=float(dO1_tok[dO1_tok > 0].sum()),
                         o1_neg=float(dO1_tok[dO1_tok < 0].sum()))

# u7 vs base の対応検定（両損失）
p("\n均一 top-7 vs top-8 の対応検定（12,240 トークン）:")
for nm, cur in [("CE", CE), ("0-1", O1)]:
    dif = cur["k7"] - cur["k8"]
    tt = stats.ttest_rel(cur["k7"], cur["k8"])
    p(f"  {nm:>4}: d={dif.mean():+.6f}  se={dif.std(ddof=1)/np.sqrt(n):.6f}  "
      f"t={tt.statistic:+.2f}  p={tt.pvalue:.2e}")
    OUT[f"u7_vs_base_{nm}"] = dict(d=float(dif.mean()), t=float(tt.statistic),
                                   p=float(tt.pvalue))

# 後半削減 vs 均一（0-1）
dif = O1a["f8b6"] - O1a["u7"]
tt = stats.ttest_rel(O1a["f8b6"], O1a["u7"])
p(f"  0-1 で f8b6 - u7 = {dif.mean():+.6f}  t={tt.statistic:+.2f}  "
  f"(CE では +0.01674 で明確に悪い)")
OUT["f8b6_vs_u7_01"] = dict(d=float(dif.mean()), t=float(tt.statistic))

# ---------------------------------------------------------------- 4b. 難易度 10 分位で見る「計算の価値」
p("\n=== 4b. 難易度 10 分位: 計算を増やしたときの損失減（k=8 を基準に、削減コスト） ===")
dec = np.clip((np.argsort(np.argsort(CE["k8"])) * 10 // n), 0, 9)
dec_rows = []
p(f"{'D':>2} {'n':>5} {'NLL8':>7} | {'dCE(8->6)':>10} {'dCE(8->4)':>10} | "
  f"{'dL01(8->6)':>11} {'dL01(8->4)':>11}")
for g in range(10):
    m = dec == g
    r = dict(dec=g + 1, n=int(m.sum()), nll8=float(CE["k8"][m].mean()),
             dce6=float((CE["k6"][m] - CE["k8"][m]).mean()),
             dce4=float((CE["k4"][m] - CE["k8"][m]).mean()),
             d016=float((O1["k6"][m] - O1["k8"][m]).mean()),
             d014=float((O1["k4"][m] - O1["k8"][m]).mean()))
    dec_rows.append(r)
    p(f"{r['dec']:>2} {r['n']:>5} {r['nll8']:7.3f} | {r['dce6']:+10.5f} {r['dce4']:+10.5f} | "
      f"{r['d016']:+11.6f} {r['d014']:+11.6f}")
OUT["decile"] = dec_rows
pk_ce = max(dec_rows, key=lambda r: r["dce4"])
pk_01 = max(dec_rows, key=lambda r: r["d014"])
p(f"ピーク: dCE は D{pk_ce['dec']} (NLL {pk_ce['nll8']:.2f}), "
  f"dL01 は D{pk_01['dec']} (NLL {pk_01['nll8']:.2f})")
OUT["peak"] = dict(ce=pk_ce, o1=pk_01)


# 「決定済み」の割合（計算を増やしても 0-1 損失が動かないトークン）
for eps in [1e-4, 1e-3, 1e-2]:
    p(f"  |dL01| < {eps:g} のトークン: {100*np.mean(np.abs(dO1_tok) < eps):.1f}%  "
      f"(|dCE| < {eps:g}: {100*np.mean(np.abs(dCE_tok) < eps):.1f}%)")
OUT["saturated"] = {str(e): float(np.mean(np.abs(dO1_tok) < e)) for e in [1e-4, 1e-3, 1e-2]}

# ---------------------------------------------------------------- 5. 実測 0-1（仮定なし）
p("\n=== 5. 実測 0-1 損失（top-1 ミス率、仮定なし・低検出力） ===")
for k in ["base", "u7", "f6b8", "f8b6"]:
    acc = alloc[f"{k}_top1"].mean()
    p(f"  {k:>5}: acc={acc:.4f}  err={1-acc:.4f}  n_err={int(round((1-acc)*n))}")
e_u7 = 1 - alloc["u7_top1"]
e_f6 = 1 - alloc["f6b8_top1"]
diff = e_f6 - e_u7
tt = stats.ttest_rel(e_f6, e_u7)
sd = diff.std(ddof=1)
mde = 2.8 * sd / np.sqrt(n)
p(f"  err(f6b8) - err(u7) = {diff.mean():+.5f}  t={tt.statistic:+.2f}  "
  f"MDE(80%, a=.05) = {mde:.5f}")
OUT["realized01"] = dict(
    err={k: float(1 - alloc[f"{k}_top1"].mean()) for k in ["base", "u7", "f6b8", "f8b6"]},
    diff=float(diff.mean()), t=float(tt.statistic), mde=float(mde))

# ---------------------------------------------------------------- 6. 頑健性
p("\n=== 6. 頑健性: 言語分割とブートストラップ ===")
lang = d3["lang"]
win = np.repeat(np.arange(lang.size), n // lang.size)
p(f"windows={lang.size}  tokens/window={n // lang.size}  言語: "
  f"{ {u: int((lang == u).sum()) for u in np.unique(lang)} }")
OUT["robust"] = {}
for u in np.unique(lang):
    m = lang[win] == u
    for nm, cur in [("CE", CE), ("0-1", O1)]:
        dif = (cur["k7"] - cur["k8"])[m]
        tt = stats.ttest_rel(cur["k7"][m], cur["k8"][m])
        p(f"  {u} n={int(m.sum()):>5}  {nm:>4}: d={dif.mean():+.6f}  t={tt.statistic:+.2f}")
        OUT["robust"][f"{u}_{nm}"] = dict(n=int(m.sum()), d=float(dif.mean()),
                                          t=float(tt.statistic))

rng = np.random.default_rng(0)
B = 4000
boot = np.empty(B)
idx_all = np.arange(n)
for b in range(B):
    s = rng.integers(0, n, n)
    boot[b] = dO1_tok[s].mean()
lo, hi = np.percentile(boot, [2.5, 97.5])
p(f"  bootstrap(4000) mean d0-1 の 95%CI = [{lo:+.6f}, {hi:+.6f}]  "
  f"(点推定 {dO1_tok.mean():+.6f})")
boot_ce = np.empty(B)
for b in range(B):
    s = rng.integers(0, n, n)
    boot_ce[b] = dCE_tok[s].mean()
lo2, hi2 = np.percentile(boot_ce, [2.5, 97.5])
p(f"  bootstrap(4000) mean dCE の 95%CI = [{lo2:+.6f}, {hi2:+.6f}]")
OUT["bootstrap"] = dict(o1_ci=[float(lo), float(hi)], ce_ci=[float(lo2), float(hi2)])

# ---------------------------------------------------------------- 7. 図
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.3), dpi=140)
    s = [curve[k]["slots"] for k in ["k8", "k7", "k6", "k4"]]
    ce = [curve[k]["ce"] - curve["k8"]["ce"] for k in ["k8", "k7", "k6", "k4"]]
    o1 = [curve[k]["o1"] - curve["k8"]["o1"] for k in ["k8", "k7", "k6", "k4"]]
    ax[0].plot(s, ce, "o-", color="C0", label="CE (nats, left)")
    ax[0].axhline(0, color="gray", lw=0.6)
    ax2 = ax[0].twinx()
    ax2.plot(s, o1, "s-", color="C3", label="0-1 (expected, right)")
    ax2.axhline(0, color="C3", lw=0.5, ls=":")
    ax[0].set_xlabel("slots removed per token  (16 layers x (8-k))")
    ax[0].set_ylabel("CE increase vs k=8")
    ax2.set_ylabel("0-1 loss increase vs k=8")
    ax[0].set_title("Same data, two objectives: 0-1 is not monotone")
    h1, l1 = ax[0].get_legend_handles_labels()
    h2, l2 = ax2.get_legend_handles_labels()
    ax[0].legend(h1 + h2, l1 + l2, loc="upper left", fontsize=8)
    ax[0].grid(alpha=0.3)

    xs = [r["dec"] for r in dec_rows]
    ax[1].plot(xs, [r["dce4"] for r in dec_rows], "o-", color="C0", label="dCE (8->4)")
    ax[1].set_xlabel("difficulty decile of baseline NLL (1=easy, 10=hard)")
    ax[1].set_ylabel("dCE")
    ax3 = ax[1].twinx()
    ax3.plot(xs, [r["d014"] for r in dec_rows], "s-", color="C3", label="d0-1 (8->4)")
    ax3.set_ylabel("d0-1")
    ax[1].set_title("Value of compute: CE peaks at the hard end, 0-1 in the middle")
    h1, l1 = ax[1].get_legend_handles_labels()
    h3, l3 = ax3.get_legend_handles_labels()
    ax[1].legend(h1 + h3, l1 + l3, loc="upper left", fontsize=8)
    ax[1].grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig("p5a_decision_loss_figure.png")
    p("\nsaved p5a_decision_loss_figure.png")
except Exception as e:  # pragma: no cover
    p("figure failed:", e)

with open("p5a_decision_loss.json", "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=2)
with open("p5a_out_utf8.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(LOG))
p("\ndone")
