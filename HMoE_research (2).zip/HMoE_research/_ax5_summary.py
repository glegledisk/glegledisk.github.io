#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX5 報告書用の数値抽出（JSON/npz の読み直しのみ。計算は再掲）。"""
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TAG = "ax5"
with open(os.path.join(HERE, "%s_granularity_mech.json" % TAG),
          encoding="utf-8") as fp:
    J = json.load(fp)
z = np.load(os.path.join(HERE, "%s_granularity_mech.npz" % TAG))

print("== meta ==")
print(json.dumps(J["meta"], ensure_ascii=False))
print("C1", json.dumps(J["calib"]["C1"], ensure_ascii=False))
print("C4 n_bad", J["calib"]["C4"]["n_bad"])

print("\n== C2 parts ==")
for nm, p in J["calib"]["C2"]["parts"].items():
    s = p["len_stats"]
    print("%-12s N %5d mean %7.3f cv %.4f min %3d max %4d p10 %6.2f p90 %6.2f"
          % (nm, p["n_unit"], s["mean"], s["cv"], s["min"], s["max"],
             s["p10"], s["p90"]))

print("\n== confirmatory ==")
for k in ("H1_uniform_minus_sent", "H2_sent_minus_shift"):
    s = J["confirmatory"][k]
    print(k, "mean %+.8f se %.8f t %+.4f p %.6g mde %.8f med %+.8f"
          % (s["mean"], s["se"], s["t"], s["p_two"], s["mde"], s["median"]))
    print("   ci95 [%+.8f, %+.8f] n_pos %d n_neg %d top1 %.4f"
          % (s["ci95"][0], s["ci95"][1], s["n_pos"], s["n_neg"],
             s["top1_abs_share"]))
print("holm", J["confirmatory"]["holm"], "reject", J["confirmatory"]["reject"],
      "case", J["confirmatory"]["case"])
h3 = J["manipulation_check_H3"]
print("H3 mean %+.8f se %.8f t %+.4f p %.6g mde %.8f ci95 [%+.8f, %+.8f]"
      % (h3["mean"], h3["se"], h3["t"], h3["p_two"], h3["mde"],
         h3["ci95"][0], h3["ci95"][1]))
print("H3 weights", ["%+.6f" % w for w in h3["weights"]])

print("\n== C7 ==")
print(J["calib"]["C7"])
print("C6", json.dumps(J["calib"]["C6"], ensure_ascii=False))

print("\n== gains ==")
for nm, s in J["exploratory"]["gains"].items():
    print("%-12s %+.8f se %.8f t %+8.4f p %.4g mde %.8f med %+.8f pos %5d neg %5d top1 %.4f"
          % (nm, s["mean"], s["se"], s["t"], s["p_two"], s["mde"],
             s["median"], s["n_pos"], s["n_neg"], s["top1_abs_share"]))

print("\n== curve ==")
for nm, v in J["exploratory"]["granularity_curve"].items():
    print("%-12s %+.8f" % (nm, v))
print("window_controls", {k: round(v, 8) for k, v in
                          J["exploratory"]["window_controls"].items()})
print("tok ratio: ", {nm: round(v / J["exploratory"]["granularity_curve"]["tok12240"], 4)
                      for nm, v in J["exploratory"]["granularity_curve"].items()})

print("\n== decomposition ==")
for nm, s in J["exploratory"]["decomposition"].items():
    print("%-28s %+.8f se %.8f t %+8.4f p %.4g mde %.8f"
          % (nm, s["mean"], s["se"], s["t"], s["p_two"], s["mde"]))

print("\n== jensen ==")
js = J["exploratory"]["jensen"]
print("coef", ["%+.8f" % c for c in js["coef"]], "r2 %.6f" % js["r2_uniform"])
for nm in ("sent340", "shift340", "shift340b", "lognorm340", "alt340",
           "uni340w", "shift340w", "tok12240"):
    d = js[nm]
    print("%-12s pred %+.8f obs %+.8f resid %+.8f"
          % (nm, d["pred"], d["obs"], d["resid"]))

print("\n== regression ==")
rg = J["exploratory"]["regression"]
print("beta", ["%+.8f" % b for b in rg["beta"]], "r2 %.6f r2_loo %.6f"
      % (rg["r2"], rg["r2_loo"]))
print("pred_sent %+.8f resid_sent %+.8f" % (rg["pred_sent340"],
                                            rg["resid_sent340"]))
print("arms", rg["arms"])

print("\n== agreement ==")
for nm, d in J["exploratory"]["agreement"].items():
    print("%-12s cut %.4f prot %.4f both %.4f"
          % (nm, d["agree_cut"], d["agree_prot"], d["agree_both"]))

print("\n== jensen gap descriptive ==")
for nm, d in J["exploratory"]["jensen_gap_descriptive"].items():
    print("%-12s cut %+.8f prot %+.8f total %+.8f"
          % (nm, d["cut_gap"], d["prot_gap"], d["total"]))

print("\n== results ==")
for nm, r in J["results"].items():
    print("%-12s CE %.6f dCE %+.8f top1 %.4f mean_k %.6f"
          % (nm, r["ce"], r["delta_vs_u7"], r["top1"], r["mean_k"]))
