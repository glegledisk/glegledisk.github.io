"""
P4h: 「落とす Expert の重みノルム × ルーティング確率」でコストを予測できるか

動機:
  機構的特徴のスキャン（P4e）で、失う確率質量 `lost_mass` は d_j をほぼ説明しなかった
  （AUC 0.572 / Spearman 0.017）。ルータは「どれだけ重みを与えたか」しか教えない。
  しかし **Expert の出力の大きさ** はパラメータから事前に分かる:
      ||y_e|| ≈ ||W_down,e||_F × （活性の大きさ）
  よって `p_8 · ||W_down,8||_F` は「落とす寄与の大きさ」の**無料の推定**になる。
  これが d_j を予測するかを測る。

  実装上の注意: これは「Expert を実行せずに」計算できる（ノルムは静的、p はルータが出す）。

出力: p4_expertnorm.npz / 標準出力
"""

import json
import os

import numpy as np

from p4b_probe import auc_score, cv_predict, spearman

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "olmoe-1b-7b")


def expert_norms():
    """(n_layers, n_experts) の down_proj / gate_proj / up_proj の Frobenius ノルム。"""
    import glob
    from safetensors import safe_open

    shards = sorted(glob.glob(os.path.join(MODEL, "*.safetensors")))
    # どのキーがどのシャードにあるかを索引
    idx = {}
    for sh in shards:
        with safe_open(sh, framework="pt") as f:
            for k in f.keys():
                if "mlp.experts." in k and k.endswith(".weight"):
                    idx[k] = sh
    keys = sorted(idx)
    print("expert weight tensors: %d" % len(keys))

    out = {}
    cur_sh, cur_f = None, None
    for k in keys:
        if idx[k] != cur_sh:
            if cur_f is not None:
                cur_f.__exit__(None, None, None)
            cur_f = safe_open(idx[k], framework="pt")
            cur_f.__enter__()
            cur_sh = idx[k]
        t = cur_f.get_tensor(k).float()
        out[k] = float(t.norm().item())
        del t
    if cur_f is not None:
        cur_f.__exit__(None, None, None)

    n_layers, n_experts = 16, 64
    nd = np.zeros((n_layers, n_experts))
    ng = np.zeros((n_layers, n_experts))
    nu = np.zeros((n_layers, n_experts))
    for k, v in out.items():
        parts = k.split(".")
        l = int(parts[2]); e = int(parts[4]); which = parts[6]
        if which == "down_proj":
            nd[l, e] = v
        elif which == "gate_proj":
            ng[l, e] = v
        elif which == "up_proj":
            nu[l, e] = v
    return nd, ng, nu


def main():
    cache = os.path.join(HERE, "p4_expertnorm.npz")
    if os.path.exists(cache):
        z = np.load(cache)
        nd, ng, nu = z["nd"], z["ng"], z["nu"]
        print("loaded cached norms")
    else:
        nd, ng, nu = expert_norms()
        np.savez_compressed(cache, nd=nd, ng=ng, nu=nu)
        print("computed and cached norms")

    print("down_proj norm: mean %.1f  sd %.1f  min %.1f  max %.1f"
          % (nd.mean(), nd.std(), nd.min(), nd.max()))

    d = np.load(os.path.join(HERE, "p4_feats.npz"), allow_pickle=True)
    p3 = np.load(os.path.join(HERE, "p3_topk_nll.npz"))
    d_j = p3["k6"] - p3["k8"]
    nll_j = p3["k8"]
    win = d["win"]
    ybin = (d_j > np.quantile(d_j, 0.75)).astype(int)
    n = d_j.size
    n_layers = 16

    # 層ごとに「落とす 2 本（rank 7, 8）の推定寄与」
    est = np.zeros((n_layers, n))
    est_rel = np.zeros((n_layers, n))
    for l in range(n_layers):
        z = d["gate_%d" % l].astype(np.float64)
        order = np.argsort(-z, axis=1)
        p = np.exp(z - z.max(1, keepdims=True))
        p /= p.sum(1, keepdims=True)
        ps = np.take_along_axis(p, order, axis=1)
        e7 = order[:, 6]
        e8 = order[:, 7]
        p7 = ps[:, 6]
        p8 = ps[:, 7]
        nd7 = nd[l, e7]
        nd8 = nd[l, e8]
        est[l] = p7 * nd7 + p8 * nd8
        mass8 = ps[:, :8].sum(1)
        est_rel[l] = est[l] / np.maximum(mass8 * nd[l].mean(), 1e-9)

    avg = est.mean(0)
    avg_rel = est_rel.mean(0)
    l15 = est[15]
    l0 = est[0]

    def rep(name, v):
        a = auc_score(ybin, v)
        r = spearman(v, d_j)
        if r < 0:
            a = 1 - a
            r = -r
        print("  %-26s AUC %.4f  Spearman %+.4f" % (name, a, r))
        return a, r

    print("\n=== 推定寄与 p·||W_down|| の予測力 ===")
    rep("層 0", l0)
    rep("層 15", l15)
    rep("全層平均", avg)
    rep("全層平均（相対）", avg_rel)

    # 既存特徴と結合して ridge
    print("\n=== 既存特徴と結合（ridge, 5 分割 CV）===")
    from p4b_probe import build_features
    feats, _ = build_features(d)
    for name, X in {
        "gate15+est": np.concatenate([feats["gate15"], est.T], 1),
        "gate15+est+hist": np.concatenate([feats["gate15"], est.T, feats["hist"]], 1),
        "ALL(l15)+est": np.concatenate([feats["gate15"], feats["h15"], feats["hist"], est.T], 1),
    }.items():
        pr = cv_predict(X.astype(np.float64), d_j, win)
        a = auc_score(ybin, pr)
        r = spearman(pr, d_j)
        print("  %-26s AUC %.4f  Spearman %+.4f  (dim %d)" % (name, a, r, X.shape[1]))

    np.savez_compressed(os.path.join(HERE, "p4_expertnorm_feats.npz"),
                        est=est, est_rel=est_rel, avg=avg, avg_rel=avg_rel,
                        d_j=d_j, nll_j=nll_j, win=win)
    print("\nsaved p4_expertnorm_feats.npz")


if __name__ == "__main__":
    main()
