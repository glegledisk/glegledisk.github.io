# -*- coding: utf-8 -*-
"""QE1S3 Step 1: 頻度操作が copy 位置のエントロピーを動かすことを生成的に診断する.

設計書: `QE1S3課題設計書_頻度操作がcopy位置の条件付きエントロピーを動かすことを生成的に分離する_20261115.md`
        §2〜§6 / §9

本次の範囲（走行前に固定。結果を見て変更しない）
  - 学習 0 epoch・GPU なし・numpy のみ。確認的検定は 1 本も走らせない。
  - `make_task(freq, init_type="uniform")` を zipf / uniform で生成し、
    `R_copy` / `P_rule` / `H_emp` / `P_re` / `N_syn` / C2 / C3 / C7 を測る。
  - `D1 = H_emp(uniform) - H_emp(zipf)`、`D2 = P_rule(zipf,copy)/P_rule(uniform,copy)`。
    閾値 `EPS_H = 1.0` / `EPS_RATIO = 10` は設計書 §4 で走行前に固定済み。
  - §5 の分岐ケース I / II / III / IV を出力する。Step 2 は別 ID。

出力: qe1s3_step1_metrics.json / qe1s3_step1_arrays.npz / qe1s3_step1.log
      （すべて UTF-8、json は allow_nan=False）
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "不均一MoE-Corpus"))

from corpus_common import (COPY_WINDOW, N_TYPES, SEQ_LEN, TRAIN_SEED_BASE,  # noqa: E402
                           V_IDENT, V_SYNTAX, VOCAB)
from qe1_make_task import (CALIB_SEED, EDIT_RULES, EPS_EDIT, EPS_EDIT_MI,  # noqa: E402
                           EPS_POS, N_CALIB_SEQ, POS_BINS, calibrate,
                           eta2_categorical, joint_table, make_task,
                           mi_over_entropy, pos_bins)

TAG = "qe1s3_step1"
FREQS = ("zipf", "uniform")
EPS_H = 1.0            # 設計書 §4 D1
EPS_RATIO = 10.0       # 設計書 §4 D2
H_UNIF = math.log(V_IDENT)
ARRAY_KEYS = ("tokens", "types", "next_tok", "copy_mask", "is_syntax",
              "ident_rank", "type_draw", "a", "changed", "base")


def entropy_of_copy_target(c: object) -> float:
    """copy 位置の next_tok の周辺経験分布エントロピー（学習不要の代理）。"""
    vals = np.asarray(c.next_tok, dtype=np.int64)[np.asarray(c.copy_mask, dtype=bool)]
    if vals.size == 0:
        return 0.0
    cnt = np.bincount(vals, minlength=VOCAB).astype(np.float64)
    p = cnt[cnt > 0] / float(vals.size)
    return float(-np.sum(p * np.log(p)))


def recurrence_rate(c: object) -> float:
    """copy 位置で next_tok が直近 COPY_WINDOW に実際に現れた割合（copy_mask 定義の直接測定）。"""
    cm = np.asarray(c.copy_mask, dtype=bool)
    tok = np.asarray(c.tokens, dtype=np.int64)
    nxt = np.asarray(c.next_tok, dtype=np.int64)
    rows, cols = np.nonzero(cm)
    if rows.size == 0:
        return 0.0
    found = np.zeros(rows.size, dtype=bool)
    target = nxt[rows, cols]
    for lag in range(1, COPY_WINDOW + 1):
        src = cols - lag
        ok = src >= 0
        found[ok] |= (tok[rows[ok], src[ok]] == target[ok])
    return float(found.mean())


def syntax_target_rate(c: object) -> float:
    cm = np.asarray(c.copy_mask, dtype=bool)
    nxt = np.asarray(c.next_tok, dtype=np.int64)
    vals = nxt[cm]
    return float((vals < V_SYNTAX).mean()) if vals.size else 0.0


def measure(freq: str) -> dict:
    c = make_task(CALIB_SEED, N_CALIB_SEQ, base=TRAIN_SEED_BASE,
                  freq=freq, init_type="uniform")
    cal = calibrate(c, f"typed_edit_v2_{freq}")
    pb = pos_bins(c.tokens.shape)
    out = {
        "freq": freq, "n_seq": int(c.tokens.shape[0]), "n_tokens": int(c.tokens.size),
        "R_copy": float(np.asarray(c.copy_mask, dtype=np.float64).mean()),
        "P_rule": {r: float(cal["by_edit_rule"][r]["p_copyable"]) for r in EDIT_RULES},
        "P_rule_frac": {r: float(cal["by_edit_rule"][r]["frac"]) for r in EDIT_RULES},
        "P_changed_by_rule": {r: float(cal["by_edit_rule"][r]["p_changed"])
                              for r in EDIT_RULES},
        "H_emp": entropy_of_copy_target(c),
        "H_unif": H_UNIF,
        "P_re": recurrence_rate(c),
        "N_syn": syntax_target_rate(c),
        "C2_eta2_type_pos": cal["C2_eta2_type_pos"],
        "C2_mi_type_pos_norm": cal["C2_mi_type_pos_norm"],
        "C3_eta2_edit_given_pos": cal["C3_eta2_edit_given_pos"],
        "C3_mi_edit_norm": cal["C3_mi_edit_norm"],
        "C3_p_changed": cal["C3_p_changed"],
        "C3_eta2_oracle_upper": cal["C3_eta2_oracle_upper"],
        "C7_eta2_a_pos": float(eta2_categorical(c.a, pb, POS_BINS, N_TYPES)),
        "C7_mi_a_pos_norm": float(mi_over_entropy(
            joint_table(pb, c.a, POS_BINS, N_TYPES))),
        "pos_corr_abs": float(c.pos_corr),
    }
    out["C2_pass"] = bool(out["C2_eta2_type_pos"] < EPS_POS
                          and out["C2_mi_type_pos_norm"] < EPS_POS)
    out["C3_pass"] = bool(out["C3_eta2_edit_given_pos"] > EPS_EDIT
                          and out["C3_mi_edit_norm"] > EPS_EDIT_MI)
    out["C7_pass"] = bool(out["C7_eta2_a_pos"] < EPS_POS
                          and out["C7_mi_a_pos_norm"] < EPS_POS)
    out["C4_pass"] = bool(abs(out["P_re"] - 1.0) < 1e-12
                          and abs(out["N_syn"]) < 1e-12
                          and np.isfinite([out["R_copy"], out["H_emp"]]).all())
    out["_corpus"] = c
    return out


def c1_reproducible(freq: str) -> dict:
    a = make_task(CALIB_SEED, N_CALIB_SEQ, base=TRAIN_SEED_BASE,
                  freq=freq, init_type="uniform")
    b = make_task(CALIB_SEED, N_CALIB_SEQ, base=TRAIN_SEED_BASE,
                  freq=freq, init_type="uniform")
    per = {}
    for k in ARRAY_KEYS:
        per[k] = int(np.max(np.abs(np.asarray(getattr(a, k), dtype=np.int64)
                                  - np.asarray(getattr(b, k), dtype=np.int64))))
    return {"per_array_maxdiff": per, "maxdiff": int(max(per.values())),
            "pass": bool(max(per.values()) == 0)}


def scan_nonfinite(o, path="root"):
    bad = []
    if isinstance(o, dict):
        for k, v in o.items():
            bad += scan_nonfinite(v, f"{path}.{k}")
    elif isinstance(o, list):
        for j, v in enumerate(o):
            bad += scan_nonfinite(v, f"{path}[{j}]")
    elif isinstance(o, float) and not np.isfinite(o):
        bad.append(path)
    return bad


def main() -> None:
    out = {
        "tag": TAG, "phase": "QE1S3 Step 1 (generative diagnosis, no training / no GPU)",
        "design": "QE1S3課題設計書_頻度操作がcopy位置の条件付きエントロピーを動かすことを生成的に分離する_20261115.md",
        "no_training": True, "no_gpu": True, "no_confirmatory_test": True,
    }
    out["prereg"] = {
        "FREQS": list(FREQS), "CALIB_SEED": CALIB_SEED,
        "N_CALIB_SEQ": N_CALIB_SEQ, "SEQ_LEN": SEQ_LEN,
        "V_IDENT": V_IDENT, "V_SYNTAX": V_SYNTAX, "VOCAB": VOCAB,
        "COPY_WINDOW": COPY_WINDOW, "N_TYPES": N_TYPES, "POS_BINS": POS_BINS,
        "INIT_TYPE": "uniform", "BASE": TRAIN_SEED_BASE,
        "EPS_POS": EPS_POS, "EPS_EDIT": EPS_EDIT, "EPS_EDIT_MI": EPS_EDIT_MI,
        "EPS_H": EPS_H, "EPS_RATIO": EPS_RATIO, "H_UNIF": H_UNIF,
        "D1": "H_emp(uniform) - H_emp(zipf) > EPS_H",
        "D2": "P_rule(zipf,copy) / P_rule(uniform,copy) > EPS_RATIO",
        "H_emp_note": "copy 位置 next_tok の周辺経験分布エントロピー。真の条件付きエントロピーでも性能下限でもない",
    }

    res = {f: measure(f) for f in FREQS}
    corpora = {f: res[f].pop("_corpus") for f in FREQS}
    out["measurement"] = res
    out["C1"] = {f: c1_reproducible(f) for f in FREQS}

    z, u = res["zipf"], res["uniform"]
    d1 = float(u["H_emp"] - z["H_emp"])
    d2 = float(z["P_rule"]["copy"] / max(u["P_rule"]["copy"], 1e-300))
    d1_ok, d2_ok = bool(d1 > EPS_H), bool(d2 > EPS_RATIO)
    extra = {
        "delta_H": d1, "ratio_copy": d2,
        "D1_pass": d1_ok, "D2_pass": d2_ok,
        "delta_R_copy": float(u["R_copy"] - z["R_copy"]),
        "ratio_C3_eta2": float(u["C3_eta2_edit_given_pos"]
                               / max(z["C3_eta2_edit_given_pos"], 1e-300)),
        "P_re_zipf": z["P_re"], "P_re_uniform": u["P_re"],
        "N_syn_zipf": z["N_syn"], "N_syn_uniform": u["N_syn"],
    }
    gates_ok = all(res[f][k] for f in FREQS
                   for k in ("C2_pass", "C3_pass", "C7_pass", "C4_pass"))
    checks = {
        "C1_reproducible": bool(all(out["C1"][f]["pass"] for f in FREQS)),
        "C2_position_independence": bool(all(res[f]["C2_pass"] for f in FREQS)),
        "C3_edit_contribution": bool(all(res[f]["C3_pass"] for f in FREQS)),
        "C4_copy_mask_definition": bool(all(res[f]["C4_pass"] for f in FREQS)),
        "C7_effective_rule": bool(all(res[f]["C7_pass"] for f in FREQS)),
    }
    if not gates_ok:
        case = "IV: C2/C3/C4/C7 のいずれかが不合格。課題設計が律速。分岐を止め Step 2 を起動しない"
    elif d1_ok and d2_ok:
        case = ("I: 頻度操作が copy 位置のエントロピーと再出現率を動かすと確定。"
                "T3 の estimand は頻度効果を測っていない。エントロピーを揃えた頻度対照を別 ID で構成")
    elif d1_ok or d2_ok:
        case = ("II: 片方のみ成立。エントロピーと再出現の寄与が分離しきれない。"
                "両方を同時に統制する対照を別 ID で設計")
    else:
        case = ("III: 両方不成立。生成的な説明は棄却。学習成否・eval 系列数の粒度など"
                "別要因を別 ID で設計")
    out["diagnosis"] = {**extra, "checks": checks,
                        "all_gates_pass": bool(gates_ok), "case": case}

    # ---- C6 と書き出し（Step 4 の独立検算用に配列を保存）
    nonfinite = scan_nonfinite(out)
    out["C6"] = {"nonfinite_paths": nonfinite, "pass": bool(len(nonfinite) == 0)}
    out["verdict"] = "PASS" if checks["C1_reproducible"] and out["C6"]["pass"] else "FAIL"

    arrays = {}
    for f in FREQS:
        c = corpora[f]
        for k in ("tokens", "next_tok", "copy_mask", "a", "type_draw", "changed"):
            arrays[f"{f}_{k}"] = np.asarray(getattr(c, k))
        arrays[f"{f}_pos_bin"] = pos_bins(c.tokens.shape).astype(np.int8)
        arrays[f"{f}_ident_rank"] = np.asarray(c.ident_rank, dtype=np.int16)
        arrays[f"{f}_base"] = np.asarray(c.base, dtype=np.int16)
    np.savez(HERE / f"{TAG}_arrays.npz", **arrays)
    (HERE / f"{TAG}_metrics.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")

    lines = [
        f"tag={TAG}", f"verdict={out['verdict']}",
        f"R_copy zipf={z['R_copy']:.8f} uniform={u['R_copy']:.8f}",
        f"H_emp zipf={z['H_emp']:.8f} uniform={u['H_emp']:.8f} H_unif={H_UNIF:.8f}",
        f"D1 delta_H={d1:.8f} (eps {EPS_H}) pass={d1_ok}",
        f"D2 ratio_copy={d2:.4f} (eps {EPS_RATIO}) pass={d2_ok}",
        f"P_rule(copy) zipf={z['P_rule']['copy']:.8f} uniform={u['P_rule']['copy']:.8f}",
        f"P_rule(inc)  zipf={z['P_rule']['inc']:.8f} uniform={u['P_rule']['inc']:.8f}",
        f"C3_eta2 zipf={z['C3_eta2_edit_given_pos']:.8f} "
        f"uniform={u['C3_eta2_edit_given_pos']:.8f}",
        f"P_re zipf={z['P_re']:.8f} uniform={u['P_re']:.8f} "
        f"N_syn zipf={z['N_syn']:.8f} uniform={u['N_syn']:.8f}",
        f"C1 maxdiff={[out['C1'][f]['maxdiff'] for f in FREQS]}",
        f"checks={checks}", f"case={case}", "",
    ]
    (HERE / f"{TAG}.log").write_text("\n".join(lines), encoding="utf-8")
    sys.stdout.write("\n".join(lines))
    sys.stdout.flush()


if __name__ == "__main__":
    main()
