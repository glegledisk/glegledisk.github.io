# -*- coding: utf-8 -*-
"""_a1_calib.py — A1 の再実装が既存ハーネス（q1 の forward_q1 / RewriteMoE）と一致するか。

`a1_activation_ffn.py` の relu アームは q1 の H+LB と**同じ計算**であるはず。
1 epoch 回して loss_hist が一致するかを見る（AGENTS.md Step 4 の「測定器の校正」）。
"""
import json
import os
import sys

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import q1_trace_routing as Q1          # noqa: E402
import a1_activation_ffn as A1         # noqa: E402

torch.set_num_threads(1)

SEED, EP, SEQS, BS, LR, AUXW = 0, 1, 3000, 32, 2e-3, 0.05

print("--- q1 の run_arm（既存）---", flush=True)
r_q1 = Q1.run_arm("H+LB", SEED, SEQS, EP, BS, LR, AUXW, task="compute")
print("q1 loss_hist:", r_q1["loss_hist"], flush=True)
print("q1 eval ce_all:", r_q1["eval"]["base"]["ce_all"], flush=True)

print("--- a1 の relu アーム（再実装）---", flush=True)
r_a1 = A1.run_one("relu", SEED, SEQS, EP, BS, LR, AUXW)
print("a1 loss_hist:", r_a1["loss_hist"], flush=True)
print("a1 eval ce_all:", r_a1["eval"]["ce_all"], flush=True)

dl = abs(r_q1["loss_hist"][-1] - r_a1["loss_hist"][-1])
dc = abs(r_q1["eval"]["base"]["ce_all"] - r_a1["eval"]["ce_all"])
print(f"\nΔloss = {dl:.3e}   ΔCE = {dc:.3e}")
print("一致" if (dl < 1e-6 and dc < 1e-6) else "不一致")
json.dump({"q1": r_q1["loss_hist"], "a1": r_a1["loss_hist"],
           "d_loss": dl, "d_ce": dc},
          open(os.path.join(HERE, "_a1_calib.json"), "w"), indent=2)
os._exit(0)
