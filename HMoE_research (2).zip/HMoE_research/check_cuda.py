"""check_cuda.py — CUDA セットアップの検証

使い方:
    C:\\Users\\gochu\\.workbuddy-ai\\binaries\\python\\envs\\gpu\\Scripts\\python.exe check_cuda.py

確認すること:
  1. torch が GPU を見つけているか / どの CUDA ランタイムでビルドされているか
  2. 実効 VRAM（WDDM ではデスクトップが既に食っている）
  3. 行列積の実測 TFLOPS（期待値との比較）
  4. 152K 語彙 softmax の速度（診断のボトルネック）
  5. 診断に使える batch / chunk の推奨値
"""

import os
import sys
import time


def hr(t):
    print("\n" + "=" * 60)
    print(t)
    print("=" * 60)


def main():
    try:
        import torch
    except Exception as e:
        print("[NG] import torch に失敗:", e)
        print("  -> pip install --index-url https://download.pytorch.org/whl/cu128 torch")
        return 1

    hr("1. 基本情報")
    print("python      :", sys.version.split()[0])
    print("torch       :", torch.__version__)
    print("torch cuda  :", torch.version.cuda)
    print("cudnn       :", torch.backends.cudnn.version())
    print("available   :", torch.cuda.is_available())
    if not torch.cuda.is_available():
        print("[NG] CUDA が見えない。ドライバか wheel の組み合わせを確認。")
        return 1

    i = torch.cuda.current_device()
    props = torch.cuda.get_device_properties(i)
    free, total = torch.cuda.mem_get_info()
    print("device      :", torch.cuda.get_device_name(i))
    print("capability  :", torch.cuda.get_device_capability(i))
    print("VRAM total  : %.2f GiB" % (total / 2**30))
    print("VRAM free   : %.2f GiB  (デスクトップが %.2f GiB 使用中)"
          % (free / 2**30, (total - free) / 2**30))
    print("SM count    :", props.multi_processor_count)
    print("bf16 対応   :", torch.cuda.is_bf16_supported())

    hr("2. 行列積ベンチマーク (fp16)")
    n = 8192
    a = torch.randn(n, n, device="cuda", dtype=torch.float16)
    b = torch.randn(n, n, device="cuda", dtype=torch.float16)
    for _ in range(3):
        c = a @ b
    torch.cuda.synchronize()
    reps = 20
    t0 = time.perf_counter()
    for _ in range(reps):
        c = a @ b
    torch.cuda.synchronize()
    dt = time.perf_counter() - t0
    tflops = 2 * n ** 3 * reps / dt / 1e12
    print("matmul 8192^3 x%d : %.2f s -> %.1f TFLOPS" % (reps, dt, tflops))
    print("(RTX 4060 の理論値は fp16 で約 121 TFLOPS。30〜70 出れば正常)")
    del a, b, c
    torch.cuda.empty_cache()

    hr("3. 語彙 softmax の速度（診断のボトルネック）")
    for V in (100352, 151936):
        for chunk in (1024, 2048):
            try:
                x = torch.randn(chunk, V, device="cuda", dtype=torch.float32)
                torch.cuda.synchronize()
                t0 = time.perf_counter()
                for _ in range(5):
                    y = torch.softmax(x, dim=-1)
                torch.cuda.synchronize()
                dt = (time.perf_counter() - t0) / 5
                gb = chunk * V * 4 / 2**30
                print("V=%6d chunk=%4d : %.2f ms  (logits %.2f GiB)" % (V, chunk, dt * 1e3, gb))
                del x, y
                torch.cuda.empty_cache()
            except RuntimeError as e:
                print("V=%6d chunk=%4d : OOM (%s)" % (V, chunk, str(e)[:60]))
                torch.cuda.empty_cache()

    hr("4. 推奨設定")
    free, total = torch.cuda.mem_get_info()
    free_gb = free / 2**30
    print("現在の空き VRAM: %.2f GiB" % free_gb)
    if free_gb >= 6.0:
        print("  -> 1B 級 fp16 教師 / batch 2 / seq 1024 / logits chunk 2048 で余裕あり")
    elif free_gb >= 4.0:
        print("  -> 1B 級 fp16 教師 / batch 1 / seq 1024 / logits chunk 1024")
    else:
        print("  -> 他プロセスを落とすか、seq 512 / chunk 512 に落とす")
    print("  -> 環境変数 PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True を推奨")
    print("\n[OK] セットアップは正常です。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
