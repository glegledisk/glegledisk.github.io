#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX9: 別 ckpt（OLMoE-1B-7B-0924-Instruct）をローカルへ取得する。

初回の snapshot_download は Xet 経路で 0 バイトのままハングしたため、
HF_HUB_DISABLE_XET=1 で通常 HTTPS に切り替え、hf_hub_download で
1 ファイルずつ順番に取得する（進捗が見え、再開も効く）。
Windows は symlink 非対応なので local_dir を指定して実ファイルとして保存する。
"""
import json
import os
import time

os.environ["HF_HUB_DISABLE_XET"] = "1"
os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
from huggingface_hub import hf_hub_download  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
REPO = "allenai/OLMoE-1B-7B-0924-Instruct"
DST = os.path.join(HERE, "models", "olmoe-1b-7b-instruct")

SMALL = ["config.json", "generation_config.json", "tokenizer.json",
         "tokenizer_config.json", "special_tokens_map.json",
         "model.safetensors.index.json"]
WEIGHTS = ["model-00001-of-00003.safetensors",
           "model-00002-of-00003.safetensors",
           "model-00003-of-00003.safetensors"]


def main():
    os.makedirs(DST, exist_ok=True)
    files = []
    for name in SMALL + WEIGHTS:
        t0 = time.time()
        p = hf_hub_download(repo_id=REPO, filename=name, local_dir=DST)
        sz = os.path.getsize(p)
        print("%-45s %8.2f GB  %6.0f s" % (name, sz / 1e9, time.time() - t0),
              flush=True)
        files.append({"name": name, "bytes": sz})
    cfg = json.load(open(os.path.join(DST, "config.json"), encoding="utf-8"))
    out = {"repo": REPO, "local_dir": DST, "method": "hf_hub_download_https_no_xet",
           "config": {k: cfg.get(k) for k in
                      ("model_type", "num_hidden_layers", "num_experts",
                       "num_experts_per_tok", "hidden_size", "vocab_size",
                       "architectures")},
           "files": files, "total_bytes": sum(f["bytes"] for f in files)}
    with open(os.path.join(HERE, "_ax9_download.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    print("done: %.2f GB in %d files" % (out["total_bytes"] / 1e9, len(files)))
    print("config %s" % out["config"])


if __name__ == "__main__":
    main()
