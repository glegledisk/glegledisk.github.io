#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""W2: 同 params の均一幅より HMoE が一貫して勝つか（≥ 7 seed, MDE 付き）。

事前登録: `W2課題設計書_同params均一幅対照_20261106.md`。腕・seed 数・指標・
補正・校正条件・判定規則は実行前に固定。本ファイルはその実装である。

q12b と完全同一の訓練条件で H / U / R の 3 腕を 8 seed 走らせ、
instr_valid の対応差を paired t + Holm(m=3) + MDE + 符号一貫性で判定する。
評価器は W1 の evaluate_full を再利用（Q8.evaluate_q8 と 30/30 ビット一致済み）。

出力: w2_results.json / w2_delta.npz / w2_analysis.json / w2_out_utf8.txt
"""
import argparse
import json
import math
import os
import sys

import numpy as np
import torch
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import q8_static_dispatch as Q8            # noqa: E402 （内部で Q2 → E2.SEQ=128）
import q2_difficulty_ladder as Q2          # noqa: E402
import e2b_rewrite_routing_fixed as E2     # noqa: E402
from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS  # noqa: E402
from w1_local_edit_absorption import evaluate_full  # noqa: E402

assert E2.SEQ == 128

OUTDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "w2")
Q12BDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q12b")

WIDTH_VECTORS = {
    "H": tuple(WIDTHS["H+LB"]),
    "U": tuple(WIDTHS["U+LB"]),
    "R": tuple(int(WIDTHS["H+LB"][i])
               for i in np.random.default_rng(20261106).permutation(8)),
}
ARMS = ("H", "U", "R")
PAIRS = (("H", "U"), ("H", "R"), ("U", "R"))
SEEDS = tuple(range(8))
CALIB_SEEDS = tuple(range(6))

SEQS, EPOCHS, BS, LR, AUXW = 3000, 6, 32, 2e-3, 0.05
N_EVAL, EVAL_SEED, THREADS = 1024, 777, 1  # 設計書 追記 2: 決定性を優先

for a, w in WIDTH_VECTORS.items():
    assert sum(w) == 1024, (a, w)
assert WIDTH_VECTORS["R"] != WIDTH_VECTORS["H"]


# ---------------------------------------------------------------------------
def run_one(arm, seed, seq, typ, epochs=None, save=True):
    """Q8.run と同一の訓練。widths だけ差し替える。"""
    epochs = EPOCHS if epochs is None else epochs
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    widths = WIDTH_VECTORS[arm]
    model = RewriteMoE(widths, seed=seed)
    assert list(model.dims) == list(widths)
    opt = Adam(model.params(), lr=LR)
    nparam = int(sum(v.numel() for v in model.params().values()))
    steps = max(1, SEQS // BS)
    hist = []
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps):
            xs, ty = Q2.make_trace_batch(rng, BS, task="hard")
            logits, aux, _ = Q8.forward_dispatch(
                model, torch.from_numpy(xs), typ=torch.from_numpy(ty),
                mode="dynamic_lb")
            loss = Q2.trace_loss(logits, xs) + AUXW * aux
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        hist.append(float(run / steps))
    metrics, extras = evaluate_full(model, seq, typ)
    if save:
        torch.save({k: v.detach() for k, v in model.params().items()},
                   os.path.join(OUTDIR, f"ckpt_{arm}_s{seed}.pt"))
    return {"arm": arm, "seed": seed, "widths": list(widths),
            "nparam": nparam, "loss_hist": hist, "n_eval": N_EVAL,
            "eval": metrics}, extras


def load_ckpt(arm, seed):
    path = os.path.join(Q12BDIR, f"ckpt_H+LB_hard_dynamic_lb_s{seed}.pt")
    td = torch.load(path, map_location="cpu")
    model = RewriteMoE(WIDTH_VECTORS["H"], seed=seed)
    assert set(td.keys()) == set(model.p.keys())
    for k in td:
        assert tuple(td[k].shape) == tuple(model.p[k].shape)
    model.p = {k: v.detach().clone() for k, v in td.items()}
    for k in model.p:
        model.p[k].requires_grad_(False)
    return model


def calibration_instrument(seq, typ):
    """C1: 保存済み q12b ckpt を evaluate_full で再評価し json とビット一致。"""
    items = []
    for seed in CALIB_SEEDS:
        model = load_ckpt("H", seed)
        m, _ = evaluate_full(model, seq, typ)
        with open(os.path.join(Q12BDIR,
                               f"H+LB_hard_dynamic_lb_s{seed}.json"),
                  encoding="utf-8") as f:
            ref = json.load(f)["eval"]["base"]
        for fld in ("ce_all", "instr_valid", "acc_payload", "ce_payload",
                    "usage_l0"):
            got, want = m[fld], ref[fld]
            if isinstance(want, list):
                d = float(np.max(np.abs(np.array(got, dtype=float) -
                                        np.array(want, dtype=float))))
            else:
                d = abs(float(got) - float(want))
            items.append({"seed": seed, "field": fld, "got": got,
                          "want": want, "abs_diff": d,
                          "bit_match": bool(d < 1e-12)})
    return items


def calibration_training_loop(seq, typ):
    """C2: 1 スレッド・1 epoch で Q8.run と run_one がビット一致するか。"""
    torch.set_num_threads(1)
    diag_dir = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "w2_diag")
    os.makedirs(diag_dir, exist_ok=True)
    old = Q8.OUTDIR
    Q8.OUTDIR = diag_dir
    r_q8 = Q8.run("hard", "dynamic_lb", 0, SEQS, 1, BS, LR)
    r_w2, _ = run_one("H", 0, seq, typ, epochs=1, save=False)
    Q8.OUTDIR = old
    torch.set_num_threads(THREADS)
    a = np.array(r_q8["loss_hist"])
    b = np.array(r_w2["loss_hist"])
    d_loss = float(np.max(np.abs(a - b)))
    d_eval = float(max(abs(r_q8["eval"]["base"][k] - r_w2["eval"][k])
                       for k in ("ce_all", "instr_valid", "acc_payload",
                                 "ce_payload", "width_struct")))
    return {"q8_loss": r_q8["loss_hist"], "w2_loss": r_w2["loss_hist"],
            "loss_max_abs_diff": d_loss, "eval_max_abs_diff": d_eval,
            "bit_match": bool(d_loss < 1e-12 and d_eval < 1e-12)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=list(SEEDS))
    ap.add_argument("--arms", nargs="+", default=list(ARMS))
    ap.add_argument("--tag", default="w2")
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    torch.set_num_threads(THREADS)
    os.makedirs(OUTDIR, exist_ok=True)

    tag = args.tag
    LOG = os.path.join(HERE, f"{tag}_out_utf8.txt")
    if os.path.exists(LOG):
        os.remove(LOG)

    def log(msg):
        print(msg, flush=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")

    log(f"W2: arms={args.arms} seeds={args.seeds} threads={THREADS} "
        f"seqs={SEQS} epochs={EPOCHS} bs={BS} lr={LR} auxw={AUXW} smoke={args.smoke}")
    for a in args.arms:
        assert a in WIDTH_VECTORS, f"未登録の腕: {a}"
        log(f"  {a}: widths={WIDTH_VECTORS[a]} sum={sum(WIDTH_VECTORS[a])}")

    ev_rng = np.random.default_rng(EVAL_SEED)
    seq, typ = Q2.make_trace_batch(ev_rng, N_EVAL, task="hard")

    # --- 校正 C1 / C2（設計書 追記 2026-11-06 00:55）---
    calib = calibration_instrument(seq, typ)
    log(f"  C1 測定器の校正: {sum(c['bit_match'] for c in calib)}/{len(calib)}")
    c2 = calibration_training_loop(seq, typ)
    log(f"  C2 訓練ループの同一性(1thread,1epoch): "
        f"loss_diff={c2['loss_max_abs_diff']:.3e} "
        f"eval_diff={c2['eval_max_abs_diff']:.3e} bit_match={c2['bit_match']}")

    rows = []
    ia = {a: i for i, a in enumerate(args.arms)}
    sa = {s: j for j, s in enumerate(args.seeds)}
    na, ns = len(args.arms), len(args.seeds)
    iv = np.full((na, ns), np.nan)
    ce_all = np.full((na, ns), np.nan)
    ce_pay = np.full((na, ns), np.nan)
    acc_pay = np.full((na, ns), np.nan)
    width = np.full((na, ns), np.nan)
    instr_seq = np.zeros((na, ns, N_EVAL), dtype=np.int8)
    ce_seq = np.zeros((na, ns, N_EVAL), dtype=np.float64)
    nparam = np.zeros(na, dtype=np.int64)

    for seed in args.seeds:
        for arm in args.arms:
            r, x = run_one(arm, seed, seq, typ)
            m = r["eval"]
            i, j = ia[arm], sa[seed]
            iv[i, j] = m["instr_valid"]
            ce_all[i, j] = m["ce_all"]
            ce_pay[i, j] = m["ce_payload"]
            acc_pay[i, j] = m["acc_payload"]
            width[i, j] = (m["width_struct"] + m["width_payload"]) / 2.0
            instr_seq[i, j] = x["instr_seq"]
            ce_seq[i, j] = x["ce_seq"]
            nparam[i] = r["nparam"]
            rows.append({**r, "iv": m["instr_valid"],
                         "ce_all": m["ce_all"]})
            log(f"  {arm} s{seed}: iv={m['instr_valid']:.4f} "
                f"ce_all={m['ce_all']:.6f} ce_pl={m['ce_payload']:.6f} "
                f"w_st/pl={m['width_struct']:.1f}/{m['width_payload']:.1f} "
                f"nparam={r['nparam']} loss[-1]={r['loss_hist'][-1]:.4f}")

    # --- 前提の assert ---
    assert len(set(nparam.tolist())) == 1, f"nparam が腕で違う: {nparam.tolist()}"
    if "U" in ia:
        ust = [r["eval"]["width_struct"] for r in rows if r["arm"] == "U"]
        assert all(abs(v - 128.0) < 1e-6 for v in ust), \
            f"U の width_struct が 128 でない（幅ベクトルのフォールバック疑い）: {ust}"
    log(f"  assert: nparam={nparam.tolist()} (全腕一致), "
        f"U.width_struct=128.0 OK")

    # --- 保存 ---
    with open(os.path.join(HERE, f"{tag}_results.json"), "w", encoding="utf-8") as f:
        json.dump({"rows": rows, "args": vars(args),
                   "arms": list(args.arms), "seeds": list(args.seeds),
                   "width_vectors": {a: list(v) for a, v in WIDTH_VECTORS.items()}},
                  f, ensure_ascii=False, indent=2, default=float)
    np.savez_compressed(
        os.path.join(HERE, f"{tag}_delta.npz"),
        arms=np.array(args.arms, dtype=object), seeds=np.array(args.seeds),
        iv=iv, ce_all=ce_all, ce_payload=ce_pay, acc_payload=acc_pay,
        width=width, instr_seq=instr_seq, ce_seq=ce_seq,
        nparam=nparam, pairs=np.array([f"{a}-{b}" for a, b in PAIRS]))

    # --- 集計 ---
    def compare(a, b):
        if a not in ia or b not in ia:
            return None
        d = iv[ia[a]] - iv[ia[b]]
        se = float(d.std(ddof=1) / math.sqrt(len(d))) if len(d) >= 2 else float("nan")
        if not np.isfinite(se) or se == 0:
            t, p, mde = 0.0, 1.0, 0.0
        else:
            t = float(d.mean() / se)
            p = float(2 * stats.t.sf(abs(t), df=len(d) - 1))
            mde = float(stats.t.ppf(0.975, len(d) - 1) * se)
        x, y = instr_seq[ia[a]].reshape(-1), instr_seq[ia[b]].reshape(-1)
        n01 = int(((x == 1) & (y == 0)).sum())
        n10 = int(((x == 0) & (y == 1)).sum())
        mc_p = float(stats.binomtest(min(n10, n01), n01 + n10, 0.5).pvalue) \
            if n01 + n10 > 0 else 1.0
        dseq = (ce_seq[ia[a]] - ce_seq[ia[b]]).reshape(-1)
        absd = np.abs(dseq)
        ntop = max(1, int(math.ceil(len(absd) * 0.01)))
        top1 = float(np.sort(absd)[-ntop:].sum() / max(1e-12, absd.sum()))
        dce = float((ce_all[ia[a]] - ce_all[ia[b]]).mean())
        return {"pair": f"{a}-{b}", "delta": float(d.mean()), "se": se,
                "t": t, "p": p, "mde": mde, "n": int(len(d)),
                "per_seed": d.tolist(), "n_pos": int((d > 0).sum()),
                "n_neg": int((d < 0).sum()),
                "iv_a": float(iv[ia[a]].mean()), "iv_b": float(iv[ia[b]].mean()),
                "d_ce_all": dce,
                "d_ce_payload": float((ce_pay[ia[a]] - ce_pay[ia[b]]).mean()),
                "d_acc_payload": float((acc_pay[ia[a]] - acc_pay[ia[b]]).mean()),
                "width_a": float(width[ia[a]].mean()),
                "width_b": float(width[ia[b]].mean()),
                "mcnemar": {"a_better": n01, "b_better": n10, "p": mc_p},
                "ce_seq_delta": float(dseq.mean()),
                "ce_seq_median": float(np.median(dseq)),
                "ce_seq_max": float(absd.max()),
                "ce_seq_top1_share": top1}

    comps = {f"{a}-{b}": compare(a, b) for a, b in PAIRS
             if a in ia and b in ia}
    order = sorted(comps, key=lambda k: comps[k]["p"])
    run = 0.0
    holm = {}
    for r, k in enumerate(order):
        run = max(run, min(1.0, (len(comps) - r) * comps[k]["p"]))
        holm[k] = {"p_raw": comps[k]["p"], "p_holm": float(run),
                   "rank": r + 1, "m": len(comps)}
    for k in comps:
        comps[k]["p_holm"] = holm[k]["p_holm"]

    main_c = comps.get("H-U")
    supported = bool(
        main_c and main_c["delta"] > 0 and
        abs(main_c["delta"]) > main_c["mde"] and
        main_c["p_holm"] < 0.05 and main_c["n_pos"] >= 7)
    calib_ok = all(c["bit_match"] for c in calib) and c2["bit_match"]

    analysis = {
        "calibration": {"C1_instrument": {
                            "items": calib, "n": len(calib),
                            "all_bit_match": bool(all(c["bit_match"] for c in calib))},
                        "C2_training_loop": c2,
                        "C3_no_cross_run_absolute_comparison": True,
                        "all_bit_match": bool(calib_ok)},
        "asserts": {"nparam_equal": True,
                    "nparam": int(nparam[0]),
                    "U_width_struct": [r["eval"]["width_struct"] for r in rows
                                       if r["arm"] == "U"]},
        "comparisons": comps, "holm": holm,
        "verdict": {"prediction_supported": supported,
                    "criteria": {
                        "delta_positive": bool(main_c and main_c["delta"] > 0),
                        "delta_over_mde": bool(main_c and abs(main_c["delta"]) > main_c["mde"]),
                        "holm_p_lt_005": bool(main_c and main_c["p_holm"] < 0.05),
                        "sign_ge_7_of_8": bool(main_c and main_c["n_pos"] >= 7)},
                    "calibration_ok": bool(calib_ok)},
        "meta": {"threads": THREADS, "n_eval": N_EVAL, "eval_seed": EVAL_SEED,
                 "seqs": SEQS, "epochs": EPOCHS, "bs": BS, "lr": LR,
                 "auxw": AUXW, "seeds": list(args.seeds),
                 "arms": list(args.arms), "n_rows": len(rows),
                 "smoke": args.smoke},
    }
    with open(os.path.join(HERE, f"{tag}_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2, default=float)

    log("")
    log(f"== 校正: C1 {sum(c['bit_match'] for c in calib)}/{len(calib)} "
        f"bit-match / C2 bit_match={c2['bit_match']}  all={calib_ok}")
    for c in calib:
        if not c["bit_match"]:
            log(f"  MISMATCH s{c['seed']} {c['field']}: "
                f"diff={c['abs_diff']}")
    log("")
    log("== instr_valid 対応差（Holm m=3）==")
    for k, c in comps.items():
        log(f"  {k}: Δ={c['delta']:+.4f} se={c['se']:.4f} t={c['t']:+.2f} "
            f"p={c['p']:.4f} Holm={c['p_holm']:.4f} MDE={c['mde']:.4f} "
            f"符号 {c['n_pos']}正/{c['n_neg']}負 n={c['n']} "
            f"McNemar={c['mcnemar']['a_better']}/{c['mcnemar']['b_better']} "
            f"width={c['width_a']:.1f}/{c['width_b']:.1f}")
    log("")
    log(f"  prediction_supported={supported}  "
        f"criteria={analysis['verdict']['criteria']}")
    log(f"saved: {tag}_results.json / {tag}_delta.npz / {tag}_analysis.json")
    os._exit(0)


if __name__ == "__main__":
    main()
