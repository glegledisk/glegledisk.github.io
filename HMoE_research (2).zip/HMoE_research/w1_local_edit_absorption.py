#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""W1: 0.016% 級の 1 expert 重み編集は系列単位の指標を動かすか。

事前登録: `W1課題設計書_局所編集の吸収検定_20261105.md`（判定規則・腕・閾値は
実行前に固定。本ファイルはその実装であって設計を変更しない）。

q12b の dynamic_lb ckpt（6 seed）を凍結したまま、`l0.e{e}.w2` に射影除去を
入れ、Q8 と同一の評価器で系列単位の instr_valid を paired に比べる。
同時に層別の再選択率を測り、「吸収」と「編集が小さすぎる」を分離する。

出力: w1_results.json / w1_delta.npz / w1_analysis.json / w1_out_utf8.txt
"""
import argparse
import json
import math
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# q2_difficulty_ladder を先に import しないと E2.SEQ=128 が効かず pos.w の形が壊れる。
import q8_static_dispatch as Q8            # noqa: E402  （内部で Q2 → E2.SEQ を設定）
import q2_difficulty_ladder as Q2          # noqa: E402
import e2b_rewrite_routing_fixed as E2     # noqa: E402
from e2b_rewrite_routing_fixed import RewriteMoE, WIDTHS  # noqa: E402

assert E2.SEQ == 128, "Q2 の import が E2.SEQ を設定していない"

CKPTDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q12b")

ARMS = (
    "none", "rand_0016", "dir_0016", "dir_0016_a6", "dir_0077", "dir_all",
    "zero_one", "zero_expert", "dir_0016_e6", "zero_expert_e6", "oracle",
)
PRIMARY = (
    "rand_0016", "dir_0016", "dir_0016_a6", "dir_0077", "dir_all",
    "zero_one", "zero_expert",
)
EXPLORATORY = ("dir_0016_e6", "zero_expert_e6", "oracle")
N_EDIT = {
    "rand_0016": 215, "dir_0016": 215, "dir_0016_a6": 215,
    "dir_0077": 1028, "dir_0016_e6": 215,
}
ALPHA = {
    "rand_0016": 1.0, "dir_0016": 1.0, "dir_0016_a6": 6.0,
    "dir_0077": 6.0, "dir_all": 6.0, "dir_0016_e6": 6.0,
}
SEEDS = (0, 1, 2, 3, 4, 5)
N_EVAL = 1024
EVAL_SEED = 777
SPAN = Q2.T_LEN - Q2.TRACE0


# ---------------------------------------------------------------------------
# 評価器: Q8.evaluate_q8 と同一の forward・同一のスライス + 系列単位の配列
# ---------------------------------------------------------------------------
@torch.no_grad()
def evaluate_full(model, seq, typ, bs=128):
    n, L, E = seq.shape[0], model.L, model.E
    dims = np.array(model.dims, dtype=np.float32)
    ce = np.zeros((n, SPAN), dtype=np.float32)
    hit = np.zeros((n, SPAN), dtype=bool)
    wid = np.zeros((n, SPAN), dtype=np.float32)
    top1_l = np.zeros((L, n, SPAN), dtype=np.int64)
    topi_store = [np.zeros((n, Q2.T_LEN, 2), dtype=np.int8) for _ in range(L)]

    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = torch.from_numpy(seq[s])
        t_batch = torch.from_numpy(typ[s])
        logits, _, idx_l = Q8.forward_dispatch(model, x, typ=t_batch,
                                               mode="dynamic_lb")
        lg = logits[:, Q2.TRACE0 - 1:-1, :len(Q2.VOCAB)]
        tgt = torch.from_numpy(seq[s, Q2.TRACE0:])
        lp = F.cross_entropy(lg.reshape(-1, len(Q2.VOCAB)), tgt.reshape(-1),
                             reduction="none").reshape(-1, SPAN)
        ce[s] = lp.numpy()
        hit[s] = (lg.argmax(-1).numpy() == tgt.numpy())
        for l, ti in enumerate(idx_l):
            a = ti.numpy()
            topi_store[l][s] = a.astype(np.int8)
            aa = a[:, Q2.TRACE0 - 1:-1, :]
            top1_l[l][s] = aa[:, :, 0]
            wid[s] += dims[aa].mean(-1) / L

    ty = typ[:, Q2.TRACE0:]
    m_st, m_pl = (ty == Q2.TYP_STRUCT), (ty == Q2.TYP_PAYLOAD)
    u_l0 = np.bincount(top1_l[0].reshape(-1), minlength=E)
    ent = Q8.usage_entropy(u_l0)
    hp = hit.reshape(n, Q2.P_STEPS, Q2.TPI)[:, :, 2:]
    instr_ok = hp.all(-1)

    metrics = {
        "ce_all": float(ce.mean()),
        "ce_struct": float(ce[m_st].mean()),
        "ce_payload": float(ce[m_pl].mean()),
        "acc_struct": float(hit[m_st].mean()),
        "acc_payload": float(hit[m_pl].mean()),
        "width_struct": float(wid[m_st].mean()),
        "width_payload": float(wid[m_pl].mean()),
        "small_struct": float(np.isin(top1_l[-1][m_st], Q2.SMALL).mean()),
        "small_payload": float(np.isin(top1_l[-1][m_pl], Q2.SMALL).mean()),
        "usage_l0": u_l0.tolist(),
        "usage_entropy": ent,
        "usage_share_max": float(u_l0.max() / max(1.0, u_l0.sum())),
        "dead_experts": int(np.sum((u_l0 / max(1.0, u_l0.sum())) < 0.01)),
        "instr_valid": float(instr_ok.all(-1).mean()),
        "instr_acc": float(instr_ok.mean()),
        "payload_token_acc": float(hp.mean()),
        "n_eval": int(n),
    }
    extras = {
        "instr_seq": instr_ok.all(-1).astype(np.int8),
        "ce_seq": ce.mean(1).astype(np.float64),
        "topi": topi_store,
        "usage_by_layer": [np.bincount(top1_l[l].reshape(-1), minlength=E)
                           for l in range(L)],
    }
    return metrics, extras


def selection_change(base_topi, cur_topi):
    """層別 top-1 選択の変化率（予測スライスのみ）。凍結推論の吸収経路を測る。"""
    out = []
    for b, c in zip(base_topi, cur_topi):
        bb = b[:, Q2.TRACE0 - 1:-1, 0]
        cc = c[:, Q2.TRACE0 - 1:-1, 0]
        out.append(float((bb != cc).mean()))
    return np.asarray(out, dtype=np.float64)


# ---------------------------------------------------------------------------
# 編集: 上位左特異ベクトルの射影除去。 eval データは一切使わない
# ---------------------------------------------------------------------------
def load_ckpt(seed):
    path = os.path.join(CKPTDIR, f"ckpt_H+LB_hard_dynamic_lb_s{seed}.pt")
    td = torch.load(path, map_location="cpu")
    model = RewriteMoE(WIDTHS["H+LB"], seed=seed)
    assert set(td.keys()) == set(model.p.keys()), "ckpt のキーがモデルと違う"
    for k in td:
        assert tuple(td[k].shape) == tuple(model.p[k].shape), \
            f"{k} の形が違う: {tuple(td[k].shape)} vs {tuple(model.p[k].shape)}"
    return model, {k: v.detach().clone() for k, v in td.items()}


def fresh_model(model, clean):
    model.p = {k: v.clone() for k, v in clean.items()}
    for k in model.p:
        model.p[k].requires_grad_(False)
    return model


def apply_edit(model, arm, seed):
    """未知の腕は黙って既定に落とさず例外にする（Q 系 / PC 系の罠）。"""
    if arm not in ARMS:
        raise ValueError(f"未登録の腕: {arm}")
    if arm == "none":
        return {"n_edited": 0, "alpha": 0.0, "target": None,
                "delta_l2": 0.0, "keys": []}

    p = model.p
    e = 6 if arm.endswith("_e6") else 0
    key0 = f"l0.e{e}.w2"
    W = p[key0]
    delta_l2 = 0.0
    n_edit = 0
    keys = []

    if arm in N_EDIT or arm == "dir_all":
        # 方向は重みの上位左特異ベクトル。eval データは一切使わない。
        u = torch.linalg.svd(W, full_matrices=False)[0][:, 0]
        proj = u @ W                                     # (w,)
        D = -ALPHA[arm] * u[:, None] * proj[None, :]     # (128, w)
        delta_l2 = float(torch.linalg.vector_norm(D.reshape(-1)))
        if arm == "dir_all":
            p[key0] = W + D
            n_edit = int(W.numel())
            keys = [key0]
        else:
            n = N_EDIT[arm]
            flat_d = D.reshape(-1)
            idx = torch.topk(flat_d.abs(), n).indices
            vals = flat_d[idx]
            if arm == "rand_0016":
                rng = np.random.default_rng(9000 + seed)
                pos = rng.choice(W.numel(), size=n, replace=False)
                idx = torch.from_numpy(pos.astype(np.int64))
                perm = torch.randperm(
                    n, generator=torch.Generator().manual_seed(3000 + seed))
                vals = vals[perm]
            Wn = W.clone()
            fl = Wn.reshape(-1)
            fl[idx] = fl[idx] + vals
            p[key0] = Wn
            n_edit = int(n)
            keys = [key0]
    elif arm in ("zero_one", "zero_expert", "zero_expert_e6", "oracle"):
        if arm == "zero_one":
            targets = [key0]
        elif arm == "oracle":
            targets = [f"l{l}.e{i}.w2" for l in range(model.L)
                       for i in range(model.E)]
        else:
            targets = [f"l{l}.e{e}.w2" for l in range(model.L)]
        for k in targets:
            p[k] = torch.zeros_like(p[k])
            n_edit += int(p[k].numel())
        keys = targets
    else:
        raise ValueError(f"編集規則が未定義: {arm}")

    return {"n_edited": n_edit, "alpha": float(ALPHA.get(arm, 0.0)),
            "target": e, "keys": keys, "delta_l2": delta_l2}


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=list(SEEDS))
    ap.add_argument("--arms", nargs="+", default=list(ARMS))
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--n_eval", type=int, default=N_EVAL)
    ap.add_argument("--tag", default="w1")
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()
    torch.set_num_threads(args.threads)
    torch.manual_seed(12345)

    tag = args.tag
    LOG = os.path.join(HERE, f"{tag}_out_utf8.txt")
    if os.path.exists(LOG):
        os.remove(LOG)

    def log(msg):
        print(msg, flush=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")

    log(f"W1: threads={args.threads} seeds={args.seeds} arms={len(args.arms)} "
        f"n_eval={args.n_eval} smoke={args.smoke} tag={tag}")
    assert E2.SEQ == 128

    ev_rng = np.random.default_rng(EVAL_SEED)
    seq, typ = Q2.make_trace_batch(ev_rng, args.n_eval, task="hard")
    log(f"eval batch: seq={seq.shape} typ={typ.shape} SPAN={SPAN}")

    rows = []
    calib = []
    # npz 用の配列（腕 × seed）
    ia = {a: i for i, a in enumerate(args.arms)}
    sa = {s: i for i, s in enumerate(args.seeds)}
    na, ns, L = len(args.arms), len(args.seeds), 4
    iv = np.full((na, ns), np.nan)
    ce_all = np.full((na, ns), np.nan)
    ce_pay = np.full((na, ns), np.nan)
    acc_pay = np.full((na, ns), np.nan)
    instr_seq = np.zeros((na, ns, args.n_eval), dtype=np.int8)
    ce_seq = np.zeros((na, ns, args.n_eval), dtype=np.float64)
    selchg = np.zeros((na, ns, L), dtype=np.float64)
    share_edited = np.zeros((na, ns, L), dtype=np.float64)
    perturb = np.zeros((na, ns), dtype=np.float64)   # 実際の重み差分の L2
    relpert = np.zeros((na, ns), dtype=np.float64)   # 全 params の L2 に対する比
    n_edited = np.zeros(na, dtype=np.int64)

    for seed in args.seeds:
        model, clean = load_ckpt(seed)
        params_norm = math.sqrt(sum(float((v ** 2).sum()) for v in clean.values()))
        ref_path = os.path.join(CKPTDIR, f"H+LB_hard_dynamic_lb_s{seed}.json")
        with open(ref_path, encoding="utf-8") as f:
            ref = json.load(f)["eval"]["base"]

        # 校正腕を最初に評価し、topi を保持（層別再選択の基準）
        fresh_model(model, clean)
        m0, x0 = evaluate_full(model, seq, typ)
        cal_fields = ("ce_all", "instr_valid", "acc_payload", "ce_payload")
        for fld in cal_fields:
            calib.append({"seed": seed, "field": fld,
                          "ref": float(ref[fld]), "got": float(m0[fld]),
                          "abs_diff": abs(float(ref[fld]) - float(m0[fld])),
                          "bit_match": bool(abs(float(ref[fld]) - float(m0[fld])) < 1e-12)})
        calib.append({"seed": seed, "field": "usage_l0",
                      "ref": ref["usage_l0"], "got": m0["usage_l0"],
                      "abs_diff": float(np.abs(np.array(ref["usage_l0"]) -
                                               np.array(m0["usage_l0"])).max()),
                      "bit_match": bool(list(ref["usage_l0"]) == list(m0["usage_l0"]))})
        log(f"  s{seed} 校正 ce_all={m0['ce_all']:.9f} iv={m0['instr_valid']:.6f} "
            f"ref ce_all={ref['ce_all']:.9f} iv={ref['instr_valid']:.6f}")

        for arm in args.arms:
            fresh_model(model, clean)
            info = apply_edit(model, arm, seed)
            if arm != "none" and arm in N_EDIT:
                assert info["n_edited"] == N_EDIT[arm], (arm, info["n_edited"])
            sq = sum(float(((model.p[k] - clean[k]) ** 2).sum()) for k in clean)
            diff_l2 = math.sqrt(sq)
            m, x = evaluate_full(model, seq, typ)
            i, j = ia[arm], sa[seed]
            iv[i, j] = m["instr_valid"]
            ce_all[i, j] = m["ce_all"]
            ce_pay[i, j] = m["ce_payload"]
            acc_pay[i, j] = m["acc_payload"]
            instr_seq[i, j] = x["instr_seq"]
            ce_seq[i, j] = x["ce_seq"]
            n_edited[i] = info["n_edited"]
            perturb[i, j] = diff_l2
            relpert[i, j] = diff_l2 / max(1e-12, params_norm)
            if arm == "none":
                selchg[i, j] = 0.0
            else:
                selchg[i, j] = selection_change(x0["topi"], x["topi"])
            e = info["target"] if info["target"] is not None else 0
            for l in range(L):
                u = x["usage_by_layer"][l]
                share_edited[i, j, l] = float(u[e] / max(1, u.sum()))
            rows.append({"arm": arm, "seed": seed, **m,
                         "n_edited": info["n_edited"],
                         "alpha": info["alpha"], "target": info["target"],
                         "diff_l2": diff_l2, "rel_perturb": relpert[i, j],
                         "sel_change": selchg[i, j].tolist(),
                         "share_edited": share_edited[i, j].tolist()})
            log(f"    {arm:<17s} s{seed}  iv={m['instr_valid']:.4f} "
                f"ce_all={m['ce_all']:.6f} ce_pl={m['ce_payload']:.6f} "
                f"n_edit={info['n_edited']:>6d} "
                f"selchg={np.round(selchg[i, j], 4).tolist()}")

    # ---------------- 保存 ----------------
    with open(os.path.join(HERE, f"{tag}_results.json"), "w", encoding="utf-8") as f:
        json.dump({"rows": rows, "args": vars(args),
                   "arms": list(args.arms), "seeds": list(args.seeds)},
                  f, ensure_ascii=False, indent=2, default=float)
    np.savez_compressed(
        os.path.join(HERE, f"{tag}_delta.npz"),
        arms=np.array(args.arms, dtype=object), seeds=np.array(args.seeds),
        iv=iv, ce_all=ce_all, ce_payload=ce_pay, acc_payload=acc_pay,
        instr_seq=instr_seq, ce_seq=ce_seq, sel_change=selchg,
        share_edited=share_edited, perturb=perturb, relpert=relpert,
        n_edited=n_edited,
        primary=np.array(PRIMARY, dtype=object),
        exploratory=np.array(EXPLORATORY, dtype=object))

    # ---------------- 集計 ----------------
    def paired(arm):
        if arm not in ia or "none" not in ia:
            return None
        d = iv[ia[arm]] - iv[ia["none"]]
        se = float(d.std(ddof=1) / math.sqrt(len(d))) if len(d) >= 2 else float("nan")
        if not np.isfinite(se) or se == 0:
            t, p, mde = 0.0, 1.0, 0.0
        else:
            t = float(d.mean() / se)
            p = float(2 * stats.t.sf(abs(t), df=len(d) - 1))
            mde = float(stats.t.ppf(0.975, len(d) - 1) * se)
        # 系列単位の反転（McNemar）
        b = instr_seq[ia["none"]].reshape(-1)
        c = instr_seq[ia[arm]].reshape(-1)
        n01 = int(((b == 1) & (c == 0)).sum())   # 正解→不正解
        n10 = int(((b == 0) & (c == 1)).sum())   # 不正解→正解
        mc_p = float(stats.binomtest(min(n01, n10), n01 + n10, 0.5).pvalue) \
            if (n01 + n10) > 0 else 1.0
        # 系列単位 ce_seq の paired t（seed ごと）
        tts = []
        for j in range(ns):
            tv = float(stats.ttest_rel(ce_seq[ia[arm], j],
                                       ce_seq[ia["none"], j]).statistic)
            tts.append(tv if np.isfinite(tv) else 0.0)
        dseq = (ce_seq[ia[arm]] - ce_seq[ia["none"]]).reshape(-1)
        absd = np.abs(dseq)
        ntop = max(1, int(math.ceil(len(absd) * 0.01)))
        top1_share = float(np.sort(absd)[-ntop:].sum() / max(1e-12, absd.sum()))
        return {"arm": arm, "iv_none": float(iv[ia["none"]].mean()),
                "iv_arm": float(iv[ia[arm]].mean()),
                "delta": float(d.mean()), "se": se, "t": t, "p": p,
                "n": int(len(d)), "mde": mde, "per_seed": d.tolist(),
                "n_neg": int((d < 0).sum()),
                "mcnemar": {"n01": n01, "n10": n10, "p": mc_p},
                "ce_seq_t_per_seed": tts,
                "ce_seq_delta": float(dseq.mean()),
                "ce_seq_median": float(np.median(dseq)),
                "ce_seq_max": float(np.max(absd)),
                "ce_seq_top1_share": top1_share,
                "sel_change_mean": selchg[ia[arm]].mean(0).tolist(),
                "share_edited_mean": share_edited[ia[arm]].mean(0).tolist(),
                "diff_l2": float(perturb[ia[arm]].mean()),
                "rel_perturb": float(relpert[ia[arm]].mean()),
                "n_edited": int(n_edited[ia[arm]])}

    comps = {a: paired(a) for a in args.arms if a != "none"}

    # Holm（主比較 7 腕のみ。探索的腕は補正対象外）
    prim = [a for a in PRIMARY if a in comps]
    order = sorted(prim, key=lambda a: comps[a]["p"])
    holm = {}
    running = 0.0
    for r, a in enumerate(order):
        adj = min(1.0, (len(prim) - r) * comps[a]["p"])
        running = max(running, adj)
        holm[a] = {"p_raw": comps[a]["p"], "p_holm": float(running),
                   "rank": r + 1, "m": len(prim)}
    for a in comps:
        comps[a]["p_holm"] = holm[a]["p_holm"] if a in holm else None
        comps[a]["class"] = "primary" if a in holm else "exploratory"

    ok_calib = all(c["bit_match"] for c in calib)
    oracle_ok = ("oracle" in comps and
                 comps["oracle"]["delta"] <= -0.5)
    kill = [a for a in ("dir_0016", "dir_0016_a6")
            if a in comps and
            comps[a]["p_holm"] is not None and
            comps[a]["p_holm"] < 0.05 and
            abs(comps[a]["delta"]) > comps[a]["mde"]]

    analysis = {
        "calibration": {"items": calib, "n": len(calib),
                        "all_bit_match": bool(ok_calib)},
        "sensitivity": {"oracle_delta": comps.get("oracle", {}).get("delta"),
                        "oracle_ok": bool(oracle_ok)},
        "comparisons": comps, "holm": holm,
        "verdict": {
            "calibration_ok": bool(ok_calib),
            "sensitivity_ok": bool(oracle_ok),
            "prediction_falsified_by": kill,
            "mechanism": {
                "sel_change_by_arm": {a: comps[a]["sel_change_mean"]
                                      for a in comps},
                "all_zero_sel_change": bool(all(
                    max(comps[a]["sel_change_mean"]) == 0.0 for a in comps)),
            },
        },
        "meta": {"threads": args.threads, "n_eval": args.n_eval,
                 "eval_seed": EVAL_SEED, "seeds": list(args.seeds),
                 "arms": list(args.arms), "n_rows": len(rows),
                 "smoke": args.smoke},
    }
    with open(os.path.join(HERE, f"{tag}_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2, default=float)

    log("")
    log("== 校正 ==")
    log(f"  {sum(c['bit_match'] for c in calib)}/{len(calib)} bit-match  "
        f"all_bit_match={ok_calib}")
    for c in calib:
        if not c["bit_match"]:
            log(f"  MISMATCH s{c['seed']} {c['field']} ref={c['ref']} got={c['got']}")
    log("")
    log("== 主指標 instr_valid（none との paired 差）==")
    for a in args.arms:
        if a == "none" or a not in comps:
            continue
        c = comps[a]
        ph = c["p_holm"]
        log(f"  {a:<17s} Δ={c['delta']:+.4f} se={c['se']:.4f} t={c['t']:+.2f} "
            f"p={c['p']:.4f} Holm={('%.4f' % ph) if ph is not None else 'explore':>8s} "
            f"MDE={c['mde']:.4f} Mc={c['mcnemar']['n01']}/{c['mcnemar']['n10']} "
            f"selchg={np.round(c['sel_change_mean'], 4).tolist()}")
    log("")
    log(f"sensitivity oracle_ok={oracle_ok}  "
        f"prediction_falsified_by={kill}")
    log(f"saved: {tag}_results.json / {tag}_delta.npz / {tag}_analysis.json")
    os._exit(0)


if __name__ == "__main__":
    main()
