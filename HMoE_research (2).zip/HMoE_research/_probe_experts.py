# -*- coding: utf-8 -*-
"""_probe_experts.py — expert モジュールの実装を確認する（使い捨て）

知りたいこと:
  1. OlmoeExperts の forward は per-expert ループか fused einsum か
  2. 重みの形（gate_up_proj が fused か、gate_proj/up_proj が別か）
  3. バイアスの有無、活性化関数
  4. rank-8 を動的に狙えるか（forward を差し替えられるか）
"""
import inspect
import os

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "olmoe-1b-7b")

from transformers import AutoModelForCausalLM

m = AutoModelForCausalLM.from_pretrained(MODEL, torch_dtype=torch.bfloat16,
                                         device_map="cpu", low_cpu_mem_usage=True)
blk = m.model.layers[0].mlp
print("=== mlp ===")
print(type(blk))
print("children:", [(n, type(c).__name__) for n, c in blk.named_children()])
exp = blk.experts
print("\n=== experts ===")
print(type(exp))
for n, p in exp.named_parameters():
    print("  param %-24s %s" % (n, tuple(p.shape)))
for n, b in exp.named_buffers():
    print("  buffer %-23s %s" % (n, tuple(b.shape)))
print("\n--- experts.forward ---")
try:
    print(inspect.getsource(exp.forward))
except Exception as e:
    print("source unavailable:", e)
print("\n--- mlp.forward ---")
try:
    print(inspect.getsource(blk.forward))
except Exception as e:
    print("source unavailable:", e)
print("\n=== config ===")
for k in ("hidden_size", "intermediate_size", "num_experts", "num_experts_per_tok",
          "hidden_act", "norm_topk_prob"):
    print("  %-22s %s" % (k, getattr(m.config, k, None)))
print("\n=== gate ===")
print(type(blk.gate))
try:
    print(inspect.getsource(blk.gate.forward))
except Exception as e:
    print("source unavailable:", e)
