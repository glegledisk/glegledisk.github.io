# -*- coding: utf-8 -*-
"""e7_eval_artifact.py — 60 epoch 単点評価が tail をどれだけ過大評価するか。

診断ラン 11 本のトレースから、最終 epoch の val_ce と「最終 k epoch の中央値」を比較する。
一過性スパイクが終盤に当たると単点評価だけが跳ね、中央値は安定することを示す。
"""
import json
import os

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
D = json.load(open(os.path.join(HERE, "e7_catastrophe_traces.json"), encoding="utf-8"))
T = D["traces"]

rows = []
for name, tr in T.items():
    v = np.array([x["val_ce"] for x in tr])
    rows.append(dict(run=name, endpoint=v[-1], last5_med=np.median(v[-5:]),
                     last10_med=np.median(v[-10:]), last20_med=np.median(v[-20:]),
                     max_last10=v[-10:].max(), p50_all=np.median(v)))
df = pd.DataFrame(rows)
pd.set_option("display.width", 200)
print("=== 最終 epoch 単点 vs 最終 k epoch 中央値（val_ce） ===")
print(df.round(4).to_string(index=False))

print("\n=== 集計 ===")
print(f" 単点評価の平均 {df['endpoint'].mean():.4f} / 中央値 {df['endpoint'].median():.4f} / max {df['endpoint'].max():.4f}")
print(f" 最終5中央値の平均 {df['last5_med'].mean():.4f} / 中央値 {df['last5_med'].median():.4f} / max {df['last5_med'].max():.4f}")
print(f" 最終10中央値の平均 {df['last10_med'].mean():.4f} / max {df['last10_med'].max():.4f}")
print(f" 単点 > 0.3 のラン: {int((df['endpoint'] > 0.3).sum())}/{len(df)}  "
      f"最終5中央値 > 0.3 のラン: {int((df['last5_med'] > 0.3).sum())}/{len(df)}")

print("\n=== 壊滅 2 例の詳細 ===")
for name in ("wb3_s7", "wb4_s8"):
    v = np.array([x["val_ce"] for x in T[name]])
    print(f" {name}: 単点 {v[-1]:.4f} / 最終5中央値 {np.median(v[-5:]):.4f} / "
          f"最終10中央値 {np.median(v[-10:]):.4f} / 全 epoch 中央値 {np.median(v):.4f}  "
          f"→ 単点は中央値の {v[-1] / max(np.median(v[-5:]), 1e-9):.1f} 倍")
