"""H6: 交互作用テスト（合成課題 × 均一/不均一 expert × ブロックサイズ）。

## 設計の根拠（H1〜H5 の結果を全部使う）

- **課題は H5 の合成課題**。`depth1`（幅に感応）と `depth2`/`depth3`（幅に無感応）が
  同一系列に同居し、CE 差が 0.44 対 2.88 と大きい（§7.1）。
- **d_ff=512**。H5 で `depth1` が解けるのは活性 H=768 の一点だけだった（H=512 と H=1024 は
  どちらも失敗）。d_ff=512 なら不均一アームの `s=1.5` expert がちょうど H=768 になる。
  → **均一（全 expert H=512）は原理的に届かず、不均一だけが届く**構図が作れる。
- **λ を入れる**（§2.2, §4.4）。λ=0 ではルータが小さい expert を選ぶ理由を持たない。
- **muP 初期化**（§6.2）。std 固定だと幅依存で不安定になり、幅の比較が壊れる（§5.4 の正体）。
- **幅 4.0 以上は使わない**（§6.5 の不安定域）。不均一の活性幅は 1.0〜3.0 に収まる。

## 要因

  b ∈ {1, 4, 16}   （b=1 が AR）
  arm:
    uni_k1  均一 [1.0]*8, top-1  活性 H=512
    uni_k2  均一 [1.0]*8, top-2  活性 H=1024
    het_l05 不均一 [.5,.5,.75,.75,1.25,1.25,1.5,1.5], top-2, λ=0.05
    het_l2  同上, λ=0.2
  seed ∈ {0,1,2}

総パラメータは全アームで一致（sizes の合計 8.0、d_ff=512）。
主指標: 検証 ELBO。Δ_b = L_uni_k2(b) − L_het(b)。交互作用 = Δ_16 − Δ_1。
"""
import json
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

from h3_bigvocab import Net, block_mask, sample_mask, diff_loss, evaluate, SEQ, P_NCUE
from h4_arith import mup_init
from h5_tasks import gen_comp, make_types, TYPE_NAMES

HERE = os.path.dirname(os.path.abspath(__file__))

C = 31
D_FF = 512
HET = [0.5, 0.5, 0.75, 0.75, 1.25, 1.25, 1.5, 1.5]
ARMS = {
    "uni_k1": dict(sizes=[1.0] * 8, k=1, lam=0.0),
    "uni_k2": dict(sizes=[1.0] * 8, k=2, lam=0.0),
    "het_l005": dict(sizes=HET, k=2, lam=0.005),
    "het_l01": dict(sizes=HET, k=2, lam=0.01),
}
BS = [1, 4, 16]
SEEDS = [0, 1, 2]
STEPS = 3000
LR = 3e-3


@torch.no_grad()
def diag_by_depth(model, xs, am, mask_id):
    """depth 型ごとの平均活性幅（ルータが配分しているか）。"""
    g = torch.Generator().manual_seed(4242)
    dev = xs.device
    tm = make_types("comp").to(dev)
    acc = {}
    for _ in range(6):
        m, _ = sample_mask(xs.shape[0], 0.1, g, dev)
        inp = torch.where(m, torch.full_like(xs, mask_id), xs)
        _, _, _, fis, _ = model(inp, am)
        sizes = model.blocks[0].moe.sizes
        width = sizes[fis[-1].view(xs.shape[0], SEQ, -1)].sum(-1)
        for ti, tn in enumerate(TYPE_NAMES["comp"]):
            sel = m & (tm == ti).unsqueeze(0)
            if sel.any():
                acc.setdefault(tn, []).append(float(width[sel].mean()))
    return {k: float(np.mean(v)) for k, v in acc.items()}


def run(arm, b, seed):
    spec = ARMS[arm]
    torch.manual_seed(seed)
    np.random.seed(seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    n_class = 2 * C + 1
    mask_id = 2 * C

    model = Net(n_class, 128, 4, 4, D_FF, spec["sizes"], spec["k"]).to(dev)
    mup_init(model, 128)
    opt = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda i: min(1.0, i / max(1, STEPS * 0.05)))
    am = ~block_mask(b).to(dev)

    gt = torch.Generator().manual_seed(1234)
    f = torch.randint(0, C, (C, C), generator=gt)
    gen = torch.Generator(device="cpu").manual_seed(seed * 77 + 1)
    xv = gen_comp(512, C, f, torch.Generator().manual_seed(7)).to(dev)

    t0 = time.time()
    for _ in range(STEPS):
        x = gen_comp(64, C, f, gen).to(dev)
        loss, cost, aux = diff_loss(model, x, am, gen, mask_id)
        opt.zero_grad(set_to_none=True)
        (loss + 0.01 * aux + spec["lam"] * cost).backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()

    val = evaluate(model, xv, am, mask_id)
    tm = make_types("comp").to(dev)
    from h5_tasks import ce_by_type
    cells = ce_by_type(model, xv, am, mask_id, tm, TYPE_NAMES["comp"])
    diag = diag_by_depth(model, xv, am, mask_id)
    with torch.no_grad():
        xb = gen_comp(256, C, f, torch.Generator().manual_seed(11)).to(dev)
        m, _ = sample_mask(256, 0.5, torch.Generator().manual_seed(5), dev)
        inp = torch.where(m, torch.full_like(xb, mask_id), xb)
        _, cost_meas, _, _, _ = model(inp, am)
    return dict(arm=arm, b=b, seed=seed, steps=STEPS, lr=LR, d_ff=D_FF, C=C,
                val=val, cost=float(cost_meas), cells=cells, diag=diag,
                sec=time.time() - t0,
                params=sum(p.numel() for p in model.parameters()))


def main():
    out = os.path.join(HERE, "h6_results.jsonl")
    done = set()
    if os.path.exists(out):
        with open(out, encoding="utf-8") as fp:
            for line in fp:
                if line.strip():
                    d = json.loads(line)
                    done.add((d["arm"], d["b"], d["seed"]))
    jobs = [(a, b, s) for b in BS for a in ARMS for s in SEEDS]
    print(f"resume: {len(done)} done / {len(jobs)} total", flush=True)

    t0 = time.time()
    for i, (arm, b, seed) in enumerate(jobs, 1):
        if (arm, b, seed) in done:
            continue
        print(f"[{i}/{len(jobs)}] {arm} b={b} seed={seed} elapsed={(time.time()-t0)/60:.1f}m", flush=True)
        try:
            r = run(arm, b, seed)
        except Exception as e:                                   # noqa: BLE001
            print(f"  FAIL {type(e).__name__}: {e}", flush=True)
            torch.cuda.empty_cache()
            continue
        with open(out, "a", encoding="utf-8") as fp:
            fp.write(json.dumps(r, ensure_ascii=False) + "\n")
        print(f"  val={r['val']:.4f} cost={r['cost']:.2f} "
              f"d1={r['cells'].get('depth1', float('nan')):.3f} "
              f"d2={r['cells'].get('depth2', float('nan')):.3f} "
              f"d3={r['cells'].get('depth3', float('nan')):.3f} sec={r['sec']:.0f}", flush=True)
    print("DONE", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
