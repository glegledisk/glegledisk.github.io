import difflib, io
a = io.open("検証報告_A4_小にReLU2は正しいか_20261102.md", encoding="utf-8").read().split("\n")
b = io.open("_tmp_a4.md", encoding="utf-8").read().split("\n")
for line in difflib.unified_diff(a, b, "before", "after", lineterm="", n=0):
    print(line[:200])