# -*- coding: utf-8 -*-
"""_a4b_verify_report.py — 検証報告_A4b の数値を一次データから引き直して突合する。"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a4")
ok, bad = [], []


def chk(name, got, want, tol=5e-3):
    if abs(got - want) <= tol * max(1.0, abs(want)):
        ok.append(f"  OK  {name}: {got:.6g} (report {want})")
    else:
        bad.append(f"  NG  {name}: {got:.6g} != report {want}")


raw = [r for r in json.load(open(os.path.join(D, "a4_results.json"), encoding="utf-8"))
       if "evals" in r]
g = [r for r in json.load(open(os.path.join(D, "a4_results_g.json"), encoding="utf-8"))
     if "evals" in r]

# --- 1. 校正 ---
GAIN = {"all_relu": (1.0000, 1.0000, 1.0000),
        "small_relu2": (1.0869, 0.9903, 1.4024),
        "large_relu2": (1.2134, 1.0000, 2.0251),
        "all_relu2": (1.6993, 1.1662, 2.1250)}
for a, (m, lo, hi) in GAIN.items():
    gi = next(x for x in g if x["arm"] == a)["gain"]
    chk(f"gain mean {a}", gi.get("mean", 1.0), m, tol=2e-3)
    chk(f"gain min {a}", gi["min"], lo, tol=2e-3)
    chk(f"gain max {a}", gi["max"], hi, tol=2e-3)
chk("small e0 gain", next(x for x in g if x["arm"] == "small_relu2")["gain"]["by_expert"][0],
    1.2445, tol=2e-3)
chk("small e1 gain", next(x for x in g if x["arm"] == "small_relu2")["gain"]["by_expert"][1],
    1.2773, tol=2e-3)
chk("large e6 gain", next(x for x in g if x["arm"] == "large_relu2")["gain"]["by_expert"][6],
    1.8097, tol=2e-3)
chk("large e7 gain", next(x for x in g if x["arm"] == "large_relu2")["gain"]["by_expert"][7],
    1.7516, tol=2e-3)

# --- 2. 到達点 raw → gain ---
TAB = {"all_relu": (0.0219, 0.0219, 0.643, 0.643),
       "small_relu2": (0.0211, 0.0209, 0.632, 0.641),
       "large_relu2": (0.0206, 0.0179, 0.688, 0.695),
       "all_relu2": (0.0651, 0.5439, 0.121, 0.127)}
for a, (c0, c1, i0, i1) in TAB.items():
    chk(f"CE raw {a}", float(np.mean([r["evals"][-1]["ce_all"] for r in raw if r["arm"] == a])),
        c0, tol=5e-3)
    chk(f"CE gain {a}", float(np.mean([r["evals"][-1]["ce_all"] for r in g if r["arm"] == a])),
        c1, tol=5e-3)
    chk(f"iv raw {a}", float(np.mean([r["evals"][-1]["instr_valid"] for r in raw if r["arm"] == a])),
        i0, tol=1e-2)
    chk(f"iv gain {a}", float(np.mean([r["evals"][-1]["instr_valid"] for r in g if r["arm"] == a])),
        i1, tol=1e-2)


def paired(rows, a, b, key):
    da = {r["seed"]: r["evals"][-1][key] for r in rows if r["arm"] == a}
    db = {r["seed"]: r["evals"][-1][key] for r in rows if r["arm"] == b}
    ks = sorted(set(da) & set(db))
    x = np.array([da[i] for i in ks])
    y = np.array([db[i] for i in ks])
    d = x - y
    se = d.std(ddof=1) / math.sqrt(len(d))
    t, p = stats.ttest_rel(x, y)
    return float(d.mean()), float(se), float(t), float(p), int((d > 0).sum())


# --- 3. 主対比 ---
WANT = {
    ("small_relu2", "all_relu", "instr_valid"): ((-0.0106, 0.9051, 3), (-0.0016, 0.9776, 4)),
    ("large_relu2", "all_relu", "instr_valid"): ((+0.0452, 0.7441, 5), (+0.0522, 0.3958, 4)),
    ("all_relu2", "all_relu", "instr_valid"): ((-0.5220, 0.0005, 0), (-0.5163, 0.0044, 0)),
    ("small_relu2", "large_relu2", "instr_valid"): ((-0.0558, 0.6350, 3), (-0.0539, 0.4544, 2)),
    ("all_relu2", "all_relu", "ce_all"): ((+0.0432, 0.0114, 6), (+0.5220, 0.0672, 6)),
}
for (a, b, key), (w0, w1) in WANT.items():
    m, se, t, p, pos = paired(raw, a, b, key)
    chk(f"{a}-{b} {key} raw mean", m, w0[0], tol=2e-2)
    chk(f"{a}-{b} {key} raw p", p, w0[1], tol=5e-2)
    chk(f"{a}-{b} {key} raw pos", pos, w0[2], tol=0)
    m, se, t, p, pos = paired(g, a, b, key)
    chk(f"{a}-{b} {key} gain mean", m, w1[0], tol=2e-2)
    chk(f"{a}-{b} {key} gain p", p, w1[1], tol=5e-2)
    chk(f"{a}-{b} {key} gain pos", pos, w1[2], tol=0)

# --- 4. ルーティング ---
ROUTE = {("small_relu2", "all_relu"): ((-0.1693, 0.0010, 6), (-0.1714, 0.0004, 6)),
         ("large_relu2", "all_relu"): ((+0.0022, 0.8173, 3), (-0.0025, 0.8295, 2)),
         ("all_relu2", "all_relu"): ((-0.0254, 0.4100, 4), (-0.0162, 0.4196, 5))}
for (a, b), (w0, w1) in ROUTE.items():
    for nm, rows, w in (("raw", raw, w0), ("gain", g, w1)):
        da = {r["seed"]: r["routing"]["small_share"] for r in rows if r["arm"] == a}
        db = {r["seed"]: r["routing"]["small_share"] for r in rows if r["arm"] == b}
        ks = sorted(set(da) & set(db))
        d = np.array([da[i] - db[i] for i in ks])
        t, p = stats.ttest_rel([da[i] for i in ks], [db[i] for i in ks])
        chk(f"routing {a}-{b} [{nm}] Δ", float(d.mean()), w[0], tol=2e-2)
        chk(f"routing {a}-{b} [{nm}] p", float(p), w[1], tol=5e-2)
        chk(f"routing {a}-{b} [{nm}] 負", int((d < 0).sum()), w[2], tol=0)

# --- 5. 校正が参照を動かしていないこと ---
a1 = json.load(open(os.path.join(HERE, "data", "a1", "a1_results.json"), encoding="utf-8"))
a1relu = {r["seed"]: r["evals"][-1]["ce_all"] for r in a1 if r["arm"] == "relu"}
for r in g:
    if r["arm"] != "all_relu":
        continue
    if abs(r["evals"][-1]["ce_all"] - a1relu[r["seed"]]) > 1e-9:
        bad.append(f"  NG  all_relu(gain) が A1 の relu と不一致 seed{r['seed']}")
if not any("all_relu(gain)" in b for b in bad):
    ok.append("  OK  all_relu は gain 補正を入れても A1 の relu と完全一致（Δ < 1e-9）")

print("\n".join(ok))
if bad:
    print("\n".join(bad))
    print(f"\nFAIL: {len(bad)} 件")
    sys.exit(1)
print(f"\nPASS: {len(ok)} 件すべて報告書と一致")
