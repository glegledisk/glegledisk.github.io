#!/usr/bin/env python3
"""K4: Bayes 余裕の大きい課題（Qwenputer 型トレース）で、教師 HMoE と等計算量の dense 生徒を比べる。

なぜ課題を変えるか
  書き換え課題（K1 系）は 16 epoch で Bayes 下限 0.3251 の 0.026 上まで飽和し、
  教師と生徒の差が −0.0026 ± 0.0021（MDE 0.0070）になった。**識別力を残していない。**
  トレース課題は決定論的（Bayes CE = 0）で、6 epoch の HMoE でも CE 0.104。
  **余裕が 4 倍**あり、幅・容量の差が出る余地がある。

設計
  task    : Q1 の compute（8 桁初期値 + 固定プログラム ADADSDADAS を 10 命令、T=109）
  教師    : H+LB（幅 32/32/96/96/160/160/224/224, top-2, p_pen auxw=0.05）
  生徒    : dense W = round(教師の実測 active 幅)  ← **seed ごとに等計算量へ合わせる**
  条件    : 3000 系列 × 16 epoch, bs 32, lr 2e-3, 1 スレッド、評価 seed 777 の 2048 系列
  指標    : CE_all / CE_payload / acc_payload / instr_valid（10 命令すべて正解）/ 実測幅

  教師の幅は学習で決まる（初期は 256、p_pen で狭くなる）。固定 W で合わせると
  seed ごとにずれるので、**教師を先に訓練して実測幅を読み、その幅で生徒を作る**（K1b の処方）。

出力: k4_results.json / k4_out_utf8.txt / data/k4/ckpt_*.pt
"""
import argparse
import json
import os
import sys
import time
from multiprocessing import Pool

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
# e2b_rewrite_routing_fixed は simulation_hmoe_mmlu にある。worker（spawn）でも
# 効くよう、モジュール読み込み時にパスを通しておく（q1 を先に import する手もあるが、
# 依存の向きが読みにくくなるので明示する）。
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

LOG = os.path.join(HERE, "k4_out_utf8.txt")
D_MODEL, N_LAYERS = 128, 4


def log(msg):
    print(msg, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(msg + "\n")


def macs(W, E):
    """FFN + qkv/o + router の 1 トークンあたり MACs（attention と head は共通なので除く）。"""
    return N_LAYERS * (4 * D_MODEL * D_MODEL + 2 * D_MODEL * W + D_MODEL * E)


def worker(job):
    seed, seqs, epochs, n_eval, suf = job
    import numpy as np
    import torch
    import torch.nn.functional as F
    from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS
    from q1_trace_routing import (make_trace_batch, trace_loss, forward_q1,
                                  T_LEN, TRACE0, P_STEPS, TPI, VOCAB)

    torch.set_num_threads(1)
    t0 = time.time()

    @torch.no_grad()
    def ev(model, seq, typ, bs=128):
        n = seq.shape[0]
        L = T_LEN - TRACE0
        ce = np.zeros((n, L), dtype=np.float32)
        hit = np.zeros((n, L), dtype=bool)
        wid = np.zeros((n, L), dtype=np.float32)
        dims = np.array(model.dims, float)
        for i in range(0, n, bs):
            s = slice(i, min(i + bs, n))
            x = torch.from_numpy(seq[s])
            logits, idx_l = forward_q1(model, x, need_idx=True)
            lg = logits[:, TRACE0 - 1:-1, :len(VOCAB)]
            tgt = torch.from_numpy(seq[s, TRACE0:])
            lp = F.cross_entropy(lg.reshape(-1, len(VOCAB)), tgt.reshape(-1),
                                 reduction="none").reshape(-1, L)
            ce[s] = lp.numpy()
            hit[s] = (lg.argmax(-1).numpy() == tgt.numpy())
            acc = np.zeros((s.stop - s.start, L), dtype=np.float32)
            for ti in idx_l:
                a = ti.numpy()[:, TRACE0 - 1:-1, :]
                acc += dims[a].mean(-1)
            wid[s] = acc / len(idx_l)
        ty = typ[:, TRACE0:]
        m_st, m_pl = (ty == 1), (ty == 2)
        hp = hit.reshape(n, P_STEPS, TPI)[:, :, 2:]
        ok = hp.all(-1).all(-1)
        return {"ce_all": float(ce.mean()), "ce_payload": float(ce[m_pl].mean()),
                "ce_struct": float(ce[m_st].mean()),
                "acc_payload": float(hit[m_pl].mean()),
                "instr_valid": float(ok.mean()),
                "width": float(wid.mean()), "width_payload": float(wid[m_pl].mean()),
                "width_struct": float(wid[m_st].mean()),
                "ce_seq": ce.mean(1).astype(np.float64)}

    def train(model, aux_mode, auxw, seed):
        torch.manual_seed(seed)
        rng = np.random.default_rng(2000 + seed)
        opt = Adam(model.params(), lr=2e-3)
        hist = []
        steps = max(1, seqs // 32)
        for ep in range(epochs):
            run = 0.0
            for _ in range(steps):
                s, _t = make_trace_batch(rng, 32, task="compute")
                x = torch.from_numpy(s)
                logits, aux, _ = model(x, aux_mode=aux_mode)
                loss = trace_loss(logits, s) + auxw * aux
                loss.backward()
                opt.step(model.params())
                run += float(loss.detach())
            hist.append(run / steps)
        return hist

    ev_rng = np.random.default_rng(777)
    seq, typ = make_trace_batch(ev_rng, n_eval, task="compute")

    # --- 教師 ---
    torch.manual_seed(seed)
    tm = RewriteMoE(WIDTHS["H+LB"], seed=seed)
    hist_t = train(tm, "p_pen", 0.05, seed)
    rt = ev(tm, seq, typ)
    # --- 生徒（教師の実測幅に合わせる） ---
    W = int(round(rt["width"]))
    torch.manual_seed(seed)
    sm = RewriteMoE([W], seed=seed, topk=1)
    hist_s = train(sm, "none", 0.0, seed)
    rs = ev(sm, seq, typ)

    d = np.asarray(rs["ce_seq"]) - np.asarray(rt["ce_seq"])
    outdir = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "k4")
    os.makedirs(outdir, exist_ok=True)
    torch.save({k: v.detach() for k, v in tm.params().items()},
               os.path.join(outdir, "ckpt_teacher_s%d%s.pt" % (seed, suf)))
    torch.save({k: v.detach() for k, v in sm.params().items()},
               os.path.join(outdir, "ckpt_dense%d_s%d%s.pt" % (W, seed, suf)))
    return {
        "seed": seed, "W_student": W,
        "teacher": {k: v for k, v in rt.items() if k != "ce_seq"},
        "student": {k: v for k, v in rs.items() if k != "ce_seq"},
        "macs_ratio": macs(rt["width"], 8) / macs(W, 1),
        "delta": float(d.mean()),
        "se_seq": float(d.std(ddof=1) / np.sqrt(len(d))),
        "t_seq": float(d.mean() / (d.std(ddof=1) / np.sqrt(len(d)))),
        "hist_t": hist_t, "hist_s": hist_s,
        "sec": round(time.time() - t0, 1),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=list(range(10)))
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=16)
    ap.add_argument("--n_eval", type=int, default=2048)
    ap.add_argument("--tag", type=str, default="")
    args = ap.parse_args()

    suf = ("_" + args.tag) if args.tag else ""
    global LOG
    LOG = os.path.join(HERE, "k4_out_utf8%s.txt" % suf)
    if os.path.exists(LOG):
        os.remove(LOG)
    log("K4: トレース課題で教師 HMoE vs 等計算量 dense（epochs=%d, n_eval=%d）"
        % (args.epochs, args.n_eval))
    log("seeds=%s workers=%d seqs=%d tag=%s" % (args.seeds, args.workers, args.seqs, suf))
    t0 = time.time()

    jobs = [(s, args.seqs, args.epochs, args.n_eval, suf) for s in args.seeds]
    rows = []
    part = os.path.join(HERE, "k4_partial%s.json" % suf)
    with Pool(processes=args.workers) as pool:
        for r in pool.imap_unordered(worker, jobs):
            rows.append(r)
            log("  s%-2d  W=%-3d  CE_t %.4f / CE_s %.4f  Δ %+.4f  acc_p %.3f/%.3f  "
                "instr %.3f/%.3f  (%.0fs)"
                % (r["seed"], r["W_student"], r["teacher"]["ce_all"],
                   r["student"]["ce_all"], r["delta"],
                   r["teacher"]["acc_payload"], r["student"]["acc_payload"],
                   r["teacher"]["instr_valid"], r["student"]["instr_valid"], r["sec"]))
            with open(part, "w", encoding="utf-8") as f:
                json.dump({"rows": rows}, f, ensure_ascii=False, indent=2, default=float)
    rows.sort(key=lambda r: r["seed"])

    d = np.array([r["delta"] for r in rows])
    n = len(d)
    se = float(d.std(ddof=1) / np.sqrt(n))
    coef = {2: 5.36, 5: 3.49}.get(n - 1, 2.95 if n < 12 else 2.85)
    log("")
    log("== 集計（n=%d） ==" % n)
    log("  ΔCE = %+.4f  中央値 %+.4f  SD %.4f  se %.4f  t %+.2f  %d/%d 負  MDE %.4f"
        % (d.mean(), np.median(d), d.std(ddof=1), se, d.mean() / se,
           int((d < 0).sum()), n, coef * se))
    for key in ("ce_all", "ce_payload", "acc_payload", "instr_valid", "width"):
        a = np.array([r["teacher"][key] for r in rows])
        b = np.array([r["student"][key] for r in rows])
        log("  %-12s 教師 %.4f ± %.4f / 生徒 %.4f ± %.4f"
            % (key, a.mean(), a.std(ddof=1), b.mean(), b.std(ddof=1)))
    log("  MACs 比（教師/生徒）%.3f ± %.3f"
        % (np.mean([r["macs_ratio"] for r in rows]),
           np.std([r["macs_ratio"] for r in rows], ddof=1)))
    log("  壁時計 %.0f 分" % ((time.time() - t0) / 60))

    with open(os.path.join(HERE, "k4_results%s.json" % suf), "w", encoding="utf-8") as f:
        json.dump({"rows": rows, "epochs": args.epochs,
                   "agg": {"delta_mean": float(d.mean()), "median": float(np.median(d)),
                           "sd": float(d.std(ddof=1)), "se": se,
                           "t": float(d.mean() / se), "n": n, "mde": coef * se,
                           "n_neg": int((d < 0).sum())}}, f,
                  ensure_ascii=False, indent=2, default=float)
    log("[write] k4_results%s.json" % suf)
    os._exit(0)


if __name__ == "__main__":
    main()
