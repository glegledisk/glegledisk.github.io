# -*- coding: utf-8 -*-
"""S1b: distractor_drop control for the S1 sibling claim.

For every query that has a sibling candidate, rebuild the full ToC with the
SIBLING's row removed (the gold row stays) and measure the same teacher-forced
margin.  This separates

    A = toc - toc_drop        "the gold row carries sibling-specific information"
    B = toc - distractor_drop "the two rows are visible and compete"

If B ~ 0            -> gold-specific information (A is real)
If B ~ -A           -> relative visibility only (A + B ~ 0)

The sibling row is also removed for the far candidate, which gives a placebo:
the far decision should not care about a sibling row.

Measurement only.  No ablation, no calibration, no gate patching.

Run (PowerShell):
  $p = "C:\\Users\\gochu\\.workbuddy-ai\\binaries\\python\\envs\\gpu\\Scripts\\python.exe"
  & $p s1b_distractor_drop.py --domains finance,law --limit 1 --tag s1b_smoke
  & $p s1b_distractor_drop.py --tag s1b_distractor_drop
"""
import argparse
import json
import os
import time

import numpy as np
import torch

import s1_stair_routing as S

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--manifest", type=str, default=os.path.join(HERE, "s1_manifest.json"))
    ap.add_argument("--core", type=str, default=os.path.join(HERE, "s1_core.npz"))
    ap.add_argument("--gpu-gib", type=float, default=7.5)
    ap.add_argument("--cpu-gib", type=float, default=12.0)
    ap.add_argument("--domains", type=str, default="all")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--tag", type=str, default="s1b_distractor_drop")
    args = ap.parse_args()

    t_start = time.time()
    with open(args.manifest, encoding="utf-8") as f:
        man = json.load(f)
    doms = list(man["domains"].keys()) if args.domains == "all" else [d.strip() for d in args.domains.split(",")]

    # --- reference: prompt lengths and gold ids from the S1 core run ---
    z = np.load(args.core, allow_pickle=True)
    core_plen = {}
    core_gold = {}
    for i in range(len(z["row_domain"])):
        if int(z["row_is_gold"][i]) and str(z["row_prompt"][i]) == "toc":
            core_plen[(str(z["row_domain"][i]), int(z["row_query_id"][i]))] = int(z["row_prompt_len"][i])
    for i in range(len(z["gold_len"])):
        if str(z["gold_prompt"][i]) == "toc" and str(z["gold_ablation"][i]) == "base":
            L = int(z["gold_len"][i])
            core_gold[(str(z["gold_domain"][i]), int(z["gold_query_id"][i]))] = \
                z["gold_ids"][i, :L].astype(np.int64)
    log("[0/4] reference: %d toc prompt lengths, %d gold sequences" % (len(core_plen), len(core_gold)))

    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[1/4] loading %s" % args.model)
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      device_map: " + json.dumps({str(k): str(v) for k, v in model.hf_device_map.items()}))

    Wsrc = model.lm_head.weight
    if Wsrc.is_meta:
        hook = getattr(model.lm_head, "_hf_hook", None)
        wm = getattr(hook, "weights_map", None) if hook is not None else None
        real = wm["weight"] if wm is not None else None
        if real is None or getattr(real, "is_meta", False):
            raise RuntimeError("lm_head real weight not found in weights_map")
    else:
        real = Wsrc
    Whead = real.detach().float().cpu()
    log("      lm_head materialised: %s" % (tuple(Whead.shape),))

    chk = tok("The quick brown fox jumps over the lazy dog.", return_tensors="pt",
              add_special_tokens=False).input_ids.to(model.device)
    with torch.no_grad():
        h = model.model(input_ids=chk, use_cache=False).last_hidden_state[:, -1:, :]
        lg = h.float().cpu() @ Whead.t()
        ref = model(input_ids=chk, use_cache=False).logits[:, -1:, :].float().cpu()
    head_err = float((lg - ref).abs().max())
    log("      head check max|N@W.T - logits| = %.5f" % head_err)
    if head_err > 0.5:
        raise RuntimeError("head check failed: %.5f" % head_err)

    # --- measurement ---
    log("[2/4] forward (distractor_drop)")
    rows = []
    gold_tok = []
    checks = {"plen_ok": 0, "plen_bad": 0, "gold_ok": 0, "gold_bad": 0, "skipped": 0}
    n_fwd = 0
    t_fwd = 0.0

    for dom in doms:
        titles = man["domains"][dom]["titles"]
        book = man["domains"][dom]["book"]
        entries = man["domains"][dom]["entries"]
        if args.limit:
            entries = entries[:args.limit]
        for ei, ent in enumerate(entries):
            sib = next((c for c in ent["candidates"] if c["type"] == "sibling"), None)
            if sib is None:
                checks["skipped"] += 1
                continue
            n_in = sum(1 for t in titles if t == sib["title"])
            if n_in != 1 or sib["title"] == ent["gold"]:
                checks["skipped"] += 1
                log("      SKIP %s/%s: sibling occurrences in titles=%d" % (dom, ent["query_id"], n_in))
                continue

            toc_text = "\n".join(titles)
            dd_text = "\n".join(t for t in titles if t != sib["title"])
            prompt = S.build_prompt(book, ent["query"], dd_text, True)
            prompt_ids = tok(prompt, add_special_tokens=False)["input_ids"]

            cands = [{"type": "gold", "title": ent["gold"], "lca": 99,
                      "depth": ent["gold_depth"], "train_count": ent["gold_train_count"]}]
            cands += ent["candidates"]
            cdata = [S.tokenize_suffix(tok, c["title"]) for c in cands]
            gd = cdata[0]
            for c, cd in zip(cands, cdata):
                cd["div"], cd["div_level"] = S.divergence(gd, cd)

            # --- instrument checks against the S1 core run ---
            key = (dom, ent["query_id"])
            toc_prompt = S.build_prompt(book, ent["query"], toc_text, True)
            toc_plen = len(tok(toc_prompt, add_special_tokens=False)["input_ids"])
            if key in core_plen and toc_plen == core_plen[key]:
                checks["plen_ok"] += 1
            else:
                checks["plen_bad"] += 1
                log("      PLEN MISMATCH %s: rebuilt=%d core=%s" % (str(key), toc_plen, core_plen.get(key)))
            if key in core_gold and np.array_equal(np.asarray(gd["ids"], dtype=np.int64), core_gold[key]):
                checks["gold_ok"] += 1
            else:
                checks["gold_bad"] += 1
                log("      GOLD MISMATCH %s" % str(key))

            gold_ids = gd["ids"]
            C = len(gold_ids)
            P = len(prompt_ids)
            seq = prompt_ids + gold_ids
            ids = torch.tensor([seq], dtype=torch.long, device=model.device)
            t1 = time.time()
            with torch.no_grad():
                out = model.model(input_ids=ids, use_cache=False)
                h = out.last_hidden_state[:, P - 1:P - 1 + C, :]
                lg = h.float().cpu() @ Whead.t()
            t_fwd += time.time() - t1
            n_fwd += 1
            lsm = torch.log_softmax(lg, dim=-1)

            gtgt = torch.tensor(gold_ids, dtype=torch.long, device=lsm.device)
            gvals = lsm[0, torch.arange(C, device=lsm.device), gtgt].cpu().numpy()
            gfull = float(np.sum(gvals))

            for b, cd in enumerate(cdata):
                c = cands[b]
                div = cd["div"]
                if b == 0:
                    logp_div = float("nan")
                elif 0 <= div < C and 0 <= div < len(cd["ids"]):
                    logp_div = float(lsm[0, div, cd["ids"][div]])
                else:
                    logp_div = float("nan")
                rows.append({
                    "domain": dom, "query_id": ent["query_id"], "entry": ei,
                    "cand_type": c["type"], "is_gold": int(b == 0),
                    "lca": c["lca"], "depth": c["depth"], "train_count": c["train_count"],
                    "prompt": "distractor_drop", "ablation": "base",
                    "prompt_len": P, "logp_full": gfull if b == 0 else float("nan"),
                    "logp_div": logp_div, "div_idx": div, "div_level": cd["div_level"],
                    "n_tok": len(cd["ids"]),
                    "dropped_len": len(toc_text) - len(dd_text),
                })
            gold_tok.append({
                "entry": ei, "domain": dom, "prompt": "distractor_drop", "ablation": "base",
                "query_id": ent["query_id"], "ids": np.asarray(gold_ids), "str": gd["str"],
                "num_mask": gd["num_mask"], "logp": np.asarray(gvals, dtype=np.float32),
            })
            log("      %-16s q=%3d  P=%4d C=%2d  sibling_tok=%2d  %.2fs  (elapsed %.0fs)"
                % (dom, ent["query_id"], P, C, len(cdata[1]["ids"]), time.time() - t1, time.time() - t_start))

    log("[3/4] checks: %s" % json.dumps(checks))
    if checks["plen_bad"] or checks["gold_bad"]:
        raise RuntimeError("instrument check failed: %s" % json.dumps(checks))

    # --- save ---
    log("[4/4] saving")
    meta = {
        "model": args.model, "tag": args.tag, "prompt": "distractor_drop",
        "n_queries": len(gold_tok), "n_rows": len(rows), "n_fwd": n_fwd,
        "mean_fwd_s": t_fwd / max(n_fwd, 1), "elapsed_s": time.time() - t_start,
        "checks": checks, "dropped": "sibling candidate row only",
        "domains": doms, "limit": args.limit,
    }

    def arr(key, dtype=float):
        return np.asarray([r[key] for r in rows], dtype=dtype)

    def sarr(key):
        return np.asarray([r[key] for r in rows], dtype=object)

    maxC = max(len(g["ids"]) for g in gold_tok) if gold_tok else 0
    gt = {}
    a = np.full((len(gold_tok), maxC), np.nan, dtype=np.float64)
    for i, g in enumerate(gold_tok):
        a[i, :len(g["ids"])] = np.asarray(g["ids"], dtype=np.float64)
    gt["gold_ids"] = a
    gt["gold_len"] = np.asarray([len(g["ids"]) for g in gold_tok], dtype=np.int64)
    a = np.full((len(gold_tok), maxC), np.nan, dtype=np.float64)
    for i, g in enumerate(gold_tok):
        v = np.asarray(g["logp"], dtype=np.float64)
        a[i, :len(v)] = v
    gt["gold_logp"] = a
    gt["gold_isnum"] = np.full((len(gold_tok), maxC), False, dtype=bool)
    for i, g in enumerate(gold_tok):
        v = np.asarray(g["num_mask"], dtype=bool)
        gt["gold_isnum"][i, :len(v)] = v
    gt["gold_entry"] = np.asarray([g["entry"] for g in gold_tok], dtype=np.int64)
    gt["gold_query_id"] = np.asarray([g["query_id"] for g in gold_tok], dtype=np.int64)
    gt["gold_prompt"] = np.asarray([g["prompt"] for g in gold_tok], dtype=object)
    gt["gold_ablation"] = np.asarray([g["ablation"] for g in gold_tok], dtype=object)
    gt["gold_domain"] = np.asarray([g["domain"] for g in gold_tok], dtype=object)

    out_npz = os.path.join(HERE, args.tag + ".npz")
    np.savez_compressed(
        out_npz,
        meta=np.asarray([json.dumps(meta, ensure_ascii=False)], dtype=object),
        row_domain=sarr("domain"), row_query_id=arr("query_id", int), row_entry=arr("entry", int),
        row_cand_type=sarr("cand_type"), row_is_gold=arr("is_gold", int),
        row_lca=arr("lca", int), row_depth=arr("depth", int), row_train_count=arr("train_count", int),
        row_prompt=sarr("prompt"), row_ablation=sarr("ablation"),
        row_prompt_len=arr("prompt_len", int), row_logp_full=arr("logp_full"),
        row_logp_div=arr("logp_div"), row_div_idx=arr("div_idx", int),
        row_div_level=arr("div_level", int), row_n_tok=arr("n_tok", int),
        row_dropped_len=arr("dropped_len", int),
        **gt,
    )
    with open(os.path.join(HERE, args.tag + ".json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)
    with open(os.path.join(HERE, args.tag + "_out_utf8.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(LOG))
    log("wrote %s (%d rows, %d gold-token rows)" % (out_npz, len(rows), len(gold_tok)))
    os._exit(0)


if __name__ == "__main__":
    main()
