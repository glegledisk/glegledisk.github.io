# -*- coding: utf-8 -*-
"""_a3_verify_report.py — 検証報告_A3 の数値を一次データから引き直して突合する。"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a3")
ok, bad = [], []


def chk(name, got, want, tol=5e-3):
    if abs(got - want) <= tol * max(1.0, abs(want)):
        ok.append(f"  OK  {name}: {got:.6g} (report {want})")
    else:
        bad.append(f"  NG  {name}: {got:.6g} != report {want}")


rows = [r for r in json.load(open(os.path.join(D, "a3_results.json"), encoding="utf-8"))
        if "evals" in r]
an = json.load(open(os.path.join(D, "a3_analysis.json"), encoding="utf-8"))

# --- 1. 構成 ---
CONF = {"relu_1x": (557373, 16384, 1.00), "relu_15x": (688957, 24576, 1.00),
        "relu2_1x": (557373, 16384, 1.166), "relu2_15x": (688957, 24576, 1.275),
        "swiglu_1x": (689469, 24576, 1.515), "swiglu_15x": (887101, 36864, 1.550)}
for a, (p, m, g) in CONF.items():
    r = next(x for x in rows if x["arm"] == a)
    chk(f"params {a}", r["nparam"], p, tol=0)
    chk(f"MACs {a}", r["nominal_macs"], m, tol=0)
    chk(f"gain {a}", float(np.mean([x["gain"] for x in rows if x["arm"] == a])), g, tol=2e-2)

# --- 2. 到達点 ---
TAB = {"relu_15x": (0.0236, 0.590, 0.9926), "swiglu_15x": (0.2310, 0.321, 0.8942),
       "relu_1x": (0.0633, 0.272, 0.9779), "swiglu_1x": (0.1874, 0.170, 0.9161),
       "relu2_15x": (0.6588, 0.012, 0.6985), "relu2_1x": (0.4468, 0.001, 0.7976)}
for a, (ce, iv, ap) in TAB.items():
    rs = [x for x in rows if x["arm"] == a]
    chk(f"CE {a}", float(np.mean([x["evals"][-1]["ce_all"] for x in rs])), ce, tol=5e-3)
    chk(f"instr {a}", float(np.mean([x["evals"][-1]["instr_valid"] for x in rs])), iv, tol=1e-2)
    chk(f"acc_pl {a}", float(np.mean([x["evals"][-1]["acc_payload"] for x in rs])), ap, tol=5e-3)

# --- 3. 対比 ---
got = {(c["a"], c["b"], c["metric"]): c for c in an["contrasts"]}
WANT = {
    ("relu_15x", "relu_1x", "instr_valid"): (+0.318, 0.065, 5),
    ("swiglu_15x", "swiglu_1x", "instr_valid"): (+0.151, 0.388, 3),
    ("relu2_15x", "relu2_1x", "instr_valid"): (+0.012, 0.365, 2),
    ("relu2_1x", "relu_1x", "instr_valid"): (-0.271, 0.049, 0),
    ("relu2_15x", "swiglu_1x", "instr_valid"): (-0.158, 0.119, 1),
    ("relu2_15x", "relu_1x", "instr_valid"): (-0.259, 0.065, 1),
    ("relu2_1x", "relu_1x", "ce_all"): (+0.384, 0.032, 6),
    ("relu2_15x", "swiglu_1x", "ce_all"): (+0.471, 0.020, 5),
    ("relu_15x", "relu_1x", "ce_all"): (-0.040, 0.081, 1),
}
for k, (m, p, pos) in WANT.items():
    c = got.get(k)
    if c is None:
        bad.append(f"  NG  対比が無い: {k}")
        continue
    chk(f"{k[0]}-{k[1]} {k[2]} mean", c["mean"], m, tol=5e-3)
    if p >= 0.01:
        chk(f"{k[0]}-{k[1]} {k[2]} p", c["p"], p, tol=5e-2)
    chk(f"{k[0]}-{k[1]} {k[2]} pos", c["pos"], pos, tol=0)

# --- 4. 分解 ---
w = got[("relu2_15x", "relu2_1x", "instr_valid")]["mean"]
s = -got[("relu2_1x", "swiglu_1x", "instr_valid")]["mean"]   # 向きを反転して swiglu − relu2
t = got[("relu2_15x", "swiglu_1x", "instr_valid")]["mean"]
chk("分解: 幅の得", w, 0.012, tol=2e-2)
chk("分解: 3 行列との差", s, 0.170, tol=1e-2)
chk("分解: 残差", t, -0.158, tol=1e-2)
chk("分解: 残差/差", t / s, -0.93, tol=2e-2)
chk("分解: 幅で埋まる割合", w / s, 0.07, tol=1e-1)

# --- 5. 派生した主張 ---
chk("幅の効き方の比 0.318/0.012", 0.318 / 0.012, 26.5, tol=5e-2)
chk("幅への応答の差", 0.318 - 0.012, 0.306, tol=5e-3)
chk("relu_15x − swiglu_1x（等 params）", 0.590 - 0.170, 0.420, tol=5e-3)

# --- 6. パイロット（scale 0.5 / 0.25）---
for tag, want in (("_p50", (0.0203, 0.608, 0.0108, 0.779)),
                  ("_p25", (0.0446, 0.282, 0.0713, 0.123))):
    p = os.path.join(D, f"a3_results{tag}.json")
    if not os.path.exists(p):
        continue
    pr = [r for r in json.load(open(p, encoding="utf-8")) if "evals" in r]
    ce = sorted(x["evals"][-1]["ce_all"] for x in pr)
    iv = sorted(x["evals"][-1]["instr_valid"] for x in pr)
    chk(f"{tag} CE range", ce[0], min(want[0], want[2]), tol=5e-3)
    chk(f"{tag} CE range (hi)", ce[-1], max(want[0], want[2]), tol=5e-3)
    chk(f"{tag} iv range", iv[0], min(want[1], want[3]), tol=5e-3)
    chk(f"{tag} iv range (hi)", iv[-1], max(want[1], want[3]), tol=5e-3)

# --- 7. A1 の数値（帯の対比）---
a1 = json.load(open(os.path.join(HERE, "data", "a1", "a1_analysis.json"), encoding="utf-8"))
c1 = {(c["a"], c["b"], c["metric"]): c for c in a1["contrasts"]}
c = c1.get(("relu_w15", "relu", "instr_valid"))
chk("A1 の relu_w15 − relu（instr）", c["mean"], -0.081, tol=1e-2)
c = c1.get(("relu2_raw", "relu", "instr_valid"))
chk("A1 の relu2_raw − relu（instr）", c["mean"], -0.522, tol=1e-2)

print("\n".join(ok))
if bad:
    print("\n".join(bad))
    print(f"\nFAIL: {len(bad)} 件")
    sys.exit(1)
print(f"\nPASS: {len(ok)} 件すべて報告書と一致")
