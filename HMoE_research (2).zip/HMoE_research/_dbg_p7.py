import re, io
from markdown_it import MarkdownIt
MD = MarkdownIt("commonmark").enable("table")
def cnt(s):
    h = MD.render(s); b = re.sub(r"<pre>.*?</pre>","",h,flags=re.S)
    b = re.sub(r"<code>.*?</code>","",b,flags=re.S)
    return len(re.findall(r"\*\*", b))
p = "検証報告_P7_スロットは均質な単位ではない_20261028.md"
t = io.open(p, encoding="utf-8").read()
print("orig:", cnt(t))
i = t.find("**「その expert")
print("opener ctx:", repr(t[i-12:i+40]))
a = t[:i] + " " + t[i:]                      # 直前に空白
print("after C:", cnt(a))
j = a.find("か」**で")
print("closer ctx:", repr(a[j-8:j+14]))
b = a[:j+4] + " " + a[j+4:]                  # 直後に空白
print("after C+B:", cnt(b))