import re, sys
from markdown_it import MarkdownIt
MD = MarkdownIt("commonmark").enable("table")
for p in sys.argv[1:]:
    src = open(p, encoding="utf-8").read()
    html = MD.render(src)
    body = re.sub(r"<pre>.*?</pre>", "", html, flags=re.S)
    body = re.sub(r"<code>.*?</code>", "", body, flags=re.S)
    hits = [m.start() for m in re.finditer(r"\*\*", body)]
    if not hits: continue
    print(f"--- {p}  ({len(hits)})")
    for h in hits[:6]:
        print("   ", repr(body[max(0,h-45):h+45]))