#!/usr/bin/env python3
"""PC3: 生徒 HMoE の容量が「境目」に来る N を K6 の実測から逆算する。

K6 の実測: dense:107（FFN パラメータ 1.10e5, 総 381,645）で
  N=3e3（3.99e4 bit）CE 0.751 / acc 0.758  ← 境目
  N=1e4（1.33e5 bit）CE 2.067 / acc 0.262  ← ほぼ覚えられない
したがって有効容量は 4.0e4〜1.3e5 bit、FFN パラメータあたり 0.36〜1.21 bit。

この比を使って、候補の生徒が容量の境目に来る N を出す。
"""
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
BITS_PER_KEY = 13.288
D, L = 128, 4
E = 8


def ffn_params(w_sum):
    """幅の和 w_sum の HMoE（8 expert, d=128, 4 層）の FFN パラメータ数。"""
    return L * (2 * D * w_sum + w_sum + E * D)


def total_params(w_sum):
    attn = L * 4 * D * D
    router = L * (E * D + E)
    emb = 29 * D + 95 * D + 29 * D + 29
    return attn + router + emb + ffn_params(w_sum)


def main():
    lad = json.load(open(os.path.join(HERE, "k6_results_ladder.json"), encoding="utf-8"))
    rows = {r["N"]: r for r in lad["rows"]}
    ffn107 = ffn_params(107) if False else L * 2 * D * 107
    cap_lo = rows[3000]["knowledge_bits"] / ffn107
    cap_hi = rows[10000]["knowledge_bits"] / ffn107
    print("K6 dense:107  nparam %d  FFN %d" % (rows[3000]["nparam"], ffn107))
    print("容量の見積り: %.3e 〜 %.3e bit  → %.3f 〜 %.3f bit / FFN param"
          % (rows[3000]["knowledge_bits"], rows[10000]["knowledge_bits"], cap_lo, cap_hi))

    cfgs = [
        ("教師 HMoE  W=1024", 1024),
        ("生徒 0.75x  W=768", 768),
        ("生徒 0.50x  W=512", 512),
        ("生徒 0.37x  W=379", 379),
        ("dense:107（K6 と同一）", 107),
    ]
    out = {"cap_bits_lo": cap_lo * 1.0, "cap_bits_hi": cap_hi * 1.0,
           "cap_lo": cap_lo, "cap_hi": cap_hi, "rows": []}
    print("\n%-24s %9s %9s %9s   %s" % ("cfg", "FFN", "総 params", "N_edge(lo)", "N_edge(hi)"))
    for name, w in cfgs:
        f = ffn_params(w) if w > 107 else L * 2 * D * w
        tot = total_params(w) if w > 107 else rows[3000]["nparam"]
        n_lo = cap_lo * f / BITS_PER_KEY
        n_hi = cap_hi * f / BITS_PER_KEY
        print("%-24s %9d %9d %9.2e %9.2e" % (name, f, tot, n_lo, n_hi))
        out["rows"].append({"cfg": name, "w_sum": w, "ffn_params": f,
                            "total_params": tot, "n_edge_lo": n_lo, "n_edge_hi": n_hi})

    print("\n各 N での容量使用率（bit / 容量）。1.0 を超えると覚えられない側。")
    Ns = [1000, 3000, 5000, 10000, 15000, 20000, 30000, 50000]
    hdr = "%-24s" % "cfg" + "".join("%8s" % ("N=%d" % n) for n in Ns)
    print(hdr)
    util = {}
    for r in out["rows"]:
        line = "%-24s" % r["cfg"]
        vals = []
        for n in Ns:
            bits = n * BITS_PER_KEY
            u = bits / (cap_lo * r["ffn_params"])
            vals.append(u)
            line += "%8.2f" % u
        util[r["cfg"]] = vals
        print(line)
    out["util_lo"] = {"Ns": Ns, "rows": util}

    print("\nK6 の実測ラダー（校正）")
    for n in sorted(rows):
        r = rows[n]
        print("  N=%6d  bit %.3e  CE %.3f  acc %.3f" %
              (n, r["knowledge_bits"], r["ce"], r["acc"]))

    print("\n★ 0.50x の生徒が境目に来る N: %.2e 〜 %.2e"
          % (out["rows"][2]["n_edge_lo"], out["rows"][2]["n_edge_hi"]))
    print("★ 教師が境目に来る N:        %.2e 〜 %.2e"
          % (out["rows"][0]["n_edge_lo"], out["rows"][0]["n_edge_hi"]))
    print("★ 両者が同時に境目の内/外にならない帯: %.2e 〜 %.2e"
          % (out["rows"][2]["n_edge_lo"], out["rows"][0]["n_edge_lo"]))
    print("★ K6 が実際に訓練できた最大 N = 1.0e+04（N=2e4 は acc 0.10 = チャンス）")

    with open(os.path.join(HERE, "pc3_capacity.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=float)
    print("\nsaved: pc3_capacity.json")


if __name__ == "__main__":
    main()
