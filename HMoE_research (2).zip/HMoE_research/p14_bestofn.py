# -*- coding: utf-8 -*-
"""P14: best-of-N / 多数決の較正劣化予測の検証（修復可能性考察 §4-4 の予測）

問い（予測, 未検証だったもの）:
  「N 個から argmax で選ぶと p は上がる。正解率の上昇より p の上昇が大きく、
   較正ギャップが広がる（質量欠落と同型の選択バイアス）。」

測定:
  モデル Qwen3-0.6B / thinking off / 5 桁加算（P8/P9 と同一の手続・同一の 20 問）
  20 問 × 8 サンプル × 2 ラウンド（T=0.9, top_p=0.95）＋ greedy 20（対照）
  各サンプルについて「解答文字列のトークン列」を 2 回目の forward で再採点し、
  解答レベルの確信度を得る:
    p_ans  = exp(mean logprob of answer tokens)   （解答スパン＝文末の最後の数字列）
      ※ teacher forcing の行は「logits[p] が seq[p+1] を予測する」規約
        （答トークンの位置−1 の行。初回 run は 1 つずれて無効だった）
    p_full = exp(mean logprob of 生成トークン全体)  （EOS を除く、参考値）
  検査: greedy 行では出力トークン＝各 step の argmax なので lp_ans−rowmax ≈ 0
  （slack）。これが ≈0 なら位置規約と再トークン化の両方が正しい証拠。

  選択規則の検定・集計は p14_analyze.py に分離（測定と解析を別ファイルにする）。

出力: p14_bestofn.jsonl（生行）/ p14_meta.json（メタと検査）
注意: 確信度の採点は full scores を一切使わない（P8 §5-1 の (B,T,V) 2.5GB の罠を回避）。
"""

import argparse
import json
import os
import random
import re

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "qwen3-0.6b")
SYS = "You are a careful arithmetic assistant. Solve the problem and give the final answer."

NUM_RE = re.compile(r"\d[\d,]*")
VAL_RE = re.compile(r"-?\d+")


def log(m):
    print(m, flush=True)


def extract_value(txt):
    """P8/P9 と同一の判定: カンマ除去した末尾の数値を取る。"""
    nums = VAL_RE.findall(txt.replace(",", ""))
    return nums[-1] if nums else None


def answer_token_span(tok, txt):
    """文末の最後の数字列（カンマ込み）のトークン添字を offsets で特定する。"""
    matches = list(NUM_RE.finditer(txt))
    if not matches:
        return None
    ms, me = matches[-1].span()
    enc = tok(txt, add_special_tokens=False, return_offsets_mapping=True)
    ids, offs = enc["input_ids"], enc["offset_mapping"]
    idx = [j for j, (s, e) in enumerate(offs) if s < me and e > ms]
    return ids, idx


@torch.no_grad()
def score_sample(model, tok, prompt_ids, gen_text, eos_id,
                 ids_gen=None, slack=False):
    """teacher forcing 1 回で解答トークンの logprob を取る。

    位置の規約（重要）: logits[p] は seq[p+1] を予測する。答トークンが
    seq 上の位置 len(prompt)+j にあるなら、それを予測するのは row
    len(prompt)+j-1。（2026-10-29 の初回 run は +j と 1 つずれていた →
    p_ans / p_full が全行無効。）
    """
    out = {"p_ans": None, "p_full": None, "n_ans": 0, "err": "",
           "slack": None, "retok": None}
    span = answer_token_span(tok, gen_text)
    if span is None:
        out["err"] = "no_number"
        return out
    ids_ans, tok_idx = span
    if len(tok_idx) == 0:
        out["err"] = "no_overlap"
        return out
    # 再トークン化の忠実度: decode→re-encode 列が実際の生成列（特殊トークン除く）と一致するか
    if ids_gen is not None:
        specials = set(tok.all_special_ids)
        clean = [t for t in ids_gen if t not in specials]
        out["retok"] = bool(list(ids_ans) == clean)
    seq_ids = list(prompt_ids) + list(ids_ans)
    inp = torch.tensor([seq_ids], dtype=torch.long, device=model.device)
    logits = model(inp).logits[0]                       # (T, V)
    rows = torch.tensor([len(prompt_ids) + j - 1 for j in tok_idx],
                        device=model.device)
    targets = torch.tensor([ids_ans[j] for j in tok_idx], device=model.device)
    lp = torch.log_softmax(logits.index_select(0, rows).float(), dim=-1)
    lp_ans = lp.gather(1, targets.unsqueeze(1)).squeeze(1).double()   # (n_ans,)
    if slack:
        # greedy では出力トークンは各 step の argmax → lp_ans は rowmax に一致すべき
        out["slack"] = float((lp_ans - lp.max(dim=1).values.double()).abs().max())
    out["p_ans"] = float(torch.exp(lp_ans.mean()).item())
    out["n_ans"] = lp_ans.shape[0]

    # 参考: 生成トークン全体（EOS を除く）の平均 logprob
    n_gen = len(ids_ans)
    keep = [j for j in range(n_gen) if ids_ans[j] != eos_id]
    if keep:
        try:
            rows_all = torch.arange(len(prompt_ids) - 1,
                                    len(prompt_ids) - 1 + n_gen, device=model.device)
            rows_all = rows_all[torch.tensor(keep, device=model.device)]
            tgt_all = torch.tensor([ids_ans[j] for j in keep], device=model.device)
            lp_all = torch.log_softmax(
                logits.index_select(0, rows_all).float(), dim=-1)
            lp_all = lp_all.gather(1, tgt_all.unsqueeze(1)).squeeze(1).double()
            out["p_full"] = float(torch.exp(lp_all.mean()).item())
        except Exception as e:                      # noqa: BLE001
            out["err"] = "p_full:" + str(e)[:100]
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_prob", type=int, default=20)
    ap.add_argument("--n_samp", type=int, default=8)
    ap.add_argument("--bs", type=int, default=8)
    ap.add_argument("--rounds", type=int, default=2)
    ap.add_argument("--seed", type=int, default=31)      # P9 と同じ問題列になる
    ap.add_argument("--tag", type=str, default="p14")
    ap.add_argument("--skip_greedy", action="store_true")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer

    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    eos_id = tok.eos_token_id
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, torch_dtype=torch.bfloat16, device_map="cuda",
        attn_implementation="sdpa").eval()

    # ---- 問題列（P9 と同一手続・同一 seed → 同一 20 問になることを assert）----
    rnd = random.Random(args.seed)
    probs = []
    for _ in range(args.n_prob):
        a, b = rnd.randint(10001, 99999), rnd.randint(10001, 99999)
        probs.append({"q": "Compute %d + %d." % (a, b), "gold": str(a + b)})
    p9_path = os.path.join(HERE, "p9_count.jsonl")
    if os.path.exists(p9_path):
        with open(p9_path, encoding="utf-8") as fp:
            p9_qs = [json.loads(l)["q"] for l in fp if l.strip()]
        assert p9_qs[:args.n_prob] == [p["q"] for p in probs], \
            "problem list diverges from p9_count.jsonl"
        log("problem list matches p9_count.jsonl (%d problems)" % len(p9_qs))

    prompts = []
    for p in probs:
        msgs = [{"role": "system", "content": SYS}, {"role": "user", "content": p["q"]}]
        prompts.append(tok.apply_chat_template(msgs, tokenize=False,
                                               add_generation_prompt=True,
                                               enable_thinking=False))
    prompt_ids = [tok(pr, add_special_tokens=False)["input_ids"] for pr in prompts]

    # ---- 生成（ラウンドごとに torch seed を替える。問題は同一）----
    recs, rej = [], {"no_number": 0, "score_err": 0}
    for r_i in range(args.rounds):
        torch.manual_seed(args.seed + 100 + r_i)
        for i, p in enumerate(probs):
            enc = tok([prompts[i]] * args.n_samp, return_tensors="pt",
                      padding=True, add_special_tokens=False).to(model.device)
            with torch.no_grad():
                o = model.generate(**enc, max_new_tokens=96, do_sample=True,
                                   temperature=0.9, top_p=0.95,
                                   pad_token_id=tok.pad_token_id)
            gen = o[:, enc["input_ids"].shape[1]:]
            samples = []
            for j in range(args.n_samp):
                ids = gen[j].tolist()
                # 末尾の pad を落とす
                ids = [t for t in ids if t != tok.pad_token_id]
                txt = tok.decode(ids, skip_special_tokens=True)
                sc = {"p_ans": None, "p_full": None, "n_ans": 0, "err": ""}
                try:
                    sc = score_sample(model, tok, prompt_ids[i], txt, eos_id,
                                      ids_gen=ids)
                except Exception as e:                      # noqa: BLE001
                    sc = {"p_ans": None, "p_full": None, "n_ans": 0, "err": str(e)[:120]}
                pred = extract_value(txt)
                if sc["p_ans"] is not None and pred is not None:
                    correct = (pred == p["gold"])
                else:
                    correct = None
                    rej["no_number" if pred is None else "score_err"] += 1
                samples.append({"pred": pred, "correct": correct,
                                "p_ans": sc["p_ans"], "p_full": sc["p_full"],
                                "n_ans": sc["n_ans"], "err": sc["err"],
                                "retok": sc["retok"],
                                "ntok": len(ids), "tail": txt.strip()[-60:]})
            recs.append({"round": r_i, "q": p["q"], "gold": p["gold"],
                         "samples": samples})
        log("round %d generated+scored" % r_i)

    # ---- greedy 対照（決定的 1 回）----
    greedy = []
    torch.manual_seed(args.seed + 999)
    for i, p in enumerate(probs if not args.skip_greedy else []):
        enc = tok(prompts[i], return_tensors="pt",
                  add_special_tokens=False).to(model.device)
        with torch.no_grad():
            o = model.generate(**enc, max_new_tokens=96, do_sample=False,
                               pad_token_id=tok.pad_token_id)
        ids = o[0, enc["input_ids"].shape[1]:].tolist()
        txt = tok.decode(ids, skip_special_tokens=True)
        sc = {"p_ans": None, "p_full": None, "n_ans": 0, "err": ""}
        try:
            sc = score_sample(model, tok, prompt_ids[i], txt, eos_id,
                              ids_gen=ids, slack=True)
        except Exception as e:                          # noqa: BLE001
            sc = {"p_ans": None, "p_full": None, "n_ans": 0, "err": str(e)[:120]}
        pred = extract_value(txt)
        greedy.append({"q": p["q"], "gold": p["gold"], "pred": pred,
                       "correct": None if (sc["p_ans"] is None or pred is None)
                       else (pred == p["gold"]),
                       "p_ans": sc["p_ans"], "p_full": sc["p_full"],
                       "n_ans": sc["n_ans"], "err": sc["err"], "ntok": len(ids),
                       "slack": sc["slack"], "retok": sc["retok"],
                       "tail": txt.strip()[-60:]})
    log("greedy arm done" if greedy else "greedy arm skipped")

    # ---- 検査: greedy の argmax-slack（≈0 が採点位置の正しさの証拠）----
    slacks = [g["slack"] for g in greedy if g.get("slack") is not None]
    if slacks:
        log("greedy argmax-slack: mean=%.6f max=%.6f (n=%d, ≈0 が正しい規約の証拠)"
            % (float(np.mean(slacks)), float(np.max(slacks)), len(slacks)))
        if np.mean(slacks) > 0.02:
            log("WARN: slack が大きい — 採点位置の規約を疑え")

    # ---- 検査と保存 ----
    n_retok_bad = (sum(1 for r in recs for s in r["samples"] if s.get("retok") is False)
                   + sum(1 for g in greedy if g.get("retok") is False))
    meta = {"n_prob": len(probs), "n_samp": args.n_samp, "rounds": args.rounds,
            "seed": args.seed, "temperature": 0.9, "top_p": 0.95,
            "rejected": rej,
            "n_recs": len(recs), "n_samples": len(recs) * args.n_samp,
            "n_greedy": len(greedy),
            "n_ans_scored": sum(1 for r in recs for s in r["samples"] if s["p_ans"] is not None),
            "n_retok_mismatch": n_retok_bad,
            "conf_def": "p_ans = exp(mean logprob of answer-token span = last number run in text), scored at row position-1",
            "scoring_note": "off-by-one of 2026-10-29 first run fixed: rows = len(prompt)+j-1",
            "model": MODEL}
    path_jl = os.path.join(HERE, "%s_bestofn.jsonl" % args.tag)
    with open(path_jl, "w", encoding="utf-8") as fp:
        for r in recs:
            fp.write(json.dumps(r, ensure_ascii=False) + "\n")
        for g in greedy:
            fp.write(json.dumps({"round": "greedy", **g}, ensure_ascii=False) + "\n")
    with open(os.path.join(HERE, "%s_meta.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(meta, fp, ensure_ascii=False, indent=2)
    log(json.dumps(meta, ensure_ascii=False))
    log("saved: %s_bestofn.jsonl / %s_meta.json" % (args.tag, args.tag))
    os._exit(0)


if __name__ == "__main__":
    main()
