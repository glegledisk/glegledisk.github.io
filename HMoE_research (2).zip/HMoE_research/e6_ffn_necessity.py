# -*- coding: utf-8 -*-
"""e6_ffn_necessity.py — E6 で FFN が本質的に必要になるかを検定する

問い: ランダムな 4096 エントリのルックアップ表を記憶させると、
      d=64 でも FFN が必須になるか。

  判定基準（60 epoch、4 seeds）:
    ΔCE = CE(frozen_identity) − CE(frozen_ffn)
      > 0.30  → FFN が本質的に必要。E6 は有効なテストベッド。
      0.05〜0.30 → 部分的に必要。容量との兼ね合い。
      < 0.05  → Attention で代替できる。E6 も失敗。

  参照:
    E5 (a+b) mod A : d=16 で 0.2616 / d=64 で 0.0280
    E4 copy 課題    : d=64 で 0.008
"""
import os, json, time
import numpy as np
import pandas as pd
from e6_memory_task import run, make_lookup_table
from e5_dependency_task import ROLE_NAME

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=64, lag=3, anchor_vals=tuple(range(8)), d=64)
ARMS = ["frozen_ffn", "frozen_identity"]
SEEDS = [0, 1, 2, 3]
OUT = os.path.join(HERE, "e6_ffn_necessity.csv")
tab = make_lookup_table(64)

rows = []
if os.path.exists(OUT):
    rows = pd.read_csv(OUT).to_dict("records")
have = {(r["arm"], int(r["seed"])) for r in rows}

t0 = time.time()
for arm in ARMS:
    for s in SEEDS:
        if (arm, s) in have:
            continue
        r = run(arm, s, table=tab, **CFG)
        r["arm"] = arm
        rows.append(r)
        pd.DataFrame(rows).to_csv(OUT, index=False)
        print(f"  {arm:16s} s{s} | CE {r['ce_all']:.4f} | acc {r['acc_all']:.4f} "
              f"(copy {r['acc_copy']:.3f} / anchor {r['acc_anchor']:.3f} / dep {r['acc_dep']:.3f}) "
              f"| FFN {r['ffn_cost']:.3f} | {time.time()-t0:.0f}s", flush=True)

df = pd.DataFrame(rows)
print("\n=== E6 (A=64, ランダム 4096 表), d=64, 60 epoch ===")
for a in ARMS:
    d = df[df.arm == a]
    print(f" {a:16s} n={len(d)}  CE {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"acc {d['acc_all'].mean():.4f}  anchor {d['acc_anchor'].mean():.4f}")

piv = df.pivot_table(index="seed", columns="arm", values="ce_all")
if {"frozen_ffn", "frozen_identity"}.issubset(piv.columns):
    diff = (piv["frozen_identity"] - piv["frozen_ffn"]).dropna()
    print(f"\n FFN の寄与 ΔCE = {diff.mean():+.4f} ± {diff.std(ddof=1):.4f} "
          f"(n={len(diff)}, 各 seed: {[round(x,4) for x in diff.values]})")
    print("\n === 比較 ===")
    print("  E5 (a+b) mod A : d=16 で 0.2616 / d=64 で 0.0280")
    print("  E4 copy 課題    : d=64 で 0.008")
    print(f"  E6 (ランダム表) : d=64 で {diff.mean():+.4f}  ← 本測定")
    json.dump({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in CFG.items()},
               "dce_mean": float(diff.mean()), "dce_sd": float(diff.std(ddof=1)),
               "n": int(len(diff)),
               "ce_ffn": float(piv["frozen_ffn"].mean()),
               "ce_id": float(piv["frozen_identity"].mean()),
               "acc_anchor_ffn": float(df[df.arm == "frozen_ffn"]["acc_anchor"].mean()),
               "acc_anchor_id": float(df[df.arm == "frozen_identity"]["acc_anchor"].mean()),
               "raw": rows},
              open(os.path.join(HERE, "e6_ffn_necessity.json"), "w", encoding="utf-8"),
              indent=2, ensure_ascii=False)
print("\nsaved e6_ffn_necessity.csv / .json")
