#!/usr/bin/env python3
"""A1 の検算と集計。

`a1_activation_ffn.py` が出した json を**読むだけ**だが、CE は `ce_*.npy` から
独立に再計算して json の値と突合する（AGENTS.md Step 4）。t・p・符号も再計算する。

主指標を 2 本立てにする
  CE_all   : 連続で敏感。ただし**裾に支配される**（relu2 の 1 seed が 1.14）。
  instr_valid : 有界（0-1）。裾の影響を受けない。P5a/P6 系の「二次で有界な損失」側。

判定の枠組み（走らせる前に決めた）
  形が効くか   : relu / silu / relu2 は **params も幅も完全に同一**（2 行列・幅 1.0）。
                 drelu vs swiglu は **3 行列・等パラメータ・ほぼ等 gain**。
  幅が効くか   : relu_w15 − relu（増やす）/ relu_w067 − relu（削る）の**両方向**。
  gain 交絡    : silu_raw / swiglu_raw（gain=1）と matched 版を比べる。
  主評価点     : 固定予算の**最終 epoch**。途中 epoch は軌跡として併記（選択に使わない）。
"""
import argparse
import json
import math
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a1")

ORDER = ["relu", "silu", "silu_raw", "relu2", "relu2_raw",
         "swiglu", "swiglu_raw", "drelu", "relu_w15", "relu_w067", "relu2_w15"]


def load():
    rows = []
    for fn in ("a1_results.json", "a1_results_b.json"):
        p = os.path.join(D, fn)
        if not os.path.exists(p):
            continue
        with open(p, encoding="utf-8") as fh:
            for r in json.load(fh):
                if "evals" not in r:
                    continue
                tag = "_b" if fn.endswith("_b.json") else ""
                r["_ce"] = np.load(os.path.join(D, f"ce_{tag}{r['arm']}_s{r['seed']}.npy"))
                rows.append(r)
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", default="a1_analysis.json")
    args = ap.parse_args()

    rows = load()
    arms = [a for a in ORDER if any(r["arm"] == a for r in rows)]
    E = rows[0]["_ce"].shape[0]

    print("=== 1. 再計算の突合（npy から CE を引き直す）===")
    bad = [(r["arm"], r["seed"], k) for r in rows for k in range(E)
           if abs(float(r["_ce"][k].mean()) - r["evals"][k]["ce_all"]) > 1e-6]
    if bad:
        print("  NG:", bad[:5])
    else:
        print(f"  OK  {len(rows)} 本 × {E} epoch すべて json と npy が一致（|Δ| < 1e-6）")
    print("  n per arm:", {a: sum(1 for r in rows if r["arm"] == a) for a in arms})

    def vals(a, k, m):
        rs = [r for r in rows if r["arm"] == a]
        if m == "ce":
            return np.array([float(r["_ce"][k].mean()) for r in rs])
        return np.array([r["evals"][k][m] for r in rs])

    def paired(a, b, k, m):
        da = {r["seed"]: (float(r["_ce"][k].mean()) if m == "ce" else r["evals"][k][m])
              for r in rows if r["arm"] == a}
        db = {r["seed"]: (float(r["_ce"][k].mean()) if m == "ce" else r["evals"][k][m])
              for r in rows if r["arm"] == b}
        ks = sorted(set(da) & set(db))
        if len(ks) < 3:
            return None
        x = np.array([da[i] for i in ks])
        y = np.array([db[i] for i in ks])
        d = x - y
        n = len(d)
        se = d.std(ddof=1) / math.sqrt(n)
        t, p = stats.ttest_rel(x, y)
        ci = stats.t.ppf(0.975, n - 1) * se
        mde = (stats.t.ppf(0.975, n - 1) + stats.t.ppf(0.80, n - 1)) * se
        return dict(a=a, b=b, metric=m, ep=k + 1, n=n, mean=float(d.mean()), se=float(se),
                    t=float(t), p=float(p), ci_lo=float(d.mean() - ci),
                    ci_hi=float(d.mean() + ci), pos=int((d > 0).sum()), mde=float(mde),
                    dz=float(d.mean() / d.std(ddof=1)) if d.std(ddof=1) > 0 else float("nan"),
                    per_seed=d.round(5).tolist())

    print("\n=== 2. 学習の軌跡（CE_all 平均 / instr_valid）===")
    print("  " + f"{'arm':11s}" + "".join(f"{f'CE ep{k+1}':>10s}" for k in range(E))
          + f"{'iv ep%d' % E:>9s}{'dead':>7s}{'params':>11s}{'MACs':>8s}{'gain':>6s}")
    for a in arms:
        rs = [r for r in rows if r["arm"] == a]
        cells = "".join(f"{vals(a, k, 'ce').mean():>10.4f}" for k in range(E))
        print(f"  {a:11s}{cells}{vals(a, E - 1, 'instr_valid').mean():>9.3f}"
              f"{np.mean([np.mean(list(r['dead_by_expert'].values())) for r in rs]):>7.3f}"
              f"{rs[0]['nparam']:>11,}{rs[0]['nominal_macs']:>8.0f}"
              f"{np.mean([r['gain'] for r in rs]):>6.2f}")

    base = vals("relu", E - 1, "ce").mean()
    print(f"\n  飽和チェック: relu の最終 CE = {base:.5f} "
          f"({'飽和' if base < 0.01 else '未飽和（差を測れる）'})")
    print("  裾チェック（最終 epoch の CE, seed 別）:")
    for a in arms:
        v = vals(a, E - 1, "ce")
        print(f"    {a:11s} 中央値={np.median(v):.4f} 最大={v.max():.4f} "
              f"最大/中央値={v.max()/max(np.median(v),1e-9):.1f}")

    contrasts = [
        ("silu", "relu", "形：SiLU vs ReLU（2 行列・等 params・等幅）"),
        ("relu2", "relu", "形：ReLU² vs ReLU（同上）"),
        ("relu2_raw", "relu", "形：ReLU² vs ReLU（どちらも gain=1）"),
        ("drelu", "swiglu", "形：ReLU ゲート vs SiLU ゲート（3 行列・等 params）"),
        ("silu_raw", "relu", "gain 交絡の確認：SiLU raw vs ReLU"),
        ("swiglu_raw", "relu", "gain 交絡の確認：SwiGLU raw vs ReLU"),
        ("swiglu", "relu", "行列数：SwiGLU vs ReLU（等幅・params 1.5 倍）"),
        ("relu_w15", "relu", "幅 +1.5 倍（形は同じ・params 1.5 倍）"),
        ("relu_w067", "relu", "幅 ×2/3（形は同じ・params 0.67 倍）"),
        ("relu2_w15", "swiglu", "幅 vs 行列数（等 params・等 MACs）"),
        ("relu_w067", "relu_w15", "幅の両端（0.67 倍 vs 1.5 倍）"),
        ("silu_raw", "relu_w067", "最良の形 vs 最良の幅"),
    ]
    res = []
    print("\n=== 3. 対応差（seed で対応、a − b）— 最終 epoch ===")
    for a, b, lab in contrasts:
        if a not in arms or b not in arms:
            continue
        print(f"  [{lab}]")
        for m in ("ce", "instr_valid"):
            c = paired(a, b, E - 1, m)
            if not c:
                continue
            c["label"] = lab
            res.append(c)
            star = " *" if c["p"] < 0.05 else "  "
            print(f"    {a:11s}− {b:11s} [{m:11s}] Δ={c['mean']:+.4f} se={c['se']:.4f} "
                  f"t={c['t']:+.2f} p={c['p']:.4f}{star} {c['pos']}/{c['n']} "
                  f"CI[{c['ci_lo']:+.4f},{c['ci_hi']:+.4f}] MDE={c['mde']:.4f}")

    print("\n=== 4. epoch ごとの軌跡（instr_valid, a − b）===")
    for a, b, lab in contrasts[:6]:
        if a not in arms or b not in arms:
            continue
        cells = []
        for k in range(E):
            c = paired(a, b, k, "instr_valid")
            cells.append(f"{c['mean']:+.3f}(p={c['p']:.2f})" if c else "—")
        print(f"  {a:11s}− {b:11s} " + "  ".join(cells) + f"   {lab}")

    agg = {}
    for a in arms:
        rs = [r for r in rows if r["arm"] == a]
        v = vals(a, E - 1, "ce")
        iv = vals(a, E - 1, "instr_valid")
        agg[a] = dict(n=len(rs), ce=float(v.mean()), ce_sd=float(v.std(ddof=1)),
                      ce_median=float(np.median(v)), ce_max=float(v.max()),
                      iv=float(iv.mean()), iv_sd=float(iv.std(ddof=1)),
                      ce_by_ep=[float(vals(a, k, "ce").mean()) for k in range(E)],
                      iv_by_ep=[float(vals(a, k, "instr_valid").mean()) for k in range(E)],
                      pl=float(np.mean([r["evals"][-1]["ce_payload"] for r in rs])),
                      dead=float(np.mean([np.mean(list(r["dead_by_expert"].values()))
                                          for r in rs])),
                      nparam=rs[0]["nparam"], macs=rs[0]["nominal_macs"],
                      gain=float(np.mean([r["gain"] for r in rs])),
                      rms_raw=float(np.mean([r["rms_init_raw"] for r in rs])))
    out = {"aggregate": agg, "contrasts": res, "epochs": E,
           "saturated": bool(base < 0.01), "n_runs": len(rows)}
    with open(os.path.join(D, args.json), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(f"\n[write] {os.path.join(D, args.json)}")


if __name__ == "__main__":
    main()
