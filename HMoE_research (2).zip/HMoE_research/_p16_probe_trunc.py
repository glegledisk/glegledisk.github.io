# -*- coding: utf-8 -*-
"""P16 補助: 打ち切られたのに正解のサンプルは何をしているか（使い捨て）"""
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
rows = [json.loads(l) for l in open(os.path.join(HERE, "p16_difficulty.jsonl"),
                                    encoding="utf-8") if l.strip()]
recs = [r for r in rows if r.get("round") != "greedy"]

for lv in ["add5", "sub5", "mul2"]:
    S = [s for r in recs if r["level"] == lv for s in r["samples"]]
    tr = [s for s in S if s["ntok"] >= 96]
    ok = [s for s in tr if s["correct"]]
    bad = [s for s in tr if not s["correct"]]
    print("=== %s === truncated=%d correct=%d (%.3f)" % (lv, len(tr), len(ok), len(ok) / len(tr)))
    print("  n_ans: correct mean=%.2f / wrong mean=%.2f"
          % (np.mean([s["n_ans"] for s in ok]) if ok else float("nan"),
             np.mean([s["n_ans"] for s in bad]) if bad else float("nan")))
    for tag, lst in [("OK", ok), ("NG", bad)]:
        for s in lst[:3]:
            print("  %s n_ans=%d | %s" % (tag, s["n_ans"], s["tail"].replace("\n", " ")[-58:]))
    print("")
