# -*- coding: utf-8 -*-
"""使い捨て: AX3 コーパスの形状と語彙 ID 範囲を確認する（次の一手の精査用）。"""
import numpy as np

z = np.load("corpus_ids_ax3_w24_l256.npz")
print("keys:", list(z.files))
for k in z.files:
    a = z[k]
    if np.issubdtype(a.dtype, np.integer):
        print(k, a.shape, a.dtype, "min", int(a.min()), "max", int(a.max()))
    else:
        print(k, a.shape, a.dtype)
