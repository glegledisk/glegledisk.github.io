# -*- coding: utf-8 -*-
import re
from markdown_it import MarkdownIt

path = "不均一MoE-Corpus/C1課題設計書_Corpus3検定とコーパス選定_20261105.md"
with open(path, encoding="utf-8") as fh:
    src = fh.read()
html = MarkdownIt("commonmark").enable("table").render(src)
body = re.sub(r"<pre>.*?</pre>", "", html, flags=re.S)
body = re.sub(r"<code>.*?</code>", "<code>X</code>", body, flags=re.S)

out = []
for m in re.finditer(r"[\u3040-\u30ff\u4e00-\u9fff]\s+[\u3040-\u30ff\u4e00-\u9fff]", body):
    out.append(repr(body[max(0, m.start() - 90):m.end() + 90].replace("\n", " ")))

with open("_corpus_md_probe_out.txt", "w", encoding="utf-8") as fh:
    fh.write("\n".join(out) + "\n")
print("done", len(out))
