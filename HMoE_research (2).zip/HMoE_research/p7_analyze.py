# -*- coding: utf-8 -*-
"""P7 解析: スロット粒度と凸性比 ρ（予算別の判定）

入力: p7_granularity.npz（8 条件） + p7b_granularity.npz（base + 5 条件）
出力: p7_analysis.json / p7_analysis_out_utf8.txt

判定の構造:
  「層方向の不均一が報われるか」は予算ごとに別の問いである。
  予算 B（= 1 層あたり平均 m スロット）で、前重み (m+δ, m−δ) が
  均一 (m, m) に勝つ条件は

      C_f(m+δ) − C_f(m)  <  C_b(m) − C_b(m−δ)

  左 = 前半に δ を足す限界コスト、右 = 後半から δ を抜いて得する限界コスト。
  P3b の 1+ρ 条件は δ=1・m=1 の場合の特殊形にすぎない。

  予算 8  (m=0.5): (1,0) vs (0.5,0.5)   -> u05 vs f1
  予算 16 (m=1.0): (1.5,0.5) vs (1,1)   -> u1 vs h15f
                   (2,0)     vs (1,1)   -> u1 vs f2     ← P3b の f6b8 の再測
"""

import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TAGS = ["p7", "p7b"]


def paired(a, b):
    d = np.asarray(a, np.float64) - np.asarray(b, np.float64)
    n = d.size
    m = float(d.mean())
    sd = float(d.std(ddof=1))
    se = sd / np.sqrt(n)
    return {"mean": m, "se": se, "sd": sd, "n": int(n),
            "t": m / se if se > 0 else float("nan"),
            "ci95": [m - 1.96 * se, m + 1.96 * se],
            "mde80": 2.8 * se}


def fmt(d):
    return "%+.5f (se %.5f, t %+.2f)" % (d["mean"], d["se"], d["t"])


def load_merged():
    nll, acc, mass, base_nll, lang = {}, {}, {}, None, None
    for tag in TAGS:
        path = os.path.join(HERE, "%s_granularity.npz" % tag)
        if not os.path.exists(path):
            continue
        z = np.load(path, allow_pickle=True)
        if lang is None:
            lang = z["lang"]
        for k in z.files:
            if k.startswith("nll_"):
                c = k[4:]
                if c in nll:
                    continue
                nll[c] = z[k]
                acc[c] = z["acc1_%s" % c]
                mass[c] = z["mass_%s" % c]
        if "base" in nll:
            if base_nll is None:
                base_nll = nll["base"]
            else:
                # 決定性の検算: 別プロセスの base がビット一致するか
                assert np.array_equal(base_nll, nll["base"]), "base mismatch between runs"
    return nll, acc, mass, lang


def main():
    nll, acc, mass, lang = load_merged()
    n = nll["base"].size
    per_win = n // lang.size
    assert per_win * lang.size == n
    tok_lang = np.repeat(lang, per_win)
    base = nll["base"]

    lines = []
    def emit(s=""):
        lines.append(s)
        print(s, flush=True)

    emit("=== P7 粒度と凸性 (n=%d tokens, %d windows, 条件 %d)" % (n, lang.size, len(nll)))
    emit("")

    # ---------- 0. 水準 ----------
    emit("[0] 水準（base との対応差, n=%d）" % n)
    emit("%-6s %10s %11s %9s %8s %8s %8s" % ("cond", "CE", "dCE", "se", "t", "top1", "mass"))
    out = {"n_tokens": int(n), "n_windows": int(lang.size), "levels": {}}
    for c in ["base", "u05", "f05", "b05", "u1", "f1", "b1", "h15f", "f15", "b15", "u15", "f2", "b2"]:
        if c not in nll:
            continue
        d = paired(nll[c], base)
        emit("%-6s %10.5f %+11.5f %9.5f %+8.2f %8.4f %8.4f" % (
            c, nll[c].mean(), d["mean"], d["se"], d["t"], acc[c].mean(), mass[c].mean()))
        out["levels"][c] = {"ce": float(nll[c].mean()), "delta": d,
                            "top1": float(acc[c].mean()),
                            "mass": float(mass[c].mean())}
    emit("")

    # ---------- 1. 曲線 ----------
    emit("[1] 曲線 C_h(m) = 層あたり m スロット削ったときの ΔCE（×8 層）")
    emit("%-3s %10s %10s %10s %10s %10s" % ("half", "m=0.5", "m=1.0", "m=1.5", "m=2.0", "限界/0.5"))
    curve = {}
    for h, keys in (("f", ["f05", "f1", "f15", "f2"]), ("b", ["b05", "b1", "b15", "b2"])):
        vals = []
        for k in keys:
            vals.append(float((nll[k] - base).mean()) if k in nll else float("nan"))
        curve[h] = vals
        marg = []
        prev = 0.0
        for v in vals:
            marg.append((v - prev) / 0.5)   # 1 スロットあたりに換算
            prev = v
        emit("%-3s %10.5f %10.5f %10.5f %10.5f   %s"
             % (h, vals[0], vals[1], vals[2], vals[3],
                " ".join("%.5f" % x for x in marg)))
        out.setdefault("curve", {})[h] = {
            "m": [0.5, 1.0, 1.5, 2.0], "C": vals, "marginal_per_slot": marg}
    emit("   （限界は「その 0.5 スロット区間を 1 スロットあたりに換算」した値）")
    emit("")

    # ---------- 2. 予算別の判定 ----------
    emit("[2] 予算別「前重み vs 均一」")
    out["budget_tests"] = {}

    def test(name, front_cond, uni_cond, note=""):
        if front_cond not in nll or uni_cond not in nll:
            return
        d = paired(nll[front_cond], nll[uni_cond])
        verdict = ("前重みが勝ち" if d["mean"] < 0 else "前重みが負け")
        sig = "有意" if abs(d["t"]) > 2 else "n.s."
        emit("    予算 %-2s %-22s ΔCE %s  → %s (%s) %s"
             % (name, "%s − %s" % (front_cond, uni_cond), fmt(d), verdict, sig, note))
        out["budget_tests"]["%s:%s_vs_%s" % (name, front_cond, uni_cond)] = {
            "delta": d, "front_wins": bool(d["mean"] < 0),
            "significant": bool(abs(d["t"]) > 2), "note": note}

    test("8", "f1", "u05", "(1,0) vs (0.5,0.5)")
    test("16", "h15f", "u1", "(1.5,0.5) vs (1,1)  ← 半スロット")
    test("16", "f2", "u1", "(2,0) vs (1,1)  ← P3b の f6b8 の再測（全スロット）")
    emit("")

    # ---------- 3. 限界費用の比 κ ----------
    emit("[3] 限界費用の比 κ = (後半を δ 抜いて得する分) / (前半に δ 足す分)")
    emit("    κ > 1 なら前重みが勝つ。δ=0.5。")
    ks = {}
    for m, i_hi in ((0.5, 1), (1.0, 2)):
        # 前重み (m+0.5, m-0.5) vs 均一 (m, m)
        cf_add = curve["f"][i_hi] - curve["f"][i_hi - 1]
        cb_save = curve["b"][i_hi - 1] - (curve["b"][i_hi - 2] if i_hi >= 2 else 0.0)
        k = cb_save / cf_add if cf_add else float("inf")
        ks[m] = {"cf_add": cf_add, "cb_save": cb_save, "kappa": k}
        emit("    m=%.1f: 前半に 0.5 足す +%.5f / 後半から 0.5 抜く −%.5f  → κ=%.2f %s"
             % (m, cf_add, cb_save, k, "（前重み勝ち）" if k > 1 else "（均一勝ち）"))
    out["kappa"] = {str(k): v for k, v in ks.items()}
    emit("")

    # ---------- 4. 曲率 ----------
    emit("[4] 曲率: C(1) − 2C(0.5)（0 なら線形、正なら凸）と C(0.5)/(C(1)/2)")
    out["curvature"] = {}
    for h in ("f", "b"):
        q = (nll["%s1" % h] - base) - 2.0 * (nll["%s05" % h] - base)
        d = paired(q, np.zeros_like(q))
        lin = curve[h][0] / (0.5 * curve[h][1])
        emit("    %s: 二次差分 %s   線形比 %.3f" % (h, fmt(d), lin))
        out["curvature"][h] = {"second_diff": d, "linearity": float(lin)}
    emit("")

    # ---------- 4b. 非単調性（限界費用が下がる区間があるか）----------
    emit("[4b] 限界費用の非単調性: C(1.5) − 2C(1) + C(0.5)（負なら限界が下降＝凹）")
    out["nonmonotone"] = {}
    for h in ("f", "b"):
        c05, c1, c15 = nll["%s05" % h], nll["%s1" % h], nll["%s15" % h]
        q = (c15 - base) - 2.0 * (c1 - base) + (c05 - base)
        d = paired(q, np.zeros_like(q))
        emit("    %s: 二次差分 %s  → %s" % (h, fmt(d),
                                          "限界が下降（凹）" if d["mean"] < 0 else "限界が上昇（凸）"))
        out["nonmonotone"][h] = d
    emit("    注: 各区間の限界は差の差なので SE が大きく、点推定の非単調は有意でない可能性がある")
    emit("")

    # ---------- 5. 加法性 ----------
    emit("[5] 加法性（前後分割が独立に足せるか）")
    out["additivity"] = {}
    for lab, comb, parts in (
            ("m=0.5", "u05", ["f05", "b05"]),
            ("m=1.0", "u1", ["f1", "b1"]),
            ("m=1.5", "u15", ["f15", "b15"])):
        if comb not in nll or any(p not in nll for p in parts):
            continue
        resid = nll[comb] - (nll[parts[0]] + nll[parts[1]] - base)
        d = paired(resid, np.zeros_like(resid))
        emit("    %-5s 残差 %s  → %s" % (lab, fmt(d), "加法" if abs(d["t"]) < 2 else "非加法"))
        out["additivity"][lab] = d
    emit("")

    # ---------- 6. 言語別 ----------
    emit("[6] 言語別（予算 16 の 2 比較）")
    out["per_lang"] = {}
    for lab, a, b in (("h15f−u1", "h15f", "u1"), ("f2−u1", "f2", "u1")):
        if a not in nll or b not in nll:
            continue
        for lg in ("en", "ja"):
            sel = (tok_lang == lg)
            d = paired(nll[a][sel], nll[b][sel])
            emit("    %-9s %s: %s" % (lab, lg, fmt(d)))
            out["per_lang"]["%s:%s" % (lab, lg)] = d
    emit("")

    # ---------- 7. 検算 ----------
    emit("[7] 検算")
    emit("    base CE = %.5f（P6c の 2.68932）" % base.mean())
    emit("    u1 ΔCE = %+.5f（P6c の k=7 +0.01497。α=0 と top_k=7 は経路が違う）"
         % (nll["u1"] - base).mean())
    if "f1" in nll and "b1" in nll:
        asym = (nll["b1"] - base).mean() / (nll["f1"] - base).mean()
        emit("    後半/前半 の非対称性 = %.3f（P3b は 1.66）" % asym)
        out["calibration"] = {"base_ce": float(base.mean()),
                              "u1_dce": float((nll["u1"] - base).mean()),
                              "asymmetry": float(asym)}

    with open(os.path.join(HERE, "p7_analysis.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2, default=float)
    with open(os.path.join(HERE, "p7_analysis_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(lines) + "\n")
    print("")
    print("saved: p7_analysis.json / p7_analysis_out_utf8.txt")


if __name__ == "__main__":
    main()
