#!/usr/bin/env python3
"""A7: 「中間を厚くした」別の幅ベクトルで A6 の k=4 効果が再現するか。

背景: A6 の幅ベクトル (32,32,96,96,160,160,224,224) では **幅の順位と使用率の順位が一致**していて、
「幅が広い」と「使われていない」を分離できない。ここでは中間を厚くした
W_MID = (32,32,192,192,192,192,96,96) で同じ操作（幅の広い 4 個を ReLU²）を繰り返す。

分離できるか / 再現するかを別々に見る
  (a) 分離: W_MID でも w×share が一定なら、**使用率は 1/幅 に機械的に従う**ので
      どんな単調ベクトルでも分離できない（＝交絡は構造的）
  (b) 再現: mid_wide4 − mid_base が BASE_W の +0.202 と同じ向き・大きさなら、
      効果は「特定の expert の組」ではなく「幅の広い（＝使われない）群」に属する
"""
import argparse
import json
import math
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a4")


def load(fn):
    p = os.path.join(D, fn)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8") as fh:
        return [r for r in json.load(fh) if "evals" in r]


def paired(rows, a, b, key, ep=-1):
    da = {r["seed"]: r["evals"][ep][key] for r in rows if r["arm"] == a}
    db = {r["seed"]: r["evals"][ep][key] for r in rows if r["arm"] == b}
    ks = sorted(set(da) & set(db))
    if len(ks) < 3:
        return None
    x = np.array([da[i] for i in ks])
    y = np.array([db[i] for i in ks])
    d = x - y
    se = d.std(ddof=1) / math.sqrt(len(d))
    t, p = stats.ttest_rel(x, y)
    mde = (stats.t.ppf(0.975, len(d) - 1) + stats.t.ppf(0.80, len(d) - 1)) * se
    return dict(mean=float(d.mean()), se=float(se), t=float(t), p=float(p),
                pos=int((d > 0).sum()), n=len(d), mde=float(mde),
                per_seed=d.round(4).tolist(), seeds=ks)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", default="a7_replication.json")
    args = ap.parse_args()

    mid = load("a4_results_m.json")
    base_rows = load("a4_results.json")
    wide_rows = load("a4_results_w.json")
    if not mid:
        print("mid のデータが無い")
        return

    mb = [r for r in mid if r["arm"] == "mid_base"]
    mw = [r for r in mid if r["arm"] == "mid_wide4"]
    W = mb[0]["widths"]
    TOT = sum(W)
    print("=== 0. 構成 ===")
    print(f"  W_MID = {tuple(W)}  合計 {TOT}（BASE_W も 1024）")
    print(f"  n: mid_base={len(mb)} mid_wide4={len(mw)} "
          f"seeds={sorted(r['seed'] for r in mb)}")
    print(f"  mid_wide4 が ReLU² にする expert = "
          f"{[i for i, v in enumerate(mw[0]['act_i']) if v == 'relu2']}")

    print("\n=== 1. 分離できるか: W_MID でも w×share は一定か ===")
    for nm, rows, arm in (("BASE_W all_relu", base_rows, "all_relu"),
                          ("BASE_W wide4", wide_rows, "wide4"),
                          ("W_MID mid_base", mid, "mid_base"),
                          ("W_MID mid_wide4", mid, "mid_wide4")):
        rs = [r for r in rows if r["arm"] == arm]
        if not rs:
            continue
        u = np.array([r["routing"]["usage"] for r in rs]).mean(0)
        w = np.array(rs[0]["widths"], dtype=float)
        prod = w * u
        print(f"  {nm:18s} w×share = " + " ".join(f"{v:5.1f}" for v in prod)
              + f"   CV={prod.std()/prod.mean():.3f}")

    print("\n=== 2. 使用率の順位（W_MID）===")
    u = np.array([r["routing"]["usage"] for r in mb]).mean(0)
    for i in np.argsort(-u):
        print(f"  e{i} (w={W[i]:>3d})  share={u[i]:.4f}  w×share={W[i]*u[i]:.1f}")
    order_w = sorted(range(len(W)), key=lambda i: -W[i])[:4]
    order_u = list(np.argsort(u)[:4])
    print(f"  幅の広い 4 個 = {sorted(order_w)}")
    print(f"  使われない 4 個 = {sorted(order_u)}")
    print(f"  → {'一致（分離できていない）' if set(order_w) == set(order_u) else '不一致（分離できた）'}")

    print("\n=== 3. 再現: mid_wide4 − mid_base（seed 対応、n=6）===")
    res = []
    for key in ("instr_valid", "ce_all"):
        c = paired(mid, "mid_wide4", "mid_base", key)
        if not c:
            continue
        c["metric"] = key
        res.append(c)
        star = " *" if c["p"] < 0.05 else "  "
        print(f"  {key:11s} Δ={c['mean']:+.4f} se={c['se']:.4f} t={c['t']:+.2f} "
              f"p={c['p']:.4f}{star} {c['pos']}/{c['n']} MDE={c['mde']:.4f}")
        print(f"    seed 別: {', '.join(f'{v:+.3f}' for v in c['per_seed'])}")

    print("\n=== 4. BASE_W の k=4 と並べる ===")
    c0 = paired(base_rows + wide_rows, "wide4", "all_relu", "instr_valid")
    c1 = paired(mid, "mid_wide4", "mid_base", "instr_valid")
    if c0 and c1:
        print(f"  BASE_W (幅 32..224) : wide4 − all_relu   = {c0['mean']:+.4f} "
              f"(p={c0['p']:.3f}, {c0['pos']}/{c0['n']}, MDE {c0['mde']:.3f})")
        print(f"  W_MID  (幅 32..192) : mid_wide4 − mid_base = {c1['mean']:+.4f} "
              f"(p={c1['p']:.3f}, {c1['pos']}/{c1['n']}, MDE {c1['mde']:.3f})")
        same = (np.sign(c0["mean"]) == np.sign(c1["mean"]))
        print(f"  符号が一致: {'✓ 再現' if same else '✗ 再現せず'}"
              f"（大きさの比 = {c1['mean']/c0['mean']:.2f}）" if c0["mean"] else "")

    print("\n=== 5. ベースライン同士の比較（幅ベクトルの効果）===")
    c = paired(mid + base_rows, "mid_base", "all_relu", "instr_valid")
    if c:
        print(f"  mid_base − all_relu = {c['mean']:+.4f} (p={c['p']:.3f})")

    agg = {}
    for a in ("mid_base", "mid_wide4"):
        rs = [r for r in mid if r["arm"] == a]
        agg[a] = dict(ce=float(np.mean([r["evals"][-1]["ce_all"] for r in rs])),
                      iv=float(np.mean([r["evals"][-1]["instr_valid"] for r in rs])),
                      iv_sd=float(np.std([r["evals"][-1]["instr_valid"] for r in rs], ddof=1)),
                      usage=np.array([r["routing"]["usage"] for r in rs]).mean(0).tolist(),
                      nparam=rs[0]["nparam"])
    out = {"aggregate": agg, "contrasts": res, "widths": list(W)}
    with open(os.path.join(D, args.json), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(f"\n[write] {os.path.join(D, args.json)}")


if __name__ == "__main__":
    main()
