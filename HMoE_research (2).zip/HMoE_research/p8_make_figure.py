# -*- coding: utf-8 -*-
"""P8 作図: P(pass|L) の崖と、失敗の見え方（測定とは分離）

入力: p8_length.jsonl
出力: p8_length.png
"""

import json
import os
import re

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

matplotlib.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "MS Gothic", "sans-serif"]
matplotlib.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))


def resolve(r):
    src = r.get("forced_tail") if r["cond"] == "force256" else r["text_tail"]
    nums = re.findall(r"-?\d+", (src or "").replace(",", ""))
    pred = nums[-1] if nums else None
    ok = pred is not None and (r["cond"] == "force256" or r["finished"])
    return pred, ok


def main():
    recs = [json.loads(l) for l in open(os.path.join(HERE, "p8_length.jsonl"), encoding="utf-8")]
    for r in recs:
        pred, ok = resolve(r)
        r["answered"] = ok
        r["correct"] = bool(ok and pred == r["gold"])

    fig, axes = plt.subplots(1, 2, figsize=(11.8, 4.7))

    # ---- A: P(pass|L) ----
    ax = axes[0]
    caps = [128, 256, 512, 1024]
    for lv, col, lab in (("add4", "#c0392b", "4 桁加算（n=14）"),
                         ("add3", "#2c6fbb", "3 桁加算（n=6）")):
        ys = []
        for c in caps:
            sel = [r for r in recs if r["cond"] == "cap%d" % c and r["level"] == lv]
            ys.append(np.mean([r["correct"] for r in sel]))
        ax.plot(caps, ys, marker="o", color=col, label=lab, lw=1.9)
        for x, y in zip(caps, ys):
            ax.annotate("%.2f" % y, (x, y), textcoords="offset points",
                        xytext=(0, 8 if lv == "add3" else -14), ha="center",
                        fontsize=8.5, color=col)
    na = []
    for c in caps:
        sel = [r for r in recs if r["cond"] == "cap%d" % c]
        na.append(np.mean([not r["answered"] for r in sel]))
    ax.plot(caps, na, ls="--", color="#7f8c8d", marker="s", label="答えなし率")
    ax.set_xscale("log", base=2)
    ax.set_xticks(caps)
    ax.set_xticklabels([str(c) for c in caps])
    ax.set_xlabel("生成の上限 L（トークン）")
    ax.set_ylabel("率")
    ax.set_ylim(-0.05, 1.08)
    ax.set_title("A. P(pass | L) は凹ではなく崖\n256→512 で 0.17→0.83（3 桁）", fontsize=10)
    ax.legend(fontsize=8.5)
    ax.grid(alpha=0.3)

    # ---- B: 失敗の見え方 ----
    ax = axes[1]
    hard = {r["q"]: r for r in recs if r["cond"] == "cap256"}
    fails = [q for q, r in hard.items() if not r["answered"]]
    conds = [("cap256", "hard-A\n打ち切り"), ("force256", "hard-B\n強制解答"),
             ("soft", "soft\n短く考えよ"), ("nothink", "nothink\nthinking off")]
    xs = np.arange(len(conds))
    no_ans, wrong, right = [], [], []
    for c, _ in conds:
        d = {r["q"]: r for r in recs if r["cond"] == c}
        sub = [d[q] for q in fails if q in d]
        no_ans.append(np.mean([not r["answered"] for r in sub]))
        wrong.append(np.mean([r["answered"] and not r["correct"] for r in sub]))
        right.append(np.mean([r["answered"] and r["correct"] for r in sub]))
    ax.bar(xs, no_ans, 0.6, color="#95a5a6", label="答えなし（見える失敗）")
    ax.bar(xs, wrong, 0.6, bottom=no_ans, color="#c0392b", label="誤答を出した（見えない失敗）")
    ax.bar(xs, right, 0.6, bottom=np.array(no_ans) + np.array(wrong),
           color="#1e8449", label="正解")
    ax.set_xticks(xs)
    ax.set_xticklabels([c[1] for c in conds], fontsize=8.5)
    ax.set_ylabel("hard-A で答えなしだった 19 問の割合")
    ax.set_ylim(0, 1.05)
    ax.set_title("B. 同じ失敗が、条件で「見える／見えない」に分かれる\n"
                 "強制解答にすると 84% が誤答として出てくる", fontsize=10)
    ax.legend(fontsize=8.5, loc="lower right")
    ax.grid(alpha=0.3, axis="y")

    fig.suptitle("P8: 長さ L のパイロット — Qwen3-0.6B, 加算, n=20 問", fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.92])
    out = os.path.join(HERE, "p8_length.png")
    fig.savefig(out, dpi=150)
    print("saved: " + out)


if __name__ == "__main__":
    main()
