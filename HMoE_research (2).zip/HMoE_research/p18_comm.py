# -*- coding: utf-8 -*-
"""P18: mid-flight 通信が best-of-N の独立性を壊すか（考察 §7 予測 1）

予測（`考察_HMoEとサブエージェントPro_Ultraモード_20261029.md` §4 末 / §7 予測 1）:
  Ultra は subagent 間の mid-flight 通信を含むため、best-of-N の独立性条件が崩れる。
  通信で誤りが相関すると、oracle 利得の回収は N=1 の方向に縮むはず。

設計（星型: 先頭 agent の出力を後続 7 本の prompt に注入）:
  arm A  独立 8 本（P14 の 320 サンプルをそのまま使う。seed 31・同一問題・bit 同一）
  arm B  1 本目は独立（= arm A の sample#1）＋ 2〜8 本目は「別の解答者が X と答えた」を注入
  arm C  placebo: 同じ長さ・同じ形で、**無情報の数字**を注入（金と一致しない妥当桁の乱数）

  B と C の差が「情報の伝達」の効果、C と A の差が「prompt が長くなった」効果。

測るもの:
  得票集中度（注入値への一致率）/ 答えの種類数 / 誤り相関（P(両方誤) / P(誤)^2）
  majority・pass@1・pass@8 / **回収率 = (maj − pass@1) / (pass@8 − pass@1)**
  majority と pass@8 の差（= 独立性が壊れた分だけ開く）

出力: p18_comm.jsonl / p18_meta.json
"""

import argparse
import json
import os
import random

import numpy as np
import torch

from p14_bestofn import score_sample, extract_value

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "qwen3-0.6b")
SYS = "You are a careful arithmetic assistant. Solve the problem and give the final answer."
INJECT = ("\n\nAnother solver already attempted this problem and answered {ans}. "
          "Give your own final answer.")


def log(m):
    print(m, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_prob", type=int, default=20)
    ap.add_argument("--n_samp", type=int, default=8)
    ap.add_argument("--rounds", type=int, default=2)
    ap.add_argument("--seed", type=int, default=31)        # P14 と同じ問題列
    ap.add_argument("--seed_arm", type=int, default=71)    # B/C の生成 seed（A と別）
    ap.add_argument("--tag", type=str, default="p18")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer
    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    eos_id = tok.eos_token_id
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, torch_dtype=torch.bfloat16, device_map="cuda",
        attn_implementation="sdpa").eval()

    # ---- 問題列（P14/P9 と同一）----
    rnd = random.Random(args.seed)
    probs = []
    for _ in range(args.n_prob):
        a, b = rnd.randint(10001, 99999), rnd.randint(10001, 99999)
        probs.append({"q": "Compute %d + %d." % (a, b), "gold": str(a + b)})
    p9 = os.path.join(HERE, "p9_count.jsonl")
    if os.path.exists(p9):
        qs = [json.loads(l)["q"] for l in open(p9, encoding="utf-8") if l.strip()]
        assert qs[:args.n_prob] == [p["q"] for p in probs], "problem list diverges from p9"

    # ---- arm A（P14 の独立 8 本）を読む ----
    armA = {}
    with open(os.path.join(HERE, "p14_bestofn.jsonl"), encoding="utf-8") as fp:
        for line in fp:
            r = json.loads(line)
            if r.get("round") == "greedy":
                continue
            armA[(r["round"], r["q"])] = r["samples"]
    assert len(armA) == args.rounds * args.n_prob, len(armA)
    log("arm A loaded from p14_bestofn.jsonl (%d records)" % len(armA))

    def build(q, inj=None):
        content = q if inj is None else q + INJECT.format(ans=inj)
        return tok.apply_chat_template(
            [{"role": "system", "content": SYS}, {"role": "user", "content": content}],
            tokenize=False, add_generation_prompt=True, enable_thinking=False)

    prng = random.Random(args.seed_arm)
    recs = []
    for r_i in range(args.rounds):
        torch.manual_seed(args.seed_arm + 100 + r_i)
        for p in probs:
            base = armA[(r_i, p["q"])]
            inj_ans = base[0]["pred"]                 # 先頭 agent の答え（星型の中心）
            # placebo: 妥当な桁の乱数で、gold と注入元の答えのどちらでもないもの
            while True:
                ph = str(prng.randint(20002, 199998))
                if ph != p["gold"] and ph != inj_ans:
                    break
            row = {"round": r_i, "q": p["q"], "gold": p["gold"],
                   "inj_ans": inj_ans, "placebo": ph, "arms": {}}
            for arm, inj in [("B", inj_ans), ("C", ph)]:
                prompts = [build(p["q"], inj)] * (args.n_samp - 1)
                enc = tok(prompts, return_tensors="pt", padding=True,
                          add_special_tokens=False).to(model.device)
                with torch.no_grad():
                    o = model.generate(**enc, max_new_tokens=96, do_sample=True,
                                       temperature=0.9, top_p=0.95,
                                       pad_token_id=tok.pad_token_id)
                gen = o[:, enc["input_ids"].shape[1]:]
                samples = []
                for j in range(args.n_samp - 1):
                    ids = [t for t in gen[j].tolist() if t != tok.pad_token_id]
                    txt = tok.decode(ids, skip_special_tokens=True)
                    pred = extract_value(txt)
                    samples.append({"pred": pred,
                                    "correct": None if pred is None else (pred == p["gold"]),
                                    "ntok": len(ids), "tail": txt.strip()[-60:]})
                row["arms"][arm] = samples
            recs.append(row)
        log("round %d done (B/C)" % r_i)

    meta = {"n_prob": args.n_prob, "n_samp": args.n_samp, "rounds": args.rounds,
            "seed_problems": args.seed, "seed_arm": args.seed_arm,
            "n_recs": len(recs), "n_conditioned_per_arm": len(recs) * (args.n_samp - 1),
            "inject_template": INJECT,
            "arm_A_source": "p14_bestofn.jsonl (independent, seed 31)",
            "model": MODEL}
    with open(os.path.join(HERE, "%s_comm.jsonl" % args.tag), "w", encoding="utf-8") as fp:
        for r in recs:
            fp.write(json.dumps(r, ensure_ascii=False) + "\n")
    with open(os.path.join(HERE, "%s_meta.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(meta, fp, ensure_ascii=False, indent=2)
    log(json.dumps(meta, ensure_ascii=False))
    os._exit(0)


if __name__ == "__main__":
    main()
