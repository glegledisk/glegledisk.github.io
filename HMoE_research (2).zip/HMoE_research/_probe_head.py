# -*- coding: utf-8 -*-
"""_probe_head.py — 本物の lm_head 重みはどこか（使い捨て）

N(最終norm後) と各候補 W の内積を出力 logits と突き合わせる。
"""
import os
import sys

import torch
import numpy as np
from transformers import AutoModelForCausalLM

HERE = os.path.dirname(os.path.abspath(__file__))
M = os.path.join(HERE, "models", "olmoe-1b-7b")

model = AutoModelForCausalLM.from_pretrained(
    M, torch_dtype=torch.bfloat16, device_map="auto",
    max_memory={0: "7.5GiB", "cpu": "8.0GiB"},
).eval()
print("config.tie_word_embeddings =", model.config.tie_word_embeddings)

z = np.load(os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"), allow_pickle=True)
ids = torch.from_numpy(z["en_ids"].astype(np.int64))[:256].unsqueeze(0).to(model.device)

h_final = []
def hook(module, inp, out):
    h_final.append(out.detach().float().cpu())
model.model.norm.register_forward_hook(hook)

with torch.no_grad():
    out = model(input_ids=ids, use_cache=False)
lg = out.logits[0, :-1].float().cpu()      # (T, V)
N = h_final[0][0, :-1].float()             # (T, d)
print("N", tuple(N.shape), "lg", tuple(lg.shape))

# 候補 1: weights_map の中身をそのまま
m = model.lm_head
cands = {}
cands["placeholder"] = m.weight
h = getattr(m, "_hf_hook", None)
print("lm_head._hf_hook =", type(h).__name__ if h is not None else None)
if h is not None:
    wm = getattr(h, "weights_map", None)
    print("weights_map type =", type(wm).__name__)
    try:
        w = wm["weight"]
        cands["weights_map"] = w
    except Exception as e:
        print("cannot index weights_map:", repr(e))
cands["embed_tokens"] = model.model.embed_tokens.weight

def mat_err(name, Wc):
    if getattr(Wc, "is_meta", False):
        print("%-12s meta placeholder (実体なし)" % name)
        return
    W = Wc.detach().float().cpu()
    print("%-12s device=%s shape=%s  err=%s" % (
        name, Wc.device, tuple(W.shape),
        "%.5f" % (N @ W.t() - lg).abs().max().item()))
    del W

for k, v in cands.items():
    mat_err(k, v)
sys.stdout.flush()
os._exit(0)
