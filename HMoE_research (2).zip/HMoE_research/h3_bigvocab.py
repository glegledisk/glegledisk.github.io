"""H3: 容量が律速する regime でのテストベッド（cue 課題）。

## なぜ作り直したか

H1/H2 では活性幅 1.0〜3.0 で CE が平坦だった（8 セルすべて dCE/dwidth ≈ 0）。
原因を追ったところ、**課題の設計ミス**だった:

  H1 の「難しい位置」は x_t = T2[x_{t-1}, x_{t-2}]。
  ところが T1 はほぼ単射なので、x_{t-1} から x_{t-2} が復元できる
  （x_{t-1} = T1[x_{t-2}] の逆像がほぼ一意）。よって T2 の実効サイズは
  512x512 = 262,144 ではなく **512**。どの位置も「直前 1 トークンの表引き」に
  退化しており、記憶量は 8192 エントリしか要求していなかった。
  モデルの FFN は 2.1M パラメータなので、容量は最初から余っていた。

## 修正後の課題

独立な cue を入力に置き、内容トークンを cue の関数にする。cue は常に可視なので
（マスクしない）、内容トークンは cue だけの決定的関数になり、表の実効サイズが
設計値どおりになる。

  SEQ=32。偶数位置 = cue（i.i.d. 一様、常に可視）、奇数位置 = 内容（マスク対象）。
  内容の i 番目（位置 2i+1）:
      i 偶数 : x = Ts[c_i]           表 Ts は C エントリ        → 軽い
      i 奇数 : x = Tb[c_i, c_{i-1}]   表 Tb は CxC エントリ      → 重い

  C=256, V=512 なら Tb は 65,536 エントリ。FFN 2.1M パラメータに対し
  32 パラメータ/エントリで、容量が効き始める領域。

## 期待

  - 幅を増やすと CE が単調に下がる（容量が律速する）
  - その下がり方は「重い」位置で大きく「軽い」位置で小さい
    → 容量の限界価値が位置で違う → 配分の余地が生まれる

これが満たされて初めて、AR×ブロック拡散の交互作用を測る意味が出る。
"""
import argparse
import json
import os
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))

SEQ = 32
P_NCUE = SEQ // 2          # 16 個の cue / 内容ペア


# ---------------------------------------------------------------- task
def make_task(V, C):
    g = torch.Generator().manual_seed(1234)
    Ts = torch.randint(0, V, (C,), generator=g)          # 軽い表
    Tb = torch.randint(0, V, (C, C), generator=g)        # 重い表
    return Ts, Tb


@torch.no_grad()
def gen_batch(n, V, C, Ts, Tb, g):
    """偶数位置 = cue（id < C）、奇数位置 = 内容（id = C + v）。"""
    cue = torch.randint(0, C, (n, P_NCUE), generator=g)
    x = torch.empty(n, SEQ, dtype=torch.long)
    x[:, 0::2] = cue
    for i in range(P_NCUE):
        if i % 2 == 0:
            v = Ts[cue[:, i]]
        else:
            v = Tb[cue[:, i], cue[:, i - 1]]
        x[:, 2 * i + 1] = C + v
    return x


# ---------------------------------------------------------------- model
class MoE(nn.Module):
    def __init__(self, d, d_ff, sizes, k):
        super().__init__()
        self.E = len(sizes)
        self.k = k
        hs = [max(8, int(round(s * d_ff))) for s in sizes]
        H = max(hs)
        self.hs = hs
        self.W1 = nn.Parameter(torch.empty(self.E, H, d))
        self.b1 = nn.Parameter(torch.zeros(self.E, H))
        self.W2 = nn.Parameter(torch.empty(self.E, d, H))
        self.b2 = nn.Parameter(torch.zeros(self.E, d))
        nn.init.normal_(self.W1, std=0.02)
        nn.init.normal_(self.W2, std=0.02)
        m1 = torch.zeros(self.E, H)
        for e, h in enumerate(hs):
            m1[e, :h] = 1.0
        self.register_buffer("m1", m1)
        self.register_buffer("sizes", torch.tensor(sizes, dtype=torch.float32))
        self.router = nn.Linear(d, self.E, bias=False)

    def forward(self, x):
        B, Ln, D = x.shape
        N = B * Ln
        fx = x.reshape(N, D)
        logits = self.router(x)
        probs = logits.softmax(-1)
        w, idx = logits.topk(self.k, dim=-1)
        w = w.softmax(-1)
        fw = w.reshape(N, self.k)
        fi = idx.reshape(N, self.k)

        h = torch.bmm(fx.unsqueeze(0).expand(self.E, -1, -1), self.W1.transpose(1, 2))
        h = F.gelu(h + self.b1.unsqueeze(1)) * self.m1.unsqueeze(1)
        y = torch.bmm(h, self.W2.transpose(1, 2)) + self.b2.unsqueeze(1)
        y = y.permute(1, 0, 2)

        gate = torch.zeros(N, self.E, device=x.device, dtype=fx.dtype)
        gate.scatter_add_(1, fi, fw)
        out = (gate.unsqueeze(-1) * y).sum(1)

        hard = self.sizes[fi].sum(-1).mean()
        soft = self.k * (probs * self.sizes).sum(-1).mean()
        cost = hard + (soft - soft.detach())
        top1 = fi[:, 0]
        frac = torch.bincount(top1, minlength=self.E).float() / top1.numel()
        aux = self.E * (frac * probs.reshape(-1, self.E).mean(0)).sum()
        return out.view(B, Ln, D), cost, aux, fi, fw


class Block(nn.Module):
    def __init__(self, d, nh, d_ff, sizes, k):
        super().__init__()
        self.ln1 = nn.LayerNorm(d)
        self.attn = nn.MultiheadAttention(d, nh, batch_first=True)
        self.ln2 = nn.LayerNorm(d)
        self.moe = MoE(d, d_ff, sizes, k)

    def forward(self, x, am):
        h = self.ln1(x)
        a, _ = self.attn(h, h, h, attn_mask=am, need_weights=False)
        x = x + a
        y, cost, aux, fi, fw = self.moe(self.ln2(x))
        return x + y, cost, aux, fi, fw


class Net(nn.Module):
    def __init__(self, n_class, d, nh, nlay, d_ff, sizes, k):
        super().__init__()
        self.emb = nn.Embedding(n_class, d)
        self.pos = nn.Parameter(torch.zeros(SEQ, d))
        self.blocks = nn.ModuleList(Block(d, nh, d_ff, sizes, k) for _ in range(nlay))
        self.ln_f = nn.LayerNorm(d)
        self.head = nn.Linear(d, n_class, bias=False)
        nn.init.normal_(self.pos, std=0.02)

    def forward(self, x, am):
        h = self.emb(x) + self.pos
        cs, as_, fis, fws = [], [], [], []
        for blk in self.blocks:
            h, c, a, fi, fw = blk(h, am)
            cs.append(c)
            as_.append(a)
            fis.append(fi)
            fws.append(fw)
        return self.head(self.ln_f(h)), torch.stack(cs).mean(), torch.stack(as_).mean(), fis, fws


def block_mask(b):
    idx = torch.arange(SEQ)
    blk = idx // b
    return (blk[:, None] == blk[None, :]) | (blk[None, :] < blk[:, None])


def sample_mask(B, t_min, gen, dev):
    """内容位置（奇数）だけをマスクする。cue は常に可視。"""
    t = t_min + (1.0 - t_min) * torch.rand(B, 1, generator=gen)
    m = torch.rand(B, SEQ, generator=gen) < t
    m[:, 0::2] = False
    m[:, SEQ - 1] = True                     # 最低 1 つは必ずマスク
    return m.to(dev), t.to(dev)


def diff_loss(model, x, am, gen, mask_id):
    B = x.shape[0]
    m, t = sample_mask(B, 0.05, gen, x.device)
    inp = torch.where(m, torch.full_like(x, mask_id), x)
    logits, cost, aux, _, _ = model(inp, am)
    ce = F.cross_entropy(logits.reshape(-1, logits.shape[-1]), x.reshape(-1),
                         reduction="none").view(B, SEQ)
    return (ce * m.float() / t).mean(), cost, aux


@torch.no_grad()
def evaluate(model, xs, am, mask_id):
    g = torch.Generator().manual_seed(999)
    tot, n = 0.0, 0
    for _ in range(6):
        m, _ = sample_mask(xs.shape[0], 0.1, g, xs.device)
        inp = torch.where(m, torch.full_like(xs, mask_id), xs)
        logits, _, _, _, _ = model(inp, am)
        ce = F.cross_entropy(logits.reshape(-1, logits.shape[-1]), xs.reshape(-1),
                             reduction="none").view(-1, SEQ)
        tot += float((ce * m.float()).sum() / m.float().sum())
        n += 1
    return tot / n


@torch.no_grad()
def ce_by_pos(model, xs, am, mask_id):
    """内容位置の種別（light = Ts, heavy = Tb）× マスク率ビン の CE。"""
    g = torch.Generator().manual_seed(555)
    dev = xs.device
    heavy = torch.zeros(SEQ, dtype=torch.bool, device=dev)
    heavy[3::4] = True                                   # i 奇数 → 位置 2i+1 = 3,7,11,...
    buckets = [(0.0, 0.25), (0.25, 0.5), (0.5, 0.75), (0.75, 1.01)]
    acc = {}
    for _ in range(6):
        m, t = sample_mask(xs.shape[0], 0.1, g, dev)
        inp = torch.where(m, torch.full_like(xs, mask_id), xs)
        logits, _, _, _, _ = model(inp, am)
        ce = F.cross_entropy(logits.reshape(-1, logits.shape[-1]), xs.reshape(-1),
                             reduction="none").view(-1, SEQ)
        for lo, hi in buckets:
            mb = m & (t >= lo) & (t < hi)
            for is_heavy, kn in ((True, "heavy"), (False, "light")):
                sel = mb & (heavy == is_heavy).unsqueeze(0)
                if sel.any():
                    acc.setdefault(f"{lo:.2f}|{kn}", []).append(float(ce[sel].mean()))
    return {k: float(np.mean(v)) for k, v in acc.items()}


def run_one(V, C, s, b, seed, steps, d, nh, nlay, d_ff, bs, lr, k):
    torch.manual_seed(seed)
    np.random.seed(seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    n_class = C + V + 1
    mask_id = C + V
    Ts, Tb = make_task(V, C)
    Ts, Tb = Ts.to(dev), Tb.to(dev)

    model = Net(n_class, d, nh, nlay, d_ff, [s] * 8, k).to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda i: min(1.0, i / max(1, steps * 0.05)))
    am = ~block_mask(b).to(dev)
    gen = torch.Generator(device="cpu").manual_seed(seed * 77 + 1)
    xv = gen_batch(512, V, C, Ts.cpu(), Tb.cpu(), torch.Generator().manual_seed(7)).to(dev)

    t0 = time.time()
    for _ in range(steps):
        x = gen_batch(bs, V, C, Ts.cpu(), Tb.cpu(), gen).to(dev)
        loss, cost, aux = diff_loss(model, x, am, gen, mask_id)
        opt.zero_grad(set_to_none=True)
        (loss + 0.01 * aux).backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()

    val = evaluate(model, xv, am, mask_id)
    cells = ce_by_pos(model, xv, am, mask_id)
    with torch.no_grad():
        xb = gen_batch(256, V, C, Ts.cpu(), Tb.cpu(), torch.Generator().manual_seed(11)).to(dev)
        m, _ = sample_mask(256, 0.5, torch.Generator().manual_seed(5), dev)
        inp = torch.where(m, torch.full_like(xb, mask_id), xb)
        _, cost_meas, _, _, _ = model(inp, am)
    return dict(V=V, C=C, s=s, width=k * s, b=b, seed=seed, steps=steps, val=val,
                cost=float(cost_meas), cells=cells, sec=time.time() - t0,
                params=sum(p.numel() for p in model.parameters()))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--V", type=int, default=512)
    ap.add_argument("--C", type=int, default=256)
    ap.add_argument("--widths", default="0.5,0.75,1.0,1.5")
    ap.add_argument("--b", type=int, default=16)
    ap.add_argument("--seeds", default="0")
    ap.add_argument("--steps", type=int, default=3000)
    ap.add_argument("--d", type=int, default=128)
    ap.add_argument("--nh", type=int, default=4)
    ap.add_argument("--nlay", type=int, default=4)
    ap.add_argument("--d_ff", type=int, default=256)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--lr", type=float, default=3e-3)
    ap.add_argument("--k", type=int, default=2)
    ap.add_argument("--out", default="h3_width_sweep.jsonl")
    a = ap.parse_args()

    out = os.path.join(HERE, a.out)
    if os.path.exists(out):
        os.remove(out)
    for s in [float(x) for x in a.widths.split(",")]:
        for seed in [int(x) for x in a.seeds.split(",")]:
            r = run_one(a.V, a.C, s, a.b, seed, a.steps, a.d, a.nh, a.nlay,
                        a.d_ff, a.bs, a.lr, a.k)
            print(json.dumps({k: v for k, v in r.items() if k != "cells"}, ensure_ascii=False), flush=True)
            for kk in sorted(r["cells"]):
                print(f"    {kk:16s} {r['cells'][kk]:.4f}", flush=True)
            with open(out, "a", encoding="utf-8") as fp:
                fp.write(json.dumps(r, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
