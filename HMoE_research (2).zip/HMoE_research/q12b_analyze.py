#!/usr/bin/env python3
"""Q12b の解析: 競合なしの再走と、Q12（競合あり）との比較。

わかること:
  1. 2×2 を競合なしの draw で作り直す
  2. **固定 seed での run-to-run ノイズ**（q12 と q12b の per-seed 差）を直接測る
     → この testbed の「同じ条件を 2 回走らせたときのばらつき」の実測値
  3. 前回の結論（両方 32 はルーンの半分）が別 draw でも出るか
"""
import json
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "simulation_hmoe_mmlu", "data")
OUT = []
def w(s=""):
    print(s)
    OUT.append(s)


def st(x):
    x = np.asarray(x, float)
    n = len(x)
    m = x.mean()
    se = x.std(ddof=1) / np.sqrt(n)
    t = m / se if se > 0 else 0.0
    p = 2 * stats.t.sf(abs(t), df=n - 1) if se > 0 else 1.0
    return m, se, t, p, int((x > 0).sum()), int((x < 0).sum())


MODES = ["dynamic_lb", "static_1x", "static_swapped", "static_narrow"]
POOLW = {"static_1x": ([32], [224]), "static_swapped": ([224, 224], [32, 32]),
         "static_narrow": ([32], [32])}
D, ATT, SH_S, SH_P = 128, 4 * 128 * 128, 0.2, 0.8


def load(d, m):
    rows = []
    for s in range(6):
        p = os.path.join(DATA, d, f"H+LB_hard_{m}_s{s}.json")
        with open(p, encoding="utf-8") as f:
            rows.append(json.load(f))
    e = [r["eval"]["base"] for r in rows]
    return {k: np.array([x[k] for x in e])
            for k in ("instr_valid", "acc_payload", "ce_payload",
                      "width_struct", "width_payload")}


A = {m: load("q12", m) for m in MODES}
B = {m: load("q12b", m) for m in MODES}

w("=" * 86)
w("Q12（競合あり） vs Q12b（競合なし）")
w("=" * 86)

w("\n[1] 幅の校正（q12b が設計どおりか）")
EXPECT = {"static_1x": (32.0, 224.0), "static_swapped": (224.0, 32.0),
          "static_narrow": (32.0, 32.0)}
for m in MODES:
    ws, wp = B[m]["width_struct"].mean(), B[m]["width_payload"].mean()
    tag = ""
    if m in EXPECT:
        ok = abs(ws - EXPECT[m][0]) < 1e-6 and abs(wp - EXPECT[m][1]) < 1e-6
        tag = "  OK" if ok else "  **不一致**"
    w(f"  {m:<15} {ws:6.1f} / {wp:6.1f}{tag}")

w("\n[2] 水準（q12 → q12b）")
for m in MODES:
    a, b = A[m]["instr_valid"], B[m]["instr_valid"]
    w(f"  {m:<15} {a.mean():.3f} (se {st(a)[1]:.3f})  →  {b.mean():.3f} "
      f"(se {st(b)[1]:.3f})   差 {b.mean()-a.mean():+.3f}")
    w(f"    q12b per-seed: " + ", ".join(f"{x:.3f}" for x in b))

w("\n[3] ★ 固定 seed での run-to-run ノイズ（q12b − q12）")
all_d = []
for m in MODES:
    d = B[m]["instr_valid"] - A[m]["instr_valid"]
    all_d.append(d)
    w(f"  {m:<15} mean {d.mean():+.3f}  sd {d.std(ddof=1):.3f}  "
      f"per-seed " + ", ".join(f"{x:+.3f}" for x in d))
pool = np.concatenate(all_d)
w(f"  全 24 ペアをプール: mean {pool.mean():+.3f}  sd {pool.std(ddof=1):.3f}  "
  f"|差| の中央値 {np.median(np.abs(pool)):.3f}  最大 {np.abs(pool).max():.3f}")
w("  → **同じ seed・同じコードで条件を変えずに走らせた差**。これが判定の下限になる")

w("\n[4] 2×2（q12b、競合なし）")
w(f"  (struct 32, payload 224) static_1x      {B['static_1x']['instr_valid'].mean():.3f}")
w(f"  (struct 224, payload 32) static_swapped {B['static_swapped']['instr_valid'].mean():.3f}")
w(f"  (struct 32, payload 32)  static_narrow  {B['static_narrow']['instr_valid'].mean():.3f}")
w(f"  (共有 224/224)           dense224x2     （Q9a の別プロセス値 0.149）")

w("\n[5] 対応差（q12b、df=5）")
for a, b in [("static_narrow", "static_1x"), ("static_narrow", "static_swapped"),
             ("static_swapped", "static_1x"), ("static_1x", "dynamic_lb"),
             ("static_narrow", "dynamic_lb")]:
    d = B[a]["instr_valid"] - B[b]["instr_valid"]
    m, se, t, p, npos, nneg = st(d)
    w(f"  {a:<14}−{b:<13} {m:+.4f}  se {se:.4f}  t {t:+.2f}  p {p:.4f}  "
      f"正{npos}/負{nneg}  MDE {3.49*se:.3f}")

w("\n[6] FLOPs")
ref = None
for m in MODES:
    if m in POOLW:
        ws, wp = POOLW[m]
        ffn = SH_S * sum(2 * D * x for x in ws) + SH_P * sum(2 * D * x for x in wp)
    else:
        ffn = (SH_S * 4 * D * B[m]["width_struct"].mean()
               + SH_P * 4 * D * B[m]["width_payload"].mean())
    tot = ATT + ffn
    if ref is None:
        ref = tot
    w(f"  {m:<15} 総 {tot:8.0f}  {tot/ref:.2f}×")

with open(os.path.join(HERE, "q12b_analysis_out_utf8.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(OUT) + "\n")
print("\n[written] q12b_analysis_out_utf8.txt")
