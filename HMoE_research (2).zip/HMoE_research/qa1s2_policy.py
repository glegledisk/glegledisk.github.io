# -*- coding: utf-8 -*-
"""QA1S2: 3 点対照用の `PolicyActMoE` と評価関数.

設計書: `QA1S2課題設計書_幅3腕をA4bハーネスに載せDelta_ivを7seedで検定する_20261114.md` §4

- `ActMoE` を継承し `forward` を上書きして、層ごとの `topi` と `gate` を差し替える。
  `gate_of` だけでは `topi == i` の expert gather が変わらないため、選択自体を差し替える。
- 返り値は既存 `ActMoE` と同じ 3 値 `(out, aux, idxs)` で、`a1_activation_ffn.evaluate`
  および `a4_small_expert_act.run_one` の呼び出し規約を壊さない。
- 方策: `learned` (topk) / `uniform` (全 expert 等重み) / `random` (型と独立な一様) /
  `oracle` (struct → 小幅群 e0/e1、payload → 大幅群 e6/e7)。
- 乱数ストリームは `seed + 977` で走行前に固定（設計書 §4）。
"""
from __future__ import annotations

import math
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import q1_trace_routing as Q1                     # noqa: E402
from a1_activation_ffn import ActMoE             # noqa: E402

POLICIES = ("learned", "uniform", "random", "oracle")
RNG_SEED_OFFSET = 977


class PolicyActMoE(ActMoE):
    """3 点対照用。`policy` を切り替えて同一 ckpt・同一トークンを再評価する。"""

    def __init__(self, *args, policy: str = "learned", rng_seed: int = 0,
                 random_without_replacement: bool = False, **kwargs):
        super().__init__(*args, **kwargs)
        assert policy in POLICIES, f"unknown policy: {policy}"
        self.policy = policy
        self.rng_seed = int(rng_seed)
        self.rng = np.random.default_rng(self.rng_seed + RNG_SEED_OFFSET)
        self.random_without_replacement = bool(random_without_replacement)
        self.typ_batch = None        # (B, T) の int64 tensor。oracle のみ使用
        self.last_topi = None        # 層 0 の topi (N, k or E)。C5 校正用

    def reset_rng(self):
        """方策評価ごとに乱数ストリームを走行前固定の初期状態へ戻す。"""
        self.rng = np.random.default_rng(self.rng_seed + RNG_SEED_OFFSET)

    def _select(self, logits, B, T):
        N, E = logits.shape
        if self.policy == "learned":
            topv, topi = logits.topk(self.k, dim=1)
            return topi, self.gate_of(logits, topv, topi)

        if self.policy == "uniform":
            topi = (torch.arange(E, device=logits.device)
                    .unsqueeze(0).expand(N, E).contiguous())
            gate = torch.full_like(logits, 1.0 / E)
            return topi, gate

        if self.policy == "random":
            if self.random_without_replacement:
                scores = self.rng.random((N, E))
                arr = np.argsort(scores, axis=1)[:, :self.k].astype(np.int64)
            else:
                arr = self.rng.integers(0, E, size=(N, self.k)).astype(np.int64)
            topi = torch.from_numpy(arr).to(logits.device)
            topv = logits.gather(1, topi)
            return topi, self.gate_of(logits, topv, topi)

        if self.policy == "oracle":
            assert self.typ_batch is not None, "oracle policy requires typ_batch"
            ty = self.typ_batch.reshape(-1).to(logits.device)
            small = (ty != Q1.TYP_PAYLOAD)       # struct / input → 小幅群
            col0 = torch.where(small, 0, E - 2)
            col1 = torch.where(small, 1, E - 1)
            topi = torch.stack([col0, col1], dim=1).to(torch.long)
            topv = logits.gather(1, topi)
            return topi, self.gate_of(logits, topv, topi)

        raise ValueError(self.policy)

    def forward(self, idx, aux_mode="p_pen", need_idx=False, need_hiddens=False):
        assert not need_hiddens, "PolicyActMoE.forward does not support need_hiddens"
        p = self.p
        B, T = idx.shape
        h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
        h = h.reshape(B * T, -1)
        aux_sum = torch.zeros(())
        idxs = [] if need_idx else None
        causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
        dims = torch.tensor(self.dims, dtype=torch.float32)
        for l in range(self.L):
            hb = h.reshape(B, T, -1)
            q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, self.nh, self.dh).transpose(1, 2)
            kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, self.nh, self.dh).transpose(1, 2)
            v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, self.nh, self.dh).transpose(1, 2)
            att = (q @ kk.transpose(-1, -2)) / math.sqrt(self.dh)
            att = att.masked_fill(causal, float("-inf")).softmax(-1)
            o = (att @ v).transpose(1, 2).reshape(B, T, -1)
            h = (hb + F.linear(o, p[f"l{l}.o.w"])).reshape(B * T, -1)

            logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
            topi, gate = self._select(logits, B, T)
            if l == 0:
                self.last_topi = topi.detach().cpu().numpy().copy()
            y = torch.zeros_like(h)
            for i in range(self.E):
                tok, _ = (topi == i).nonzero(as_tuple=True)
                if tok.numel() == 0:
                    continue
                y.index_add_(0, tok,
                             self.ffn(l, i, h[tok]) * gate[tok, i].unsqueeze(1))
            top1 = topi[:, 0]
            f = torch.zeros(self.E)
            f.scatter_add_(0, top1, torch.ones_like(top1, dtype=f.dtype))
            f = f / h.shape[0]
            P = torch.softmax(logits, dim=1).mean(0)
            if aux_mode == "switch":
                aux = self.E * (f * P).sum()
            elif aux_mode == "p_pen":
                aux = self.E * (f * P * (dims / dims.mean())).sum()
            else:
                aux = torch.zeros(())
            h = h + y
            aux_sum = aux_sum + aux
            if need_idx:
                idxs.append(topi.reshape(B, T, -1))
        out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, -1)
        return out, aux_sum / self.L, idxs


@torch.no_grad()
def eval_policy(model, seq, typ, policy, bs=128):
    """1 方策を同一 ckpt・同一 eval トークンで評価する（方策ごとに forward をやり直す）。

    `a1_activation_ffn.evaluate` と同じ指標を返すが、`model.typ_batch` をバッチごとに
    セットして oracle 方策へ型を渡す点が異なる。1 回の logits を使い回さない
    （`corpus_common.run_model` §329-331 の罠）。
    """
    torch.set_num_threads(1)
    model.policy = policy
    model.reset_rng()
    n = seq.shape[0]
    W = Q1.T_LEN - Q1.TRACE0
    ce = np.zeros((n, W), dtype=np.float32)
    hit = np.zeros((n, W), dtype=bool)
    first_logits = None
    topi_parts, typ_parts = [], []
    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = torch.from_numpy(seq[s])
        model.typ_batch = torch.from_numpy(np.asarray(typ[s], dtype=np.int64))
        logits, _, _ = model(x, aux_mode="none")
        if first_logits is None:
            first_logits = logits.detach().cpu().numpy().copy()
        topi_parts.append(model.last_topi.copy())
        typ_parts.append(np.asarray(typ[s], dtype=np.int64).reshape(-1))
        lg = logits[:, Q1.TRACE0 - 1:-1, :len(Q1.VOCAB)]
        tgt = torch.from_numpy(seq[s, Q1.TRACE0:])
        ce[s] = F.cross_entropy(lg.reshape(-1, len(Q1.VOCAB)), tgt.reshape(-1),
                                reduction="none").reshape(-1, W).numpy()
        hit[s] = (lg.argmax(-1).numpy() == tgt.numpy())
    ty = typ[:, Q1.TRACE0:]
    m_st, m_pl = (ty == Q1.TYP_STRUCT), (ty == Q1.TYP_PAYLOAD)
    hp = hit.reshape(n, Q1.P_STEPS, Q1.TPI)[:, :, 2:]
    instr_ok = hp.all(-1)
    return {
        "policy": policy,
        "ce_all": float(ce.mean()),
        "ce_struct": float(ce[m_st].mean()),
        "ce_payload": float(ce[m_pl].mean()),
        "instr_valid": float(instr_ok.all(-1).mean()),
        "instr_acc": float(instr_ok.mean()),
        "first_logits": first_logits,
        "topi": np.concatenate(topi_parts, axis=0),
        "typ_flat": np.concatenate(typ_parts, axis=0),
    }
