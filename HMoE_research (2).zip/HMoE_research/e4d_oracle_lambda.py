# -*- coding: utf-8 -*-
"""e4d_oracle_lambda.py — 決定的対照: Oracle アームで λ を上げる

λ スイープで分かったこと:
  λ>=0.4 では baseline / edit_count とも FFN コスト = 0.000（全トークン恒等パス）になり、
  CE は 0.815 -> 0.823 とほとんど悪化しない。
  → この課題では MoE の FFN がほぼ冗長。ルーティング選択に品質上の意味がない。

すると疑問が立つ: Oracle(PLAN) の CE 0.440 は「ルーティングが賢いから」か、
「PLAN が入力にあるから」か。

  - λ を上げて Oracle が全恒等になっても CE が 0.44 のままなら、
    PLAN の効果は**入力条件付け**であり、ルーティングは無関係（E4b/E4c の解釈を修正）。
  - λ を上げると CE が 0.8 台に戻るなら、ルーティングが本質。
"""
import os, json, time
import numpy as np
import pandas as pd
from e4d_prefix_stats import run_arm

HERE = os.path.dirname(os.path.abspath(__file__))
LAMS = [0.4, 0.8]
SEEDS = [0, 1, 2]

rows = []
t0 = time.time()
for lam in LAMS:
    for s in SEEDS:
        r = run_arm("oracle", s, lam_cost=lam)
        r["lam"] = lam
        rows.append(r)
        print(f"  oracle λ={lam:4.2f} s{s} | Δ {r['sel_delta']:+.3f} | FFN {r['ffn_cost']:.3f} "
              f"| CE {r['ce_all']:.4f} (copy {r['ce_copy']:.4f} / edit {r['ce_edit']:.4f}) "
              f"| acc {r['acc_all']:.4f}", flush=True)
    print(f"    ({time.time()-t0:.0f}s)", flush=True)

df = pd.DataFrame(rows)
df.to_csv(os.path.join(HERE, "e4d_oracle_lambda_results.csv"), index=False)

base = pd.read_csv(os.path.join(HERE, "e4d_prefix_stats_results.csv"))
o15 = base[base.arm == "oracle"]
print("\n=== Oracle: λ 別 (3 seeds) ===")
print(f"{'λ':>5s} {'FFN cost':>16s} {'CE all':>16s} {'CE copy':>16s} {'CE edit':>16s} {'acc':>8s}")
d = o15
print(f"{0.15:5.2f} {d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f}  "
      f"{d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
      f"{d['ce_copy'].mean():.4f}  {d['ce_edit'].mean():.4f}  {d['acc_all'].mean():.4f}")
for lam in LAMS:
    d = df[df.lam == lam]
    print(f"{lam:5.2f} {d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f}  "
          f"{d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"{d['ce_copy'].mean():.4f}  {d['ce_edit'].mean():.4f}  {d['acc_all'].mean():.4f}")

json.dump({"oracle_lambda": rows}, open(os.path.join(HERE, "e4d_oracle_lambda.json"), "w",
                                       encoding="utf-8"), indent=2, ensure_ascii=False)
print("\nsaved e4d_oracle_lambda_results.csv / .json")
