"""H5: 合成的課題と確率的課題。

H4（算術）で「部分点があり、幅への応答が型で違う」ことが確認できた。
ここでは §5.5 で挙げた残り 2 つの設計を実装し、同じ性質が出るかを確かめる。

## 合成的課題 (--task comp)

同じ表 f: [C]x[C] -> [C] を**繰り返し適用する**。表は 1 つだけなので、
1 段目を学べば 2 段目・3 段目の部分点になる（合成性がそのまま部分点になる）。

    i%3 == 0  depth1 : f(c, a)
    i%3 == 1  depth2 : f(f(c, a), b)
    i%3 == 2  depth3 : f(f(f(c, a), b), d)

  c = cue[i], a = cue[i-1], b = cue[i-2], d = cue[i-3]（添字は前に限定。wrap 禁止）

C=31 なら表は 961 エントリで記憶は易しい。律速は**合成の深さ**。
予想: depth1 が最も低く、depth3 が最も高い。幅が深さに効くかを見る。

## 確率的課題 (--task prob)

**H3 の「崖」を直接治す設計。** H3 では 16,384 エントリの表が
「幅を 6 倍にしても全く学習されない（CE = log V）」だった。全か無かで部分点が無いため。
ラベルノイズを混ぜると CE に**床**ができ、学習の度合いが連続量になる。

    i 偶数  type A : Ts[c]                        （C エントリ、決定的）
    i 奇数  type B : Tb[c, a] を確率 q で、そうでなければ一様乱数
                     （Tb は CxC エントリ、ノイズ付き）

type B の CE の床（q=0.7, V=128）:
    正解のとき -log(q + (1-q)/V) = 0.354
    外れのとき -log((1-q)/V)     = 6.056
    床 = 0.7*0.354 + 0.3*6.056 = 2.06      （未学習なら log 128 = 4.85）

つまり CE は 4.85（何も学ばない）から 2.06（完全に学ぶ）まで連続的に動く。
**幅が床への到達度を買うか**を測れる。type A は床 0 なので、幅に無感応なはず。
"""
import argparse
import json
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

from h3_bigvocab import Net, block_mask, sample_mask, diff_loss, evaluate, SEQ, P_NCUE
from h4_arith import mup_init

HERE = os.path.dirname(os.path.abspath(__file__))


# ---------------------------------------------------------------- task
@torch.no_grad()
def gen_comp(n, C, f, g):
    cue = torch.randint(0, C, (n, P_NCUE), generator=g)
    x = torch.empty(n, SEQ, dtype=torch.long)
    x[:, 0::2] = cue
    for i in range(P_NCUE):
        c = cue[:, i]
        a = cue[:, max(0, i - 1)]
        b = cue[:, max(0, i - 2)]
        d = cue[:, max(0, i - 3)]
        u = f[c, a]
        m = i % 3
        if m == 1:
            u = f[u, b]
        elif m == 2:
            u = f[f[u, b], d]
        x[:, 2 * i + 1] = C + u
    return x


@torch.no_grad()
def gen_prob(n, C, V, Ts, Tb, q, g):
    cue = torch.randint(0, C, (n, P_NCUE), generator=g)
    x = torch.empty(n, SEQ, dtype=torch.long)
    x[:, 0::2] = cue
    rnd = torch.rand(n, P_NCUE, generator=g)
    noise = torch.randint(0, V, (n, P_NCUE), generator=g)
    for i in range(P_NCUE):
        c = cue[:, i]
        a = cue[:, max(0, i - 1)]
        if i % 2 == 0:
            v = Ts[c]
        else:
            v = torch.where(rnd[:, i] < q, Tb[c, a], noise[:, i])
        x[:, 2 * i + 1] = C + v
    return x


def make_types(task):
    """内容位置ごとの型 id。SEQ 長、-1 は内容でない位置。"""
    t = torch.full((SEQ,), -1, dtype=torch.long)
    for i in range(P_NCUE):
        t[2 * i + 1] = (i % 3) if task == "comp" else (i % 2)
    return t


TYPE_NAMES = {"comp": ("depth1", "depth2", "depth3"), "prob": ("typeA_det", "typeB_noisy")}


# ---------------------------------------------------------------- eval
@torch.no_grad()
def ce_by_type(model, xs, am, mask_id, tm, names):
    g = torch.Generator().manual_seed(555)
    dev = xs.device
    acc = {}
    for _ in range(6):
        m, _ = sample_mask(xs.shape[0], 0.1, g, dev)
        inp = torch.where(m, torch.full_like(xs, mask_id), xs)
        logits, _, _, _, _ = model(inp, am)
        ce = F.cross_entropy(logits.reshape(-1, logits.shape[-1]), xs.reshape(-1),
                             reduction="none").view(-1, SEQ)
        for ti, tn in enumerate(names):
            sel = m & (tm == ti).unsqueeze(0)
            if sel.any():
                acc.setdefault(tn, []).append(float(ce[sel].mean()))
    return {k: float(np.mean(v)) for k, v in acc.items()}


# ---------------------------------------------------------------- run
def run_one(task, C, V, q, s, b, seed, steps, d, nh, nlay, d_ff, bs, lr, k):
    torch.manual_seed(seed)
    np.random.seed(seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    n_class = C + V + 1
    mask_id = C + V

    model = Net(n_class, d, nh, nlay, d_ff, [s] * 8, k).to(dev)
    mup_init(model, d)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda i: min(1.0, i / max(1, steps * 0.05)))
    am = ~block_mask(b).to(dev)
    gen = torch.Generator(device="cpu").manual_seed(seed * 77 + 1)

    gt = torch.Generator().manual_seed(1234)
    if task == "comp":
        f = torch.randint(0, C, (C, C), generator=gt)
        sample = lambda n, gg: gen_comp(n, C, f, gg)                      # noqa: E731
    else:
        Ts = torch.randint(0, V, (C,), generator=gt)
        Tb = torch.randint(0, V, (C, C), generator=gt)
        sample = lambda n, gg: gen_prob(n, C, V, Ts, Tb, q, gg)           # noqa: E731

    xv = sample(512, torch.Generator().manual_seed(7)).to(dev)

    t0 = time.time()
    for _ in range(steps):
        x = sample(bs, gen).to(dev)
        loss, cost, aux = diff_loss(model, x, am, gen, mask_id)
        opt.zero_grad(set_to_none=True)
        (loss + 0.01 * aux).backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()

    val = evaluate(model, xv, am, mask_id)
    tm = make_types(task).to(dev)
    cells = ce_by_type(model, xv, am, mask_id, tm, TYPE_NAMES[task])
    return dict(task=task, C=C, V=V, q=q, s=s, width=k * s, b=b, seed=seed, steps=steps,
                lr=lr, val=val, cells=cells, sec=time.time() - t0,
                params=sum(p.numel() for p in model.parameters()))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--task", default="comp", choices=["comp", "prob"])
    ap.add_argument("--C", type=int, default=31)
    ap.add_argument("--V", type=int, default=None)
    ap.add_argument("--q", type=float, default=0.7)
    ap.add_argument("--widths", default="1.0,2.0,3.0")
    ap.add_argument("--b", type=int, default=16)
    ap.add_argument("--seeds", default="0")
    ap.add_argument("--steps", type=int, default=3000)
    ap.add_argument("--d", type=int, default=128)
    ap.add_argument("--nh", type=int, default=4)
    ap.add_argument("--nlay", type=int, default=4)
    ap.add_argument("--d_ff", type=int, default=256)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--lr", type=float, default=3e-3)
    ap.add_argument("--k", type=int, default=2)
    ap.add_argument("--out", default=None)
    a = ap.parse_args()

    V = a.V if a.V is not None else a.C
    out = os.path.join(HERE, a.out or f"h5_{a.task}.jsonl")
    if os.path.exists(out):
        os.remove(out)
    for s in [float(x) for x in a.widths.split(",")]:
        for seed in [int(x) for x in a.seeds.split(",")]:
            r = run_one(a.task, a.C, V, a.q, s, a.b, seed, a.steps, a.d, a.nh, a.nlay,
                        a.d_ff, a.bs, a.lr, a.k)
            print(json.dumps({k: v for k, v in r.items() if k != "cells"}, ensure_ascii=False), flush=True)
            for kk in sorted(r["cells"]):
                print(f"    {kk:14s} {r['cells'][kk]:.4f}", flush=True)
            with open(out, "a", encoding="utf-8") as fp:
                fp.write(json.dumps(r, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
