#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX3: 別コーパス・文単位決定・非線形 prefill 特徴で AX2 の予測不能性を反証する

設計書: AX3課題設計書_別コーパスで文単位決定と非線形prefill特徴による反証_20261111.md
（走行前に決定規則・検定族・校正を凍結）

腕 46 本 = native 36（base / base_rep / u7 / u6 / ab7_L×16 / ab6_L×16）＋ mask 10
  mask7 / lay_tok_oracle / lay_tok_ridge / lay_win_oracle / lay_win_ridge /
  lay_win_mlp / lay_win_random / tok_oracle50 / tok_probe50 / tok_random50

確認的（Holm m=3, alpha=0.05, 両側）
  W1: G_lay_tok_oracle = CE(u7) - CE(lay_tok_oracle) = 0        （AX2 T1 の再現）
  W2: G_lay_win_mlp   = CE(u7) - CE(lay_win_mlp)   = 0        （主・反証検定）
  W3: |G_lay_win_mlp - G_tok_probe50| < 0.01 の TOST

実行:
  python _ax3_freeze.py                                  # 走行前に 1 回
  python ax3_transfer.py --smoke --tag ax3smoke        # ドライラン
  python ax3_transfer.py --tag ax3                     # 本番（46 forward）
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ax2_layer_cost import (  # noqa: E402  純関数のみ import
    paired, tost, holm, ridge_fit_predict, cv_predict,
    spearman, gate_stats, randproj, shift_within, movavg,
)

N_LAYERS = 16
H_STRATA = (0, 5, 10, 15)
FEAT_PER_LAYER = 71
NHIST = 9
LAM = 10.0
ALPHA = 0.05
DELTA_TOST = 0.01
PERM_SEED = 777
RAND_WIN_SEED = 901
RAND_TOK_SEED = 7
MLP_SEED0 = 300
MLP_EPOCHS, MLP_LR, MLP_WD, MLP_PATIENCE = 250, 3e-3, 1e-4, 40
FROZEN_AX2 = os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz")
FROZEN_AX3 = os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz")

TEE = None


def log(msg):
    print(msg, flush=True)
    if TEE is not None:
        TEE.write(msg + "\n")
        TEE.flush()


# ---------------------------------------------------------------- corpus
def load_ax3(n_win, ln):
    z = np.load(FROZEN_AX3, allow_pickle=True)
    seqs = []
    for lang in ("en", "ja"):
        ids = torch.from_numpy(z["%s_ids" % lang].astype(np.int64))
        assert ids.numel() >= n_win * ln
        for w in range(n_win):
            seqs.append((lang, ids[w * ln:(w + 1) * ln]))
    return seqs


def grams8(x):
    return set(tuple(int(v) for v in x[i:i + 8]) for i in range(len(x) - 7))


def overlap8(a, b):
    """AX2 側の各位置の 8-gram が本次側に含まれる割合。"""
    gb = grams8(b)
    return float(np.mean([tuple(int(v) for v in a[i:i + 8]) in gb
                         for i in range(len(a) - 7)]))


# ---------------------------------------------------------------- 窓レベル予測器
def ridge_loo(W, Y, lam=LAM):
    """leave-one-window-out ridge（32 出力を列ごとに closed-form）。"""
    n, d = W.shape
    pred = np.zeros_like(Y, dtype=np.float64)
    for f in range(n):
        tr = np.arange(n) != f
        Xtr, Xte = W[tr], W[f:f + 1]
        mu, sd = Xtr.mean(0), Xtr.std(0) + 1e-8
        A, B = (Xtr - mu) / sd, (Xte - mu) / sd
        ym = Y[tr].mean(0)
        d_ = A.shape[1]
        if d_ <= A.shape[0]:
            w = np.linalg.solve(A.T @ A + lam * np.eye(d_), A.T @ (Y[tr] - ym))
        else:
            a = np.linalg.solve(A @ A.T + lam * np.eye(A.shape[0]), Y[tr] - ym)
            w = A.T @ a
        pred[f] = (B @ w + ym)[0]
    return pred


def _init_mlp(layers, seed):
    rng = np.random.RandomState(seed)
    Ws, bs = [], []
    for i in range(len(layers) - 1):
        Ws.append(rng.randn(layers[i], layers[i + 1]) * np.sqrt(2.0 / layers[i]))
        bs.append(np.zeros(layers[i + 1]))
    return Ws, bs


def _fwd(X, Ws, bs):
    acts = [X]
    h = X
    for i in range(len(Ws) - 1):
        h = np.maximum(h @ Ws[i] + bs[i], 0.0)
        acts.append(h)
    return h @ Ws[-1] + bs[-1], acts


def _bwd(acts, Ws, dout, wd):
    """multi-output 版（p4f_mlp._backward の dout[:, None] を (n, n_out) に拡張）。"""
    n = acts[0].shape[0]
    gW = [None] * len(Ws)
    gb = [None] * len(Ws)
    g = dout
    for i in range(len(Ws) - 1, -1, -1):
        gW[i] = acts[i].T @ g / n + wd * Ws[i]
        gb[i] = g.mean(0)
        if i > 0:
            g = (g @ Ws[i].T) * (acts[i] > 0)
    return gW, gb


def mlp_loo(W, Y, epochs=MLP_EPOCHS, lr=MLP_LR, wd=MLP_WD,
            patience=MLP_PATIENCE, seed0=MLP_SEED0):
    """leave-one-window-out MLP（124→64→32→32、Adam＋早期停止）。"""
    n, d = W.shape
    n_out = Y.shape[1]
    pred = np.zeros_like(Y, dtype=np.float64)
    layers = [d, 64, 32, n_out]
    for f in range(n):
        idx = np.where(np.arange(n) != f)[0]           # 47 窓
        va_mask = (np.arange(idx.size) % 4) == 0
        tr_idx, va_idx = idx[~va_mask], idx[va_mask]
        mu, sd = W[tr_idx].mean(0), W[tr_idx].std(0) + 1e-8
        A, V, T = (W[tr_idx] - mu) / sd, (W[va_idx] - mu) / sd, (W[f:f + 1] - mu) / sd
        ym, ys = Y[tr_idx].mean(0), Y[tr_idx].std(0) + 1e-8
        ya, yv = (Y[tr_idx] - ym) / ys, (Y[va_idx] - ym) / ys
        Ws, bs = _init_mlp(layers, seed0 + f)
        best_state = ([w.copy() for w in Ws], [b.copy() for b in bs])
        mW = [np.zeros_like(w) for w in Ws]
        vW = [np.zeros_like(w) for w in Ws]
        mb = [np.zeros_like(b) for b in bs]
        vb = [np.zeros_like(b) for b in bs]
        b1, b2, eps = 0.9, 0.999, 1e-8
        best, bad = np.inf, 0
        for ep in range(1, epochs + 1):
            out, acts = _fwd(A, Ws, bs)
            resid = out - ya
            dout = 2.0 * resid / n_out
            gW, gb = _bwd(acts, Ws, dout, wd)
            for i in range(len(Ws)):
                mW[i] = b1 * mW[i] + (1 - b1) * gW[i]
                vW[i] = b2 * vW[i] + (1 - b2) * (gW[i] ** 2)
                Ws[i] -= lr * (mW[i] / (1 - b1 ** ep)) / (np.sqrt(vW[i] / (1 - b2 ** ep)) + eps)
                mb[i] = b1 * mb[i] + (1 - b1) * gb[i]
                vb[i] = b2 * vb[i] + (1 - b2) * (gb[i] ** 2)
                bs[i] -= lr * (mb[i] / (1 - b1 ** ep)) / (np.sqrt(vb[i] / (1 - b2 ** ep)) + eps)
            vo, _ = _fwd(V, Ws, bs)
            vl = float(((vo - yv) ** 2).mean())
            if vl < best - 1e-12:
                best = vl
                best_state = ([w.copy() for w in Ws], [b.copy() for b in bs])
                bad = 0
            else:
                bad += 1
                if bad >= patience:
                    break
        Ws_b, bs_b = best_state
        out_t, _ = _fwd(T, Ws_b, bs_b)
        pred[f] = out_t[0] * ys + ym
    return pred


# ---------------------------------------------------------------- main
def main():
    global TEE
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--tag", type=str, default="ax3")
    args = ap.parse_args()
    tag = args.tag
    TEE = open(os.path.join(HERE, "%s_transfer_out_utf8.txt" % tag), "w", encoding="utf-8")
    n_win = 3 if args.smoke else args.windows
    ln = args.len
    n_eval = ln - 1

    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[1/9] load model")
    t0 = time.time()
    AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      %.0f s" % (time.time() - t0))
    n_layers = int(model.config.num_hidden_layers)
    d_model = int(model.config.hidden_size)
    full_k = int(model.config.num_experts_per_tok)
    assert full_k == 8 and n_layers == N_LAYERS
    gates = [l.mlp.gate for l in model.model.layers]
    gate_fwd = [g.forward for g in gates]

    STATE = {"kmat": None}

    def make_masked(orig, li):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            km = STATE["kmat"]
            if km is not None and scores.shape[-1] == full_k:
                kk = km[li]
                if kk.numel() == scores.shape[0]:
                    ar = torch.arange(scores.shape[-1], device=scores.device, dtype=torch.float32)
                    scores = scores * (ar[None, :] < kk[:, None]).to(scores.dtype)
            return logits, scores, idx
        return _patched

    for i, g in enumerate(gates):
        g.forward = make_masked(gate_fwd[i], i)

    CAP = {"on": False, "g": None, "h": None}

    def gate_hook(li):
        def fn(module, inp, out):
            if CAP["on"]:
                CAP["g"][li] = out[0].detach().float().cpu()
        return fn

    def mlp_hook(s):
        def fn(module, inp, out):
            if CAP["on"]:
                CAP["h"][s] = inp[0].detach().float().cpu()[0]
        return fn

    handles = [g.register_forward_hook(gate_hook(i)) for i, g in enumerate(gates)]
    handles += [model.model.layers[s].mlp.register_forward_hook(mlp_hook(s)) for s in H_STRATA]
    Rs = {s: torch.from_numpy(randproj(d_model, 256, seed=100 + s)) for s in H_STRATA}

    log("[2/9] corpus (AX3 independent)")
    seqs = load_ax3(n_win, ln)
    lang = np.array([lg for lg, _ in seqs])
    n_tok = len(seqs) * n_eval
    wi_arr = np.repeat(np.arange(len(seqs)), n_eval)
    pos = np.tile(np.arange(n_eval), len(seqs)).astype(np.float64)
    log("      %d windows, %d eval tokens" % (len(seqs), n_tok))

    # ---- 評価ループ（AX2 と同一）----
    def run_eval(name, native_topks=None, capture=False, kmat_windows=None):
        t1 = time.time()
        if kmat_windows is not None:
            for g in gates:
                g.top_k = full_k
        else:
            STATE["kmat"] = None
            tk = full_k if native_topks is None else native_topks
            for i, g in enumerate(gates):
                g.top_k = int(tk[i] if not np.isscalar(tk) else tk)
        nll_c, a1_c = [], []
        capG = [None] * n_layers
        capH = {s: None for s in H_STRATA}
        ent_c, in_c, tgt_c = [], [], []
        G_big = np.zeros((n_layers, n_tok, 64), dtype=np.float32) if capture else None
        H_big = np.zeros((len(H_STRATA), n_tok, 256), dtype=np.float32) if capture else None
        CAP["on"] = capture
        CAP["g"], CAP["h"] = capG, capH
        with torch.no_grad():
            for wi, (lg_lang, ids) in enumerate(seqs):
                if kmat_windows is not None:
                    STATE["kmat"] = torch.from_numpy(
                        kmat_windows[:, wi * ln:(wi + 1) * ln].astype(np.float32)
                    ).to(model.device)
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                logit = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(logit, tgt, reduction="none")
                true_l = logit.gather(1, tgt.unsqueeze(-1))
                a1_c.append(((logit > true_l).sum(-1) == 0).float().cpu().numpy())
                nll_c.append(nll.cpu().numpy())
                if capture:
                    p = torch.softmax(logit, dim=-1)
                    ent_c.append(-(p * torch.log(p + 1e-12)).sum(-1).cpu().numpy())
                    in_c.append(x[0, :-1].cpu().numpy())
                    tgt_c.append(tgt.cpu().numpy())
                    sl = slice(wi * n_eval, (wi + 1) * n_eval)
                    for i in range(n_layers):
                        G_big[i, sl] = capG[i].numpy()[:n_eval]
                    for si, s in enumerate(H_STRATA):
                        H_big[si, sl] = capH[s].numpy()[:n_eval] @ Rs[s].numpy()
                del out, logit
        STATE["kmat"] = None
        CAP["on"] = False
        nll = np.concatenate(nll_c).astype(np.float32)
        a1 = np.concatenate(a1_c).astype(np.float32)
        log("      %-18s CE %.5f  top1 %.4f  (%.0f s)"
            % (name, nll.mean(), a1.mean(), time.time() - t1))
        r = {"nll": nll, "acc1": a1}
        if capture:
            r.update({"G": G_big, "H": H_big, "ent": np.concatenate(ent_c),
                      "in_ids": np.concatenate(in_c), "tgt": np.concatenate(tgt_c)})
        return r

    # ---- native 36 本 ----
    native_arms = [("base", [full_k] * n_layers), ("base_rep", [full_k] * n_layers),
                   ("u7", [7] * n_layers), ("u6", [6] * n_layers)]
    for L in range(n_layers):
        native_arms.append(("ab7_%02d" % L, [7 if i == L else full_k for i in range(n_layers)]))
    for L in range(n_layers):
        native_arms.append(("ab6_%02d" % L, [6 if i == L else full_k for i in range(n_layers)]))

    log("[3/9] native forwards (%d arms)" % len(native_arms))
    res, cap = {}, None
    for ai, (name, topks) in enumerate(native_arms):
        r = run_eval(name, native_topks=topks, capture=(name == "base"))
        res[name] = {k: v for k, v in r.items() if k in ("nll", "acc1")}
        if name == "base":
            cap = r
        if (ai + 1) % 8 == 0:
            np.savez_compressed(os.path.join(HERE, "%s_transfer_partial.npz" % tag),
                                **{("nll_" + k): v["nll"] for k, v in res.items()})

    # ---- 特徴 X（層内因果 2169 列）と W（窓集約 124 列）----
    log("[4/9] features")
    G_big, H_big = cap["G"], cap["H"]
    nll_base = res["base"]["nll"].astype(np.float64)
    ent = cap["ent"].astype(np.float64)
    t1a = res["base"]["acc1"].astype(np.float64)
    in_ids = cap["in_ids"]
    prev_nll = shift_within(nll_base, 1, nll_base.mean(), pos)
    prev_ent = shift_within(ent, 1, ent.mean(), pos)
    prev_t1 = shift_within(t1a, 1, t1a.mean(), pos)
    ma8 = movavg(nll_base, 8, nll_base.mean(), wi_arr)
    ma32 = movavg(nll_base, 32, nll_base.mean(), wi_arr)
    ma64 = movavg(nll_base, 64, nll_base.mean(), wi_arr)
    freq = np.zeros(n_tok)
    for w in np.unique(wi_arr):
        sel = np.where(wi_arr == w)[0]
        seen = {}
        for idx, tid in zip(sel, in_ids[sel]):
            seen[int(tid)] = seen.get(int(tid), 0) + 1
            freq[idx] = seen[int(tid)]
    freq = np.log1p(freq)
    hist = np.stack([prev_nll, prev_ent, prev_t1, ma8, ma32, ma64, freq,
                     pos, np.log1p(pos)], axis=1)
    nfeat = n_layers * FEAT_PER_LAYER + len(H_STRATA) * 256 + NHIST
    hcol0 = n_layers * FEAT_PER_LAYER
    hist_col = hcol0 + 256 * len(H_STRATA)
    X = np.zeros((n_tok, nfeat), dtype=np.float32)
    gstat_all = np.zeros((n_layers, n_tok, 7), dtype=np.float32)
    for l in range(n_layers):
        X[:, FEAT_PER_LAYER * l:FEAT_PER_LAYER * l + 64] = G_big[l]
        gs = gate_stats(G_big[l]).astype(np.float32)
        gstat_all[l] = gs
        X[:, FEAT_PER_LAYER * l + 64:FEAT_PER_LAYER * (l + 1)] = gs
    for si, s in enumerate(H_STRATA):
        X[:, hcol0 + 256 * si:hcol0 + 256 * (si + 1)] = H_big[si]
    X[:, hist_col:] = hist.astype(np.float32)

    nw = len(seqs)
    W_cols = []
    for l in range(n_layers):
        W_cols.append(gstat_all[l].reshape(n_tok, 7)[:, :].reshape(nw, n_eval, 7).mean(axis=1))
    W_gstat = np.concatenate(W_cols, axis=1)                     # (nw, 112)
    nll_w = nll_base.reshape(nw, n_eval)
    ent_w = ent.reshape(nw, n_eval)
    a1_w = t1a.reshape(nw, n_eval)
    W_stat = np.stack([
        nll_w.mean(1), nll_w.std(1), np.percentile(nll_w, 90, axis=1),
        nll_w.max(1), np.median(nll_w, axis=1),
        ent_w.mean(1), ent_w.std(1),
        a1_w.mean(1), a1_w.std(1),
        np.abs(np.diff(nll_w, axis=1)).mean(1) if n_eval > 1 else np.zeros(nw),
    ], axis=1)                                                   # (nw, 10)
    W_pos = np.stack([np.arange(nw) % max(1, nw // 2),
                      (lang == "ja").astype(np.float64)], axis=1)
    W = np.concatenate([W_gstat, W_stat, W_pos], axis=1).astype(np.float64)
    assert W.shape[1] == 124, W.shape

    # ---- ターゲット ----
    c8 = np.stack([res["ab7_%02d" % L]["nll"].astype(np.float64) - nll_base
                   for L in range(n_layers)])
    c7 = np.stack([res["ab6_%02d" % L]["nll"].astype(np.float64)
                   - res["ab7_%02d" % L]["nll"].astype(np.float64)
                   for L in range(n_layers)])
    d_j = res["u6"]["nll"].astype(np.float64) - nll_base
    Y = np.concatenate([c8.reshape(n_layers, nw, n_eval).mean(2).T,
                        c7.reshape(n_layers, nw, n_eval).mean(2).T], axis=1)   # (nw, 32)

    # ---- 予測器 ----
    log("[5/9] probes (per-token ridge 33 / window ridge+MLP LOO)")
    def cols_for_layer(L):
        cs = list(range(0, FEAT_PER_LAYER * (L + 1)))
        for si, s in enumerate(H_STRATA):
            if s <= L:
                cs += list(range(hcol0 + 256 * si, hcol0 + 256 * (si + 1)))
        cs += list(range(hist_col, nfeat))
        return np.array(cs)

    cols_tok = []
    for l in (0, 4, 8, 12, 15):
        cols_tok += list(range(FEAT_PER_LAYER * l, FEAT_PER_LAYER * (l + 1)))
    cols_tok += list(range(hcol0, nfeat))
    cols_tok = np.array(cols_tok)
    oof_tok, probe_q = {}, {}
    for L in range(n_layers):
        for nm, y, cs in (("c8_%02d" % L, c8[L], cols_for_layer(L)),
                          ("c7_%02d" % L, c7[L], cols_for_layer(L))):
            pred = cv_predict(X[:, cs].astype(np.float64), y, wi_arr, LAM)
            oof_tok[nm] = pred
            probe_q[nm] = {"spearman": spearman(y, pred),
                           "r2": 1.0 - float(((y - pred) ** 2).sum()
                                             / ((y - y.mean()) ** 2).sum())}
    oof_tok["d_j"] = cv_predict(X[:, cols_tok].astype(np.float64), d_j, wi_arr, LAM)
    probe_q["d_j"] = {"spearman": spearman(d_j, oof_tok["d_j"]),
                      "r2": 1.0 - float(((d_j - oof_tok["d_j"]) ** 2).sum()
                                        / ((d_j - d_j.mean()) ** 2).sum())}
    oof_tok_mat = np.stack([oof_tok["c8_%02d" % L] for L in range(n_layers)]
                           + [oof_tok["c7_%02d" % L] for L in range(n_layers)]
                           + [oof_tok["d_j"]], axis=1)

    pred_win_ridge = ridge_loo(W, Y)
    pred_win_mlp = mlp_loo(W, Y)
    win_q = {}
    for nm, pred in (("ridge", pred_win_ridge), ("mlp", pred_win_mlp)):
        win_q[nm] = {"spearman": [spearman(Y[:, j], pred[:, j]) for j in range(32)],
                     "r2": 1.0 - float(((Y - pred) ** 2).sum()
                                       / ((Y - Y.mean(0)) ** 2).sum())}
        log("      win %-6s R2 %.4f  mean|rho| %.4f"
            % (nm, win_q[nm]["r2"], np.mean(np.abs(win_q[nm]["spearman"]))))

    # C6 permutation（Y の行をシャッフル）
    perm = np.random.RandomState(PERM_SEED).permutation(nw)
    Yp = Y[perm]
    pr_ridge, pr_mlp = ridge_loo(W, Yp), mlp_loo(W, Yp)
    perm_q = {}
    for nm, pred in (("ridge", pr_ridge), ("mlp", pr_mlp)):
        perm_q[nm] = {"max_abs_rho": float(max(abs(spearman(Yp[:, j], pred[:, j]))
                                               for j in range(32)))}
        log("      perm %-6s max|rho| %.4f" % (nm, perm_q[nm]["max_abs_rho"]))

    np.savez_compressed(os.path.join(HERE, "%s_transfer_partial.npz" % tag),
                        **{("nll_" + k): v["nll"] for k, v in res.items()},
                        X=X, W=W, Y=Y, oof_tok=oof_tok_mat,
                        win_ridge=pred_win_ridge, win_mlp=pred_win_mlp,
                        wi=wi_arr.astype(np.int16))

    # ---- 決定 ----
    log("[6/9] decisions")
    ar_t = np.arange(n_tok)
    c8f, c7f = c8.astype(np.float32), c7.astype(np.float32)
    pc8 = oof_tok_mat[:, :n_layers].T.astype(np.float32)
    pc7 = oof_tok_mat[:, n_layers:2 * n_layers].T.astype(np.float32)

    def tok_decision(c7m, c8m):
        cut = np.argmin(c7m, axis=0).astype(np.int8)
        mask8 = c8m.copy()
        mask8[cut, ar_t] = -np.inf
        prot = np.argmax(mask8, axis=0).astype(np.int8)
        assert (cut != prot).all()
        km = np.full((n_layers, n_tok), 7, dtype=np.int8)
        km[cut, ar_t] = 6
        km[prot, ar_t] = 8
        return km, cut, prot

    km_tok_o, cut_tok_o, prot_tok_o = tok_decision(c7f, c8f)
    km_tok_r, cut_tok_r, prot_tok_r = tok_decision(pc7, pc8)

    def win_decision(P):
        """P: (nw, 32) の予測／真値。窓ごとに (cut, protect) を固定。"""
        cut = np.argmin(P[:, n_layers:], axis=1).astype(np.int8)
        Q = P[:, :n_layers].copy()
        Q[np.arange(nw), cut] = -np.inf
        prot = np.argmax(Q, axis=1).astype(np.int8)
        assert (cut != prot).all()
        km = np.full((n_layers, nw * ln), 7, dtype=np.int8)
        for w in range(nw):
            sl = slice(w * ln, (w + 1) * ln)
            km[cut[w], sl] = 6
            km[prot[w], sl] = 8
        return km, cut, prot

    km_win_o, cut_w_o, prot_w_o = win_decision(Y)
    km_win_r, cut_w_r, prot_w_r = win_decision(pred_win_ridge)
    km_win_m, cut_w_m, prot_w_m = win_decision(pred_win_mlp)
    rng_w = np.random.RandomState(RAND_WIN_SEED)
    cut_w_rand = rng_w.randint(0, n_layers, size=nw).astype(np.int8)
    draw = rng_w.randint(0, n_layers - 1, size=nw)
    prot_w_rand = (draw + (draw >= cut_w_rand)).astype(np.int8)
    km_win_rand = np.full((n_layers, nw * ln), 7, dtype=np.int8)
    for w in range(nw):
        sl = slice(w * ln, (w + 1) * ln)
        km_win_rand[cut_w_rand[w], sl] = 6
        km_win_rand[prot_w_rand[w], sl] = 8

    def topk_k(mat, f, lo=6, hi=8):
        out = np.full(mat.shape, lo, dtype=np.float32)
        m = int(round(f * mat.size))
        order = np.argsort(-mat.ravel())
        keep = np.zeros(mat.size, bool)
        keep[order[:m]] = True
        out.ravel()[keep] = hi
        return out

    dmat = d_j.astype(np.float32).reshape(nw, n_eval)
    kv_o = topk_k(dmat, 0.5)
    kv_p = topk_k(oof_tok["d_j"].astype(np.float32).reshape(nw, n_eval), 0.5)
    rng_t = np.random.RandomState(RAND_TOK_SEED)
    kv_r = topk_k(rng_t.rand(nw, n_eval).astype(np.float32), 0.5)

    def to_windows(kmat_eval=None, kvec=None, pad_val=7):
        if kvec is not None:
            kv = np.concatenate([kvec, np.full((nw, 1), pad_val, dtype=np.float32)], axis=1)
            km = np.tile(kv[None, :, :], (n_layers, 1, 1))
        else:
            km = kmat_eval.reshape(n_layers, nw, n_eval)
            km = np.concatenate([km, np.full((n_layers, nw, 1), pad_val,
                                            dtype=kmat_eval.dtype)], axis=2)
        return km.reshape(n_layers, nw * ln)

    mask_arms = [
        ("mask7", to_windows(kvec=np.full((nw, n_eval), 7, dtype=np.float32), pad_val=7)),
        ("lay_tok_oracle", to_windows(kmat_eval=km_tok_o, pad_val=7)),
        ("lay_tok_ridge", to_windows(kmat_eval=km_tok_r, pad_val=7)),
        ("lay_win_oracle", km_win_o),
        ("lay_win_ridge", km_win_r),
        ("lay_win_mlp", km_win_m),
        ("lay_win_random", km_win_rand),
        ("tok_oracle50", to_windows(kvec=kv_o, pad_val=6)),
        ("tok_probe50", to_windows(kvec=kv_p, pad_val=6)),
        ("tok_random50", to_windows(kvec=kv_r, pad_val=6)),
    ]
    for name, km in mask_arms:
        log("      %-18s mean_k %.6f" % (name, km.mean()))

    log("[7/9] mask forwards (%d arms)" % len(mask_arms))
    for name, km in mask_arms:
        r = run_eval(name, kmat_windows=km)
        res[name] = {k: v for k, v in r.items() if k in ("nll", "acc1")}

    # ---- 統計・校正 ----
    log("[8/9] stats / calibration")
    nll = {k: v["nll"].astype(np.float64) for k, v in res.items()}
    for k, v in res.items():
        assert v["nll"].shape == (n_tok,) and np.isfinite(v["nll"]).all() \
            and (v["nll"] >= 0).all(), "配列健全性 NG: %s" % k

    st1 = paired(nll["u7"] - nll["lay_tok_oracle"], nw, n_eval)
    st2 = paired(nll["u7"] - nll["lay_win_mlp"], nw, n_eval)
    st3 = paired(nll["tok_probe50"] - nll["lay_win_mlp"], nw, n_eval)
    to3 = tost(st3, DELTA_TOST)
    ph = holm({"W1": st1["p_two"], "W2": st2["p_two"], "W3": to3["p_tost"]})
    rej = {k: bool(ph[k] < ALPHA) for k in ph}
    g1, g2 = st1["mean"], st2["mean"]
    if rej["W2"] and g2 > 0 and not to3["equivalent"]:
        case = "A"
    elif rej["W2"] and g2 > 0 and to3["equivalent"]:
        case = "B"
    elif rej["W1"] and not rej["W2"] and to3["equivalent"]:
        case = "C"
    elif not rej["W1"]:
        case = "D"
    elif rej["W2"] and g2 < 0:
        case = "E"
    else:
        case = "UNLISTED"

    calib = {}
    d_c1 = res["base_rep"]["nll"].astype(np.float64) - res["base"]["nll"].astype(np.float64)
    calib["C1"] = {"maxdiff": float(np.abs(d_c1).max()), "meandiff": float(d_c1.mean()),
                   "tier": "A" if np.abs(d_c1).max() == 0.0 else "FAIL"}
    z2, z3 = np.load(FROZEN_AX2), np.load(FROZEN_AX3)
    ov = {lg: overlap8(z2[lg + "_ids"], z3[lg + "_ids"]) for lg in ("en", "ja")}
    calib["C2"] = {"overlap8_en": ov["en"], "overlap8_ja": ov["ja"],
                   "threshold": {"en": 0.05, "ja": 0.20},
                   "pass": bool(ov["en"] < 0.05 and ov["ja"] < 0.20)}
    d_c3 = res["mask7"]["nll"].astype(np.float64) - nll["u7"]
    calib["C3"] = {"meandiff": float(d_c3.mean()), "sd": float(d_c3.std(ddof=1)),
                   "maxdiff": float(np.abs(d_c3).max()),
                   "tier": "A'" if abs(d_c3.mean()) <= 0.002 else "FAIL"}
    calib["C4"] = {"n_arms": len(res), "n_tok": int(n_tok),
                   "lang_order_ok": bool(np.all(lang[:nw // 2] == "en")
                                         and np.all(lang[nw // 2:] == "ja"))}
    mean_k = {"base": 8.0, "base_rep": 8.0, "u7": 7.0, "u6": 6.0}
    for L in range(n_layers):
        mean_k["ab7_%02d" % L] = (15 * 8 + 7) / 16
        mean_k["ab6_%02d" % L] = (15 * 8 + 6) / 16
    for name, km in mask_arms:
        mean_k[name] = float(km.mean())
    exp_mk = dict(mean_k)
    m_half = int(round(0.5 * n_tok))
    exp_mk["tok_oracle50"] = exp_mk["tok_probe50"] = exp_mk["tok_random50"] = \
        (m_half * 2 + n_tok * 6 + nw * 6) / (n_tok + nw)
    exp_mk["mask7"] = 7.0
    for nm in ("lay_tok_oracle", "lay_tok_ridge", "lay_win_oracle", "lay_win_ridge",
               "lay_win_mlp", "lay_win_random"):
        exp_mk[nm] = 7.0
    mk_bad = {k: (v, exp_mk[k]) for k, v in mean_k.items() if abs(v - exp_mk[k]) > 1e-9}
    calib["C5"] = {"mean_k": mean_k, "expected": exp_mk, "n_bad": len(mk_bad), "bad": mk_bad}
    calib["C6"] = {"perm": perm_q,
                   "max_abs_rho": float(max(v["max_abs_rho"] for v in perm_q.values())),
                   "pass": bool(max(v["max_abs_rho"] for v in perm_q.values()) < 0.15)}
    calib["C7"] = {"win_conflict_oracle": int((cut_w_o == prot_w_o).sum()),
                   "win_conflict_ridge": int((cut_w_r == prot_w_r).sum()),
                   "win_conflict_mlp": int((cut_w_m == prot_w_m).sum()),
                   "cut_hist_mlp": np.bincount(cut_w_m, minlength=16).tolist(),
                   "prot_hist_mlp": np.bincount(prot_w_m, minlength=16).tolist(),
                   "cut_hist_oracle": np.bincount(cut_w_o, minlength=16).tolist()}

    results_arm = {}
    for k, v in res.items():
        results_arm[k] = {
            "ce": float(v["nll"].mean()), "top1": float(v["acc1"].mean()),
            "delta_vs_u7": float((v["nll"].astype(np.float64) - nll["u7"]).mean()),
            "mean_k": mean_k.get(k),
        }
    exploratory = {"gains": {}}
    for nm in ("lay_tok_oracle", "lay_tok_ridge", "lay_win_oracle", "lay_win_ridge",
               "lay_win_mlp", "lay_win_random", "tok_oracle50", "tok_probe50",
               "tok_random50", "mask7"):
        exploratory["gains"][nm] = paired(nll["u7"] - nll[nm], nw, n_eval)
    # 言語別（探索的）
    lang_tok = np.repeat(lang, n_eval)
    exploratory["by_lang"] = {}
    for lg in ("en", "ja"):
        sel = lang_tok == lg
        entry = {}
        for nm in ("lay_tok_oracle", "lay_win_mlp", "tok_probe50"):
            d = (nll["u7"] - nll[nm])[sel]
            se = float(d.std(ddof=1) / math.sqrt(d.size))
            entry[nm] = {"mean": float(d.mean()), "se": se,
                         "t": float(d.mean() / se) if se > 0 else float("nan"),
                         "n": int(d.size)}
        exploratory["by_lang"][lg] = entry
    exploratory["window_ridge_quality"] = win_q["ridge"]
    exploratory["window_mlp_quality"] = win_q["mlp"]
    exploratory["top1_abs_share_W2"] = st2["top1_abs_share"]
    exploratory["top1_abs_share_W1"] = st1["top1_abs_share"]

    out = {
        "meta": {"tag": tag, "smoke": bool(args.smoke), "windows": nw, "len": ln,
                 "n_tok": int(n_tok), "n_arms": len(res),
                 "design": "AX3課題設計書_別コーパスで文単位決定と非線形prefill特徴による反証_20261111.md",
                 "oof_tok_columns": ["c8_%02d" % L for L in range(n_layers)]
                                    + ["c7_%02d" % L for L in range(n_layers)] + ["d_j"]},
        "results": results_arm,
        "confirmatory": {"W1_lay_tok_oracle": st1, "W2_lay_win_mlp": st2,
                         "W3_diff": st3, "W3_tost": to3, "holm": ph,
                         "reject": rej, "case": case},
        "calib": calib, "probe_quality": probe_q, "exploratory": exploratory,
    }
    log("[9/9] save")
    with open(os.path.join(HERE, "%s_transfer.json" % tag), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    np.savez_compressed(
        os.path.join(HERE, "%s_transfer.npz" % tag),
        **{("nll_" + k): v["nll"] for k, v in res.items()},
        **{("acc1_" + k): v["acc1"] for k, v in res.items()},
        c8=c8, c7=c7, d_j=d_j, X=X, W=W, Y=Y,
        oof_tok=oof_tok_mat, win_ridge=pred_win_ridge, win_mlp=pred_win_mlp,
        perm_ridge=pr_ridge, perm_mlp=pr_mlp,
        wi=wi_arr.astype(np.int16), lang=lang,
        cut_tok_o=cut_tok_o, prot_tok_o=prot_tok_o,
        cut_tok_r=cut_tok_r, prot_tok_r=prot_tok_r,
        cut_w_o=cut_w_o, prot_w_o=prot_w_o, cut_w_r=cut_w_r, prot_w_r=prot_w_r,
        cut_w_m=cut_w_m, prot_w_m=prot_w_m,
        cut_w_rand=cut_w_rand, prot_w_rand=prot_w_rand)
    part = os.path.join(HERE, "%s_transfer_partial.npz" % tag)
    if os.path.exists(part):
        os.remove(part)

    log("")
    log("== confirmatory (Holm m=3, alpha=%.2f) ==" % ALPHA)
    log("W1 G_lay_tok_oracle %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
        % (g1, st1["t"], st1["p_two"], ph["W1"], st1["mde"]))
    log("W2 G_lay_win_mlp    %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
        % (g2, st2["t"], st2["p_two"], ph["W2"], st2["mde"]))
    log("W3 diff %+.8f  p_tost %.6g  holm %.6g  equiv %s  ci90 [%.8f, %.8f]"
        % (st3["mean"], to3["p_tost"], ph["W3"], to3["equivalent"],
           to3["ci90"][0], to3["ci90"][1]))
    log("case = %s" % case)
    log("calib: C1 %s  C2 %s (en %.4f / ja %.4f)  C3 %s  C5 bad %d  C6 %s"
        % (calib["C1"]["tier"], calib["C2"]["pass"], ov["en"], ov["ja"],
           calib["C3"]["tier"], calib["C5"]["n_bad"], calib["C6"]["pass"]))
    log("saved: %s_transfer.npz / .json" % tag)
    TEE.close()
    os._exit(0)


if __name__ == "__main__":
    main()
