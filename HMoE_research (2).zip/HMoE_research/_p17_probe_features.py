# -*- coding: utf-8 -*-
"""P17 診断: 「答えが出たか」を観測できる特徴はどれか（使い捨て）

各サンプルに GT を使わない特徴を計算し、正解との分離を測る。
  trunc    : ntok >= 96（P15/P16 の規則）
  boxed    : \\boxed{...} がある
  final    : "final answer" / "the answer is" / "the result is" を含む
  term     : 最後の数字列より後ろが空 or 句読点のみ
  closed   : 文末が . $ ) } のいずれか（閉じている）
  eqnum    : 最後の数字列の直前 3 文字以内に '='
  digok    : 抽出値の桁数が、問題のオペランドから導ける妥当範囲に入る（算術限定）
出力: _p17_features_out_utf8.txt / _p17_features.json
"""
import json
import os
import re

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = []
NUM_RE = re.compile(r"-?\d[\d,]*")


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def last_num_span(txt):
    ms = list(NUM_RE.finditer(txt))
    return ms[-1].span() if ms else None


def feats(txt, ntok, n_ans, pred, level, q):
    low = txt.lower()
    sp = last_num_span(txt)
    after = txt[sp[1]:].strip() if sp else None
    before = txt[max(0, sp[0] - 4):sp[0]] if sp else ""
    f = {
        "trunc": ntok >= 96,
        "boxed": bool(re.search(r"\\boxed\s*\{", txt)),
        "final": bool(re.search(r"final answer|the answer is|the result is|answer is", low)),
        "term": bool(after is not None and len(after) <= 2),
        "closed": txt.rstrip().endswith((".", "$", ")", "}", "$$")),
        "eqnum": "=" in before,
    }
    # 桁数の妥当範囲（**オペランドの桁だけから導く。gold は計算しない**）
    # 5 桁 + 5 桁 → 和は 5 or 6 桁 / 5 桁 − 5 桁（結果は正）→ 1〜5 桁 / 2 桁 × 2 桁 → 3 or 4 桁
    m = re.match(r"Compute (\d+) ([-+*]) (\d+)\.", q)
    if m and pred is not None and re.fullmatch(r"-?\d+", pred or ""):
        la, lb = len(m.group(1)), len(m.group(3))
        op = m.group(2)
        if op == "+":
            allowed = {la, la + 1} if la == lb else {max(la, lb), max(la, lb) + 1}
        elif op == "-":
            allowed = set(range(1, max(la, lb) + 1))
        else:                                   # 積: 桁数は la+lb-1 〜 la+lb
            allowed = {la + lb - 1, la + lb}
        f["digok"] = len(pred.lstrip("-")) in allowed
    else:
        f["digok"] = False
    return f


def main():
    rows = [json.loads(l) for l in open(os.path.join(HERE, "p17_runs.jsonl"),
                                        encoding="utf-8") if l.strip()]
    res = {}
    for lv in ["add5", "mul2"]:
        S = [(r, s) for r in rows if r["level"] == lv for s in r["samples"]]
        F = [feats(s["text"], s["ntok"], s["n_ans"], s["pred"], lv, r["q"]) for r, s in S]
        y = np.array([bool(s["correct"]) for r, s in S])
        tr = np.array([s["ntok"] >= 96 for r, s in S])
        log("\n=== %s === n=%d  correct=%d  truncated=%d" % (lv, len(S), y.sum(), tr.sum()))
        log("  %-8s %6s %8s %8s %8s %8s" %
            ("feature", "n", "P(c|1)", "P(c|0)", "recall", "prec"))
        for k in ["trunc", "boxed", "final", "term", "closed", "eqnum", "digok"]:
            v = np.array([f[k] for f in F])
            if v.sum() == 0:
                log("  %-8s %6d %8s %8s %8s %8s" % (k, 0, "-", "-", "-", "-"))
                continue
            p1 = y[v].mean()
            p0 = y[~v].mean() if (~v).sum() else float("nan")
            rec = v[y].mean() if y.sum() else float("nan")
            prec = p1
            log("  %-8s %6d %8.3f %8.3f %8.3f %8.3f" % (k, int(v.sum()), p1, p0, rec, prec))
        # 打ち切りの中だけ: どの特徴が正解を拾えるか
        idx = np.where(tr)[0]
        if len(idx):
            yt = y[idx]
            log("  --- truncated only (n=%d, correct=%d) ---" % (len(idx), yt.sum()))
            for k in ["boxed", "final", "term", "closed", "eqnum", "digok"]:
                v = np.array([F[i][k] for i in idx])
                if v.sum() == 0:
                    log("    %-8s n=0" % k)
                    continue
                log("    %-8s n=%-4d P(c|1)=%.3f  P(c|0)=%.3f"
                    % (k, int(v.sum()), yt[v].mean(),
                       yt[~v].mean() if (~v).sum() else float("nan")))
        # 完走の中だけ
        idx = np.where(~tr)[0]
        if len(idx):
            yt = y[idx]
            log("  --- complete only (n=%d, correct=%d) ---" % (len(idx), yt.sum()))
            for k in ["boxed", "final", "term", "closed", "eqnum", "digok"]:
                v = np.array([F[i][k] for i in idx])
                if v.sum() == 0:
                    log("    %-8s n=0" % k)
                    continue
                log("    %-8s n=%-4d P(c|1)=%.3f  P(c|0)=%.3f"
                    % (k, int(v.sum()), yt[v].mean(),
                       yt[~v].mean() if (~v).sum() else float("nan")))
        res[lv] = {"n": len(S), "correct": int(y.sum()), "truncated": int(tr.sum()),
                   "features": {k: int(sum(1 for f in F if f[k]))
                                for k in ["trunc", "boxed", "final", "term",
                                          "closed", "eqnum", "digok"]}}

    with open(os.path.join(HERE, "_p17_features.json"), "w", encoding="utf-8") as fp:
        json.dump(res, fp, ensure_ascii=False, indent=2)
    with open(os.path.join(HERE, "_p17_features_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    os._exit(0)


if __name__ == "__main__":
    main()
