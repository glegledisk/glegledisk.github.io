# -*- coding: utf-8 -*-
"""P20: thinking on で best-of-N の較正はどうなるか（P14 §9-2）

P14 は thinking off・cap 96 で測った。thinking on では生成が長くなり、
「答えが出たか」の判定が支配的になる（パイロット: cap 1024 で打ち切り 75%・acc 0.25、
cap 2048 で打ち切り 50%・acc 0.562）。本測定は cap 2048。

設計:
  16 問（P14/P9 と同一列の先頭 16）× 4 サンプル × 2 ラウンド = 128 サンプル
  T=0.9, top_p=0.95, max_new_tokens=2048, enable_thinking=True
  greedy 4 問（argmax-slack による採点規約の検査）

測るもの:
  打ち切り率 / 完走率 / \\boxed の有無 / "final answer" 句 / 答えの種類数
  正解率（サンプル・多数決・pass@N）/ 適格性規則ごとの被覆と精度
  p_ans（最後の数字列の幾何平均）/ p_full（生成全体の幾何平均）

出力: p20_think.jsonl / p20_meta.json
"""

import argparse
import json
import os
import random
import re

import numpy as np
import torch

from p14_bestofn import score_sample, extract_value

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "qwen3-0.6b")
SYS = "You are a careful arithmetic assistant. Solve the problem and give the final answer."
BOX_RE = re.compile(r"\\boxed\s*\{\s*(-?\d[\d,]*)\s*\}")
FIN_RE = re.compile(r"final answer|the answer is|the result is|answer is", re.I)


def log(m):
    print(m, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_prob", type=int, default=16)
    ap.add_argument("--n_samp", type=int, default=4)
    ap.add_argument("--rounds", type=int, default=2)
    ap.add_argument("--cap", type=int, default=2048)
    ap.add_argument("--seed", type=int, default=31)      # P14 と同じ問題列
    ap.add_argument("--n_greedy", type=int, default=4)
    ap.add_argument("--tag", type=str, default="p20")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer
    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    eos_id = tok.eos_token_id
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, torch_dtype=torch.bfloat16, device_map="cuda",
        attn_implementation="sdpa").eval()

    rnd = random.Random(args.seed)
    probs = []
    for _ in range(20):                                   # P14 と同じ 20 問を作って先頭を使う
        a, b = rnd.randint(10001, 99999), rnd.randint(10001, 99999)
        probs.append({"q": "Compute %d + %d." % (a, b), "gold": str(a + b)})
    probs = probs[:args.n_prob]
    log("problems: %d (5 桁加算, P14 の先頭 %d 問)" % (len(probs), args.n_prob))

    prompts = [tok.apply_chat_template(
        [{"role": "system", "content": SYS}, {"role": "user", "content": p["q"]}],
        tokenize=False, add_generation_prompt=True, enable_thinking=True) for p in probs]
    prompt_ids = [tok(pr, add_special_tokens=False)["input_ids"] for pr in prompts]

    recs = []
    for r_i in range(args.rounds):
        torch.manual_seed(args.seed + 100 + r_i)
        for i, p in enumerate(probs):
            enc = tok([prompts[i]] * args.n_samp, return_tensors="pt",
                      padding=True, add_special_tokens=False).to(model.device)
            with torch.no_grad():
                o = model.generate(**enc, max_new_tokens=args.cap, do_sample=True,
                                   temperature=0.9, top_p=0.95,
                                   pad_token_id=tok.pad_token_id)
            gen = o[:, enc["input_ids"].shape[1]:]
            samples = []
            for j in range(args.n_samp):
                ids = [t for t in gen[j].tolist() if t != tok.pad_token_id]
                txt = tok.decode(ids, skip_special_tokens=True)
                try:
                    sc = score_sample(model, tok, prompt_ids[i], txt, eos_id, ids_gen=ids)
                except Exception as e:                        # noqa: BLE001
                    sc = {"p_ans": None, "p_full": None, "n_ans": 0, "err": str(e)[:120],
                          "retok": None}
                pred = extract_value(txt)
                mbox = BOX_RE.findall(txt)
                box_val = mbox[-1].replace(",", "") if mbox else None
                samples.append({
                    "pred": pred, "box_val": box_val,
                    "correct": None if pred is None else (pred == p["gold"]),
                    "box_correct": None if box_val is None else (box_val == p["gold"]),
                    "p_ans": sc["p_ans"], "p_full": sc["p_full"], "n_ans": sc["n_ans"],
                    "err": sc["err"], "retok": sc["retok"], "ntok": len(ids),
                    "finished": len(ids) < args.cap,
                    "boxed": bool(mbox), "final_phr": bool(FIN_RE.search(txt)),
                    "text": txt})
            recs.append({"round": r_i, "q": p["q"], "gold": p["gold"], "samples": samples})
        log("round %d done" % r_i)

    # greedy（slack 検査）
    greedy = []
    torch.manual_seed(args.seed + 999)
    for i, p in enumerate(probs[:args.n_greedy]):
        enc = tok(prompts[i], return_tensors="pt",
                  add_special_tokens=False).to(model.device)
        with torch.no_grad():
            o = model.generate(**enc, max_new_tokens=args.cap, do_sample=False,
                               pad_token_id=tok.pad_token_id)
        ids = o[0, enc["input_ids"].shape[1]:].tolist()
        txt = tok.decode(ids, skip_special_tokens=True)
        try:
            sc = score_sample(model, tok, prompt_ids[i], txt, eos_id, ids_gen=ids, slack=True)
        except Exception as e:                                # noqa: BLE001
            sc = {"p_ans": None, "p_full": None, "n_ans": 0, "err": str(e)[:120],
                  "slack": None, "retok": None}
        pred = extract_value(txt)
        greedy.append({"round": "greedy", "q": p["q"], "gold": p["gold"], "pred": pred,
                       "correct": None if pred is None else (pred == p["gold"]),
                       "p_ans": sc["p_ans"], "p_full": sc["p_full"], "n_ans": sc["n_ans"],
                       "slack": sc["slack"], "ntok": len(ids),
                       "finished": len(ids) < args.cap,
                       "boxed": bool(BOX_RE.findall(txt)),
                       "final_phr": bool(FIN_RE.search(txt)), "text": txt})
    log("greedy arm done")

    sl = [g["slack"] for g in greedy if g.get("slack") is not None]
    log("greedy argmax-slack: mean=%.6f max=%.6f n=%d"
        % (float(np.mean(sl)), float(np.max(sl)), len(sl)))
    if float(np.mean(sl)) > 0.02:
        log("WARN: slack too large — scoring convention suspect")

    S = [s for r in recs for s in r["samples"]]
    meta = {"n_prob": len(probs), "n_samp": args.n_samp, "rounds": args.rounds,
            "cap": args.cap, "seed": args.seed, "thinking": True,
            "n_recs": len(recs), "n_samples": len(S), "n_greedy": len(greedy),
            "trunc_rate": float(np.mean([not s["finished"] for s in S])),
            "finished_rate": float(np.mean([s["finished"] for s in S])),
            "boxed_rate": float(np.mean([s["boxed"] for s in S])),
            "final_phrase_rate": float(np.mean([s["final_phr"] for s in S])),
            "acc_sample": float(np.mean([bool(s["correct"]) for s in S])),
            "median_ntok": float(np.median([s["ntok"] for s in S])),
            "slack": {"mean": float(np.mean(sl)), "max": float(np.max(sl))},
            "instrument": "score_sample imported from p14_bestofn.py",
            "model": MODEL}
    with open(os.path.join(HERE, "%s_think.jsonl" % args.tag), "w", encoding="utf-8") as fp:
        for r in recs:
            fp.write(json.dumps(r, ensure_ascii=False) + "\n")
        for g in greedy:
            fp.write(json.dumps(g, ensure_ascii=False) + "\n")
    with open(os.path.join(HERE, "%s_meta.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(meta, fp, ensure_ascii=False, indent=2)
    log(json.dumps(meta, ensure_ascii=False))
    os._exit(0)


if __name__ == "__main__":
    main()
