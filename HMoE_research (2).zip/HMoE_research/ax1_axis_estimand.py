# -*- coding: utf-8 -*-
"""AX1: put the token axis and the layer axis on ONE estimand.

Read-only re-analysis of saved per-token NLL arrays. No new forward passes.
Pre-registered in AX1課題設計書_両軸を同一estimandと同一予算で衝突させ軸分離を直接検定_20261111.md.

Outputs (all UTF-8 / machine readable):
  ax1_calib.json    C1..C7 calibration
  ax1_analysis.json confirmatory + exploratory statistics
  ax1_results.json  full result bundle (incl. verdict)
  ax1_delta.npz     per-token difference arrays for independent recomputation
  _ax1_summary.txt  human-readable digest
"""
import os
import json
import math
import numpy as np
from scipy import stats

ROOT = os.path.dirname(os.path.abspath(__file__))
N_EXPECT = 12240
N_WIN = 48
TOK_PER_WIN = 255
ALPHA = 0.05
DELTA_TOST = 0.01
SEED_CORPUS = 11

FILES = {
    "p3": "p3_topk_nll.npz",
    "p3b": "p3b_alloc_nll.npz",
    "p4": "p4_adaptive_nll.npz",
    "c8a": "p3c8a_topk_nll.npz",
    "c8b": "p3c8b_topk_nll.npz",
    "p24": "p24_layer_cost.npz",
}


def f64(z, key):
    a = np.asarray(z[key], dtype=np.float64).ravel()
    return a


def load_all():
    z = {}
    for tag, fn in FILES.items():
        path = os.path.join(ROOT, fn)
        if not os.path.exists(path):
            raise FileNotFoundError(fn)
        z[tag] = np.load(path, allow_pickle=False)
    return z


# ---------------------------------------------------------------- statistics
def paired(d, n_win=N_WIN, tok_per_win=TOK_PER_WIN):
    """paired per-token statistics. d is float64, shape (N,)."""
    d = np.asarray(d, dtype=np.float64).ravel()
    n = d.size
    m = float(d.mean())
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    t = m / se if se > 0 else float("nan")
    p_two = float(2.0 * stats.t.sf(abs(t), n - 1)) if se > 0 else float("nan")
    tcrit975 = float(stats.t.ppf(0.975, n - 1))
    tcrit95 = float(stats.t.ppf(0.95, n - 1))
    mde = tcrit975 * se
    ci95 = [m - tcrit975 * se, m + tcrit975 * se]
    ci90 = [m - tcrit95 * se, m + tcrit95 * se]

    # window-level conservative sensitivity: 48 windows x 255 tokens
    wm = d.reshape(n_win, tok_per_win).mean(axis=1)
    se_win = float(wm.std(ddof=1) / math.sqrt(n_win))
    t_win = m / se_win if se_win > 0 else float("nan")
    p_win = float(2.0 * stats.t.sf(abs(t_win), n_win - 1)) if se_win > 0 else float("nan")

    # tails
    srt = np.sort(np.abs(d))[::-1]
    k1 = max(1, int(math.ceil(0.01 * n)))
    top1_abs = float(srt[:k1].sum() / srt.sum())
    signed_sum = float(d.sum())
    idx = np.argsort(np.abs(d))[::-1][:k1]
    top1_signed = float(d[idx].sum() / signed_sum) if signed_sum != 0 else float("nan")

    return {
        "mean": m, "sd": sd, "se": se, "t": t, "p_two": p_two,
        "n": int(n), "df": int(n - 1), "mde": mde,
        "ci95": ci95, "ci90": ci90,
        "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
        "n_zero": int((d == 0).sum()),
        "median": float(np.median(d)), "min": float(d.min()), "max": float(d.max()),
        "se_win": se_win, "t_win": t_win, "p_win_two": p_win,
        "top1_abs_share": top1_abs, "top1_signed_share": top1_signed,
    }


def tost(st, delta):
    """TOST for H0: |mean| >= delta. Returns p_tost, p_low, p_high, equivalent."""
    m, se, df = st["mean"], st["se"], st["df"]
    p_low = float(stats.t.sf((m + delta) / se, df))     # reject mu <= -delta
    p_high = float(stats.t.cdf((m - delta) / se, df))   # reject mu >= +delta
    p_tost = max(p_low, p_high)
    lo, hi = st["ci90"]
    equivalent = bool((p_tost < ALPHA) and (lo > -delta) and (hi < delta))
    return {"delta": delta, "p_low": p_low, "p_high": p_high,
            "p_tost": p_tost, "ci90": [lo, hi], "equivalent": equivalent}


def holm(pvals):
    """Holm step-down. pvals: dict id -> p. Returns dict id -> adjusted p."""
    ids = sorted(pvals, key=lambda k: pvals[k])
    m = len(ids)
    out, running = {}, 0.0
    for i, key in enumerate(ids):
        val = (m - i) * pvals[key]
        running = max(running, val)
        out[key] = min(1.0, running)
    return out


# ---------------------------------------------------------------- calibration
def calibrate(z, A):
    calib, checks = {}, []

    def add(cid, ok, detail):
        checks.append({"id": cid, "pass": bool(ok), "detail": detail})

    def maxdiff(a, b):
        return float(np.max(np.abs(a - b)))

    E, U, C6 = A["E"], A["U"], A["C6"]

    c1 = {
        "p3b_base": maxdiff(E, A["base"]),
        "c8a_k8": maxdiff(E, A["c8a_k8"]),
        "c8b_k8": maxdiff(E, A["c8b_k8"]),
        "p3rs2_k8": maxdiff(E, A["rs2_k8"]),
    }
    add("C1", all(v == 0.0 for v in c1.values()), c1)
    calib["C1_baseline_k8"] = c1

    c2 = {
        "p3b_u7": maxdiff(U, A["u7"]),
        "p4_uniform7": maxdiff(U, A["uniform7"]),
    }
    add("C2", all(v == 0.0 for v in c2.values()), c2)
    calib["C2_uniform_k7"] = c2

    c3 = {"p4_uniform6": maxdiff(C6, A["uniform6"])}
    add("C3", all(v == 0.0 for v in c3.values()), c3)
    calib["C3_uniform_k6"] = c3

    # C4: reproduce published numbers
    def near(x, y, tol):
        return bool(abs(float(x) - float(y)) <= tol)

    d_f2_u7 = paired(A["F2"] - U)
    d_tp_u7 = paired(A["T_p"] - U)
    d_to_u7 = paired(A["T_o"] - U)
    quart = quartile_ratio(E, U - E)
    c4 = {
        "ce_k8": {"observed": float(E.mean()), "expected": 2.60046935,
                  "pass": near(E.mean(), 2.60046935, 1e-5)},
        "ce_u7": {"observed": float(U.mean()), "expected": 2.61495519,
                  "pass": near(U.mean(), 2.61495519, 1e-5)},
        "f6b8_minus_u7": {"observed": d_f2_u7["mean"], "expected": 0.00266,
                          "pass": near(d_f2_u7["mean"], 0.00266, 1e-4)},
        "f6b8_minus_u7_se": {"observed": d_f2_u7["se"], "expected": 0.00219,
                             "pass": near(d_f2_u7["se"], 0.00219, 1e-4)},
        "f6b8_minus_u7_t": {"observed": d_f2_u7["t"], "expected": 1.22,
                            "pass": near(d_f2_u7["t"], 1.22, 0.05)},
        "probe50_minus_u7": {"observed": d_tp_u7["mean"], "expected": 0.00310,
                             "pass": near(d_tp_u7["mean"], 0.00310, 1e-4)},
        "oracle50_minus_u7": {"observed": d_to_u7["mean"], "expected": -0.05252,
                              "pass": near(d_to_u7["mean"], -0.05252, 1e-4)},
        "p3_quartile_ratio": {"observed": quart["ratio_q4_q1"],
                              "expected": 21.5,
                              "pass": near(quart["ratio_q4_q1"], 21.5, 0.5)},
    }
    add("C4", all(v["pass"] for v in c4.values()), c4)
    calib["C4_published_values"] = c4

    # C5: array sanity
    names = ["E", "U", "C6", "F1", "B1", "F2", "B2", "T_o", "T_p", "T_r"]
    bad = {}
    for nm in names:
        a = A[nm]
        ok = (a.shape == (N_EXPECT,) and np.isfinite(a).all() and (a >= 0).all())
        if not ok:
            bad[nm] = {"shape": list(a.shape),
                       "n_nan": int(np.isnan(a).sum()),
                       "n_neg": int((a < 0).sum())}
    langs = {}
    for tag, zz in z.items():
        if "lang" in zz.files:
            langs[tag] = np.asarray(zz["lang"]).tolist()
    lang_ok = len(set(map(tuple, langs.values()))) == 1 and all(
        len(v) == N_WIN for v in langs.values())
    add("C5", len(bad) == 0 and lang_ok,
        {"bad_arrays": bad, "lang_identical": lang_ok,
         "lang_len": {k: len(v) for k, v in langs.items()}})
    calib["C5_sanity"] = {"bad_arrays": bad, "lang_identical": lang_ok}

    # C6: budget accounting
    summ_path = os.path.join(ROOT, "p3b_alloc_summary.json")
    slots = {}
    if os.path.exists(summ_path):
        with open(summ_path, "r", encoding="utf-8") as f:
            summ = json.load(f)
        for lab in ("u7", "f6b8", "f8b6"):
            slots[lab] = summ.get("results", {}).get(lab, {}).get("slots_saved")
    p4res_path = os.path.join(ROOT, "p4_adaptive_results.json")
    p4_mean_k = None
    if os.path.exists(p4res_path):
        with open(p4res_path, "r", encoding="utf-8") as f:
            p4res = json.load(f)
        p4_mean_k = p4res.get("mean_k")
    budget_ok = all(v == 16.0 for v in slots.values()) and len(slots) == 3
    calib["C6_budget"] = {"slots_saved": slots, "all_16": budget_ok,
                          "p4_mean_k_file": p4_mean_k,
                          "published_mean_k": {"probe50": 6.996,
                                               "oracle50": 6.996,
                                               "random50": 6.996}}
    add("C6", budget_ok, calib["C6_budget"])

    # C7: P24 corpus mismatch (record only; must NOT enter the analysis)
    d24 = maxdiff(E, A["p24_base"])
    calib["C7_p24_mismatch"] = {
        "p24_base_ce": float(A["p24_base"].mean()),
        "p3_k8_ce": float(E.mean()),
        "maxdiff": d24, "excluded_from_analysis": True,
    }
    add("C7", d24 > 0.0 and A["p24_base"] is not None, calib["C7_p24_mismatch"])

    calib["checks"] = checks
    calib["all_pass"] = bool(all(c["pass"] for c in checks))
    return calib, d_f2_u7, d_tp_u7, d_to_u7, quart


def quartile_ratio(baseline, delta):
    """P3-style quartile split (rank based, 3060 tokens each) + 2-way split."""
    order = np.argsort(baseline, kind="stable")
    groups = np.array_split(order, 4)
    q = [float(delta[g].mean()) for g in groups]
    halves = np.array_split(order, 2)
    h = [float(delta[g].mean()) for g in halves]
    return {
        "q1": q[0], "q2": q[1], "q3": q[2], "q4": q[3],
        "ratio_q4_q1": (q[3] / q[0]) if q[0] != 0 else float("nan"),
        "low_half": h[0], "high_half": h[1],
        "ratio_halves": (h[1] / h[0]) if h[0] != 0 else float("nan"),
        "group_sizes": [int(g.size) for g in groups],
    }


# ---------------------------------------------------------------- main
def main():
    z = load_all()
    A = {
        "E": f64(z["p3"], "k8"),
        "U": f64(z["p3"], "k7"),
        "C6": f64(z["p3"], "k6"),
        "base": f64(z["p3b"], "base"),
        "u7": f64(z["p3b"], "u7"),
        "F2": f64(z["p3b"], "f6b8"),
        "B2": f64(z["p3b"], "f8b6"),
        "uniform6": f64(z["p4"], "uniform6"),
        "uniform7": f64(z["p4"], "uniform7"),
        "T_o": f64(z["p4"], "oracle50"),
        "T_p": f64(z["p4"], "probe50"),
        "T_r": f64(z["p4"], "random50"),
        "F1": f64(z["c8a"], "k7"),
        "B1": f64(z["c8b"], "k7"),
        "c8a_k8": f64(z["c8a"], "k8"),
        "c8b_k8": f64(z["c8b"], "k8"),
        "p24_base": f64(z["p24"], "nll_base"),
    }
    rs2 = np.load(os.path.join(ROOT, "p3rs2_topk_nll.npz"), allow_pickle=False)
    A["rs2_k8"] = f64(rs2, "k8")

    calib, d_f2_u7, d_tp_u7, d_to_u7, quart = calibrate(z, A)

    E, U, C6 = A["E"], A["U"], A["C6"]
    F1, B1, F2, B2 = A["F1"], A["B1"], A["F2"], A["B2"]
    T_o, T_p, T_r = A["T_o"], A["T_p"], A["T_r"]

    # signal-free controls: analytic expectations (deterministic, symmetric)
    R_tok = 0.5 * (C6 + E)
    R_lay = 0.5 * (F2 + B2)

    # layer-axis true-cost oracle: select with INDEPENDENT 1-slot measurements
    cf, cb = F1 - E, B1 - E
    choose_front = cf < cb
    L_o = np.where(choose_front, F2, B2)

    # estimands
    d_AX = (R_tok - T_o) - (R_lay - L_o)
    d_AX_feas = T_p - F2
    S_tok_arr = R_tok - T_o
    S_lay_arr = R_lay - L_o

    st = {
        "AX": paired(d_AX),
        "AX_feas": paired(d_AX_feas),
        "S_tok": paired(S_tok_arr),
        "S_lay": paired(S_lay_arr),
        "G_tok_oracle": paired(T_o - U),
        "G_tok_probe": paired(T_p - U),
        "G_tok_random": paired(R_tok - U),
        "G_tok_random_realized": paired(T_r - U),
        "G_lay_oracle": paired(L_o - U),
        "G_lay_static_best": paired(F2 - U),
        "G_lay_worst": paired(B2 - U),
        "G_lay_random": paired(R_lay - U),
        "J_delta": paired((R_tok - U) - (R_lay - U)),
        "R_tok_vs_T_r": paired(R_tok - T_r),
        "F1_cost": paired(cf),
        "B1_cost": paired(cb),
        "F2_vs_B2": paired(F2 - B2),
        "layer_additivity": paired((cf + cb) - (U - E)),
        "AX_using_realized_random": paired((T_r - T_o) - (R_lay - L_o)),
        "AX_feas_vs_worst": paired(T_p - B2),
    }

    # confirmatory family (Holm m=3)
    T1 = {"id": "T1", "estimand": "AX", "h0": "AX = 0",
          "p": st["AX"]["p_two"], **st["AX"]}
    T2 = {"id": "T2", "estimand": "AX_feas", "h0": "AX_feas = 0",
          "p": st["AX_feas"]["p_two"], **st["AX_feas"]}
    t3 = tost(st["AX_feas"], DELTA_TOST)
    T3 = {"id": "T3", "estimand": "AX_feas", "h0": "abs(AX_feas) >= delta",
          "p": t3["p_tost"], **t3}
    adj = holm({"T1": T1["p"], "T2": T2["p"], "T3": T3["p"]})
    family = {"alpha": ALPHA, "m": 3, "holm": adj,
              "T1": {**T1, "p_holm": adj["T1"], "reject": bool(adj["T1"] < ALPHA)},
              "T2": {**T2, "p_holm": adj["T2"], "reject": bool(adj["T2"] < ALPHA)},
              "T3": {**T3, "p_holm": adj["T3"], "reject": bool(adj["T3"] < ALPHA)}}
    # TOST requires BOTH p and CI (design doc §4)
    family["T3"]["reject"] = bool(t3["p_tost"] < ALPHA and t3["equivalent"])
    family["T3"]["ci_requirement_met"] = bool(t3["equivalent"])

    delta_sens = {str(d): tost(st["AX_feas"], d)
                  for d in (0.05, 0.0106, 0.01, 0.005)}

    # verdict
    if not calib["all_pass"]:
        case = "D"
    elif family["T1"]["reject"] and st["AX"]["mean"] > 0 and family["T3"]["reject"]:
        case = "A"
    elif family["T1"]["reject"] and st["AX"]["mean"] > 0:
        case = "B"
    else:
        case = "C"

    verdict = {
        "case": case,
        "calibration_all_pass": bool(calib["all_pass"]),
        "claim_permitted": bool(case in ("A", "B", "C")),
        "z1_rule3_still_forbidden": True,
        "reserved_1_retired": False,
        "claim_text": {
            "A": "回収可能な信号の量には軸分離があり、実装可能な配分では両軸は 0.01 nats 以内で等価",
            "B": "軸分離は oracle 領域で検出され、実装可能領域は未決着",
            "C": "軸分離はこの N と se では検出できず",
            "D": "校正不合格のため解釈不能",
        }[case],
        "forbidden": ["中心命題が確認された", "中心命題が偽",
                      "差が無い", "層方向は効かない（一般則）"],
    }

    exploratory = {
        "quartiles": quart,
        "spearman_E_vs_1slot": float(stats.spearmanr(E, U - E).statistic),
        "spearman_E_vs_2slot": float(stats.spearmanr(E, C6 - E).statistic),
        "layer_cost_ratio_back_front": float(cb.mean() / cf.mean()),
        "L_o_front_selection_rate": float(choose_front.mean()),
        "L_o_front_count": int(choose_front.sum()),
        "L_o_back_count": int((~choose_front).sum()),
        "convexity_rho_from_P3b": 2.44,
        "jensen_penalty_token": st["G_tok_random"]["mean"],
        "jensen_penalty_layer": st["G_lay_random"]["mean"],
        "delta_jensen": st["J_delta"]["mean"],
        "R_tok_ce": float(R_tok.mean()),
        "R_lay_ce": float(R_lay.mean()),
        "L_o_ce": float(L_o.mean()),
        "p4_recovered_signal": float(st["G_tok_random_realized"]["mean"]
                                     - st["G_tok_oracle"]["mean"]),
        "seed_corpus": SEED_CORPUS,
        "n_windows": N_WIN,
        "tokens_per_window": TOK_PER_WIN,
        "new_forward_passes": 0,
    }

    analysis = {
        "series": "AX1",
        "design_doc": "AX1課題設計書_両軸を同一estimandと同一予算で衝突させ軸分離を直接検定_20261111.md",
        "estimand_primary": "AX = S_tok - S_lay = mean_t[(R_tok-T_o)-(R_lay-L_o)]",
        "n_tokens": N_EXPECT,
        "confirmatory": family,
        "delta_sensitivity_T3": delta_sens,
        "statistics": st,
        "exploratory": exploratory,
        "verdict": verdict,
    }

    # save
    def dump(name, obj):
        with open(os.path.join(ROOT, name), "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=True)

    dump("ax1_calib.json", calib)
    dump("ax1_analysis.json", analysis)
    dump("ax1_results.json", {
        "series": "AX1", "verdict": verdict,
        "confirmatory": family, "statistics": st,
        "exploratory": exploratory, "calibration": calib,
        "source_files": FILES,
    })
    np.savez_compressed(
        os.path.join(ROOT, "ax1_delta.npz"),
        E=E, U=U, C6=C6, F1=F1, B1=B1, F2=F2, B2=B2,
        T_o=T_o, T_p=T_p, T_r=T_r,
        R_tok=R_tok, R_lay=R_lay, L_o=L_o,
        cf=cf, cb=cb, choose_front=choose_front.astype(np.uint8),
        d_AX=d_AX, d_AX_feas=d_AX_feas,
        S_tok=S_tok_arr, S_lay=S_lay_arr,
    )

    lines = ["=== AX1 SUMMARY ===",
             "calibration all_pass=%s (%d checks)" %
             (calib["all_pass"], len(calib["checks"]))]
    for c in calib["checks"]:
        lines.append("  %s %s" % (c["id"], "PASS" if c["pass"] else "FAIL"))
    lines.append("case=%s  claim=%s" % (case, verdict["claim_text"]))
    for key in ("T1", "T2", "T3"):
        f = family[key]
        lines.append("  %s: mean=%.8f se=%.8f t=%.4f p=%.8g p_holm=%.8g reject=%s MDE=%.8f" %
                     (key, f.get("mean", float("nan")), f.get("se", float("nan")),
                      f.get("t", float("nan")), f["p"], f["p_holm"],
                      f["reject"], f.get("mde", float("nan"))))
    lines.append("  T3 TOST delta=%.5f p_tost=%.8g equivalent=%s" %
                 (DELTA_TOST, t3["p_tost"], t3["equivalent"]))
    lines.append("S_tok=%.8f  S_lay=%.8f  AX=%.8f  AX_feas=%.8f" %
                 (st["S_tok"]["mean"], st["S_lay"]["mean"],
                  st["AX"]["mean"], st["AX_feas"]["mean"]))
    lines.append("J_tok=%.8f  J_lay=%.8f  dJ=%.8f" %
                 (st["G_tok_random"]["mean"], st["G_lay_random"]["mean"],
                  st["J_delta"]["mean"]))
    lines.append("L_o front rate=%.6f  quartile ratio=%.4f  halves ratio=%.4f" %
                 (exploratory["L_o_front_selection_rate"],
                  quart["ratio_q4_q1"], quart["ratio_halves"]))
    lines.append("spearman(E,1slot)=%.6f  spearman(E,2slot)=%.6f" %
                 (exploratory["spearman_E_vs_1slot"],
                  exploratory["spearman_E_vs_2slot"]))
    lines.append("window se: AX=%.8f  AX_feas=%.8f" %
                 (st["AX"]["se_win"], st["AX_feas"]["se_win"]))
    with open(os.path.join(ROOT, "_ax1_summary.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n".join(lines[:8]))
    print("AX1 done: case=%s" % case)


if __name__ == "__main__":
    main()
