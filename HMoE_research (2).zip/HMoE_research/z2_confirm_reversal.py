#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Z2: Z1 が見つけた等 MACs 対角の逆方向の差を、独立確認標本で検定する。

事前登録: `Z2課題設計書_逆方向の差を片側優位と非劣性で独立標本36seedで確認する_20261108.md`
（追記 21:00 を含む）。仮説・δ・n・Holm・判定規則はすべて実行前に固定。

Δ = ce_seq(H_1024) - ce_seq(U_688)。正なら H が悪い。
  主検定: H0: Δ <= 0        対 H1: Δ > 0        （片側優位、delta_sup = 0）
  副検定: H0: Δ >= 0.05     対 H1: Δ < 0.05     （非劣性、delta_NI = 0.05）
Holm m = 2。主解析は新規 seed 24..59 の 36 個だけ。Z1 の 0..23 は
校正・ビット再現・探索的プール解析に限定し、確認的統計量には混ぜない。

出力: z2_results.json / z2_delta.npz / z2_analysis.json / z2_calib.json /
      z2_train.json / z2_out_utf8.txt / simulation_hmoe_mmlu/data/z2/ckpt_*.pt
"""
import argparse
import hashlib
import json
import math
import os
import sys
import time

import numpy as np
import torch
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# Z1 のハーネスをそのまま流用（腕・幅・訓練 backend・評価器・校正 129 項目）
import z1_p2_seed_extension as Z1            # noqa: E402

Q2, Q8 = Z1.Q2, Z1.Q8
assert Z1.Y1.E2.SEQ == 128

W2DIR, Y1DIR, Z1DIR = Z1.W2DIR, Z1.Y1DIR, Z1.Z1DIR
Z2DIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "z2")
Z2SMOKEDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "z2_smoke")
ACTIVE_Z2DIR = Z2DIR

ARMS = ("H_1024", "U_688")
ORACLE_ARMS = tuple(f"oracle_{a}" for a in ARMS)
ALL_ARMS = ARMS + ORACLE_ARMS
SEEDS_DISCOVERY = tuple(range(24))
SEEDS_CONFIRM = tuple(range(24, 60))
SEEDS_SMOKE = tuple(range(8))
SEEDS_ALL = tuple(range(60))

MARGIN_NI = 0.05
MARGIN_STRICT = 0.04141674564862646   # Z1 / Y1 の MDE（探索的感度）
MARGIN_WIDE = 0.06                    # Z1 事後候補（探索的感度）
REF_IV = 0.1467
ALPHA = 0.05
EVAL_SEED, EVAL_SEED_ROB, N_EVAL = 777, 778, 1024
EPOCHS = 6
TRAIN_LOG = os.path.join(HERE, "z2_train.json")

assert Z1.NPARAM_EXPECT["H_1024"] == 1346877
assert Z1.NPARAM_EXPECT["U_688"] == 1001469
assert len(SEEDS_CONFIRM) == 36


# ---------------------------------------------------------------------------
# ckpt の 4 出所を明示する（seed 0..7 は W2/Y1、8..23 は Z1、24..59 は Z2）
# ---------------------------------------------------------------------------
def ckpt_path(arch, seed, active_dir=None):
    if arch not in ARMS:
        raise ValueError(f"未登録の腕: {arch}")
    if seed in SEEDS_DISCOVERY:
        if seed < 8:
            if arch == "H_1024":
                return os.path.join(W2DIR, f"ckpt_H_s{seed}.pt")
            return os.path.join(Y1DIR, f"ckpt_U_688_s{seed}.pt")
        return os.path.join(Z1DIR, f"ckpt_{arch}_s{seed}.pt")
    if seed not in SEEDS_CONFIRM:
        raise ValueError(f"未登録の seed: {seed}")
    return os.path.join(active_dir or ACTIVE_Z2DIR, f"ckpt_{arch}_s{seed}.pt")


def load_arch(arch, seed, active_dir=None):
    path = ckpt_path(arch, seed, active_dir)
    td = torch.load(path, map_location="cpu")
    model = Z1.build_model(arch, seed)
    assert set(td.keys()) == set(model.p.keys()), f"{arch} s{seed}: ckpt キー不一致"
    for kk in td:
        assert tuple(td[kk].shape) == tuple(model.p[kk].shape), \
            f"{arch} s{seed}: {kk} の形が違う"
    clean = {k: v.detach().clone() for k, v in td.items()}
    return model, clean


def fingerprint(path):
    """ckpt の軽量フィンガープリント（全テンソル先頭 64 float ずつ）。"""
    td = torch.load(path, map_location="cpu")
    h = hashlib.sha256()
    for k in sorted(td.keys()):
        h.update(k.encode("utf-8"))
        v = np.ascontiguousarray(
            td[k].detach().cpu().numpy(), dtype="<f4").reshape(-1)[:64]
        h.update(v.tobytes())
    return h.hexdigest()


def calibration_c6(seq, typ, active_dir, log):
    """本次 evaluator の seed 0..7 の P2 配列が y1_delta.npz と全要素一致するか。"""
    yd = np.load(os.path.join(HERE, "y1_delta.npz"), allow_pickle=True)
    yarms = [str(x) for x in yd["arms"]]
    yseed = [int(x) for x in yd["seeds"]]
    yh, yu = yarms.index("H_1024"), yarms.index("U_688")
    cols = [yseed.index(s) for s in SEEDS_SMOKE]
    ce = {a: [] for a in ARMS}
    iv = {a: [] for a in ARMS}
    for s in SEEDS_SMOKE:
        for arch in ARMS:
            model, clean = load_arch(arch, s, active_dir)
            Z1.fresh(model, clean)
            m, x = Z1.evaluate(model, seq, typ)
            ce[arch].append(x["ce_seq"])
            iv[arch].append(m["instr_valid"])
    d_ce = np.asarray(ce["H_1024"]) - np.asarray(ce["U_688"])
    d_iv = np.asarray(iv["H_1024"]) - np.asarray(iv["U_688"])
    ref_ce = yd["ce_seq"][yh][cols] - yd["ce_seq"][yu][cols]
    ref_iv = yd["iv"][yh][cols] - yd["iv"][yu][cols]
    out = {"n_seed": len(SEEDS_SMOKE),
           "n_values": int(d_ce.size + d_iv.size),
           "max_abs_ce_seq": float(np.abs(d_ce - ref_ce).max()),
           "max_abs_iv": float(np.abs(d_iv - ref_iv).max()),
           "bit_match": bool(np.abs(d_ce - ref_ce).max() < 1e-12 and
                             np.abs(d_iv - ref_iv).max() < 1e-12)}
    log(f"C6: {out}")
    return out


def calibration_c7(new_seeds, active_dir, log):
    """新規 ckpt が既存 24 ckpt（腕ごと）のいずれとも一致しないこと。"""
    existing = {}
    for arch in ARMS:
        existing[arch] = {fingerprint(ckpt_path(arch, s, active_dir))
                          for s in SEEDS_DISCOVERY}
    newfp = {a: set() for a in ARMS}
    collisions = []
    for s in new_seeds:
        for arch in ARMS:
            fp = fingerprint(ckpt_path(arch, s, active_dir))
            if fp in existing[arch]:
                collisions.append(f"{arch}_s{s}")
            newfp[arch].add(fp)
    n_new = len(new_seeds) * len(ARMS)
    n_unique = sum(len(v) for v in newfp.values())
    out = {"n_new_ckpt": n_new, "n_existing_per_arm": len(SEEDS_DISCOVERY),
           "n_unique_fingerprints": n_unique,
           "duplicate_within_new": int(n_new - n_unique),
           "collisions_with_existing": collisions,
           "bit_match": bool(not collisions and n_new == n_unique)}
    log(f"C7: {out}")
    return out


# ---------------------------------------------------------------------------
# 検定（設計書 §5）
# ---------------------------------------------------------------------------
def sup_and_ni(r, margin=MARGIN_NI):
    """片側優位 p_sup と非劣性 p_NI（同じ paired 結果から）。"""
    p_sup = float(stats.t.sf(r["delta"] / r["se"], r["df"]))
    p_ni = float(stats.t.cdf((r["delta"] - margin) / r["se"], r["df"]))
    return {"margin": float(margin), "p_sup": p_sup, "p_ni": p_ni,
            "upper95": r["ci90"][1],
            "sup_reject_raw": bool(p_sup < ALPHA),
            "ni_reject_raw": bool(p_ni < ALPHA and r["ci90"][1] < margin)}


def confirm(d, margin=MARGIN_NI):
    r = Z1.paired(d)
    sn = sup_and_ni(r, margin)
    holm = Z1.holm2([("sup", sn["p_sup"]), ("ni", sn["p_ni"])])
    sup_rej = bool(holm["sup"]["p_holm"] < ALPHA)
    ni_rej = bool(holm["ni"]["p_holm"] < ALPHA)
    if sup_rej and ni_rej:
        case = "A"
    elif sup_rej:
        case = "B"
    elif ni_rej:
        case = "C"
    else:
        case = "D"
    return {"paired": r, "test": sn, "holm": holm,
            "sup_reject": sup_rej, "ni_reject": ni_rej, "case": case}


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=list(SEEDS_CONFIRM))
    ap.add_argument("--train_seeds", nargs="+", type=int,
                    default=list(SEEDS_CONFIRM))
    ap.add_argument("--tag", default="z2")
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--n_eval", type=int, default=N_EVAL)
    ap.add_argument("--epochs", type=int, default=EPOCHS)
    ap.add_argument("--reuse", action="store_true")
    ap.add_argument("--train_only", action="store_true")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--no_repro", action="store_true")
    args = ap.parse_args()

    global ACTIVE_Z2DIR
    ACTIVE_Z2DIR = Z2SMOKEDIR if args.smoke else Z2DIR
    train_log = os.path.join(HERE, "z2_smoke_train.json") \
        if args.smoke else TRAIN_LOG
    if args.smoke:
        args.seeds = list(SEEDS_SMOKE)
        args.train_seeds = [24]
        args.epochs = 1
    torch.set_num_threads(args.threads)
    torch.manual_seed(12345)

    tag = args.tag
    LOG = os.path.join(HERE, f"{tag}_out_utf8.txt")
    if os.path.exists(LOG):
        os.remove(LOG)

    def log(msg):
        print(msg, flush=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")

    for s in args.seeds:
        assert s in SEEDS_ALL, f"未登録の評価 seed: {s}"
    for s in args.train_seeds:
        assert s in SEEDS_CONFIRM, f"未登録の訓練 seed: {s}"
    log(f"Z2: threads={args.threads} arms={list(ALL_ARMS)} "
        f"eval_seeds={len(args.seeds)} train_seeds={len(args.train_seeds)} "
        f"n_eval={args.n_eval} epochs={args.epochs} reuse={args.reuse} "
        f"train_only={args.train_only} smoke={args.smoke}")
    log(f"  MARGIN_NI={MARGIN_NI} MARGIN_STRICT={MARGIN_STRICT} "
        f"MARGIN_WIDE={MARGIN_WIDE} ALPHA={ALPHA} Holm m=2")

    ev_rng = np.random.default_rng(EVAL_SEED)
    seq, typ = Q2.make_trace_batch(ev_rng, args.n_eval, task="hard")
    ev_rng2 = np.random.default_rng(EVAL_SEED_ROB)
    seq_rob, typ_rob = Q2.make_trace_batch(ev_rng2, args.n_eval, task="hard")
    log(f"eval batch: seq={seq.shape} typ={typ.shape} "
        f"rob={seq_rob.shape} SPAN={Z1.SPAN}")

    # ---------------- 新規 seed の訓練 ----------------
    train_rows = []
    for seed in args.train_seeds:
        for arch in ARMS:
            path = ckpt_path(arch, seed, ACTIVE_Z2DIR)
            if args.reuse and os.path.exists(path):
                log(f"  [reuse] {arch} s{seed}")
                continue
            r, _, _ = Z1.train_one(arch, seed, epochs=args.epochs,
                                   active_dir=ACTIVE_Z2DIR, save_path=path)
            train_rows.append(r)
            log(f"  [train] {arch} s{seed} backend={r['backend']} "
                f"loss[-1]={r['loss_hist'][-1]:.4f} {r['sec']}s")

    if args.train_only:
        if os.path.exists(train_log):
            with open(train_log, encoding="utf-8") as f:
                prev = json.load(f).get("rows", [])
            merged = {f"{r['arch']}_s{r['seed']}": r for r in prev}
            for r in train_rows:
                merged[f"{r['arch']}_s{r['seed']}"] = r
            train_rows = list(merged.values())
        with open(train_log, "w", encoding="utf-8") as f:
            json.dump({"rows": train_rows, "args": vars(args)},
                      f, ensure_ascii=False, indent=2, default=float)
        log(f"train_only 完了: 今回 {len(args.train_seeds)*len(ARMS)} 走行、"
            f"{os.path.basename(train_log)} 累計 {len(train_rows)} 走行")
        os._exit(0)

    if not train_rows and os.path.exists(train_log):
        with open(train_log, encoding="utf-8") as f:
            train_rows = json.load(f).get("rows", [])
        log(f"  G1 用に {os.path.basename(train_log)} から "
            f"{len(train_rows)} 走行を復元")

    # ---------------- 校正 ----------------
    t0 = time.time()
    calib, ok_calib = Z1.calibration(seq, typ, ACTIVE_Z2DIR, tag, log,
                                     do_repro=not args.no_repro)
    c6 = calibration_c6(seq, typ, ACTIVE_Z2DIR, log)
    c7_new_seeds = ([24] if args.smoke else list(SEEDS_CONFIRM))
    c7 = calibration_c7(c7_new_seeds, ACTIVE_Z2DIR, log)
    extra = []
    for name, out, field in (("C6_y1_p2_bitmatch", c6,
                             max(c6["max_abs_ce_seq"], c6["max_abs_iv"])),
                            ("C7_new_ckpt_uniqueness", c7,
                             0.0 if c7["bit_match"] else 1.0)):
        extra.append({"check": name, "arch": "-", "seed": -1,
                      "field": "bit_match", "want": True,
                      "got": out["bit_match"], "abs_diff": field,
                      "bit_match": out["bit_match"]})
    calib = calib + extra
    ok_calib = bool(ok_calib and c6["bit_match"] and c7["bit_match"])
    cpath = os.path.join(HERE, f"{tag}_calib.json")
    with open(cpath, "w", encoding="utf-8") as f:
        json.dump({"items": calib, "n": len(calib),
                   "all_bit_match": bool(ok_calib)},
                  f, ensure_ascii=False, indent=2, default=float)
    log(f"校正 総項目: {sum(1 for x in calib if x['bit_match'])}/{len(calib)} "
        f"all={ok_calib} ({time.time()-t0:.0f}s)")
    if not ok_calib:
        log("校正が落ちたので本番を走らせない。原因を調べること。")
        os._exit(1)

    # ---------------- 本番評価 ----------------
    na, ns = len(ALL_ARMS), len(args.seeds)
    aa = {a: i for i, a in enumerate(ALL_ARMS)}
    iv = np.full((na, ns), np.nan)
    ce_all = np.full((na, ns), np.nan)
    act_w = np.full((na, ns), np.nan)
    instr_seq = np.zeros((na, ns, args.n_eval), dtype=np.int8)
    ce_seq = np.zeros((na, ns, args.n_eval), dtype=np.float64)
    nparam_arr = np.zeros(na, dtype=np.int64)
    rows = []
    for arm in ALL_ARMS:
        base = arm[len("oracle_"):] if arm.startswith("oracle_") else arm
        for seed in args.seeds:
            model, clean = load_arch(base, seed, ACTIVE_Z2DIR)
            if arm.startswith("oracle_"):
                info = Z1.apply_oracle(model, clean)
            else:
                Z1.fresh(model, clean)
                info = {"n_zeroed": 0, "keys": []}
            m, x = Z1.evaluate(model, seq, typ)
            i, j = aa[arm], args.seeds.index(seed)
            iv[i, j] = m["instr_valid"]
            ce_all[i, j] = m["ce_all"]
            act_w[i, j] = m["active_width"]
            instr_seq[i, j] = x["instr_seq"]
            ce_seq[i, j] = x["ce_seq"]
            nparam_arr[i] = int(sum(v.numel() for v in clean.values()))
            rows.append({"arm": arm, "arch": base, "seed": seed, **m,
                         "n_zeroed": info["n_zeroed"],
                         "nparam": int(nparam_arr[i]),
                         "ckpt": os.path.relpath(
                             ckpt_path(base, seed, ACTIVE_Z2DIR), HERE)})
            log(f"  {arm:<16s} s{seed:2d} iv={m['instr_valid']:.4f} "
                f"ce={m['ce_all']:.5f} actW={m['active_width']:.1f}")

    # ロバストネスバッチ（base 2 腕だけ、設計書 §4）
    ra = {a: i for i, a in enumerate(ARMS)}
    ce_seq_rob = np.zeros((len(ARMS), ns, args.n_eval), dtype=np.float64)
    iv_rob = np.full((len(ARMS), ns), np.nan)
    for arm in ARMS:
        for seed in args.seeds:
            model, clean = load_arch(arm, seed, ACTIVE_Z2DIR)
            Z1.fresh(model, clean)
            m, x = Z1.evaluate(model, seq_rob, typ_rob)
            i, j = ra[arm], args.seeds.index(seed)
            ce_seq_rob[i, j] = x["ce_seq"]
            iv_rob[i, j] = m["instr_valid"]

    # ---------------- 保存 ----------------
    with open(os.path.join(HERE, f"{tag}_results.json"), "w",
              encoding="utf-8") as f:
        json.dump({"rows": rows, "train_rows": train_rows,
                   "args": vars(args), "arms": list(ALL_ARMS),
                   "seeds": list(args.seeds),
                   "margin_ni": MARGIN_NI, "eval_seed_rob": EVAL_SEED_ROB},
                  f, ensure_ascii=False, indent=2, default=float)
    np.savez_compressed(
        os.path.join(HERE, f"{tag}_delta.npz"),
        arms=np.array(ALL_ARMS, dtype=object), seeds=np.array(args.seeds),
        iv=iv, ce_all=ce_all, active_width=act_w,
        instr_seq=instr_seq, ce_seq=ce_seq, nparam=nparam_arr,
        rob_arms=np.array(ARMS, dtype=object),
        ce_seq_rob=ce_seq_rob, iv_rob=iv_rob)

    # ---------------- 主解析（新規 seed だけ） ----------------
    H, U = aa["H_1024"], aa["U_688"]
    dseq = ce_seq[H] - ce_seq[U]
    d_ce = dseq.mean(1)
    d_iv = iv[H] - iv[U]
    ab = np.abs(dseq.reshape(-1))
    ntop = max(1, int(math.ceil(len(ab) * 0.01)))
    main_c = confirm(d_ce, MARGIN_NI)
    r_ce, r_iv = main_c["paired"], Z1.paired(d_iv)

    exploratory = {"ni_margins": {}, "pooled_n60": None,
                   "robustness_seed778": None, "iv_one_sided_vs_ref": None,
                   "iv_floor_excluded": None}
    for m in (MARGIN_STRICT, MARGIN_NI, MARGIN_WIDE):
        sn = sup_and_ni(r_ce, m)
        exploratory["ni_margins"][str(m)] = sn

    # プール n=60（探索的。Z1 の 0..23 は z1_delta.npz から読む）
    z1d = np.load(os.path.join(HERE, "z1_delta.npz"), allow_pickle=True)
    z1arms = [str(x) for x in z1d["arms"]]
    z1seeds = [int(x) for x in z1d["seeds"]]
    zh, zu = z1arms.index("H_1024"), z1arms.index("U_688")
    d_old = (z1d["ce_seq"][zh] - z1d["ce_seq"][zu]).mean(1)
    if args.smoke:
        d_old = d_old[:0]
    d_pool = np.concatenate([d_old, d_ce])
    exploratory["pooled_n60"] = confirm(d_pool, MARGIN_NI)

    # ロバストネス（seed 778）
    rh, ru = ra["H_1024"], ra["U_688"]
    d_rob = (ce_seq_rob[rh] - ce_seq_rob[ru]).mean(1)
    rob = confirm(d_rob, MARGIN_NI)
    rob["sign_flip"] = bool(rob["paired"]["delta"] * r_ce["delta"] < 0)
    exploratory["robustness_seed778"] = rob

    # instr_valid の 1 片側（参照 +0.1467）と床除去（ともに探索的）
    exploratory["iv_one_sided_vs_ref"] = {
        "ref": REF_IV, "delta": r_iv["delta"], "se": r_iv["se"],
        "p": float(stats.t.cdf((r_iv["delta"] - REF_IV) / r_iv["se"],
                               r_iv["df"])),
        "upper95": r_iv["ci90"][1]}
    mask = (iv[H] >= 0.10) & (iv[U] >= 0.10)
    if int(mask.sum()) >= 2:
        exploratory["iv_floor_excluded"] = Z1.paired(d_iv[mask])

    # ---------------- ゲート ----------------
    losses = [r["loss_hist"][-1] for r in train_rows
              if r["seed"] in SEEDS_CONFIRM]
    g1 = {"n": len(losses),
          "median_last_loss": float(np.median(losses)) if losses else None,
          "n_below_030": int(np.sum(np.array(losses) < 0.30)) if losses else 0,
          "pass": bool(losses and len(losses) >= 72 and
                       float(np.median(losses)) < 0.30 and
                       int(np.sum(np.array(losses) < 0.30)) >= 65)}
    g2 = {a: {"n_iv_ge_010": int((iv[aa[a]] >= 0.10).sum()),
              "record_only": True} for a in ARMS}
    g3 = {}
    for a in ARMS:
        o = aa[f"oracle_{a}"]
        dd = (ce_seq[o] - ce_seq[aa[a]]).mean(1)
        g3[a] = {"min_delta_ce_seq": float(dd.min()),
                 "mean_delta_ce_seq": float(dd.mean()),
                 "n_below_030": int((dd < 0.30).sum()),
                 "pass": bool(dd.min() >= 0.30)}
    hw, uw = float(act_w[H].mean()), float(act_w[U].mean())
    c4 = {"H_1024": hw, "U_688": uw,
          "rel_diff": abs(hw - uw) / max(1e-12, 0.5 * (hw + uw)),
          "pass": bool(abs(hw - uw) / max(1e-12, 0.5 * (hw + uw)) <= 0.10)}

    gates_ok = bool(g1["pass"] and all(v["pass"] for v in g3.values())
                    and c4["pass"])
    claim_permitted = bool(main_c["sup_reject"] and gates_ok and ok_calib)
    analysis = {
        "calibration": {"n": len(calib), "all_bit_match": bool(ok_calib),
                        "C6": c6, "C7": c7},
        "primary": {
            "delta_def": "ce_seq(H_1024) - ce_seq(U_688); positive = H worse",
            "n": int(ns), "seeds": list(args.seeds),
            "P2_ce_seq": r_ce, "P2_instr_valid": r_iv,
            "confirm": main_c,
            "ce_top1_share": float(np.sort(ab)[-ntop:].sum() /
                                   max(1e-12, ab.sum())),
            "ce_diff_median": float(np.median(dseq)),
            "ce_diff_max": float(ab.max()),
        },
        "exploratory": exploratory,
        "gates": {"G1_train_convergence": g1, "G2_iv_floor_record_only": g2,
                  "G3_oracle_sensitivity": g3},
        "C4_active_width": c4,
        "baseline": {a: {"iv": float(iv[aa[a]].mean()),
                         "ce_all": float(ce_all[aa[a]].mean()),
                         "active_width": float(act_w[aa[a]].mean()),
                         "nparam": int(nparam_arr[aa[a]])}
                     for a in ARMS},
        "verdict": {"case": main_c["case"],
                    "sup_reject": bool(main_c["sup_reject"]),
                    "ni_reject": bool(main_c["ni_reject"]),
                    "claim_permitted": claim_permitted,
                    "confirmed_reversal": claim_permitted,
                    "gates_ok": gates_ok,
                    "calibration_ok": bool(ok_calib)},
        "meta": {"threads": args.threads, "n_eval": args.n_eval,
                 "eval_seed": EVAL_SEED, "eval_seed_rob": EVAL_SEED_ROB,
                 "epochs": args.epochs, "seqs": Z1.SEQS, "bs": Z1.BS,
                 "lr": Z1.LR, "auxw": Z1.AUXW,
                 "seeds": list(args.seeds), "arms": list(ALL_ARMS),
                 "n_rows": len(rows), "n_train": len(train_rows),
                 "smoke": args.smoke, "margin_ni": MARGIN_NI,
                 "margin_strict": MARGIN_STRICT, "margin_wide": MARGIN_WIDE,
                 "ref_iv": REF_IV, "alpha": ALPHA},
    }
    with open(os.path.join(HERE, f"{tag}_analysis.json"), "w",
              encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2, default=float)

    log("")
    t = main_c["test"]
    log(f"== 主解析 n={ns}: Δ={r_ce['delta']:+.6f} se={r_ce['se']:.6f} "
        f"t={r_ce['t']:+.3f} 両側p={r_ce['p']:.6f} MDE={r_ce['mde']:.6f} "
        f"90%CI={r_ce['ci90']} 符号 {r_ce['n_pos']}正/{r_ce['n_neg']}負")
    log(f"== p_sup={t['p_sup']:.6g} (Holm "
        f"{main_c['holm']['sup']['p_holm']:.6g}) | "
        f"p_NI(δ={MARGIN_NI})={t['p_ni']:.6g} (Holm "
        f"{main_c['holm']['ni']['p_holm']:.6g}) upper95={t['upper95']:+.6f}")
    log(f"== case={main_c['case']} sup_reject={main_c['sup_reject']} "
        f"ni_reject={main_c['ni_reject']}")
    log(f"== gates G1={g1['pass']} G3="
        f"{ {k: v['pass'] for k, v in g3.items()} } C4={c4['pass']}")
    log(f"== verdict: {analysis['verdict']}")
    log(f"saved: {tag}_results.json / {tag}_delta.npz / "
        f"{tag}_analysis.json / {tag}_calib.json")
    os._exit(0)


if __name__ == "__main__":
    main()
