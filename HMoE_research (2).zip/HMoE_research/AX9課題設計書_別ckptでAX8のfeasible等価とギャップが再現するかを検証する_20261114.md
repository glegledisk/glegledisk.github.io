# AX9 課題設計書: 別 ckpt で AX8 の feasible 等価と oracle–feasible ギャップが再現するかを検証する

- 日付: 2026-11-14（AX8 完走追記 2026-11-13 19:14 より後に作成した新しい設計書。`MEMORY.md` の次の一手 ① に対応）
- ステータス: 設計確定（走行前）。走行前調査 `_ax9_probe.py` / `_ax9_probe.json`、ckpt 取得 `_ax9_download.py`、実装 `ax9_cross_ckpt.py`、Step 4 検証 `_ax9_verify.py`。
- 関連: `検証報告_AX8_別コーパスでもfeasible利得は0.005nats未満と等価でoracle-feasibleギャップだけが再現する_20261113.md`、`AX8課題設計書_別コーパスでprobe腕を置きfeasible利得が再現するかを検証する_20261113.md`、`AX6課題設計書_別コーパスでper-token限界コストを測り直しlog-N対比が再現するかを検証する_20261112.md`、`AGENTS.md` §7-3 / §7-4 / §11。

## 0. 背景と問い

AX1〜AX8 はすべて **OLMoE-1B-7B の単一 ckpt** で走っている。AX6 / AX8 でコーパスは 2 スライスになったが、`AGENTS.md` §11 の「単一 seed・単一スライスの結果を確定知見として書かない」のうち**モデル多様性が未解消**のままである。本次は ① として、別の学習済み ckpt で AX8 と同一の確認的検定を再走する。

**走行前調査**（`_ax9_probe.py`、実行済み）で確定した事実:

| 項目 | 実測 |
|---|---|
| ローカル ckpt | `olmoe-1b-7b`（16 層 / 64E / top8）、`_smoke_olmoe`（2 層 / 8E / top2）、`qwen3-0.6b`・`smollm-135m`（dense）、`switch-base-8/16`（top-1 seq2seq） |
| `_smoke_olmoe` の NLL | **10.83811569**、ln(49152) = 10.80267282、比 **1.00328** → **ランダム初期化**で言語モデルとして使えない |
| HF 到達性 | `allenai/OLMoE-1B-7B-0924-Instruct` / `Qwen/Qwen1.5-MoE-A2.7B` / `mistralai/Mixtral-8x7B-Instruct-v0.1` いずれも参照可 |
| Instruct 版 config | 16 層 / 64E / top8 / hidden 2048 / vocab 50304 / `OlmoeForCausalLM` で**本番と完全一致**。13.84 GB |
| Qwen1.5-MoE config | 24 層 / 60E / top4 / vocab 151936。28.63 GB |

- 本次は **Instruct 版を別 ckpt として採用**した（ユーザー選択）。同一アーキテクチャなので AX8 の測定器を改造せずに済み、同一コーパス・同一 estimand で「別の学習 run」の反証が取れる。
- **Qwen1.5-MoE は本次の対象外**。語彙・tokenizer・層数・expert 数・top_k がすべて異なるためコーパス再凍結＋決定規則の再設計が必要で、AX8 との同一 estimand 比較ができない（§9 限界 1）。

- Q1（主）: 別 ckpt でも AX8 の確認的結論（S1 非棄却・S2 棄却・TOST δ = 0.005 等価）は再現するか。
- Q2: 別 ckpt でも oracle–feasible ギャップは AX4 `+0.01090368` / AX8 `+0.01064340` と同帯か。
- Q3（探索的）: 別 ckpt でも粒度カーブは oracle 側だけが増え、feasible は 0.003 未満に留まるか。
- Q4（探索的）: probe の R² 負と C7 帰無分布の形状は ckpt に依らず同型か。

## 1. 固定する量と動かす量

**固定**: コーパス `corpus_ids_ax6_w24_l256.npz`（AX8 と同一、48 窓・12,240 評価トークン）。AX4 の文境界定義（境界集合 {2, 15, 32, 4340}・最小文長 8・窓内完結・窓末端数は直前の文へマージ）。予算 mean_k = 7（各トークン 112 スロット）。決定規則（§2）。評価指標（per-token NLL）。検定族・δ = 0.005・AX8 の 124 列 prefill 特徴・LOO ridge λ = 10・random seed 1201・permutation seed 4400。校正 C1〜C7。

**動かす**: **モデルの重みのみ**（同一 pretrain ＋ SFT 済みの別 ckpt、`models/olmoe-1b-7b-instruct`）。

**★ `c8` / `c7` は新 ckpt で測り直す**: AX8 が再利用した AX6 保存の `c8` / `c7` は旧 ckpt の per-token 限界コストである。これを新 ckpt へ持ち込むと「決定の転移実験」に留まり、モデル依存性の反証にならない（AX6 の教訓）。本次は **32 本の ablate forward** から `c8_L = nll_ab7_L − nll_base_cap`、`c7_L = nll_ab6_L − nll_ab7_L` を測り直し、全腕の決定を本次の ckpt 上で作り直す（`base_cap` が native top_k = 8 の base を兼ね、C1 で `base_rep` とのビット一致を確認する）。

**符号の規約**: 利得 `G = CE(u7) − CE(腕)`（正＝改善）。per-token 差 `d = nll_u7 − nll_腕`。`G_a − G_b = nll_b − nll_a` で `u7` は代数消去される。キー名に依存せず G の表から差を引き直す（AX5 査読指摘 3 を反映）。

**本次が測る 3 条件**（`AGENTS.md` §2）: **予測可能性**が主。冗長性・異質性は対照として測るが主目的ではない。

## 2. 腕の一覧（新規 forward 45 本）

| 群 | 腕 | 本数 | 役割 |
|---|---|---:|---|
| 校正・基準 | `base_cap`（capture 付き）/ `base_rep` / `u7` / `u7_rep` | 4 | `base_cap` は C1 ＋ 124 列特徴 S の材料＋`c8` の基準。`u7` は全利得の基準 |
| 限界コスト | `ab7_L` × 16 / `ab6_L` × 16 | 32 | 新 ckpt の `c8` / `c7` |
| AX8 型 | `sent_oracle` / `sent_random` / `sent_probe` / `uni48_probe` / `uni340_probe` / `uni48_oracle` / `uni340_oracle` | 7 | 3 点対照＋主腕＋粒度対照。**oracle 側の粒度 2 点も本次で測り直す**（AX6 保存 NLL は別 ckpt なので混ぜない） |
| seed 依存 | `sent_random_s2` / `sent_random_s3` | 2 | random 対照の seed 1202 / 1203（探索的・§5） |

- `base_cap` は native top_k = 8 の base を兼ね、`u7` は native top_k = 7。`base_rep` / `u7_rep` は同一プロセスで再走し C1 のビット一致を取る。
- 予算: 全マスク腕で各トークン 6 ＋ 8 ＋ 14 × 7 ＝ 112 スロット、mean_k 厳密 7.000。各窓の末尾 1 トークン（評価外）は 7 で埋める。
- **AX3 / AX4 / AX5 / AX6 / AX7 / AX8 の保存 NLL は利得計算に一切混ぜない**。AX4 / AX8 値は独立 ckpt の点推定比較にだけ使う。
- **一次評価と厳密測定の分離**（§7-4）: `c8` / `c7` は決定規則の入力にだけ使い、利得は必ず本次の forward 実測 NLL で測る。
- **per-token probe 腕は置かない**（LOO solve 12,240 回で計算が破綻するため。AX8 と同じ制約）。

## 3. 決定規則（AX4 / AX8 と同一・走行前に凍結）

各単位 u について本次の `c8` / `c7`（16, 12240）を**単位内平均**して `Y_u`（n_unit, 32）を作る。

- cut `i*(u) = argmin_L Y_u[u, 16+L]`、protect `j*(u) = argmax_{L≠i*} Y_u[u, L]`（cut 層を除外）。同点は最若 index。cut ≠ protect を全単位で assert（C5）。
- 単位 u の全トークンへ層 i* を 6、層 j* を 8、他を 7。
- oracle 版は真の `Y_u`、random 版は seed 1201（＋1202 / 1203）の乱数、probe 版は **124 列の単位集約 prefill 特徴 → LOO ridge（λ=10）の oof 予測 `Ŷ_u`** で決定する。
- 124 列の内訳は AX4 / AX8 と同一（gate_stats 16 層 × 7 ＝ 112、単位内 NLL / entropy / top1 統計 10、位置・言語 2）。en 側単位数は `sent` 188 / `uni48` 24 / `uni340` 170。

## 4. 確認的検定（Holm m = 2、α = 0.05、両側、n = 12,240）

AX8 と**完全に同一**の estimand を置く（比較可能性を優先し、結果を見てからの変更はしない）。

| ID | estimand | 検定の意味 |
|---|---|---|
| **S1（主）** | `G_sent_probe = 0` | 別 ckpt で feasible 利得が検出できるか |
| S2 | `G_sent_oracle − G_sent_probe = 0` | oracle–feasible ギャップの直接検定 |

- 統計は `paired()` を流用（per-token se、48 窓保守 se、MDE、CI95 / CI90、上位 1% 寄与率）。§7-5 により上位 1% 寄与率が 50% を超えたら平均を主張に使わない。
- **TOST（δ = 0.005）を Holm 家族の外で独立に事前登録**: `tost(st_S1, 0.005)` で「feasible 利得が 0.005 nats 未満と等価か」を報告する（Y2 / AX8 の前例）。等価が成立しても「差が無い」とは書かない。
- **★ 検出力を事前に認める**: AX8 の S1 MDE は 0.00196480、AX4 の点推定は 0.00126101。本次も同程度の sd なら MDE ≈ 0.002 で、**0.001 台の効果は原理的に検出できず S1 の非棄却は予想された結果**である。非棄却には MDE と 90% CI を必ず併記する。確認的結論の実質は S2 が担う。

## 5. 別 seed の扱い（探索的・正直に）

**AX8 の確認的統計量は決定的**: probe は LOO ridge、oracle は `c8` / `c7` 由来、コーパスも固定で、乱数 seed を変えても S1 / S2 / TOST は変わらない。したがって「別 seed 反復」は確認的結論の反証にならない。本次では範囲を明示して探索的に置く。

- `sent_random` の seed 1201 に加え 1202 / 1203 の 2 腕を置き、**3 腕の最大−最小を記述統計として記録**する。有意差・有意性は主張せず、事後に「最も効いた seed」を選ばない。
- C7 の permutation seed は AX8 との帰無分布の形状比較のため **4400 で固定**する。
- 分割抽選（AX7 で N=102 のノイズ 0.0024 が分解能の壁と判明）は本次の estimand に効かないため増やさない（§9 限界 10）。

## 6. 判定ケース

AX8 と同一の優先順（S1 の棄却と符号 ＞ S2）を事前に固定する。

| ケース | 条件 | 読み |
|---|---|---|
| A | S1 棄却かつ正 | 別 ckpt で feasible 利得が検出。AX8 と異なる |
| B | S1 非棄却かつ S2 棄却 | **AX8 の再現**。feasible は MDE 未満、ギャップは実在 |
| C | S1 非棄却かつ S2 非棄却 | 新 ckpt では文単位 oracle 自体が検出限界未満 |
| D | S1 棄却かつ負 | 逆方向（probe が劣化）。登録枠で正直に記述 |

- ケース表に現れない組合せは登録枠で記述し、事後の枠追加はしない（AX1 の反省）。
- **いずれのケースでも「差が無い」とは書かない**。非棄却には MDE と 90% CI を添える。
- Q2 / Q3 / Q4 と AX4 / AX8 との点推定比較はいずれのケースでも探索的に独立報告する。**別 ckpt 間の差は独立標本なので paired 検定にせず、有意差を主張しない**（AX6 / AX8 の前例）。

## 7. 校正 C1〜C7

AX6 / AX7 / AX8 の方式を継承し、**各項目で観測統計量と合格条件（閾値）の両方を明示**する。

| ID | 観測統計量 | 合格条件 |
|---|---|---|
| C1 | 同一プロセス内の `base_cap` 対 `base_rep`、`u7` 対 `u7_rep` の per-token 差の max 絶対値。**スモーク（en のみ 6 窓）でも判定** | 両方 **0.0**（tier A）。FAIL なら本番を起動しない。新 ckpt には外部保存アンカーが無いため AX6 方式を採る |
| C2 | AX3 凍結 npz との共通 8-gram 割合（en / ja） | en **＜ 0.05** かつ ja **＜ 0.20**。走行前実測 0.041225 / 0.001629 |
| C3 | 文 ID の連続性・窓またぎ・最小文長・337 文、`c8` / `c7` から再計算した決定の不一致、全腕 mean_k | 不良 **0**・不一致 **0**・mean_k 7.000（誤差 1e-9） |
| C4 | 全マスク腕の各トークンのスロット数 | 112、不良 0 |
| C5 | 全単位の cut ≠ protect 違反数 | 0、tie 数と cut ヒストグラムを記録 |
| C6 | 3 点対照 uniform `u7` ／ random `sent_random` ／ oracle `sent_oracle` ／ probe `sent_probe` | `G_random ≤ G_oracle`。新規検定ではない |
| C7 | **観測統計量 ＝ `max_j abs(Spearman(Y_u[:, j], Ŷ_u[:, j]))`**（32 列の最大絶対 rho）。Y の行を 100 回並べ替えた帰無分布の p95 を併記 | **記録のみ・合否なし**（AX3 / AX4 の連続失敗、AX6 / AX7 / AX8 の方式を継承）。リーク検査として解釈しない |

## 8. 禁止事項（継承）

- Z1 §4 規則 3 を解除しない。**保留 1 は退役させない**。
- 「差が無い」「中心命題が偽 / 確認された」「層方向は効く / 効かない（一般則）」は書かない。
- 絶対 CE を別コーパス・別 ckpt の過去報告と直接比較しない。本次は利得（同一コーパス内の paired 差）だけを比較する。
- 一次評価（`c8` / `c7` の和）を実装可能な性能として書かない（§7-4）。
- 単一 seed・単一スライスの結果を確定知見として `MEMORY.md` に書かない（§11）。本次で ckpt は 2 つになるが、**pretrain は共通**であることを限界に明記する。
- 結果を見てから規則・検定族・主腕・文境界定義・probe の λ・δ を変えない。変更が必要なら新しい日付の設計書を 1 本作る。

## 9. 限界

1. **別 ckpt だが同一アーキテクチャ・同一 pretrain**。差は SFT のみで、真の別アーキテクチャ（Qwen1.5-MoE、24 層 / 60E / top4 / 語彙 151936）は未検証。§11 のモデル多様性は「別の学習 run」までしか緩まない。
2. **S1 の MDE（約 0.002）が AX4 / AX8 の点推定（0.00126 / −0.00004）を上回る**。同規模の効果は検出できず、「再現した／しない」を有意差で判定できない。
3. 依然 1 つの推論 seed・2 コーパススライス。確認的統計量は seed 非依存（§5）。
4. 文境界はトークン ID のヒューリスティック。`.` は小数点・略語にも現れる。文を窓内で強制終了させている。
5. `c8` / `c7` は同コーパス・同 ckpt の測定値で選択しており winner's curse を含む。
6. probe は LOO ridge（λ=10）のみ。より強い予測器なら feasible は動く可能性がある。
7. C7 の permutation は 100 回のみ・記録のみ。
8. **本次は per-token 腕（oracle / probe とも）を置かない**。別 ckpt の保存 NLL を混ぜないため、粒度カーブは 48 / 337 / 340 の 3 点に限定し、AX8 の `tok_oracle +0.04165` に対応する点は測らない。feasible カーブの上端も測らない。
9. マスク方式は FLOPs を削らず、計算量は解析値 mean_k で管理する。
10. 別 seed 反復は random 腕 3 つのみで、確認的統計量には効かない。分割抽選ノイズ（AX7）は本次では扱わない。
11. 新 ckpt は SFT 済みのため、AX8 の base ckpt と出力分布が系統的に異なる。利得は各 ckpt 内の paired 差なので比較可能だが、絶対 CE は比較しない。

## 10. 実行計画と出力

- 走行前調査: `python _ax9_probe.py` → `_ax9_probe.json`（**実行済み**。ローカル ckpt 棚卸し・ランダム初期化の実測・HF 到達性・config 一致を確認）。
- ckpt 取得: `python _ax9_download.py` → `models/olmoe-1b-7b-instruct/`（13.84 GB・再開可能）＋ `_ax9_download.json`。完了後に config と safetensors 3 ファイルを検証する。
- dry-run: `ax9_cross_ckpt.py --dry-run`（モデルをロードせず、分割・文 ID・C2 / C3 / C4 / C5 の assert）。
- smoke: `ax9_cross_ckpt.py --smoke --tag ax9smoke`（**en のみ 6 窓**で全腕・全段階。**C1 を判定**し FAIL なら本番を起動しない）。出力名は別 tag で本番 npz を壊さない。
- 本番: `ax9_cross_ckpt.py --tag ax9`。45 forward ≈ 1h50m。PowerShell は `run_in_background=true` で 1 本だけ起動し、forward ごとに `_ax9_cache_ax9/<arm>.npz` へ保存して再開可能にする（AX5〜AX8 の障害回避を継承）。
- Step 4: `_ax9_verify.py ax9` が別実装（`scipy.stats.ttest_rel` 経由・`np.add.at` で限界コストと決定を独立再構成）で Δ・se・t・p・Holm・MDE・TOST・件数・上位 1% 寄与率・文 ID・mean_k・C1〜C7 を再計算し 0 不一致を確認。
- 出力: `ax9_cross_ckpt.npz` / `.json` / `ax9_cross_ckpt_out_utf8.txt` / `ax9_exit.txt`。**JSON を書く前に非有限値を走査して assert**し、**npz 保存前に全値が数値 ndarray であることを assert**する（AX8 で再踏みした §8 の罠）。
- 報告: `検証報告_AX9_..._20261114.md`（結論 6 行以内・3 点対照・限界 3 項目以上・再現 PowerShell）、`STATE.md` への `## 追記`、`MEMORY.md` 追記、日次ログ `2026-11-14.md` 追記。新しい罠を踏んだら `AGENTS.md` §8 に行を追加する。
