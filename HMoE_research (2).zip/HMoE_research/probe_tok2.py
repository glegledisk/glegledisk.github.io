import os, sys, time, traceback
os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["HF_HUB_DISABLE_PROGRESS_BARS"] = "1"

from huggingface_hub import hf_hub_download
from tokenizers import Tokenizer

cands = [
    ("allenai/OLMo-2-0425-1B", "tokenizer.json"),
    ("Qwen/Qwen3-0.6B", "tokenizer.json"),
    ("HuggingFaceTB/SmolLM-135M", "tokenizer.json"),
]
for repo, fn in cands:
    try:
        t0 = time.time()
        p = hf_hub_download(repo_id=repo, filename=fn)
        sz = os.path.getsize(p)
        print(f"[DL OK] {repo}  {sz/1e6:.2f} MB  {time.time()-t0:.1f}s  -> {p}")
        tk = Tokenizer.from_file(p)
        print(f"         vocab={tk.get_vocab_size()}  loaded OK")
    except Exception as e:
        print(f"[FAIL] {repo}: {type(e).__name__}: {str(e)[:300]}")
