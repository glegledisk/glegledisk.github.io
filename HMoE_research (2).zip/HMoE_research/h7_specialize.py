"""H7: 不均一アームの二峰性の原因と対策。

## 診断（H6 の結果から）

幅の量は判別子になっていない。het_l01 b=16 の 2 seed は
  seed1: depth1 CE 2.503（失敗）, depth1 の平均活性幅 1.333
  seed2: depth1 CE 0.004（成功）, depth1 の平均活性幅 1.329
で**幅がほぼ同じ**なのに 2.5 nats 違う。

→ 二峰性の原因は「幅を寄せたか」ではなく「**depth1 のトークンを同じ expert に
安定して流せたか**」。割当が毎ステップ揺れると、どの expert も depth1 の表を
覚えられない（専門化の失敗）。だから「集中度」を測る必要がある。

## 対策（2 つ、2x2 で独立に試す）

1. **ルータ温度** `temp`（<1 で鋭く）。softmax と top-k 選択の両方が決定的になり、
   expert ごとに見るデータが揃う。

2. **サイズ比例の負荷分散** `balance=size`。従来（と H6）は「全 expert が等しく
   1/E のトークンを受ける」よう罰していた。これはサイズの異なる expert には
   **逆効果**で、大きい expert の使用を抑えてしまう（文書 §2.3 が指摘した問題）。
   目標を `s_e/Σs` にすると大きい expert が比例して多く受ける。

   両方とも二乗誤差型 `aux = E * Σ_e (frac_e − target_e)^2` にして比較を揃える
   （H6 の Switch 型は目標が一様固定なので、size 目標を表現できない）。

## 測るもの

- depth 型ごとの平均活性幅（配分の量）
- depth 型ごとの **top-1 expert の最大シェアとエントロピー**（割当の安定性）
- val / depth1 CE
- seed 間 SD（二峰性が減ったか）
"""
import argparse
import json
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

from h3_bigvocab import Net, MoE, block_mask, sample_mask, diff_loss, evaluate, SEQ
from h4_arith import mup_init
from h5_tasks import gen_comp, make_types, TYPE_NAMES, ce_by_type

HERE = os.path.dirname(os.path.abspath(__file__))

C = 31
D_FF = 512
HET = [0.5, 0.5, 0.75, 0.75, 1.25, 1.25, 1.5, 1.5]
STEPS = 3000
LR = 3e-3
LAM = 0.01
AUX_W = 0.1


def patch_moe():
    """温度とサイズ比例負荷分散を入れた forward に差し替える。"""
    if getattr(MoE, "_h7_patched", False):
        return

    def fwd(self, x):
        B, Ln, D = x.shape
        N = B * Ln
        fx = x.reshape(N, D)
        logits = self.router(x) / getattr(self, "temp", 1.0)
        probs = logits.softmax(-1)
        w, idx = logits.topk(self.k, dim=-1)
        w = w.softmax(-1)
        fw = w.reshape(N, self.k)
        fi = idx.reshape(N, self.k)

        h = torch.bmm(fx.unsqueeze(0).expand(self.E, -1, -1), self.W1.transpose(1, 2))
        h = F.gelu(h + self.b1.unsqueeze(1)) * self.m1.unsqueeze(1)
        y = torch.bmm(h, self.W2.transpose(1, 2)) + self.b2.unsqueeze(1)
        y = y.permute(1, 0, 2)

        gate = torch.zeros(N, self.E, device=x.device, dtype=fx.dtype)
        gate.scatter_add_(1, fi, fw)
        out = (gate.unsqueeze(-1) * y).sum(1)

        hard = self.sizes[fi].sum(-1).mean()
        soft = self.k * (probs * self.sizes).sum(-1).mean()
        cost = hard + (soft - soft.detach())

        # 負荷分散。hard な frac は bincount 由来で微分不能なので使わない
        # （H1 の λ と同じ罠。一度これで aux の勾配が消えた）。
        # 微分可能な soft な使用率で罰する。
        mode = getattr(self, "aux_mode", "none")
        if mode == "none":
            # Net.forward が torch.stack するので None は返せない。ゼロを返す。
            aux = torch.zeros((), device=x.device)
        else:
            frac = probs.reshape(-1, self.E).mean(0)
            tgt = self.bal_target
            aux = self.E * ((frac - tgt) ** 2).sum()
        return out.view(B, Ln, D), cost, aux, fi, fw

    MoE.forward = fwd
    MoE._h7_patched = True


@torch.no_grad()
def diagnose(model, xs, am, mask_id):
    g = torch.Generator().manual_seed(4242)
    dev = xs.device
    tm = make_types("comp").to(dev)
    E = model.blocks[0].moe.E
    widths, hist = {}, {}
    for _ in range(6):
        m, _ = sample_mask(xs.shape[0], 0.1, g, dev)
        inp = torch.where(m, torch.full_like(xs, mask_id), xs)
        _, _, _, fis, _ = model(inp, am)
        sizes = model.blocks[0].moe.sizes
        fi = fis[-1].view(xs.shape[0], SEQ, -1)
        width = sizes[fi].sum(-1)
        top1 = fi[..., 0]
        for ti, tn in enumerate(TYPE_NAMES["comp"]):
            sel = m & (tm == ti).unsqueeze(0)
            if not sel.any():
                continue
            widths.setdefault(tn, []).append(float(width[sel].mean()))
            h = torch.bincount(top1[sel], minlength=E).float()
            hist.setdefault(tn, []).append((h / h.sum()).cpu())
    out = {}
    for tn in TYPE_NAMES["comp"]:
        if tn not in widths:
            continue
        H = torch.stack(hist[tn]).mean(0)
        p = H.clamp_min(1e-9)
        out[tn] = dict(width=float(np.mean(widths[tn])),
                       top1_share=float(H.max()),
                       entropy=float(-(p * p.log()).sum()),
                       hist=[round(float(v), 3) for v in H])
    return out


def run(aux_mode, lam, seed, b=1, steps=STEPS):
    torch.manual_seed(seed)
    np.random.seed(seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    n_class = 2 * C + 1
    mask_id = 2 * C

    model = Net(n_class, 128, 4, 4, D_FF, HET, 2).to(dev)
    mup_init(model, 128)
    E = len(HET)
    sz = torch.tensor(HET, device=dev)
    tgt = (torch.ones(E, device=dev) / E) if aux_mode == "uniform" else (sz / sz.sum())
    for blk in model.blocks:
        blk.moe.temp = 1.0
        blk.moe.aux_mode = aux_mode
        blk.moe.bal_target = tgt

    opt = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda i: min(1.0, i / max(1, steps * 0.05)))
    am = ~block_mask(b).to(dev)

    gt = torch.Generator().manual_seed(1234)
    f = torch.randint(0, C, (C, C), generator=gt)
    gen = torch.Generator(device="cpu").manual_seed(seed * 77 + 1)
    xv = gen_comp(512, C, f, torch.Generator().manual_seed(7)).to(dev)

    t0 = time.time()
    for _ in range(steps):
        x = gen_comp(64, C, f, gen).to(dev)
        loss, cost, aux = diff_loss(model, x, am, gen, mask_id)
        opt.zero_grad(set_to_none=True)
        tot = loss + lam * cost
        if aux is not None:
            tot = tot + AUX_W * aux
        tot.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()

    val = evaluate(model, xv, am, mask_id)
    tm = make_types("comp").to(dev)
    cells = ce_by_type(model, xv, am, mask_id, tm, TYPE_NAMES["comp"])
    diag = diagnose(model, xv, am, mask_id)
    with torch.no_grad():
        xb = gen_comp(256, C, f, torch.Generator().manual_seed(11)).to(dev)
        m, _ = sample_mask(256, 0.5, torch.Generator().manual_seed(5), dev)
        inp = torch.where(m, torch.full_like(xb, mask_id), xb)
        _, cost_meas, _, _, _ = model(inp, am)
    return dict(aux_mode=aux_mode, lam=lam, seed=seed, b=b, steps=steps,
                val=val, cost=float(cost_meas), cells=cells, diag=diag,
                sec=time.time() - t0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--aux_modes", default="none,uniform,size")
    ap.add_argument("--lams", default="0.005")
    ap.add_argument("--seeds", default="0,1,2,3")
    ap.add_argument("--b", type=int, default=1)
    ap.add_argument("--out", default="h7_results.jsonl")
    a = ap.parse_args()
    patch_moe()

    out = os.path.join(HERE, a.out)
    if os.path.exists(out):
        os.remove(out)
    modes = a.aux_modes.split(",")
    lams = [float(x) for x in a.lams.split(",")]
    seeds = [int(x) for x in a.seeds.split(",")]
    jobs = [(m, lm, s) for lm in lams for m in modes for s in seeds]
    print(f"jobs: {len(jobs)}", flush=True)

    t0 = time.time()
    for i, (m, lm, s) in enumerate(jobs, 1):
        print(f"[{i}/{len(jobs)}] aux={m} lam={lm} seed={s} "
              f"elapsed={(time.time()-t0)/60:.1f}m", flush=True)
        try:
            r = run(m, lm, s, a.b)
        except Exception as e:                                   # noqa: BLE001
            print(f"  FAIL {type(e).__name__}: {e}", flush=True)
            torch.cuda.empty_cache()
            continue
        with open(out, "a", encoding="utf-8") as fp:
            fp.write(json.dumps(r, ensure_ascii=False) + "\n")
        d = r["diag"]
        print(f"  val={r['val']:.3f} cost={r['cost']:.2f} d1={r['cells']['depth1']:.3f} "
              f"w1={d['depth1']['width']:.2f} share={d['depth1']['top1_share']:.2f} "
              f"H={d['depth1']['entropy']:.2f} sec={r['sec']:.0f}", flush=True)
    print("DONE", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
