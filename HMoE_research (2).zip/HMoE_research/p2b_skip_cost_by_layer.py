"""P2b: 各層で「最下位 Expert を落とす」コストを測る（skip の CE 価格の層プロファイル）。

方法: ルータの forward hook で top-k の最後（最小重み）の重みを 0 にする。
norm_topk_prob=False なので、これはその Expert の寄与を丸ごと落とすことと同じ。
層ごとに 1 回ずつ forward し、CE の増分を測る。
"""

import argparse
import glob
import json
import os
import re

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "olmoe-1b-7b")


def log(m):
    print(m, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--layers", nargs="*", type=int, default=[0, 2, 4, 6, 8, 10, 12, 14, 15])
    ap.add_argument("--len", type=int, default=128)
    ap.add_argument("--windows", type=int, default=2)
    ap.add_argument("--tag", default="p2b")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer

    tok = AutoTokenizer.from_pretrained(MODEL)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "6.5GiB", "cpu": "8.0GiB"},
        offload_folder=os.path.join(HERE, "_p2_offload"),
    ).eval()

    files = sorted(glob.glob(os.path.join(HERE, "english_version", "**", "*.md"), recursive=True))[:2]
    corpus = "\n\n".join(re.sub(r"```.*?```", " ", open(f, encoding="utf-8").read(), flags=re.S) for f in files)
    ids_all = tok(corpus, return_tensors="pt", add_special_tokens=False).input_ids[0]
    import random
    random.seed(0)
    wins = [ids_all[random.randrange(0, ids_all.numel() - args.len):][:args.len] for _ in range(args.windows)]

    def ce_of(ids):
        with torch.no_grad():
            out = model(input_ids=ids.unsqueeze(0), labels=ids.unsqueeze(0), use_cache=False)
        return float(out.loss.item())

    base = [ce_of(w) for w in wins]
    log("baseline CE = %.4f" % (sum(base) / len(base)))

    rows = []
    for L in args.layers:
        gate = model.model.layers[L].mlp.gate
        state = {"on": True}

        def hook(m, inp, out, state=state):
            if not state["on"]:
                return out
            logits, scores, idx = out
            s = scores.clone()
            s[..., -1] = 0.0
            return (logits, s, idx)

        h = gate.register_forward_hook(hook)
        ces = [ce_of(w) for w in wins]
        h.remove()
        d = sum(ces) / len(ces) - sum(base) / len(base)
        rows.append({"layer": L, "ce_skip": sum(ces) / len(ces), "dce": d})
        log("  layer %2d  CE %.4f  ΔCE %+.5f" % (L, sum(ces) / len(ces), d))

    with open(os.path.join(HERE, "%s_skip_cost.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump({"baseline": sum(base) / len(base), "rows": rows}, fp, ensure_ascii=False, indent=2)
    log("saved %s_skip_cost.json" % args.tag)


if __name__ == "__main__":
    main()
