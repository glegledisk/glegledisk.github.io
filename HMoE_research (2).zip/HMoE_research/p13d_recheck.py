#!/usr/bin/env python3
"""P13d: P13 §4 の再測定と条件 D（同 params 均一幅）を、同一 ckpt・同一 eval で測る。

背景
----
PC §5-2 は「p13_hmoe_path.py の gate[tok, slot] により P13 §4 の CE が MoE 側だけ
+0.018 ずれる（差 0.0337 の半分）」と指摘した。しかし P13 §4 は修正版
p13c_retrain.py（gate[tok, i]）と data/e2b の ckpt 由来であり、p13_hmoe_path.py は
data/e2 の ckpt を読む「バグ版・無効」ファイルとして P13 自身が明示している。
出所の取り違えを実測で切り分けるのが本測定の第一の目的。

3 つの forward を同一 ckpt・同一評価系列（seed 777, n=2048）で比較:
  fixed : gate[tok, i]      … p13c_retrain.py と同一（＝ P13 §4 の測定器）
  buggy : gate[tok, slot]   … p13_hmoe_path.py と同一
  native: e2b.RewriteMoE.__call__ … モデル本体（校正用）

第二の目的は条件 D。同総パラメータ 1,342,653 の H+LB（不均一幅）と
U+LB（均一幅 128x8）を、fixed forward で paired 比較し、不均一性そのものの
寄与を Δ / se / t / n / MDE 付きで確定させる。

出力: p13d_results.json / p13d_analysis.json / p13d_out_utf8.txt
"""
import argparse
import json
import math
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, E2DIR)
from e2b_rewrite_routing_fixed import (  # noqa: E402
    RewriteMoE, make_batch, to_seq, SL, OL, V, WIDTHS)

OUTDIR = os.path.join(E2DIR, "data", "e2b")
DENSE_WIDTHS = (97, 180, 256)
MOE_ARMS = ("H+LB", "U+LB")
CONDS = (("top1", 1), ("base", 2))
MODES = ("fixed", "buggy")


def forward_variant(model, idx, mode, k=2, force=None):
    """p13c_retrain.py の forward_forced を 2 通りに分けたもの。

    gate は (N, E)。fixed は expert 添字 i、buggy は top-k 内の位置 slot で引く。
    """
    p = model.p
    B, T = idx.shape
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    idx_l = []
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
        if force is None:
            topv, topi = logits.topk(k, dim=1)
        else:
            topi = torch.tensor(list(force), dtype=torch.long).expand(h.shape[0], -1)
            topv = logits.gather(1, topi)
        gate = torch.softmax(
            torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
        idx_l.append(topi.reshape(B, T, -1))
        y = torch.zeros_like(h)
        for i in range(model.E):
            tok, slot = (topi == i).nonzero(as_tuple=True)
            if tok.numel() == 0:
                continue
            x = h[tok]
            h1 = F.relu(F.linear(x, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
            g = gate[tok, i] if mode == "fixed" else gate[tok, slot]
            y.index_add_(0, tok,
                         F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                         * g.unsqueeze(1))
        h = h + y
    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, V)
    return out, idx_l


@torch.no_grad()
def run_cond(model, src, out, em, mode, k, force=None, bs=128):
    """p13c_retrain.py の run_cond と同一の評価。mode=native だけモデル本体を使う。"""
    n = src.shape[0]
    ce = np.zeros((n, OL), dtype=np.float32)
    hit_c = np.zeros((n, OL), dtype=bool)
    hit_e = np.zeros((n, OL), dtype=bool)
    widths = np.zeros((n, OL), dtype=np.float32)
    dims = np.array(model.dims, float)
    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = to_seq(src[s], out[s])
        if mode == "native":
            logits, _, idx_l, _ = model(x, aux_mode="none", need_idx=True)
        else:
            logits, idx_l = forward_variant(model, x, mode, k=k, force=force)
        lg = logits[:, SL:SL + OL, :]
        tgt = torch.from_numpy(out[s])
        lp = F.cross_entropy(lg.reshape(-1, V), tgt.reshape(-1),
                             reduction="none").reshape(-1, OL)
        ce[s] = lp.numpy()
        pred = lg.argmax(-1).numpy()
        m = em[s]
        hit_c[s] = (pred == tgt.numpy()) & (~m)
        hit_e[s] = (pred == tgt.numpy()) & m
        for l, ti in enumerate(idx_l):
            a = ti.numpy()[:, SL:SL + OL, :]
            widths[s] += dims[a].sum(-1)
    widths /= max(1, len(idx_l))
    return {
        "ce_all": float(ce.mean()),
        "ce_copy": float(ce[~em].mean()),
        "ce_edit": float(ce[em].mean()),
        "acc_copy": float(hit_c.sum() / max(1, (~em).sum())),
        "acc_edit": float(hit_e.sum() / max(1, em.sum())),
        "width": float(widths.mean()),
        "ce_seq": ce.mean(1).astype(np.float64).tolist(),
        "n_eval": int(n),
    }


def load_ckpt(model, path):
    td = torch.load(path, map_location="cpu")
    model.p = {k: v for k, v in td.items()}
    for k in model.p:
        model.p[k].requires_grad_(False)
    return model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--n_eval", type=int, default=2048)
    ap.add_argument("--threads", type=int, default=6,
                    help="p13c_retrain.py と同じ 6 が校正のビット一致条件")
    args = ap.parse_args()
    torch.set_num_threads(args.threads)

    LOG = os.path.join(HERE, "p13d_out_utf8.txt")

    def log(msg):
        print(msg, flush=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")

    if os.path.exists(LOG):
        os.remove(LOG)

    ev = np.random.default_rng(777)
    src, out, em, ks = make_batch(ev, args.n_eval)
    log("P13d: n_eval=%d OUT=%d edit率=%.4f threads=%d seeds=%s"
        % (src.shape[0], OL, em.mean(), args.threads, args.seeds))

    rows = []

    def emit(arm, seed, cond, mode, k, r, nparam):
        row = {"arm": arm, "seed": seed, "cond": cond, "mode": mode, "k": k,
               "nparam": int(nparam)}
        row.update(r)
        rows.append(row)
        log("  %-8s s%d %-5s %-6s k=%d  CE %.6f  copy %.6f  w %.1f"
            % (arm, seed, cond, mode, k, r["ce_all"], r["ce_copy"], r["width"]))

    for arm in MOE_ARMS:
        widths = WIDTHS[arm]
        for seed in args.seeds:
            path = os.path.join(OUTDIR, "ckpt_%s_s%d.pt" % (arm, seed))
            model = load_ckpt(RewriteMoE(widths, seed=seed), path)
            nparam = sum(v.numel() for v in model.params().values())
            for cond, k in CONDS:
                for mode in MODES:
                    emit(arm, seed, cond, mode, k,
                         run_cond(model, src, out, em, mode, k), nparam)
            emit(arm, seed, "base", "native", 2,
                 run_cond(model, src, out, em, "native", 2), nparam)

    for w in DENSE_WIDTHS:
        for seed in args.seeds:
            path = os.path.join(OUTDIR, "ckpt_dense%d_s%d.pt" % (w, seed))
            model = load_ckpt(RewriteMoE([w], seed=seed, topk=1), path)
            nparam = sum(v.numel() for v in model.params().values())
            for mode in ("fixed", "buggy", "native"):
                emit("dense%d" % w, seed, "dense", mode, 1,
                     run_cond(model, src, out, em, mode, 1), nparam)

    with open(os.path.join(HERE, "p13d_results.json"), "w", encoding="utf-8") as f:
        json.dump({"rows": rows, "args": vars(args)}, f,
                  ensure_ascii=False, indent=2, default=float)

    # ---------------- 集計 ----------------
    by = {}
    for r in rows:
        by.setdefault((r["arm"], r["cond"], r["mode"]), []).append(r)
    summary = {}
    for key, rs in by.items():
        rs = sorted(rs, key=lambda x: x["seed"])
        summary["|".join(key)] = {
            "ce": float(np.mean([r["ce_all"] for r in rs])),
            "ce_copy": float(np.mean([r["ce_copy"] for r in rs])),
            "width": float(np.mean([r["width"] for r in rs])),
            "per_seed": [float(r["ce_all"]) for r in rs],
            "nparam": int(rs[0]["nparam"]),
            "n": len(rs),
        }

    def get(arm, cond, mode):
        return by.get((arm, cond, mode), [])

    # 校正: p13c_analysis.json（= P13 §4 の一次ソース）とのビット一致
    ref = json.load(open(os.path.join(HERE, "p13c_analysis.json"), encoding="utf-8"))
    calib_map = [
        ("H+LB:top1", "H+LB", "top1"), ("H+LB:base", "H+LB", "base"),
        ("U+LB:top1", "U+LB", "top1"), ("U+LB:base", "U+LB", "base"),
        ("dense:97", "dense97", "dense"), ("dense:180", "dense180", "dense"),
        ("dense:256", "dense256", "dense"),
    ]
    calib = []
    for ref_key, arm, cond in calib_map:
        got = summary.get("|".join((arm, cond, "fixed")))
        want = ref["points"][ref_key]["ce"]
        calib.append({"key": ref_key, "ref_ce": float(want),
                      "fixed_ce": got["ce"] if got else None,
                      "abs_diff": abs(got["ce"] - want) if got else None,
                      "bit_match": bool(got and abs(got["ce"] - want) < 1e-12)})

    # fixed vs native（同一測定器の内部整合）
    native_check = []
    for arm in MOE_ARMS + tuple("dense%d" % w for w in DENSE_WIDTHS):
        cond = "dense" if arm.startswith("dense") else "base"
        f_ = get(arm, cond, "fixed")
        n_ = get(arm, cond, "native")
        if not f_ or not n_:
            continue
        d = [a["ce_all"] - b["ce_all"] for a, b in
             zip(sorted(f_, key=lambda x: x["seed"]),
                 sorted(n_, key=lambda x: x["seed"]))]
        native_check.append({"arm": arm, "max_abs_diff": float(max(abs(x) for x in d)),
                             "all_zero": bool(max(abs(x) for x in d) < 1e-12)})

    # バイアス buggy - fixed（seed 対応）
    bias = {}
    for key, rs in by.items():
        arm, cond, mode = key
        if mode != "buggy":
            continue
        f_ = {r["seed"]: r for r in get(arm, cond, "fixed")}
        b_ = {r["seed"]: r for r in rs}
        seeds = sorted(set(f_) & set(b_))
        d = np.array([b_[s]["ce_all"] - f_[s]["ce_all"] for s in seeds])
        dc = np.array([b_[s]["ce_copy"] - f_[s]["ce_copy"] for s in seeds])
        bias["|".join((arm, cond))] = {
            "d_ce": float(d.mean()), "se": float(d.std(ddof=1) / np.sqrt(len(d))),
            "per_seed": d.tolist(), "d_ce_copy": float(dc.mean()),
            "n": len(seeds),
        }

    # P13 §4 の差 H+LB base - dense180 が fixed / buggy でどうなるか
    def gap(mode):
        h = summary["H+LB|base|" + mode]["ce"]
        d = summary["dense180|dense|" + mode]["ce"]
        return {"H_ce": h, "dense_ce": d, "gap": h - d}

    gap_fixed, gap_buggy = gap("fixed"), gap("buggy")

    # 条件 D: 同 params の H+LB vs U+LB（fixed / base）
    h_rows = sorted(get("H+LB", "base", "fixed"), key=lambda x: x["seed"])
    u_rows = sorted(get("U+LB", "base", "fixed"), key=lambda x: x["seed"])
    d_seed = np.array([a["ce_all"] - b["ce_all"] for a, b in zip(h_rows, u_rows)])
    se_seed = float(d_seed.std(ddof=1) / np.sqrt(len(d_seed)))
    t_seed = float(d_seed.mean() / se_seed) if se_seed > 0 else float("nan")
    p_seed = float(2 * stats.t.sf(abs(t_seed), df=len(d_seed) - 1))
    mde_seed = float(stats.t.ppf(0.975, len(d_seed) - 1) * se_seed)

    cond_d_by_seed = []
    for a, b in zip(h_rows, u_rows):
        da = np.array(a["ce_seq"]) - np.array(b["ce_seq"])
        tt = stats.ttest_rel(np.array(a["ce_seq"]), np.array(b["ce_seq"]))
        absd = np.abs(da)
        ntop = max(1, int(math.ceil(len(absd) * 0.01)))
        top1_share = float(np.sort(absd)[-ntop:].sum() / max(1e-12, absd.sum()))
        cond_d_by_seed.append({
            "seed": a["seed"], "delta": float(da.mean()),
            "se": float(da.std(ddof=1) / np.sqrt(len(da))),
            "t": float(tt.statistic), "p": float(tt.pvalue),
            "n_seq": int(len(da)), "top1_share": top1_share,
            "median": float(np.median(da)), "max": float(np.max(da)),
        })

    cond_d = {
        "H_ce": float(np.mean([r["ce_all"] for r in h_rows])),
        "U_ce": float(np.mean([r["ce_all"] for r in u_rows])),
        "params_H": int(h_rows[0]["nparam"]),
        "params_U": int(u_rows[0]["nparam"]),
        "seed_level": {
            "delta": float(d_seed.mean()), "se": se_seed, "t": t_seed,
            "p": p_seed, "n": int(len(d_seed)), "mde": mde_seed,
            "per_seed": d_seed.tolist(),
            "n_neg": int((d_seed < 0).sum()),
        },
        "seq_level": cond_d_by_seed,
    }

    analysis = {
        "summary": summary, "calibration": calib, "native_check": native_check,
        "bias_buggy_minus_fixed": bias,
        "p13_s4_gap": {"fixed": gap_fixed, "buggy": gap_buggy,
                       "gap_change": gap_buggy["gap"] - gap_fixed["gap"]},
        "condition_D": cond_d,
        "meta": {"n_eval": args.n_eval, "seeds": args.seeds,
                 "threads": args.threads, "eval_seed": 777,
                 "ckpt_dir": OUTDIR, "n_rows": len(rows)},
    }
    with open(os.path.join(HERE, "p13d_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2, default=float)

    log("")
    log("== 校正（fixed vs p13c_analysis.json）==")
    for c in calib:
        log("  %-14s ref %.9f  fixed %.9f  diff %.3g  bit_match=%s"
            % (c["key"], c["ref_ce"], c["fixed_ce"] or float("nan"),
               c["abs_diff"] if c["abs_diff"] is not None else float("nan"),
               c["bit_match"]))
    log("")
    log("== バイアス buggy - fixed ==")
    for k, v in bias.items():
        log("  %-18s ΔCE %+.6f  se %.6f  n %d"
            % (k, v["d_ce"], v["se"], v["n"]))
    log("")
    log("== P13 §4 の差 H+LB base - dense180 ==")
    log("  fixed %.6f - %.6f = %+.6f" % (gap_fixed["H_ce"], gap_fixed["dense_ce"], gap_fixed["gap"]))
    log("  buggy %.6f - %.6f = %+.6f" % (gap_buggy["H_ce"], gap_buggy["dense_ce"], gap_buggy["gap"]))
    log("")
    log("== 条件 D（同 params の H+LB - U+LB, fixed/base）==")
    s = cond_d["seed_level"]
    log("  H %.6f  U %.6f  params %d / %d"
        % (cond_d["H_ce"], cond_d["U_ce"], cond_d["params_H"], cond_d["params_U"]))
    log("  Δ %+.6f  se %.6f  t %+.4f  p %.4f  n %d  MDE %.6f  負 %d"
        % (s["delta"], s["se"], s["t"], s["p"], s["n"], s["mde"], s["n_neg"]))
    for r in cond_d_by_seed:
        log("  s%d 系列対応 Δ %+.6f  t %+.2f  n_seq %d  top1_share %.4f"
            % (r["seed"], r["delta"], r["t"], r["n_seq"], r["top1_share"]))
    log("")
    log("saved: p13d_results.json / p13d_analysis.json")
    os._exit(0)


if __name__ == "__main__":
    main()
