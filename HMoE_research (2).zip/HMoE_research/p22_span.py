# -*- coding: utf-8 -*-
"""P22: 思考中の数字を span から除く（P20 §6-4 の宿題）

P20 は「全文の最後の数字列」を答えとしたため、思考が終わっていないサンプルの
**思考中の断片**（例: "...80,00"）を答えとして拾っていた。本スクリプトは
``</think>`` 以降だけを答え領域とし、**思考が閉じていないサンプルは「答えなし」**とする。

再生成は不要: Qwen3 のテンプレートは ``</think>`` を**通常テキスト**として出すので、
P20 が保存した text にそのまま残っている（26/80）。P20 と同一の 80 サンプルに対する
**抽出規則だけの A/B** になる。

やること:
  1. 各サンプルで ``</think>`` の位置を探し、以降を答え領域とする
  2. 答え領域の最後の数字列を答えとする（pred_ans）。``</think>`` が無ければ答えなし
  3. その span に対して p_ans を採点し直す（P20 の p_ans は全文基準）
  4. P20 の pred（全文基準）と突き合わせて、規則の差だけを分離する

出力: p22_span.jsonl / p22_meta.json
"""

import argparse
import json
import os
import re

import numpy as np
import torch

from p14_bestofn import score_sample, extract_value

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "qwen3-0.6b")
SYS = "You are a careful arithmetic assistant. Solve the problem and give the final answer."
END = "</" + "think>"          # テンプレート由来の通常テキスト
NUM_RE = re.compile(r"\d[\d,]*")


def log(m):
    print(m, flush=True)


@torch.no_grad()
def score_after_think(model, tok, prompt_ids, txt, eos_id):
    """``</think>`` 以降の最後の数字列を採点する。無ければ p_ans=None。

    位置の規約は p14_bestofn.score_sample と同じ（row = 位置−1）。
    """
    out = {"p_ans": None, "n_ans": 0, "has_end": False, "n_end": 0,
           "ans_region_len": 0, "err": ""}
    n_end = txt.count(END)
    out["n_end"] = n_end
    if n_end == 0:
        out["err"] = "no_end_think"
        return out
    out["has_end"] = True
    i = txt.rfind(END)
    region = txt[i + len(END):]
    out["ans_region_len"] = len(region)
    matches = list(NUM_RE.finditer(region))
    if not matches:
        out["err"] = "no_number_in_region"
        return out
    ms, me = matches[-1].span()
    off = i + len(END)
    ms, me = ms + off, me + off
    enc = tok(txt, add_special_tokens=False, return_offsets_mapping=True)
    ids, offs = enc["input_ids"], enc["offset_mapping"]
    idx = [j for j, (s, e) in enumerate(offs) if s < me and e > ms]
    if not idx:
        out["err"] = "no_overlap"
        return out
    seq = list(prompt_ids) + list(ids)
    inp = torch.tensor([seq], dtype=torch.long, device=model.device)
    logits = model(inp).logits[0]
    rows = torch.tensor([len(prompt_ids) + j - 1 for j in idx], device=model.device)
    tgt = torch.tensor([ids[j] for j in idx], device=model.device)
    lp = torch.log_softmax(logits.index_select(0, rows).float(), dim=-1)
    lp_ans = lp.gather(1, tgt.unsqueeze(1)).squeeze(1).double()
    out["p_ans"] = float(torch.exp(lp_ans.mean()).item())
    out["n_ans"] = int(lp_ans.shape[0])
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="p22")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer
    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    eos_id = tok.eos_token_id
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, torch_dtype=torch.bfloat16, device_map="cuda",
        attn_implementation="sdpa").eval()

    rows = [json.loads(l) for l in open(os.path.join(HERE, "p20_think.jsonl"),
                                        encoding="utf-8") if l.strip()]
    recs = [r for r in rows if r.get("round") != "greedy"]

    out_recs = []
    n_proc = 0
    for r in recs:
        prompt = tok.apply_chat_template(
            [{"role": "system", "content": SYS}, {"role": "user", "content": r["q"]}],
            tokenize=False, add_generation_prompt=True, enable_thinking=True)
        pid = tok(prompt, add_special_tokens=False)["input_ids"]
        samples = []
        for s in r["samples"]:
            txt = s["text"]
            sc = score_after_think(model, tok, pid, txt, eos_id)
            # 答え領域の最後の数字列（テキストだけでも取れる）
            pred_ans = None
            if sc["has_end"]:
                region = txt[txt.rfind(END) + len(END):]
                m = NUM_RE.findall(region)
                pred_ans = m[-1].replace(",", "") if m else None
            samples.append({
                "pred_whole": s["pred"], "correct_whole": s["correct"],
                "pred_ans": pred_ans,
                "correct_ans": None if pred_ans is None else (pred_ans == r["gold"]),
                "has_end": sc["has_end"], "n_end": sc["n_end"],
                "ans_region_len": sc["ans_region_len"],
                "p_ans_region": sc["p_ans"], "n_ans_region": sc["n_ans"],
                "p_ans_whole": s["p_ans"], "p_full": s["p_full"],
                "ntok": s["ntok"], "finished": s["finished"],
                "boxed": s["boxed"], "final_phr": s["final_phr"],
                "err": sc["err"]})
            n_proc += 1
        out_recs.append({"round": r["round"], "q": r["q"], "gold": r["gold"],
                         "samples": samples})
        log("done %s (%d samples so far)" % (r["q"], n_proc))

    S = [s for r in out_recs for s in r["samples"]]
    meta = {"n_recs": len(out_recs), "n_samples": len(S),
            "has_end_rate": float(np.mean([s["has_end"] for s in S])),
            "n_end_multi": int(sum(1 for s in S if s["n_end"] > 1)),
            "answered_rate_ans": float(np.mean([s["pred_ans"] is not None for s in S])),
            "answered_rate_whole": float(np.mean([s["pred_whole"] is not None for s in S])),
            "note": "P20 と同一サンプル。抽出規則だけを差し替えた（再生成なし）",
            "end_marker": END, "model": MODEL}
    with open(os.path.join(HERE, "%s_span.jsonl" % args.tag), "w", encoding="utf-8") as fp:
        for r in out_recs:
            fp.write(json.dumps(r, ensure_ascii=False) + "\n")
    with open(os.path.join(HERE, "%s_meta.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(meta, fp, ensure_ascii=False, indent=2)
    log(json.dumps(meta, ensure_ascii=False))
    os._exit(0)


if __name__ == "__main__":
    main()
