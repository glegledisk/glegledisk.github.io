# -*- coding: utf-8 -*-
"""P10 解析: 自信の歪みの分解

入力: p10_auroc.npz
出力: p10_analysis.json / p10_analysis_out_utf8.txt

AUROC が落ちるとき、何が起きているか:
  p_top1 が一様に上がるだけなら AUROC は変わらない。
  落ちるなら「不正解トークンの p_top1 が正解トークンより多く上がった」はず。
  そこで 確信度差 = mean p_top1(正解) − mean p_top1(不正解) を条件間で比べる。
"""

import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
CONDS = ["base", "f1", "u1", "f1_rs"]


def auroc(score, label):
    score = np.asarray(score, np.float64)
    label = np.asarray(label, bool)
    npos = int(label.sum())
    nneg = label.size - npos
    if npos == 0 or nneg == 0:
        return float("nan")
    order = np.argsort(score, kind="mergesort")
    ranks = np.empty(score.size, np.float64)
    ranks[order] = np.arange(1, score.size + 1)
    s = score[order]
    i = 0
    while i < s.size:
        j = i
        while j + 1 < s.size and s[j + 1] == s[i]:
            j += 1
        if j > i:
            ranks[order[i:j + 1]] = (i + j + 2) / 2.0
        i = j + 1
    return float((ranks[label].sum() - npos * (npos + 1) / 2) / (npos * nneg))


def ece(conf, correct, nb=15):
    conf = np.asarray(conf, np.float64)
    correct = np.asarray(correct, np.float64)
    e = 0.0
    edges = np.linspace(0, 1, nb + 1)
    for i in range(nb):
        m = (conf > edges[i]) & (conf <= edges[i + 1])
        if m.sum():
            e += m.mean() * abs(correct[m].mean() - conf[m].mean())
    return float(e)


def main():
    z = np.load(os.path.join(HERE, "p10_auroc.npz"), allow_pickle=True)
    lang = z["lang"]
    d = {c: {f: z["%s_%s" % (c, f)] for f in ("nll", "ptop", "correct", "gold_p")}
         for c in CONDS}
    n = d["base"]["nll"].size
    nw = lang.size
    per = n // nw
    assert per * nw == n
    tok_lang = np.repeat(lang, per)

    lines = []
    def emit(s=""):
        lines.append(s)
        print(s, flush=True)

    emit("=== P10 自信の歪み（n=%d, %d 窓）===" % (n, nw))
    emit("")
    out = {"n_tokens": int(n), "n_windows": int(nw)}

    # ---------- 0. 水準と AUROC ----------
    emit("[0] 水準 / 識別力")
    emit("%-7s %9s %7s %8s %8s %8s %8s %8s" %
         ("cond", "CE", "top1", "p_top1", "p(corr)", "p(wrong)", "gap", "AUROC"))
    for c in CONDS:
        r = d[c]
        cor = r["correct"]
        pc = r["ptop"][cor].mean()
        pw = r["ptop"][~cor].mean()
        au = auroc(r["ptop"], cor)
        emit("%-7s %9.5f %7.4f %8.4f %8.4f %8.4f %8.4f %8.4f"
             % (c, r["nll"].mean(), cor.mean(), r["ptop"].mean(), pc, pw, pc - pw, au))
        out.setdefault("levels", {})[c] = {
            "ce": float(r["nll"].mean()), "top1": float(cor.mean()),
            "ptop": float(r["ptop"].mean()), "p_correct": float(pc),
            "p_wrong": float(pw), "gap": float(pc - pw), "auroc": au,
            "ece": ece(r["ptop"], cor)}
    emit("")

    # ---------- 1. 窓クラスタの対応差 ----------
    emit("[1] 窓クラスタ対応差（48 窓）")
    emit("%-14s %9s %9s %8s %8s %9s" % ("対比", "ΔAUROC", "Δgap", "se", "t", "MDE80"))
    for c in CONDS[1:]:
        da, dg = [], []
        for w in range(nw):
            sl = slice(w * per, (w + 1) * per)
            A, B = d[c], d["base"]
            da.append(auroc(A["ptop"][sl], A["correct"][sl]) -
                      auroc(B["ptop"][sl], B["correct"][sl]))
            ga = A["ptop"][sl][A["correct"][sl]].mean() - A["ptop"][sl][~A["correct"][sl]].mean()
            gb = B["ptop"][sl][B["correct"][sl]].mean() - B["ptop"][sl][~B["correct"][sl]].mean()
            dg.append(ga - gb)
        da, dg = np.array(da), np.array(dg)
        se = da.std(ddof=1) / np.sqrt(nw)
        seg = dg.std(ddof=1) / np.sqrt(nw)
        emit("%-14s %+9.4f %+9.4f %8.4f %+8.2f %9.4f"
             % (c + " − base", da.mean(), dg.mean(), se, da.mean() / se, 2.8 * se))
        out.setdefault("delta", {})[c] = {
            "d_auroc": float(da.mean()), "d_auroc_se": float(se),
            "d_auroc_t": float(da.mean() / se), "d_auroc_mde80": float(2.8 * se),
            "d_gap": float(dg.mean()), "d_gap_se": float(seg),
            "d_gap_t": float(dg.mean() / seg)}
    emit("")

    # ---------- 2. どこで上がったか（正解 / 不正解）----------
    emit("[2] p_top1 の変化を正解・不正解に分ける（base との差）")
    for c in CONDS[1:]:
        dc = d[c]["ptop"][d[c]["correct"]].mean() - d["base"]["ptop"][d["base"]["correct"]].mean()
        dw = d[c]["ptop"][~d[c]["correct"]].mean() - d["base"]["ptop"][~d["base"]["correct"]].mean()
        emit("    %-6s 正解 +%.4f / 不正解 %+.4f  → 不正解の方が %+.4f 大きく動いた"
             % (c, dc, dw, dw - dc))
        out.setdefault("shift", {})[c] = {"d_correct": float(dc), "d_wrong": float(dw)}
    emit("")

    # ---------- 3. 閾値運用 ----------
    emit("[3] 閾値 τ=0.8 の運用")
    emit("%-7s %8s %10s %10s %10s" % ("cond", "自動化率", "自動化内誤り", "全体誤り", "取りこぼし"))
    for c in CONDS:
        r = d[c]
        hi = r["ptop"] >= 0.8
        emit("%-7s %8.4f %10.4f %10.4f %10.4f"
             % (c, hi.mean(), (~r["correct"][hi]).mean() if hi.sum() else float("nan"),
                (~r["correct"]).mean(), (~r["correct"][~hi]).mean() if (~hi).sum() else float("nan")))
        out.setdefault("threshold", {})[c] = {
            "auto_rate": float(hi.mean()),
            "err_in_auto": float((~r["correct"][hi]).mean()) if hi.sum() else None,
            "err_all": float((~r["correct"]).mean())}
    emit("")

    # ---------- 4. 言語別 ----------
    emit("[4] 言語別 AUROC")
    out["per_lang"] = {}
    for lg in ("en", "ja"):
        sel = (tok_lang == lg)
        row = []
        for c in CONDS:
            row.append(auroc(d[c]["ptop"][sel], d[c]["correct"][sel]))
        emit("    %s: %s" % (lg, "  ".join("%s %.4f" % (c, v) for c, v in zip(CONDS, row))))
        out["per_lang"][lg] = {c: v for c, v in zip(CONDS, row)}
    emit("")

    with open(os.path.join(HERE, "p10_analysis.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2, default=float)
    with open(os.path.join(HERE, "p10_analysis_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(lines) + "\n")
    print("saved: p10_analysis.json / p10_analysis_out_utf8.txt")


if __name__ == "__main__":
    main()
