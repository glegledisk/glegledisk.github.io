# -*- coding: utf-8 -*-
"""_a5_verify_report.py — 考察_ルータの頑健性… の数値を一次データから引き直して突合する。"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a4")
ok, bad = [], []


def chk(name, got, want, tol=5e-3):
    if abs(got - want) <= tol * max(1.0, abs(want)):
        ok.append(f"  OK  {name}: {got:.6g} (report {want})")
    else:
        bad.append(f"  NG  {name}: {got:.6g} != report {want}")


base = [r for r in json.load(open(os.path.join(D, "a4_results.json"), encoding="utf-8"))
        if "evals" in r and r["arm"] == "all_relu"]
probe = [r for r in json.load(open(os.path.join(D, "a4_results_p.json"), encoding="utf-8"))
         if "evals" in r]
arms = sorted({r["arm"] for r in probe})
seeds = sorted({r["seed"] for r in probe} & {r["seed"] for r in base})
E = len(base[0]["routing"]["usage"])
W = base[0]["widths"]


def sh(rows, arm, i):
    return np.array([r["routing"]["usage"][i] for r in rows
                     if r["arm"] == arm and r["seed"] in seeds])


def ivv(rows, arm):
    return np.array([r["evals"][-1]["instr_valid"] for r in rows
                     if r["arm"] == arm and r["seed"] in seeds])


EPS = {0: 0.1155, 1: 0.1160, 2: 0.0572, 3: 0.0330, 4: 0.0192, 5: 0.0145, 6: 0.0034, 7: 0.0103}
S0 = {0: 0.2953, 1: 0.2822, 2: 0.1155, 3: 0.1054, 4: 0.0648, 5: 0.0601, 6: 0.0351, 7: 0.0416}
S1 = {0: 0.1797, 1: 0.1662, 2: 0.0584, 3: 0.0724, 4: 0.0456, 5: 0.0457, 6: 0.0316, 7: 0.0312}
DIV = {0: 0.000, 1: 0.102, 2: -0.140, 3: 0.103, 4: 0.148, 5: 0.164, 6: -0.108, 7: 0.190}

eps_v, sh_v, w_v, dv_v = [], [], [], []
for i in range(E):
    a = f"deg_e{i}"
    s0, s1 = sh(base, "all_relu", i), sh(probe, a, i)
    eps = float(-(s1 - s0).mean())
    chk(f"ε e{i}", eps, EPS[i], tol=5e-3)
    chk(f"share(base) e{i}", float(s0.mean()), S0[i], tol=5e-3)
    chk(f"share(deg) e{i}", float(s1.mean()), S1[i], tol=5e-3)
    chk(f"Δiv e{i}", float((ivv(probe, a) - ivv(base, "all_relu")).mean()), DIV[i], tol=2e-2)
    eps_v.append(eps)
    sh_v.append(float(s0.mean()))
    w_v.append(W[i])
    dv_v.append(float((ivv(probe, a) - ivv(base, "all_relu")).mean()))
eps_v, sh_v, w_v, dv_v = map(np.array, (eps_v, sh_v, w_v, dv_v))

chk("r(ε, share)", float(stats.pearsonr(eps_v, sh_v)[0]), 0.990, tol=2e-3)
chk("r(ε, w)", float(stats.pearsonr(eps_v, w_v)[0]), -0.922, tol=5e-3)
chk("r(ε, Δiv)", float(stats.pearsonr(eps_v, dv_v)[0]), -0.175, tol=5e-2)
chk("ε/share の平均", float((eps_v / sh_v).mean()), 0.312, tol=2e-2)
chk("ε/share e2", float(eps_v[2] / sh_v[2]), 0.495, tol=1e-2)
chk("ε/share e6", float(eps_v[6] / sh_v[6]), 0.098, tol=5e-2)

# 使用率で回帰した残差
A = np.vstack([np.ones_like(sh_v), sh_v]).T
coef, *_ = np.linalg.lstsq(A, eps_v, rcond=None)
res = eps_v - A @ coef
chk("残差 最大（e2）", float(res[2]), 0.0151, tol=5e-2)
chk("残差 2 番目", float(np.sort(np.abs(res))[-2]), 0.0047, tol=1e-1)

# 置換行列の行和は 0
M = np.zeros((E, E))
for i in range(E):
    for j in range(E):
        M[i, j] = float((sh(probe, f"deg_e{i}", j) - sh(base, "all_relu", j)).mean())
for i in range(E):
    chk(f"行和 e{i}", float(M[i].sum()), 0.0, tol=1.0)
# 報告書に載せたセル
CELL = {(0, 0): -0.116, (0, 1): 0.033, (0, 2): 0.018, (0, 3): 0.031, (0, 5): 0.015,
        (1, 0): 0.027, (1, 1): -0.116, (1, 2): 0.028, (1, 5): 0.024,
        (2, 2): -0.057, (2, 5): 0.020, (4, 0): 0.024, (4, 1): -0.036, (4, 4): -0.019,
        (7, 0): -0.024, (7, 5): 0.016, (7, 7): -0.010}
for (i, j), v in CELL.items():
    chk(f"M[{i},{j}]", float(M[i, j]), v, tol=2e-2)

# 疎性の会計
tot = sum(W)
share_w = (W[6] + W[7]) / tot
chk("e6+e7 の幅シェア", share_w, 0.4375, tol=1e-3)
chk("楽観 45%", share_w * 0.45, 0.197, tol=1e-2)
chk("保守 5%", share_w * 0.05, 0.0219, tol=2e-2)
chk("楽観 / 1.323", share_w * 0.45 / 1.323, 0.149, tol=1e-2)
chk("保守 / 1.323", share_w * 0.05 / 1.323, 0.0165, tol=3e-2)

# A4 の large_relu2 の数値（引用）
a4an = json.load(open(os.path.join(D, "a4_analysis.json"), encoding="utf-8"))
c = {(x["a"], x["b"], x["metric"]): x for x in a4an["contrasts"]}
chk("A4 large_relu2−all_relu iv", c[("large_relu2", "all_relu", "instr_valid")]["mean"],
    0.045, tol=2e-2)
chk("A4 large_relu2−all_relu CE", c[("large_relu2", "all_relu", "ce_all")]["mean"],
    -0.0013, tol=5e-2)
chk("A4 all_relu2−all_relu iv", c[("all_relu2", "all_relu", "instr_valid")]["mean"],
    -0.522, tol=1e-2)

print("\n".join(ok))
if bad:
    print("\n".join(bad))
    print(f"\nFAIL: {len(bad)} 件")
    sys.exit(1)
print(f"\nPASS: {len(ok)} 件すべて報告書と一致")
