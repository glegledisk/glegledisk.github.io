# -*- coding: utf-8 -*-
"""_a2_verify_report.py — 検証報告_A2 の数値を一次データから引き直して突合する。"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a2")
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))
import q1_trace_routing as Q1          # noqa: E402

ok, bad = [], []


def chk(name, got, want, tol=5e-3):
    if abs(got - want) <= tol * max(1.0, abs(want)):
        ok.append(f"  OK  {name}: {got:.6g} (report {want})")
    else:
        bad.append(f"  NG  {name}: {got:.6g} != report {want}")


rows = [r for r in json.load(open(os.path.join(D, "a2_results.json"), encoding="utf-8"))
        if "evals" in r]
ident = json.load(open(os.path.join(D, "a2_identity.json"), encoding="utf-8"))
an = json.load(open(os.path.join(D, "a2_analysis.json"), encoding="utf-8"))

# --- 1. 構成的結果 ---
chk("identity sm_norm mass", ident["sm_norm"]["mass_mean"], 1.0000)
chk("identity sig_norm mass", ident["sig_norm"]["mass_mean"], 1.0000)
chk("identity sig_raw mass", ident["sig_raw"]["mass_mean"], 1.0703)
chk("identity sm_raw mass", ident["sm_raw"]["mass_mean"], 0.2875)
chk("identity sm_raw min", ident["sm_raw"]["mass_min"], 0.262)
chk("identity sm_raw max", ident["sm_raw"]["mass_max"], 0.328)
chk("identity sig_raw min", ident["sig_raw"]["mass_min"], 0.984)
chk("identity sig_raw max", ident["sig_raw"]["mass_max"], 1.171)
for a, g in (("sm_norm", 0.518), ("sig_norm", 0.508), ("sig_raw", 0.544), ("sm_raw", 0.149)):
    chk(f"identity gate_max {a}", ident[a]["gate_max_mean"], g)
for a in ("sig_norm", "sig_raw", "sm_raw"):
    if not ident[a].get("selection_identical"):
        bad.append(f"  NG  選択が一致しない: {a}")

# --- 2. 到達点 ---
TAB = {"sm_norm": (1.0000, -0.0019, 0.9926, 0.9945, 0.643, 0.0219),
       "sig_norm": (1.0000, 0.0000, 0.9873, 0.9873, 0.494, 0.0435),
       "sig_raw": (0.9603, -0.0029, 0.9916, 0.9945, 0.609, 0.0208),
       "sm_raw": (0.5901, -0.0022, 0.9888, 0.9910, 0.494, 0.0311)}
for a, (m, g, c, ac, iv, ce) in TAB.items():
    rs = [r for r in rows if r["arm"] == a]
    e = lambda k: float(np.mean([r["evals"][-1][k] for r in rs]))
    chk(f"mass {a}", e("mass_mean"), m, tol=2e-3)
    chk(f"gap {a}", e("gap_all"), g, tol=2e-2)
    chk(f"conf {a}", e("conf_all"), c, tol=2e-3)
    chk(f"acc {a}", e("acc_all"), ac, tol=2e-3)
    chk(f"instr {a}", e("instr_valid"), iv, tol=5e-3)
    chk(f"CE {a}", e("ce_all"), ce, tol=5e-3)

# --- 3. 質量の初期値と軌跡 ---
for a, v in (("sig_raw", 1.1522), ("sm_raw", 0.3002)):
    got = float(np.mean([r["init_eval"]["mass_mean"] for r in rows if r["arm"] == a]))
    chk(f"mass init {a}", got, v, tol=3e-3)
TRAJ = {"sig_raw": (0.9996, 0.9953, 0.9603), "sm_raw": (0.4392, 0.5434, 0.5901)}
for a, vs in TRAJ.items():
    rs = [r for r in rows if r["arm"] == a]
    for k, v in enumerate(vs):
        got = float(np.mean([r["evals"][k]["mass_mean"] for r in rs]))
        chk(f"mass ep{k+1} {a}", got, v, tol=3e-3)

# --- 4. 対比 ---
got = {(c["a"], c["b"], c["metric"]): c for c in an["contrasts"]}
WANT = {("sm_raw", "sm_norm", "mass_mean"): (-0.4099, 0.0),
        ("sm_raw", "sm_norm", "gap_all"): (-0.0003, 0.616),
        ("sig_raw", "sm_norm", "acc_all"): (+0.0000, 0.989),
        ("sig_raw", "sm_norm", "ce_all"): (-0.0011, 0.826),
        ("sig_raw", "sm_norm", "instr_valid"): (-0.0343, 0.457),
        ("sig_norm", "sm_norm", "instr_valid"): (-0.1488, 0.171),
        ("sig_norm", "sm_norm", "ce_all"): (+0.0216, 0.221),
        ("sig_norm", "sm_norm", "gap_all"): (+0.0019, 0.336)}
for k, (m, p) in WANT.items():
    c = got.get(k)
    if c is None:
        bad.append(f"  NG  対比が無い: {k}")
        continue
    chk(f"{k[0]}-{k[1]} {k[2]} mean", c["mean"], m, tol=5e-3)
    if p > 0:
        chk(f"{k[0]}-{k[1]} {k[2]} p", c["p"], p, tol=5e-2)

# --- 5. within-arm 相関 ---
R = {"sm_norm": 0.0012, "sig_norm": 0.0024, "sig_raw": -0.0327, "sm_raw": -0.0097}
for a, v in R.items():
    rs = [r for r in rows if r["arm"] == a]
    rr = []
    for r in rs:
        z = np.load(os.path.join(D, f"ptok_{a}_s{r['seed']}.npz"))
        m, c = z["mass"].ravel(), z["conf"].ravel()
        if m.std() > 1e-9:
            rr.append(float(np.corrcoef(m, c)[0, 1]))
    chk(f"within r {a}", float(np.mean(rr)), v, tol=5e-2)

# --- 6. 中央値と失敗 seed 数 ---
MED = {"sm_norm": (0.620, 0), "sig_norm": (0.579, 2), "sig_raw": (0.617, 0), "sm_raw": (0.547, 2)}
for a, (med, nfail) in MED.items():
    v = np.array([r["evals"][-1]["instr_valid"] for r in rows if r["arm"] == a])
    chk(f"median iv {a}", float(np.median(v)), med, tol=1e-2)
    chk(f"n<0.3 {a}", int((v < 0.3).sum()), nfail, tol=0)

# --- 7. A1 との一致（測定器の校正）---
a1 = json.load(open(os.path.join(HERE, "data", "a1", "a1_results.json"), encoding="utf-8"))
a1relu = {r["seed"]: r["evals"][-1]["ce_all"] for r in a1 if r["arm"] == "relu"}
for r in rows:
    if r["arm"] != "sm_norm":
        continue
    d = abs(r["evals"][-1]["ce_all"] - a1relu[r["seed"]])
    if d > 1e-9:
        bad.append(f"  NG  A1 の relu と不一致 seed{r['seed']}: Δ={d:.3e}")
if not any("A1" in b for b in bad):
    ok.append("  OK  sm_norm は A1 の relu と seed 別に完全一致（Δ < 1e-9）")

print("\n".join(ok))
if bad:
    print("\n".join(bad))
    print(f"\nFAIL: {len(bad)} 件")
    sys.exit(1)
print(f"\nPASS: {len(ok)} 件すべて報告書と一致")
