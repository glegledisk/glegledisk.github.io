#!/usr/bin/env python3
"""A3 の検算と集計。「ReLU² の勝ちは幅で説明できる」を 3 つの形で見る。

検定の構造
  H 「幅だけで決まる」  → (a) relu2_1x < swiglu_1x かつ (b) relu2_15x ≈ swiglu_1x
  H'「形も効く」        → (b') relu2_15x > swiglu_1x
  A1 の再現             → relu2_15x < swiglu_1x（幅を与えても負ける）

分解の恒等式（幅だけで説明できるなら厳密に成り立つ）
  (relu2_15x − relu2_1x)  =  (swiglu_1x − relu2_1x)
  つまり「幅を 1.5 倍にした得」が「3 行列との差」をちょうど埋める。
"""
import argparse
import json
import math
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a3")
ORDER = ["relu_1x", "relu_15x", "relu2_1x", "relu2_15x", "swiglu_1x", "swiglu_15x"]


def load(tag=""):
    with open(os.path.join(D, f"a3_results{tag}.json"), encoding="utf-8") as fh:
        return [r for r in json.load(fh) if "evals" in r]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="")
    ap.add_argument("--json", default="a3_analysis.json")
    args = ap.parse_args()

    rows = load(args.tag)
    arms = [a for a in ORDER if any(r["arm"] == a for r in rows)]
    E = len(rows[0]["evals"])

    print("=== 1. 構成 ===")
    print("  n per arm:", {a: sum(1 for r in rows if r["arm"] == a) for a in arms})
    print(f"  {'arm':11s}{'act':8s}{'mat':>4s}{'params':>11s}{'MACs':>8s}{'gain':>7s}"
          f"{'widths':>34s}")
    for a in arms:
        r = next(x for x in rows if x["arm"] == a)
        print(f"  {a:11s}{r['act']:8s}{r['n_mat']:>4d}{r['nparam']:>11,}"
              f"{r['nominal_macs']:>8.0f}{r['gain']:>7.2f}   {tuple(r['widths'])}")

    def col(a, k, key):
        return np.array([r["evals"][k][key] for r in rows if r["arm"] == a])

    print("\n=== 2. 到達点（最終 epoch, n=6）===")
    print(f"  {'arm':11s}{'CE':>9s}{'instr':>8s}{'acc_pl':>9s}")
    for a in arms:
        print(f"  {a:11s}{col(a, E-1, 'ce_all').mean():>9.4f}"
              f"{col(a, E-1, 'instr_valid').mean():>8.3f}"
              f"{col(a, E-1, 'acc_payload').mean():>9.4f}")

    def paired(a, b, key, ep=-1):
        da = {r["seed"]: r["evals"][ep][key] for r in rows if r["arm"] == a}
        db = {r["seed"]: r["evals"][ep][key] for r in rows if r["arm"] == b}
        ks = sorted(set(da) & set(db))
        if len(ks) < 3:
            return None
        x = np.array([da[i] for i in ks])
        y = np.array([db[i] for i in ks])
        d = x - y
        n = len(d)
        se = d.std(ddof=1) / math.sqrt(n)
        t, p = stats.ttest_rel(x, y)
        ci = stats.t.ppf(0.975, n - 1) * se
        mde = (stats.t.ppf(0.975, n - 1) + stats.t.ppf(0.80, n - 1)) * se
        return dict(a=a, b=b, metric=key, n=n, mean=float(d.mean()), se=float(se),
                    t=float(t), p=float(p), ci_lo=float(d.mean() - ci),
                    ci_hi=float(d.mean() + ci), pos=int((d > 0).sum()), mde=float(mde),
                    per_seed=d.round(5).tolist())

    CONTRASTS = [
        ("relu_15x", "relu_1x", "幅（形は同じ）— 容量が縛られているかの確認"),
        ("relu2_15x", "relu2_1x", "幅（ReLU² 内）"),
        ("swiglu_15x", "swiglu_1x", "幅（SwiGLU 内）"),
        ("relu2_1x", "swiglu_1x", "等幅で ReLU² vs SwiGLU（ReLU² は params 2/3）"),
        ("relu2_15x", "swiglu_1x", "**等 params・等 MACs** で ReLU² vs SwiGLU"),
        ("relu2_15x", "relu_1x", "ReLU² 1.5 倍 vs ReLU 1 倍"),
        ("relu2_1x", "relu_1x", "等幅・等 params で ReLU² vs ReLU"),
    ]
    res = []
    print("\n=== 3. 対比（seed 対応、n=6、最終 epoch）===")
    for a, b, lab in CONTRASTS:
        if a not in arms or b not in arms:
            continue
        print(f"  [{lab}]  {a} − {b}")
        for key in ("instr_valid", "ce_all"):
            c = paired(a, b, key)
            if not c:
                continue
            c["label"] = lab
            res.append(c)
            star = " *" if c["p"] < 0.05 else "  "
            print(f"    {key:11s} Δ={c['mean']:+.4f} se={c['se']:.4f} t={c['t']:+.2f} "
                  f"p={c['p']:.4f}{star} {c['pos']}/{c['n']} "
                  f"CI[{c['ci_lo']:+.4f},{c['ci_hi']:+.4f}] MDE={c['mde']:.4f}")

    print("\n=== 4. 分解の恒等式（幅だけで説明できるなら差が 0）===")
    w = paired("relu2_15x", "relu2_1x", "instr_valid")
    s = paired("swiglu_1x", "relu2_1x", "instr_valid")
    t = paired("relu2_15x", "swiglu_1x", "instr_valid")
    if w and s and t:
        print(f"  幅の得（relu2_15x − relu2_1x）        = {w['mean']:+.4f}")
        print(f"  3 行列との差（swiglu_1x − relu2_1x）  = {s['mean']:+.4f}")
        print(f"  残差（relu2_15x − swiglu_1x）         = {t['mean']:+.4f}"
              f"   ← 0 なら幅で完全に説明できる")
        print(f"  残差 / 3 行列との差 = {t['mean']/s['mean'] if s['mean'] else float('nan'):+.3f}")
    print("\n  同じ分解を CE で")
    w2 = paired("relu2_15x", "relu2_1x", "ce_all")
    s2 = paired("swiglu_1x", "relu2_1x", "ce_all")
    t2 = paired("relu2_15x", "swiglu_1x", "ce_all")
    if w2 and s2 and t2:
        print(f"  幅の得 = {w2['mean']:+.4f} / 3 行列との差 = {s2['mean']:+.4f} / "
              f"残差 = {t2['mean']:+.4f}")

    print("\n=== 5. epoch ごとの軌跡（instr_valid）===")
    for a in arms:
        cells = "".join(f"{col(a, k, 'instr_valid').mean():>9.3f}" for k in range(E))
        print(f"  {a:11s}{cells}")

    agg = {}
    for a in arms:
        r = next(x for x in rows if x["arm"] == a)
        agg[a] = dict(n=sum(1 for x in rows if x["arm"] == a),
                      ce=float(col(a, E - 1, "ce_all").mean()),
                      ce_sd=float(col(a, E - 1, "ce_all").std(ddof=1)),
                      iv=float(col(a, E - 1, "instr_valid").mean()),
                      iv_sd=float(col(a, E - 1, "instr_valid").std(ddof=1)),
                      acc_pl=float(col(a, E - 1, "acc_payload").mean()),
                      iv_by_ep=[float(col(a, k, "instr_valid").mean()) for k in range(E)],
                      ce_by_ep=[float(col(a, k, "ce_all").mean()) for k in range(E)],
                      nparam=r["nparam"], macs=r["nominal_macs"],
                      n_mat=r["n_mat"], widths=r["widths"], gain=r["gain"])
    out = {"aggregate": agg, "contrasts": res, "epochs": E, "n_runs": len(rows),
           "scale": rows[0]["scale"]}
    with open(os.path.join(D, args.json), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(f"\n[write] {os.path.join(D, args.json)}")


if __name__ == "__main__":
    main()
