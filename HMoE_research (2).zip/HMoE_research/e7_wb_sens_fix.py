# -*- coding: utf-8 -*-
"""e7_wb_sens_fix.py — warm_bias 感度の正しい解析（ベースラインを旧 CSV とマージ）

問題: 新規実行した frozen_ffn / bias10 は seed {0, 7〜12} のみで、sp_wb3_w10 の 13 seed と
突き合わせると悪い seed に偏った 7 seed 部分サンプルになっていた。
旧 CSV（e7_routing_7seed.csv / e7_deadzone_7seed.csv）の seed 0〜6 とマージして 13 seed 化する。
seed 0 の再現性は確認済み（完全一致）なのでマージは妥当。
"""
import numpy as np
import pandas as pd

new = pd.read_csv("e7_staged_7seed.csv")
new["obj015"] = new["ce_all"] + 0.15 * new["ffn_cost"]
e7 = pd.read_csv("e7_routing_7seed.csv")
e7["obj015"] = e7["ce_all"] + 0.15 * e7["ffn_cost"]
dz = pd.read_csv("e7_deadzone_7seed.csv")
dz["obj015"] = dz["ce_all"] + 0.15 * dz["ffn_cost"]


def merge(old_df, old_key, new_name):
    """旧 CSV の seed 0〜6 と新規 run の seed 7〜12 をマージして 13 seed 化。"""
    o = old_df[old_df[old_key] if isinstance(old_key, str) else old_key].copy()
    o = o.rename(columns={"arm": "variant"} if "arm" in o.columns else {})
    o = o[o["seed"] <= 6]
    n = new[new.variant == new_name]
    n = n[n["seed"] >= 7]
    m = pd.concat([o[["variant", "seed", "ce_all", "ffn_cost", "obj015", "acc_all",
                      "acc_ff", "acc_fr", "acc_rr", "ce_ff", "ce_fr", "ce_rr",
                      "id_rate_ff", "id_rate_fr", "id_rate_rr"]],
                   n[["variant", "seed", "ce_all", "ffn_cost", "obj015", "acc_all",
                      "acc_ff", "acc_fr", "acc_rr", "ce_ff", "ce_fr", "ce_rr",
                      "id_rate_ff", "id_rate_fr", "id_rate_rr"]]], ignore_index=True)
    return m.set_index("seed")


ffn13 = merge(e7, e7.arm == "frozen_ffn", "frozen_ffn")
b1013 = merge(dz, dz.variant == "bias10", "bias10")
print(f"frozen_ffn 13 seeds: {sorted(ffn13.index.tolist())}")
print(f"bias10     13 seeds: {sorted(b1013.index.tolist())}")


def get(a):
    if a == "frozen_ffn":
        return ffn13
    if a == "bias10":
        return b1013
    return new[new.variant == a].set_index("seed")


print("\n=== 正しいサマリー（seed 数に注意） ===")
print(f"{'arm':14s} {'n':>3s} {'CE':>16s} {'median':>8s} {'max CE':>8s} {'FFN':>14s} "
      f"{'obj(λ=.15)':>16s} {'acc rr':>8s} {'id ff':>7s}")
for a in ["frozen_ffn", "bias10", "sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]:
    d = get(a)
    print(f"{a:14s} {len(d):3d} {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f} "
          f"{d['ce_all'].median():8.4f} {d['ce_all'].max():8.4f} "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f} {d['obj015'].mean():.4f}±{d['obj015'].std():.4f} "
          f"{d['acc_rr'].mean():8.4f} {d['id_rate_ff'].mean():7.3f}")


def paired(d_new, d_base, key):
    d = (d_new[key] - d_base[key]).dropna()
    m, sd = d.mean(), d.std(ddof=1)
    t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
    rng = np.random.default_rng(0)
    boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(20000)])
    lo, hi = np.percentile(boot, [2.5, 97.5])
    return m, lo, hi, t, int((d < 0).sum()), len(d)


print("\n=== 13 seed: sp_wb3_w10 の paired 検定（正しいベースライン） ===")
res = {}
d13 = get("sp_wb3_w10")
for base_name in ["frozen_ffn", "bias10"]:
    db = get(base_name)
    for k in ("obj015", "ce_all", "ffn_cost"):
        m, lo, hi, t, w_, n = paired(d13, db, k)
        res[f"wb3_vs_{base_name}_{k}"] = {"mean": float(m), "ci": [float(lo), float(hi)],
                                          "t": float(t), "wins": w_, "n": n}
        print(f" vs {base_name:10s}(n={n}) {k:9s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {w_}/{n}")

print("\n=== 中央値ベースの評価（外れ値の影響を除く） ===")
for a in ["frozen_ffn", "bias10", "sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]:
    d = get(a)
    print(f" {a:12s} CE 中央値 {d['ce_all'].median():.4f}  obj 中央値 {d['obj015'].median():.4f}  "
          f"FFN 中央値 {d['ffn_cost'].median():.3f}  CE>0.15: {int((d['ce_all']>0.15).sum())}/{len(d)}")

print("\n=== warm_bias 用量反応（seed 0〜6 で統一、paired vs 13seed baseline の対応 seed） ===")
for v in ["sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]:
    dv = get(v)
    dv7 = dv.loc[dv.index <= 6]
    for base_name in ["frozen_ffn", "bias10"]:
        db7 = get(base_name).loc[get(base_name).index <= 6]
        for k in ("obj015", "ce_all", "ffn_cost"):
            m, lo, hi, t, w_, n = paired(dv7, db7, k)
            print(f" {v:12s} vs {base_name:10s} {k:9s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {w_}/{n}")

print("\n=== E6 効果量からの回復率（13 seed baseline, obj） ===")
e6 = -0.1509
for a in ["bias10", "sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]:
    d = get(a)
    o = d["obj015"].mean() - ffn13["obj015"].mean()
    print(f" {a:12s} obj 差 {o:+.4f}（E6 の {100*o/e6:5.0f}%）  CE 差 {d['ce_all'].mean()-ffn13['ce_all'].mean():+.4f}  "
          f"FFN 差 {d['ffn_cost'].mean()-ffn13['ffn_cost'].mean():+.4f}")

print("\n=== 中央値ベースの E6 回復率 ===")
for a in ["bias10", "sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]:
    d = get(a)
    o = d["obj015"].median() - ffn13["obj015"].median()
    print(f" {a:12s} obj 中央値差 {o:+.4f}（E6 の {100*o/e6:5.0f}%）")

print("\n=== sp_wb3_w10 の seed 別（13 seed） ===")
d = get("sp_wb3_w10").sort_index()
for s, r in d.iterrows():
    print(f" s{s:2d}: CE {r['ce_all']:.4f}  FFN {r['ffn_cost']:.3f}  obj {r['obj015']:.4f}  "
          f"idff {r['id_rate_ff']:.3f}  acc_rr {r['acc_rr']:.3f}")

print("\n=== λ 感度（13 seed） ===")
print(f"{'λ':>5s} {'frozen_ffn':>12s} {'bias10':>10s} " + "".join(f"{v:>12s}" for v in ["sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]))
for lam in [0.03, 0.05, 0.08, 0.15, 0.30]:
    vals = {a: get(a)["ce_all"].mean() + lam * get(a)["ffn_cost"].mean()
            for a in ["frozen_ffn", "bias10", "sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]}
    print(f"{lam:5.2f} {vals['frozen_ffn']:12.4f} {vals['bias10']:10.4f} "
          + "".join(f"{vals[v]:12.4f}" for v in ["sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]))
