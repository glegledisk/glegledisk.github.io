#!/usr/bin/env python3
"""K1c: seed を増やして ΔCE(等 active 計算量の dense 生徒 − HMoE 教師) の CI を縮める。

なぜ並列か
  K1 の seed あたりコストは約 7〜9 分（教師 300〜400s + dense 140s、1 スレッド）。
  MDE 0.02 には 10 seed 要るので直列だと 90 分。**seed は独立**なので、
  プロセスを分けて 1 スレッドずつ走らせれば数倍速くなる（Q9: 1 スレッドは
  プロセスをまたいで完全一致するので、並列化は数値を変えない）。

  **各ワーカーは torch.set_num_threads(1) を必ず呼ぶ。** ここを 6 にすると
  数値が変わる（K1 §6、Q9）。

設計
  教師 : H+LB top-2（幅 32..224, p_pen auxw=0.05）
  生徒 : dense W=161（教師の平均 active 幅 160.9 と等 MACs、比 1.002〜1.058）
  条件 : K1 と同一（3000 系列 × 6 epoch, bs 32, lr 2e-3, 評価 seed 777 の 2048 系列）
  出力 : k1c_results.json / k1c_out_utf8.txt
"""
import argparse
import json
import os
import sys
import time
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

LOG = os.path.join(HERE, "k1c_out_utf8.txt")


def log(msg):
    print(msg, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(msg + "\n")


def worker(job):
    """1 seed を訓練・評価して要約を返す（この関数の中だけで torch を触る）。"""
    seed, width, seqs, epochs, n_eval = job
    import numpy as np
    import torch
    from p13c_retrain import (E2DIR, make_batch, run_cond, train_dense, train_moe, OL)

    torch.set_num_threads(1)
    t0 = time.time()
    ev = np.random.default_rng(777)
    src, out, em, ks = make_batch(ev, n_eval)

    tm = train_moe("H+LB", seed, seqs, epochs, 32, 2e-3, 0.05)
    rt = run_cond(tm, src, out, em, None, 2)
    dm = train_dense(width, seed, seqs, epochs, 32, 2e-3)
    rs = run_cond(dm, src, out, em, None, 1)

    ce_t = np.array(rt["ce_seq"], dtype=np.float64)
    ce_s = np.array(rs["ce_seq"], dtype=np.float64)
    d = ce_s - ce_t
    outdir = os.path.join(E2DIR, "data", "k1")
    os.makedirs(outdir, exist_ok=True)
    torch.save({k: v.detach() for k, v in tm.params().items()},
               os.path.join(outdir, "ckpt_teacher_s%d.pt" % seed))
    torch.save({k: v.detach() for k, v in dm.params().items()},
               os.path.join(outdir, "ckpt_dense%d_s%d.pt" % (width, seed)))
    return {
        "seed": seed, "width": width,
        "ce_t": rt["ce_all"], "ce_s": rs["ce_all"],
        "ce_copy_t": rt["ce_copy"], "ce_copy_s": rs["ce_copy"],
        "ce_edit_t": rt["ce_edit"], "ce_edit_s": rs["ce_edit"],
        "w_teacher": rt["width"],
        "delta": float(d.mean()),
        "se_seq": float(d.std(ddof=1) / np.sqrt(len(d))),
        "t_seq": float(d.mean() / (d.std(ddof=1) / np.sqrt(len(d)))),
        "n_neg_seq": int((d < 0).sum()),
        "n_eval": len(d),
        "sec": round(time.time() - t0, 1),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=[3, 4, 5, 6, 7, 8, 9])
    ap.add_argument("--width", type=int, default=161)
    ap.add_argument("--workers", type=int, default=3)
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--n_eval", type=int, default=2048)
    args = ap.parse_args()

    if os.path.exists(LOG):
        os.remove(LOG)
    log("K1c: seed 拡張（各ワーカー 1 スレッド、教師 H+LB top-2 / 生徒 dense W=%d）"
        % args.width)
    log("seeds=%s workers=%d seqs=%d epochs=%d" % (args.seeds, args.workers,
                                                   args.seqs, args.epochs))
    t0 = time.time()
    jobs = [(s, args.width, args.seqs, args.epochs, args.n_eval) for s in args.seeds]
    rows = []
    with Pool(processes=args.workers) as pool:
        for r in pool.imap_unordered(worker, jobs):
            rows.append(r)
            log("  s%-2d  CE_t %.4f / CE_s %.4f  Δ %+.4f  (t_seq %+.1f, %.0fs)"
                % (r["seed"], r["ce_t"], r["ce_s"], r["delta"], r["t_seq"], r["sec"]))
    rows.sort(key=lambda r: r["seed"])

    import numpy as np
    d = np.array([r["delta"] for r in rows])
    n = len(d)
    se = float(d.std(ddof=1) / np.sqrt(n))
    coef = {2: 5.36, 5: 3.49}.get(n - 1, 2.95 if n < 12 else 2.85)
    log("")
    log("== 追加分の集計（n=%d） ==" % n)
    log("  ΔCE = %+.4f  se %.4f  t %+.2f  %d/%d で負  MDE %.4f"
        % (d.mean(), se, d.mean() / se, int((d < 0).sum()), n, coef * se))
    log("  壁時計 %.0f 分" % ((time.time() - t0) / 60))

    with open(os.path.join(HERE, "k1c_results.json"), "w", encoding="utf-8") as f:
        json.dump({"rows": rows, "agg": {"delta_mean": float(d.mean()), "se": se,
                                         "t": float(d.mean() / se), "n": n,
                                         "mde": coef * se,
                                         "n_neg": int((d < 0).sum())},
                   "args": vars(args)}, f, ensure_ascii=False, indent=2)
    log("[write] k1c_results.json")
    os._exit(0)


if __name__ == "__main__":
    main()
