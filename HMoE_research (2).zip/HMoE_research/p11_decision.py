# -*- coding: utf-8 -*-
"""P11: 決定単位でも順序は保たれるか（P10 の橋渡し）

問い:
  P10 はトークン単位で「削っても AUROC は落ちない」を示した。しかし決定単位では
  確信度の正規化の母集団が違う（語彙全体 vs 選択肢集合）。順序が保たれるとは限らない。

決定単位の作り方:
  各トークン位置に **4 択**を作る。選択肢 = {正解} ∪ {base の 2〜4 位の予測}。
  正解は必ず選択肢に入るので、決定の正解率 = トークン単位の top-1 正解率と一致する。
  確信度 = 4 択のロジットの softmax（＝選択肢集合上での正規化）。
  **選択肢集合は base で固定**する（条件ごとに変わると比較にならない）。

測るもの:
  (1) 4 択 AUROC（順序が保たれるか）
  (2) τ=0.8 の運用点（水準の移動が運用を壊すか）
  (3) P6c の「新規越境」— 条件で新たに閾値を越えた決定の誤り率

出力: p11_decision.npz / p11_decision.json
"""

import argparse
import json
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
FROZEN = os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz")

FRONT = set(range(0, 8))
CONDS = [
    ("base", "all", 8, False),
    ("f1", "front", 7, False),
    ("u1", "all", 7, False),
    ("f1_rs", "front", 7, True),
]
NOPT = 4


def log(m):
    print(m, flush=True)


def load_frozen(n_win, ln):
    z = np.load(FROZEN, allow_pickle=True)
    seqs = []
    for lang in ("en", "ja"):
        ids = torch.from_numpy(z["%s_ids" % lang].astype(np.int64))
        for w in range(n_win):
            seqs.append((lang, ids[w * ln:(w + 1) * ln]))
    return seqs


def make_rescaled(orig, full_k):
    def _patched(hidden_states):
        logits, scores, idx = orig(hidden_states)
        if scores.shape[-1] < full_k:
            probs = torch.softmax(logits.float(), dim=-1)
            m_full = torch.topk(probs, full_k, dim=-1).values.sum(-1, keepdim=True)
            m_now = scores.float().sum(-1, keepdim=True).clamp_min(1e-9)
            scores = (scores.float() * (m_full / m_now)).to(scores.dtype)
        return logits, scores, idx
    return _patched


def auroc(score, label):
    score = np.asarray(score, np.float64)
    label = np.asarray(label, bool)
    npos = int(label.sum())
    nneg = label.size - npos
    if npos == 0 or nneg == 0:
        return float("nan")
    order = np.argsort(score, kind="mergesort")
    ranks = np.empty(score.size, np.float64)
    ranks[order] = np.arange(1, score.size + 1)
    s = score[order]
    i = 0
    while i < s.size:
        j = i
        while j + 1 < s.size and s[j + 1] == s[i]:
            j += 1
        if j > i:
            ranks[order[i:j + 1]] = (i + j + 2) / 2.0
        i = j + 1
    return float((ranks[label].sum() - npos * (npos + 1) / 2) / (npos * nneg))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--tag", type=str, default="p11")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer

    n_win = 1 if args.smoke else args.windows
    log("[1/5] load")
    t0 = time.time()
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      %.0f s" % (time.time() - t0))

    FULL_K = int(model.config.num_experts_per_tok)
    gates = [l.mlp.gate for l in model.model.layers]
    ORIG = [g.forward for g in gates]
    seqs = load_frozen(n_win, args.len)
    lang = np.array([lg for lg, _ in seqs])
    log("      %d windows, %d tokens" % (len(seqs), len(seqs) * args.len))

    def set_cond(cut, k, rs):
        for i, g in enumerate(gates):
            g.forward = ORIG[i]
            g.top_k = k if (cut == "all" or i in FRONT) else FULL_K
        if rs:
            for g in gates:
                g.forward = make_rescaled(g.forward, FULL_K)

    def run_pass(opt_ids=None):
        """opt_ids=None なら選択肢集合を作る。あればそれを使う。"""
        nll_c, p_c, cor_c, c4_c, ok4_c, opt_c = [], [], [], [], [], []
        with torch.no_grad():
            for wi, (lg, ids) in enumerate(seqs):
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                lgts = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(lgts, tgt, reduction="none")
                probs = torch.softmax(lgts, dim=-1)
                ptop, amax = probs.max(dim=-1)
                nll_c.append(nll.cpu().numpy())
                p_c.append(ptop.cpu().numpy())
                cor_c.append((amax == tgt).cpu().numpy())

                if opt_ids is None:
                    top = torch.topk(probs, NOPT, dim=-1).indices
                    has = (top == tgt.unsqueeze(-1)).any(-1)
                    o = torch.where(has.unsqueeze(-1), top,
                                    torch.cat([top[:, :NOPT - 1], tgt.unsqueeze(-1)], -1))
                    opt_c.append(o.cpu().numpy())
                else:
                    o = opt_ids[wi].to(lgts.device)
                lo = lgts.gather(1, o)
                c4 = torch.softmax(lo, dim=-1)
                v, j = c4.max(dim=-1)
                gold_j = (o == tgt.unsqueeze(-1)).float().argmax(-1)
                c4_c.append(v.cpu().numpy())
                ok4_c.append((j == gold_j).cpu().numpy())
                del out, lgts, probs
        r = {"nll": np.concatenate(nll_c), "ptop": np.concatenate(p_c),
             "correct": np.concatenate(cor_c), "conf4": np.concatenate(c4_c),
             "correct4": np.concatenate(ok4_c)}
        if opt_ids is None:
            r["opt_ids"] = np.concatenate(opt_c)
        return r

    # --- base: 選択肢集合と 4 択確信度を同時に作る ---
    log("[2/5] base（選択肢集合を作る）")
    set_cond("all", 8, False)
    base = run_pass()
    opt_ids = [torch.from_numpy(base["opt_ids"][i:i + (args.len - 1)]).long()
               for i in range(0, base["opt_ids"].shape[0], args.len - 1)]
    log("      CE %.5f  top1 %.4f  4択conf %.4f  acc4 %.4f" %
        (base["nll"].mean(), base["correct"].mean(), base["conf4"].mean(),
         base["correct4"].mean()))

    res = {"base": base}
    for name, cut, k, rs in CONDS[1:]:
        log("[3/5] %s" % name)
        set_cond(cut, k, rs)
        r = run_pass(opt_ids=opt_ids)
        r["opt_ids"] = base["opt_ids"]
        res[name] = r
        log("      CE %.5f  top1 %.4f  4択conf %.4f" %
            (r["nll"].mean(), r["correct"].mean(), r["conf4"].mean()))
    for i, g in enumerate(gates):
        g.forward = ORIG[i]
        g.top_k = FULL_K

    # ---- 集計 ----
    log("")
    log("[4/5] 決定単位（4 択）")
    log("%-7s %8s %9s %9s %9s %9s" %
        ("cond", "acc", "conf4", "AUROC4", "AUROC_tok", "gap4"))
    summary = {}
    for name, _, _, _ in CONDS:
        r = res[name]
        au4 = auroc(r["conf4"], r["correct4"])
        aut = auroc(r["ptop"], r["correct"])
        gap4 = float(r["conf4"].mean() - r["correct4"].mean())
        log("%-7s %8.4f %9.4f %9.4f %9.4f %+9.4f"
            % (name, r["correct4"].mean(), r["conf4"].mean(), au4, aut, gap4))
        summary[name] = {"acc4": float(r["correct4"].mean()),
                         "conf4": float(r["conf4"].mean()),
                         "auroc4": au4, "auroc_tok": aut, "gap4": gap4,
                         "ce": float(r["nll"].mean())}

    log("")
    log("[5/5] 窓クラスタ対応差（48 窓）")
    n = res["base"]["nll"].size
    per = n // len(seqs)
    for name, _, _, _ in CONDS[1:]:
        d4, dt = [], []
        for w in range(len(seqs)):
            sl = slice(w * per, (w + 1) * per)
            A, B = res[name], res["base"]
            d4.append(auroc(A["conf4"][sl], A["correct4"][sl]) -
                      auroc(B["conf4"][sl], B["correct4"][sl]))
            dt.append(auroc(A["ptop"][sl], A["correct"][sl]) -
                      auroc(B["ptop"][sl], B["correct"][sl]))
        d4, dt = np.array(d4), np.array(dt)
        s4 = d4.std(ddof=1) / np.sqrt(len(seqs))
        st = dt.std(ddof=1) / np.sqrt(len(seqs))
        log("    %-6s − base: ΔAUROC4 %+.4f (se %.4f, t %+.2f, MDE %.4f) | ΔAUROC_tok %+.4f (t %+.2f)"
            % (name, d4.mean(), s4, d4.mean() / s4, 2.8 * s4, dt.mean(), dt.mean() / st))
        summary[name]["d_auroc4"] = {"mean": float(d4.mean()), "se": float(s4),
                                     "t": float(d4.mean() / s4), "mde80": float(2.8 * s4)}
        summary[name]["d_auroc_tok"] = {"mean": float(dt.mean()), "se": float(st),
                                        "t": float(dt.mean() / st)}

    # ---- 閾値運用と新規越境（P6c の再現）----
    log("")
    log("[6] τ=0.8 の運用と新規越境（4 択の確信度）")
    log("%-7s %8s %10s %12s %12s" % ("cond", "自動化率", "自動化内誤り", "新規越境率", "新規越境の誤り"))
    for name, _, _, _ in CONDS:
        r = res[name]
        hi = r["conf4"] >= 0.8
        hb = res["base"]["conf4"] >= 0.8
        new = hi & ~hb
        err_auto = float((~r["correct4"][hi]).mean()) if hi.sum() else float("nan")
        err_new = float((~r["correct4"][new]).mean()) if new.sum() else float("nan")
        log("%-7s %8.4f %10.4f %12.4f %12.4f"
            % (name, hi.mean(), err_auto, new.mean(), err_new))
        summary[name].update({"auto_rate": float(hi.mean()), "err_in_auto": err_auto,
                              "new_cross_rate": float(new.mean()), "err_new_cross": err_new,
                              "n_new": int(new.sum())})

    np.savez_compressed(os.path.join(HERE, "%s_decision.npz" % args.tag),
                        **{"%s_%s" % (k, f): res[k][f]
                           for k in res for f in ("nll", "ptop", "correct", "conf4", "correct4")},
                        opt_ids=res["base"]["opt_ids"], lang=lang)
    with open(os.path.join(HERE, "%s_decision.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2, default=float)
    log("")
    log("saved: %s_decision.npz / %s_decision.json" % (args.tag, args.tag))


if __name__ == "__main__":
    main()
