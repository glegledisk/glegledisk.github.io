#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX9: HF の大容量ファイルが Range 分割取得できるかを標準ライブラリで診断する。"""
import urllib.request

REPO = "allenai/OLMoE-1B-7B-0924-Instruct"
NAME = "model-00001-of-00003.safetensors"
URL = "https://huggingface.co/%s/resolve/main/%s" % (REPO, NAME)


def main():
    try:
        req = urllib.request.Request(URL, method="HEAD")
        with urllib.request.urlopen(req, timeout=30) as r:
            print("HEAD", r.status, "len", r.headers.get("Content-Length"),
                  "ranges", r.headers.get("Accept-Ranges"), flush=True)
            print("final host", str(r.geturl()).split("/")[2], flush=True)
    except Exception as e:
        print("HEAD ERR", type(e).__name__, str(e)[:200], flush=True)
        return
    try:
        req = urllib.request.Request(URL, headers={"Range": "bytes=0-1048575"})
        with urllib.request.urlopen(req, timeout=60) as r:
            buf = r.read()
            print("RANGE", r.status, "content-range", r.headers.get("Content-Range"),
                  "bytes", len(buf), flush=True)
    except Exception as e:
        print("RANGE ERR", type(e).__name__, str(e)[:200], flush=True)


if __name__ == "__main__":
    main()
