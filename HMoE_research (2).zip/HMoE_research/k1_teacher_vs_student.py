#!/usr/bin/env python3
"""K1: 教師（HMoE top-2）と「蒸留なしの生徒」（dense）を同一プロセス・1 スレッドで
訓練し、同一評価セットで CE を比べる。

なぜ必要か
  P13 は「等 active 幅では dense が最良」を 6 スレッドで測った。Q9 は
  「同一コード・同一 seed でもスレッド 6 では別プロセスで再現しない（epoch 2 で
  1.5623 vs 1.5559、6 epoch で iv が 0.14 ずれる）」を示した。蒸留の効果量は
  0.05〜0.2 級なので、条件間の差がスレッド・プロセスの差に埋もれる。
  そこで本スクリプトは **1 プロセス・1 スレッド**で教師と生徒を交互に訓練し、
  同一評価系列（seed 777, n=2048）の per-sequence CE で対応差を取る。

条件
  teacher : H+LB（幅 32/32/96/96/160/160/224/224）, top-2, p_pen auxw=0.05
  student : dense W（E=1, top-1）。W=161 が教師の平均 active 幅 160.9 と等 MACs。
            W=180 は P13 の比較点（+4.5% MACs）。

測るもの
  ce_all / ce_copy / ce_edit / acc_copy / acc_edit / mean width / 総 MACs
  per-sequence CE（2048 本）→ 同一系列での対応差 ΔCE = CE(student) − CE(teacher)
  seed 別の Δ と、seed を単位にした Δ の平均・se・t（n=3）

出力
  k1_results.json / k1_ce_seq.npz / k1_out_utf8.txt
  simulation_hmoe_mmlu/data/k1/ckpt_*.pt
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from p13c_retrain import (  # noqa: E402
    E2DIR, make_batch, run_cond, train_dense, train_moe, WIDTHS, OL,
)

OUTDIR = os.path.join(E2DIR, "data", "k1")
LOG = os.path.join(HERE, "k1_out_utf8.txt")

D_MODEL, N_LAYERS = 128, 4


def macs_per_token(width, n_expert):
    """FFN + qkv/o + router の 1 トークンあたり MACs。

    attention のスコア行列（2·T·d/層）と head（d·V）は全条件で同一なので含めない。
    含めないことによる比の誤差は 0（両方に同じだけ足される）。
    """
    return N_LAYERS * (4 * D_MODEL * D_MODEL + 2 * D_MODEL * width + D_MODEL * n_expert)


def log(msg):
    print(msg, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(msg + "\n")


def paired(a, b):
    d = np.asarray(a, dtype=np.float64) - np.asarray(b, dtype=np.float64)
    n = len(d)
    m = float(d.mean())
    se = float(d.std(ddof=1) / np.sqrt(n))
    return {"delta": m, "se": se, "t": (m / se if se > 0 else float("nan")), "n": n}


def mde(se, n):
    """80% 検出力・両側 5% の MDE ≈ (t_{.975,n-1} + t_{.8,n-1}) · se。"""
    from math import sqrt
    # df が小さいときの係数（n=3:5.36 / n=6:3.49 / n>=20:2.9 で十分近似）
    coef = {2: 5.36, 5: 3.49}.get(n - 1, 2.95)
    return coef * se


def dump_partial(res, ce_seq, args, path):
    """途中経過の逐次保存（長時間ランが落ちても数値を失わないため）。"""
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"runs": res,
                   "ce_seq_keys": list(ce_seq.keys()),
                   "args": vars(args)},
                  f, ensure_ascii=False, indent=2, default=float)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--widths", nargs="+", type=int, default=[161, 180])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--auxw", type=float, default=0.05)
    ap.add_argument("--n_eval", type=int, default=2048)
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--tag", type=str, default="")
    args = ap.parse_args()

    torch.set_num_threads(args.threads)
    os.makedirs(OUTDIR, exist_ok=True)
    suf = ("_" + args.tag) if args.tag else ""
    global LOG
    LOG = os.path.join(HERE, "k1_out_utf8%s.txt" % suf)
    if os.path.exists(LOG):
        os.remove(LOG)

    log("K1: teacher vs no-distillation student / 1 process, 1 thread")
    log("torch=%s threads=%d  seqs=%d epochs=%d bs=%d lr=%g auxw=%g n_eval=%d"
        % (torch.__version__, torch.get_num_threads(), args.seqs, args.epochs,
           args.bs, args.lr, args.auxw, args.n_eval))

    ev = np.random.default_rng(777)
    src, out, em, ks = make_batch(ev, args.n_eval)
    log("eval: n=%d OUT=%d k_mean=%.2f edit率=%.3f" % (src.shape[0], OL, ks.mean(), em.mean()))

    res = {}
    ce_seq = {}
    t_all = time.time()

    for seed in args.seeds:
        log("\n=== seed %d ===" % seed)
        t0 = time.time()
        tm = train_moe("H+LB", seed, args.seqs, args.epochs, args.bs, args.lr, args.auxw)
        rt = run_cond(tm, src, out, em, None, 2)
        rt.update({"role": "teacher", "seed": seed, "cond": "H+LB:top2",
                   "macs": macs_per_token(rt["width"], len(WIDTHS["H+LB"])),
                   "sec": round(time.time() - t0, 1)})
        res["teacher:s%d" % seed] = rt
        ce_seq["teacher:s%d" % seed] = np.array(rt["ce_seq"])
        torch.save({k: v.detach() for k, v in tm.params().items()},
                   os.path.join(OUTDIR, "ckpt_teacher_s%d%s.pt" % (seed, suf)))
        log("  teacher s%d  CE %.4f  width %6.1f  copy %.4f  edit %.4f  (%.0fs)"
            % (seed, rt["ce_all"], rt["width"], rt["acc_copy"], rt["acc_edit"],
               time.time() - t0))

        for w in args.widths:
            t1 = time.time()
            dm = train_dense(w, seed, args.seqs, args.epochs, args.bs, args.lr)
            rs = run_cond(dm, src, out, em, None, 1)
            rs.update({"role": "student", "seed": seed, "cond": "dense%d" % w,
                       "width_design": w,
                       "macs": macs_per_token(w, 1),
                       "nparam": int(sum(v.numel() for v in dm.params().values())),
                       "sec": round(time.time() - t1, 1)})
            res["dense%d:s%d" % (w, seed)] = rs
            ce_seq["dense%d:s%d" % (w, seed)] = np.array(rs["ce_seq"])
            torch.save({k: v.detach() for k, v in dm.params().items()},
                       os.path.join(OUTDIR, "ckpt_dense%d_s%d%s.pt" % (w, seed, suf)))
            log("  dense%d s%d  CE %.4f  copy %.4f  edit %.4f  params %d  (%.0fs)"
                % (w, seed, rs["ce_all"], rs["acc_copy"], rs["acc_edit"],
                   rs["nparam"], time.time() - t1))

        # 同一 seed 内の対応差（同一評価系列 2048 本）
        for w in args.widths:
            p = paired(ce_seq["dense%d:s%d" % (w, seed)], ce_seq["teacher:s%d" % seed])
            res["diff:dense%d:s%d" % (w, seed)] = p
            log("  ΔCE(dense%d − teacher) s%d = %+.4f  se %.4f  t %+.2f  n %d"
                % (w, seed, p["delta"], p["se"], p["t"], p["n"]))
        dump_partial(res, ce_seq, args, os.path.join(HERE, "k1_partial%s.json" % suf))

    # seed を単位にした集計
    agg = {}
    for w in args.widths:
        ds = [res["diff:dense%d:s%d" % (w, s)]["delta"] for s in args.seeds]
        ds = np.array(ds, dtype=np.float64)
        n = len(ds)
        se = float(ds.std(ddof=1) / np.sqrt(n))
        agg["dense%d" % w] = {
            "delta_mean": float(ds.mean()), "se": se,
            "t": float(ds.mean() / se) if se > 0 else float("nan"),
            "n_seed": n, "per_seed": ds.tolist(),
            "mde": mde(se, n),
            "n_neg": int((ds < 0).sum()),
        }
        log("\n[agg] dense%d: ΔCE = %+.4f (se %.4f, t %+.2f, n=%d, %d/%d で負, MDE %.4f)"
            % (w, ds.mean(), se, ds.mean() / se if se > 0 else float("nan"),
               n, (ds < 0).sum(), n, agg["dense%d" % w]["mde"]))

    # 参考: 教師と生徒の絶対 CE（seed 平均）
    absmean = {}
    for key, r in res.items():
        if "ce_all" not in r:
            continue
        absmean.setdefault(r["cond"], []).append(r["ce_all"])
    for k, v in absmean.items():
        log("  CE(%s) = %.4f ± %.4f (n=%d)" % (k, np.mean(v), np.std(v, ddof=1), len(v)))

    out_json = {
        "meta": {"threads": torch.get_num_threads(), "seqs": args.seqs,
                 "epochs": args.epochs, "bs": args.bs, "lr": args.lr,
                 "auxw": args.auxw, "n_eval": args.n_eval,
                 "torch": torch.__version__,
                 "wall_sec": round(time.time() - t_all, 1)},
        "runs": res, "agg": agg,
        "ce_abs_mean": {k: {"mean": float(np.mean(v)), "sd": float(np.std(v, ddof=1)),
                            "n": len(v)} for k, v in absmean.items()},
    }
    with open(os.path.join(HERE, "k1_results%s.json" % suf), "w", encoding="utf-8") as f:
        json.dump(out_json, f, ensure_ascii=False, indent=2, default=float)
    np.savez_compressed(os.path.join(HERE, "k1_ce_seq%s.npz" % suf),
                        **{k: v.astype(np.float32) for k, v in ce_seq.items()})
    log("\nsaved: k1_results%s.json / k1_ce_seq%s.npz  (wall %.0f min)"
        % (suf, suf, (time.time() - t_all) / 60))
    os._exit(0)


if __name__ == "__main__":
    main()
