# -*- coding: utf-8 -*-
"""_probe_cpu.py — CPU 実行の速度と base CE の再現性（使い捨て）"""
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "olmoe-1b-7b")

from transformers import AutoModelForCausalLM

t0 = time.time()
m = AutoModelForCausalLM.from_pretrained(MODEL, torch_dtype=torch.bfloat16,
                                         device_map="cpu").eval()
print("load %.0f s" % (time.time() - t0))
print("any meta:", any(p.is_meta for p in m.parameters()))

z = np.load(os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"))
ids = torch.from_numpy(z["en_ids"][:256].astype("int64")).unsqueeze(0)

for rep in range(2):
    t1 = time.time()
    with torch.no_grad():
        out = m(input_ids=ids, use_cache=False)
    lg = out.logits[0, :-1].float()
    tgt = ids[0, 1:]
    nll = F.cross_entropy(lg, tgt, reduction="none")
    print("rep%d  %.1f s  CE %.5f  finite=%s"
          % (rep, time.time() - t1, nll.mean(), bool(torch.isfinite(lg).all())))
