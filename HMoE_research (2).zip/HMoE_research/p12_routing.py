# -*- coding: utf-8 -*-
"""P12: 振り分けの予測可能性（考察 20261029 §7 予測 3）

問い:
  生成前に「この問題は高速経路で正解できるか」を当てられるか。
  当てられなければ、高速/低速の振り分けは成立しない。

比較点:
  P4b は per-token のコスト予測で AUC 0.55 だった（層 0 のルータ logit）。
  予測 3 は「リクエスト単位の易しさはもっと易しい」として AUC > 0.75 を予想した。

特徴量（すべて生成前に計算できる）:
  surface  桁数 ndigits / 繰り上がり回数 ncarry   ← 課題固有。上限の目安
  model    最後のプロンプト位置のエントロピー H_last / p_top1 / プロンプト全体の平均エントロピー
            ← モデル内部の事前信号。P4b と同種

出力: p12_routing.jsonl / p12_routing.json
"""

import argparse
import json
import os
import random
import re
import time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "qwen3-0.6b")
SYS = "You are a careful arithmetic assistant. Solve the problem and give the final answer."


def log(m):
    print(m, flush=True)


def extract(txt):
    nums = re.findall(r"-?\d+", txt.replace(",", ""))
    return nums[-1] if nums else None


def n_carries(a, b):
    c = 0
    while a or b:
        if (a % 10) + (b % 10) >= 10:
            c += 1
        a //= 10
        b //= 10
    return c


def make_problems(per_level, seed):
    """乗算にする。加算は thinking off で天井（0.95）になり、予測の分散が取れない。"""
    rnd = random.Random(seed)
    out = []
    for da, db in ((2, 2), (2, 3), (3, 3)):
        lo_a, hi_a = 10 ** (da - 1), 10 ** da - 1
        lo_b, hi_b = 10 ** (db - 1), 10 ** db - 1
        for _ in range(per_level):
            a, b = rnd.randint(lo_a, hi_a), rnd.randint(lo_b, hi_b)
            out.append({"a": a, "b": b, "gold": str(a * b), "level": "%dx%d" % (da, db),
                        "ndigits": da + db, "nprod": db,
                        "q": "Compute %d * %d." % (a, b)})
    return out


def auroc(score, label):
    score = np.asarray(score, np.float64)
    label = np.asarray(label, bool)
    npos, nneg = int(label.sum()), label.size - int(label.sum())
    if npos == 0 or nneg == 0:
        return float("nan")
    order = np.argsort(score, kind="mergesort")
    ranks = np.empty(score.size, np.float64)
    ranks[order] = np.arange(1, score.size + 1)
    s = score[order]
    i = 0
    while i < s.size:
        j = i
        while j + 1 < s.size and s[j + 1] == s[i]:
            j += 1
        if j > i:
            ranks[order[i:j + 1]] = (i + j + 2) / 2.0
        i = j + 1
    return float((ranks[label].sum() - npos * (npos + 1) / 2) / (npos * nneg))


def cv_auc(x, y, folds=5, seed=0):
    """単一特徴の AUC を 5 分割で。符号は「大きいほど易しい」に揃える。"""
    rng = np.random.RandomState(seed)
    idx = rng.permutation(len(y))
    aucs = []
    for f in range(folds):
        te = idx[f::folds]
        if len(np.unique(y[te])) < 2:
            continue
        aucs.append(auroc(x[te], y[te]))
    return float(np.mean(aucs)) if aucs else float("nan")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--per_level", type=int, default=60)
    ap.add_argument("--bs", type=int, default=8)
    ap.add_argument("--seed", type=int, default=41)
    ap.add_argument("--tag", type=str, default="p12")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer

    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, torch_dtype=torch.bfloat16, device_map="cuda",
        attn_implementation="sdpa").eval()

    probs = make_problems(args.per_level, args.seed)
    log("problems: %d (2〜5 桁 × %d)" % (len(probs), args.per_level))

    def prompt(p):
        msgs = [{"role": "system", "content": SYS}, {"role": "user", "content": p["q"]}]
        return tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True,
                                       enable_thinking=False)

    prompts = [prompt(p) for p in probs]

    # ---- 1. 生成前の信号（1 forward）----
    log("[1/3] 生成前のエントロピー")
    t0 = time.time()
    for i in range(0, len(prompts), 16):
        chunk = prompts[i:i + 16]
        enc = tok(chunk, return_tensors="pt", padding=True,
                  add_special_tokens=False).to(model.device)
        with torch.no_grad():
            out = model(**enc)
        lg = out.logits.float()
        lp = torch.log_softmax(lg, dim=-1)
        H = -(lp.exp() * lp).sum(-1)                        # (B, T)
        mask = enc["attention_mask"].bool()
        last_idx = mask.sum(1) - 1
        for j in range(len(chunk)):
            p_ = probs[i + j]
            n = int(mask[j].sum())
            p_["H_last"] = float(H[j, last_idx[j]])
            p_["H_mean"] = float(H[j, :n].mean())
            p_["p_last"] = float(lp[j, last_idx[j]].exp().max())
        del out, lg, lp
    log("      %.0f s" % (time.time() - t0))

    # ---- 2. 生成（fast path = thinking off）----
    log("[2/3] 生成（thinking off, greedy）")
    t0 = time.time()
    for i in range(0, len(probs), args.bs):
        chunk = probs[i:i + args.bs]
        enc = tok([prompts[i + j] for j in range(len(chunk))], return_tensors="pt",
                  padding=True, add_special_tokens=False).to(model.device)
        with torch.no_grad():
            o = model.generate(**enc, max_new_tokens=96, do_sample=False,
                               pad_token_id=tok.pad_token_id)
        new = o[:, enc["input_ids"].shape[1]:]
        for j, p_ in enumerate(chunk):
            txt = tok.decode(new[j], skip_special_tokens=True)
            p_["pred"] = extract(txt)
            p_["correct"] = int(p_["pred"] == p_["gold"])
            p_["ntok"] = int((new[j] != tok.pad_token_id).sum())
    log("      %.0f s" % (time.time() - t0))

    with open(os.path.join(HERE, "%s_routing.jsonl" % args.tag), "w", encoding="utf-8") as fp:
        for p in probs:
            fp.write(json.dumps(p, ensure_ascii=False) + "\n")

    # ---- 3. 予測可能性 ----
    y = np.array([p["correct"] for p in probs], bool)
    log("")
    log("[3/3] 正解率 %.3f（n=%d）" % (y.mean(), y.size))
    log("")
    feats = {
        "ndigits（桁数の合計・小さいほど易）": -np.array([p["ndigits"] for p in probs], float),
        "nprod（部分積の数・少ないほど易）": -np.array([p["nprod"] for p in probs], float),
        "H_last（最後の位置のエントロピー・低いほど易）": -np.array([p["H_last"] for p in probs]),
        "H_mean（プロンプト平均・低いほど易）": -np.array([p["H_mean"] for p in probs]),
        "p_last（最後の p_top1・高いほど易）": np.array([p["p_last"] for p in probs]),
    }
    log("%-42s %8s" % ("特徴量（単独）", "CV AUC"))
    res = {}
    for k, v in feats.items():
        a = cv_auc(v, y)
        log("%-42s %8.3f" % (k, a))
        res[k] = a

    # 組み合わせ（surface 2 + model 3、標準化して平均）
    def z(v):
        return (v - v.mean()) / (v.std() + 1e-9)
    comb = (z(feats["ndigits（桁数の合計・小さいほど易）"]) + z(feats["nprod（部分積の数・少ないほど易）"])
            + z(feats["H_last（最後の位置のエントロピー・低いほど易）"])
            + z(feats["p_last（最後の p_top1・高いほど易）"])) / 4
    a = cv_auc(comb, y)
    log("%-42s %8.3f" % ("組み合わせ（4 特徴の z 平均）", a))
    res["comb"] = a

    # ---- 振り分け曲線 ----
    log("")
    log("振り分け曲線（スコア上位 k% を高速経路に回したときの正解率）")
    log("%6s %12s %12s %10s" % ("上位%", "スコア順", "ランダム", "n"))
    order = np.argsort(-comb)
    curve = {}
    for frac in (0.25, 0.5, 0.75, 1.0):
        n = int(round(frac * y.size))
        sel = order[:n]
        acc = float(y[sel].mean())
        base = float(y.mean())
        log("%6d %12.3f %12.3f %10d" % (int(frac * 100), acc, base, n))
        curve["%d" % int(frac * 100)] = {"acc": acc, "n": n}
    res["routing_curve"] = curve

    with open(os.path.join(HERE, "%s_routing.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump({"n": int(y.size), "acc": float(y.mean()), "cv_auc": res,
                   "routing_curve": curve}, fp, ensure_ascii=False, indent=2, default=float)
    log("")
    log("saved: %s_routing.jsonl / %s_routing.json" % (args.tag, args.tag))


if __name__ == "__main__":
    main()
