# -*- coding: utf-8 -*-
import json, numpy as np

with open(r"C:\Users\gochu\WorkBuddy AI\不均一MoE\ax7_plateau.json", encoding="utf-8") as f:
    d = json.load(f)

g102a = d["gains"]["shift102"]["mean"]
g102b = d["gains"]["shift102b"]["mean"]
g181a = d["gains"]["shift181"]["mean"]
g181b = d["gains"]["shift181b"]["mean"]
print(f"N=102 shift: a={g102a:+.8f} b={g102b:+.8f}  diff={abs(g102a-g102b):.8f}")
print(f"N=181 shift: a={g181a:+.8f} b={g181b:+.8f}  diff={abs(g181a-g181b):.8f}")

sigma102 = abs(g102a - g102b) / np.sqrt(2)
sigma181 = abs(g181a - g181b) / np.sqrt(2)
print(f"\nEstimated per-draw sigma: N102={sigma102:.6f}  N181={sigma181:.6f}")
for S in (10, 16, 20, 24, 30):
    se102 = sigma102 / np.sqrt(S)
    se181 = sigma181 / np.sqrt(S)
    print(f"  S={S:2d}: se102={se102:.6f}  se181={se181:.6f}  new_forwards={2*S}  time_min~{2*S*2.5:.0f}")

# For the per-token paired t approach: what is the per-token se for each shift arm?
# This tells us how much of the noise is per-token vs across-draw
se_shift102 = d["gains"]["shift102"]["se"]
se_shift102b = d["gains"]["shift102b"]["se"]
print(f"\nPer-token se: shift102={se_shift102:.8f}  shift102b={se_shift102b:.8f}")
print(f"  These are MUCH larger than the across-draw noise.")
print(f"  The per-token noise ~0.001 is from the MEAN of 12,240 tokens varying across draws.")

# The approach: run S shift draws. For each, compute G_shift = mean(nll_u7 - nll_shift).
# Then compare mean(G_shift_1..S) vs G_uni. The key is that per-token d_i changes across draws
# because the mask allocation changes.
# Confirmatory: paired t on per-token vectors: d_i = nll_u7 - nll_shiftMEAN(i)
# where nll_shiftMEAN(i) = (1/S) * sum_s nll_shift_s(i)

# The per-token variance should shrink by ~1/S for the shift-noise part,
# but the baseline (nll_u7 - nll_uni) part stays the same.
# So the t-test should gain power.

# With S=20, total new forwards = 40 + 2 (base_rep, u7_rep) = 42 forward
# At ~2.5 min each => ~105 min

# Check AX8 timing
with open(r"C:\Users\gochu\WorkBuddy AI\不均一MoE\ax8_feasible_probe.json", encoding="utf-8") as f:
    d8 = json.load(f)
print(f"\nAX8: n_new_forwards={d8['meta']['n_new_forwards']}")
