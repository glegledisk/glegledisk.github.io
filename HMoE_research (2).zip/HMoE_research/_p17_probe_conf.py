# -*- coding: utf-8 -*-
"""P17 補助: 型検査プールの中で p_ans はなぜ負けるのか（使い捨て）"""
import json
import os
import re

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


def digits_ok(pred, q):
    if pred is None or not re.fullmatch(r"-?\d+", pred):
        return False
    m = re.match(r"Compute (\d+) ([-+*]) (\d+)\.", q)
    if not m:
        return False
    la, lb, op = len(m.group(1)), len(m.group(3)), m.group(2)
    if op == "+":
        allowed = {la, la + 1} if la == lb else {max(la, lb), max(la, lb) + 1}
    elif op == "-":
        allowed = set(range(1, max(la, lb) + 1))
    else:
        allowed = {la + lb - 1, la + lb}
    return len(pred.lstrip("-")) in allowed


def auroc(s, y):
    s = np.asarray(s, float)
    y = np.asarray(y, bool)
    ok = np.isfinite(s)
    s, y = s[ok], y[ok]
    pos, neg = s[y], s[~y]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    d = (pos[:, None] > neg[None, :]).sum() + 0.5 * (pos[:, None] == neg[None, :]).sum()
    return float(d / (len(pos) * len(neg)))


rows = [json.loads(l) for l in open(os.path.join(HERE, "p17_runs.jsonl"),
                                    encoding="utf-8") if l.strip()]

for lv in ["add5", "mul2"]:
    rlv = [r for r in rows if r["level"] == lv]
    S = [(r, s) for r in rlv for s in r["samples"]]
    dig = [(r, s) for r, s in S if digits_ok(s["pred"], r["q"])]
    tr = [(r, s) for r, s in S if s["ntok"] < 96]
    print("=== %s ===" % lv)
    for name, pool in [("all", S), ("trunc", tr), ("dig", dig)]:
        y = np.array([bool(s["correct"]) for r, s in pool])
        p = np.array([s["p_ans"] for r, s in pool], float)
        f = np.array([s["p_full"] for r, s in pool], float)
        n_ans = np.array([s["n_ans"] for r, s in pool], float)
        print("  %-6s n=%-3d acc=%.3f | p_ans correct=%.4f wrong=%.4f AUC=%.3f | "
              "p_full AUC=%.3f | n_ans c=%.2f w=%.2f"
              % (name, len(pool), y.mean(), p[y].mean(), p[~y].mean(), auroc(p, y),
                 auroc(f, y), n_ans[y].mean(), n_ans[~y].mean()))
    # dig プール内で「自信のある誤答」の例
    bad = [(r, s) for r, s in dig if not s["correct"]]
    bad.sort(key=lambda t: -t[1]["p_ans"])
    print("  dig プール内の高 p_ans 誤答 上位 3 件:")
    for r, s in bad[:3]:
        print("    p_ans=%.4f n_ans=%d gold=%s pred=%s | %s"
              % (s["p_ans"], s["n_ans"], r["gold"], s["pred"],
                 s["text"].replace("\n", " ")[-70:]))
    print("")
