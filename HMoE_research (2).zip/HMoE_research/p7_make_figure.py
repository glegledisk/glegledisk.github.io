# -*- coding: utf-8 -*-
"""P7 作図（改訂版）: 曲線 / 予算別判定 / 実 FLOPs あたり

批評（2026-10-28）を受けて:
  - エラーバーを窓クラスタ SE に変更（独立単位は 48 窓）
  - パネル C を追加（実 FLOPs 節約あたりのコスト）
入力: p7_granularity.npz / p7b_granularity.npz
出力: p7_granularity.png
"""

import os

import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

matplotlib.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "MS Gothic", "sans-serif"]
matplotlib.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))
TAGS = ["p7", "p7b"]


def load():
    nll, lang = {}, None
    for tag in TAGS:
        p = os.path.join(HERE, "%s_granularity.npz" % tag)
        if not os.path.exists(p):
            continue
        z = np.load(p, allow_pickle=True)
        if lang is None:
            lang = z["lang"]
        for k in z.files:
            if k.startswith("nll_"):
                nll.setdefault(k[4:], z[k])
    return nll, lang


def win_stats(a, b, nw):
    """窓単位の paired 差（独立単位 = 窓）。"""
    d = (a - b).reshape(nw, -1).mean(1).astype(np.float64)
    return d.mean(), d.std(ddof=1) / np.sqrt(d.size)


def main():
    nll, lang = load()
    nw = lang.size
    base = nll["base"]

    fig, axes = plt.subplots(1, 3, figsize=(16.4, 4.9))

    # ---- A: 曲線 ----
    ax = axes[0]
    ms = [0.0, 0.5, 1.0, 1.5, 2.0]
    for h, col, lab in (("f", "#c0392b", "前半 8 層"), ("b", "#2c6fbb", "後半 8 層")):
        ys, es = [0.0], [0.0]
        for key in ("%s05" % h, "%s1" % h, "%s15" % h, "%s2" % h):
            m, s = win_stats(nll[key], base, nw)
            ys.append(m)
            es.append(s)
        ax.errorbar(ms, ys, yerr=[1.96 * e for e in es], marker="o", capsize=3,
                    color=col, label=lab, lw=1.8, ms=5)
        for i in (1, 2, 3, 4):
            ax.annotate("%.4f" % ys[i], (ms[i], ys[i]), textcoords="offset points",
                        xytext=(5, -13 if h == "f" else 7), fontsize=7.5, color=col)
    ax.set_xlabel("1 層あたりに削ったスロット数 m")
    ax.set_ylabel("ΔCE (nats)")
    ax.set_title("A. 1 スロット内は強く凸\n"
                 "半スロットはフルスロットの 3.8% / 15.3%", fontsize=10)
    ax.grid(alpha=0.3)
    ax.legend(fontsize=9)
    ax.set_xticks(ms)

    # ---- B: 予算別判定（窓クラスタ SE）----
    ax = axes[1]
    tests = [
        ("予算 8\n(1,0)−(.5,.5)\n事前登録", "f1", "u05"),
        ("予算 16\n(1.5,.5)−(1,1)", "h15f", "u1"),
        ("予算 16\n(1.5,.5)−(2,0)", "h15f", "f2"),
        ("予算 16\n(2,0)−(1,1)", "f2", "u1"),
    ]
    xs = np.arange(len(tests))
    vals, errs, cols = [], [], []
    for _, a, b in tests:
        m, se = win_stats(nll[a], nll[b], nw)
        vals.append(m)
        errs.append(1.96 * se)
        cols.append("#1e8449" if m < 0 else "#922b21")
    ax.bar(xs, vals, yerr=errs, capsize=5, color=cols, alpha=0.85, width=0.6)
    ax.axhline(0, color="k", lw=1)
    ax.set_xticks(xs)
    ax.set_xticklabels([t[0] for t in tests], fontsize=8)
    ax.set_ylabel("ΔCE（前重み − 均一） nats")
    ax.set_title("B. 半スロットは両方の隅に勝つ（最適点は内点）\n"
                 "エラーバーは窓クラスタ 95% CI", fontsize=10)
    ax.grid(alpha=0.3, axis="y")
    for x, v in zip(xs, vals):
        ax.annotate("%+.4f" % v, (x, v), textcoords="offset points",
                    xytext=(0, -15 if v > 0 else 11), ha="center", fontsize=8.5)

    # ---- C: 実 FLOPs あたり ----
    ax = axes[2]
    real = {"f1": 8, "u1": 16, "f2": 16, "b1": 8, "h15f": 8, "u15": 16}
    rows = []
    for c, r in real.items():
        if c not in nll:
            continue
        d = float((nll[c] - base).mean())
        rows.append((c, d, r, d / r))
    rows.sort(key=lambda t: t[3])
    names = ["%s（%d slot）" % (c, r) for c, _, r, _ in rows]
    per = [x[3] for x in rows]
    colors = ["#1e8449" if c == "f1" else ("#922b21" if c == "h15f" else "#7f8c8d")
              for c, _, _, _ in rows]
    ax.barh(range(len(rows)), per, color=colors, alpha=0.85)
    ax.set_yticks(range(len(rows)))
    ax.set_yticklabels(names, fontsize=8.5)
    ax.invert_yaxis()
    ax.set_xlabel("ΔCE / 実節約スロット（小さいほど良い）")
    ax.set_title("C. 実 FLOPs では f1（前半だけ）が最良\n"
                 "α=0.5 は計算を飛ばさないので実節約に数えない", fontsize=10)
    ax.grid(alpha=0.3, axis="x")
    for i, v in enumerate(per):
        ax.annotate("%.5f" % v, (v, i), textcoords="offset points",
                    xytext=(4, 0), va="center", fontsize=8)

    fig.suptitle("P7（改訂）: スロットの粒度と層方向の不均一 — OLMoE-1B-7B, n=12,240 tokens / 48 窓",
                 fontsize=11)
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    out = os.path.join(HERE, "p7_granularity.png")
    fig.savefig(out, dpi=150)
    print("saved: " + out)


if __name__ == "__main__":
    main()
