"""H1 の解析: (cost, val) 平面での不均一の優位と、その b 依存（交互作用）。

Δ_b(c) = val_uni(c) − val_het(c)   （同一活性幅 c での損失差。正なら不均一が良い）
交互作用 = Δ_16(c) − Δ_1(c)
"""
import json
import os
from collections import defaultdict

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

UNI = {"uni_k1": 1.0, "uni_k2": 2.0, "uni_k3": 3.0}
HET = ["het_l0", "het_l002", "het_l005", "het_l02", "het_l05"]
SWEEP = {"uni_s05": 0.5, "uni_s075": 0.75, "uni_k2": 1.0, "uni_s15": 1.5}


def load():
    rows = []
    with open(os.path.join(HERE, "h1_results.jsonl"), encoding="utf-8") as fp:
        for line in fp:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def interp(xs, ys, x):
    """xs 昇順で線形補間。範囲外は None。"""
    o = np.argsort(xs)
    xs, ys = np.asarray(xs)[o], np.asarray(ys)[o]
    if x < xs[0] - 1e-9 or x > xs[-1] + 1e-9:
        return None
    return float(np.interp(x, xs, ys))


def main():
    rows = load()
    by = defaultdict(list)
    for r in rows:
        by[(r["b"], r["arm"])].append(r)

    print("=== 生データ（seed 平均 ± SD）===")
    print("%4s %-10s %8s %8s %8s" % ("b", "arm", "val", "sd", "cost"))
    for b in sorted({r["b"] for r in rows}):
        for arm in sorted({r["arm"] for r in rows}):
            rs = by.get((b, arm), [])
            if not rs:
                continue
            v = np.array([r["val"] for r in rs])
            c = np.array([r["cost"] for r in rs])
            print("%4d %-10s %8.4f %8.4f %8.3f" % (b, arm, v.mean(), v.std(ddof=1) if len(v) > 1 else 0, c.mean()))
        print()

    # ---- 幅の凸性（b=16 の掃引）
    print("=== 幅のコスト曲線 CE(width)（b=16, seed 平均）===")
    print("%8s %8s %8s" % ("width", "val", "n"))
    W, Vv = [], []
    for arm, w in SWEEP.items():
        rs = by.get((16, arm), [])
        if not rs:
            continue
        v = float(np.mean([r["val"] for r in rs]))
        W.append(2 * w)          # top-2 なので活性幅は 2w
        Vv.append(v)
        print("%8.2f %8.4f %8d" % (2 * w, v, len(rs)))
    if len(W) >= 3:
        o = np.argsort(W)
        W, Vv = np.array(W)[o], np.array(Vv)[o]
        d1 = np.diff(Vv) / np.diff(W)                    # 限界コスト
        print("\n限界 dCE/dwidth:", np.round(d1, 5))
        if len(d1) >= 2:
            print("比（凸性の指標、大きいほど凸）:", np.round(-d1[1:] / -d1[:-1], 3))

    # ---- 同一活性幅での Δ と交互作用
    print("\n=== 同一活性幅 c での Δ = val_uni(c) − val_het(c) ===")
    seeds = sorted({r["seed"] for r in rows})
    for c in (1.25, 1.5, 1.75):
        print(f"\n-- c = {c} --")
        print("%4s %10s %10s %10s" % ("b", "Δ mean", "Δ sd", "n"))
        deltas = {}
        for b in sorted({r["b"] for r in rows}):
            ux = [UNI[a] for a in UNI if by.get((b, a))]
            ds = []
            for s in seeds:
                uy, ux2 = [], []
                for a, cc in UNI.items():
                    rr = [r for r in by.get((b, a), []) if r["seed"] == s]
                    if rr:
                        ux2.append(cc)
                        uy.append(rr[0]["val"])
                hx, hy = [], []
                for a in HET:
                    rr = [r for r in by.get((b, a), []) if r["seed"] == s]
                    if rr:
                        hx.append(rr[0]["cost"])
                        hy.append(rr[0]["val"])
                if len(ux2) < 2 or len(hx) < 2:
                    continue
                uv = interp(ux2, uy, c)
                hv = interp(hx, hy, c)
                if uv is not None and hv is not None:
                    ds.append(uv - hv)
            if ds:
                deltas[b] = (float(np.mean(ds)), float(np.std(ds, ddof=1)) if len(ds) > 1 else 0.0, len(ds))
                print("%4d %10.4f %10.4f %10d" % (b, deltas[b][0], deltas[b][1], deltas[b][2]))
        if 1 in deltas and 16 in deltas:
            ia = deltas[16][0] - deltas[1][0]
            print(f"  交互作用 Δ16 − Δ1 = {ia:+.4f}")

    # ---- 機構: 難易度別の活性幅（b=16）
    print("\n=== 機構: マスク位置の難易度別 活性幅（b=16, 最終層, seed 平均）===")
    for arm in HET + ["uni_k2"]:
        rs = by.get((16, arm), [])
        if not rs:
            continue
        keys = [k for k in rs[0]["diag"] if k.endswith("hard") or k.endswith("easy")]
        hard = [np.mean([r["diag"][k] for r in rs if k in r["diag"]]) for k in keys if k.endswith("hard")]
        easy = [np.mean([r["diag"][k] for r in rs if k in r["diag"]]) for k in keys if k.endswith("easy")]
        if hard and easy:
            print("%-10s hard=%.3f  easy=%.3f  diff=%+.3f" % (arm, np.mean(hard), np.mean(easy), np.mean(hard) - np.mean(easy)))


if __name__ == "__main__":
    main()
