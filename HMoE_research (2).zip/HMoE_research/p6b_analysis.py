# -*- coding: utf-8 -*-
"""p6b_analysis.py — p6a の npz から H1 の判定に必要な統計を出す（GPU 不要）

出すもの:
  1. 各 k の較正ギャップ（mean p - 実正解率）と、k=8 vs k=6 の対応検定
  2. 閾値 τ ごとの V_total（realized cost の差）と t
  3. 信頼度ビンごとの v とその SE（ピーク位置が検出力内かを見る）
  4. CE のビン別ピークとの比較
出力: p6b_analysis.json / p6b_out_utf8.txt / p6b_calibration.png
"""
import json
import math

import numpy as np

LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


def ttest(a, b):
    d = np.asarray(a, float) - np.asarray(b, float)
    n = d.size
    se = d.std(ddof=1) / math.sqrt(n)
    return float(d.mean()), float(se), float(d.mean() / se) if se > 0 else float("nan")


d = np.load("p6a_decision_curve.npz", allow_pickle=True)
KS = [8, 7, 6]
BASE, LOW = 8, 6
lang = d["lang"]
win = np.repeat(np.arange(lang.size), d["k8_nll"].size // lang.size)
OUT = {}

# ---------------------------------------------------------------- 1. 較正ギャップ
log("=== 1. 較正: p は正解率と合っているか ===")
log("%3s | %8s %8s %8s | %8s %8s %8s" % ("k", "p_top1", "top1 acc", "gap(pt)",
                                        "mass5", "in5", "gap(pt)"))
cal = {}
for k in KS:
    p1, y1 = d["k%d_ptop1" % k].astype(float), d["k%d_top1" % k].astype(float)
    p5, y5 = d["k%d_mass5" % k].astype(float), d["k%d_in5" % k].astype(float)
    cal[k] = dict(ptop1=float(p1.mean()), acc=float(y1.mean()),
                  gap1=float(p1.mean() - y1.mean()),
                  mass5=float(p5.mean()), in5=float(y5.mean()),
                  gap5=float(p5.mean() - y5.mean()))
    log("%3d | %8.4f %8.4f %+8.2f | %8.4f %8.4f %+8.2f"
        % (k, p1.mean(), y1.mean(), 100 * (p1.mean() - y1.mean()),
           p5.mean(), y5.mean(), 100 * (p5.mean() - y5.mean())))
log("")
for tag, pk, yk in (("Q1", "ptop1", "top1"), ("Q2", "mass5", "in5")):
    g = {k: d["k%d_%s" % (k, pk)].astype(float) - d["k%d_%s" % (k, yk)].astype(float)
         for k in KS}
    m, se, t = ttest(g[LOW], g[BASE])
    log("%s: 較正ギャップの変化 (k=%d - k=%d) = %+.4f (se %.4f, t=%+.2f)  "
        "%.2f pt -> %.2f pt (%.1f 倍)"
        % (tag, LOW, BASE, m, se, t, 100 * g[BASE].mean(), 100 * g[LOW].mean(),
           g[LOW].mean() / g[BASE].mean() if g[BASE].mean() != 0 else float("nan")))
    OUT["gap_%s" % tag] = dict(delta=m, se=se, t=t,
                               gap_base=float(g[BASE].mean()), gap_low=float(g[LOW].mean()))
    # 過信の方向: p が上がったのに精度が落ちたか
    mp, sp, tp = ttest(d["k%d_%s" % (LOW, pk)], d["k%d_%s" % (BASE, pk)])
    my, sy, ty = ttest(d["k%d_%s" % (LOW, yk)], d["k%d_%s" % (BASE, yk)])
    log("    p の変化 %+.4f (t=%+.2f) / 精度の変化 %+.4f (t=%+.2f) -> %s"
        % (mp, tp, my, ty,
           "過信の悪化（p↑ & 精度↓）" if mp > 0 and my < 0 else "単純な劣化"))
    OUT["gap_%s" % tag].update(d_p=mp, t_p=tp, d_acc=my, t_acc=ty)
log("")
log("言語別（k=%d - k=%d, Q1 のギャップ）:" % (LOW, BASE))
for u in ("en", "ja"):
    m = lang[win] == u
    g8 = (d["k8_ptop1"] - d["k8_top1"]).astype(float)[m]
    g6 = (d["k6_ptop1"] - d["k6_top1"]).astype(float)[m]
    mm, ss, tt = ttest(g6, g8)
    log("  %s n=%5d: %+.4f (t=%+.2f)  %.2f pt -> %.2f pt"
        % (u, m.sum(), mm, tt, 100 * g8.mean(), 100 * g6.mean()))
    OUT["gap_lang_%s" % u] = dict(delta=mm, t=tt, base=float(g8.mean()), low=float(g6.mean()))

# ---------------------------------------------------------------- 2. V_total
log("")
log("=== 2. 閾値ごとの V_total（realized cost, k=8 -> k=6） ===")
TAU = [0.5, 0.6, 0.7, 0.8, 0.9, 0.95]
EDGES = np.round(np.arange(0.0, 1.0001, 0.1), 2)


def cost(p, y, tau):
    c = p >= tau
    return c * (1.0 - y) + (1.0 - tau) * (~c)


res = {}
for q, pk, yk in (("Q1", "ptop1", "top1"), ("Q2", "mass5", "in5")):
    p8, y8 = d["k8_%s" % pk].astype(float), d["k8_%s" % yk].astype(float)
    p6, y6 = d["k6_%s" % pk].astype(float), d["k6_%s" % yk].astype(float)
    b = np.clip(np.digitize(p8, EDGES) - 1, 0, len(EDGES) - 2)
    log("[%s]  %s" % (q, " ".join("%.1f-%.1f:%d" % (EDGES[i], EDGES[i + 1],
                                                    int((b == i).sum()))
                                  for i in range(len(EDGES) - 1))))
    log("%5s %10s %10s %9s %8s | %-28s" % ("tau", "loss k8", "loss k6", "V x1000", "t",
                                           "ピーク bin (v x1000 ± se)"))
    rows = {}
    for tau in TAU:
        c8, c6 = cost(p8, y8, tau), cost(p6, y6, tau)
        m, se, t = ttest(c6, c8)
        bins = []
        for i in range(len(EDGES) - 1):
            mm = b == i
            if mm.sum() < 30:
                bins.append(None)
                continue
            v = (c6 - c8)[mm]
            bins.append(dict(lo=float(EDGES[i]), hi=float(EDGES[i + 1]), n=int(mm.sum()),
                             v=float(v.mean()), se=float(v.std(ddof=1) / math.sqrt(mm.sum()))))
        best = max((x for x in bins if x), key=lambda x: x["v"])
        rows[str(tau)] = dict(loss8=float(c8.mean()), loss6=float(c6.mean()),
                              v=m, se=se, t=t, bins=bins, peak=best)
        log("%5.2f %10.5f %10.5f %+9.3f %+8.2f | %.1f-%.1f  (%+6.2f ± %.2f, n=%d)"
            % (tau, c8.mean(), c6.mean(), 1000 * m, t,
               best["lo"], best["hi"], 1000 * best["v"], 1000 * best["se"], best["n"]))
    res[q] = dict(by_tau=rows, edges=EDGES.tolist())
    # ピークが τ を追従しているか: peak.lo と τ の相関
    pk_lo = np.array([rows[str(t)]["peak"]["lo"] for t in TAU])
    log("  ピーク bin の下端: %s   (tau: %s)" % (list(pk_lo), TAU))
    log("  peak.lo - tau:     %s" % [round(float(a - t), 2) for a, t in zip(pk_lo, TAU)])
    OUT["peak_track_%s" % q] = [float(a - t) for a, t in zip(pk_lo, TAU)]
OUT["decision"] = res

# ---------------------------------------------------------------- 3. CE のビン
log("")
log("=== 3. CE のビン別（k=8 -> k=6）===")
for q, pk in (("Q1", "ptop1"), ("Q2", "mass5")):
    p8 = d["k8_%s" % pk].astype(float)
    b = np.clip(np.digitize(p8, EDGES) - 1, 0, len(EDGES) - 2)
    dce = d["k6_nll"].astype(float) - d["k8_nll"].astype(float)
    log("[%s]" % q)
    line = []
    for i in range(len(EDGES) - 1):
        m = b == i
        if m.sum() < 30:
            continue
        line.append("%.1f:%.3f" % (EDGES[i], dce[m].mean()))
    log("  " + "  ".join(line))

with open("p6b_analysis.json", "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=2)
with open("p6b_out_utf8.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(LOG))

# ---------------------------------------------------------------- 3b. 運用指標
log("")
log("=== 3b. 運用指標: 自動化率と、自動化した中の誤り率 ===")
ops = {}
for q, pk, yk in (("Q1", "ptop1", "top1"), ("Q2", "mass5", "in5")):
    log("[%s]" % q)
    log("%5s %5s %10s %10s %10s | %10s %10s" %
        ("tau", "k", "自動化率", "自動化内誤り", "全体コスト", "対 k=8 差", ""))
    for tau in (0.5, 0.8, 0.9):
        row = {}
        base_cost = None
        for k in KS:
            p = d["k%d_%s" % (k, pk)].astype(float)
            y = d["k%d_%s" % (k, yk)].astype(float)
            commit = p >= tau
            rate = commit.mean()
            err_in = (1 - y)[commit].mean() if commit.sum() else float("nan")
            c = cost(p, y, tau).mean()
            if k == BASE:
                base_cost = c
            row[k] = dict(rate=float(rate), err_in=float(err_in), cost=float(c))
            log("%5.2f %5d %10.4f %10.4f %10.5f | %+10.5f"
                % (tau, k, rate, err_in, c, c - base_cost if base_cost is not None else 0.0))
        ops["%s_%.2f" % (q, tau)] = row
        # 自動化率の変化（k=8 -> k=6）
        dp = row[LOW]["rate"] - row[BASE]["rate"]
        log("      -> 自動化率 %+.4f (%+.2f pt) / 自動化内誤り %+.4f (%+.2f pt)"
            % (dp, 100 * dp, row[LOW]["err_in"] - row[BASE]["err_in"],
               100 * (row[LOW]["err_in"] - row[BASE]["err_in"])))
OUT["ops"] = ops

# ---------------------------------------------------------------- 3c. CE の価値のうち決定損失がゼロと言う割合
log("")
log("=== 3c. CE の価値はどこにあり、決定損失はそこをどう扱うか ===")
for q, pk in (("Q1", "ptop1"), ("Q2", "mass5")):
    p8 = d["k8_%s" % pk].astype(float)
    dce = d["k6_nll"].astype(float) - d["k8_nll"].astype(float)
    tot = dce.sum()
    for thr in (0.4, 0.5):
        share = dce[p8 < thr].sum() / tot
        log("  %s: CE 価値のうち p<%.1f にある割合 = %.1f%%" % (q, thr, 100 * share))
        OUT["ce_share_%s_%.1f" % (q, thr)] = float(share)

# ---------------------------------------------------------------- 3d. 自動化された判断だけの対応検定
log("")
log("=== 3d. k=8 で自動化された判断（p8>=tau）に限った誤り率の変化 ===")
for q, pk, yk in (("Q1", "ptop1", "top1"), ("Q2", "mass5", "in5")):
    p8 = d["k8_%s" % pk].astype(float)
    for tau in (0.8, 0.9):
        sel = p8 >= tau
        e8 = 1.0 - d["k8_%s" % yk].astype(float)[sel]
        e6 = 1.0 - d["k6_%s" % yk].astype(float)[sel]
        m, se, t = ttest(e6, e8)
        log("  %s tau=%.1f n=%4d: 誤り率 %.4f -> %.4f  (%+.4f, se %.4f, t=%+.2f, 相対 %+.0f%%)"
            % (q, tau, sel.sum(), e8.mean(), e6.mean(), m, se, t,
               100 * m / e8.mean() if e8.mean() > 0 else float("nan")))
        OUT["automated_%s_%.1f" % (q, tau)] = dict(
            n=int(sel.sum()), err8=float(e8.mean()), err6=float(e6.mean()),
            d=m, se=se, t=t)

# ---------------------------------------------------------------- 4. 図
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.3), dpi=140)
    for tau, col in zip([0.5, 0.7, 0.9], ["C0", "C1", "C3"]):
        bins = [x for x in res["Q2"]["by_tau"][str(tau)]["bins"] if x]
        xs = [(x["lo"] + x["hi"]) / 2 for x in bins]
        ys = [1000 * x["v"] for x in bins]
        es = [1000 * x["se"] for x in bins]
        ax[0].errorbar(xs, ys, yerr=es, fmt="o-", color=col, capsize=2, lw=1.2,
                       label="tau=%.1f" % tau)
    for tau, col in zip([0.5, 0.7, 0.9], ["C0", "C1", "C3"]):
        ax[0].axvline(tau, color=col, ls=":", lw=0.8, alpha=0.6)
    ax[0].axhline(0, color="gray", lw=0.6)
    ax[0].set_xlabel("baseline confidence p (mass of top-5, k=8)")
    ax[0].set_ylabel("value of compute  x1000")
    ax[0].set_title("Q2: value of compute by confidence (dotted = tau)")
    ax[0].legend(fontsize=8)
    ax[0].grid(alpha=0.3)

    # 較正: ビンごとの p vs 実正解率
    p8 = d["k8_mass5"].astype(float)
    y8 = d["k8_in5"].astype(float)
    p6 = d["k6_mass5"].astype(float)
    y6 = d["k6_in5"].astype(float)
    b = np.clip(np.digitize(p8, EDGES) - 1, 0, len(EDGES) - 2)
    xs, a8, a6 = [], [], []
    for i in range(len(EDGES) - 1):
        m = b == i
        if m.sum() < 30:
            continue
        xs.append(p8[m].mean())
        a8.append(y8[m].mean())
        a6.append(y6[m].mean())
    ax[1].plot([0, 1], [0, 1], "k--", lw=0.8, label="perfect calibration")
    ax[1].plot(xs, a8, "o-", color="C0", label="k=8")
    ax[1].plot(xs, a6, "s-", color="C3", label="k=6")
    ax[1].set_xlabel("model probability p")
    ax[1].set_ylabel("empirical hit rate")
    ax[1].set_title("Cutting experts pushes p up and accuracy down")
    ax[1].legend(fontsize=8)
    ax[1].grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig("p6b_calibration.png")
    log("\nsaved p6b_calibration.png")
except Exception as e:
    log("figure failed: %s" % e)
