"""ローカルシャードの破損パターンを診断する（直接ダウンロードしたバイト列がローカルのどこにあるか）。"""
import json
import os
import struct
import urllib.request

D = r"C:\Users\gochu\WorkBuddy AI\不均一MoE\models\olmoe-1b-7b"
URL = "https://huggingface.co/allenai/OLMoE-1B-7B-0924/resolve/main/model-00001-of-00003.safetensors"
KEY = "model.layers.1.mlp.experts.5.down_proj.weight"


def main():
    sh = os.path.join(D, "model-00001-of-00003.safetensors")
    size = os.path.getsize(sh)
    with open(sh, "rb") as fp:
        n = struct.unpack("<Q", fp.read(8))[0]
        hdr = json.loads(fp.read(n).decode("utf-8"))
    s, e = hdr[KEY]["data_offsets"]
    abs_s = 8 + n + s
    req = urllib.request.Request(URL, headers={"Range": "bytes=%d-%d" % (abs_s, abs_s + 63)})
    with urllib.request.urlopen(req, timeout=300) as r:
        probe = r.read()
    print("probe bytes:", probe[:16].hex(), "at abs offset", abs_s)
    # ローカルファイル中に probe が存在するオフセットを探す
    found = []
    CH = 1 << 20
    with open(sh, "rb") as fp:
        off = 0
        prev = b""
        while True:
            buf = fp.read(CH)
            if not buf:
                break
            win = prev + buf
            base = off - len(prev)
            idx = win.find(probe)
            while idx != -1:
                found.append(base + idx)
                idx = win.find(probe, idx + 1)
            prev = buf[-64:]
            off += len(buf)
    print("probe found at local offsets:", found, "(expected exactly [%d])" % abs_s)
    print("file size:", size)
    # 直接版の先頭 64 バイトと、ローカルの対応位置の 64 バイト
    with open(sh, "rb") as fp:
        fp.seek(abs_s)
        loc64 = fp.read(64)
    print("local   at expected:", loc64[:16].hex())
    print("direct  at expected:", probe[:16].hex())


if __name__ == "__main__":
    main()
