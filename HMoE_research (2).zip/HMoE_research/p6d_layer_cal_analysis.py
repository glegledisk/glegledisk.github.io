# -*- coding: utf-8 -*-
"""p6d_layer_cal_analysis.py — H3 の判定（GPU 不要）

P3b の層非対称性（後半を削る方が高い）が、較正指標でも同じ順序で出るかを見る。
中心量は「非対称性比」= (f8b6 - base) / (f6b8 - base)。CE では 1.82。
H3 はこれが較正指標では 1 に近づく（または逆転する）と予測する。

ECE は集合レベルの統計なので、ウィンドウ単位のブートストラップで CI を出す
（トークン単位だと空間相関で過大に有意になる。P4b の教訓）。

出力: p6d_analysis.json / p6d_out_utf8.txt / p6d_layer_cal.png
"""
import json
import math

import numpy as np

LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


def ttest(a, b):
    d = np.asarray(a, float) - np.asarray(b, float)
    n = d.size
    se = d.std(ddof=1) / math.sqrt(n)
    return float(d.mean()), float(se), float(d.mean() / se) if se > 0 else float("nan")


def ece(p, y, nbins=10):
    """等幅ビンの ECE と符号つきギャップ（conf - acc）の内訳。"""
    edges = np.linspace(0.0, 1.0, nbins + 1)
    b = np.clip(np.digitize(p, edges) - 1, 0, nbins - 1)
    tot = 0.0
    for i in range(nbins):
        m = b == i
        if m.sum() == 0:
            continue
        tot += m.sum() / p.size * abs(y[m].mean() - p[m].mean())
    return tot


def brier(p, y):
    return float(np.mean((p - y) ** 2))


z = np.load("p6c_layer_cal.npz", allow_pickle=True)
lang = z["lang"]
nwin = lang.size
ALLOCS = ["base", "u7", "f6b8", "f8b6"]
QS = [("Q1", "ptop1", "top1"), ("Q2", "mass5", "in5")]
OUT = {"n_tokens": int(z["base_nll"].size), "n_windows": int(nwin)}

log("tokens=%d  windows=%d" % (z["base_nll"].size, nwin))
log("")
log("=== 1. 各指標の水準 ===")
log("%-6s %10s %10s %10s %10s %10s %10s" %
    ("alloc", "CE", "p_top1", "acc", "gap(pt)", "ECE(pt)", "Brier"))
tab = {}
for a in ALLOCS:
    p, y = z["%s_ptop1" % a].astype(float), z["%s_top1" % a].astype(float)
    row = dict(ce=float(z["%s_nll" % a].astype(float).mean()),
               p=float(p.mean()), acc=float(y.mean()),
               gap=float(p.mean() - y.mean()), ece=ece(p, y), brier=brier(p, y))
    p5, y5 = z["%s_mass5" % a].astype(float), z["%s_in5" % a].astype(float)
    row.update(p5=float(p5.mean()), acc5=float(y5.mean()),
               gap5=float(p5.mean() - y5.mean()), ece5=ece(p5, y5), brier5=brier(p5, y5))
    tab[a] = row
    log("%-6s %10.5f %10.4f %10.4f %+10.2f %10.2f %10.5f"
        % (a, row["ce"], row["p"], row["acc"], 100 * row["gap"], 100 * row["ece"], row["brier"]))
OUT["levels"] = tab

log("")
log("=== 2. 非対称性比 (f8b6 - base) / (f6b8 - base) ===")
log("    P3b の CE は 1.82（後半を削る方が高い）。H3 は較正指標で 1 に近づくと予測。")
METRICS = [("CE", "ce"), ("較正ギャップ", "gap"), ("ECE", "ece"), ("Brier", "brier"),
           ("較正ギャップ(top5)", "gap5"), ("ECE(top5)", "ece5"), ("Brier(top5)", "brier5")]
ratios = {}
for label, key in METRICS:
    d6 = tab["f6b8"][key] - tab["base"][key]
    d8 = tab["f8b6"][key] - tab["base"][key]
    r = d8 / d6 if d6 != 0 else float("nan")
    ratios[key] = dict(d_f6b8=d6, d_f8b6=d8, ratio=r)
    log("  %-20s d(f6b8)=%+.5f  d(f8b6)=%+.5f  ratio=%+.2f" % (label, d6, d8, r))
OUT["ratios"] = ratios

log("")
log("=== 3. f6b8 vs f8b6 の対応検定 ===")
log("  (a) トークン単位（n=%d）" % z["base_nll"].size)
pairs = {}
for q, pk, yk in QS:
    p6, y6 = z["f6b8_%s" % pk].astype(float), z["f6b8_%s" % yk].astype(float)
    p8, y8 = z["f8b6_%s" % pk].astype(float), z["f8b6_%s" % yk].astype(float)
    for nm, a, b in (("CE", z["f6b8_nll"], z["f8b6_nll"]),
                     ("gap", p6 - y6, p8 - y8),
                     ("Brier", (p6 - y6) ** 2, (p8 - y8) ** 2)):
        m, se, t = ttest(a, b)
        log("    %s %-6s f6b8-f8b6 = %+.6f (se %.6f, t=%+.2f)" % (q, nm, m, se, t))
        pairs["%s_%s_tok" % (q, nm)] = dict(d=m, se=se, t=t)

log("  (b) ウィンドウ単位（n=%d, 空間相関を保守的に扱う）" % nwin)
win = np.repeat(np.arange(nwin), z["base_nll"].size // nwin)
for nm, fn in (
    ("CE", lambda a: z["%s_nll" % a].astype(float)),
    ("gap(Q1)", lambda a: z["%s_ptop1" % a].astype(float) - z["%s_top1" % a].astype(float)),
    ("gap(Q2)", lambda a: z["%s_mass5" % a].astype(float) - z["%s_in5" % a].astype(float)),
    ("Brier(Q1)", lambda a: (z["%s_ptop1" % a].astype(float) - z["%s_top1" % a].astype(float)) ** 2),
):
    d = fn("f6b8") - fn("f8b6")
    per_win = np.array([d[win == w].mean() for w in range(nwin)])
    m, se, t = ttest(per_win, np.zeros_like(per_win))
    log("    %-10s f6b8-f8b6 = %+.6f (se %.6f, t=%+.2f)" % (nm, m, se, t))
    pairs["%s_win" % nm] = dict(d=m, se=se, t=t)
OUT["pairs"] = pairs

log("")
log("=== 3b. 機構: p と正解率を分けて見る（f6b8 - f8b6） ===")
for q, pk, yk in QS:
    for nm, a, b in (("p", z["f6b8_%s" % pk], z["f8b6_%s" % pk]),
                     ("正解", z["f6b8_%s" % yk], z["f8b6_%s" % yk])):
        m, se, t = ttest(a, b)
        log("    %s %-4s = %+.6f (se %.6f, t=%+.2f)" % (q, nm, m, se, t))
        OUT.setdefault("mech", {})["%s_%s" % (q, nm)] = dict(d=m, se=se, t=t)
log("    base からの変化:")
for a in ("f6b8", "f8b6"):
    dp = z["%s_ptop1" % a].astype(float).mean() - z["base_ptop1"].astype(float).mean()
    da = z["%s_top1" % a].astype(float).mean() - z["base_top1"].astype(float).mean()
    log("      %-5s: dp=%+.5f  d(acc)=%+.5f" % (a, dp, da))
    OUT.setdefault("mech", {})["d_%s" % a] = dict(dp=float(dp), dacc=float(da))

log("")
log("=== 4. ECE の差のブートストラップ（ウィンドウ再標本, B=2000） ===")
rng = np.random.default_rng(0)
B = 2000
boot = {a: [] for a in ALLOCS}
for b in range(B):
    w = rng.integers(0, nwin, nwin)
    idx = np.concatenate([np.where(win == x)[0] for x in w])
    for a in ALLOCS:
        p = z["%s_ptop1" % a].astype(float)[idx]
        y = z["%s_top1" % a].astype(float)[idx]
        boot[a].append(ece(p, y))
boot = {a: np.array(v) for a, v in boot.items()}
for cmp_name, hi, lo in (("f8b6 - f6b8", "f8b6", "f6b8"), ("u7 - base", "u7", "base")):
    d = boot[hi] - boot[lo]
    lo95, hi95 = np.percentile(d, [2.5, 97.5])
    log("  ECE %s: %+.5f  95%%CI [%+.5f, %+.5f]  P(d>0)=%.2f"
        % (cmp_name, d.mean(), lo95, hi95, float((d > 0).mean())))
    OUT["boot_%s" % cmp_name.replace(" ", "_")] = dict(
        mean=float(d.mean()), lo=float(lo95), hi=float(hi95),
        p_pos=float((d > 0).mean()))
# 比のブートストラップ
d6 = boot["f6b8"] - boot["base"]
d8 = boot["f8b6"] - boot["base"]
ok = np.abs(d6) > 1e-9
r = d8[ok] / d6[ok]
lo95, hi95 = np.percentile(r, [2.5, 97.5])
log("  ECE の非対称性比: 中央 %.2f  95%%CI [%.2f, %.2f]" % (np.median(r), lo95, hi95))
OUT["boot_ratio_ece"] = dict(median=float(np.median(r)), lo=float(lo95), hi=float(hi95))

log("")
log("=== 5. 非対称性比のブートストラップ（全指標・ウィンドウ再標本, B=2000） ===")


def metric_value_idx(a, key, idx):
    """部分標本 idx 上での指標値。"""
    if key == "ce":
        return float(z["%s_nll" % a].astype(float)[idx].mean())
    p = z["%s_ptop1" % a].astype(float)[idx]
    y = z["%s_top1" % a].astype(float)[idx]
    if key == "gap":
        return float((p - y).mean())
    if key == "brier":
        return brier(p, y)
    if key == "ece":
        return ece(p, y)
    raise KeyError(key)


def metric_value(a, key):
    return metric_value_idx(a, key, np.arange(z["base_nll"].size))


ratio_boot = {}
for key in ("ce", "gap", "ece", "brier"):
    vals = {a: [] for a in ("base", "f6b8", "f8b6")}
    for b in range(B):
        w = rng.integers(0, nwin, nwin)
        idx = np.concatenate([np.where(win == x)[0] for x in w])
        for a in vals:
            vals[a].append(metric_value_idx(a, key, idx))
    d6 = np.array(vals["f6b8"]) - np.array(vals["base"])
    d8 = np.array(vals["f8b6"]) - np.array(vals["base"])
    ok2 = np.abs(d6) > 1e-9
    rr = d8[ok2] / d6[ok2]
    lo95, hi95 = np.percentile(rr, [2.5, 97.5])
    ratio_boot[key] = dict(median=float(np.median(rr)), lo=float(lo95), hi=float(hi95),
                           p_pos=float((rr > 0).mean()))
    log("  %-6s ratio 中央 %6.2f  95%%CI [%7.2f, %7.2f]  P(>0)=%.2f"
        % (key, np.median(rr), lo95, hi95, float((rr > 0).mean())))
OUT["ratio_boot"] = ratio_boot

with open("p6d_analysis.json", "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=2)
with open("p6d_out_utf8.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(LOG))

# ---------------------------------------------------------------- 図
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.3), dpi=140)
    # 左: 非対称性比そのもの（対数軸）。1 = 非対称なし、1.82 = CE の比
    keys = ["ce", "gap", "ece", "brier"]
    labels = ["CE", "calib gap", "ECE", "Brier"]
    med = [ratio_boot[k]["median"] for k in keys]
    err = [[max(0.0, ratio_boot[k]["median"] - ratio_boot[k]["lo"]) for k in keys],
           [max(0.0, ratio_boot[k]["hi"] - ratio_boot[k]["median"]) for k in keys]]
    xs = np.arange(len(keys))
    ax[0].bar(xs, med, color=["C0", "C3", "C1", "C2"], alpha=0.8)
    ax[0].errorbar(xs, med, yerr=err, fmt="none", ecolor="k", capsize=4, lw=1)
    ax[0].axhline(1.0, color="k", ls="--", lw=0.9, label="no asymmetry")
    ax[0].axhline(1.82, color="gray", ls=":", lw=0.9, label="P3b CE = 1.82")
    ax[0].set_yscale("symlog", linthresh=1.0)
    ax[0].set_xticks(xs)
    ax[0].set_xticklabels(labels)
    ax[0].set_ylabel("asymmetry ratio  (f8b6-base)/(f6b8-base)")
    ax[0].set_title("How big is the back-half penalty? depends on the metric")
    for x, m in zip(xs, med):
        ax[0].text(x, m, " %.2f" % m, ha="center", va="bottom", fontsize=9)
    ax[0].legend(fontsize=8, loc="upper right")
    ax[0].grid(alpha=0.3, axis="y")

    # 右: 信頼性曲線 f6b8 vs f8b6
    edges = np.linspace(0, 1, 11)
    for a, col in (("base", "gray"), ("f6b8", "C2"), ("f8b6", "C3")):
        p = z["%s_ptop1" % a].astype(float)
        y = z["%s_top1" % a].astype(float)
        b = np.clip(np.digitize(p, edges) - 1, 0, 9)
        xs2, ys2 = [], []
        for i in range(10):
            m = b == i
            if m.sum() < 30:
                continue
            xs2.append(p[m].mean())
            ys2.append(y[m].mean())
        ax[1].plot(xs2, ys2, "o-", color=col, label=a, ms=3)
    ax[1].plot([0, 1], [0, 1], "k--", lw=0.8)
    ax[1].set_xlabel("p_top1")
    ax[1].set_ylabel("empirical accuracy")
    ax[1].set_title("Reliability: which half is cut matters?")
    ax[1].legend(fontsize=8)
    ax[1].grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig("p6d_layer_cal.png")
    log("\nsaved p6d_layer_cal.png")
except Exception as e:
    log("figure failed: %s" % e)
