"""P1（汎用版）: 任意の MoE で「logit b のゼロ計算 Expert が top-k に入る割合」を測る。

OLMoE 版（p1_deadzone_probe_olmoe.py）の汎用化。ルータ構造を自動発見する:
  - 名前が ".router" で終わる nn.Linear（Switch Transformer 系）→ 出力は logits テンソル
  - クラス名が "Router" で終わる独自モジュール（OLMoE の OlmoeTopKRouter）→ 出力は tuple、[0] が logits

使い方:
  python p1_deadzone_probe_generic.py --model models/switch-base-8 --tag sw8 --top-k 1
"""

import argparse
import glob
import json
import os
import random
import re

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))


def log(msg):
    print(msg, flush=True)


def load_corpus(lang, max_chars=400000):
    if lang == "en":
        files = sorted(glob.glob(os.path.join(HERE, "english_version", "**", "*.md"), recursive=True))
    else:
        files = [f for f in sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True))
                 if "english_version" not in f]
    parts = []
    for f in files:
        try:
            with open(f, "r", encoding="utf-8") as fp:
                txt = fp.read()
        except Exception:
            continue
        txt = re.sub(r"```.*?```", " ", txt, flags=re.S)
        txt = re.sub(r"<!--.*?-->", " ", txt, flags=re.S)
        txt = re.sub(r"^\s*\|[-: ]+\|.*$", " ", txt, flags=re.M)
        parts.append(txt)
        if sum(len(p) for p in parts) >= max_chars:
            break
    return "\n\n".join(parts)


def find_routers(model):
    """(name, module, kind) を返す。kind は 'linear' か 'tuple'。

    - Switch 系: mlp.router.classifier（nn.Linear）が生 logits を出す
    - OLMoE 系 : OlmoeTopKRouter（weight を直接持ち、tuple を返す）
    """
    out = []
    for name, m in model.named_modules():
        if isinstance(m, torch.nn.Linear) and (name.endswith(".router") or name.endswith(".router.classifier")):
            out.append((name, m, "linear"))
        elif type(m).__name__.endswith("Router") and hasattr(m, "weight"):
            out.append((name, m, "tuple"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", required=True)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--top-k", type=int, default=None, help="省略時は config から推定")
    ap.add_argument("--windows", type=int, default=6)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--dtype", default="float32", choices=["float32", "bfloat16"])
    ap.add_argument("--device", default="cuda")
    args = ap.parse_args()

    rng = random.Random(args.seed)
    torch.manual_seed(args.seed)

    from transformers import AutoConfig, AutoModelForCausalLM, AutoModelForSeq2SeqLM, AutoTokenizer

    cfg = AutoConfig.from_pretrained(args.model)
    is_seq2seq = cfg.model_type in ("t5", "switch_transformers", "mt5")
    ModelCls = AutoModelForSeq2SeqLM if is_seq2seq else AutoModelForCausalLM
    tok = AutoTokenizer.from_pretrained(args.model)
    dtype = torch.float32 if args.dtype == "float32" else torch.bfloat16
    model = ModelCls.from_pretrained(args.model, dtype=dtype).to(args.device).eval()
    log("[1/4] loaded %s (model_type=%s, seq2seq=%s)" % (args.model, cfg.model_type, is_seq2seq))

    routers = find_routers(model)
    if not routers:
        raise RuntimeError("ルータが見つからない")
    log("      %d routers: %s ..." % (len(routers), [r[0] for r in routers[:3]]))

    n_experts = None
    for name, m, kind in routers:
        n_experts = m.out_features if kind == "linear" else int(m.num_experts)
        break
    n_experts = int(getattr(cfg, "num_experts", n_experts))
    top_k = args.top_k
    if top_k is None:
        top_k = int(getattr(cfg, "num_experts_per_tok", 1))
    log("      experts=%d top_k=%d" % (n_experts, top_k))

    captured = {}

    def make_hook(idx, kind):
        def hook(module, inp, out):
            z = out[0] if (kind == "tuple" and isinstance(out, (tuple, list))) else out
            captured[idx] = z.detach().to(torch.float32).cpu()
        return hook

    handles = []
    for i, (name, m, kind) in enumerate(routers):
        handles.append(m.register_forward_hook(make_hook(i, kind)))

    # コーパス
    log("[2/4] building corpus")
    corpora = {}
    for lang in ("en", "ja"):
        ids = tok(load_corpus(lang), return_tensors="pt", add_special_tokens=False).input_ids[0]
        log("      %s: %d tokens" % (lang, ids.numel()))
        corpora[lang] = ids

    windows = []
    for lang, ids in corpora.items():
        L = ids.numel()
        for _ in range(args.windows):
            start = 0 if L <= args.len else rng.randrange(0, L - args.len)
            windows.append((lang, ids[start:start + args.len]))
    log("      %d windows x %d tokens" % (len(windows), args.len))

    log("[3/4] forward passes")
    per_router = {i: [] for i in range(len(routers))}
    lang_of_token = []
    with torch.no_grad():
        for wi, (lang, win) in enumerate(windows):
            captured.clear()
            ids = win.unsqueeze(0).to(args.device)
            kw = dict(input_ids=ids)
            if is_seq2seq:
                kw["decoder_input_ids"] = ids
            model(**kw)
            ntok = captured[0].reshape(-1, n_experts).shape[0]
            for i in range(len(routers)):
                per_router[i].append(captured[i].reshape(-1, n_experts).numpy().astype(np.float32))
            lang_of_token.extend([lang] * ntok)
            log("      window %d/%d (%s)" % (wi + 1, len(windows), lang))
    for h in handles:
        h.remove()
    lang_of_token = np.array(lang_of_token)

    log("[4/4] statistics")
    b_grid = [0.0, 0.5, 1.0, 2.0, 3.0, 5.0]
    targets = [0.01, 0.05, 0.10, 0.25, 0.50]
    rows, all_tau, all_z = [], [], []
    for i in range(len(routers)):
        Z = np.concatenate(per_router[i], axis=0)
        if Z.shape[1] != n_experts:
            continue
        k = min(top_k, n_experts)
        tau = np.partition(Z, n_experts - k, axis=1)[:, n_experts - k]
        order = np.argsort(-Z, axis=1)
        sel = np.zeros_like(Z, dtype=bool)
        sel[np.arange(Z.shape[0])[:, None], order[:, :k]] = True
        row = {
            "router": routers[i][0],
            "n_tokens": int(Z.shape[0]),
            "tau_mean": float(tau.mean()),
            "tau_median": float(np.median(tau)),
            "z_mean": float(Z.mean()),
            "z_std": float(Z.std()),
            "n_logit_pos_mean": float((Z > 0).sum(axis=1).mean()),
            "inzone_b0": float((0.0 >= tau).mean()),
        }
        for b in b_grid:
            row["inzone_b%.1f" % b] = float((b >= tau).mean())
        for q in targets:
            row["bstar_q%.2f" % q] = float(np.quantile(tau, q))
        rows.append(row)
        all_tau.append(tau)
        all_z.append(Z)

    TAU = np.concatenate(all_tau)
    Z = np.concatenate(all_z, axis=0)
    sigma = float(Z.std())
    summary = {
        "model": args.model,
        "model_type": cfg.model_type,
        "n_routers": len(rows),
        "n_experts": n_experts,
        "top_k": top_k,
        "n_tokens_total": int(TAU.shape[0]),
        "z_mean": float(Z.mean()),
        "z_std": sigma,
        "n_logit_pos_mean": float((Z > 0).sum(axis=1).mean()),
        "tau_mean": float(TAU.mean()),
        "tau_median": float(np.median(TAU)),
        "inzone_b0": float((0.0 >= TAU).mean()),
        "inzone_grid": {str(b): float((b >= TAU).mean()) for b in b_grid},
        "bstar": {("%.2f" % q): float(np.quantile(TAU, q)) for q in targets},
        "bstar_sigma": {("%.2f" % q): float(np.quantile(TAU, q) / sigma) for q in targets},
        "by_language": {},
    }
    for lang in sorted(set(lang_of_token.tolist())):
        # all_tau は「ルータごとに全トークン」を連結しているので、マスクもルータ数だけ繰り返す
        mask = np.tile(lang_of_token == lang, len(rows))
        T = TAU[mask]
        summary["by_language"][lang] = {
            "n_tokens": int(T.shape[0]),
            "tau_median": float(np.median(T)),
            "inzone_b0": float((0.0 >= T).mean()),
            "inzone_b1.0": float((1.0 >= T).mean()),
        }

    import csv
    with open(os.path.join(HERE, "p1_%s_by_router.csv" % args.tag), "w", newline="", encoding="utf-8") as fp:
        cols = list(rows[0].keys()) + ["inzone_b%.1f" % b for b in b_grid] + ["bstar_q%.2f" % q for q in targets]
        w = csv.DictWriter(fp, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow(r)
    with open(os.path.join(HERE, "p1_%s_summary.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    for i, arr in enumerate(per_router.values()):
        pass

    log("")
    log("=== SUMMARY (%s) ===" % args.tag)
    log("  routers=%d experts=%d top_k=%d samples=%d" % (len(rows), n_experts, top_k, TAU.shape[0]))
    log("  logit mean %.3f, std %.3f, #pos %.2f/%d" % (Z.mean(), sigma, summary["n_logit_pos_mean"], n_experts))
    log("  tau median %.3f, mean %.3f" % (np.median(TAU), TAU.mean()))
    log("  in-zone @ b=0: %.5f" % summary["inzone_b0"])
    for b in b_grid:
        log("  in-zone @ b=%.1f: %.5f" % (b, summary["inzone_grid"][str(b)]))
    for q in targets:
        log("  b* for %.0f%%: %.3f (= %.2f sigma)" % (q * 100, summary["bstar"]["%.2f" % q], summary["bstar_sigma"]["%.2f" % q]))
    for lang, d in summary["by_language"].items():
        log("  [%s] n=%d tau_med=%.3f inzone_b0=%.4f" % (lang, d["n_tokens"], d["tau_median"], d["inzone_b0"]))


if __name__ == "__main__":
    main()
