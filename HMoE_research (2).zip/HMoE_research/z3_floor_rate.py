#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Z3: 床モード発生率の確認的比率検定（McNemar）と eval 側収束ゲート。

事前登録: `Z3課題設計書_床モード発生率の比率検定とeval側収束ゲート_20261109.md`
（仮説・estimand・検定・n=60・seed 100..159・閾値・ゲート・判定規則は実行前に固定）。

★ 本次は保留 1（中心命題の直接検定）ではない。Z1 §4 規則 3 の禁止は解除しない。
★ 床 seed を 1 個も除外しない（除外すれば estimand 自身を消す）。

主解析: 2x2 (両腕とも床 a / H のみ b / U のみ c / 非床 d) から
  p = binomtest(b, b+c, 0.5, alternative="two-sided").pvalue
  RD = (b-c)/n, Wald 95% CI, pi = b/(b+c), Clopper-Pearson 95% CI
確認的ファミリは m = 1、alpha = 0.05、Holm 不要。

出力: z3_results.json / z3_delta.npz / z3_analysis.json / z3_calib.json /
      z3_train.json / z3_out_utf8.txt / simulation_hmoe_mmlu/data/z3/ckpt_*.pt
"""
import argparse
import hashlib
import json
import math
import os
import sys
import time

import numpy as np
import torch
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# Z1 / Z2 のハーネスをそのまま流用（腕・幅・訓練 backend・評価器・校正 129 項目）
import z1_p2_seed_extension as Z1            # noqa: E402
import z2_confirm_reversal as Z2             # noqa: E402

Q2, Q8 = Z1.Q2, Z1.Q8
assert Z1.Y1.E2.SEQ == 128
assert Z2.Z1.Y1.E2.SEQ == 128

Z3DIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "z3")
Z3SMOKEDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "z3_smoke")
ACTIVE_Z3DIR = Z3DIR

ARMS = ("H_1024", "U_688")
ORACLE_ARMS = tuple(f"oracle_{a}" for a in ARMS)
ALL_ARMS = ARMS + ORACLE_ARMS

# 0..59 は発見・校正専用（W2 / Y1 / Z1 / Z2 の既存 ckpt）。100..159 が確認標本。
SEEDS_EXISTING = tuple(range(60))
SEEDS_CONFIRM = tuple(range(100, 160))
SEEDS_SMOKE = (100,)
SEEDS_ALL = SEEDS_EXISTING + SEEDS_CONFIRM

# 設計書 §2 / §4 / §6 の固定値。結果を見て変更しない。
TAU_IV, TAU_LOSS, TAU_CE = 0.10, 0.30, 0.50
ALPHA = 0.05
E_FLAG_CAP = 6                    # ceil(0.10 * 60)
MIN_CONVERGED = 108               # 90% of 120 runs
EVAL_SEED, EVAL_SEED_GATE, EVAL_SEED_ROB = 777, 779, 778
N_EVAL, EPOCHS = 1024, 6
TRAIN_LOG = os.path.join(HERE, "z3_train.json")

assert len(SEEDS_CONFIRM) == 60
assert Z1.NPARAM_EXPECT["H_1024"] == 1346877
assert Z1.NPARAM_EXPECT["U_688"] == 1001469


# ---------------------------------------------------------------------------
# ckpt の出所（0..7 W2/Y1、8..23 Z1、24..59 Z2、100..159 Z3）
# ---------------------------------------------------------------------------
def ckpt_path(arch, seed, active_dir=None):
    if arch not in ARMS:
        raise ValueError(f"未登録の腕: {arch}")
    if seed in SEEDS_EXISTING:
        return Z2.ckpt_path(arch, seed, None)
    if seed not in SEEDS_CONFIRM:
        raise ValueError(f"未登録の seed: {seed}")
    return os.path.join(active_dir or ACTIVE_Z3DIR,
                        f"ckpt_{arch}_s{seed}.pt")


def load_arch(arch, seed, active_dir=None):
    path = ckpt_path(arch, seed, active_dir)
    td = torch.load(path, map_location="cpu")
    model = Z1.build_model(arch, seed)
    assert set(td.keys()) == set(model.p.keys()), f"{arch} s{seed}: ckpt キー不一致"
    for kk in td:
        assert tuple(td[kk].shape) == tuple(model.p[kk].shape), \
            f"{arch} s{seed}: {kk} の形が違う"
    clean = {k: v.detach().clone() for k, v in td.items()}
    return model, clean


def fingerprint(path):
    """ckpt の軽量フィンガープリント（全テンソル先頭 64 float ずつ）。"""
    td = torch.load(path, map_location="cpu")
    h = hashlib.sha256()
    for k in sorted(td.keys()):
        h.update(k.encode("utf-8"))
        v = np.ascontiguousarray(
            td[k].detach().cpu().numpy(), dtype="<f4").reshape(-1)[:64]
        h.update(v.tobytes())
    return h.hexdigest()


def gate_eval(arch, seed, seq_gate, typ_gate, active_dir):
    """訓練直後の eval 側ゲート測定（設計書 §4-2 / §5）。"""
    model, clean = load_arch(arch, seed, active_dir)
    Z1.fresh(model, clean)
    m, x = Z1.evaluate(model, seq_gate, typ_gate)
    iv = float(m["instr_valid"])
    ce = float(np.mean(x["ce_seq"]))
    finite = bool(np.isfinite(iv) and np.isfinite(ce)
                  and np.isfinite(x["ce_seq"]).all())
    return {"iv_gate": iv, "ce_seq_gate": ce, "n_eval": int(len(x["ce_seq"])),
            "finite": finite,
            "in_range": bool(finite and 0.0 <= iv <= 1.0)}


# ---------------------------------------------------------------------------
# 校正 C6 / C7' / C8 / C9
# ---------------------------------------------------------------------------
def _item(name, arch, seed, field, want, got, ok):
    try:
        diff = abs(float(want) - float(got))
    except (TypeError, ValueError):
        diff = 0.0 if ok else 1.0
    return {"check": name, "arch": arch, "seed": seed, "field": field,
            "want": want, "got": got, "abs_diff": float(diff),
            "bit_match": bool(ok)}


def calibration_c7p(new_seeds, active_dir, log):
    """新規 ckpt が既存 60/腕のいずれとも一致せず、新規内重複も 0。"""
    existing = {a: {fingerprint(ckpt_path(a, s, None))
                    for s in SEEDS_EXISTING} for a in ARMS}
    newfp = {a: set() for a in ARMS}
    collisions = []
    for s in new_seeds:
        for a in ARMS:
            fp = fingerprint(ckpt_path(a, s, active_dir))
            if fp in existing[a]:
                collisions.append(f"{a}_s{s}")
            newfp[a].add(fp)
    n_new = len(new_seeds) * len(ARMS)
    n_unique = sum(len(v) for v in newfp.values())
    out = {"n_new_ckpt": n_new, "n_existing_per_arm": len(SEEDS_EXISTING),
           "n_unique_fingerprints": n_unique,
           "duplicate_within_new": int(n_new - n_unique),
           "collisions_with_existing": collisions,
           "bit_match": bool(not collisions and n_new == n_unique)}
    log(f"C7': {out}")
    return out


def calibration_c8(seq_gate, typ_gate, seed, active_dir, log):
    """gate バッチ 779 の同一 ckpt 2 回評価がビット一致するか。"""
    vals = []
    for _ in range(2):
        model, clean = load_arch("H_1024", seed, active_dir)
        Z1.fresh(model, clean)
        m, x = Z1.evaluate(model, seq_gate, typ_gate)
        vals.append((float(m["instr_valid"]), np.asarray(x["ce_seq"],
                                                         dtype=np.float64)))
    d_iv = abs(vals[0][0] - vals[1][0])
    d_ce = float(np.abs(vals[0][1] - vals[1][1]).max())
    out = {"seed": int(seed), "max_abs_iv": d_iv, "max_abs_ce_seq": d_ce,
           "bit_match": bool(d_iv < 1e-12 and d_ce < 1e-12)}
    log(f"C8: {out}")
    return out


def calibration_c9(log):
    """床ラベルの独立 2 実装一致＋発見標本 iv と z2_results.json の一致。"""
    z2d = np.load(os.path.join(HERE, "z2_delta.npz"), allow_pickle=True)
    a2 = [str(x) for x in z2d["arms"]]
    s2 = [int(x) for x in z2d["seeds"]]
    ih, iu = a2.index("H_1024"), a2.index("U_688")
    fh_a = z2d["iv"][ih] < TAU_IV
    fu_a = z2d["iv"][iu] < TAU_IV
    cells_a = [int((fh_a & fu_a).sum()), int((fh_a & ~fu_a).sum()),
               int((~fh_a & fu_a).sum()), int((~fh_a & ~fu_a).sum())]
    with open(os.path.join(HERE, "z2_results.json"), encoding="utf-8") as f:
        rows = json.load(f)["rows"]
    ivmap = {(r["arm"], int(r["seed"])): float(r["instr_valid"])
             for r in rows if r["arm"] in ARMS}
    max_iv_diff, fh_b, fu_b = 0.0, [], []
    for k, s in enumerate(s2):
        for arm, idx, dst in (("H_1024", ih, fh_b), ("U_688", iu, fu_b)):
            max_iv_diff = max(max_iv_diff,
                              abs(float(z2d["iv"][idx, k]) - ivmap[(arm, s)]))
            dst.append(ivmap[(arm, s)] < TAU_IV)
    fh_b, fu_b = np.array(fh_b), np.array(fu_b)
    cells_b = [int((fh_b & fu_b).sum()), int((fh_b & ~fu_b).sum()),
               int((~fh_b & fu_b).sum()), int((~fh_b & ~fu_b).sum())]
    with open(os.path.join(HERE, "_z3_power.json"), encoding="utf-8") as f:
        pc = json.load(f)["Z2_discovery"]["cells"]
    cells_c = [int(pc["both_floor"]), int(pc["H_only"]),
               int(pc["U_only"]), int(pc["neither"])]
    out = {"cells_npz": cells_a, "cells_rows_json": cells_b,
           "cells_power_json": cells_c,
           "max_abs_iv_npz_vs_rows": float(max_iv_diff),
           "two_impl_match": bool(cells_a == cells_b),
           "power_json_match": bool(cells_a == cells_c),
           "rows_match": bool(max_iv_diff < 1e-12)}
    log(f"C9: {out}")
    return out


# ---------------------------------------------------------------------------
# 正確二項の検出力（設計書 §3-2 / §6 規則 4、_z3_power.py と同じ定義）
# ---------------------------------------------------------------------------
_CCACHE = {}


def critical_c(m):
    if m < 1:
        return -1
    grid = np.arange(0, m // 2 + 1)
    cdf = stats.binom.cdf(grid, m, 0.5)
    ok = np.where(2 * cdf < ALPHA)[0]
    return int(grid[ok[-1]]) if len(ok) else -1


def power_mcnemar(n, p10, p01):
    q = p10 + p01
    if q <= 0:
        return 0.0
    pi = p10 / q
    pw = 0.0
    for m in range(n + 1):
        pm = float(stats.binom.pmf(m, n, q))
        if pm < 1e-13:
            continue
        if m not in _CCACHE:
            _CCACHE[m] = critical_c(m)
        c = _CCACHE[m]
        if c < 0:
            continue
        x = np.arange(m + 1)
        rej = (x <= c) | (x >= m - c)
        pw += pm * float(stats.binom.pmf(x[rej], m, pi).sum())
    return pw


def min_n_for_80(p10, p01, cap=400):
    for n in range(8, cap + 1):
        if power_mcnemar(n, p10, p01) >= 0.80:
            return n
    return None


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=list(SEEDS_CONFIRM))
    ap.add_argument("--train_seeds", nargs="+", type=int,
                    default=list(SEEDS_CONFIRM))
    ap.add_argument("--tag", default="z3")
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--n_eval", type=int, default=N_EVAL)
    ap.add_argument("--epochs", type=int, default=EPOCHS)
    ap.add_argument("--reuse", action="store_true")
    ap.add_argument("--train_only", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--no_repro", action="store_true")
    args = ap.parse_args()

    global ACTIVE_Z3DIR
    ACTIVE_Z3DIR = Z3SMOKEDIR if args.smoke else Z3DIR
    train_log = os.path.join(HERE, "z3_smoke_train.json") \
        if args.smoke else TRAIN_LOG
    if args.smoke:
        args.seeds = list(SEEDS_SMOKE)
        args.train_seeds = list(SEEDS_SMOKE)
        args.epochs = 1
    torch.set_num_threads(args.threads)
    torch.manual_seed(12345)
    os.makedirs(ACTIVE_Z3DIR, exist_ok=True)

    tag = args.tag
    LOG = os.path.join(HERE, f"{tag}_out_utf8.txt")
    if os.path.exists(LOG):
        os.remove(LOG)

    def log(msg):
        print(msg, flush=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")

    for s in args.seeds:
        assert s in SEEDS_ALL, f"未登録の評価 seed: {s}"
    for s in args.train_seeds:
        assert s in SEEDS_CONFIRM, f"未登録の訓練 seed: {s}"
    if not args.smoke:
        assert list(args.seeds) == list(SEEDS_CONFIRM), \
            "確認標本は seed 100..159 の 60 個で固定"
        assert args.epochs == EPOCHS and args.n_eval == N_EVAL
    log(f"Z3: threads={args.threads} arms={list(ALL_ARMS)} "
        f"eval_seeds={len(args.seeds)} train_seeds={len(args.train_seeds)} "
        f"n_eval={args.n_eval} epochs={args.epochs} reuse={args.reuse} "
        f"train_only={args.train_only} resume={args.resume} "
        f"smoke={args.smoke}")
    log(f"  固定値: TAU_IV={TAU_IV} TAU_LOSS={TAU_LOSS} TAU_CE={TAU_CE} "
        f"ALPHA={ALPHA} E_FLAG_CAP={E_FLAG_CAP} MIN_CONVERGED={MIN_CONVERGED} "
        f"gate={EVAL_SEED_GATE} main={EVAL_SEED} rob={EVAL_SEED_ROB}")

    # 評価バッチ（3 系統すべて独立の rng）
    seq, typ = Q2.make_trace_batch(np.random.default_rng(EVAL_SEED),
                                   args.n_eval, task="hard")
    seq_gate, typ_gate = Q2.make_trace_batch(
        np.random.default_rng(EVAL_SEED_GATE), args.n_eval, task="hard")
    seq_rob, typ_rob = Q2.make_trace_batch(
        np.random.default_rng(EVAL_SEED_ROB), args.n_eval, task="hard")
    log(f"eval batch: seq={seq.shape} gate={seq_gate.shape} "
        f"rob={seq_rob.shape} SPAN={Z1.SPAN}")

    # ---------------- 訓練＋訓練直後の gate 評価 ----------------
    by_key = {}
    if (args.resume or args.reuse) and os.path.exists(train_log):
        with open(train_log, encoding="utf-8") as f:
            for r in json.load(f).get("rows", []):
                by_key[(r["arch"], int(r["seed"]))] = r
        log(f"  [restore] {os.path.basename(train_log)} から "
            f"{len(by_key)} 走行を復元")

    def save_train():
        rows = [by_key[k] for k in sorted(by_key)]
        with open(train_log, "w", encoding="utf-8") as f:
            json.dump({"rows": rows, "args": vars(args)},
                      f, ensure_ascii=False, indent=2, default=float)

    for seed in args.train_seeds:
        for arch in ARMS:
            key = (arch, seed)
            path = ckpt_path(arch, seed, ACTIVE_Z3DIR)
            row = by_key.get(key)
            already = bool((args.resume or args.reuse) and row
                           and row.get("gate") and os.path.exists(path))
            if not already:
                row, _, _ = Z1.train_one(arch, seed, epochs=args.epochs,
                                         active_dir=ACTIVE_Z3DIR,
                                         save_path=path)
                row["gate"] = gate_eval(arch, seed, seq_gate, typ_gate,
                                        ACTIVE_Z3DIR)
                by_key[key] = row
                save_train()      # 1 走行ごとに保存（中断しても再開可能）
                log(f"  [train] {arch} s{seed} backend={row['backend']} "
                    f"loss[-1]={row['loss_hist'][-1]:.4f} {row['sec']}s | "
                    f"gate iv={row['gate']['iv_gate']:.4f} "
                    f"ce={row['gate']['ce_seq_gate']:.5f} "
                    f"finite={row['gate']['finite']}")
            else:
                log(f"  [skip] {arch} s{seed} ckpt/gate あり")

    train_rows = [by_key[k] for k in sorted(by_key)]
    if args.train_only:
        log(f"train_only 完了: {os.path.basename(train_log)} 累計 "
            f"{len(train_rows)} 走行")
        os._exit(0)

    if not args.smoke:
        need = {(a, s) for a in ARMS for s in SEEDS_CONFIRM}
        assert need.issubset(set(by_key)), \
            f"訓練行が不足: {len(need - set(by_key))} 件"
        for k in need:
            assert by_key[k].get("gate") is not None, f"gate 欠損: {k}"

    # ---------------- 校正（本番評価の前に全項目を確定） ----------------
    t0 = time.time()
    items, ok_base = Z1.calibration(seq, typ, ACTIVE_Z3DIR, tag, log,
                                    do_repro=not args.no_repro)
    extra = []
    c6 = Z2.calibration_c6(seq, typ, ACTIVE_Z3DIR, log)
    extra.append(_item("C6_y1_p2_bitmatch", "P2", -1, "max_abs",
                       0.0, max(c6["max_abs_ce_seq"], c6["max_abs_iv"]),
                       c6["bit_match"]))
    new_seeds = list(SEEDS_SMOKE) if args.smoke else list(SEEDS_CONFIRM)
    c7 = calibration_c7p(new_seeds, ACTIVE_Z3DIR, log)
    extra.append(_item("C7p_new_ckpt_uniqueness", "-", -1, "bit_match",
                       True, c7["bit_match"], c7["bit_match"]))
    c8 = calibration_c8(seq_gate, typ_gate, SEEDS_SMOKE[0]
                        if args.smoke else SEEDS_CONFIRM[0],
                        ACTIVE_Z3DIR, log)
    extra.append(_item("C8_gate_bit_repro_iv", "H_1024", -1, "max_abs",
                       0.0, c8["max_abs_iv"], c8["bit_match"]))
    extra.append(_item("C8_gate_bit_repro_ce", "H_1024", -1, "max_abs",
                       0.0, c8["max_abs_ce_seq"], c8["bit_match"]))
    c9 = calibration_c9(log)
    extra.append(_item("C9_floor_label_two_impl", "Z2", -1, "cell_diff",
                       0.0, float(max(abs(x - y) for x, y in
                                      zip(c9["cells_npz"],
                                          c9["cells_rows_json"]))),
                       c9["two_impl_match"]))
    extra.append(_item("C9_z2_iv_rows_vs_npz", "Z2", -1, "max_abs",
                       0.0, c9["max_abs_iv_npz_vs_rows"], c9["rows_match"]))
    extra.append(_item("C9_z2_cells_vs_powerjson", "Z2", -1, "cell_diff",
                       0.0, float(max(abs(x - y) for x, y in
                                      zip(c9["cells_npz"],
                                          c9["cells_power_json"]))),
                       c9["power_json_match"]))
    calib = items + extra
    ok_calib = bool(ok_base and all(x["bit_match"] for x in extra))
    with open(os.path.join(HERE, f"{tag}_calib.json"), "w",
              encoding="utf-8") as f:
        json.dump({"items": calib, "n": len(calib),
                   "all_bit_match": ok_calib,
                   "C6": c6, "C7p": c7, "C8": c8, "C9": c9},
                  f, ensure_ascii=False, indent=2, default=float)
    log(f"校正 総項目: {sum(1 for x in calib if x['bit_match'])}/"
        f"{len(calib)} all={ok_calib} ({time.time()-t0:.0f}s)")
    if not ok_calib:
        log("校正が落ちたので本番を走らせない。原因を調べること。")
        os._exit(1)

    # ---------------- 本番評価（主バッチ 777） ----------------
    na, ns = len(ALL_ARMS), len(args.seeds)
    aa = {a: i for i, a in enumerate(ALL_ARMS)}
    sa = {s: j for j, s in enumerate(args.seeds)}
    iv = np.full((na, ns), np.nan)
    ce_all = np.full((na, ns), np.nan)
    act_w = np.full((na, ns), np.nan)
    instr_seq = np.zeros((na, ns, args.n_eval), dtype=np.int8)
    ce_seq = np.zeros((na, ns, args.n_eval), dtype=np.float64)
    nparam_arr = np.zeros(na, dtype=np.int64)
    rows = []
    for arm in ALL_ARMS:
        base = arm[len("oracle_"):] if arm.startswith("oracle_") else arm
        for seed in args.seeds:
            model, clean = load_arch(base, seed, ACTIVE_Z3DIR)
            if arm.startswith("oracle_"):
                info = Z1.apply_oracle(model, clean)
            else:
                Z1.fresh(model, clean)
                info = {"n_zeroed": 0, "keys": []}
            m, x = Z1.evaluate(model, seq, typ)
            i, j = aa[arm], sa[seed]
            iv[i, j] = m["instr_valid"]
            ce_all[i, j] = m["ce_all"]
            act_w[i, j] = m["active_width"]
            instr_seq[i, j] = x["instr_seq"]
            ce_seq[i, j] = x["ce_seq"]
            nparam_arr[i] = int(sum(v.numel() for v in clean.values()))
            rows.append({"arm": arm, "arch": base, "seed": seed, **m,
                         "n_zeroed": info["n_zeroed"],
                         "nparam": int(nparam_arr[i]),
                         "ckpt": os.path.relpath(
                             ckpt_path(base, seed, ACTIVE_Z3DIR), HERE)})
            log(f"  {arm:<16s} s{seed:3d} iv={m['instr_valid']:.4f} "
                f"ce={m['ce_all']:.5f} actW={m['active_width']:.1f}")

    # ロバストネスバッチ 778（base 2 腕だけ）
    ra = {a: i for i, a in enumerate(ARMS)}
    ce_seq_rob = np.zeros((len(ARMS), ns, args.n_eval), dtype=np.float64)
    iv_rob = np.full((len(ARMS), ns), np.nan)
    for arm in ARMS:
        for seed in args.seeds:
            model, clean = load_arch(arm, seed, ACTIVE_Z3DIR)
            Z1.fresh(model, clean)
            m, x = Z1.evaluate(model, seq_rob, typ_rob)
            i, j = ra[arm], sa[seed]
            ce_seq_rob[i, j] = x["ce_seq"]
            iv_rob[i, j] = m["instr_valid"]

    # gate 配列（train_rows から復元）
    gate_by = {(r["arch"], int(r["seed"])): r for r in train_rows}
    iv_gate = np.full((len(ARMS), ns), np.nan)
    ce_gate = np.full((len(ARMS), ns), np.nan)
    loss_arr = np.full((len(ARMS), ns), np.nan)
    for i, arm in enumerate(ARMS):
        for j, seed in enumerate(args.seeds):
            r = gate_by.get((arm, seed))
            if r and r.get("gate"):
                iv_gate[i, j] = r["gate"]["iv_gate"]
                ce_gate[i, j] = r["gate"]["ce_seq_gate"]
                loss_arr[i, j] = r["loss_hist"][-1]

    H, U = aa["H_1024"], aa["U_688"]
    floor_h, floor_u = iv[H] < TAU_IV, iv[U] < TAU_IV

    # ---------------- 保存 ----------------
    with open(os.path.join(HERE, f"{tag}_results.json"), "w",
              encoding="utf-8") as f:
        json.dump({"rows": rows, "train_rows": train_rows,
                   "args": vars(args), "arms": list(ALL_ARMS),
                   "seeds": list(args.seeds),
                   "tau": {"iv": TAU_IV, "loss": TAU_LOSS, "ce": TAU_CE},
                   "eval_seeds": {"main": EVAL_SEED, "gate": EVAL_SEED_GATE,
                                  "rob": EVAL_SEED_ROB},
                   "e_flag_cap": E_FLAG_CAP},
                  f, ensure_ascii=False, indent=2, default=float)
    np.savez_compressed(
        os.path.join(HERE, f"{tag}_delta.npz"),
        arms=np.array(ALL_ARMS, dtype=object), seeds=np.array(args.seeds),
        iv=iv, ce_all=ce_all, active_width=act_w,
        instr_seq=instr_seq, ce_seq=ce_seq, nparam=nparam_arr,
        rob_arms=np.array(ARMS, dtype=object),
        ce_seq_rob=ce_seq_rob, iv_rob=iv_rob,
        gate_arms=np.array(ARMS, dtype=object),
        iv_gate=iv_gate, ce_seq_gate=ce_gate, loss=loss_arr,
        floor_h=floor_h, floor_u=floor_u)

    # ---------------- 主解析（確認的ファミリ m = 1） ----------------
    a = int((floor_h & floor_u).sum())
    b = int((floor_h & ~floor_u).sum())
    c = int((~floor_h & floor_u).sum())
    d = int((~floor_h & ~floor_u).sum())
    m_disc = b + c
    if m_disc > 0:
        bt = stats.binomtest(b, m_disc, 0.5)
        p_two = float(bt.pvalue)
        p_one = float(stats.binomtest(b, m_disc, 0.5,
                                      alternative="greater").pvalue)
        ci_pi = [float(v) for v in bt.proportion_ci(0.95, method="exact")]
        pi = b / m_disc
    else:
        p_two, p_one, pi = 1.0, 1.0, None
        ci_pi = [None, None]
    p10, p01 = b / ns, c / ns
    rd = p10 - p01
    sd_rd = math.sqrt((p10 + p01 - (p10 - p01) ** 2) / ns)
    rd_ci = [float(rd - 1.959963985 * sd_rd),
             float(rd + 1.959963985 * sd_rd)]
    q_obs, pi_obs = (b + c) / ns, (b / m_disc if m_disc else None)
    power_post = float(power_mcnemar(ns, p10, p01))
    min_n_post = min_n_for_80(p10, p01)
    m_exp = int(round(ns * q_obs))
    c_m = critical_c(m_exp)
    min_rd = float((m_exp - 2 * c_m) / ns) if c_m >= 0 else None

    primary = {
        "estimand": "floor-mode incidence (iv_main < 0.10)",
        "test": "McNemar exact conditional binomial, two-sided, alpha=0.05",
        "n": int(ns), "seeds": list(args.seeds),
        "cells": {"both_floor": a, "H_only": b, "U_only": c,
                  "neither": d},
        "p_H": float(floor_h.mean()), "p_U": float(floor_u.mean()),
        "n_floor_H": int(floor_h.sum()), "n_floor_U": int(floor_u.sum()),
        "discordant_m": m_disc, "pi": pi, "pi_exact95_ci": ci_pi,
        "risk_difference": float(rd), "rd_wald95_ci": rd_ci,
        "p_two_sided": p_two, "p_one_sided_reference": p_one,
        "p10": float(p10), "p01": float(p01), "q": float(q_obs),
        "power_posthoc": power_post, "min_n_for_80_posthoc": min_n_post,
        "min_detectable_rd": min_rd, "expected_discordant_m": m_exp,
        "critical_c": c_m,
        "claim_permitted_raw": bool(p_two < ALPHA),
    }

    # ---------------- ゲート G1〜G6 / C4 ----------------
    loss_flat = loss_arr.reshape(-1)
    loss_valid = loss_flat[np.isfinite(loss_flat)]
    n_conv = int((loss_valid < TAU_LOSS).sum())
    med_loss = float(np.median(loss_valid)) if loss_valid.size else None
    if args.smoke:
        # n = 2・1 epoch のドライランなので合否は経路確認のみ
        g1 = {"n": int(loss_valid.size), "median_last_loss": med_loss,
              "n_below_030": n_conv, "required": 0,
              "pass": bool(loss_valid.size > 0)}
    else:
        g1 = {"n": int(loss_valid.size), "median_last_loss": med_loss,
              "n_below_030": n_conv, "required": MIN_CONVERGED,
              "pass": bool(loss_valid.size >= 2 * len(SEEDS_CONFIRM)
                           and med_loss is not None
                           and med_loss < TAU_LOSS
                           and n_conv >= MIN_CONVERGED)}

    bad_gate = []
    for i, arm in enumerate(ARMS):
        for j, s in enumerate(args.seeds):
            g = gate_by.get((arm, s), {}).get("gate")
            if (not g or not g["finite"] or not g["in_range"]
                    or g["n_eval"] != args.n_eval):
                bad_gate.append(f"{arm}_s{s}")
    g2 = {"n_expected": len(ARMS) * ns, "n_bad": len(bad_gate),
          "bad": bad_gate, "pass": bool(not bad_gate)}

    cells_te = {arm: {"T+E+": 0, "T+E-": 0, "T-E+": 0, "T-E-": 0}
                for arm in ARMS}
    for i, arm in enumerate(ARMS):
        for j, s in enumerate(args.seeds):
            tplus = bool(np.isfinite(loss_arr[i, j]) and
                         loss_arr[i, j] < TAU_LOSS)
            eplus = bool(np.isfinite(iv_gate[i, j]) and
                         iv_gate[i, j] >= TAU_IV)
            cells_te[arm][("T+" if tplus else "T-") +
                          ("E+" if eplus else "E-")] += 1
    g3 = {"cells": cells_te, "n_excluded_from_primary": 0, "pass": True}

    ce_main_mean = ce_seq[[H, U]].mean(axis=2)     # (2, ns)
    eflag = (ce_main_mean > TAU_CE) | (ce_gate > TAU_CE)
    eflag_h = [int(s) for s, f in zip(args.seeds, eflag[0]) if f]
    eflag_u = [int(s) for s, f in zip(args.seeds, eflag[1]) if f]
    g4 = {"H": eflag_h, "U": eflag_u,
          "n_H": len(eflag_h), "n_U": len(eflag_u),
          "cap": E_FLAG_CAP,
          "pass": bool(len(eflag_h) <= E_FLAG_CAP and
                       len(eflag_u) <= E_FLAG_CAP)}

    g5 = {}
    for arm in ARMS:
        o = aa[f"oracle_{arm}"]
        dd = (ce_seq[o] - ce_seq[aa[arm]]).mean(axis=1)
        g5[arm] = {"min_delta_ce_seq": float(dd.min()),
                   "mean_delta_ce_seq": float(dd.mean()),
                   "n_below_030": int((dd < 0.30).sum()),
                   "pass": bool(dd.min() >= 0.30)}
    g6 = {"Tplus_Eminus": {arm: cells_te[arm]["T+E-"] for arm in ARMS},
          "pass": True}

    hw, uw = float(act_w[H].mean()), float(act_w[U].mean())
    c4 = {"H_1024": hw, "U_688": uw,
          "rel_diff": abs(hw - uw) / max(1e-12, 0.5 * (hw + uw)),
          "pass": bool(abs(hw - uw) / max(1e-12, 0.5 * (hw + uw)) <= 0.10)}

    hard_ok = bool(g1["pass"] and g2["pass"] and g4["pass"] and
                   all(v["pass"] for v in g5.values()) and c4["pass"]
                   and ok_calib)
    if not hard_ok:
        case = "C"
    elif p_two < ALPHA:
        case = "A"
    else:
        case = "B"

    # ---------------- 探索的（主判定に使わない） ----------------
    dseq = ce_seq[H] - ce_seq[U]
    d_ce = dseq.mean(axis=1)
    d_iv = iv[H] - iv[U]
    exploratory = {
        "ce_seq_paired": Z1.paired(d_ce),
        "iv_paired": Z1.paired(d_iv),
        "ce_seq_floor_excluded": None,
        "pooled_n120_ce_seq": None,
        "robustness_seed778": None,
        "eflag_excluded_cells": None,
        "gate_main_label_disagreement": None,
        "z1_24seed_floor_rate": None,
    }
    mask = (~floor_h) & (~floor_u)
    if int(mask.sum()) >= 2:
        exploratory["ce_seq_floor_excluded"] = Z1.paired(d_ce[mask])
    old = []
    for fn in ("z1_delta.npz", "z2_delta.npz"):
        z = np.load(os.path.join(HERE, fn), allow_pickle=True)
        ar = [str(x) for x in z["arms"]]
        old.append((z["ce_seq"][ar.index("H_1024")] -
                    z["ce_seq"][ar.index("U_688")]).mean(axis=1))
    exploratory["pooled_n120_ce_seq"] = Z1.paired(
        np.concatenate([old[0], old[1], d_ce]))
    d_rob = (ce_seq_rob[ra["H_1024"]] -
             ce_seq_rob[ra["U_688"]]).mean(axis=1)
    exploratory["robustness_seed778"] = Z1.paired(d_rob)
    keep = ~(eflag[0] | eflag[1])
    if int(keep.sum()) >= 2:
        bh = int((floor_h[keep] & ~floor_u[keep]).sum())
        ch = int((~floor_h[keep] & floor_u[keep]).sum())
        exploratory["eflag_excluded_cells"] = {
            "n": int(keep.sum()), "b": bh, "c": ch,
            "p_two_sided": float(stats.binomtest(bh, bh + ch, 0.5).pvalue)
            if bh + ch > 0 else None}
    disagree = {}
    for i, arm in enumerate(ARMS):
        gh = iv_gate[i] < TAU_IV
        mh = floor_h if i == 0 else floor_u
        disagree[arm] = int((gh != mh).sum())
    exploratory["gate_main_label_disagreement"] = disagree
    with open(os.path.join(HERE, "_z3_power.json"), encoding="utf-8") as f:
        z1r = json.load(f)["Z1_exploratory_only"]
    exploratory["z1_24seed_floor_rate"] = {
        "rates": z1r["rates"], "cells": z1r["cells"],
        "p_two_sided": z1r["mcnemar_exact_two_sided_p"]}

    baseline = {arm: {"iv": float(iv[aa[arm]].mean()),
                      "ce_all": float(ce_all[aa[arm]].mean()),
                      "active_width": float(act_w[aa[arm]].mean()),
                      "nparam": int(nparam_arr[aa[arm]])}
                for arm in ARMS}
    analysis = {
        "calibration": {"n": len(calib), "all_bit_match": bool(ok_calib),
                        "C6": c6, "C7p": c7, "C8": c8, "C9": c9},
        "primary": primary,
        "exploratory": exploratory,
        "gates": {"G1_train_convergence": g1,
                  "G2_gate_finiteness": g2,
                  "G3_TxE_classification": g3,
                  "G4_E_flag": g4,
                  "G5_oracle_sensitivity": g5,
                  "G6_Tplus_Eminus": g6},
        "C4_active_width": c4,
        "baseline": baseline,
        "verdict": {"case": case, "p_two_sided": p_two,
                    "p_reject": bool(p_two < ALPHA),
                    "hard_gates_ok": hard_ok,
                    "calibration_ok": bool(ok_calib),
                    "claim_permitted": bool(case == "A"),
                    "z1_rule3_still_forbidden": True},
        "meta": {"threads": args.threads, "n_eval": args.n_eval,
                 "eval_seed": EVAL_SEED, "eval_seed_gate": EVAL_SEED_GATE,
                 "eval_seed_rob": EVAL_SEED_ROB, "epochs": args.epochs,
                 "seqs": Z1.SEQS, "bs": Z1.BS, "lr": Z1.LR,
                 "auxw": Z1.AUXW, "seeds": list(args.seeds),
                 "arms": list(ALL_ARMS), "n_rows": len(rows),
                 "n_train": len(train_rows), "smoke": args.smoke,
                 "tau_iv": TAU_IV, "tau_loss": TAU_LOSS, "tau_ce": TAU_CE,
                 "alpha": ALPHA, "e_flag_cap": E_FLAG_CAP},
    }
    with open(os.path.join(HERE, f"{tag}_analysis.json"), "w",
              encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2, default=float)

    log("")
    log(f"== 主解析 n={ns}: 2x2 (both,H,U,neither)=({a},{b},{c},{d}) "
        f"m={m_disc} p_two={p_two:.7g} p_one={p_one:.7g}")
    log(f"== p_H={primary['p_H']:.6f} p_U={primary['p_U']:.6f} "
        f"RD={rd:+.6f} Wald95={rd_ci} pi={pi} exact95={ci_pi}")
    log(f"== posthoc power={power_post:.4f} min_n80={min_n_post} "
        f"min_RD={min_rd} (m_exp={m_exp}, c_m={c_m})")
    log(f"== gates G1={g1['pass']} G2={g2['pass']} G4={g4['pass']} "
        f"G5={ {k: v['pass'] for k, v in g5.items()} } C4={c4['pass']}")
    log(f"== T+E- {g6['Tplus_Eminus']} / E flag H={g4['n_H']} U={g4['n_U']}")
    log(f"== case={case} verdict={analysis['verdict']}")
    log(f"saved: {tag}_results.json / {tag}_delta.npz / "
        f"{tag}_analysis.json / {tag}_calib.json")
    os._exit(0)


if __name__ == "__main__":
    main()
