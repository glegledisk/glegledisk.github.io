# -*- coding: utf-8 -*-
"""e7_routing_7seed.py — E7 で free / sidecar を 60 epoch・7 seed で測定（本実験）

目的:
  E6（ランダム 4096 エントリ表, アンカー 25%）では free が全 FFN 固定を Pareto 支配した
  （CE 0.0392 < 0.0712、FFN 21%、7/7 seed、crossover λ* = −0.040）。
  しかし E6 の「易しい（コピー・依存 75%）／難しい（表参照 25%）」は明確なカテゴリ分離だった。

  E7 は分離を弱めた課題: **全位置が π(src[i], src[i-1]) を参照し、頻度だけが違う**
  （ff 56%: よくサンプルされる／fr 37%／rr 6%: ほとんど訓練に現れない）。
  ここで free がまだ全 FFN を上回るか。

  - 上回る → E6 の結論は易難分離の強さに依存しない（実モデルへ外挿可能）
  - 上回らない → E6 の結果は「明確な易難分離」に依存する（重要的な否定的結論）

構成: L=16, A=64, w_freq=0.75, freq_vals=range(16), d=64, epochs=60, λ=0.15
      4 アーム × 7 seed（不足分のみ実行・逐次保存・再開可能）
      表 π は固定シード 12345（E6 と同一）
"""
import os, json, time
import numpy as np
import pandas as pd
import torch
from e7_weaksep_task import run, make_lookup_table, ROLE_NAME

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)), d=64, epochs=60)
ARMS = ["frozen_ffn", "frozen_identity", "free", "sidecar"]
SEEDS = list(range(7))
OUT = os.path.join(HERE, "e7_routing_7seed.csv")
LAMS = [0.03, 0.05, 0.08, 0.15, 0.30]
DEV = "cuda" if torch.cuda.is_available() else "cpu"
tab = make_lookup_table(64)

rows = []
if os.path.exists(OUT):
    rows = pd.read_csv(OUT).to_dict("records")
have = {(r["arm"], int(r["seed"])) for r in rows}
print(f"device: {DEV}  既存 {len(have)} 件")

todo = [(a, s) for a in ARMS for s in SEEDS if (a, s) not in have]
print(f"追加実行 {len(todo)} 件")

t0 = time.time()
for i, (arm, s) in enumerate(todo, 1):
    r = run(arm, s, table=tab, device=DEV, **CFG)
    r["arm"] = arm
    rows.append(r)
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"  [{i}/{len(todo)}] {arm:16s} s{s} | CE {r['ce_all']:.4f} | FFN {r['ffn_cost']:.3f} "
          f"| acc {r['acc_all']:.4f} (ff {r['acc_ff']:.3f} / fr {r['acc_fr']:.3f} / rr {r['acc_rr']:.3f}) "
          f"| {time.time()-t0:.0f}s", flush=True)

df = pd.DataFrame(rows)
df["obj015"] = df["ce_all"] + 0.15 * df["ffn_cost"]
df = df.sort_values(["arm", "seed"]).reset_index(drop=True)
df.to_csv(OUT, index=False)

print("\n=== E7 ルーティング比較（60 epoch・7 seed, d=64, 全位置ルックアップ＋頻度スキュー） ===")
print(f"{'arm':16s} {'CE':>16s} {'FFN':>14s} {'obj(λ=.15)':>16s} {'acc':>16s} "
      + " ".join(f"{'acc '+nm:>10s}" for nm in ROLE_NAME.values()))
for a in ARMS:
    d = df[df.arm == a]
    print(f"{a:16s} {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f}  "
          f"{d['obj015'].mean():.4f}±{d['obj015'].std():.4f}  "
          f"{d['acc_all'].mean():.4f}±{d['acc_all'].std():.4f}  "
          + " ".join(f"{d['acc_'+nm].mean():10.4f}" for nm in ROLE_NAME.values()))

# CE の役割別分解（どのグループがロスを生んでいるか）
print("\n=== CE の役割別分解（n_role × ce_role の総和 = ce_all） ===")
print(f"{'arm':16s} " + " ".join(f"{nm+' ('+str(round(100*df[df.arm=='frozen_ffn']['n_'+nm].mean(),1))+'%)':>18s}" for nm in ROLE_NAME.values()))
for a in ARMS:
    d = df[df.arm == a]
    contrib = {nm: float((d[f"n_{nm}"] * d[f"ce_{nm}"]).mean()) for nm in ROLE_NAME.values()}
    print(f"{a:16s} " + " ".join(f"{contrib[nm]:8.3f} ({100*contrib[nm]/float(d['ce_all'].mean()):4.0f}%)" for nm in ROLE_NAME.values()))

piv = df.pivot_table(index="seed", columns="arm", values=["ce_all", "ffn_cost", "obj015", "acc_all"])

print("\n=== seed 対応検定（各アーム − frozen_ffn、7 seeds） ===")
res = {}
for a in ["free", "sidecar"]:
    line = f" {a:8s}"
    for k in ("obj015", "ce_all", "ffn_cost", "acc_all"):
        d = (piv[k][a] - piv[k]["frozen_ffn"]).dropna()
        m, sd = d.mean(), d.std(ddof=1)
        t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
        rng = np.random.default_rng(0)
        boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(20000)])
        lo, hi = np.percentile(boot, [2.5, 97.5])
        wins = int((d < 0).sum()) if k != "acc_all" else int((d > 0).sum())
        res[f"{a}_{k}"] = {"mean": float(m), "sd": float(sd), "t": float(t),
                           "ci": [float(lo), float(hi)], "wins": wins, "n": int(len(d))}
        line += f" | {k} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {wins}/{len(d)}"
    print(line)

# 役割別の paired 差（free/sidecar − frozen_ffn）: どこで品質を失い/得るか
print("\n=== 役割別 seed 対応差（各アーム − frozen_ffn の CE） ===")
role_res = {}
for a in ["free", "sidecar"]:
    for nm in ROLE_NAME.values():
        p2 = df.pivot_table(index="seed", columns="arm", values=f"ce_{nm}")
        d = (p2[a] - p2["frozen_ffn"]).dropna()
        m, sd = d.mean(), d.std(ddof=1)
        t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
        rng = np.random.default_rng(1)
        boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(20000)])
        lo, hi = np.percentile(boot, [2.5, 97.5])
        role_res[f"{a}_ce_{nm}"] = {"mean": float(m), "sd": float(sd), "t": float(t),
                                    "ci": [float(lo), float(hi)], "n": int(len(d))}
        print(f" {a:8s} ce_{nm:3s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f}")

# ルータのグループ判別（恒等パスへ逃がした割合）
print("\n=== ルータの役割別 id_rate（恒等パスを選んだ割合。大きい＝恒等へ逃がした） ===")
print(f"{'arm':16s} " + " ".join(f"{'id '+nm:>10s}" for nm in ROLE_NAME.values()))
route_res = {}
for a in ["free", "sidecar"]:
    d = df[df.arm == a]
    line = f"{a:16s} " + " ".join(f"{d['id_rate_'+nm].mean():10.3f}" for nm in ROLE_NAME.values())
    print(line)
    route_res[a] = {nm: float(d['id_rate_'+nm].mean()) for nm in ROLE_NAME.values()}
# 判別の有無（ff vs rr の差を seed 対応で検定）
for a in ["free", "sidecar"]:
    d = df[df.arm == a].set_index("seed")
    diff = (d["id_rate_rr"] - d["id_rate_ff"]).dropna()
    m, sd = diff.mean(), diff.std(ddof=1)
    t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
    print(f"  {a}: id_rate_rr − id_rate_ff = {m:+.3f} ± {sd:.3f} (t={t:+.2f}) "
          f"→ {'rr を恒等へ逃がしている（判別あり）' if m > 0.05 and t > 2 else '明確な判別はなし'}")

# FFN の寄与を役割別に（frozen_identity − frozen_ffn）
print("\n=== FFN の寄与（役割別, frozen_identity − frozen_ffn の CE 差） ===")
ffn_role = {}
for nm in ROLE_NAME.values():
    p2 = df.pivot_table(index="seed", columns="arm", values=f"ce_{nm}")
    d = (p2["frozen_identity"] - p2["frozen_ffn"]).dropna()
    ffn_role[nm] = float(d.mean())
    print(f" {nm}: ΔCE = {d.mean():+.4f}  (CE_ffn {df[df.arm=='frozen_ffn'][f'ce_{nm}'].mean():.3f} "
          f"/ CE_identity {df[df.arm=='frozen_identity'][f'ce_{nm}'].mean():.3f})")

print("\n=== λ 感度 ===")
print(f"{'λ':>5s} " + "".join(f"{a:>15s}" for a in ARMS) + "   最良")
lam_tab = {}
for lam in LAMS:
    vals = {a: df[df.arm == a]["ce_all"].mean() + lam * df[df.arm == a]["ffn_cost"].mean() for a in ARMS}
    best = min(vals, key=vals.get)
    lam_tab[str(lam)] = {"vals": {k: float(v) for k, v in vals.items()}, "best": best}
    print(f"{lam:5.2f} " + "".join(f"{vals[a]:15.4f}" for a in ARMS) + f"   {best}")

ce_f = df[df.arm == "frozen_ffn"]["ce_all"].mean()
for a in ["free", "sidecar"]:
    ce_r = df[df.arm == a]["ce_all"].mean(); ff_r = df[df.arm == a]["ffn_cost"].mean()
    if ff_r < 1.0:
        print(f"\n {a} vs 全FFN の crossover λ* = {(ce_r - ce_f)/(1.0 - ff_r):.4f}")
        if ce_r < ce_f:
            print("   → λ* < 0: λ=0（品質のみ）でも勝つ＝Pareto 改善")
        else:
            print("   → λ* > 0: 品質は落ちる。計算量と品質の trade-off が復活")

print("\n=== seed 別（free / sidecar） ===")
for a in ["free", "sidecar"]:
    d = df[df.arm == a]
    print(f" {a:8s} CE  " + " ".join(f"{x:.3f}" for x in d["ce_all"]))
    print(f" {'':8s} FFN " + " ".join(f"{x:.3f}" for x in d["ffn_cost"]))
    print(f" {'':8s} obj " + " ".join(f"{x:.3f}" for x in d["obj015"]))
    print(f" {'':8s} idRR" + " ".join(f"{x:.3f}" for x in d["id_rate_rr"]))

json.dump({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in CFG.items()},
           "device": DEV,
           "summary": {a: {k: float(df[df.arm == a][k].mean()) for k in
                           ["ce_all", "ffn_cost", "obj015", "acc_all", "acc_ff", "acc_fr", "acc_rr",
                            "ce_ff", "ce_fr", "ce_rr", "id_rate_ff", "id_rate_fr", "id_rate_rr"]}
                       for a in ARMS},
           "paired_vs_ffn": res, "role_paired_vs_ffn": role_res, "router_id_rates": route_res,
           "ffn_contribution_by_role": ffn_role, "lambda_sensitivity": lam_tab, "raw": rows},
          open(os.path.join(HERE, "e7_routing_7seed.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e7_routing_7seed.csv / .json")
