"""P3 の図: (a) 品質 vs k、(b) 難易度四分位ごとの ΔCE、(c) 層の用量反応。"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "Noto Sans JP", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))
s = json.load(open(os.path.join(HERE, "p3_topk_summary.json"), encoding="utf-8"))
z = np.load(os.path.join(HERE, "p3_topk_nll.npz"))
base = z["k8"]

ks = [8, 7, 6, 4, 2, 1]
ce = [s["results"][str(k)]["ce"] for k in ks]
ppl = [s["results"][str(k)]["ppl"] for k in ks]
dce = [0.0] + [s["results"][str(k)]["delta_ce"]["mean"] for k in ks[1:]]
dse = [0.0] + [s["results"][str(k)]["delta_ce"]["se"] for k in ks[1:]]

fig = plt.figure(figsize=(13.5, 4.2))

# (a) PPL vs k
ax = fig.add_subplot(1, 3, 1)
ax.plot(ks, ppl, "o-", color="#c0392b", lw=2, ms=7)
ax.set_yscale("log")
ax.set_xlabel("top-k (experts per token)")
ax.set_ylabel("perplexity (log)")
ax.set_title("(a) 品質は k=6 と k=4 の間で崩れる", fontsize=11)
for k, p in zip(ks, ppl):
    ax.annotate("%.1f" % p, (k, p), textcoords="offset points", xytext=(0, 8),
                ha="center", fontsize=8)
ax.axvspan(4, 6, color="#f1c40f", alpha=0.15)
ax.set_xticks(ks)
ax.invert_xaxis()
ax.grid(alpha=0.3)
ax.set_ylim(8, 2000)
ax.text(5, 30, "cliff", ha="center", fontsize=9, color="#b7950b")

# (b) ΔCE vs k（誤差棒つき）
ax = fig.add_subplot(1, 3, 2)
ax.errorbar(ks[1:], dce[1:], yerr=[1.96 * e for e in dse[1:]], fmt="o-",
            color="#2c3e50", lw=2, ms=7, capsize=4)
ax.set_xlabel("top-k")
ax.set_ylabel(r"$\Delta$CE vs k=8  (nats/token)")
ax.set_title("(b) 削減コスト（95% CI）", fontsize=11)
ax.set_yscale("symlog", linthresh=0.01)
ax.axhline(0, color="gray", lw=0.8)
ax.set_xticks(ks[1:])
ax.invert_xaxis()
ax.grid(alpha=0.3, which="both")
for k, d in zip(ks[1:], dce[1:]):
    ax.annotate("%+.3f" % d, (k, d), textcoords="offset points", xytext=(0, 10),
                ha="center", fontsize=8)

# (c) 難易度四分位 × k
ax = fig.add_subplot(1, 3, 3)
edges = np.percentile(base, [25, 50, 75])
grp = np.digitize(base, edges)
labels = ["Q1\n(易)", "Q2", "Q3", "Q4\n(難)"]
w = 0.26
colors = ["#95a5a6", "#e67e22", "#c0392b"]
for j, (k, c) in enumerate(zip([7, 6, 4], colors)):
    d = z["k%d" % k] - base
    vals = [d[grp == i].mean() for i in range(4)]
    ax.bar(np.arange(4) + (j - 1) * w, vals, w, label="k=%d" % k, color=c)
ax.set_xticks(np.arange(4))
ax.set_xticklabels(labels, fontsize=9)
ax.set_ylabel(r"$\Delta$CE (nats/token)")
ax.set_title("(c) コストは難しいトークンに集中", fontsize=11)
ax.legend(fontsize=8)
ax.grid(alpha=0.3, axis="y")

fig.tight_layout()
out = os.path.join(HERE, "p3_topk_quality.png")
fig.savefig(out, dpi=140)
print("saved", out)

# (d) 層の用量反応（別図）
fig2, ax2 = plt.subplots(figsize=(5.2, 3.8))
xs = [0, 8, 16]
ys = [0.0, 0.01374, 0.01449]
ax2.plot([0, 8], [0.0, 0.00517], "o--", color="#2980b9", label="前半 8 層 (0-7)")
ax2.plot([0, 8], [0.0, 0.00857], "o--", color="#8e44ad", label="後半 8 層 (8-15)")
ax2.plot(xs, ys, "o-", color="#c0392b", lw=2.2, ms=8, label="実測 (全 16 層)")
ax2.plot([8, 16], [0.01374, 0.01449], "s", color="#c0392b", ms=6)
ax2.annotate("和 = +0.01374\n実測 = +0.01449\n交互作用 t=0.64 (n.s.)",
             (0.97, 0.06), xycoords="axes fraction", fontsize=8.5, ha="right", va="bottom",
             bbox=dict(boxstyle="round", fc="#fdf2e9", ec="#e67e22"))
ax2.set_xlabel("top-7 を適用した層数")
ax2.set_ylabel(r"$\Delta$CE (nats/token)")
ax2.set_title("(d) 層の効果は加法的", fontsize=11)
ax2.set_xticks([0, 8, 16])
ax2.set_ylim(-0.0012, 0.0175)
ax2.legend(fontsize=8, loc="upper left")
ax2.grid(alpha=0.3)
fig2.tight_layout()
out2 = os.path.join(HERE, "p3_layer_additivity.png")
fig2.savefig(out2, dpi=140)
print("saved", out2)
