# -*- coding: utf-8 -*-
"""e7_wb_paired13.py — 全アーム 13 seed の paired 検定"""
import numpy as np
import pandas as pd

new = pd.read_csv("e7_staged_7seed.csv")
new["obj015"] = new["ce_all"] + 0.15 * new["ffn_cost"]
e7 = pd.read_csv("e7_routing_7seed.csv")
e7["obj015"] = e7["ce_all"] + 0.15 * e7["ffn_cost"]
dz = pd.read_csv("e7_deadzone_7seed.csv")
dz["obj015"] = dz["ce_all"] + 0.15 * dz["ffn_cost"]
KEEP = ["variant", "seed", "ce_all", "ffn_cost", "obj015", "acc_all", "acc_ff", "acc_fr",
        "acc_rr", "ce_ff", "ce_fr", "ce_rr", "id_rate_ff", "id_rate_fr", "id_rate_rr"]


def merge(old_df, mask, new_name):
    o = old_df[mask].rename(columns={"arm": "variant"})
    o = o[o["seed"] <= 6][KEEP]
    n = new[(new.variant == new_name) & (new.seed >= 7)][KEEP]
    return pd.concat([o, n], ignore_index=True).set_index("seed")


ffn = merge(e7, e7.arm == "frozen_ffn", "frozen_ffn")
b10 = merge(dz, dz.variant == "bias10", "bias10")


def get(a):
    if a == "frozen_ffn":
        return ffn
    if a == "bias10":
        return b10
    return new[new.variant == a].set_index("seed")


def paired(dn, db, key):
    d = (dn[key] - db[key]).dropna()
    m, sd = d.mean(), d.std(ddof=1)
    t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
    rng = np.random.default_rng(0)
    boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(20000)])
    lo, hi = np.percentile(boot, [2.5, 97.5])
    return m, lo, hi, t, int((d < 0).sum()), len(d)


for v in ["sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]:
    print(f"=== {v} (n={len(get(v))}) ===")
    for bn in ["frozen_ffn", "bias10"]:
        for k in ("obj015", "ce_all", "ffn_cost"):
            m, lo, hi, t, w, n = paired(get(v), get(bn), k)
            print(f"  vs {bn:10s} {k:9s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {w}/{n}")

print("\n=== 中央値と外れ値を除いた平均（CE>0.35 の seed を除外） ===")
for a in ["frozen_ffn", "bias10", "sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]:
    d = get(a)
    d2 = d[d["ce_all"] <= 0.35]
    print(f" {a:12s} 全 {len(d):2d} seed: CE {d['ce_all'].mean():.4f} obj {d['obj015'].mean():.4f} FFN {d['ffn_cost'].mean():.3f}"
          f"  | 外れ値除外 {len(d2):2d}: CE {d2['ce_all'].mean():.4f} obj {d2['obj015'].mean():.4f} FFN {d2['ffn_cost'].mean():.3f}")

print("\n=== 壊滅的 seed の一覧（CE > 0.35） ===")
for a in ["frozen_ffn", "bias10", "sp_wb2_w10", "sp_wb3_w10", "sp_wb4_w10"]:
    d = get(a)
    bad = d[d["ce_all"] > 0.35]
    print(f" {a:12s} " + ", ".join(f"s{int(s)}: CE {r['ce_all']:.3f} (idff {r['id_rate_ff']:.2f})"
                                   for s, r in bad.iterrows()) if len(bad) else f" {a:12s} なし")
