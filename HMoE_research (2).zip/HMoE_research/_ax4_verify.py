# -*- coding: utf-8 -*-
"""AX4 Step 4: 独立再計算（ax4_sentence_bound.py を import しない別経路）。

scipy.stats.ttest_rel 経路で Δ・se・t・p・Holm・MDE・上位 1% 寄与率を作り直し、
npz の生配列から文 ID・決定・mean_k・校正・粒度カーブを再構築して
ax4_sentence_bound.json と突合する。使い方: python _ax4_verify.py [tag]
"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats as scistats

HERE = os.path.dirname(os.path.abspath(__file__))
TAG = sys.argv[1] if len(sys.argv) > 1 else "ax4"
ALPHA = 0.05
N_LAYERS = 16
LAM = 10.0
PERM_SEED = 4400
NPERM = 100
MIN_SENT = 8
BOUND_PERIOD = (2, 15, 32, 4340)
BOUND_NL = (2, 15, 32, 187, 4340)
RAND_SEED = 1201

ITEMS, MISMATCH = [], []


def chk(name, got, exp, rtol=1e-6, atol=1e-9):
    ITEMS.append(name)
    ok = False
    if isinstance(exp, (list, tuple)):
        ok = (list(got) == list(exp))
    elif isinstance(exp, bool) or isinstance(exp, str):
        ok = (got == exp)
    elif isinstance(exp, (int, np.integer)) and isinstance(got, (int, np.integer)):
        ok = (int(got) == int(exp))
    else:
        try:
            ok = math.isclose(float(got), float(exp), rel_tol=rtol, abs_tol=atol)
        except Exception:
            ok = False
    if not ok:
        MISMATCH.append((name, got, exp))


def rst(d, tok_per_win=255):
    d = np.asarray(d, dtype=np.float64).ravel()
    n = d.size
    m = float(d.mean())
    t, p = scistats.ttest_rel(d, np.zeros_like(d))
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    tc975 = float(scistats.t.ppf(0.975, n - 1))
    tc95 = float(scistats.t.ppf(0.95, n - 1))
    wm = d.reshape(-1, tok_per_win).mean(axis=1)
    sew = float(wm.std(ddof=1) / math.sqrt(wm.size))
    srt = np.sort(np.abs(d))[::-1]
    k1 = max(1, int(math.ceil(0.01 * n)))
    return {"mean": m, "sd": sd, "se": se, "t": float(t), "p_two": float(p),
            "mde": tc975 * se, "ci95": [m - tc975 * se, m + tc975 * se],
            "ci90": [m - tc95 * se, m + tc95 * se],
            "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
            "median": float(np.median(d)), "se_win": sew,
            "top1_abs_share": float(srt[:k1].sum() / srt.sum())}


def holm_adj(pvals):
    ids = sorted(pvals, key=lambda k: pvals[k])
    out, run = {}, 0.0
    for i, k in enumerate(ids):
        run = max(run, (len(ids) - i) * pvals[k])
        out[k] = min(1.0, run)
    return out


def spearman(a, b):
    ra = np.argsort(np.argsort(a)).astype(np.float64)
    rb = np.argsort(np.argsort(b)).astype(np.float64)
    ra -= ra.mean()
    rb -= rb.mean()
    den = np.sqrt((ra ** 2).sum() * (rb ** 2).sum())
    return float((ra * rb).sum() / den) if den > 0 else float("nan")


def build_sent(ids, bset, n_win, ln, minlen=MIN_SENT):
    """文 ID の独立再構築。"""
    out, sid, lens, merged = np.zeros(len(ids), dtype=np.int32), 0, [], 0
    for w in range(n_win):
        seg = ids[w * ln:(w + 1) * ln]
        ends = np.where(np.isin(seg, list(bset)))[0]
        cuts, start = [], 0
        for e in ends:
            if e + 1 - start >= minlen:
                cuts.append([start, e + 1])
                start = e + 1
        if start < ln:
            if cuts:
                cuts[-1][1] = ln
                merged += 1
            else:
                cuts.append([0, ln])
        for a, b in cuts:
            out[w * ln + a:w * ln + b] = sid
            lens.append(b - a)
            sid += 1
    return out, np.array(lens), merged


def sent_tok(sent, n_win, n_eval):
    return np.concatenate([sent[w * 256:w * 256 + n_eval] for w in range(n_win)])


def group_local(sid, k, nw, n_eval):
    out, off = np.zeros_like(sid), 0
    for w in range(nw):
        sl = slice(w * n_eval, (w + 1) * n_eval)
        sw = sid[sl]
        out[sl] = off + (sw - sw.min()) // k
        off = int(out[sl].max()) + 1
    return out


def unit_targets(c8, c7, sid, n_unit):
    cnt = np.bincount(sid, minlength=n_unit).astype(np.float64)
    a = np.stack([np.bincount(sid, weights=c8[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    b = np.stack([np.bincount(sid, weights=c7[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    return np.concatenate([a, b], axis=1)


def unit_decision(Y):
    cut = np.argmin(Y[:, N_LAYERS:], axis=1).astype(np.int8)
    Q = Y[:, :N_LAYERS].copy()
    Q[np.arange(Y.shape[0]), cut] = -np.inf
    prot = np.argmax(Q, axis=1).astype(np.int8)
    return cut, prot


def ridge_loo(W, Y, lam=LAM):
    n = W.shape[0]
    pred = np.zeros_like(Y, dtype=np.float64)
    for f in range(n):
        tr = np.arange(n) != f
        Xtr, Xte = W[tr], W[f:f + 1]
        mu, sd = Xtr.mean(0), Xtr.std(0) + 1e-8
        A, B = (Xtr - mu) / sd, (Xte - mu) / sd
        ym = Y[tr].mean(0)
        d = A.shape[1]
        if d <= A.shape[0]:
            w = np.linalg.solve(A.T @ A + lam * np.eye(d), A.T @ (Y[tr] - ym))
        else:
            a = np.linalg.solve(A @ A.T + lam * np.eye(A.shape[0]), Y[tr] - ym)
            w = A.T @ a
        pred[f] = (B @ w + ym)[0]
    return pred


def mean_k(sid, cut, prot, n_tok, nw, n_eval, ln):
    km = np.full((N_LAYERS, n_tok), 7, dtype=np.int8)
    for u in range(len(cut)):
        sel = (sid == u)
        km[cut[u], sel] = 6
        km[prot[u], sel] = 8
    km = km.reshape(N_LAYERS, nw, n_eval)
    km = np.concatenate([km, np.full((N_LAYERS, nw, 1), 7, dtype=np.int8)], axis=2)
    return float(km.mean())


def main():
    z = np.load(os.path.join(HERE, "%s_sentence_bound.npz" % TAG))
    with open(os.path.join(HERE, "%s_sentence_bound.json" % TAG), encoding="utf-8") as fp:
        J = json.load(fp)
    n_tok = J["meta"]["n_tok"]
    nw = J["meta"]["windows"]
    n_eval = n_tok // nw
    ln = J["meta"]["len"]
    n_win = nw // 2
    arms = [k[4:] for k in z.files if k.startswith("nll_")]
    N = {a: z["nll_" + a].astype(np.float64) for a in arms}
    c8, c7 = z["c8"].astype(np.float64), z["c7"].astype(np.float64)

    z3 = np.load(os.path.join(HERE, "ax3_transfer.npz"))
    sl = slice(0, n_tok)
    base_ax3 = z3["nll_base"][sl].astype(np.float64)
    u7_ax3 = z3["nll_u7"][sl].astype(np.float64)
    win_ax3 = z3["nll_lay_win_oracle"][sl].astype(np.float64)
    tok_ax3 = z3["nll_lay_tok_oracle"][sl].astype(np.float64)
    win_mlp_ax3 = z3["nll_lay_win_mlp"][sl].astype(np.float64)

    # ---- C2 文 ID の独立再構築 ----
    zc = np.load(os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz"), allow_pickle=True)
    parts, parts_nl = [], []
    for lg in ("en", "ja"):
        ids = zc[lg + "_ids"].astype(np.int64)[:n_win * ln]
        s, lens, nm = build_sent(ids, BOUND_PERIOD, n_win, ln)
        snl, lens_nl, nm_nl = build_sent(ids, BOUND_NL, n_win, ln)
        parts.append(sent_tok(s, n_win, n_eval))
        parts_nl.append(sent_tok(snl, n_win, n_eval))
        st = J["calib"]["C2"]["stats"][lg]
        chk("C2.n_sent_" + lg, int(lens.size), st["n_sent"])
        chk("C2.mean_len_" + lg, float(lens.mean()), st["mean_len"])
        chk("C2.max_len_" + lg, int(lens.max()), st["max_len"])
        chk("C2.n_merged_" + lg, int(nm), st["n_merged"])
        chk("C2.n_sent_nl_" + lg, int(lens_nl.size), st["n_sent_nl"])
    off = int(parts[0].max()) + 1
    sent = np.concatenate([parts[0], parts[1] + off]).astype(np.int32)
    off_nl = int(parts_nl[0].max()) + 1
    sent_nl = np.concatenate([parts_nl[0], parts_nl[1] + off_nl]).astype(np.int32)
    sent2, sent4 = group_local(sent, 2, nw, n_eval), group_local(sent, 4, nw, n_eval)
    for nm, a, b in (("sent", sent, z["sent"]), ("sent_nl", sent_nl, z["sent_nl"]),
                     ("sent2", sent2, z["sent2"]), ("sent4", sent4, z["sent4"])):
        chk("C2.ids_" + nm, int((a != b).sum()), 0)
    chk("C2.n_sent", int(sent.max()) + 1, J["calib"]["C2"]["n_sent"])
    chk("C2.n_sent_nl", int(sent_nl.max()) + 1, J["calib"]["C2"]["n_sent_nl"])
    chk("C2.n_2merge", int(sent2.max()) + 1, J["calib"]["C2"]["n_2merge"])
    chk("C2.n_4merge", int(sent4.max()) + 1, J["calib"]["C2"]["n_4merge"])
    seen, cross = set(), False
    for w in range(nw):
        sw = set(np.unique(sent[w * n_eval:(w + 1) * n_eval]).tolist())
        if sw & seen:
            cross = True
        seen |= sw
    chk("C2.no_cross", not cross, J["calib"]["C2"]["no_cross_window"])

    # ---- C1 ----
    c1 = J["calib"]["C1"]
    chk("C1.base_maxdiff", float(np.abs(N["base_rep"] - base_ax3).max()), c1["base_maxdiff"])
    chk("C1.u7_maxdiff", float(np.abs(N["u7_rep"] - u7_ax3).max()), c1["u7_maxdiff"])
    exp_tier = "SKIP" if J["meta"]["smoke"] else \
        ("A" if c1["base_maxdiff"] == 0.0 and c1["u7_maxdiff"] == 0.0 else "FAIL")
    chk("C1.tier", c1["tier"], exp_tier)

    # ---- 決定の再構築・C5 ----
    n_sent = int(sent.max()) + 1
    Y_sent = unit_targets(c8, c7, sent, n_sent)
    chk("Y_sent", float(np.abs(Y_sent - z["Y_sent"]).max()), 0.0)
    cut_s, prot_s = unit_decision(Y_sent)
    chk("dec.cut_s", int((cut_s != z["cut_s"]).sum()), 0)
    chk("dec.prot_s", int((prot_s != z["prot_s"]).sum()), 0)
    Y_p = z["pred_sent"].astype(np.float64)
    cut_p, prot_p = unit_decision(Y_p)
    chk("dec.cut_p", int((cut_p != z["cut_p"]).sum()), 0)
    chk("dec.prot_p", int((prot_p != z["prot_p"]).sum()), 0)
    rng_r = np.random.RandomState(RAND_SEED)
    cut_r = rng_r.randint(0, N_LAYERS, size=n_sent).astype(np.int8)
    draw = rng_r.randint(0, N_LAYERS - 1, size=n_sent)
    prot_r = (draw + (draw >= cut_r)).astype(np.int8)
    chk("dec.cut_r", int((cut_r != z["cut_r"]).sum()), 0)
    chk("dec.prot_r", int((prot_r != z["prot_r"]).sum()), 0)
    n2, n4, nnl = int(sent2.max()) + 1, int(sent4.max()) + 1, int(sent_nl.max()) + 1
    for nm, sid, nu, ck, cp in (("2", sent2, n2, "cut2", "prot2"),
                                ("4", sent4, n4, "cut4", "prot4"),
                                ("nl", sent_nl, nnl, "cut_nl", "prot_nl")):
        c, p = unit_decision(unit_targets(c8, c7, sid, nu))
        chk("dec.cut" + nm, int((c != z[ck]).sum()), 0)
        chk("dec.prot" + nm, int((p != z[cp]).sum()), 0)
    C5 = J["calib"]["C5"]
    chk("C5.conf_sent", int((cut_s == prot_s).sum()), C5["conflicts"]["sent"])
    chk("C5.conf_probe", int((cut_p == prot_p).sum()), C5["conflicts"]["probe"])
    for i in range(N_LAYERS):
        chk("C5.cut_%02d" % i, int((cut_s == i).sum()), C5["cut_hist"][i])
        chk("C5.prot_%02d" % i, int((prot_s == i).sum()), C5["prot_hist"][i])

    # ---- C3 mean_k ----
    mk = {"base_rep": 8.0, "u7_rep": 7.0,
          "sent_oracle": mean_k(sent, cut_s, prot_s, n_tok, nw, n_eval, ln),
          "sent_random": mean_k(sent, cut_r, prot_r, n_tok, nw, n_eval, ln),
          "sent_probe": mean_k(sent, cut_p, prot_p, n_tok, nw, n_eval, ln),
          "sent2_oracle": mean_k(sent2, z["cut2"], z["prot2"], n_tok, nw, n_eval, ln),
          "sent4_oracle": mean_k(sent4, z["cut4"], z["prot4"], n_tok, nw, n_eval, ln),
          "sent_nl_oracle": mean_k(sent_nl, z["cut_nl"], z["prot_nl"], n_tok, nw, n_eval, ln)}
    for k, v in mk.items():
        chk("C3." + k, float(J["calib"]["C3"]["mean_k"][k]), v)

    # ---- C4 ----
    C4 = J["calib"]["C4"]
    chk("C4.random_le_oracle",
        bool((N["u7_rep"] - N["sent_random"]).mean() <= (N["u7_rep"] - N["sent_oracle"]).mean()),
        C4["random_le_oracle"])

    # ---- C6 permutation の独立再実行 ----
    S, Ys = z["S"].astype(np.float64), z["Y_sent"].astype(np.float64)
    pred0 = ridge_loo(S, Ys)
    chk("C6.pred", float(np.abs(pred0 - z["pred_sent"]).max()), 0.0)
    obs = max(abs(spearman(Ys[:, j], pred0[:, j])) for j in range(32))
    chk("C6.observed", obs, J["calib"]["C6"]["observed"])
    rng = np.random.RandomState(PERM_SEED)
    null = []
    for it in range(NPERM):
        p = rng.permutation(n_sent)
        Yp = Ys[p]
        pr = ridge_loo(S, Yp)
        null.append(max(abs(spearman(Yp[:, j], pr[:, j])) for j in range(32)))
    null = np.array(null)
    c6 = J["calib"]["C6"]
    chk("C6.null_mean", float(null.mean()), c6["null_mean"])
    chk("C6.null_p95", float(np.percentile(null, 95)), c6["null_p95"])
    chk("C6.null_max", float(null.max()), c6["null_max"])
    chk("C6.pass", bool(obs < np.percentile(null, 95)), c6["pass"])

    # ---- 確認的 ----
    u7 = N["u7_rep"]
    d1 = win_ax3 - N["sent_oracle"]
    d2 = u7 - N["sent_oracle"]
    d3 = tok_ax3 - N["sent_oracle"]
    for sid, d, key in (("V1", d1, "V1_sent_minus_win"), ("V2", d2, "V2_sent"),
                        ("V3", d3, "V3_sent_minus_tok")):
        s = rst(d, n_eval)
        rj = J["confirmatory"][key]
        for f in ("mean", "sd", "se", "t", "p_two", "mde", "median",
                  "se_win", "top1_abs_share"):
            chk("%s.%s" % (sid, f), s[f], rj[f])
        chk("%s.n_pos" % sid, s["n_pos"], rj["n_pos"])
        chk("%s.n_neg" % sid, s["n_neg"], rj["n_neg"])
        for f in ("ci95", "ci90"):
            chk("%s.%s_lo" % (sid, f), s[f][0], rj[f][0])
            chk("%s.%s_hi" % (sid, f), s[f][1], rj[f][1])
    ph = holm_adj({"V1": J["confirmatory"]["V1_sent_minus_win"]["p_two"],
                   "V2": J["confirmatory"]["V2_sent"]["p_two"],
                   "V3": J["confirmatory"]["V3_sent_minus_tok"]["p_two"]})
    for k, v in ph.items():
        chk("holm." + k, v, J["confirmatory"]["holm"][k])
    rej = {k: ph[k] < ALPHA for k in ph}
    m1 = float(d1.mean())
    case = ("D" if not rej["V2"] else
            "A" if (rej["V1"] and m1 > 0) else
            "C" if (rej["V1"] and m1 < 0) else "B")
    chk("case", case, J["confirmatory"]["case"])

    # ---- 粒度カーブ・結果表 ----
    E = J["exploratory"]
    gain_map = {"sent_oracle": u7 - N["sent_oracle"],
                "sent_random": u7 - N["sent_random"],
                "sent_probe": u7 - N["sent_probe"],
                "sent2_oracle": u7 - N["sent2_oracle"],
                "sent4_oracle": u7 - N["sent4_oracle"],
                "sent_nl_oracle": u7 - N["sent_nl_oracle"],
                "win_oracle_ax3": u7_ax3 - win_ax3,
                "tok_oracle_ax3": u7_ax3 - tok_ax3,
                "win_mlp_ax3": u7_ax3 - win_mlp_ax3}
    for k, d in gain_map.items():
        chk("gain." + k, float(d.mean()), E["gains"][k]["mean"])
    curve = {"window_48": gain_map["win_oracle_ax3"].mean(),
             "sent4_85": gain_map["sent4_oracle"].mean(),
             "sent2_170": gain_map["sent2_oracle"].mean(),
             "sent_340": gain_map["sent_oracle"].mean(),
             "sent_nl_630": gain_map["sent_nl_oracle"].mean(),
             "per_token_12240": gain_map["tok_oracle_ax3"].mean()}
    for k, v in curve.items():
        chk("curve." + k, float(E["granularity_curve"][k]), float(v))
    for a in arms:
        r = J["results"][a]
        chk("arm.ce_" + a, float(N[a].mean()), r["ce"])
        chk("arm.dce_" + a, float((N[a] - u7).mean()), r["delta_vs_u7"])
        chk("arm.top1_" + a, float(z["acc1_" + a].mean()), r["top1"])
    chk("exp.top1_V1", rst(d1, n_eval)["top1_abs_share"], E["top1_abs_share_V1"])
    chk("exp.top1_V2", rst(d2, n_eval)["top1_abs_share"], E["top1_abs_share_V2"])

    lines = ["AX4 Step 4 verify (tag=%s)" % TAG,
             "items=%d  mismatches=%d" % (len(ITEMS), len(MISMATCH))]
    for nm, got, exp in MISMATCH[:25]:
        lines.append("  MISMATCH %s: got=%r exp=%r" % (nm, got, exp))
    txt = "\n".join(lines)
    print(txt)
    with open(os.path.join(HERE, "_ax4_verify_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write(txt + "\n")


if __name__ == "__main__":
    main()
