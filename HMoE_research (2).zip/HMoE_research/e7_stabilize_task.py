# -*- coding: utf-8 -*-
"""e7_stabilize_task.py — A4: ルータの学習安定性を改善する（E7 課題上的介入実験）

## 動機（E7 報告書 §10-2、セッション総括 A4）
E7（易しい／難しいの分離が弱い課題）で free ルーティングの効果は E6 の 1/8 に縮小した。
診断（E7 報告書 §5.3）:

  1. **ルータは「同種 vs 混合」は判別できるが「頻度（ff/rr）」は判別できない**
     （id_rate: ff 0.147 / fr 0.003 / rr 0.151。ff と rr に差なし）
  2. **最適方針（ff → 恒等、fr/rr → FFN）はほぼ無価格**（ff の恒等劣化は 0.057 nats/位置）
     なのに、ルータは ff の 15% しか逃がさない。FFN コスト 0.90（最適なら 0.43）
  3. **seed による二峰性**（id_rate_rr が 0.21 または 0.00）＝方針が seed によって成立/不成立

## なぜ sidecar でも最適方針にならないのか（検討済みの仮説）
sidecar の router 入力は [x, f0, f1]（f = 頻度指示 2 次元）。数値検証（__main__）により:
- 「ff のみ恒等」は [f0, f1] だけで**線形分離可能**（(1,1) の角を f0+f1 > 4/3 で孤立できる）。
  XOR 型ではない。→ **sidecar の失敗は表現力ではなく最適化（学習）の問題**と考えられる。
- 仮説 H-A（シグナル）: free router は残留 x から「両トークンが頻繁」を**線形に復号できない**
  （E7 の実測: id_rate に ff/rr の判別なし）。tokid（one-hot を直接付与）または MLP（非線形復号）で解決するか。
- 仮説 H-B（局所最適）: router が ff を恒等に逃がさない → 恒等パスが ff を学習しない →
  router に ff 逃がしの勾動機が湧かない、という鶏と卵の構造。entropy/balance で脱出できるか。

## 介入アーム（E7 の free を baseline として同 seed で比較）
| バリアント | 介入 | 狙い |
|---|---|---|
| `free_entropy` | gate エントロピー報酬（β=0.05） | 退化した全か無かの決定を防ぐ（安定化） |
| `free_balance` | Switch -style load-balancing 補助損失（β=0.1） | 全 Expert を遊ばせず、router が見捨てるのを防ぐ（安定化） |
| `free_tokid` | router 入力に src[i], src[i-1] の one-hot（2A=128 次元）を追加 | 信号を直接付与（シグナル復号の問題を回避） |
| `free_mlp` | router を線形から 2 層 MLP（hidden=d）に | 非線形性で x から頻度を復号（表現力） |

`free_tokid` で最適方針が線形表現可能であることの証明: one-hot 特徴 [e_a; e_b] に対し
w = [u; u], u(t) = +1 (t∈F) / −1 (t∉F), bias = −1 とすると
score = u_a + u_b − 1 > 0 ⟺ a,b ∈ F（ff）。__main__ で数値検証する。

## 実装ノート
- 学習ループは `e7_weaksep_task.run()` と同一（optimizer・lr・λ・データ生成の流れ）。
  変更点は ①router の差し替え（MLP）②router 入力の拡張（tokid）③安定化の損失項のみ。
- `NetX` は e5 の Net の複製（router の extra 次元を可変にしただけ）。e5/e6 のコードは不変更。
"""
import os, math, json, time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from e7_weaksep_task import make_weaksep_batch, make_lookup_table, ROLE_NAME, ID_IDX
from e5_dependency_task import MoELayer, Net

# バリアント定義: (route_mode, router, stab, extra)
VARIANTS = {
    "free_entropy": dict(route="free", router="linear", stab="entropy", extra=None),
    "free_balance": dict(route="free", router="linear", stab="balance", extra=None),
    "free_tokid":   dict(route="free", router="linear", stab=None,       extra="tokid"),
    "free_mlp":     dict(route="free", router="mlp",    stab=None,       extra=None),
}


class NetX(Net):
    """e5 の Net の複製。router の extra 入力次元を可変にした（tokid バリアント用）。

    e5/e6 の Net は extra = 2 if sidecar else 0 が直書き。tokid は 2A=128 次元を要する。
    動作は Net と同一（self.sidecar=True で extra 特徴を通す）。
    """

    def __init__(self, V, L, arm="free", route_mode="free", d=64, extra_dim=0):
        nn.Module.__init__(self)
        self.arm = arm
        self.sidecar = extra_dim > 0
        self.tok = nn.Embedding(V, d)
        self.pos = nn.Embedding(3 * L + 4, d)
        self.l0 = MoELayer(V, L, route_mode, 0, d=d)
        self.l1 = MoELayer(V, L, route_mode, extra_dim, d=d)
        self.head = nn.Linear(d, V)


class MLPRouter(nn.Module):
    """2 層 MLP ルータ。線形ルータと差し替え可能（出力は (B, T, e_num) の logits）。"""

    def __init__(self, in_dim, e_num, hidden=64):
        super().__init__()
        self.net = nn.Sequential(nn.Linear(in_dim, hidden), nn.ReLU(),
                                 nn.Linear(hidden, e_num))

    def forward(self, x):
        return self.net(x)


def tokid_feats(seq, L, T, A):
    """tokid バリアントの router 入力特徴: [onehot(src[i]), onehot(src[i-1])]（2A 次元）。

    出力部の L 位置に合わせ、前方を 0 でパディングする（sidecar と同じ規約）。
    """
    src = seq[:, :L].numpy()
    prev = np.concatenate([src[:, :1], src[:, :-1]], axis=1)
    f0 = np.zeros((seq.shape[0], L, A), dtype=np.float32)
    f1 = np.zeros((seq.shape[0], L, A), dtype=np.float32)
    np.put_along_axis(f0, src[:, :, None].astype(np.int64), 1.0, axis=2)
    np.put_along_axis(f1, prev[:, :, None].astype(np.int64), 1.0, axis=2)
    f = np.concatenate([f0, f1], axis=-1)
    pad = np.zeros((f.shape[0], T - L, f.shape[2]), dtype=np.float32)
    return torch.from_numpy(np.concatenate([pad, f], axis=1))


def gate_entropy(tg):
    """gate 分布の平均エントロピー（top-K 規格化済み）。tg: (B, T, K)。"""
    p = tg.clamp_min(1e-9)
    return -(p * p.log()).sum(-1).mean()


def balance_loss(ti, tg, e_num=8):
    """Switch -style load-balancing 補助損失: e_num × Σ_e f_e × P_e。

    f_e = expert e に割り当てられた (位置, slot) の割合、P_e = e に割り当てられた gate 質量の割合。
    一様使用で最小（= 0.5）、退化（1 expert に集中）で最大（= e_num）。
    """
    B, T, K = tg.shape
    N = B * T * K
    fs, Ps = [], []
    for e in range(e_num):
        m = (ti == e).float()
        fs.append(m.sum() / N)
        Ps.append((tg * m).sum() / N)
    return e_num * (torch.stack(fs) * torch.stack(Ps)).sum()


def margin_stats(lg_out, role, os_):
    """l1 の router logits（B, T, e_num）から、役割別の in-zone 率とマージン統計を計算。

    マージン = identity logit − 全体 2 位の logit。> 0 なら identity は top-2 内
    （＝コスト圧力の勾配が届く）。≤ 0 なら top-2 外（＝勾配が届かない dead zone）。
    """
    lg = lg_out[:, os_:]                          # (B, L, e_num)
    z_id = lg[..., ID_IDX]                        # (B, L)
    top2 = lg.topk(2, dim=-1).values              # (B, L, 2) 降順
    margin = z_id - top2[..., 1]                  # (B, L)
    st = {}
    for r, nm in ROLE_NAME.items():
        m = (role == r)
        if m.sum() > 0:
            mg = margin[m]
            st[f"inzone_{nm}"] = float((mg > 0).float().mean())
            st[f"margin_p10_{nm}"] = float(torch.quantile(mg, 0.1))
            st[f"margin_p50_{nm}"] = float(torch.quantile(mg, 0.5))
            st[f"margin_p90_{nm}"] = float(torch.quantile(mg, 0.9))
            st[f"zid_{nm}"] = float(z_id[m].mean())
    return st


def run(variant, seed, L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)), n_train=3500,
        n_val=2048, epochs=60, bs=64, lam_cost=0.15, d=64, ent_beta=0.05, bal_beta=0.1,
        table=None, device=None, spec=None, warmup=0, id_bias=0.0, probe_epochs=(),
        lam_post=None, ent_beta_post=None, id_bias_post=None, warm_bias=0.0,
        trace=False, trace_n=1024, lr=3e-3):
    """A4 の 1 ラン。学習ループは e7_weaksep_task.run() と同一（安定化項を追加）。

    spec を直接渡すと VARIANTS の参照を上書きする（後続実験の組合せアーム用。
    省略時は VARIANTS[variant]。既定動作は不変）。
    warmup > 0 のとき、最初の warmup epoch は ff 位置を恒等パスへルーティングする:
      - warm_bias = 0（既定）: 強制置き換え（force_id）。ff 位置の勾配は流れない。
      - warm_bias > 0: ff 位置の identity logit に warm_bias を足すソフト版。
        ゲート混合になるので勾配が流れ続ける（dead zone で凍結しない）。
    id_bias != 0 のとき、router の identity logit に定数を足す（top-k dead zone 検証用）。
    probe_epochs を渡すと、その epoch 後に in-zone 率・マージン分布を記録する
    （probe バッチは別 RNG。本体のデータ stream は変えない）。
    lam_post / ent_beta_post / id_bias_post: warmup 後（フェーズ 2）の λ / β / bias。
    省略時は lam_cost / ent_beta / id_bias（＝スケジュールなし）。warmup 中は bias = 0。
    trace = True のとき、1 epoch ごとに固定プローブバッチ（別 RNG 4242, bias=0）で
    val CE（役割別）・FFN cost・idmass・in-zone・マージン・Expert 質量・gate entropy・
    router logit 規模・router 勾配ノルムを記録する（壊滅的 seed の診断用）。
    プローブは no_grad・eval で RNG を消費しないため、本体の学習軌跡は不変。
    """
    spec = spec if spec is not None else VARIANTS[variant]
    lam_post = lam_cost if lam_post is None else lam_post
    ent_beta_post = ent_beta if ent_beta_post is None else ent_beta_post
    id_bias_post = id_bias if id_bias_post is None else id_bias_post
    if table is None:
        table = make_lookup_table(A)
    if device is None:
        device = "cuda" if torch.cuda.is_available() else "cpu"
    rng = np.random.default_rng(seed)
    torch.manual_seed(seed)
    V = A + 1
    extra_dim = 2 * A if spec["extra"] == "tokid" else 0
    net = NetX(V, L, arm="free", route_mode=spec["route"], d=d, extra_dim=extra_dim)
    if spec["router"] == "mlp":
        for layer in (net.l0, net.l1):
            layer.router = MLPRouter(layer.router.in_features, layer.e_num, hidden=d)
    net = net.to(device)
    opt = torch.optim.AdamW(net.parameters(), lr=lr, weight_decay=1e-4)
    pos_out = L + 1
    os_ = pos_out - 1

    def gen(n):
        return make_weaksep_batch(rng, n, L, A, w_freq, freq_vals, table=table)

    def feats(seq):
        if spec["extra"] == "tokid":
            return tokid_feats(seq, L, seq.shape[1] - 1, A).to(device)
        return None

    # probe バッチ（別 RNG: 本体のデータ stream を変えない）
    probe_log = []
    ps = pr = sc_p = None
    if probe_epochs:
        prng = np.random.default_rng(999)
        ps, pr, _ = make_weaksep_batch(prng, n_val, L, A, w_freq, freq_vals, table=table)
        sc_p = feats(ps)
        ps = ps.to(device)

    def probe(ep, bias):
        net.eval()
        with torch.no_grad():
            _, _, _, lg1 = net(ps[:, :-1], pos_out, sc_p, id_bias=bias, return_logits=True)
        probe_log.append({"epoch": ep, **margin_stats(lg1, pr, os_)})
        net.train()

    # trace バッチ（固定・別 RNG: 本体のデータ stream を変えない）
    trace_log = []
    tps = tpr = tsc_p = None
    _pstate = {"prev": None}          # 前 epoch のパラメータ（更新量の直接測定用）
    if trace:
        trng = np.random.default_rng(4242)
        tps, tpr, _ = make_weaksep_batch(trng, trace_n, L, A, w_freq, freq_vals, table=table)
        tsc_p = feats(tps)
        tps = tps.to(device)

    def trace_probe(ep, phase, train_ce, gnorm):
        """壊滅的 seed の診断: 1 epoch 末のモデル状態を固定バッチで全測定。

        margin_stats は **bias=0 の生 logit** を見る（warmup 中は外部バイアスを
        外した状態＝ルータ自身が zone を維持できているかの直接測度）。
        """
        net.eval()
        with torch.no_grad():
            lo, (ti0, ti1), (tg0, tg1), lg1 = net(tps[:, :-1], pos_out, tsc_p, id_bias=0.0,
                                                  return_logits=True)
            tt = tps[:, 1:]
            ce_t = F.cross_entropy(lo[:, os_:].reshape(-1, V), tt[:, os_:].reshape(-1),
                                   reduction="none").reshape(tps.shape[0], L)
            gate_id = (tg1[:, os_:] * (ti1[:, os_:] == ID_IDX).float()).sum(-1).mean().item()
            idm = (tg1[:, os_:] * (ti1[:, os_:] == ID_IDX).float()).sum(-1)
            Bp, Lp, K = tg1[:, os_:].shape
            rec = {"epoch": ep, "phase": phase, "train_ce": float(train_ce),
                   "gnorm_router": None if gnorm is None else float(gnorm),
                   "val_ce": float(ce_t.mean()), "ffn_cost": float(1.0 - gate_id),
                   "gate_ent": float(gate_entropy(tg1[:, os_:])),
                   "lg_absmax": float(lg1[:, os_:].abs().max()),
                   "lg_std": float(lg1[:, os_:].std())}
            for e in range(net.l1.e_num):
                rec[f"emass{e}"] = float((tg1[:, os_:] * (ti1[:, os_:] == e).float()).sum()
                                         / (Bp * Lp * K))
            for r, nm in ROLE_NAME.items():
                m = torch.from_numpy(tpr == r).to(ce_t.device)
                if m.sum() > 0:
                    rec[f"ce_{nm}"] = float(ce_t[m].mean())
                    rec[f"idmass_{nm}"] = float(idm[m].mean())
            rec.update({f"tr_{k}": v for k, v in margin_stats(lg1, tpr, os_).items()})
            # パラメータ更新量（「壊したステップ」の大きさを直接測る）
            flat = torch.cat([p.detach().reshape(-1).cpu() for p in net.parameters()])
            if _pstate["prev"] is not None:
                d = flat - _pstate["prev"]
                rec["dparam_l2"] = float(d.norm())
                rec["dparam_max"] = float(d.abs().max())
            rec["theta_l2"] = float(flat.norm())
            _pstate["prev"] = flat
            # どのモジュールが動いたか（記憶 = ffn/emb/head か、経路 = router/attn か）
            groups = {
                "emb": [net.tok.weight, net.pos.weight],
                "attn": [net.l0.q.weight, net.l0.k.weight, net.l0.v.weight, net.l0.o.weight,
                         net.l1.q.weight, net.l1.k.weight, net.l1.v.weight, net.l1.o.weight],
                "router": [net.l0.router.weight, net.l1.router.weight],
                "ffn": [net.l0.up, net.l0.down, net.l1.up, net.l1.down],
                "head": [net.head.weight],
            }
            if _pstate.get("groups") is not None:
                for gname, gps in groups.items():
                    dg = (torch.cat([p.detach().reshape(-1).cpu() for p in gps])
                          - _pstate["groups"][gname])
                    rec[f"d_{gname}"] = float(dg.norm())
            _pstate["groups"] = {gname: torch.cat([p.detach().reshape(-1).cpu() for p in gps])
                                 for gname, gps in groups.items()}
        net.train()
        trace_log.append(rec)

    for ep in range(epochs):
        net.train()
        seq, role, _ = gen(n_train)
        sc = feats(seq)
        seq = seq.to(device)
        force = None
        warm = None
        # フェーズ 1（ep < warmup）: ff を恒等へ（強制 or ソフトバイアス）+ 低圧力
        # フェーズ 2（ep >= warmup）: lam_post / ent_beta_post / id_bias_post（既定は元の値）
        if warmup > 0 and ep < warmup:
            lam_e, ent_e, bias_e = lam_cost, ent_beta, 0.0
            if warm_bias > 0:
                # ソフト版: ff 位置の identity logit に warm_bias を足す（勾配が流れる）
                wb = np.zeros((seq.shape[0], seq.shape[1] - 1), dtype=np.float32)
                wb[:, L:] = np.where(np.asarray(role) == 0, warm_bias, 0.0)
                warm = torch.from_numpy(wb).to(device)
            else:
                # 強制版: ff 位置を恒等に置き換え（勾配は流れない）
                f = np.zeros((seq.shape[0], seq.shape[1] - 1), dtype=bool)
                f[:, L:] = (np.asarray(role) == 0)          # FF = 0
                force = torch.from_numpy(f).to(device)
        else:
            lam_e, ent_e, bias_e = lam_post, ent_beta_post, id_bias_post
        perm = torch.randperm(n_train)
        ce_sum, ce_cnt, gnorm = 0.0, 0, None
        for i in range(0, n_train, bs):
            idx = perm[i:i + bs].to(device)
            b = seq[idx]
            inp, tgt = b[:, :-1], b[:, 1:]
            opt.zero_grad()
            logits, (ti0, ti1), (tg0, tg1) = net(inp, pos_out, None if sc is None else sc[idx],
                                                 force_id=None if force is None else force[idx],
                                                 id_bias=bias_e,
                                                 id_bias_amt=None if warm is None else warm[idx])
            ce = F.cross_entropy(logits[:, os_:].reshape(-1, V), tgt[:, os_:].reshape(-1))
            g0 = (tg0[:, os_:] * (ti0[:, os_:] == ID_IDX).float()).sum(-1).mean()
            g1 = (tg1[:, os_:] * (ti1[:, os_:] == ID_IDX).float()).sum(-1).mean()
            loss = ce + lam_e * (2.0 - (g0 + g1))
            if spec["stab"] == "entropy":
                loss = loss - ent_e * (gate_entropy(tg0[:, os_:]) + gate_entropy(tg1[:, os_:]))
            elif spec["stab"] == "balance":
                loss = loss + bal_beta * (balance_loss(ti0[:, os_:], tg0[:, os_:])
                                          + balance_loss(ti1[:, os_:], tg1[:, os_:]))
            loss.backward()
            if trace and i + bs >= n_train:
                # epoch 末バッチの router 勾配ノルム（l0 + l1）
                g = 0.0
                for p in list(net.l0.router.parameters()) + list(net.l1.router.parameters()):
                    if p.grad is not None:
                        g += float(p.grad.norm()) ** 2
                gnorm = g ** 0.5
            opt.step()
            if trace:
                ce_sum += float(ce.detach()) * inp.shape[0]
                ce_cnt += inp.shape[0]
        if trace:
            trace_probe(ep, "warm" if (warmup > 0 and ep < warmup) else "post",
                        ce_sum / max(ce_cnt, 1), gnorm)
        if probe_epochs and ep in probe_epochs:
            probe(ep, bias_e)

    net.eval()
    vs, vr, _ = gen(n_val)
    sc = feats(vs)
    vs = vs.to(device)
    with torch.no_grad():
        logits, (ti0, ti1), (tg0, tg1), lg1 = net(vs[:, :-1], pos_out, sc, id_bias=id_bias_post,
                                                  return_logits=True)
        tgt = vs[:, 1:]
        lo, lt = logits[:, os_:], tgt[:, os_:]
        ce_tok = F.cross_entropy(lo.reshape(-1, V), lt.reshape(-1), reduction="none").reshape(n_val, L)
        pred = lo.argmax(-1)
        acc = (pred == lt)
        gate_id = (tg1[:, os_:] * (ti1[:, os_:] == ID_IDX).float()).sum(-1).mean().item()
        res = {"variant": variant, "seed": seed, "L": L, "A": A, "w_freq": w_freq,
               "router": spec["router"], "stab": str(spec["stab"]),
               "warmup": warmup, "lam_post": lam_post, "ent_beta_post": ent_beta_post,
               "id_bias_post": id_bias_post,
               "ce_all": float(ce_tok.mean()), "acc_all": float(acc.float().mean()),
               "ffn_cost": float(1.0 - gate_id)}
        for r, nm in ROLE_NAME.items():
            m = (vr == r)
            if m.sum() > 0:
                mt = torch.from_numpy(m).to(ce_tok.device)
                res[f"n_{nm}"] = float(m.mean())
                res[f"ce_{nm}"] = float(ce_tok[mt].mean())
                res[f"acc_{nm}"] = float(acc[mt].float().mean())
        is_id = (ti1[:, os_:, 0] == ID_IDX).cpu().numpy()
        for r, nm in ROLE_NAME.items():
            m = (vr == r)
            if m.sum() > 0:
                res[f"id_rate_{nm}"] = float(is_id[m].mean())
        # H-B 診断: ff 位置を経路別に分解した CE（ルータが ff を逃がさない理由を測る）
        id_mass = (tg1[:, os_:] * (ti1[:, os_:] == ID_IDX).float()).sum(-1).cpu().numpy()
        for r, nm in ROLE_NAME.items():
            m = (vr == r)
            if m.sum() > 0:
                res[f"idmass_{nm}"] = float(id_mass[m].mean())
        ff_m = (vr == 0)
        if ff_m.sum() > 0:
            on_id = ff_m & is_id
            on_ff = ff_m & ~is_id
            if on_id.sum() > 0:
                res["ce_ff_onid"] = float(ce_tok[torch.from_numpy(on_id).to(ce_tok.device)].mean())
                res["frac_ff_onid"] = float(on_id.sum() / ff_m.sum())
            if on_ff.sum() > 0:
                res["ce_ff_onffn"] = float(ce_tok[torch.from_numpy(on_ff).to(ce_tok.device)].mean())
        # top-k dead zone 診断: 最終状態の in-zone 率とマージン分布
        res.update({f"fin_{k}": v for k, v in margin_stats(lg1, vr, os_).items()})
        if trace:
            # 壊滅的 seed の最終状態: モデルが「予測を諦めて定番トークンを吐く」状態かを測る
            p = lo.softmax(-1)
            res["out_ent"] = float(-(p * p.clamp_min(1e-9).log()).sum(-1).mean())
            vals, cnts = torch.unique(pred, return_counts=True)
            res["pred_mode_frac"] = float(cnts.max().float() / pred.numel())
            res["pred_mode_tok"] = int(vals[cnts.argmax()])
        res["id_bias"] = float(id_bias)
        res["probe_log"] = json.dumps(probe_log)
        if trace:
            res["trace"] = json.dumps(trace_log)
    return res


def _check_linear_separability(margin=0.05):
    """[f0, f1] の 2 特徴で「ff のみ」が線形分離可能かを余裕付きで数値確認。

    (1,1) の角は (1,0),(0,1),(0,0) の三角形の外にあるので、線形分離**可能**（XOR 型ではない）。
    例: w=(1,1), b=−1.5 なら score = f0+f1−1.5 > 0 ⟺ (f0,f1)=(1,1)。
    浮動小数点の退化解（マージン 0）を避けるため margin を要求する。
    """
    pts = [(1, 1, 1), (1, 0, 0), (0, 1, 0), (0, 0, 0)]  # (f0, f1, is_ff)
    for w0 in np.linspace(-2, 2, 161):
        for w1 in np.linspace(-2, 2, 161):
            for b in np.linspace(-2, 2, 161):
                if all((w0 * f0 + w1 * f1 + b > margin if y else w0 * f0 + w1 * f1 + b < -margin)
                       for f0, f1, y in pts):
                    return (round(w0, 3), round(w1, 3), round(b, 3))
    return None


if __name__ == "__main__":
    A, L = 64, 16
    tab = make_lookup_table(64)

    # 1. 線形表現可能性の検証
    print("=== 表現力の検証 ===")
    found = _check_linear_separability()
    print(f"[f0,f1] だけで「ff のみ恒等」を線形分離できるか: {'できる（余裕 0.05）w=' + str(found) if found else '不可能'}")
    print("  → XOR 型ではない。sidecar が最適方針を学習しないのは表現力ではなく最適化の問題")
    # one-hot 特徴なら可能: w = [u; u], u(t)=+1 (t<16) else -1, bias=-1
    fv = np.arange(16)
    u = np.where(np.arange(A) < 16, 1.0, -1.0)
    rng = np.random.default_rng(0)
    src = rng.integers(0, A, size=(20000, L))
    prev = np.concatenate([src[:, :1], src[:, :-1]], axis=1)
    score = u[src] + u[prev] - 1.0
    is_ff = np.isin(src, fv) & np.isin(prev, fv)
    ok = bool(((score > 0) == is_ff).all())
    print(f"one-hot 特徴（[u;u], bias=−1）で「ff のみ」を線形分離できるか: {ok}  "
          f"(ff 一致率 {100*((score>0)==is_ff)[is_ff].mean():.1f}%, 非 ff 誤誘導率 {100*((score>0)&~is_ff).mean():.2f}%)")

    # 2. tokid 特徴の形状と整合
    seq, role, po = make_weaksep_batch(rng, 128, table=tab)
    f = tokid_feats(seq, L, seq.shape[1] - 1, A)
    print(f"\ntokid 特徴: shape {tuple(f.shape)}（期待 (128, {2*L}, {2*A}））  行和 {f.sum(-1).unique().tolist()}")
    src_ = seq[:, :L].numpy()
    prev_ = np.concatenate([src_[:, :1], src_[:, :-1]], axis=1)
    chk = all(f[i, L + j, src_[i, j]] == 1.0 and f[i, L + j, A + prev_[i, j]] == 1.0
              for i in range(5) for j in range(L))
    print(f"特徴の中身（src[i], src[i-1] の one-hot）: {chk}")

    # 3. MLPRouter の形状
    mr = MLPRouter(64, 8, hidden=64)
    out = mr(torch.randn(4, 33, 64))
    print(f"MLPRouter: 出力 shape {tuple(out.shape)}（期待 (4, 33, 8)）")

    # 4. 各バリアントの 2 epoch スモーク（実行経路の検証）
    print("\n=== スモーク（各バリアント 2 epoch × 1 seed） ===")
    for v in VARIANTS:
        t0 = time.time()
        r = run(v, 0, epochs=2, table=tab)
        print(f" {v:14s} CE {r['ce_all']:.4f} | FFN {r['ffn_cost']:.3f} | acc {r['acc_all']:.4f} "
              f"(ff {r['acc_ff']:.3f} / fr {r['acc_fr']:.3f} / rr {r['acc_rr']:.3f}) | {time.time()-t0:.1f}s",
              flush=True)
