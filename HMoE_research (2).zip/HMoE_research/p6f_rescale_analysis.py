# -*- coding: utf-8 -*-
"""p6f_rescale_analysis.py — 質量由来か内容由来かの分解（GPU 不要）

p の押し上げ（＝較正ギャップの増加）を
    total   = p(u7)      - p(base)      削減そのもの
    content = p(u7_rs)   - p(base)      rescale 後も残る＝内容の効果
    mass    = p(u7)      - p(u7_rs)     質量を戻すと消える＝質量の効果
に分解する（total = content + mass が恒等的に成り立つ）。

出力: p6f_analysis.json / p6f_out_utf8.txt / p6f_rescale.png
"""
import json
import math

import numpy as np

LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


def ttest(a, b):
    d = np.asarray(a, float) - np.asarray(b, float)
    n = d.size
    se = d.std(ddof=1) / math.sqrt(n)
    return float(d.mean()), float(se), float(d.mean() / se) if se > 0 else float("nan")


def ece(p, y, nbins=10):
    edges = np.linspace(0.0, 1.0, nbins + 1)
    b = np.clip(np.digitize(p, edges) - 1, 0, nbins - 1)
    tot = 0.0
    for i in range(nbins):
        m = b == i
        if m.sum() == 0:
            continue
        tot += m.sum() / p.size * abs(y[m].mean() - p[m].mean())
    return float(tot)


def brier(p, y):
    return float(np.mean((p - y) ** 2))


z = np.load("p6e_rescale_cal.npz", allow_pickle=True)
CONDS = ["base", "u7", "u7_rs", "k6", "k6_rs"]
OUT = {"n_tokens": int(z["base_nll"].size)}

log("tokens=%d" % z["base_nll"].size)
log("")
log("=== 1. 水準 ===")
log("%-7s %9s %9s %9s %10s %8s %10s %10s" %
    ("cond", "CE", "p_top1", "acc", "gap(pt)", "ECE(pt)", "Brier", "kept_mass"))
tab = {}
for c in CONDS:
    p = z["%s_ptop1" % c].astype(float)
    y = z["%s_top1" % c].astype(float)
    row = dict(ce=float(z["%s_nll" % c].astype(float).mean()),
               p=float(p.mean()), acc=float(y.mean()),
               gap=float(p.mean() - y.mean()), ece=ece(p, y), brier=brier(p, y),
               kept=float(z["%s_kept_mass_by_layer" % c].mean()))
    tab[c] = row
    log("%-7s %9.5f %9.4f %9.4f %+10.2f %8.2f %10.5f %10.4f"
        % (c, row["ce"], row["p"], row["acc"], 100 * row["gap"], 100 * row["ece"],
           row["brier"], row["kept"]))
OUT["levels"] = tab

log("")
log("=== 2. 対比（対応検定、n=%d） ===" % z["base_nll"].size)
CONTRASTS = [("u7", "base", "削減そのもの (k=7)"),
             ("u7_rs", "base", "rescale 後 (k=7) = 内容の効果"),
             ("u7", "u7_rs", "質量の効果 (k=7)"),
             ("k6", "base", "削減そのもの (k=6)"),
             ("k6_rs", "base", "rescale 後 (k=6) = 内容の効果"),
             ("k6", "k6_rs", "質量の効果 (k=6)")]
rows = {}
for a, b, label in CONTRASTS:
    pa, ya = z["%s_ptop1" % a].astype(float), z["%s_top1" % a].astype(float)
    pb, yb = z["%s_ptop1" % b].astype(float), z["%s_top1" % b].astype(float)
    rec = {}
    for nm, xa, xb in (("CE", z["%s_nll" % a], z["%s_nll" % b]),
                       ("p", pa, pb), ("acc", ya, yb),
                       ("gap", pa - ya, pb - yb),
                       ("Brier", (pa - ya) ** 2, (pb - yb) ** 2)):
        m, se, t = ttest(xa, xb)
        rec[nm] = dict(d=m, se=se, t=t)
    rows["%s-%s" % (a, b)] = rec
    log("  %-32s CE %+.5f (t=%+.2f) | p %+.5f (t=%+.2f) | acc %+.5f (t=%+.2f) | gap %+.5f (t=%+.2f)"
        % (label, rec["CE"]["d"], rec["CE"]["t"], rec["p"]["d"], rec["p"]["t"],
           rec["acc"]["d"], rec["acc"]["t"], rec["gap"]["d"], rec["gap"]["t"]))
OUT["contrasts"] = rows

log("")
log("=== 3. 分解: 較正ギャップの増加はどこから来るか ===")
log("%-10s %12s %12s %12s %10s" % ("k", "total", "content", "mass", "content 比"))
dec = {}
for kk, cut, rs in (("k=7", "u7", "u7_rs"), ("k=6", "k6", "k6_rs")):
    tot = tab[cut]["gap"] - tab["base"]["gap"]
    con = tab[rs]["gap"] - tab["base"]["gap"]
    mas = tab[cut]["gap"] - tab[rs]["gap"]
    share = con / tot if tot != 0 else float("nan")
    dec[kk] = dict(total=tot, content=con, mass=mas, share_content=share)
    log("%-10s %+12.5f %+12.5f %+12.5f %10.1f%%" % (kk, tot, con, mas, 100 * share))
log("")
log("同・p_top1 について:")
for kk, cut, rs in (("k=7", "u7", "u7_rs"), ("k=6", "k6", "k6_rs")):
    tot = tab[cut]["p"] - tab["base"]["p"]
    con = tab[rs]["p"] - tab["base"]["p"]
    mas = tab[cut]["p"] - tab[rs]["p"]
    log("%-10s total %+.5f  content %+.5f  mass %+.5f  (content %.0f%%)"
        % (kk, tot, con, mas, 100 * con / tot if tot else float("nan")))
    dec[kk].update(p_total=tot, p_content=con, p_mass=mas)
OUT["decomp"] = dec

log("")
log("=== 4. 運用指標（tau=0.8） ===")
log("%-7s %10s %10s %10s" % ("cond", "自動化率", "自動化内誤り", "全体コスト"))
ops = {}
for c in CONDS:
    p = z["%s_ptop1" % c].astype(float)
    y = z["%s_top1" % c].astype(float)
    commit = p >= 0.8
    cost = commit * (1 - y) + 0.2 * (~commit)
    ops[c] = dict(rate=float(commit.mean()),
                  err=float((1 - y)[commit].mean()) if commit.sum() else float("nan"),
                  cost=float(cost.mean()))
    log("%-7s %10.4f %10.4f %10.5f" % (c, commit.mean(), ops[c]["err"], cost.mean()))
OUT["ops"] = ops

with open("p6f_analysis.json", "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=2)
with open("p6f_out_utf8.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(LOG))

# ---------------------------------------------------------------- 図
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.3), dpi=140)
    xs = np.arange(2)
    con = [100 * dec["k=7"]["content"], 100 * dec["k=6"]["content"]]
    mas = [100 * dec["k=7"]["mass"], 100 * dec["k=6"]["mass"]]
    ax[0].bar(xs, con, 0.5, label="content (survives rescale)", color="C3")
    ax[0].bar(xs, mas, 0.5, bottom=con, label="mass (removed by rescale)", color="C0")
    for x, cc, mm, tot in zip(xs, con, mas, [100 * dec["k=7"]["total"],
                                             100 * dec["k=6"]["total"]]):
        ax[0].annotate("content %+.2f" % cc, (x, cc), textcoords="offset points",
                       xytext=(0, -16), ha="center", fontsize=8, color="C3")
        ax[0].annotate("total %+.2f" % tot, (x, tot), textcoords="offset points",
                       xytext=(0, 4), ha="center", fontsize=8, color="k")
    ax[0].axhline(0, color="k", lw=0.8)
    ax[0].set_xticks(xs)
    ax[0].set_xticklabels(["k=7", "k=6"])
    ax[0].set_ylabel("increase in calibration gap (pt)")
    ax[0].set_title("Where does the overconfidence come from?")
    ax[0].legend(fontsize=8)
    ax[0].grid(alpha=0.3, axis="y")

    km = {c: z["%s_kept_mass_by_layer" % c] for c in CONDS}
    for c, col in (("base", "gray"), ("u7", "C0"), ("u7_rs", "C0"),
                   ("k6", "C3"), ("k6_rs", "C3")):
        ax[1].plot(km[c], ("o-" if "rs" in c else "--"), color=col,
                   label=c, ms=3, lw=1.2, alpha=0.9 if "rs" in c else 0.5)
    ax[1].set_xlabel("layer")
    ax[1].set_ylabel("kept routing mass")
    ax[1].set_title("Rescale restores the mass (per layer)")
    ax[1].legend(fontsize=7, ncol=2)
    ax[1].grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig("p6f_rescale.png")
    log("\nsaved p6f_rescale.png")
except Exception as e:
    log("figure failed: %s" % e)
