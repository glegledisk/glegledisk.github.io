"""simulate_r2_offload.py — R2オフロード階層（小FP8/大INT2）× PCIe帯域のレイテンシ隠蔽シミュレーション

リアルなR2オフロード設定:
- モデル全体: 32層, 各層8 Expert, 総パラメータ45B
- 均一4bit重み: 22.5 GB (1層あたり約704 MB)
- GPU HBMのうちExpertキャッシュに割り当てられる予算 (モデル全体):
    - 4 GB (極端オフロード: 各層 125 MB)
    - 8 GB (標準オフロード: 各層 250 MB)
    - 12 GB (中規模オフロード: 各層 375 MB)
- 均一MoE:
    - 全Expert 4bit (0.5 byte/param)
    - 容量順（均等確率なので任意）にHBMに詰め、残りはホスト退避
- HMoE:
    - 小Expert（高頻度、細い）は FP8 (1.0 byte/param) でHBM常駐
    - 大Expert（低頻度、太い）は INT2 (0.25 byte/param) でホスト退避
"""

import os
import sys
import math
import json
import numpy as np
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))

def get_hmoe_and_uniform_configs():
    d_model = 4096
    num_experts = 8
    num_layers = 32
    
    # 均一MoE (Uniform)
    w_uniform = np.array([14336] * num_experts)
    # HMoE (等差数列、合計幅は均一と同一 = 114,688)
    w_hmoe = np.array([4096, 6963, 9830, 12697, 15564, 18431, 21298, 25809])
    
    # 1層あたりのパラメータ数 (SwiGLU: 3 * d_model * w)
    params_uniform = 3 * d_model * w_uniform # 約 1.76e8 params / expert
    params_hmoe = 3 * d_model * w_hmoe
    
    # ルーティング人気確率 p_e
    p_uniform = np.array([1.0 / num_experts] * num_experts)
    
    # HMoE実測: 細いExpertほどトラフィックを吸う (rho = -0.88〜-0.98)
    p_hmoe = np.array([0.34, 0.24, 0.14, 0.10, 0.07, 0.05, 0.03, 0.03])
    p_hmoe /= p_hmoe.sum()
    
    return {
        "d_model": d_model,
        "num_experts": num_experts,
        "num_layers": num_layers,
        "uniform": {
            "w": w_uniform,
            "params": params_uniform,
            "p": p_uniform
        },
        "hmoe": {
            "w": w_hmoe,
            "params": params_hmoe,
            "p": p_hmoe
        }
    }


def simulate_offload_scenario(
    cfg,
    total_hbm_expert_budget_gb=8.0,  # モデル全体でのHBM Expertキャッシュ予算 (GB)
    pcie_bw_gbps=25.0,               # PCIe 実効帯域 (Gen4: 25 GB/s, Gen5: 50 GB/s)
    hbm_bw_gbps=1000.0,              # HBM 実効帯域 (1000 GB/s)
    gpu_tflops=150.0,                # デコード時 FP8/FP16 実効演算性能 (TFLOPS)
    batch_sizes=[1, 2, 4, 8, 16, 32, 64],
    top_k=2
):
    num_layers = cfg["num_layers"]
    layer_hbm_budget_bytes = (total_hbm_expert_budget_gb * 1e9) / num_layers
    
    u_cfg = cfg["uniform"]
    h_cfg = cfg["hmoe"]
    
    # -----------------------------
    # 1. 均一MoEの階層配置 (4bit均一: 0.5 byte/param)
    # -----------------------------
    u_bytes_per_exp = u_cfg["params"] * 0.5
    u_resident_mask = np.zeros(cfg["num_experts"], dtype=bool)
    curr_u_hbm = 0.0
    for i in range(cfg["num_experts"]):
        if curr_u_hbm + u_bytes_per_exp[i] <= layer_hbm_budget_bytes:
            u_resident_mask[i] = True
            curr_u_hbm += u_bytes_per_exp[i]
            
    u_host_mask = ~u_resident_mask
    
    # -----------------------------
    # 2. HMoEの階層配置 (小FP8常駐 + 大INT2ホスト)
    # -----------------------------
    h_resident_mask = np.zeros(cfg["num_experts"], dtype=bool)
    h_bytes_per_exp = np.zeros(cfg["num_experts"])
    curr_h_hbm = 0.0
    
    # 細いExpertから順に FP8 (1.0 byte/param) でHBMに詰める
    for i in range(cfg["num_experts"]):
        fp8_bytes = h_cfg["params"][i] * 1.0
        if curr_h_hbm + fp8_bytes <= layer_hbm_budget_bytes:
            h_resident_mask[i] = True
            h_bytes_per_exp[i] = fp8_bytes
            curr_h_hbm += fp8_bytes
        else:
            # 溢れた大Expertは INT2 (0.25 byte/param) でホスト退避
            h_resident_mask[i] = False
            h_bytes_per_exp[i] = h_cfg["params"][i] * 0.25
            
    h_host_mask = ~h_resident_mask
    
    results = {
        "budget_gb": total_hbm_expert_budget_gb,
        "pcie_bw": pcie_bw_gbps,
        "uniform": {
            "num_resident": int(u_resident_mask.sum()),
            "resident_traffic_pct": float(u_cfg["p"][u_resident_mask].sum()),
            "transfer_mb_per_token": [],
            "transfer_mb_per_batch": [],
            "transfer_time_us": [],
            "compute_time_us": [],
            "stall_time_us": [],
            "tpot_layer_us": [],
            "overlap_ratio": []
        },
        "hmoe": {
            "num_resident": int(h_resident_mask.sum()),
            "resident_traffic_pct": float(h_cfg["p"][h_resident_mask].sum()),
            "transfer_mb_per_token": [],
            "transfer_mb_per_batch": [],
            "transfer_time_us": [],
            "compute_time_us": [],
            "stall_time_us": [],
            "tpot_layer_us": [],
            "overlap_ratio": []
        }
    }
    
    for B in batch_sizes:
        # === 均一MoE ===
        # バッチBにおける各ホストExpertの要求確率
        # 各トークンはtop_k個選択
        # P(e is selected by at least one token) = 1 - (1 - p_e * top_k)^B (近似)
        p_sel_token_u = np.minimum(1.0, u_cfg["p"] * top_k)
        p_union_u = 1.0 - (1.0 - p_sel_token_u)**B
        u_batch_transfer_bytes = np.sum(p_union_u[u_host_mask] * u_bytes_per_exp[u_host_mask])
        u_transfer_mb = u_batch_transfer_bytes / 1e6
        
        # PCIe転送時間 (us): 帯域律速 + 起動遅延 (5us)
        t_trans_u = (u_batch_transfer_bytes / (pcie_bw_gbps * 1e9)) * 1e6 + 5.0
        
        # デコード計算時間 (us):
        # 1トークンあたり top_k * 2 * d_model * mean_w FLOPs
        # メモリ帯域律速: HBM常駐重み読み出し (KVキャッシュは固定と仮定)
        flop_u = B * top_k * 2 * cfg["d_model"] * np.mean(u_cfg["w"])
        t_comp_flop_u = (flop_u / (gpu_tflops * 1e12)) * 1e6
        # 常駐重みの読み出し時間
        t_comp_mem_u = (np.sum(u_bytes_per_exp[u_resident_mask]) / (hbm_bw_gbps * 1e9)) * 1e6
        t_comp_u = max(t_comp_flop_u, t_comp_mem_u)
        
        t_stall_u = max(0.0, t_trans_u - t_comp_u)
        tpot_u = t_comp_u + t_stall_u
        ov_u = t_trans_u / max(1e-6, t_comp_u)
        
        results["uniform"]["transfer_mb_per_token"].append(u_transfer_mb / B)
        results["uniform"]["transfer_mb_per_batch"].append(u_transfer_mb)
        results["uniform"]["transfer_time_us"].append(t_trans_u)
        results["uniform"]["compute_time_us"].append(t_comp_u)
        results["uniform"]["stall_time_us"].append(t_stall_u)
        results["uniform"]["tpot_layer_us"].append(tpot_u)
        results["uniform"]["overlap_ratio"].append(ov_u)
        
        # === HMoE ===
        p_sel_token_h = np.minimum(1.0, h_cfg["p"] * top_k)
        p_union_h = 1.0 - (1.0 - p_sel_token_h)**B
        h_batch_transfer_bytes = np.sum(p_union_h[h_host_mask] * h_bytes_per_exp[h_host_mask])
        h_transfer_mb = h_batch_transfer_bytes / 1e6
        
        t_trans_h = (h_batch_transfer_bytes / (pcie_bw_gbps * 1e9)) * 1e6 + 5.0
        
        # HMoEの計算量 (細いExpertの選好を反映)
        mean_active_w = np.sum(h_cfg["p"] * h_cfg["w"])
        flop_h = B * top_k * 2 * cfg["d_model"] * mean_active_w
        t_comp_flop_h = (flop_h / (gpu_tflops * 1e12)) * 1e6
        t_comp_mem_h = (np.sum(h_bytes_per_exp[h_resident_mask]) / (hbm_bw_gbps * 1e9)) * 1e6
        t_comp_h = max(t_comp_flop_h, t_comp_mem_h)
        
        t_stall_h = max(0.0, t_trans_h - t_comp_h)
        tpot_h = t_comp_h + t_stall_h
        ov_h = t_trans_h / max(1e-6, t_comp_h)
        
        results["hmoe"]["transfer_mb_per_token"].append(h_transfer_mb / B)
        results["hmoe"]["transfer_mb_per_batch"].append(h_transfer_mb)
        results["hmoe"]["transfer_time_us"].append(t_trans_h)
        results["hmoe"]["compute_time_us"].append(t_comp_h)
        results["hmoe"]["stall_time_us"].append(t_stall_h)
        results["hmoe"]["tpot_layer_us"].append(tpot_h)
        results["hmoe"]["overlap_ratio"].append(ov_h)
        
    return results


def main():
    cfg = get_hmoe_and_uniform_configs()
    
    # 3つの代表的オフロードシナリオ:
    # 1. RTX 4090 / 24GB (Expertキャッシュ 8GB, PCIe Gen4: 25 GB/s)
    # 2. 極端メモリ制約 16GB GPU (Expertキャッシュ 4GB, PCIe Gen4: 25 GB/s)
    # 3. 次世代ワークステーション / A100 (Expertキャッシュ 8GB, PCIe Gen5: 50 GB/s)
    scenarios = [
        ("RTX4090_Gen4_8GB", 8.0, 25.0),
        ("Tight_Gen4_4GB", 4.0, 25.0),
        ("Gen5_Server_8GB", 8.0, 50.0),
    ]
    
    batch_sizes = [1, 2, 4, 8, 16, 32, 64]
    all_res = {}
    
    for name, budget, pcie_bw in scenarios:
        res = simulate_offload_scenario(
            cfg,
            total_hbm_expert_budget_gb=budget,
            pcie_bw_gbps=pcie_bw,
            hbm_bw_gbps=1000.0,
            gpu_tflops=150.0,
            batch_sizes=batch_sizes,
            top_k=2
        )
        all_res[name] = res
        
    out_json = os.path.join(HERE, "r2_offload_overlap_results.json")
    with open(out_json, "w", encoding="utf-8") as fp:
        json.dump(all_res, fp, indent=2)
        
    print(f"Results saved to {out_json}")
    
    # 可視化プロット生成
    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    
    for idx, (name, budget, pcie_bw) in enumerate(scenarios):
        ax = axes[idx]
        res = all_res[name]
        bs = batch_sizes
        
        ov_u = res["uniform"]["overlap_ratio"]
        ov_h = res["hmoe"]["overlap_ratio"]
        
        ax.plot(bs, ov_u, 'r-o', linewidth=2, label=f"Uniform (4bit, Res:{res['uniform']['num_resident']}/8)")
        ax.plot(bs, ov_h, 'b-s', linewidth=2, label=f"HMoE (FP8/INT2, Res:{res['hmoe']['num_resident']}/8)")
        ax.axhline(1.0, color='black', linestyle='--', label="Zero-bubble Overlap (1.0)")
        
        ax.set_xscale('log', base=2)
        ax.set_yscale('log')
        ax.set_xlabel("Batch Size B")
        ax.set_ylabel("Overlap Ratio (T_transfer / T_compute)")
        ax.set_title(f"{name}\n(HBM:{budget}GB, PCIe:{pcie_bw}GB/s)")
        ax.grid(True, which="both", ls="--", alpha=0.5)
        ax.legend()
        
    plt.tight_layout()
    fig_path = os.path.join(HERE, "r2_offload_overlap_frontier.png")
    plt.savefig(fig_path, dpi=200)
    print(f"Plot saved to {fig_path}")

if __name__ == "__main__":
    main()
