# Matthew effectの自己強化：機構分析

作成日: 2026-10-16
対象: HMoEにおける「大expertが好まれ、さらに好まれる」自己強化ループの構造・証拠・設計含意。
関連: HMoE論文（原典）、`ハルシネーションとHMoE_関係調査_20261016.md` §6.3、`過学習とHMoE_関係調査_20261016.md` 仮説C、`不均一MoEとRSI_関係調査_20261015.md` §5、`critical_review_不均一MoE専用チップ構想.md`（HMoE固有の危険仮説）、`サイズ分布戦略_新案_20261016.md` §7。

---

## 0. 問題の定義

HMoE論文（Wang et al., EMNLP 2025）の用語——「larger experts, having stronger representational capacity, are more likely to be favored by the router, which in turn **reinforces their dominance**. As a result, smaller experts receive insufficient training, thereby limiting the model's overall representational capacity」。

すなわち自己強化ループは **ルーティング（選好）→ 学習（品質）→ 選好** の閉ループであり、HMoEでは**幅そのものがループの種（seed）**になる点が均一MoEとの本質的な差である。

先行研究: Chi et al.（NeurIPS 2022, [arXiv:2204.09179](https://arxiv.org/abs/2204.09179)）の representation collapse は同根の現象（大部分のtokenが少数expertに集中）を均一MoEで示すが、**幅による種を持たない**。形式的な動力学解析（固定点・利得の解析）を持つ論文は今回の調査では見つからなかった——本メモの§1の定式化は独自の整理である。

---

## 1. ループの構造（3つの結合ループと閉ループ利得）

記号: p_i = expert i のルーティング確率（活性化シェア）、q_i = expert i の品質（損失低減への寄与）。

```
   ┌───────────── ループ1（選好）─────────────┐
   │  router は q_i の高い expert を好む → p_i ↑  │
   └──────────────────┬──────────────────────┘
                      ▼
   ┌───────────── ループ2（学習）─────────────┐
   │  勾配質量 ∝ p_i → 学習信号 ↑ → q_i ↑      │
   └──────────────────┬──────────────────────┘
                      ▼
              （ループ1へ戻る）

   閉ループ利得: G = (∂q_i/∂p_i) · (∂p_i/∂q_i) > 0
   G が counter-force（補助loss等）の利得を上回れば暴走、下回れば固定点へ収束
```

**幅が種を作る**: 大expertは初期から q_i が高い（容量が大きいため）。均一MoEでは種は**確率的揺らぎのみ**（弱く、遅く、load balancing lossで抑止可能）。HMoEでは幅が**体系的で持続的な種**を供給し続ける——これが「自己強化が強い」ことの本体である。

---

## 2. なぜ均一点が不安定か（対称性の破れ）

- 均一MoE: 全expert同質。均一分布は鞍点——揺らぎが正帰還で増幅しうる（Chi et al.のcollapse）が、種が無いので揺らぎレベル。load balancing loss で安定化できる（論文の均一MoEはこれで安定）。
- HMoE: 幅による傾きが初期状態に埋め込まれている。均一分布は**最初から不安定**。

**load balancing loss が効かない理由（HMoE論文の実証）**: load balancing は**カウント（トークン数）**を均す。HMoEでは品質駆動の選好は「同じカウントでも大expertの方が損失を下げる」という**質量**の問題なので、カウントを均しても選好は残る。論文の言葉——「the load-balancing loss **does not alleviate the tendency** of larger experts being activated more frequently than smaller experts. This imbalance may limit HMoE's ability to outperform conventional MoE」。

---

## 3. 実証（HMoE論文の4つの観測）

| 観測 | 内容 | ループとの関係 |
|---|---|---|
| 素朴HMoE（補助loss無し） | 均一MoEを**下回る**。大expert偏り・小expert飢え | ループが暴走した固定点（歪んだ分布） |
| サイズ×活性化率の関係 | **単調でない**。ルーター選択の確率的性質（特に同程度の幅のexpert間）も寄与 | ループ1の「選好」は q だけでなく確率的揺らぎにも乗る——種は幅だけではない |
| P-Penalty 下の訓練ダイナミクス | P-Penalty loss は最初の約1,000ステップ（約3B tokens）で急上昇→漸減。小expertの活性化は訓練を通じて増加、大expertは減少、小expertは shared expert 化 | LM loss が最初は大expert方向へ押し（ループ1の初期優位）、学習されたルーティングが新しい固定点へ落ち着く**過渡的**振る舞い |
| geometric 分布の失敗 | P-Penalty を入れても小expertが有効な負荷を担えない（「capacity is insufficient because of their too-small size」） | 容量床——§5の「自然な負帰還が効かない」ケース |

---

## 4. ループを止める力（counter-force の分類）

| 力 | 作用点 | HMoEでの有効性 |
|---|---|---|
| load balancing loss | ループ1（確率・カウント） | ✗（論文の実証——大expert偏りを止められない） |
| **P-Penalty**（活性化質量 M_i×P̂_i のペナルティ） | ループ1（幅加重） | ○（論文の採用案。小expert活性化↑） |
| router entropy loss | 活性化数の肥大化（別軸の暴走） | ○（Top-Pで活性化expert数が増え続けるのを抑制） |
| capacity / drop / spill | 物理的な飽和 | △（暴走を止める自然な負帰還。訓練lossではなく実行時の制約） |
| 確率的探索 | 揺らぎの維持 | △ |

P-Penalty は全expert同サイズなら古典的 load balancing loss と一致する——「幅を入れた load balancing」であり、種（幅）と同じ言語で counter-force を置くから効く、という読み方ができる。

---

## 5. 飽和と自然な負帰還（見落とされがちな点）

ループは無限に暴走するわけではない。**大expertの品質が飽和すると、追加トークンの限界品質が下がる**（q の頭打ち）→ p の増加も鈍化 → 別の固定点へ。論文の素朴HMoEの活性化分布（0.0〜0.2の幅、完全な退化ではない）はこの飽和を示唆する。

さらに、capacity 制約が効くレジーム（大expertが飽和）では、溢れたトークンは自然に小expertへこぼれる（drop/spill）——**これは構造的な負帰還**であり:

- 訓練時: capacity factor 付きのMoE実装で自然に発生。
- **専用チップ**: 実行時のスケジューラ（`設計_実測サービス時間フィードバック` Loop C、µs級dispatch）で**帯クォータ・capacity-based spill を意図的に設計**できる。訓練lossに依存しない、実行時の counter-force——本プロジェクト固有の実装経路である。

---

## 6. 他の失敗モードとの接続

- **ハルシネーション**（`ハルシネーションとHMoE_関係調査` §6.3）: 死容量（未訓練の小expert）= confabulation の供給源。
- **過学習**（`過学習とHMoE_関係調査` 仮説C）との**微妙な両面性**: 集中は大expertのデータ密度（n_i/(d_model·d_ff,i)）を**改善**し、小expertを飢えさせる。つまりMatthew effectは一方の不均衡（大expertの低データ密度）を自己補正しながら、他方（小expertの未学習）を作る。単純に「悪」ではない。
- **選抜の自己強化（RSI調査 §5）——最も危険な接続**: サイズ分布新案B/D（適応的幅配分）を導入すると、「**大expertのrouteが多いから幅を増やす**」という選抜ループが設計ループに重なり、Matthew effectを**増幅**しうる。route頻度は品質寄与の証拠ではない——route固定ablation・再route ablationでの限界寄与で判断する規律（critical review・RSI調査の既存方針）が、適応的設計の前提条件になる。

---

## 7. 設計への含意（本プロジェクト向け）

1. **帯構造は種を弱める**: 容量帯（同幅の複数expert、サイズ分布新案A）では Matthew effect は**帯間にのみ**働き、帯内は幅が同一なので揺らぎだけが種。→ 自己強化は「帯レベル」に限定される。MoHGE の group-wise auxiliary loss はまさにこのレベルで counter-force を置く設計である。
2. **P-Penalty の帯版**: 帯構造では M_i（expert級の平均hidden dim）ではなく、**帯レベルの質量**でペナルティを設計する（帯選択→帯内選択の二段ルーティングと整合）。
3. **ハードウェアスケジューラでの counter-force**: Loop C で帯クォータ・spill を強制（§5）。訓練lossと実行時制約の二層で均衡化する。
4. **適応的幅配分の規律**: 頻度ではなく限界寄与で判断（§6）。

---

## 8. 測定計画

1. **時系列**: per-expert の活性化シェア・勾配質量・品質proxy（held-out損失寄与）を訓練を通じて記録。**ループ利得の推定**: Δshare と Δquality の相関（∂q/∂p × ∂p/∂q の実験的估計）。
2. **介入**: router を凍結（ループ1を切断）して小expertの品質が回復するか——ループ2（学習）単独での回復力を測る。
3. **P-Penalty 係数 × 活性化分布の固定点 × 性能**: 係数を振り、固定点の分布と歪みを測定。
4. **帯版の比較**: 帯内同幅（新案A）での Matthew effect の強さを、全幅相異（現行）と比較——種の弱体化が測れる。

---

## 参考文献

1.  Wang et al., [HMoE: Heterogeneous Mixture of Experts for Language Modeling](https://aclanthology.org/2025.emnlp-main.1115.pdf), EMNLP 2025. Matthew effect の用語・実証（素朴HMoEの失敗・load balancingの非効・P-Penalty・訓練ダイナミクス・geometric失敗）の出所。
2.  Chi et al., [On the Representation Collapse of Sparse Mixture of Experts](https://arxiv.org/abs/2204.09179), NeurIPS 2022. 均一MoEの同根現象（幅seed無し）。
3.  Ma et al., [MoHGE](https://arxiv.org/abs/2604.23108), ACL 2026. group-wise auxiliary loss＝帯レベルの counter-force。
4.  プロジェクト内: `ハルシネーションとHMoE_関係調査_20261016.md`、`過学習とHMoE_関係調査_20261016.md`、`不均一MoEとRSI_関係調査_20261015.md`、`critical_review_不均一MoE専用チップ構想.md`、`サイズ分布戦略_新案_20261016.md`、`設計_実測サービス時間フィードバック_20261016.md`。
