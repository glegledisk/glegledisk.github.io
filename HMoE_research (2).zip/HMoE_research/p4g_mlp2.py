"""
P4g: MLP probe の決定価値（BCE / rank 目標）

P4f で MSE 回帰は ridge に負けたが、BCE（上位 25% の分類）は AUC 0.642 と最良だった。
ここでは目標関数を変えて AUC と **決定価値** を測る。

逆転条件（P4 §5）: 信号の回収量 > Jensen ペナルティ 0.0106 nats
  均一 top-7 = +0.01449 / ランダム = +0.02511 / oracle = −0.03803（実測）
"""

import json
import os

import numpy as np

from p4b_probe import auc_score, build_features, spearman
from p4e_mech import layer_feats
from p4f_mlp import mlp_cv

HERE = os.path.dirname(os.path.abspath(__file__))
MECH_NAMES = ["p1", "p7", "p8", "p9", "p7p8", "p8_over_p1", "p9_over_p8",
              "z8_z9", "z6_z9", "mass8", "mass6", "lost_mass", "ent",
              "zmax", "zstd", "zmean", "npos"]


def decision_value(score, d_j, f=0.5):
    n = d_j.size
    m = int(round(f * n))
    keep = np.zeros(n, bool)
    keep[np.argsort(-score)[:m]] = True
    return float(d_j[~keep].sum() / n)


def main():
    d = np.load(os.path.join(HERE, "p4_feats.npz"), allow_pickle=True)
    mech = np.load(os.path.join(HERE, "p4_mech_features.npz"))
    p3 = np.load(os.path.join(HERE, "p3_topk_nll.npz"))
    nll_j = p3["k8"]
    d_j = p3["k6"] - p3["k8"]
    win = d["win"]
    n = d_j.size
    ybin = (d_j > np.quantile(d_j, 0.75)).astype(np.float64)
    rank_y = np.argsort(np.argsort(d_j)).astype(np.float64) / (n - 1)
    feats, _ = build_features(d)

    mech_l15 = np.stack([mech["L15_" + nm] for nm in MECH_NAMES], 1)
    mech_all = np.stack([mech["avg_" + nm] for nm in MECH_NAMES], 1)

    SETS = {
        "gate15": feats["gate15"].astype(np.float64),
        "mech_L15+hist": np.concatenate([mech_l15, feats["hist"]], 1).astype(np.float64),
        "gate15+mech+hist": np.concatenate([feats["gate15"], mech_l15, feats["hist"]], 1).astype(np.float64),
        "ALL(l15)": np.concatenate([feats["gate15"], mech_l15, feats["h15"], feats["hist"]], 1).astype(np.float64),
        "gate0+gate15": np.concatenate([feats["gate0"], feats["gate15"]], 1).astype(np.float64),
        "mech_all+hist": np.concatenate([mech_all, feats["hist"]], 1).astype(np.float64),
    }
    TARGETS = {"bce": ybin, "rank": rank_y}

    print("=== AUC と決定価値（f=0.5, 予算 mean_k=7）===")
    print("  均一 top-7 +0.01449 / ランダム +0.02511 / oracle −0.03803（実測）")
    print("%-18s %-5s %8s %8s %10s %8s" % ("features", "target", "AUC", "rho", "dv(f=0.5)", "dv(f=.25)"))
    rows = {}
    preds = {}
    for name, X in SETS.items():
        for tname, y in TARGETS.items():
            m, hist = mlp_cv(X, y, win, hidden=(64, 32), epochs=250, lr=3e-3,
                             wd=1e-4, loss=("bce" if tname == "bce" else "mse"),
                             patience=40, seed=3)
            a = auc_score(ybin, m)
            r = spearman(m, d_j)
            dv5 = decision_value(m, d_j, 0.5)
            dv25 = decision_value(m, d_j, 0.25)
            key = name + "|" + tname
            rows[key] = {"auc": a, "spearman": r, "dv50": dv5, "dv25": dv25, "dim": int(X.shape[1])}
            preds[key] = m
            print("%-18s %-5s %8.4f %8.4f %10.5f %8.5f" % (name, tname, a, r, dv5, dv25))

    best = min(rows, key=lambda k: rows[k]["dv50"])
    print("\n最良の決定価値: %s  dv=%.5f  AUC=%.4f" % (best, rows[best]["dv50"], rows[best]["auc"]))
    print("均一 top-7 = +0.01449 と比較して %s" % ("勝ち" if rows[best]["dv50"] < 0.01449 else "負け"))

    with open(os.path.join(HERE, "p4_mlp2_results.json"), "w", encoding="utf-8") as fp:
        json.dump({"rows": rows, "best": best}, fp, ensure_ascii=False, indent=2)
    np.savez_compressed(os.path.join(HERE, "p4_mlp2_preds.npz"),
                        **{k.replace("|", "__"): v for k, v in preds.items()},
                        d_j=d_j, nll_j=nll_j, win=win)
    print("saved p4_mlp2_results.json / p4_mlp2_preds.npz")


if __name__ == "__main__":
    main()
