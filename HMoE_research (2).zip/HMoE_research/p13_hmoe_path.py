#!/usr/bin/env python3
"""P13: 学習済み HMoE で「等 FLOPs の同質 MoE 低 k」と比べる（批評 2026-10-29 の 1・2 への回答）。

素材: simulation_hmoe_mmlu/data/e2 の ckpt（rewrite タスク, 総パラメータ同一）
  H+LB: 幅 32/32/96/96/160/160/224/224（不均一）, top-2, p_pen aux
  U+LB: 幅 128 x 8（均一）, top-2, switch aux
  seed 0/1/2。

主分析（交絡なし）: 自然な動作点での CE vs active width
  base = 学習どおり top-2 / top1 = 学習どおり top-1 / top3 = top-3 / all8 = 全 8

副分析（交絡あり、明記）: ルータを固定部分集合に制限する。ゲートは部分集合上の softmax
  なので「その expert しか存在しない世界」に相当するが、層別の専門化とゲートスケールの
  影響を受ける。P7c と同じ「事後介入」の限界を持つ。

出力: p13_hmoe_path.json / p13_hmoe_path.csv
"""
import argparse
import csv
import json
import math
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, E2DIR)
from e2_rewrite_routing import (  # noqa: E402
    RewriteMoE, make_batch, to_seq, SL, OL, V, WIDTHS)

OUTDIR = os.path.join(E2DIR, "data", "e2")

MAIN = [("top1", None, 1), ("base", None, 2), ("top3", None, 3), ("all8", None, 8)]
SUB = [
    ("s1", (0,), 1),
    ("s2", (0, 1), 2),
    ("m2", (0, 2), 2),
    ("u2", (2, 3), 2),
    ("q4", (0, 1, 2, 3), 4),
    ("l2", (6, 7), 2),
    ("r2", "rand", 2),
]


def forward_forced(model, idx, force=None, k=None):
    p = model.p
    B, T = idx.shape
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    gates_l, idx_l = [], []
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
        if force is None:
            topv, topi = logits.topk(k, dim=1)
        else:
            topi = torch.tensor(list(force), dtype=torch.long).expand(h.shape[0], -1)
            topv = logits.gather(1, topi)
        gate = torch.softmax(
            torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
        gates_l.append(gate.detach())
        idx_l.append(topi.reshape(B, T, -1))
        y = torch.zeros_like(h)
        for i in range(model.E):
            tok, slot = (topi == i).nonzero(as_tuple=True)
            if tok.numel() == 0:
                continue
            x = h[tok]
            h1 = F.relu(F.linear(x, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
            y.index_add_(0, tok,
                         F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                         * gate[tok, slot].unsqueeze(1))
        h = h + y
    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, V)
    return out, idx_l, gates_l


@torch.no_grad()
def run_cond(model, src, out, em, force, k, bs=128):
    n = src.shape[0]
    ce = np.zeros((n, OL), dtype=np.float32)
    hit_c = np.zeros((n, OL), dtype=bool)
    hit_e = np.zeros((n, OL), dtype=bool)
    widths = np.zeros((n, OL), dtype=np.float32)
    usage = np.zeros((model.L, model.E))
    ntok = 0
    dims = np.array(model.dims, float)
    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = to_seq(src[s], out[s])
        logits, idx_l, _ = forward_forced(model, x, force=force, k=k)
        lg = logits[:, SL:SL + OL, :]
        tgt = torch.from_numpy(out[s])
        lp = F.cross_entropy(lg.reshape(-1, V), tgt.reshape(-1),
                             reduction="none").reshape(-1, OL)
        ce[s] = lp.numpy()
        pred = lg.argmax(-1).numpy()
        m = em[s]
        hit_c[s] = (pred == tgt.numpy()) & (~m)
        hit_e[s] = (pred == tgt.numpy()) & m
        # 幅は OUT 区間のトークンで
        for l, ti in enumerate(idx_l):
            a = ti.numpy()[:, SL:SL + OL, :]
            widths[s] += dims[a].sum(-1)
            for e in range(model.E):
                usage[l, e] += float((a == e).any(-1).sum())
        ntok += a.shape[0] * a.shape[1]
    widths /= max(1, len(idx_l))
    mask = em
    return {
        "ce_copy": float(ce[~mask].mean()), "ce_edit": float(ce[mask].mean()),
        "ce_all": float(ce.mean()),
        "acc_copy": float(hit_c.sum() / max(1, (~mask).sum())),
        "acc_edit": float(hit_e.sum() / max(1, mask.sum())),
        "width": float(widths.mean()),
        "width_p10": float(np.percentile(widths, 10)),
        "width_p90": float(np.percentile(widths, 90)),
        "usage": (usage / max(1, ntok)).round(4).tolist(),   # (L, E) 出現率
        "ce_seq": ce.mean(1).astype(np.float64).tolist(),    # 系列単位（対応差の単位）
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", nargs="+", default=["H+LB", "U+LB"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--n_eval", type=int, default=2048)
    ap.add_argument("--sub", action="store_true", help="副分析（固定部分集合）も回す")
    args = ap.parse_args()
    torch.set_num_threads(6)

    ev_rng = np.random.default_rng(777)          # E2 の evaluate と同一
    src, out, em, ks = make_batch(ev_rng, args.n_eval)
    print("eval: n=%d  OUT=%d  k_mean=%.2f  edit率=%.3f"
          % (src.shape[0], OL, ks.mean(), em.mean()), flush=True)

    conds = MAIN + (SUB if args.sub else [])
    results = {}
    for arm in args.arms:
        for seed in args.seeds:
            path = os.path.join(OUTDIR, "ckpt_%s_s%d.pt" % (arm, seed))
            if not os.path.exists(path):
                print("  [skip] %s" % path)
                continue
            model = RewriteMoE(WIDTHS[arm], seed=seed)
            model.p = {k: v for k, v in torch.load(path, map_location="cpu").items()}
            for k in model.p:
                model.p[k].requires_grad_(False)
            ref = json.load(open(os.path.join(OUTDIR, "%s_s%d.json" % (arm, seed)),
                                 encoding="utf-8"))
            print("\n[%s s%d] widths=%s  総幅=%d"
                  % (arm, seed, list(WIDTHS[arm]), sum(WIDTHS[arm])), flush=True)
            for name, force, k in conds:
                if force == "rand":
                    rng = np.random.default_rng(99 + seed)
                    force = tuple(sorted(rng.choice(model.E, k, replace=False).tolist()))
                r = run_cond(model, src, out, em, force, k)
                r.update({"arm": arm, "seed": seed, "cond": name,
                          "force": list(force) if force is not None else "natural",
                          "k": k, "n_eval": args.n_eval})
                results["%s:s%d:%s" % (arm, seed, name)] = r
                flag = ""
                if name == "base":
                    flag = "  [校正] json %.4f vs %.4f 一致=%s" % (
                        ref["copy_acc"], r["acc_copy"],
                        abs(r["acc_copy"] - ref["copy_acc"]) < 3e-3)
                print("  %-5s w=%4.0f [%3.0f,%3.0f]  CE %.4f  copy %.4f  edit %.4f%s"
                      % (name, r["width"], r["width_p10"], r["width_p90"],
                         r["ce_all"], r["acc_copy"], r["acc_edit"], flag), flush=True)
                if name == "base":
                    print("        layer別 使用率: %s"
                          % " | ".join(" ".join("%.2f" % x for x in row)
                                       for row in r["usage"]), flush=True)

    with open(os.path.join(HERE, "p13_hmoe_path.json"), "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2, default=float)
    keys = ["arm", "seed", "cond", "force", "k", "width", "width_p10", "width_p90",
            "ce_all", "ce_copy", "ce_edit", "acc_copy", "acc_edit"]
    with open(os.path.join(HERE, "p13_hmoe_path.csv"), "w", newline="",
              encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in results.values():
            w.writerow({k: (json.dumps(r[k]) if isinstance(r[k], list) else r[k])
                        for k in keys})
    print("\nsaved: p13_hmoe_path.json / p13_hmoe_path.csv")
    os._exit(0)


if __name__ == "__main__":
    main()
