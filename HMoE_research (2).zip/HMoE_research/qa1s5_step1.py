# -*- coding: utf-8 -*-
"""QA1S5 Step 1: 床 run を学習崩壊 / 収束途中 / 政策的床に分離する（既存データ再解析）.

設計書: `QA1S5課題設計書_床runを学習崩壊と収束途中に分離する_20261116.md` §2
新規学習なし。seed 2 は除外しない。ttest の再計算も行わない。
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
TAG = "qa1s5_step1"

COLLAPSE_LOSS_RATIO = 1.0   # max(loss_hist[1:]) > loss_hist[0]
COLLAPSE_CE = 0.5
FLOOR = 0.0


def classify(loss, final_iv, iv_main, final_ce):
    loss = np.asarray(loss, dtype=np.float64)
    spike = bool(loss.size > 1 and float(loss[1:].max()) > float(loss[0]) * COLLAPSE_LOSS_RATIO)
    if spike and abs(final_iv - FLOOR) < 1e-12 and final_ce > COLLAPSE_CE:
        return "COLLAPSE", spike
    if final_iv > FLOOR and abs(iv_main - FLOOR) < 1e-12:
        return "TRANSIENT", spike
    if abs(final_iv - FLOOR) < 1e-12 and bool(np.all(np.diff(loss) <= 0)):
        return "FLOOR_STABLE", spike
    return "HEALTHY", spike


def main():
    q = json.loads((HERE / "qa1s4_metrics.json").read_text(encoding="utf-8"))
    out = {"tag": TAG, "phase": "QA1S5 Step 1 (floor-mode disaggregation, no new training)",
           "design": "QA1S5課題設計書_床runを学習崩壊と収束途中に分離する_20261116.md",
           "no_training": True, "no_seed_exclusion": True,
           "no_confirmatory_test": True}
    out["prereg"] = {
        "COLLAPSE_LOSS_RATIO": COLLAPSE_LOSS_RATIO, "COLLAPSE_CE": COLLAPSE_CE,
        "labels": ("COLLAPSE", "TRANSIENT", "FLOOR_STABLE", "HEALTHY"),
        "n_runs": 21, "seeds": list(range(7)),
    }

    rows = []
    for r in q["rows"]:
        tail = np.asarray(r["iv_series_tail"], dtype=np.float64)
        final_iv = float(tail[-1]) if tail.size else float("nan")
        loss = r["loss_hist"]
        final_ce = float(np.median([e["ce_all"] for e in r["evals"][-3:]]))
        label, spike = classify(loss, final_iv, float(r["iv_main"]), final_ce)
        rows.append({
            "arm": r["arm"], "seed": r["seed"], "label": label,
            "loss_spike": spike,
            "loss_hist": [round(float(x), 6) for x in loss],
            "iv_series_tail": np.round(tail, 8).tolist(),
            "iv_main": float(r["iv_main"]), "final_iv": final_iv,
            "final_ce_all_median": final_ce,
            "T_plus": bool(r["T_plus"]), "E_flag": bool(r["E_flag"]),
            "small_share": (float(r["routing"]["small_share"])
                            if isinstance(r.get("routing"), dict)
                            and "small_share" in r["routing"] else None),
            "gain_key_count": int(r.get("gain_key_count", -1)),
        })
    out["rows"] = rows
    labels = {}
    for r in rows:
        labels.setdefault(r["label"], []).append(f"{r['arm']}_s{r['seed']}")
    out["groups"] = labels
    out["n_by_label"] = {k: len(v) for k, v in labels.items()}

    # QA1S4 の主統計・尾統計を再計算（確認的判定はしない）
    d = np.load(HERE / "qa1s4_delta.npz")
    diff = np.asarray(d["delta_iv_per_seed"], dtype=np.float64)
    s = np.sort(np.abs(diff))[::-1]
    top1 = float(s[:max(1, int(math.ceil(0.01 * diff.size)))].sum() / s.sum())
    out["reference_from_qa1s4"] = {
        "delta_iv": float(diff.mean()),
        "top1_share": top1,
        "median_abs": float(np.median(np.abs(diff))),
        "max_abs": float(s[0]),
        "note": "参考記録のみ。C5-P6 停止により確認的判定は出さない",
    }

    # 固定規則の主要帰結を assert する（結果を見てラベルを動かさない）
    checks = {
        "n_runs_21": len(rows) == 21,
        "collapse_only_w_mid_s2": labels.get("COLLAPSE", []) == ["w_mid_s2"],
        "transient_includes_w_ref_s0": "w_ref_s0" in labels.get("TRANSIENT", []),
        "no_seed_2_exclusion": len(diff) == 7,
        "top1_below_0.5": top1 < 0.5,
        "random_dup_zero": bool(np.asarray(d["random_dup"]).max() == 0),
    }
    out["checks"] = checks
    out["verdict"] = "PASS" if all(checks.values()) else "FAIL"

    def scan(o, path="root"):
        bad = []
        if isinstance(o, dict):
            for k, v in o.items():
                bad += scan(v, f"{path}.{k}")
        elif isinstance(o, list):
            for j, v in enumerate(o):
                bad += scan(v, f"{path}[{j}]")
        elif isinstance(o, float) and not np.isfinite(o):
            bad.append(path)
        return bad
    nf = scan(out)
    out["nonfinite"] = nf
    if nf:
        out["verdict"] = "FAIL"

    (HERE / f"{TAG}_metrics.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    lines = [
        f"tag={TAG}", f"verdict={out['verdict']}",
        f"n_by_label={out['n_by_label']}",
        f"COLLAPSE={labels.get('COLLAPSE', [])} TRANSIENT={labels.get('TRANSIENT', [])}",
        f"top1={top1:.6f} delta_iv_ref={diff.mean():.8f}",
        f"checks={checks}", f"nonfinite={nf}", "",
    ]
    (HERE / f"{TAG}.log").write_text("\n".join(lines), encoding="utf-8")
    sys.stdout.write("\n".join(lines))
    sys.stdout.flush()


if __name__ == "__main__":
    main()
