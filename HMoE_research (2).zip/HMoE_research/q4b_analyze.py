#!/usr/bin/env python3
"""Q4b の解析: d_model（容量ノブ）ごとの acc と Δ。

入力: simulation_hmoe_mmlu/data/q4b/H+LB_{task}_d{d}_s{seed}.json
出力: data/q4b/q4b_analysis.json / 標準出力
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q4b")
TASK = "hard"
DMODELS = [64, 80, 96]
SEEDS = [0, 1, 2, 3, 4, 5]


def load(d, s):
    p = os.path.join(D, f"H+LB_{TASK}_d{d}_s{s}.json")
    if not os.path.exists(p):
        return None
    try:
        with open(p, encoding="utf-8") as f:
            r = json.load(f)
    except (json.JSONDecodeError, OSError):
        return None
    return r if r.get("n_eval") == 1024 else None


def stat(xs):
    a = np.asarray(xs, float)
    n = len(a)
    m = float(a.mean())
    se = float(a.std(ddof=1) / np.sqrt(n)) if n > 1 else float("nan")
    return m, se, (m / se if se and se > 0 else float("nan"))


def main():
    out = {}
    for d in DMODELS:
        rows = [r for r in (load(d, s) for s in SEEDS) if r is not None]
        if not rows:
            continue
        b = [r["eval"]["base"] for r in rows]
        dd = [x["small_payload"] - x["small_struct"] for x in b]
        dw = [x["width_payload"] - x["width_struct"] for x in b]
        m, se, t = stat(dd)
        out[d] = {
            "n": len(rows), "seeds": [r["seed"] for r in rows],
            "acc_payload": [x["acc_payload"] for x in b],
            "ce_payload": [x["ce_payload"] for x in b],
            "instr_valid": [x["instr_valid"] for x in b],
            "small_struct": [x["small_struct"] for x in b],
            "small_payload": [x["small_payload"] for x in b],
            "width_struct": [x["width_struct"] for x in b],
            "width_payload": [x["width_payload"] for x in b],
            "d": dd, "d_mean": m, "d_se": se, "d_t": t,
            "n_neg": int(sum(x < 0 for x in dd)),
            "dw_mean": float(np.mean(dw)),
            "nparam": rows[0]["nparam"],
        }

    with open(os.path.join(D, "q4b_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print(f"\n{'d_model':>7} {'n':>2} {'acc_pl':>7} {'CE_pl':>7} {'instr':>6} "
          f"{'sm_st':>6} {'sm_pl':>6} {'Δ':>7} {'se':>6} {'t':>7} {'Δ<0':>4} "
          f"{'wid_st':>7} {'wid_pl':>7} {'widΔ':>7} {'nparam':>8}")
    for d in DMODELS:
        if d not in out:
            continue
        r = out[d]
        print(f"{d:>7} {r['n']:>2} {np.mean(r['acc_payload']):>7.4f} "
              f"{np.mean(r['ce_payload']):>7.4f} {np.mean(r['instr_valid']):>6.3f} "
              f"{np.mean(r['small_struct']):>6.3f} {np.mean(r['small_payload']):>6.3f} "
              f"{r['d_mean']:>+7.3f} {r['d_se']:>6.3f} {r['d_t']:>+7.2f} "
              f"{r['n_neg']}/{r['n']} "
              f"{np.mean(r['width_struct']):>7.1f} {np.mean(r['width_payload']):>7.1f} "
              f"{r['dw_mean']:>+7.1f} {r['nparam']:>8d}")

    print("\nper-seed Δ:")
    for d in DMODELS:
        if d in out:
            print(f"  d{d:<3} " + " ".join(f"{x:+.3f}" for x in out[d]["d"]) +
                  f"   (seeds {out[d]['seeds']})")

    print("\n対応差（共通 seed）:")
    for a, b in [(96, 80), (80, 64)]:
        if a not in out or b not in out:
            continue
        sa = dict(zip(out[a]["seeds"], out[a]["d"]))
        sb = dict(zip(out[b]["seeds"], out[b]["d"]))
        common = sorted(set(sa) & set(sb))
        if len(common) < 2:
            continue
        diff = np.array([sa[s] - sb[s] for s in common])
        m, se, t = stat(diff)
        print(f"  d{a} − d{b}: Δ {m:+.3f}  se {se:.3f}  t {t:+.2f}  "
              f"負 {int((diff<0).sum())}/{len(common)}")


if __name__ == "__main__":
    main()
    sys.exit(0)
