# -*- coding: utf-8 -*-
"""audit_20261024.py — 2026-10-24 に作成された検証ファイル群の独立再計算

A. measure_bpb.py の bpt を再現（トークナイザのみ、モデル不要）
B. verify_replica_shared_contention.py の I を再現 + トレース単位ブートストラップ
C. simulate_r2_offload.py の転送バイト・層重みを再計算
D. TV 統計の構造（T>0 の割合 = prefix が語彙に存在する割合）をトークナイザのみで確認
"""
import os, sys, glob, json, math
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
out = {}

# ---------------- A. bpt ----------------
def get_text_samples():
    en_files = sorted(glob.glob(os.path.join(HERE, "english_version", "**", "*.md"), recursive=True))
    if not en_files:
        en_files = sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True))
    en_text = ""
    for f in en_files:
        try:
            en_text += open(f, encoding="utf-8").read() + "\n\n"
        except Exception:
            pass
        if len(en_text.encode("utf-8")) > 150000:
            break
    ja_files = [f for f in sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True)) if "english_version" not in f]
    ja_text = ""
    for f in ja_files:
        try:
            ja_text += open(f, encoding="utf-8").read() + "\n\n"
        except Exception:
            pass
        if len(ja_text.encode("utf-8")) > 150000:
            break
    en_b = en_text.encode("utf-8")[:32768]
    ja_b = ja_text.encode("utf-8")[:32768]
    return {"en": en_b.decode("utf-8", errors="ignore"),
            "ja": ja_b.decode("utf-8", errors="ignore"),
            "en_first": os.path.basename(en_files[0]) if en_files else None,
            "ja_first": os.path.basename(ja_files[0]) if ja_files else None}

from transformers import AutoTokenizer
texts = get_text_samples()
print("[A] corpus: EN first file =", texts["en_first"], "| JA first file =", texts["ja_first"])
print("[A] corpus bytes: EN=%d JA=%d" % (len(texts["en"].encode()), len(texts["ja"].encode())))

A = {}
for name, sub in [("qwen3-0.6b", "qwen3-0.6b"), ("smollm-135m", "smollm-135m")]:
    p = os.path.join(HERE, "models", sub)
    if not os.path.isdir(p):
        print("[A] missing", p); continue
    tok = AutoTokenizer.from_pretrained(p, local_files_only=True)
    A[name] = {}
    for lang in ["en", "ja"]:
        ids = tok(texts[lang], add_special_tokens=False)["input_ids"][:1536]
        dec = tok.decode(ids, clean_up_tokenization_spaces=False)
        nb = len(dec.encode("utf-8"))
        A[name][lang] = {"tokens": len(ids), "bytes_full1536": nb, "bpt": nb / len(ids),
                         "bytes_covered_of_32768": nb / 32768.0}
        print("[A] %-12s %s  tok=%d bytes=%d bpt=%.4f  (32KB中 %.1f%% しか見ていない)"
              % (name, lang, len(ids), nb, nb / len(ids), 100 * nb / 32768))
out["A_bpt"] = A

# ---------------- B. contention I ----------------
SIM_DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
TR = os.path.join(SIM_DIR, "data", "cache_traces")
E = 8
W_MAP = {"U+LB": [256]*8, "U+noLB": [256]*8,
         "H+LB": [64,64,192,192,320,320,448,448],
         "H+noLB": [64,64,192,192,320,320,448,448],
         "H+shared": [64,64,192,192,320,320,448,448]}

def load(arm, seed, task):
    f = os.path.join(TR, "%s_s%d_%s.npy" % (arm, seed, task))
    return np.load(f).astype(np.int32) if os.path.exists(f) else None

def slot_counts(tr_list, ws):
    L = tr_list[0].shape[0]
    tot = np.zeros(L * E)
    for tr in tr_list:
        layers = np.arange(L, dtype=np.int32) * E
        slot = (tr + layers.reshape(-1, 1, 1)).reshape(-1)
        tot += np.bincount(slot, minlength=L * E)
    return tot

B = {}
print("\n[B] contention I = N_slots * max(p*w) / sum(p*w)")
for arm in W_MAP:
    trs = [load(arm, s, t) for s in (0,1,2) for t in ("task0","task1","task2")]
    trs = [t for t in trs if t is not None]
    if not trs:
        print("[B] no trace for", arm); continue
    ws = np.asarray(W_MAP[arm], float)
    L = trs[0].shape[0]
    tot = slot_counts(trs, ws)
    p = tot / tot.sum()
    w_slot = np.tile(ws, L)
    load_e = p * w_slot
    I = len(p) * load_e.max() / load_e.sum()
    # bootstrap over the 9 traces
    boots = []
    for _ in range(4000):
        idx = np.random.randint(0, len(trs), len(trs))
        t2 = slot_counts([trs[i] for i in idx], ws)
        p2 = t2 / t2.sum()
        l2 = p2 * w_slot
        boots.append(len(p2) * l2.max() / l2.sum())
    boots = np.array(boots)
    # replica sweep R=2,3,4,8 (top-2 slots divided)
    rep = {}
    for R in (2,3,4,8):
        l3 = load_e.copy()
        top = np.argsort(-l3)[:2]
        l3[top] /= R
        rep[R] = float(len(p) * l3.max() / l3.sum())
    B[arm] = {"I": float(I), "I_lo": float(np.percentile(boots,2.5)), "I_hi": float(np.percentile(boots,97.5)),
              "n_slots": int(len(p)), "n_layers": int(L), "max_p": float(p.max()),
              "ratio_max_over_mean": float(p.max()/(1.0/len(p))),
              "replica": rep}
    print("[B] %-9s I=%6.3f  95%%CI=[%.3f, %.3f]  slots=%d layers=%d  p_max/p_mean=%.2f"
          % (arm, I, B[arm]["I_lo"], B[arm]["I_hi"], len(p), L, B[arm]["ratio_max_over_mean"]))
    print("      replica(top-2): " + "  ".join("R=%d:%.3f" % (k, v) for k, v in rep.items()))
out["B_contention"] = B

# ---------------- C. offload arithmetic ----------------
print("\n[C] offload arithmetic")
d, nE, nL = 4096, 8, 32
w_u = np.array([14336]*nE, float)
w_h = np.array([4096,6963,9830,12697,15564,18431,21298,25809], float)
p_h = np.array([0.34,0.24,0.14,0.10,0.07,0.05,0.03,0.03]); p_h /= p_h.sum()
par_u = 3*d*w_u; par_h = 3*d*w_h
print("[C] sum(w_h)=%d  == 8*14336=%d  -> %s" % (w_h.sum(), 8*14336, w_h.sum()==8*14336))
for budget in (4.0, 8.0):
    lb = budget*1e9/nL
    # uniform: 4bit
    bu = par_u*0.5
    res_u, cur = [], 0.0
    for i in range(nE):
        if cur+bu[i] <= lb: res_u.append(i); cur += bu[i]
    # hmoe: fp8 resident, int2 host
    res_h, cur = [], 0.0
    bh = np.where(np.arange(nE)[:,None] >= 0, 0.0, 0.0)
    bh = np.zeros(nE)
    for i in range(nE):
        if cur + par_h[i]*1.0 <= lb:
            res_h.append(i); cur += par_h[i]*1.0; bh[i] = par_h[i]*1.0
        else:
            bh[i] = par_h[i]*0.25
    print("[C] budget=%.0fGB layer_budget=%.1fMB | uniform resident=%d/8 (p=%.3f) | hmoe resident=%d/8 (p=%.3f)"
          % (budget, lb/1e6, len(res_u), 1.0*np.array([i in res_u for i in range(nE)]).sum()/nE,
             len(res_h), p_h[res_h].sum()))
    print("    HMoE layer weight: resident FP8=%.1fMB + host INT2=%.1fMB = %.1fMB (vs uniform 4bit %.1fMB, %.1f%%)"
          % (sum(bh[i] for i in res_h)/1e6, sum(bh[i] for i in range(nE) if i not in res_h)/1e6,
             bh.sum()/1e6, bu.sum()/1e6, 100*bh.sum()/bu.sum()))
    # B=1 transfer
    pu = np.minimum(1.0, (1.0/nE)*2); ph = np.minimum(1.0, p_h*2)
    host_u = [i for i in range(nE) if i not in res_u]
    host_h = [i for i in range(nE) if i not in res_h]
    tu = sum(pu*bu[i] for i in host_u)/1e6
    th = sum(ph[i]*bh[i] for i in host_h)/1e6
    # uniform with the SAME precision allocation (fp8 resident / int2 host)
    bu2 = np.zeros(nE)
    cur, res_u2 = 0.0, []
    for i in range(nE):
        if cur + par_u[i]*1.0 <= lb: res_u2.append(i); cur += par_u[i]*1.0; bu2[i] = par_u[i]*1.0
        else: bu2[i] = par_u[i]*0.25
    tu2 = sum(pu*bu2[i] for i in range(nE) if i not in res_u2)/1e6
    print("    B=1 transfer: uniform(4bit)=%.1fMB  hmoe=%.1fMB  ratio=%.2fx" % (tu, th, tu/th))
    print("    B=1 transfer: uniform(SAME fp8/int2 alloc)=%.1fMB  -> ratio vs hmoe=%.2fx  (精度配分の寄与を分離)"
          % (tu2, tu2/th))
    out.setdefault("C_offload", {})["budget%.0f" % budget] = {
        "uniform_4bit_MB": tu, "hmoe_MB": th, "ratio": tu/th,
        "uniform_same_precision_MB": tu2, "ratio_same_precision": tu2/th,
        "hmoe_layer_weight_MB": float(bh.sum()/1e6), "uniform_layer_weight_MB": float(bu.sum()/1e6)}

# ---------------- D. TV structure: fraction of prefixes that exist in vocab ----------------
print("\n[D] TV 統計の構造 (T>0 になる (pos,j) の割合) — トークナイザのみ")
def bytes_to_unicode():
    bs = (list(range(ord("!"), ord("~")+1)) + list(range(ord("\u00a1"), ord("\u00ac")+1))
          + list(range(ord("\u00ae"), ord("\u00ff")+1)))
    cs = bs[:]; n = 0
    for b in range(256):
        if b not in bs:
            bs.append(b); cs.append(256+n); n += 1
    return {chr(c): b for b, c in zip(bs, cs)}
U2B = bytes_to_unicode()
def tok_bytes(s):
    o = bytearray()
    for ch in s:
        b = U2B.get(ch)
        if b is None: return s.encode("utf-8", "ignore")
        o.append(b)
    return bytes(o)

D = {}
for name in ["qwen3-0.6b", "smollm-135m"]:
    p = os.path.join(HERE, "models", name)
    if not os.path.isdir(p): continue
    tok = AutoTokenizer.from_pretrained(p, local_files_only=True)
    vocab = tok.get_vocab()
    keys = set(tok_bytes(s) for s in vocab)
    D[name] = {}
    for lang in ["en", "ja"]:
        ids = tok(texts[lang], add_special_tokens=False)["input_ids"][:1536]
        tot = 0; exist = 0; jcount = {}; jsat = {}
        for tid in ids:
            s = tok.convert_ids_to_tokens(tid)
            if s is None: continue
            b = tok_bytes(s)
            if len(b) < 2: continue
            for j in range(1, len(b)):
                tot += 1
                jcount[j] = jcount.get(j, 0) + 1
                if b[:j] in keys:
                    exist += 1; jsat[j] = jsat.get(j, 0) + 1
        D[name][lang] = {"pairs": tot, "T_possible": exist, "frac": exist/tot if tot else 0,
                         "by_j": {j: (jsat.get(j,0), jcount[j]) for j in sorted(jcount)}}
        print("[D] %-12s %s  (pos,j) pairs=%d  prefix exists in vocab=%d (%.1f%%)  -> 残りは T=0 で TV=0"
              % (name, lang, tot, exist, 100*exist/tot))
        print("    j別 存在率: " + " ".join("j%d:%d/%d" % (j, a, b) for j, (a, b) in D[name][lang]["by_j"].items()))
out["D_tv_structure"] = D

with open(os.path.join(HERE, "audit_20261024_results.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, indent=2, ensure_ascii=False)
print("\nsaved audit_20261024_results.json")
