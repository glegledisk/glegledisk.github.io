"""チャンクファイル方式の並列ダウンローダ（HF・大ファイル向け）。

背景: 同一ファイルへの並列オフセット書き込みは、サンドボックスの書き込み監視と
相性が悪く、ごく稀に余分なバイトが挿入されてデータがシフトする事故が起きた
（sha256 不一致・テンソル内 NaN として顕在化）。
そこで「各チャンクを独立ファイルへ順次書き込み → 順番に結合」する方式に変える。
シークも・同一ファイルへの並行書き込みも行わない。

使い方:
  python _dl_chunks.py <repo_id> <out_dir> [--threads 8] [--chunk-mb 32] [--force]
"""
import argparse
import hashlib
import os
import sys
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed

BASE = "https://huggingface.co"


def fetch_chunk(url, start, end, part_path):
    want = end - start + 1
    for attempt in range(6):
        try:
            req = urllib.request.Request(url, headers={"Range": "bytes=%d-%d" % (start, end)})
            with urllib.request.urlopen(req, timeout=300) as r, open(part_path, "wb") as fp:
                remaining = want
                while remaining > 0:
                    b = r.read(min(1 << 20, remaining))
                    if not b:
                        break
                    fp.write(b)
                    remaining -= len(b)
            got = os.path.getsize(part_path)
            if got == want:
                return start, end, True
            print("  retry %s [%d,%d] got %d want %d" % (os.path.basename(part_path), start, end, got, want),
                  file=sys.stderr, flush=True)
        except Exception as e:
            print("  retry %s [%d,%d] %r" % (os.path.basename(part_path), start, end, e),
                  file=sys.stderr, flush=True)
        time.sleep(2.0 * (attempt + 1))
    return start, end, False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("repo")
    ap.add_argument("outdir")
    ap.add_argument("--threads", type=int, default=8)
    ap.add_argument("--chunk-mb", type=int, default=32)
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--files", nargs="*", default=None)
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    from huggingface_hub import HfApi
    api = HfApi()
    info = api.model_info(args.repo, files_metadata=True)
    targets = []
    for s in info.siblings:
        if s.rfilename.endswith((".gitattributes", ".md", ".png", ".jpg")):
            continue
        if args.files and s.rfilename not in args.files:
            continue
        if s.size:
            targets.append((s.rfilename, s.size))
    if not targets:
        print("no files", file=sys.stderr)
        return 1

    chunk = args.chunk_mb * 1024 * 1024
    total_bytes = sum(sz for _, sz in targets)
    print("total %.2f GB, chunk %d MB, threads %d" % (total_bytes / 1024 ** 3, args.chunk_mb, args.threads), flush=True)
    t0 = time.time()
    done = 0
    for fname, size in targets:
        out = os.path.join(args.outdir, fname)
        url = "%s/%s/resolve/main/%s" % (BASE, args.repo, fname)
        pdir = os.path.join(args.outdir, "_parts_" + fname)
        if args.force and os.path.isdir(pdir):
            for p in os.listdir(pdir):
                try:
                    os.remove(os.path.join(pdir, p))
                except Exception:
                    pass
        os.makedirs(pdir, exist_ok=True)
        ranges = [(s, min(s + chunk - 1, size - 1)) for s in range(0, size, chunk)]
        todo = []
        for (s, e) in ranges:
            part = os.path.join(pdir, "p%012d" % s)
            if os.path.exists(part) and os.path.getsize(part) == (e - s + 1):
                continue
            todo.append((s, e, part))
        print("  %-40s %6.2f GB  (%d/%d chunks to fetch)"
              % (fname, size / 1024 ** 3, len(todo), len(ranges)), flush=True)
        if todo:
            with ThreadPoolExecutor(args.threads) as ex:
                futs = [ex.submit(fetch_chunk, url, s, e, p) for (s, e, p) in todo]
                for f in as_completed(futs):
                    s, e, ok = f.result()
                    if not ok:
                        print("FAILED chunk %s [%d,%d]" % (fname, s, e), file=sys.stderr, flush=True)
                        return 1
        # 結合（順次書き込み・シークなし）
        with open(out, "wb") as w:
            for (s, e) in ranges:
                part = os.path.join(pdir, "p%012d" % s)
                with open(part, "rb") as r:
                    while True:
                        b = r.read(1 << 22)
                        if not b:
                            break
                        w.write(b)
        if os.path.getsize(out) != size:
            print("SIZE MISMATCH %s %d != %d" % (fname, os.path.getsize(out), size), file=sys.stderr)
            return 1
        exp = None
        for s in info.siblings:
            if s.rfilename == fname:
                exp = (s.lfs or {}).get("sha256") or getattr(s, "sha256", None)
        if exp:
            h = hashlib.sha256()
            with open(out, "rb") as fp:
                while True:
                    b = fp.read(1 << 22)
                    if not b:
                        break
                    h.update(b)
            got = h.hexdigest()
            print("      sha256 %s" % ("OK" if got == exp else "MISMATCH got=%s exp=%s" % (got[:16], exp[:16])), flush=True)
            if got != exp:
                return 1
        done += size
        el = time.time() - t0
        print("  done %-38s total %5.1f%%  %5.1f MB/s" % (fname, 100.0 * done / total_bytes, done / 1e6 / max(el, 1e-6)), flush=True)
    print("DONE %s" % args.outdir, flush=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
