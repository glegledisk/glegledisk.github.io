# -*- coding: utf-8 -*-
"""_ax3_diag.py — AX3 の C6 校正不合格の原因を切り分ける事後診断（探索的）。

C6 は設計書で「permutation 後の Spearman 絶対値の最大 < 0.15」を合格条件にした。
本番では ridge 0.375 / MLP 0.468 で不合格だった。ここでは
  (1) Y の行を 200 通り並べ替えた帰無分布を作り、観測値の分位を出す
  (2) W の行を並べ替えた（Y はそのまま）リーク対照を測る
  (3) 予測器の R2 が並べ替え前後とも負であることを確認する
ことで、「リーク」か「32 列 × 2 モデルの最大値に対する閾値設計不良」かを判定する。

**この結果は確認的結論（W1/W2/W3/case）には一切使わない。C6 は不合格のまま記録する。**
使い方: python _ax3_diag.py
"""
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
NPERM = 200
SEED = 2000
OUT_JSON = os.path.join(HERE, "_ax3_diag.json")
OUT_TXT = os.path.join(HERE, "_ax3_diag_out_utf8.txt")


def spearman(a, b):
    ra = np.argsort(np.argsort(a)).astype(np.float64)
    rb = np.argsort(np.argsort(b)).astype(np.float64)
    ra -= ra.mean()
    rb -= rb.mean()
    den = np.sqrt((ra ** 2).sum() * (rb ** 2).sum())
    return float((ra * rb).sum() / den) if den > 0 else float("nan")


def ridge_loo(W, Y, lam=10.0):
    n = W.shape[0]
    pred = np.zeros_like(Y, dtype=np.float64)
    for f in range(n):
        tr = np.arange(n) != f
        Xtr, Xte = W[tr], W[f:f + 1]
        mu, sd = Xtr.mean(0), Xtr.std(0) + 1e-8
        A, B = (Xtr - mu) / sd, (Xte - mu) / sd
        ym = Y[tr].mean(0)
        a = np.linalg.solve(A @ A.T + lam * np.eye(A.shape[0]), Y[tr] - ym)
        pred[f] = (B @ (A.T @ a) + ym)[0]
    return pred


def _init(layers, seed):
    rng = np.random.RandomState(seed)
    Ws = [rng.randn(layers[i], layers[i + 1]) * np.sqrt(2.0 / layers[i])
          for i in range(len(layers) - 1)]
    bs = [np.zeros(layers[i + 1]) for i in range(len(layers) - 1)]
    return Ws, bs


def _fwd(X, Ws, bs):
    acts, h = [X], X
    for i in range(len(Ws) - 1):
        h = np.maximum(h @ Ws[i] + bs[i], 0.0)
        acts.append(h)
    return h @ Ws[-1] + bs[-1], acts


def _bwd(acts, Ws, dout, wd=1e-4):
    n = acts[0].shape[0]
    gW = [None] * len(Ws)
    gb = [None] * len(Ws)
    g = dout
    for i in range(len(Ws) - 1, -1, -1):
        gW[i] = acts[i].T @ g / n + wd * Ws[i]
        gb[i] = g.mean(0)
        if i > 0:
            g = (g @ Ws[i].T) * (acts[i] > 0)
    return gW, gb


def mlp_loo(W, Y, epochs=250, lr=3e-3, wd=1e-4, patience=40, seed0=300):
    n, d = W.shape
    n_out = Y.shape[1]
    pred = np.zeros_like(Y, dtype=np.float64)
    layers = [d, 64, 32, n_out]
    for f in range(n):
        idx = np.where(np.arange(n) != f)[0]
        va = (np.arange(idx.size) % 4) == 0
        tr_idx, va_idx = idx[~va], idx[va]
        mu, sd = W[tr_idx].mean(0), W[tr_idx].std(0) + 1e-8
        A, V, T = (W[tr_idx] - mu) / sd, (W[va_idx] - mu) / sd, (W[f:f + 1] - mu) / sd
        ym, ys = Y[tr_idx].mean(0), Y[tr_idx].std(0) + 1e-8
        ya, yv = (Y[tr_idx] - ym) / ys, (Y[va_idx] - ym) / ys
        Ws, bs = _init(layers, seed0 + f)
        best_state = ([w.copy() for w in Ws], [b.copy() for b in bs])
        mW = [np.zeros_like(w) for w in Ws]
        vW = [np.zeros_like(w) for w in Ws]
        mb = [np.zeros_like(b) for b in bs]
        vb = [np.zeros_like(b) for b in bs]
        b1, b2, eps, best, bad = 0.9, 0.999, 1e-8, np.inf, 0
        for ep in range(1, epochs + 1):
            out, acts = _fwd(A, Ws, bs)
            gW, gb = _bwd(acts, Ws, 2.0 * (out - ya) / n_out, wd)
            for i in range(len(Ws)):
                mW[i] = b1 * mW[i] + (1 - b1) * gW[i]
                vW[i] = b2 * vW[i] + (1 - b2) * (gW[i] ** 2)
                Ws[i] -= lr * (mW[i] / (1 - b1 ** ep)) / (np.sqrt(vW[i] / (1 - b2 ** ep)) + eps)
                mb[i] = b1 * mb[i] + (1 - b1) * gb[i]
                vb[i] = b2 * vb[i] + (1 - b2) * (gb[i] ** 2)
                bs[i] -= lr * (mb[i] / (1 - b1 ** ep)) / (np.sqrt(vb[i] / (1 - b2 ** ep)) + eps)
            vo, _ = _fwd(V, Ws, bs)
            vl = float(((vo - yv) ** 2).mean())
            if np.isfinite(vl) and vl < best - 1e-12:
                best = vl
                best_state = ([w.copy() for w in Ws], [b.copy() for b in bs])
                bad = 0
            else:
                bad += 1
                if bad >= patience:
                    break
        Ws_b, bs_b = best_state
        pred[f] = _fwd(T, Ws_b, bs_b)[0][0] * ys + ym
    return pred


def stat_max(Yp, pr, pm):
    vals = []
    for pred in (pr, pm):
        for j in range(Yp.shape[1]):
            vals.append(abs(spearman(Yp[:, j], pred[:, j])))
    return float(max(vals))


def r2(Y, pred):
    return 1.0 - float(((Y - pred) ** 2).sum() / ((Y - Y.mean(0)) ** 2).sum())


def main():
    z = np.load(os.path.join(HERE, "ax3_transfer.npz"))
    with open(os.path.join(HERE, "ax3_transfer.json"), encoding="utf-8") as fp:
        J = json.load(fp)
    W, Y = z["W"].astype(np.float64), z["Y"].astype(np.float64)
    nw = W.shape[0]
    observed = float(J["calib"]["C6"]["max_abs_rho"])

    # (3) 並べ替え前の R2（リークがあれば正になるはず）
    pr0, pm0 = ridge_loo(W, Y), mlp_loo(W, Y)
    r2_before = {"ridge": r2(Y, pr0), "mlp": r2(Y, pm0)}

    # (2) W だけを並べ替えたリーク対照
    rng_w = np.random.RandomState(SEED + 9999)
    pw = rng_w.permutation(nw)
    pr_w, pm_w = ridge_loo(W[pw], Y), mlp_loo(W[pw], Y)
    wshuf = {"ridge_r2": r2(Y, pr_w), "mlp_r2": r2(Y, pm_w),
             "max_abs_rho": stat_max(Y, pr_w, pm_w)}

    # (1) Y の行を 200 通り並べ替えた帰無分布
    rng = np.random.RandomState(SEED)
    dist = []
    r2_perm = []
    for it in range(NPERM):
        p = rng.permutation(nw)
        Yp = Y[p]
        pr, pm = ridge_loo(W, Yp), mlp_loo(W, Yp)
        dist.append(stat_max(Yp, pr, pm))
        r2_perm.append({"ridge": r2(Yp, pr), "mlp": r2(Yp, pm)})
        if (it + 1) % 25 == 0:
            print("perm %d/%d  max|rho| so far %.4f" % (it + 1, NPERM, max(dist)), flush=True)
    dist = np.array(dist)
    p_emp = float((1 + (dist >= observed).sum()) / (NPERM + 1))
    out = {
        "note": "事後診断・探索的。C6 は設計書の閾値 0.15 に対して不合格のまま記録し、確認的結論には使わない。",
        "observed_max_abs_rho": observed,
        "design_threshold": 0.15,
        "n_statistics_per_permutation": 64,
        "n_permutations": NPERM,
        "null_mean": float(dist.mean()), "null_sd": float(dist.std(ddof=1)),
        "null_median": float(np.median(dist)),
        "null_p95": float(np.percentile(dist, 95)),
        "null_max": float(dist.max()),
        "empirical_p": p_emp,
        "observed_percentile": float((dist < observed).mean() * 100.0),
        "r2_before_shuffle": r2_before,
        "r2_perm_mean": {"ridge": float(np.mean([v["ridge"] for v in r2_perm])),
                         "mlp": float(np.mean([v["mlp"] for v in r2_perm]))},
        "W_shuffle_control": wshuf,
        "null_distribution": dist.tolist(),
    }
    verdict = ("多重比較（32 列 × 2 モデル = 64 統計量の最大値）に対する閾値設計不良。"
               "観測値は permutation 帰無分布の範囲内で、リークの証拠はない")
    if p_emp < 0.05:
        verdict = "観測値は帰無分布の上位 5% にあり、リークの可能性を否定できない。要調査"
    out["verdict"] = verdict
    with open(OUT_JSON, "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    lines = [
        "AX3 C6 事後診断（探索的・確認的結論には使わない）",
        "観測 max|rho| %.6f ＞ 設計閾値 0.15 → C6 は不合格のまま" % observed,
        "帰無分布: n=%d  mean %.4f  sd %.4f  median %.4f  p95 %.4f  max %.4f"
        % (NPERM, out["null_mean"], out["null_sd"], out["null_median"],
           out["null_p95"], out["null_max"]),
        "観測値の分位 %.1f パーセンタイル  empirical p = %.4f" % (out["observed_percentile"], p_emp),
        "R2（並べ替え前）: ridge %.4f / mlp %.4f" % (r2_before["ridge"], r2_before["mlp"]),
        "R2（Y perm 平均）: ridge %.4f / mlp %.4f" % (out["r2_perm_mean"]["ridge"], out["r2_perm_mean"]["mlp"]),
        "W シャッフル対照: max|rho| %.4f  R2 ridge %.4f / mlp %.4f"
        % (wshuf["max_abs_rho"], wshuf["ridge_r2"], wshuf["mlp_r2"]),
        "判定: %s" % verdict,
    ]
    txt = "\n".join(lines)
    print(txt)
    with open(OUT_TXT, "w", encoding="utf-8") as fp:
        fp.write(txt + "\n")


if __name__ == "__main__":
    main()
