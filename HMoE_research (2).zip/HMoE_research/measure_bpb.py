"""measure_bpb.py — 既存モデル（Qwen3-0.6B, SmolLM-135M）を用いた日英BPB実測検算

目的:
1. トークナイザ語彙組成による圧縮率 (bpt: bytes per token)
2. 1トークンあたりの予測エントロピー/Cross-Entropy (bits/token)
3. 1バイトあたりの真のモデル評価 (bpb: bits per byte)
4. per-byte FFN 仕事量の実測検算
"""

import os
import sys
import time
import math
import glob
import json
import torch
import numpy as np
from transformers import AutoTokenizer, AutoModelForCausalLM

os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["TOKENIZERS_PARALLELISM"] = "false"

HERE = os.path.dirname(os.path.abspath(__file__))

def get_text_samples():
    # 英語コーパス
    en_files = sorted(glob.glob(os.path.join(HERE, "english_version", "**", "*.md"), recursive=True))
    if not en_files:
        en_files = sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True))
    en_text = ""
    for f in en_files:
        try:
            with open(f, "r", encoding="utf-8") as fp:
                en_text += fp.read() + "\n\n"
        except Exception:
            pass
        if len(en_text.encode("utf-8")) > 150000:
            break
            
    # 日本語コーパス
    ja_files = [f for f in sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True)) if "english_version" not in f]
    ja_text = ""
    for f in ja_files:
        try:
            with open(f, "r", encoding="utf-8") as fp:
                ja_text += fp.read() + "\n\n"
        except Exception:
            pass
        if len(ja_text.encode("utf-8")) > 150000:
            break

    # 切り出し（約30KB〜50KB: CPUでサクッと回る規模）
    # UTF-8バイト境界で安全にスライス
    en_bytes = en_text.encode("utf-8")[:32768]
    ja_bytes = ja_text.encode("utf-8")[:32768]
    
    en_clean = en_bytes.decode("utf-8", errors="ignore")
    ja_clean = ja_bytes.decode("utf-8", errors="ignore")
    
    return {"en": en_clean, "ja": ja_clean}


def eval_model_bpb(model_dir, model_name, texts, max_tokens=2048, chunk_len=512):
    print(f"\n==========================================")
    print(f"Loading model: {model_name} from {model_dir}")
    print(f"==========================================")
    
    t0 = time.time()
    tokenizer = AutoTokenizer.from_pretrained(model_dir, local_files_only=True)
    # SmolLM等の場合、pad_tokenがないことがある
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id

    model = AutoModelForCausalLM.from_pretrained(
        model_dir,
        local_files_only=True,
        torch_dtype=torch.float32,
        low_cpu_mem_usage=True
    )
    model.eval()
    print(f"Model loaded in {time.time()-t0:.2f}s. Vocab size: {len(tokenizer)}")
    
    results = {}
    
    for lang in ["en", "ja"]:
        text = texts[lang]
        total_bytes = len(text.encode("utf-8"))
        
        # トークナイズ
        enc = tokenizer(text, return_tensors="pt", add_special_tokens=False)
        input_ids = enc["input_ids"][0]
        
        # 評価用トークン数（CPUの実行速度を考慮して最大max_tokens）
        eval_ids = input_ids[:max_tokens]
        eval_tokens_count = len(eval_ids)
        
        # 評価トークン列が表現する実際のバイト数を算出
        # decodeしてバイト長を正確に測る
        decoded_text = tokenizer.decode(eval_ids, clean_up_tokenization_spaces=False)
        eval_bytes = len(decoded_text.encode("utf-8"))
        
        bpt = eval_bytes / eval_tokens_count
        
        # ChunkごとにForwardしてCross Entropy (nats) を計算
        loss_fn = torch.nn.CrossEntropyLoss(reduction="sum")
        total_loss_nats = 0.0
        total_evaluated_tokens = 0
        
        t_fwd = time.time()
        with torch.no_grad():
            for s in range(0, eval_tokens_count - 1, chunk_len):
                chunk = eval_ids[s:s + chunk_len + 1].unsqueeze(0) # [1, L+1]
                if chunk.size(1) < 2:
                    break
                
                inputs = chunk[:, :-1]
                targets = chunk[:, 1:]
                
                outputs = model(inputs)
                logits = outputs.logits # [1, L, V]
                
                # loss計算
                loss = loss_fn(logits.view(-1, logits.size(-1)), targets.view(-1))
                total_loss_nats += loss.item()
                total_evaluated_tokens += targets.numel()
                
        fwd_time = time.time() - t_fwd
        
        # 指標計算
        mean_ce_nats = total_loss_nats / total_evaluated_tokens
        mean_ce_bits = mean_ce_nats / math.log(2.0) # bits per token
        
        # この評価対象トークンに対応するバイト数
        # targetsに対応するテキストバイト数
        target_text = tokenizer.decode(eval_ids[1:total_evaluated_tokens+1], clean_up_tokenization_spaces=False)
        target_bytes = len(target_text.encode("utf-8"))
        
        bpb = (total_loss_nats / math.log(2.0)) / target_bytes
        
        results[lang] = {
            "vocab_size": len(tokenizer),
            "tokens": total_evaluated_tokens,
            "bytes": target_bytes,
            "bpt": target_bytes / total_evaluated_tokens, # bytes per token
            "ce_nats_per_token": mean_ce_nats,
            "ce_bits_per_token": mean_ce_bits,
            "bpb": bpb,
            "fwd_time_sec": fwd_time,
            "tokens_per_sec": total_evaluated_tokens / fwd_time
        }
        
        print(f"[{lang.upper()}] Tokens: {total_evaluated_tokens}, Bytes: {target_bytes}")
        print(f"  bpt: {results[lang]['bpt']:.3f} B/token")
        print(f"  CE:  {results[lang]['ce_bits_per_token']:.3f} bits/token ({results[lang]['ce_nats_per_token']:.3f} nats)")
        print(f"  BPB: {results[lang]['bpb']:.3f} bits/byte")
        print(f"  Speed: {results[lang]['tokens_per_sec']:.1f} tokens/s (took {fwd_time:.2f}s)")
        
    return results


def main():
    texts = get_text_samples()
    print(f"Corpus prepared: EN={len(texts['en'].encode('utf-8'))} bytes, JA={len(texts['ja'].encode('utf-8'))} bytes")
    
    models = [
        ("qwen3-0.6b", os.path.join(HERE, "models", "qwen3-0.6b")),
        ("smollm-135m", os.path.join(HERE, "models", "smollm-135m")),
    ]
    
    all_results = {}
    
    for name, path in models:
        if os.path.exists(path):
            # max_tokens=1536（CPUで数分以内に確実に完了するサイズ）
            all_results[name] = eval_model_bpb(path, name, texts, max_tokens=1536, chunk_len=512)
        else:
            print(f"[skip] {name} not found at {path}")
            
    # 比較まとめ出力
    out_file = os.path.join(HERE, "bpb_verification_results.json")
    with open(out_file, "w", encoding="utf-8") as fp:
        json.dump(all_results, fp, indent=2, ensure_ascii=False)
        
    print(f"\nSaved results to {out_file}")

if __name__ == "__main__":
    main()
