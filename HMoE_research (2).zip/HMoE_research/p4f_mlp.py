"""
P4f: 非線形 probe（小型 MLP, numpy 実装）

P4 の線形 probe では d_j が AUC 0.55 だった。§5 の計算から **1.4 倍（AUC ~0.65）** で
均一配分を逆転できる。MLP でそこに届くかを測る。

実装: numpy のみ（sklearn なし）。Adam + weight decay + early stopping（fold 内 validation）。
CV: 窓単位 5 分割（隣接トークンの漏れを防ぐ）。

比較:
  ridge（P4 の線形） / MLP / 最良の単一特徴（P4e の機構的特徴）
"""

import json
import os

import numpy as np

from p4b_probe import auc_score, build_features, cv_predict, spearman
from p4e_mech import layer_feats

HERE = os.path.dirname(os.path.abspath(__file__))
N_FOLD = 5


# ---------------- MLP ----------------

def _standardize(Xtr, Xte):
    mu = Xtr.mean(0)
    sd = Xtr.std(0) + 1e-8
    return (Xtr - mu) / sd, (Xte - mu) / sd


def _init(layers, seed):
    rng = np.random.RandomState(seed)
    Ws, bs = [], []
    for i in range(len(layers) - 1):
        fan_in = layers[i]
        Ws.append(rng.randn(layers[i], layers[i + 1]) * np.sqrt(2.0 / fan_in))
        bs.append(np.zeros(layers[i + 1]))
    return Ws, bs


def _forward(X, Ws, bs):
    acts = [X]
    h = X
    for i in range(len(Ws) - 1):
        h = h @ Ws[i] + bs[i]
        h = np.maximum(h, 0.0)
        acts.append(h)
    out = h @ Ws[-1] + bs[-1]
    return out.ravel(), acts


def _backward(acts, Ws, dout, wd):
    n = acts[0].shape[0]
    gW = [None] * len(Ws)
    gb = [None] * len(Ws)
    g = dout[:, None]                       # (n,1)
    for i in range(len(Ws) - 1, -1, -1):
        gW[i] = acts[i].T @ g / n + wd * Ws[i]
        gb[i] = g.mean(0)
        if i > 0:
            g = (g @ Ws[i].T) * (acts[i] > 0)
    return gW, gb


def mlp_cv(X, y, groups, hidden=(64, 32), epochs=250, lr=3e-3, wd=1e-4,
           loss="mse", patience=40, seed=0):
    """窓単位 CV。各 fold 内で train/val に分けて early stopping。"""
    pred = np.zeros(len(y))
    hist = []
    for f in range(N_FOLD):
        te = (groups % N_FOLD) == f
        tr_all = ~te
        # fold 内 validation（train 側の 1/4。test と同じ modulo を使うと空になるので注意）
        idx = np.where(tr_all)[0]
        va_mask = (np.arange(idx.size) % 4) == 0
        tr_idx, va_idx = idx[~va_mask], idx[va_mask]

        mu = X[tr_idx].mean(0)
        sd = X[tr_idx].std(0) + 1e-8
        A = (X[tr_idx] - mu) / sd
        V = (X[va_idx] - mu) / sd
        T = (X[te] - mu) / sd

        ym, ys = y[tr_idx].mean(), y[tr_idx].std() + 1e-8
        ya = (y[tr_idx] - ym) / ys
        yv = (y[va_idx] - ym) / ys

        layers = [X.shape[1], hidden[0], hidden[1], 1]
        Ws, bs = _init(layers, seed + f)
        mW = [np.zeros_like(w) for w in Ws]
        vW = [np.zeros_like(w) for w in Ws]
        mb = [np.zeros_like(b) for b in bs]
        vb = [np.zeros_like(b) for b in bs]
        b1, b2, eps = 0.9, 0.999, 1e-8
        best = (np.inf, None, None)
        bad = 0
        for ep in range(1, epochs + 1):
            out, acts = _forward(A, Ws, bs)
            if loss == "mse":
                resid = out - ya
                dout = 2.0 * resid
                tr_loss = float((resid ** 2).mean())
            else:  # bce（y は 0/1）
                pr = 1.0 / (1.0 + np.exp(-np.clip(out, -30, 30)))
                dout = (pr - ya)
                tr_loss = float(-(ya * np.log(pr + 1e-9) + (1 - ya) * np.log(1 - pr + 1e-9)).mean())
            gW, gb = _backward(acts, Ws, dout, wd)
            for i in range(len(Ws)):
                mW[i] = b1 * mW[i] + (1 - b1) * gW[i]
                vW[i] = b2 * vW[i] + (1 - b2) * (gW[i] ** 2)
                Ws[i] -= lr * (mW[i] / (1 - b1 ** ep)) / (np.sqrt(vW[i] / (1 - b2 ** ep)) + eps)
                mb[i] = b1 * mb[i] + (1 - b1) * gb[i]
                vb[i] = b2 * vb[i] + (1 - b2) * (gb[i] ** 2)
                bs[i] -= lr * (mb[i] / (1 - b1 ** ep)) / (np.sqrt(vb[i] / (1 - b2 ** ep)) + eps)
            # validation
            vo, _ = _forward(V, Ws, bs)
            if loss == "mse":
                vl = float(((vo - yv) ** 2).mean())
            else:
                pv = 1.0 / (1.0 + np.exp(-vo))
                vl = float(-(yv * np.log(pv + 1e-9) + (1 - yv) * np.log(1 - pv + 1e-9)).mean())
            if not np.isfinite(vl):
                break
            if vl < best[0] - 1e-6:
                best = (vl, [w.copy() for w in Ws], [b.copy() for b in bs])
                bad = 0
            else:
                bad += 1
                if bad >= patience:
                    break
        Wb, bb = (best[1], best[2]) if best[1] is not None else (Ws, bs)
        po, _ = _forward(T, Wb, bb)
        pred[te] = po
        hist.append({"fold": f, "best_val": best[0], "epochs": ep, "train_loss": tr_loss})
    return pred, hist


# ---------------- 主 ----------------

def main():
    d = np.load(os.path.join(HERE, "p4_feats.npz"), allow_pickle=True)
    mech = np.load(os.path.join(HERE, "p4_mech_features.npz"))
    p3 = np.load(os.path.join(HERE, "p3_topk_nll.npz"))
    nll_j = p3["k8"]
    d_j = p3["k6"] - p3["k8"]
    ybin = (d_j > np.quantile(d_j, 0.75)).astype(np.float64)
    feats, win = build_features(d)
    n = d_j.size

    mech_all = np.stack([mech["avg_" + nm] for nm in
                         ["p1", "p7", "p8", "p9", "p7p8", "p8_over_p1", "p9_over_p8",
                          "z8_z9", "z6_z9", "mass8", "mass6", "lost_mass", "ent",
                          "zmax", "zstd", "zmean", "npos"]], axis=1)
    mech_l15 = np.stack([mech["L15_" + nm] for nm in
                         ["p1", "p7", "p8", "p9", "p7p8", "p8_over_p1", "p9_over_p8",
                          "z8_z9", "z6_z9", "mass8", "mass6", "lost_mass", "ent",
                          "zmax", "zstd", "zmean", "npos"]], axis=1)

    SETS = {
        "gate0": np.concatenate([feats["gate0"]], 1).astype(np.float64),
        "gate15": np.concatenate([feats["gate15"]], 1).astype(np.float64),
        "gate0+gate15": np.concatenate([feats["gate0"], feats["gate15"]], 1).astype(np.float64),
        "mech_all+hist": np.concatenate([mech_all, feats["hist"]], 1).astype(np.float64),
        "mech_L15+hist": np.concatenate([mech_l15, feats["hist"]], 1).astype(np.float64),
        "gate15+mech+hist": np.concatenate([feats["gate15"], mech_l15, feats["hist"]], 1).astype(np.float64),
        "ALL(l0)": np.concatenate([feats["gate0"], feats["gstat0"], feats["h0"], feats["hist"]], 1).astype(np.float64),
        "ALL(l15)": np.concatenate([feats["gate15"], mech_l15, feats["h15"], feats["hist"]], 1).astype(np.float64),
    }

    print("=== d_j の予測: ridge（線形） vs MLP（64-32, ReLU）===")
    print("target = d_j を標準化して MSE")
    print("%-20s %6s %8s %8s %8s" % ("features", "dim", "AUC(ridge)", "AUC(MLP)", "Δ"))
    out = {}
    preds = {}
    for name, X in SETS.items():
        r = cv_predict(X, d_j, win)
        m, hist = mlp_cv(X, d_j, win, hidden=(64, 32), epochs=250, lr=3e-3, wd=1e-4,
                         loss="mse", patience=40, seed=1)
        a_r = auc_score(ybin, r)
        a_m = auc_score(ybin, m)
        preds[name] = {"ridge": r, "mlp": m}
        out[name] = {"dim": int(X.shape[1]), "auc_ridge": a_r, "auc_mlp": a_m,
                     "spearman_mlp": spearman(m, d_j)}
        print("%-20s %6d %8.4f %8.4f %+8.4f" % (name, X.shape[1], a_r, a_m, a_m - a_r))

    # 最良の特徴で損失関数を変える
    best = max(out, key=lambda k: out[k]["auc_mlp"])
    print("\n=== 最良 (%s) で損失・深さを変える ===" % best)
    X = SETS[best]
    trials = []
    for loss, y in [("mse", d_j), ("bce", ybin)]:
        for hid in [(64, 32), (128, 64), (256, 128)]:
            m, _ = mlp_cv(X, y, win, hidden=hid, epochs=250, lr=3e-3, wd=1e-4,
                          loss=loss, patience=40, seed=2)
            a = auc_score(ybin, m)
            trials.append({"loss": loss, "hidden": hid, "auc": a})
            print("  loss=%-3s hidden=%-9s AUC %.4f" % (loss, str(hid), a))

    # 決定価値
    print("\n=== 決定価値（f=0.5, 予算 mean_k=7）===")
    print("  均一 top-7 = +0.01449 / ランダム = +0.02511 / oracle = −0.03803（実測）")
    def dv(score, f=0.5):
        m_ = int(round(f * n))
        keep = np.zeros(n, bool)
        keep[np.argsort(-score)[:m_]] = True
        return float(d_j[~keep].sum() / n)
    print("  ridge(ALL l0)      %+.5f" % dv(preds["ALL(l0)"]["ridge"]))
    print("  MLP(%s)         %+.5f" % (best, dv(preds[best]["mlp"])))
    for t in trials:
        pass

    res = {"best_features": best, "table": out, "trials": trials,
           "decision_value": {"ridge_ALLl0": dv(preds["ALL(l0)"]["ridge"]),
                              "mlp_best": dv(preds[best]["mlp"])}}
    with open(os.path.join(HERE, "p4_mlp_results.json"), "w", encoding="utf-8") as fp:
        json.dump(res, fp, ensure_ascii=False, indent=2, default=str)
    np.savez_compressed(os.path.join(HERE, "p4_mlp_preds.npz"),
                        **{("%s_mlp" % k): v["mlp"] for k, v in preds.items()},
                        **{("%s_ridge" % k): v["ridge"] for k, v in preds.items()},
                        d_j=d_j, nll_j=nll_j, win=win)
    print("\nsaved p4_mlp_results.json / p4_mlp_preds.npz")


if __name__ == "__main__":
    main()
