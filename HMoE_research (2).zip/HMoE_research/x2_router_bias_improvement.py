#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""X2: ルータバイアス介入と改善型編集の検証。

事前登録: `X2課題設計書_ルータバイアス介入と改善型編集の検証_20261107.md`。
腕・介入仕様・仮説・指標・MDE・校正条件はすべて実行前に固定。

対象: HMoE（H、W2 の 8 ckpt を流用、8 seed で paired）
腕 (12 腕): none, rb_supp_e0, rb_supp_e1, rb_boost_e0, rb_boost_e6, rb_mild_e0, rb_rand,
           imp_v_a005, imp_v_a050, imp_v_a200, imp_rand, oracle

出力: x2_results.json / x2_delta.npz / x2_analysis.json / x2_calib.json / x2_out_utf8.txt
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import q8_static_dispatch as Q8            # noqa: E402
import q2_difficulty_ladder as Q2          # noqa: E402
import e2b_rewrite_routing_fixed as E2     # noqa: E402
from e2b_rewrite_routing_fixed import RewriteMoE, WIDTHS  # noqa: E402
from w1_local_edit_absorption import selection_change  # noqa: E402

assert E2.SEQ == 128, "Q2 の import が E2.SEQ を設定していない"

W2DIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "w2")
X1BDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "x1b")

W_H = tuple(WIDTHS["H+LB"])
ARMS = (
    "none",
    "rb_supp_e0",
    "rb_supp_e1",
    "rb_boost_e0",
    "rb_boost_e6",
    "rb_mild_e0",
    "rb_rand",
    "imp_v_a005",
    "imp_v_a050",
    "imp_v_a200",
    "imp_rand",
    "oracle",
)
SEEDS = (0, 1, 2, 3, 4, 5, 6, 7)
N_EVAL, EVAL_SEED = 1024, 777
SPAN = Q2.T_LEN - Q2.TRACE0
CAL_FIELDS = ("ce_all", "instr_valid", "acc_payload", "ce_payload", "width_struct")


# ---------------------------------------------------------------------------
# forward & evaluate
# ---------------------------------------------------------------------------
def forward_generic(model, idx, typ=None, k=2):
    p = model.p
    B, T = idx.shape
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    aux_sum = torch.zeros(())
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    idx_l = []
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
        topv, topi = logits.topk(k, dim=1)
        gate = torch.softmax(
            torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
        y = torch.zeros_like(h)
        for i in range(model.E):
            tok, _ = (topi == i).nonzero(as_tuple=True)
            if tok.numel() == 0:
                continue
            x_tok = h[tok]
            h1 = F.relu(F.linear(x_tok, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
            y.index_add_(0, tok,
                         F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                         * gate[tok, i].unsqueeze(1))
        top1 = topi[:, 0]
        f = torch.zeros(model.E, dtype=logits.dtype)
        f.scatter_add_(0, top1, torch.ones_like(top1, dtype=f.dtype))
        f = f / h.shape[0]
        P = torch.softmax(logits, dim=1).mean(0)
        dims = torch.tensor(model.dims, dtype=f.dtype)
        aux = model.E * (f * P * (dims / dims.mean())).sum()
        h = h + y
        aux_sum = aux_sum + aux
        idx_l.append(topi.reshape(B, T, k))
    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, -1)
    return out, aux_sum / model.L, idx_l


@torch.no_grad()
def evaluate_generic(model, seq, typ, k=2, bs=128):
    n, L, E = seq.shape[0], model.L, model.E
    dims = np.array(model.dims, dtype=np.float32)
    ce = np.zeros((n, SPAN), dtype=np.float32)
    hit = np.zeros((n, SPAN), dtype=bool)
    wid = np.zeros((n, SPAN), dtype=np.float32)
    top1_l = np.zeros((L, n, SPAN), dtype=np.int64)
    topi_store = [np.zeros((n, Q2.T_LEN, k), dtype=np.int8) for _ in range(L)]
    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = torch.from_numpy(seq[s])
        t_batch = torch.from_numpy(typ[s])
        logits, _, idx_l = forward_generic(model, x, typ=t_batch, k=k)
        lg = logits[:, Q2.TRACE0 - 1:-1, :len(Q2.VOCAB)]
        tgt = torch.from_numpy(seq[s, Q2.TRACE0:])
        lp = F.cross_entropy(lg.reshape(-1, len(Q2.VOCAB)), tgt.reshape(-1),
                             reduction="none").reshape(-1, SPAN)
        ce[s] = lp.numpy()
        pred = lg.argmax(-1).numpy()
        hit[s] = (pred == seq[s, Q2.TRACE0:])
        for l in range(L):
            a = idx_l[l].numpy()
            topi_store[l][s] = a.astype(np.int8)
            aa = a[:, Q2.TRACE0 - 1:-1, :]
            top1_l[l][s] = aa[:, :, 0]
            wid[s] += dims[aa].mean(-1) / L

    ty = typ[:, Q2.TRACE0:]
    m_st, m_pl = (ty == Q2.TYP_STRUCT), (ty == Q2.TYP_PAYLOAD)
    u_l0 = np.bincount(top1_l[0].reshape(-1), minlength=E)
    hp = hit.reshape(n, Q2.P_STEPS, Q2.TPI)[:, :, 2:]
    instr_ok = hp.all(-1)
    metrics = {
        "ce_all": float(ce.mean()),
        "ce_struct": float(ce[m_st].mean()),
        "ce_payload": float(ce[m_pl].mean()),
        "acc_struct": float(hit[m_st].mean()),
        "acc_payload": float(hit[m_pl].mean()),
        "width_struct": float(wid[m_st].mean()),
        "width_payload": float(wid[m_pl].mean()),
        "small_struct": float(np.isin(top1_l[-1][m_st], Q2.SMALL).mean()),
        "small_payload": float(np.isin(top1_l[-1][m_pl], Q2.SMALL).mean()),
        "usage_l0": u_l0.tolist(),
        "usage_entropy": Q8.usage_entropy(u_l0),
        "usage_share_max": float(u_l0.max() / max(1.0, u_l0.sum())),
        "dead_experts": int(np.sum((u_l0 / max(1.0, u_l0.sum())) < 0.01)),
        "instr_valid": float(instr_ok.all(-1).mean()),
        "instr_acc": float(instr_ok.mean()),
        "payload_token_acc": float(hp.mean()),
        "n_eval": int(n),
    }
    extras = {
        "instr_seq": instr_ok.all(-1).astype(np.int8),
        "ce_seq": ce.mean(1).astype(np.float64),
        "topi": topi_store,
        "usage_by_layer": [np.bincount(top1_l[l].reshape(-1), minlength=E)
                           for l in range(L)],
    }
    return metrics, extras


def build_model(seed):
    return RewriteMoE(W_H, seed=seed, topk=2)


def load_dict(path):
    return torch.load(path, map_location="cpu")


def fresh(model, clean):
    model.p = {k: v.clone() for k, v in clean.items()}
    for k in model.p:
        model.p[k].requires_grad_(False)
    return model


def load_arch(seed):
    path = os.path.join(W2DIR, f"ckpt_H_s{seed}.pt")
    td = load_dict(path)
    model = build_model(seed)
    assert set(td.keys()) == set(model.p.keys())
    clean = {k: v.detach().clone() for k, v in td.items()}
    return model, clean


# ---------------------------------------------------------------------------
# 誤差方向 v の抽出（Exp 8 型）
# ---------------------------------------------------------------------------
def extract_error_direction(clean, seq, typ, seed):
    """baseline forward から失敗系列と成功系列の層 0 隠れ状態差 v を抽出。"""
    model = build_model(seed)
    fresh(model, clean)
    n = seq.shape[0]
    p = model.p
    x = torch.from_numpy(seq)
    t = torch.from_numpy(typ)
    with torch.no_grad():
        logits, _, _ = forward_generic(model, x, typ=t, k=2)
        pred = logits[:, Q2.TRACE0 - 1:-1, :len(Q2.VOCAB)].argmax(-1).numpy()
        hit = (pred == seq[:, Q2.TRACE0:])
        instr_ok = hit.reshape(n, Q2.P_STEPS, Q2.TPI)[:, :, 2:].all(-1)
        seq_ok = instr_ok.all(-1)

    B, T = x.shape
    h = p["emb.w"][x] + p["pos.w"][:T].unsqueeze(0)
    h_flat = h.reshape(B * T, -1)

    trace_mask = np.zeros((B, T), dtype=bool)
    trace_mask[:, Q2.TRACE0:] = True
    trace_flat = trace_mask.reshape(-1)

    fail_flat = np.repeat(~seq_ok, T) & trace_flat
    succ_flat = np.repeat(seq_ok, T) & trace_flat

    if succ_flat.sum() == 0 or fail_flat.sum() == 0:
        # フォールバック
        v = torch.randn(128, generator=torch.Generator().manual_seed(1000 + seed))
        v = v / v.norm()
    else:
        v0 = h_flat[fail_flat].mean(0) - h_flat[succ_flat].mean(0)
        norm = float(v0.norm())
        v = (v0 / norm) if norm > 1e-12 else torch.randn(128)
        v = v / v.norm()

    # 直交するランダム方向 v_rand
    rng = torch.Generator().manual_seed(5000 + seed)
    vr = torch.randn(128, generator=rng)
    vr = vr - float(v @ vr) * v
    vr = vr / vr.norm()
    assert abs(float(v @ vr)) < 1e-6, "v と v_rand の直交性違反"
    return v, vr, int(seq_ok.sum()), int((~seq_ok).sum())


# ---------------------------------------------------------------------------
# 介入の適用
# ---------------------------------------------------------------------------
def apply_intervention(model, clean, arm, v, v_rand, seed):
    fresh(model, clean)
    p = model.p
    info = {"arm": arm, "seed": seed, "params_changed": 0, "alpha": 0.0}

    if arm == "none":
        return info

    # --- ルータバイアス介入群 ---
    if arm == "rb_supp_e0":
        p["l0.r.b"][0] -= 2.0
        info.update({"params_changed": 1, "alpha": 2.0, "type": "router_bias"})
        return info
    if arm == "rb_supp_e1":
        p["l0.r.b"][1] -= 2.0
        info.update({"params_changed": 1, "alpha": 2.0, "type": "router_bias"})
        return info
    if arm == "rb_boost_e0":
        p["l0.r.b"][0] += 2.0
        info.update({"params_changed": 1, "alpha": 2.0, "type": "router_bias"})
        return info
    if arm == "rb_boost_e6":
        p["l0.r.b"][6] += 2.0
        info.update({"params_changed": 1, "alpha": 2.0, "type": "router_bias"})
        return info
    if arm == "rb_mild_e0":
        p["l0.r.b"][0] -= 0.5
        info.update({"params_changed": 1, "alpha": 0.5, "type": "router_bias"})
        return info
    if arm == "rb_rand":
        rng = torch.Generator().manual_seed(7000 + seed)
        noise = torch.randn(8, generator=rng)
        noise = 2.0 * noise / noise.norm()
        p["l0.r.b"] = p["l0.r.b"] + noise
        info.update({"params_changed": 8, "alpha": 2.0, "type": "router_bias"})
        return info

    # --- 改善型編集群（Exp 8 型） ---
    # W は (d=128, dim=32)
    W = clean["l0.e0.w2"]
    if arm.startswith("imp_v_"):
        alpha = float(arm.split("_a")[-1]) / 100.0  # a005 -> 0.05, a050 -> 0.50, a200 -> 2.00
        proj = v @ W  # (32,)
        dW = -alpha * (v[:, None] * proj[None, :])
        p["l0.e0.w2"] = W + dW
        info.update({"params_changed": int(W.numel()), "alpha": alpha, "type": "imp_weight"})
        return info
    if arm == "imp_rand":
        alpha = 0.50
        proj = v_rand @ W
        dW = -alpha * (v_rand[:, None] * proj[None, :])
        p["l0.e0.w2"] = W + dW
        info.update({"params_changed": int(W.numel()), "alpha": alpha, "type": "imp_weight"})
        return info

    # --- 破壊上限 ---
    if arm == "oracle":
        keys = [f"l{l}.e{i}.w2" for l in range(model.L) for i in range(model.E)]
        for k in keys:
            p[k] = torch.zeros_like(p[k])
        info.update({"params_changed": int(sum(p[k].numel() for k in keys)),
                     "alpha": 0.0, "type": "oracle"})
        return info

    raise ValueError(f"未知の腕: {arm}")


# ---------------------------------------------------------------------------
# 校正
# ---------------------------------------------------------------------------
def calibration(seq, typ, x1b_rows):
    items = []

    def add(tag, seed, arm, field, want, got):
        d = abs(float(want) - float(got))
        items.append({"check": tag, "seed": seed, "arm": arm, "field": field,
                      "want": want, "got": got, "abs_diff": d,
                      "bit_match": bool(d < 1e-12)})

    # C1: H の baseline (none) および oracle 腕の 8 seed 評価結果を x1b_results.json と照合
    for seed in SEEDS:
        model, clean = load_arch(seed)
        fresh(model, clean)
        m_none, _ = evaluate_generic(model, seq, typ, k=2)
        ref_none = next(r for r in x1b_rows
                        if r["arch"] == "H" and r["arm"] == "none" and r["seed"] == seed)
        for fld in CAL_FIELDS:
            add("C1", seed, "none", fld, ref_none[fld], m_none[fld])

        apply_intervention(model, clean, "oracle", None, None, seed)
        m_ora, _ = evaluate_generic(model, seq, typ, k=2)
        ref_ora = next(r for r in x1b_rows
                       if r["arch"] == "H" and r["arm"] == "oracle" and r["seed"] == seed)
        for fld in CAL_FIELDS:
            add("C1", seed, "oracle", fld, ref_ora[fld], m_ora[fld])

    # C2: logits 一致
    model, clean = load_arch(0)
    fresh(model, clean)
    x = torch.from_numpy(seq[:32])
    t = torch.from_numpy(typ[:32])
    with torch.no_grad():
        a, auxa, ia = Q8.forward_dispatch(model, x, typ=t, mode="dynamic_lb")
        b, auxb, ib = forward_generic(model, x, typ=t, k=2)
    d_logit = float((a - b).abs().max())
    d_aux = abs(float(auxa) - float(auxb))
    d_idx = float(max(float((x1 != x2).float().max()) for x1, x2 in zip(ia, ib)))
    items.append({"check": "C2", "seed": 0, "arm": "H", "field": "logits",
                  "want": 0.0, "got": d_logit, "abs_diff": d_logit,
                  "bit_match": bool(d_logit < 1e-12 and d_aux < 1e-12 and d_idx == 0.0)})
    items.append({"check": "C2", "seed": 0, "arm": "H", "field": "aux",
                  "want": 0.0, "got": d_aux, "abs_diff": d_aux,
                  "bit_match": bool(d_aux < 1e-12)})

    # C3: l0.r.b の shape assert: (8,)
    items.append({"check": "C3", "seed": 0, "arm": "H", "field": "r.b_shape",
                  "want": 8, "got": int(clean["l0.r.b"].numel()), "abs_diff": 0.0,
                  "bit_match": bool(clean["l0.r.b"].shape == (8,))})

    # C4: v と v_rand の直交性
    v, vr, _, _ = extract_error_direction(clean, seq, typ, 0)
    d_orth = abs(float(v @ vr))
    items.append({"check": "C4", "seed": 0, "arm": "H", "field": "v_orth",
                  "want": 0.0, "got": d_orth, "abs_diff": d_orth,
                  "bit_match": bool(d_orth < 1e-6)})

    all_ok = all(x["bit_match"] for x in items)
    return {"all_bit_match": all_ok, "n": len(items),
            "n_fail": sum(1 for x in items if not x["bit_match"]),
            "items": items}


# ---------------------------------------------------------------------------
# メイン
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, nargs="+", default=list(SEEDS))
    ap.add_argument("--arms", type=str, nargs="+", default=list(ARMS))
    ap.add_argument("--n_eval", type=int, default=N_EVAL)
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--tag", type=str, default="x2")
    args = ap.parse_args()

    tag = args.tag
    logpath = os.path.join(HERE, f"{tag}_out_utf8.txt")
    out_fh = open(logpath, "w", encoding="utf-8")

    def log(msg):
        out_fh.write(msg + "\n")
        out_fh.flush()
        print(msg, flush=True)

    log(f"=== X2: ルータバイアス介入と改善型編集の検証 (tag={tag}) ===")
    log(f"seeds={args.seeds} n_eval={args.n_eval} arms={args.arms}")

    torch.set_num_threads(args.threads)
    rng_eval = np.random.default_rng(EVAL_SEED)
    seq, typ = Q2.make_trace_batch(rng_eval, args.n_eval, task="hard")

    # ---------------- 校正 ----------------
    with open(os.path.join(HERE, "x1b_results.json"), encoding="utf-8") as f:
        x1b_rows = json.load(f)["rows"]

    calib = calibration(seq, typ, x1b_rows)
    with open(os.path.join(HERE, f"{tag}_calib.json"), "w", encoding="utf-8") as f:
        json.dump(calib, f, ensure_ascii=False, indent=2)
    log(f"校正結果: n={calib['n']} all_bit_match={calib['all_bit_match']} "
        f"n_fail={calib['n_fail']}")
    if not calib["all_bit_match"]:
        for it in calib["items"]:
            if not it["bit_match"]:
                log(f"  [FAIL] {it['check']} s{it['seed']} {it['arm']} {it['field']}: "
                    f"want={it['want']} got={it['got']} diff={it['abs_diff']}")
        raise RuntimeError("校正が成立しなかったため本番走行を中止")

    # ---------------- 本番評価 ----------------
    ne, ns, L = len(args.arms), len(args.seeds), 4
    ea = {e: i for i, e in enumerate(args.arms)}
    sa = {s: j for j, s in enumerate(args.seeds)}

    iv = np.full((ne, ns), np.nan)
    ce_all = np.full((ne, ns), np.nan)
    ce_pay = np.full((ne, ns), np.nan)
    acc_pay = np.full((ne, ns), np.nan)
    instr_seq = np.zeros((ne, ns, args.n_eval), dtype=np.int8)
    ce_seq = np.zeros((ne, ns, args.n_eval), dtype=np.float64)
    selchg = np.zeros((ne, ns, L), dtype=np.float64)
    relpert = np.zeros((ne, ns), dtype=np.float64)
    diff_l2 = np.zeros((ne, ns), dtype=np.float64)
    u_l0_arr = np.zeros((ne, ns, 8), dtype=np.int64)
    rows = []

    for seed in args.seeds:
        model, clean = load_arch(seed)
        fresh(model, clean)
        v, vr, n_succ, n_fail = extract_error_direction(clean, seq, typ, seed)
        log(f"seed {seed}: baseline 成功系列={n_succ}, 失敗系列={n_fail}")
        m0, x0 = evaluate_generic(model, seq, typ, k=2)
        params_norm = math.sqrt(sum(float((val ** 2).sum()) for val in clean.values()))

        for arm in args.arms:
            info = apply_intervention(model, clean, arm, v, vr, seed)
            sq = sum(float(((model.p[k] - clean[k]) ** 2).sum()) for k in clean)
            dl2 = math.sqrt(sq)
            m, x = evaluate_generic(model, seq, typ, k=2)
            j, q = ea[arm], sa[seed]

            iv[j, q] = m["instr_valid"]
            ce_all[j, q] = m["ce_all"]
            ce_pay[j, q] = m["ce_payload"]
            acc_pay[j, q] = m["acc_payload"]
            instr_seq[j, q] = x["instr_seq"]
            ce_seq[j, q] = x["ce_seq"]
            u_l0_arr[j, q] = np.array(m["usage_l0"])
            relpert[j, q] = dl2 / max(1e-12, params_norm)
            diff_l2[j, q] = dl2

            if arm == "none":
                selchg[j, q] = 0.0
            else:
                selchg[j, q] = selection_change(x0["topi"], x["topi"])

            rows.append({
                "arm": arm, "seed": seed, **m,
                "diff_l2": dl2, "relpert": relpert[j, q],
                "alpha": info["alpha"], "params_changed": info["params_changed"],
                "sel_change": selchg[j, q].tolist(),
            })
            log(f"  {arm:<14s} s{seed} iv={m['instr_valid']:.4f} "
                f"ce={m['ce_all']:.5f} relpert={relpert[j,q]:.5f} "
                f"sel_l0={selchg[j,q,0]:.4f} u0={m['usage_l0'][0]}")

    # ---------------- 保存 ----------------
    with open(os.path.join(HERE, f"{tag}_results.json"), "w", encoding="utf-8") as f:
        json.dump({"rows": rows, "args": vars(args), "arms": list(args.arms),
                   "seeds": list(args.seeds)}, f, ensure_ascii=False, indent=2, default=float)

    np.savez_compressed(
        os.path.join(HERE, f"{tag}_delta.npz"),
        arms=np.array(args.arms, dtype=object), seeds=np.array(args.seeds),
        iv=iv, ce_all=ce_all, ce_payload=ce_pay, acc_payload=acc_pay,
        instr_seq=instr_seq, ce_seq=ce_seq, sel_change=selchg,
        relpert=relpert, diff_l2=diff_l2, usage_l0=u_l0_arr)

    # ---------------- 集計 ----------------
    def paired(d):
        d = np.asarray(d, dtype=float)
        se = float(d.std(ddof=1) / math.sqrt(len(d))) if len(d) >= 2 else float("nan")
        if not np.isfinite(se) or se == 0:
            t, p, mde = 0.0, 1.0, 0.0
        else:
            t = float(d.mean() / se)
            p = float(2 * stats.t.sf(abs(t), df=len(d) - 1))
            mde = float(stats.t.ppf(0.975, len(d) - 1) * se)
        return {"delta": float(d.mean()), "se": se, "t": t, "p": p,
                "mde": mde, "n": int(len(d)), "per_seed": d.tolist(),
                "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum())}

    def dseq(arm):
        a = ce_seq[ea[arm]] - ce_seq[ea["none"]]
        return a.mean(1)

    arm_effects = {}
    for arm in args.arms:
        if arm == "none":
            continue
        r = paired(iv[ea[arm]] - iv[ea["none"]])
        r["iv_none"] = float(iv[ea["none"]].mean())
        r["iv_arm"] = float(iv[ea[arm]].mean())
        r["ce_seq"] = paired(dseq(arm))
        r["sel_change_l0"] = float(selchg[ea[arm], :, 0].mean())
        r["sel_change_all"] = selchg[ea[arm]].mean(0).tolist()
        r["usage_l0_mean"] = u_l0_arr[ea[arm]].mean(0).tolist()
        r["relpert"] = float(relpert[ea[arm]].mean())
        # top1 寄与率
        dd = (ce_seq[ea[arm]] - ce_seq[ea["none"]]).reshape(-1)
        ab = np.abs(dd)
        ntop = max(1, int(math.ceil(len(ab) * 0.01)))
        r["ce_seq_top1_share"] = float(np.sort(ab)[-ntop:].sum() / max(1e-12, ab.sum()))
        arm_effects[arm] = r

    # 構造比較: 誤差方向 (imp_v_a050) vs ランダム方向 (imp_rand)
    struct_comp = paired((iv[ea["imp_v_a050"]] - iv[ea["none"]]) -
                         (iv[ea["imp_rand"]] - iv[ea["none"]]))
    struct_comp["ce_seq"] = paired(dseq("imp_v_a050") - dseq("imp_rand"))

    analysis = {
        "arm_effects": arm_effects,
        "structural_comparison_v_vs_rand": struct_comp,
        "calibration": calib,
    }

    with open(os.path.join(HERE, f"{tag}_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2, default=float)

    log("\n=== 集計完了 ===")
    for arm, r in arm_effects.items():
        log(f"  {arm:<14s}: Δiv={r['delta']:+.4f} (se={r['se']:.4f}, p={r['p']:.4f}, mde={r['mde']:.4f}) "
            f"Δce={r['ce_seq']['delta']:+.4f} sel_l0={r['sel_change_l0']:.4f} "
            f"pos={r['n_pos']} neg={r['n_neg']}")
    log(f"構造特異性 (v vs rand): Δiv={struct_comp['delta']:+.4f} p={struct_comp['p']:.4f} "
        f"Δce={struct_comp['ce_seq']['delta']:+.4f} p={struct_comp['ce_seq']['p']:.4f}")

    out_fh.close()
    os._exit(0)


if __name__ == "__main__":
    main()
