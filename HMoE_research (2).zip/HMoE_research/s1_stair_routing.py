# -*- coding: utf-8 -*-
"""S1: Does a ToC in context offload the rare-expert memory used for leaf retrieval?

Measurement only.  OLMoE-1B-7B (top-8, 64 experts) is used as a stand-in for
HMoE: per-layer expert activation frequency is the proxy for expert size
(frequent = small-expert proxy, rare = large-expert proxy).

Conditions
----------
prompt:   toc / shuffle / none        (+ toc_mis / none_mis for the base pass)
ablation: base / g_rare / g_freq / l_rare / l_freq (+ g_rand / l_rand optional)

For every query we score the gold leaf and one length-matched distractor at
each available LCA level, and capture the router at every answer token.

Outputs
-------
s1_stair_routing.npz / s1_stair_routing.json / s1_stair_routing_out_utf8.txt

Run (PowerShell):
  $p = "C:\\Users\\gochu\\.workbuddy-ai\\binaries\\python\\envs\\gpu\\Scripts\\python.exe"
  & $p s1_stair_routing.py --smoke
  & $p s1_stair_routing.py --gpu-gib 7.5 --cpu-gib 12.0
"""

import argparse
import json
import math
import os
import random
import re
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


def clean(s):
    s = s.replace("\ufffd\ufffds", "'s").replace("\ufffd\ufffd", "'").replace("\ufffd", "")
    return re.sub(r"\s+", " ", s).strip()


def number_span(title):
    """Return (number_string_with_optional_period, n_components)."""
    m = re.match(r"^\s*(\d+(?:\.\d+)*\.?)", title)
    if not m:
        return "", 0
    ns = m.group(1)
    core = ns.rstrip(".")
    return ns, len(core.split(".")) if core else 0


def _parts(title):
    m = re.match(r"^\s*(\d+(?:\.\d+)*)", title)
    return [int(x) for x in m.group(1).split(".")] if m else None


def subset_toc(titles, gold, max_n):
    """A deterministic local ToC: all leaves of the gold's chapter, then fill."""
    gp = _parts(gold)
    if gp is None or len(titles) <= max_n:
        return list(titles)
    same = [t for t in titles if (_parts(t) or [None])[0] == gp[0]]
    other = [t for t in titles if (_parts(t) or [None])[0] != gp[0]]
    rng = random.Random(13 + sum(ord(c) for c in gold))
    rng.shuffle(other)
    chosen = same[:max_n]
    if gold not in chosen:
        if len(chosen) >= max_n:
            chosen[-1] = gold
        else:
            chosen.append(gold)
    chosen = list(dict.fromkeys(chosen))
    chosen += other[:max(0, max_n - len(chosen))]
    return sorted(chosen, key=lambda t: _parts(t) or [0])


def build_prompt(book, query, toc_text, with_toc=True):
    if with_toc:
        head = ("### Book: %s\nPick the best section from the table of contents below which can answer "
                "the user query below. Only generate the section name, do not generate any explanation!\n"
                "### Table of Contents\n%s\n### Query: %s\n### Section:" % (book, toc_text, query))
    else:
        head = ("### Book: %s\nPick the best section which can answer the user query below. "
                "Only generate the section name, do not generate any explanation!\n"
                "### Query: %s\n### Section:" % (book, query))
    return head


def tokenize_suffix(tok, title):
    s = " " + title
    enc = tok(s, add_special_tokens=False, return_offsets_mapping=True)
    ids = enc["input_ids"]
    offs = enc["offset_mapping"]
    ns, ncomp = number_span(title)
    num_end = 1 + len(ns) if ns else 1
    num_mask = []
    digit_idx = []
    for i, (a, b) in enumerate(offs):
        in_num = bool(a < num_end and b > 1)
        num_mask.append(in_num)
        if in_num and any(ch.isdigit() for ch in s[a:b]):
            digit_idx.append(i)
    first_num = digit_idx[0] if digit_idx else -1
    last_num = digit_idx[-1] if digit_idx else -1
    return {
        "str": s,
        "ids": ids,
        "offs": offs,
        "num_mask": np.asarray(num_mask, dtype=bool),
        "first_num": first_num,
        "last_num": last_num,
        "num_end": num_end,
        "ncomp": ncomp,
    }


def divergence(gold, cand):
    """First token where cand differs from gold; level = number component index (99 = title)."""
    n = min(len(gold["ids"]), len(cand["ids"]))
    j = 0
    while j < n and gold["ids"][j] == cand["ids"][j]:
        j += 1
    if j >= len(cand["ids"]):
        return j, -1
    pos = cand["offs"][j][0]
    if pos < cand["num_end"]:
        prefix = cand["str"][1:pos]
        lvl = prefix.count(".")
    else:
        lvl = 99
    return j, lvl


def paired_stats(d):
    d = np.asarray(d, dtype=np.float64)
    d = d[np.isfinite(d)]
    n = d.size
    if n < 2:
        return {"mean": float(d.mean()) if n else float("nan"), "se": float("nan"),
                "t": float("nan"), "n": int(n), "mde": float("nan")}
    m = float(d.mean())
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    t = m / se if se > 0 else float("nan")
    return {"mean": m, "se": se, "t": t, "n": int(n), "mde": 2.8 * se}


# ---------------------------------------------------------------------------
# Router wrappers
# ---------------------------------------------------------------------------

def _renorm(scores, mask):
    """Zero masked scores and restore the original total mass (content-only lesion)."""
    s = scores.float()
    orig = s.sum(-1, keepdim=True)
    s = s.masked_fill(mask, 0.0)
    new = s.sum(-1, keepdim=True)
    s = s * (orig / new.clamp_min(1e-9))
    s = torch.where(new > 0, s, torch.zeros_like(s))
    return s.to(scores.dtype)


def make_global_wrapper(orig, banned):
    banned_t = torch.as_tensor(banned, dtype=torch.long)

    def patched(hidden_states):
        logits, scores, idx = orig(hidden_states)
        b = banned_t.to(idx.device)
        mask = (idx.unsqueeze(-1) == b.view(1, 1, -1)).any(-1)
        if bool(mask.any()):
            scores = _renorm(scores, mask)
        return logits, scores, idx

    return patched


def make_local_wrapper(orig, rank_vec, mode, n_drop=2):
    rank_t = torch.as_tensor(rank_vec, dtype=torch.long)

    def patched(hidden_states):
        logits, scores, idx = orig(hidden_states)
        r = rank_t.to(idx.device)[idx]  # (N,k), 0=rarest, E-1=most frequent
        k = min(n_drop, r.shape[-1])
        sel = r.topk(k, largest=(mode == "freq")).indices
        mask = torch.zeros_like(scores, dtype=torch.bool)
        mask.scatter_(1, sel, True)
        scores = _renorm(scores, mask)
        return logits, scores, idx

    return patched


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--manifest", type=str, default=os.path.join(HERE, "s1_manifest.json"))
    ap.add_argument("--gpu-gib", type=float, default=7.5)
    ap.add_argument("--cpu-gib", type=float, default=12.0)
    ap.add_argument("--calib-tokens", type=int, default=1500, help="tokens per domain for expert profiles")
    ap.add_argument("--domains", type=str, default="all")
    ap.add_argument("--limit", type=int, default=0, help="max entries per domain (0=all)")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--load-4bit", action="store_true", help="nf4 GPU-only fallback (gate kept bf16)")
    ap.add_argument("--core", action="store_true", help="9-condition reduced design")
    ap.add_argument("--toc-max", type=int, default=0, help="cap ToC entries per query (0=full book)")
    ap.add_argument("--tag", type=str, default="s1_stair_routing")
    ap.add_argument("--no-extra", action="store_true", help="skip random-group controls")
    args = ap.parse_args()

    if args.smoke:
        args.domains = "education,finance"
        args.limit = 1
        args.calib_tokens = min(args.calib_tokens, 300)
        args.tag = args.tag + "_smoke" if not args.tag.endswith("_smoke") else args.tag

    t_start = time.time()
    with open(args.manifest, encoding="utf-8") as f:
        man = json.load(f)
    doms = list(man["domains"].keys()) if args.domains == "all" else [d.strip() for d in args.domains.split(",")]
    for d in doms:
        if d not in man["domains"]:
            raise SystemExit("unknown domain: " + d)
        if args.limit:
            man["domains"][d]["entries"] = man["domains"][d]["entries"][:args.limit]
    n_entries = sum(len(man["domains"][d]["entries"]) for d in doms)
    log("[1/5] entries: %d from %s" % (n_entries, ",".join(doms)))

    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[2/5] loading %s" % args.model)
    t0 = time.time()
    tok = AutoTokenizer.from_pretrained(args.model)
    if args.load_4bit:
        from transformers import BitsAndBytesConfig
        bnb = BitsAndBytesConfig(
            load_in_4bit=True, bnb_4bit_quant_type="nf4",
            bnb_4bit_compute_dtype=torch.bfloat16, bnb_4bit_use_double_quant=True,
            llm_int8_skip_modules=["gate", "lm_head"],
        )
        model = AutoModelForCausalLM.from_pretrained(
            args.model, quantization_config=bnb, device_map={"": 0},
        ).eval()
    else:
        model = AutoModelForCausalLM.from_pretrained(
            args.model, torch_dtype=torch.bfloat16, device_map="auto",
            max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
        ).eval()
    log("      loaded in %.0f s" % (time.time() - t0))
    try:
        log("      device_map: " + json.dumps({str(k): str(v) for k, v in model.hf_device_map.items()}))
    except Exception:
        pass

    n_layers = int(model.config.num_hidden_layers)
    n_experts = int(model.config.num_experts)
    top_k = int(model.config.num_experts_per_tok)
    d_model = int(model.config.hidden_size)
    gates = [layer.mlp.gate for layer in model.model.layers]
    ORIG = [g.forward for g in gates]
    log("      layers=%d experts=%d top_k=%d d=%d" % (n_layers, n_experts, top_k, d_model))

    # lm_head is a meta placeholder under CPU offload (AGENTS §8).  Materialise it
    # on CPU fp32 and always apply it there; the head check proves it is the head.
    Wsrc = model.lm_head.weight
    if Wsrc.is_meta:
        hook = getattr(model.lm_head, "_hf_hook", None)
        wm = getattr(hook, "weights_map", None) if hook is not None else None
        real = wm["weight"] if wm is not None else None
        if real is None or getattr(real, "is_meta", False):
            raise RuntimeError("lm_head real weight not found in weights_map")
    else:
        real = Wsrc
    Whead = real.detach().float().cpu()
    log("      lm_head materialised: %s (%.0f MB)" % (tuple(Whead.shape), Whead.numel() * 4 / 1e6))

    # head check on a short sequence: max|N @ W.T - logits|
    chk_ids = tok("The quick brown fox jumps over the lazy dog.", return_tensors="pt",
                  add_special_tokens=False).input_ids.to(model.device)
    with torch.no_grad():
        h_chk = model.model(input_ids=chk_ids, use_cache=False).last_hidden_state[:, -1:, :]
        lg_chk = (h_chk.float().cpu() @ Whead.t())
        lg_ref = model(input_ids=chk_ids, use_cache=False).logits[:, -1:, :].float().cpu()
    head_err = float((lg_chk - lg_ref).abs().max())
    log("      head check max|N@W.T - logits| = %.5f" % head_err)
    if head_err > 0.5:
        raise RuntimeError("head check failed: %.5f (embed_tokens instead of lm_head?)" % head_err)

    # ---- calibration: expert activation frequency, token frequency, fragment rate ----
    log("[3/5] calibration")
    cal_count = np.zeros((n_layers, n_experts), dtype=np.float64)
    cal_wsum = np.zeros((n_layers, n_experts), dtype=np.float64)
    cal_tf = np.zeros((n_layers, n_experts), dtype=np.float64)
    cal_frag = np.zeros((n_layers, n_experts), dtype=np.float64)
    cal_n = np.zeros(n_layers, dtype=np.float64)
    all_ids = []
    texts = []
    for d in doms:
        rows = []
        with open(os.path.join(HERE, "data_searchtome", d + "_corpus.jsonl"), encoding="utf-8") as f:
            for line in f:
                rows.append(clean(json.loads(line)["content"]))
        text = "\n\n".join(rows)
        ids_all = tok(text, add_special_tokens=False)["input_ids"]
        all_ids.extend(ids_all)
        n_cal = args.calib_tokens
        if len(ids_all) <= n_cal:
            ids = ids_all
        else:
            # 3 evenly spaced windows, so the profile is not just the front matter
            k = 3
            w = max(1, n_cal // k)
            starts = [int(i * (len(ids_all) - w) / (k - 1)) for i in range(k)]
            ids = []
            for s in starts:
                ids.extend(ids_all[s:s + w])
            ids = ids[:n_cal]
        if ids:
            texts.append(np.asarray(ids, dtype=np.int64))
    freq_table = np.bincount(np.asarray(all_ids, dtype=np.int64), minlength=len(tok)).astype(np.float64)
    logfreq = np.log(freq_table + 1.0)
    vocab = len(tok)
    frag_flag = np.zeros(vocab, dtype=np.float64)
    # fragment flag: token string does not start with the space marker and has a letter/digit
    for i in range(vocab):
        s = tok.convert_ids_to_tokens(i)
        if not isinstance(s, str):
            continue
        if s.startswith("<") or s.startswith("Ġ"):
            continue
        if re.search(r"[A-Za-z0-9]", s):
            frag_flag[i] = 1.0

    route_buf = []

    def route_hook(layer_idx):
        def hook(module, inp, out):
            route_buf.append((layer_idx, out[2].detach().cpu(), out[1].detach().float().cpu()))
        return hook

    handles = [g.register_forward_hook(route_hook(i)) for i, g in enumerate(gates)]

    for ids in texts:
        route_buf.clear()
        x = torch.from_numpy(ids).unsqueeze(0).to(model.device)
        with torch.no_grad():
            model.model(input_ids=x, use_cache=False)
        lf = logfreq[ids]
        ff = frag_flag[ids]
        for li, idx, sc in route_buf:
            idx_np = idx.numpy().reshape(-1, top_k)
            sc_np = sc.numpy().reshape(-1, top_k)
            flat = idx_np.ravel()
            cal_count[li] += np.bincount(flat, minlength=n_experts)
            cal_wsum[li] += np.bincount(flat, weights=sc_np.ravel(), minlength=n_experts)
            cal_tf[li] += np.bincount(flat, weights=np.repeat(lf, top_k), minlength=n_experts)
            cal_frag[li] += np.bincount(flat, weights=np.repeat(ff, top_k), minlength=n_experts)
            cal_n[li] += idx_np.shape[0]
    cal_count = cal_count / np.maximum(cal_n[:, None], 1.0)
    raw = cal_count * np.maximum(cal_n[:, None], 1.0)
    cal_tf = cal_tf / np.maximum(raw, 1.0)
    cal_frag = cal_frag / np.maximum(raw, 1.0)

    rare_idx = np.argsort(cal_count, axis=1)[:, :16]
    freq_idx = np.argsort(cal_count, axis=1)[:, -16:]
    rank = np.argsort(np.argsort(cal_count, axis=1), axis=1).astype(np.int64)  # 0=rarest
    rng = np.random.RandomState(17)
    rand_idx = np.stack([rng.permutation(n_experts)[:16] for _ in range(n_layers)])

    # validation of the size proxy
    val = {}
    for name, groups in (("rare", rare_idx), ("freq", freq_idx)):
        tf = np.mean([np.mean(cal_tf[l, groups[l]]) for l in range(n_layers)])
        fr = np.mean([np.mean(cal_frag[l, groups[l]]) for l in range(n_layers)])
        ct = np.mean([np.mean(cal_count[l, groups[l]]) for l in range(n_layers)])
        val[name] = {"mean_token_logfreq": float(tf), "mean_fragment_rate": float(fr),
                     "mean_activation": float(ct)}
    log("      proxy check: rare %s / freq %s" % (val["rare"], val["freq"]))

    # ---- prompts / candidates ----
    log("[4/5] forward")
    conds = []
    if args.core:
        core_map = (("toc", ["base", "g_rare", "g_freq", "g_rand", "l_rare", "l_freq"]),
                    ("none", ["base", "g_rare", "g_freq", "l_rare"]),
                    ("shuffle", ["base"]), ("toc_drop", ["base"]),
                    ("toc_mis", ["base"]))
        for pc, abs_ in core_map:
            for ab in abs_:
                conds.append((pc, ab))
    elif args.smoke:
        # 9 conditions: enough to test the prompt controls (including the
        # gold-leaf-removed ToC), both global arms and one local arm.
        smoke_map = (("toc", ["base", "g_rare", "g_freq", "l_rare"]),
                     ("toc_drop", ["base"]), ("none", ["base"]), ("shuffle", ["base"]),
                     ("toc_mis", ["base"]), ("none_mis", ["base"]))
        for pc, abs_ in smoke_map:
            for ab in abs_:
                conds.append((pc, ab))
    else:
        for pc in ("toc", "toc_drop", "none", "shuffle", "toc_mis", "none_mis"):
            if pc in ("toc", "none"):
                abs_ = ["base", "g_rare", "g_freq", "l_rare", "l_freq"]
                if not args.no_extra:
                    abs_ += ["g_rand", "l_rand"]
            elif pc == "shuffle":
                abs_ = ["base", "g_rare", "g_freq"]
            else:
                abs_ = ["base"]
            for ab in abs_:
                conds.append((pc, ab))
    log("      conditions/query: %d (%s)" % (len(conds), ",".join("%s:%s" % c for c in conds)))

    rows = []
    gold_tok = []  # (entry_index, condition_index, token arrays)
    t_fwd = 0.0
    n_fwd = 0
    for dom in doms:
        titles = man["domains"][dom]["titles"]
        book = man["domains"][dom]["book"]
        entries = man["domains"][dom]["entries"]
        for ei, ent in enumerate(entries):
            toc_titles = (subset_toc(titles, ent["gold"], args.toc_max)
                          if args.toc_max and len(titles) > args.toc_max else list(titles))
            toc_text = "\n".join(toc_titles)
            shuf = list(toc_titles)
            random.Random(13 + sum(ord(c) for c in ent["gold"])).shuffle(shuf)
            shuf_text = "\n".join(shuf)
            query = ent["query"]
            # mismatch query: next entry with a different gold
            mis_q = None
            for off in range(1, len(entries) + 1):
                cand = entries[(ei + off) % len(entries)]
                if cand["gold"] != ent["gold"]:
                    mis_q = cand["query"]
                    break
            if mis_q is None:
                mis_q = query
            drop_text = "\n".join(t for t in toc_titles if t != ent["gold"])
            prompts = {
                "toc": build_prompt(book, query, toc_text, True),
                "toc_drop": build_prompt(book, query, drop_text, True),
                "shuffle": build_prompt(book, query, shuf_text, True),
                "none": build_prompt(book, query, "", False),
                "toc_mis": build_prompt(book, mis_q, toc_text, True),
                "none_mis": build_prompt(book, mis_q, "", False),
            }
            prompt_ids = {k: tok(v, add_special_tokens=False)["input_ids"] for k, v in prompts.items()}
            P = {k: len(v) for k, v in prompt_ids.items()}
            maxP = max(P.values())
            if maxP + 40 > int(model.config.max_position_embeddings):
                raise SystemExit("prompt too long: %d" % maxP)

            cands = [{"type": "gold", "title": ent["gold"], "lca": 99,
                      "depth": ent["gold_depth"], "train_count": ent["gold_train_count"]}]
            cands += ent["candidates"]
            cdata = [tokenize_suffix(tok, c["title"]) for c in cands]
            gd = cdata[0]
            for c, cd in zip(cands, cdata):
                cd["div"], cd["div_level"] = divergence(gd, cd)

            for ci, (pc, ab) in enumerate(conds):
                # set wrapper
                for li, g in enumerate(gates):
                    if ab == "base":
                        g.forward = ORIG[li]
                    elif ab == "g_rare":
                        g.forward = make_global_wrapper(ORIG[li], rare_idx[li])
                    elif ab == "g_freq":
                        g.forward = make_global_wrapper(ORIG[li], freq_idx[li])
                    elif ab == "g_rand":
                        g.forward = make_global_wrapper(ORIG[li], rand_idx[li])
                    elif ab == "l_rare":
                        g.forward = make_local_wrapper(ORIG[li], rank[li], "rare", 2)
                    elif ab == "l_freq":
                        g.forward = make_local_wrapper(ORIG[li], rank[li], "freq", 2)
                    elif ab == "l_rand":
                        # random 2 active experts: encode as random ranks by drawing a random order
                        g.forward = make_local_wrapper(ORIG[li], rng.permutation(n_experts), "rare", 2)
                    else:
                        raise ValueError(ab)

                # One forward per condition: the gold sequence.  Every candidate
                # shares the prompt and the prefix up to its divergence token, so
                # the next-token distribution at that position is identical.  We
                # therefore read each candidate's token log-prob from this lsm.
                gold_ids = gd["ids"]
                C = len(gold_ids)
                seq = prompt_ids[pc] + gold_ids
                L = len(seq)
                ids = torch.tensor([seq], dtype=torch.long, device=model.device)
                route_buf.clear()
                t1 = time.time()
                with torch.no_grad():
                    out = model.model(input_ids=ids, use_cache=False)
                    h = out.last_hidden_state
                    h_slice = h[:, P[pc] - 1:P[pc] - 1 + C, :]
                    lg = h_slice.float().cpu() @ Whead.t()
                t_fwd += time.time() - t1
                n_fwd += 1
                if args.smoke:
                    log("        [%d/%d] %s/%s P=%d C=%d %.2fs (elapsed %.0fs)" %
                        (ci + 1, len(conds), pc, ab, P[pc], C, time.time() - t1,
                         time.time() - t_start))
                lsm = torch.log_softmax(lg, dim=-1)

                gtgt = torch.tensor(gold_ids, dtype=torch.long, device=lsm.device)
                gvals = lsm[0, torch.arange(C, device=lsm.device), gtgt].cpu().numpy()
                gnm = gd["num_mask"]
                gfull = float(np.sum(gvals))
                gnum = float(np.sum(gvals[gnm])) if gnm.any() else float("nan")
                gmean = float(np.mean(gvals))
                gmean_num = float(np.mean(gvals[gnm])) if gnm.any() else float("nan")

                # routing at the gold answer tokens (one sequence only)
                rr = []
                ff = []
                ee = []
                mm = []
                kk = []
                by_layer = {li: (idx, sc) for li, idx, sc in route_buf}
                for li in range(n_layers):
                    if li not in by_layer:
                        continue
                    idx, sc = by_layer[li]
                    idx_b = idx.reshape(1, L, top_k)[0, P[pc]:P[pc] + C]
                    sc_b = sc.reshape(1, L, top_k)[0, P[pc]:P[pc] + C]
                    if idx_b.shape[0] != C:
                        continue
                    rare_mask = np.isin(idx_b.numpy(), rare_idx[li])
                    freq_mask = np.isin(idx_b.numpy(), freq_idx[li])
                    rr.append(rare_mask.mean(-1))
                    ff.append(freq_mask.mean(-1))
                    w = sc_b.numpy()
                    w = w / np.maximum(w.sum(-1, keepdims=True), 1e-9)
                    ee.append(-(w * np.log(np.maximum(w, 1e-12))).sum(-1) / math.log(top_k))
                    mm.append(w.max(-1))
                    kk.append(rank[li][idx_b.numpy()].mean(-1) / (n_experts - 1))
                rare_t = np.mean(rr, 0) if rr else np.full(C, np.nan)
                freq_t = np.mean(ff, 0) if ff else np.full(C, np.nan)
                ent_t = np.mean(ee, 0) if ee else np.full(C, np.nan)
                maxw_t = np.mean(mm, 0) if mm else np.full(C, np.nan)
                rank_t = np.mean(kk, 0) if kk else np.full(C, np.nan)

                def m_at(arr, pos):
                    return float(arr[pos]) if 0 <= pos < C else float("nan")

                num_pos = np.where(gnm)[0]
                title_pos = np.where(~gnm)[0]

                for b, cd in enumerate(cdata):
                    c = cands[b]
                    div = cd["div"]
                    if b == 0:
                        logp_div = float("nan")
                        logp_full, logp_num = gfull, gnum
                        mean_full, mean_num = gmean, gmean_num
                    else:
                        if 0 <= div < C and 0 <= div < len(cd["ids"]):
                            logp_div = float(lsm[0, div, cd["ids"][div]])
                        else:
                            logp_div = float("nan")
                        logp_full = float("nan")
                        logp_num = float("nan")
                        mean_full = float("nan")
                        mean_num = float("nan")

                    row = {
                        "domain": dom, "query_id": ent["query_id"], "entry": ei,
                        "cand_type": c["type"], "is_gold": int(b == 0),
                        "lca": c["lca"], "depth": c["depth"], "train_count": c["train_count"],
                        "prompt": pc, "ablation": ab,
                        "prompt_len": P[pc],
                        "logp_full": logp_full, "logp_num": logp_num, "logp_div": logp_div,
                        "mean_full": mean_full, "mean_num": mean_num, "n_tok": len(cd["ids"]),
                        "div_idx": div, "div_level": cd["div_level"],
                        "zero_frac": float("nan"),
                        "rare_div": m_at(rare_t, div), "freq_div": m_at(freq_t, div),
                        "rank_div": m_at(rank_t, div), "ent_div": m_at(ent_t, div),
                        "maxw_div": m_at(maxw_t, div),
                        "rare_num": float("nan"), "rare_title": float("nan"),
                        "rare_first": float("nan"), "rare_last": float("nan"),
                        "ent_num": float("nan"), "ent_title": float("nan"),
                    }
                    if b == 0:
                        row["rare_num"] = float(np.mean(rare_t[num_pos])) if len(num_pos) else float("nan")
                        row["rare_title"] = float(np.mean(rare_t[title_pos])) if len(title_pos) else float("nan")
                        row["rare_first"] = m_at(rare_t, cd["first_num"])
                        row["rare_last"] = m_at(rare_t, cd["last_num"])
                        row["ent_num"] = float(np.mean(ent_t[num_pos])) if len(num_pos) else float("nan")
                        row["ent_title"] = float(np.mean(ent_t[title_pos])) if len(title_pos) else float("nan")
                        # zero fraction (observational for global groups)
                        if ab == "g_rare":
                            row["zero_frac"] = float(np.mean(rare_t))
                        elif ab == "g_freq":
                            row["zero_frac"] = float(np.mean(freq_t))
                        elif ab == "g_rand":
                            row["zero_frac"] = float(np.mean([
                                np.isin(by_layer[li][0].reshape(1, L, top_k)[0, P[pc]:P[pc] + C].numpy(),
                                        rand_idx[li]).mean() for li in range(n_layers) if li in by_layer]))
                        elif ab in ("l_rare", "l_freq", "l_rand"):
                            row["zero_frac"] = 2.0 / top_k
                    rows.append(row)

                    if b == 0:
                        gold_tok.append({
                            "entry": ei, "domain": dom, "prompt": pc, "ablation": ab,
                            "query_id": ent["query_id"],
                            "ids": np.asarray(gold_ids), "str": gd["str"],
                            "num_mask": gd["num_mask"], "rare": rare_t, "freq": freq_t,
                            "ent": ent_t, "maxw": maxw_t, "rank": rank_t,
                            "logp": np.asarray(gvals, dtype=np.float32),
                            "tlogfreq": np.asarray(logfreq[np.asarray(gold_ids)], dtype=np.float32),
                            "tfrag": np.asarray(frag_flag[np.asarray(gold_ids)], dtype=np.float32),
                        })
            if (ei + 1) % 5 == 0:
                log("      %s %d/%d  (%.1f s/query, fwd %.3f s)" %
                    (dom, ei + 1, len(entries), (time.time() - t_start) / (ei + 1), t_fwd / max(n_fwd, 1)))

    # restore wrappers
    for li, g in enumerate(gates):
        g.forward = ORIG[li]
    for h in handles:
        h.remove()

    # ---- save ----
    log("[5/5] saving")
    out_npz = os.path.join(HERE, args.tag + ".npz")
    meta = {
        "model": args.model, "n_layers": n_layers, "n_experts": n_experts, "top_k": top_k,
        "n_entries": n_entries, "conds": conds, "proxy_check": val,
        "calib_tokens_per_domain": args.calib_tokens, "smoke": bool(args.smoke),
        "load_4bit": bool(args.load_4bit),
        "domains": doms, "elapsed_s": time.time() - t_start,
        "mean_fwd_s": t_fwd / max(n_fwd, 1), "n_fwd": n_fwd,
    }

    def arr(key, dtype=float):
        return np.asarray([r[key] for r in rows], dtype=dtype)

    def sarr(key):
        return np.asarray([r[key] for r in rows], dtype=object)

    maxC = max(len(g["ids"]) for g in gold_tok) if gold_tok else 0
    gt = {}
    for key in ("ids", "rare", "freq", "ent", "maxw", "rank"):
        a = np.full((len(gold_tok), maxC), np.nan, dtype=np.float64)
        for i, g in enumerate(gold_tok):
            v = np.asarray(g[key], dtype=np.float64)
            a[i, :len(v)] = v
        gt["gold_" + key] = a
    gt["gold_len"] = np.asarray([len(g["ids"]) for g in gold_tok], dtype=np.int64)
    gt["gold_logp"] = np.full((len(gold_tok), maxC), np.nan, dtype=np.float64)
    for i, g in enumerate(gold_tok):
        v = np.asarray(g["logp"], dtype=np.float64)
        gt["gold_logp"][i, :len(v)] = v
    for key in ("tlogfreq", "tfrag"):
        a = np.full((len(gold_tok), maxC), np.nan, dtype=np.float64)
        for i, g in enumerate(gold_tok):
            v = np.asarray(g[key], dtype=np.float64)
            a[i, :len(v)] = v
        gt["gold_" + key] = a
    gt["gold_isnum"] = np.full((len(gold_tok), maxC), False, dtype=bool)
    for i, g in enumerate(gold_tok):
        v = np.asarray(g["num_mask"], dtype=bool)
        gt["gold_isnum"][i, :len(v)] = v
    gt["gold_entry"] = np.asarray([g["entry"] for g in gold_tok], dtype=np.int64)
    gt["gold_query_id"] = np.asarray([g["query_id"] for g in gold_tok], dtype=np.int64)
    gt["gold_prompt"] = np.asarray([g["prompt"] for g in gold_tok], dtype=object)
    gt["gold_ablation"] = np.asarray([g["ablation"] for g in gold_tok], dtype=object)
    gt["gold_domain"] = np.asarray([g["domain"] for g in gold_tok], dtype=object)

    np.savez_compressed(
        out_npz,
        meta=np.asarray([json.dumps(meta, ensure_ascii=False)], dtype=object),
        row_domain=sarr("domain"), row_query_id=arr("query_id", int), row_entry=arr("entry", int),
        row_cand_type=sarr("cand_type"), row_is_gold=arr("is_gold", int),
        row_lca=arr("lca", int), row_depth=arr("depth", int), row_train_count=arr("train_count", int),
        row_prompt=sarr("prompt"), row_ablation=sarr("ablation"),
        row_prompt_len=arr("prompt_len", int),
        row_logp_full=arr("logp_full"), row_logp_num=arr("logp_num"), row_logp_div=arr("logp_div"),
        row_mean_full=arr("mean_full"), row_mean_num=arr("mean_num"), row_n_tok=arr("n_tok", int),
        row_div_idx=arr("div_idx", int), row_div_level=arr("div_level", int),
        row_zero_frac=arr("zero_frac"),
        row_rare_div=arr("rare_div"), row_freq_div=arr("freq_div"), row_rank_div=arr("rank_div"),
        row_ent_div=arr("ent_div"), row_maxw_div=arr("maxw_div"),
        row_rare_num=arr("rare_num"), row_rare_title=arr("rare_title"),
        row_rare_first=arr("rare_first"), row_rare_last=arr("rare_last"),
        row_ent_num=arr("ent_num"), row_ent_title=arr("ent_title"),
        cal_count=cal_count, cal_tf=cal_tf, cal_frag=cal_frag, cal_wsum=cal_wsum,
        rare_idx=rare_idx, freq_idx=freq_idx, rand_idx=rand_idx, rank=rank,
        **gt,
    )
    with open(os.path.join(HERE, args.tag + ".json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=1)
    with open(os.path.join(HERE, args.tag + "_out_utf8.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(LOG))
    log("wrote %s (%d rows, %d gold-token rows)" % (out_npz, len(rows), len(gold_tok)))
    # avoid the Windows teardown hang
    os._exit(0)


if __name__ == "__main__":
    main()
