#!/usr/bin/env python3
"""K6 の解析: dense の幅- CE 曲線から、HMoE の**実測幅**での dense を補間し、等 active で比べる。

なぜ補間か
  HMoE の実測幅は訓練で動く（書き換え課題では 6ep 160.9 → 16ep 188.1）。
  この課題では 1 epoch で既に 227.4 だった。だから「等 active」の dense 幅は事前に決められない。
  dense を 4 点（180/210/240/256）振っておき、HMoE の実測幅で線形補間する。

対応
  同一 seed は同一の表・同一のデータ順なので、seed ごとの対応差が取れる。
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TAGS = sys.argv[1:] if len(sys.argv) > 1 else ["n3k"]
OUT = os.path.join(HERE, "k6_analyze_out_utf8.txt")


def p(msg):
    print(msg)
    with open(OUT, "a", encoding="utf-8") as f:
        f.write(msg + "\n")


def main():
    if os.path.exists(OUT):
        os.remove(OUT)
    rows, args0 = [], None
    for t in TAGS:
        suf = ("_" + t) if t else ""
        res = json.load(open(os.path.join(HERE, "k6_results%s.json" % suf), encoding="utf-8"))
        rows += res["rows"]
        args0 = args0 or res["args"]
    N = rows[0]["N"]

    p("== K6 解析（N=%d, epochs=%d, freq=%s） ==" % (N, rows[0]["epochs"], rows[0]["freq"]))
    p("")

    dense = [r for r in rows if r["cfg"].startswith("dense")]
    moe = [r for r in rows if r["cfg"].startswith("moe")]
    if not dense or not moe:
        p("dense / moe の両方が必要"); return

    # --- dense の幅- CE 曲線（seed 平均）---
    ws = sorted({r["width_mean"] for r in dense})
    p("== 1) dense の幅- CE 曲線（seed 平均） ==")
    p("  %8s %9s %9s %8s %10s" % ("幅", "CE", "acc", "MACs", "param"))
    curve = []
    for w in ws:
        sel = [r for r in dense if r["width_mean"] == w]
        ce = np.mean([r["ce"] for r in sel])
        ac = np.mean([r["acc"] for r in sel])
        curve.append((w, ce))
        p("  %8.1f %9.4f %9.4f %8d %10d"
          % (w, ce, ac, sel[0]["macs"], sel[0]["nparam"]))
    p("  → 幅を %.0f から %.0f に上げると CE は %+.4f"
      % (ws[0], ws[-1], curve[-1][1] - curve[0][1]))
    p("  → 1 幅あたり %.5f nats（この範囲の傾き）"
      % ((curve[-1][1] - curve[0][1]) / (ws[-1] - ws[0])))

    # --- HMoE ---
    p("")
    p("== 2) HMoE の実測幅と、そこでの dense の補間 ==")
    p("  %-10s %3s %8s %9s %9s %8s %10s %10s"
      % ("cfg", "s", "幅", "CE", "dense補間", "Δ", "MACs比", "param比"))
    xs = np.array([c[0] for c in curve])
    ys = np.array([c[1] for c in curve])
    out = []
    for r in sorted(moe, key=lambda x: x["seed"]):
        w = r["width_mean"]
        ce_d = float(np.interp(w, xs, ys))
        d = r["ce"] - ce_d
        # MACs: dense は E=1、HMoE は E=8。ゲート分は無視できる差なので同じ式で比べる
        macs_d = 4 * (4 * 128 * 128 + 2 * 128 * w + 128 * 1)
        ratio = r["macs"] / macs_d
        pratio = r["nparam"] / np.mean([x["nparam"] for x in dense
                                        if x["width_mean"] == ws[-1]])
        p("  %-10s %3d %8.1f %9.4f %9.4f %+8.4f %10.3f %10.2f"
          % (r["cfg"], r["seed"], w, r["ce"], ce_d, d, ratio, pratio))
        out.append({"seed": r["seed"], "w": w, "ce_moe": r["ce"],
                    "ce_dense": ce_d, "delta": d, "macs_ratio": ratio,
                    "pratio": pratio})

    d = np.array([o["delta"] for o in out])
    n = len(d)
    se = d.std(ddof=1) / np.sqrt(n) if n > 1 else float("nan")
    coef = {2: 5.36, 5: 3.49}.get(n - 1, 2.95 if n < 12 else 2.85)
    p("")
    p("  ΔCE（HMoE − 等 active dense） = %+.4f  中央値 %+.4f  se %.4f  t %+.2f  %d/%d 負  MDE %.4f"
      % (d.mean(), np.median(d), se, d.mean() / se, int((d < 0).sum()), n, coef * se))
    p("  MACs 比 %.3f（1.000 なら等 active）  param 比 %.2f"
      % (np.mean([o["macs_ratio"] for o in out]),
         np.mean([o["pratio"] for o in out])))
    p("  t の臨界値（df=%d, 両側 5%%）= %.3f" % (n - 1, coef))
    p("  → %s" % ("有意（HMoE が良い）" if abs(d.mean() / se) > coef
                  else "検出できず（MDE が効果より大きい）"))

    p("")
    p("== 3) 解釈の枠 ==")
    p("  Δ < 0（HMoE が良い）なら「容量が計算の代わりになる」＝条件 C が成立。")
    p("  Δ ≈ 0 なら、容量が縛られている系でも**パラメータは品質に変わらない**。")
    p("  知識量 %.2e bit、dense の FFN パラメータ %d 個。"
      % (rows[0]["knowledge_bits"], np.mean([x["nparam"] for x in dense])))

    with open(os.path.join(HERE, "k6_analyze_%s.json" % "_".join(TAGS)), "w",
              encoding="utf-8") as f:
        json.dump({"curve": curve, "moe": out,
                   "agg": {"delta": float(d.mean()), "se": float(se),
                           "t": float(d.mean() / se), "n": n, "mde": float(coef * se),
                           "n_neg": int((d < 0).sum())}},
                  f, ensure_ascii=False, indent=2, default=float)
    p("")
    p("[write] k6_analyze_%s.json" % "_".join(TAGS))


if __name__ == "__main__":
    main()
