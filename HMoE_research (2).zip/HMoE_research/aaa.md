# Heterogeneous MoE と多言語性能 — 対話まとめ

- 主題：Heterogeneous Mixture of Experts（MoE）と多言語性能の関係
- 焦点：とくに「容量不均一型（expertのサイズを変えるHMoE型）」が多言語に効くのか
- 結論の要旨：容量不均一 × 多言語の直接実証は存在しない。近傍の異種expert研究は前向きだが、P-Penaltyとの衝突・コスト面の懸念が残る。Gini係数を前提とする議論は現状未検証。

---

## 目次

1. [Q1: Heterogeneous MoEと多言語性能（全体像）](#q1)
2. [Q2: 容量不均一型HMoEと多言語性能](#q2)
3. [Q3: ここでのCPTとは](#q3)
4. [Q4: Gini係数の高いデータ系という前提について](#q4)
5. [確実に言えること／言えないこと](#確実)
6. [主要出典](#出典)

---

<a id="q1"></a>
## Q1: Heterogeneous MoEと多言語性能（全体像）

### 結論

「Heterogeneous MoE」は文脈によって3つの異なる意味で使われ、**多言語性能との関係は「層・配置の意味では強く支持されるが、expertサイズ不均一の意味ではほぼ未検証」**。

### HMoE（Wang et al., EMNLP 2025）の要点

- 提案：Tencent Hunyuan／東京科学大ほか。expertのFFN次元を変えて容量に差をつける。
- 課題：不均一化だけでは大expertが過剰起用され、小expertが遊休化する。
- 対策：**P-Penalty（Parameter Penalty）損失** — expertのサイズを「コスト」として損失に織り込み、小expertの起用を促す。router entropy loss と併用。
- 数値（3B規模, Top-P）：
  | モデル | 活性化パラメータ | 平均スコア |
  |---|---|---|
  | HMoE-3B (Top-P) | **0.68B** | **46.53** |
  | 均質MoE-3B (Top-P) | 1.23B | 45.62 |
  | Dense-1B | 1.32B | 45.03 |
  - 16B規模でも HMoE は活性1.77B vs 均質MoE 3.83B。
- 不均一化戦略（geometric / arithmetic / hybrid を比較）：
  - **geometric が最悪**（最小・最大の差が大きすぎ、小expertが容量不足で幾乎使われない）。
  - hybrid が最良とする要約（alphaXiv）と、arithmetic を安定性と性能のバランスから採用したとする要約（Lacuna）があり、**報告が揺れている**。実験本体は arithmetic（例：{9,11,…,23}）を採用。
- **評価は英語のみ**：PIQA / HellaSwag / BoolQ / ARC / Winogrande / SIQA（＋MMLU）。事前学習は RedPajama。**多言語評価は一切なし。**

### heterogeneity の3分類

| 種類 | 内容 | 多言語との接点 |
|---|---|---|
| 容量不均一 | expertごとにサイズを変える（HMoE, MoDSE） | **直接的な多言語評価なし（ギャップ）** |
| 構造不均一 | shared expert ＋ 細粒度routed expert（DeepSeekMoE系、Qwen3、LLM-jp-4、Rakuten AI 3.0）、あるいはCNN系とAttention系の異種expert（MoSTE） | 事実上の業界標準。多言語MTで均質MoE超えの報告あり |
| 配置・モデル不均一 | 層ごとにexpert数を変える（LayerMoE, NeuronMoE）／異なるLLM自体をexpertにする | パラメータ効率・言語拡張で効果が実証 |

### 多言語MoEで分かっているメカニズム

- **ルーティングはU字型**（Bandarkar et al., arXiv:2510.04694；Chen et al., arXiv:2601.14050）
  - 浅層・深層＝言語特化、中層＝言語非依存の「意味ハブ／semantic hub」。
  - 中層で英語とどれだけ同じexpertを使えるかが、その言語の性能を強く予測。
- **推論時介入の中層steering**：
  - MGSM：Qwen3-30B 76.4 → 78.0、GPT-OSS-20B 68.9 → 71.5。15言語以上で1〜2pt改善。
  - 中層以外（浅層・深層）への介入は逆効果。
- **層介入（masking）実験**（Chen et al.）：
  - 浅層のlanguage-exclusive expertをマスク：MGSM 84.5 → 73.1
  - 中層をマスク：83.6（ほぼ無影響）
  - 深層をマスク：78.4、言語一貫性 90.9 → 56.9
- **低リソース言語の深層routing collapse**（arXiv:2605.17598）
  - Qwen3-30B-A3B と Nemotron-3-Nano-30B-A3B を解析。
  - ヘブライ語・日本語で最終層のエントロピーが急落し、少数expertにトークン集中。英語では見られない。
  - **バランスの取れたCPTはこれを是正するが、SFT単独では最深层の偏りが残る。**
  - 日本語でもヘブライ語と定量的に整合するシグネチャ → 言語固有ではなく「表現不足の帰結」と解釈。
- **高リソース vs 低リソースの非対称**（RISE, arXiv:2604.03592）
  - 高リソース言語はshared expertを柔軟に使い分ける。低リソース言語は排他的な少数expertに閉じ込められる。
  - TyDiQA ベンガル語：+10.85% F1（Phi-3.5-MoE-Instruct）。枝刈りで 54.23 → 1.00 に崩壊（因果性の確認）。

### 間接的だが強い証拠

- **SMoE（Xu et al., Findings of EMNLP 2023）** ：トークンが通過するexpert数（Requested Capacity）を動的に変える階層構造。
  - M15：vanilla MoE +0.93、Switch +1.04 spBLEU
  - OPUS-100（94言語）：vanilla MoE +1.01、**Switch +1.63 BLEU**（FLOPsは+8%）
  - 同性能にvanilla MoEはexpertを16→32（963M→1.77B）増やす必要。
  - RCはターゲット言語によって明確に変動。初期エンコーダ層ほど容量を要求。
  - → 「容量を可変・不均一に配分する」発想が多言語と相性が良い最直接の証拠。
- **NeuronMoE（EACL 2026, 東大）** ：言語特化ニューロン密度に応じて層ごとにexpert数を不均一配置。LayerMoE比で Llama-3.2-3B **41.7%**（49 vs 84 experts）、Qwen-1.5-1.8B **50%** のパラメータ削減で同等性能。言語特化は浅層・深層に集中。
- **モデルレベルheterogeneity（Alibaba, arXiv:2602.00003 / WWW Companion '26）** ：Qwen／Gemma／Sailor をexpertにしクエリ単位ルーティング。異種埋込みは加重平均でなく**連結**が有効。東南アジア6市場で **AUC +0.72pp、QPS 13.72（+9%）** 。
- **MoE-LPR（AAAI 2025）** ：凍結expert＋新規expertの二段階。拡張言語 45.07（ベース34.36）、既存言語能力を **96.6% 保持**。<1%のリプレイデータ。
- **MeLt**：対照学習で言語別専門化を誘導し、枝刈りで軽量な単言語モデルを切り出せる。

### 実務的含意

多言語性能を上げるなら、expert数を増やすより以下の3点：

1. **中層のルーティング整合**（英語task expertへの寄せ）— RA-MoE（Bengali GSM8K +3.0点、追加FLOPs <0.001%）、SARA（Global-MMLU +0.8 / +1.2）。
2. **層ごとの不均一な容量配分** — NeuronMoE、SMoE。
3. **バランス取れたデータでのCPT**。

診断指標：expert利用率のエントロピー、英語とのJSD、ci例（英語では解けるがターゲット言語では解けない）の比率。

### 日本語への引きつけ

- **LLM-jp-4 32B-A3B**（NII、2026-04）：Qwen3 MoE構成、128 routed experts、top-8、32B/active 3.8B、11.7T tokens、Apache 2.0。日本語MT-Bench **7.82**（GPT-4o 7.29、gpt-oss-20b 7.33、Qwen3-8B 7.14）。8Bは7.54。英語MT-Bench 7.79/7.88。
  - ただし学習コーパス中の日本語は約7,000億／1.95兆トークンと少なく、中層の言語非依存ハブを英語側に依存する構造と整合的。
- **Rakuten AI 3.0**（2026-03）：約7,000億パラメータMoE、Apache 2.0。JamC-QA／MMLU-ProX／MATH-100／M-IFEvalで高水準。専門家構成・活性パラメータ数の詳細は二次情報止まり。

### 限界

- サイズ不均一型の多言語評価が存在しない（最大のギャップ）。
- 中層steering系は英語能力とターゲット言語の事前学習カバレッジに依存。
- 異種LLM融合は埋込み空間の非整合という別問題。
- サイズ不均一はGPU間負荷偏りを招く（HMoEの配置戦略、MoDSEのexpert-pair分割）。

---

<a id="q2"></a>
## Q2: 容量不均一型HMoEと多言語性能

### 直接の答え：実証は存在しない

容量不均一型（expertのFFN次元を変えるHMoE型）× 多言語性能を測った研究は、**探索した限り存在しない**。

- HMoE：英語6ベンチ（＋MMLU）のみ、RedPajama学習、非英語の実験・分析なし。
- MoDSE：英中100Bトークン、MMLU/GSM8K等すべて英語ベンチ。
- EMNLP camera-ready PDFは取得できず、arXiv版・HF版・複数の中間要約を確認したが多言語評価の追加はなし。
- 追従研究も「HMoE multilingual」「heterogeneous capacity + multilingual eval」等で探索したが該当なし。

→ **「容量不均一は多言語に効く／効かない」はエビデンスがなく、論じられているのは機構的な期待と懸念のみ。**

### 近傍の前向きな実証（異種expert × 多言語）

不均一性の効能そのものが多言語で否定されているわけではない。

- **MoSTE（ICIC 2026）** ：局所CNN型expert ＋ 大域Attention型expertという**異種構成** ＋ 言語タイプ別ルーティング ＋ スケール整合 fusion。
  - TED-6多言語翻訳：最良ベースライン比 **+0.51 BLEU**、均質MoCE比 **+0.83 BLEU / +1.87 chrF**
  - 活性パラメータ **−21.5%（53.4M）** 、スループット +34.6%（175,790 WPS）
- **CDMoE（Knowledge-Based Systems）** ：共有の横断言語経路 ＋ 言語別専門家経路の二重経路。
  - NLLB-200 1.3Bに対し FLORES-200 **+1.47 BLEU4 / +2.80 chrF++**、IWSLT **+2.23 / +3.13**、WMT **+1.87 / +2.77**。パラメータ増なし。
- **ScriptMoE（多言語シーンテキスト認識）** ：
  - **共有expertの除去がアラビア文字・チベット文字など低リソーススクリプトを最も痛める。**
  - スクリプトごとにexpert（10個）を割り当てると各expertの学習サンプルが不足して悪化。4 experts + top-2 が最良。

→ 効いているのは「サイズの大小」そのものより、**大容量側を難しい／低リソースなトラフィックに確実に割り当てる経路設計と、共有expertの存在**。

### 機構論（未検証）

**追い風**
- HMoEは難トークンを大expertへ回す設計。MoDSEは「ベースラインでCEが高いトークンは最大expertに回る確率が2倍」と報告。
- 低リソース言語は系統的に予測が難しい（AfriMMLU：fertilityが精度の分散の20〜50%を説明、アフリカ言語は英語比平均 −25pt）。
- 多言語のボトルネックは容量希釈（curse of multilinguality）。容量可変のSMoEは94言語で +1.63 BLEU。
- → 難言語に自動的に多くの容量が回るという意味では多言語と相性が良いはず。

**逆風（P-Penaltyとの衝突）**
- P-Penaltyは「小expertを優先して活性パラメータを倹約する」**グローバルな**圧力。
- 低リソーストークンが系統的に難トークンなら、この一律の倹約圧力は**まさに容量を必要とする言語から容量を取り上げる**方向に働く。
- 大expert＝非英語・低リソース担当、小expert＝英語の機能語担当、という**言語沿いの偏りが固定化**する恐れ（HMoEの分析では小expertが "the" のような高頻度機能語を担当）。

**コスト（二重課税）**
- HMoEはトークンごとに活性パラメータが変わる（3Bで平均0.68B vs 均質MoE 1.23B）。
- 非英語が大expertに寄るなら、非英語は**トークナイザ税の上に活性パラメータ税を重ねて払う**。
- トークナイザ税の実測：アフリカ20言語で英語比中央値 **1.88倍**、N'Koで最大 **8.92倍**（GPT-5トークナイザ）。推論コスト・遅延に同倍率で跳ね返る。日本語・中国語もfertilityが高い側。
- AfriMMLU：fertilityが1語あたり1トークン増えるごとに精度が平均8〜18pt低下。トークン倍増で学習コスト4倍（O(n²)）。

**運用**
- 言語別expertを枝刈りして軽量な単言語モデルを作るMeLt型デプロイは、低リソーストラフィックが大expertに集約されるほど効果が薄れる。

### 検証提案

1. **学習**：CulturaX等のバランス多言語コーパス（高リソース＋低リソース混成）で、HMoEの arithmetic / hybrid 各構成を均質MoEと **IsoFLOP** で比較。
2. **評価**：言語別 bpb/loss、FLORES-200、Belebele、MGSM、Global-MMLU、AfriMMLU。
3. **新規指標（HMoE固有・最大の貢献点）** ：
   - **言語別の活性パラメータ／トークン**
   - 言語別のexpertサイズ分布
   - 英語とのルーティングJSD、ルーティングエントロピー
   - （均質MoEには存在しない公平性の指標）
4. **介入**：P-Penalty係数の言語別（またはエントロピー別）スケジュール、shared expert併用、hybrid構成の多言語での再評価。
5. **比較線**：RA-MoE・SARA・RISE はすべて均質MoE前提 → 「不均一版がこれらを上回るか」がそのまま問になる。

### 実務判断

多言語性能が主目的なら、実証がある順に：

1. **shared expert ＋ 細粒度routed expert（DeepSeekMoE型）**
2. **中層のルーティング整合（英語task expertへの寄せ）**
3. **バランス取れたデータでのCPT**

HMoE型は「英語中心のタスクで活性パラメータとFLOPsを削りたい」局面の選択肢であり、多言語で採用するなら上記3の指標を測ってからにすべき。

**不確実性の明示**：追い風・逆風の議論は「難トークン→大expert」「低リソース言語は予測が難しい」「fertilityが高いほど精度が低い」という3つの実測事実をつないだ推論であり、容量不均一MoE上での直接測定ではない。

---

<a id="q3"></a>
## Q3: ここでのCPTとは

**CPT = Continual Pre-Training（継続事前学習／継続事前訓練）**

すでに事前学習済みのモデルに、ラベル付けされていない生テキストを追加投入し、ふたたび次トークン予測で学習させる工程。日本語では「継続事前学習」が定訳。

### 本対話での使われ方

- **バランス多言語コーパスでのCPT**：Qwen3-30B-A3B や Nemotron-3-Nano-30B-A3B のような英語中心MoEを、対象言語と英語をバランスよく混ぜた**生コーパス**で追加学習する（arXiv:2605.17598）。これでヘブライ語・日本語の深層routing collapseが是正され、shared expertへのルーティングが回復。
- **SFTとの対比**：同論文では、指示データによる教師ありファインチューニング（SFT）単独では最深层の偏りが残り、**CPTの方が効果的**だった。
  - → 「タスクデータで調整する」のではなく「生テキストの事前学習分布そのものを直す」必要がある、という主張。
- **近傍用語**：MoE-LPRの「post-pretraining」、LLM-jp-4の「中間訓練（mid-training）」はほぼ同種の工程。

### 区別の要点

| | CPT | SFT |
|---|---|---|
| データ | 生テキスト（ラベルなし） | 指示応答データ |
| 目的関数 | 次トークン予測（loss/perplexity） | 教師あり目的 |
| 狙い | 言語・ドメイン知識の底上げ、分布の是正 | タスク遂行・指示追従 |

→ 前回答の「バランス取れたデータでのCPT」は、翻訳タスクデータではなく、**対象言語の生テキストを英語と拮抗する比率で混ぜて追加事前学習する**という意味。

---

<a id="q4"></a>
## Q4: 「Gini係数の高いデータ系でのみHMoEが強みを発揮する」という前提について

### 前提そのものが要検証

**「Gini係数の高いデータ系でのみHMoEが強みを発揮する」という知見は、探索した範囲では存在しない。** したがって「だから多言語性能は期待できない」という推論は、前提未確認のまま進んでいる。

### 論点1：そのGini係数は何のGiniか

- 多言語MoE文献でGini係数が出てくるのは **arXiv:2605.17598**（低リソース言語のルーティング解析）。そこでは **expert使用量の集中度**（エントロピーと並ぶ指標）として使われている。
- これは**データの性質ではなくルーティングの結果**。
- 「expert活性化が偏っている系でこそHMoEが効く」という意味なら、それは**検証された主張ではない**。
- HMoEのP-Penaltyはむしろ「大expertへの過剰集中を是正する」方向の損失。
- 同論文では **Gini的な集中（深層routing collapse）はヘブライ語・日本語で性能低下と結びつく「問題」** として報告されている。
  - → 高Gini＝HMoEの活きる舞台、ではなく、**高Gini＝低リソース言語が困っている状態** というのが見つかった証拠の向き。

### 論点2：「データのGini」を言語分布・トークン難易度の歪みと定義するなら

- 多言語コーパスは典型的な高不均等データ（英語支配の言語混合、Zipf的トークン頻度、低リソース言語の難トークンの長い裾）。
- この定義を採るなら**条件は満たされており、「期待できない」どころか追い風側**。
- SMoEは94言語のOPUS-100でSwitch比 +1.63 BLEU と、ばらつきが大きい設定でこそ差が出ている。

### 論点3：ユーザーの結論が部分的に正しくなる筋道（唯一の妥当な読み替え）

- HMoEの効率ゲインは「大量の易しいトークンを小expertに流して浮いた計算を難トークンに回す」ことから生じる（3Bで平均活性0.68B vs 均質MoE 1.23B）。
- 多言語をまともにやるには低リソース言語を意図的にoversampleして**分布を均す**のが定石（＝Q3のCPTで挙げた操作）。
- 分布を均すと易トークンの塊が相対的に減る。
- → 正しくは「多言語だから期待できない」のではなく、 **「多言語を公平に扱おうとするほど、HMoEが稼ぐ原資（易トークンの塊）が減る」** 。この形ならご指摘は筋が良い。

### それでも多言語に慎重であるべき理由（Giniとは独立）

- P-Penaltyという**グローバルな倹約圧力**が高エントロピー言語から容量を奪いうる。
- 大expertに非英語トラフィックが集中し、活性パラメータが言語ごとに変動（トークナイザ税への二重課税）。
- 何より**HMoE型を多言語で測った実験が一つもない**。

### 検証提案

「Gini条件」を実証的に使うなら、**言語別のexpert使用量Gini係数**と**言語別の活性パラメータ／トークン**を指標に、均質MoEとHMoEをIsoFLOPで比較するのが最短。

→ 「HMoEはどのGini領域で得をするか」と「その領域に多言語が入るか」が一度に判定できる。

### 現時点で言えること

 **「期待できないと結論づける根拠はないが、期待できると主張する根拠もない。」** 

Gini条件の出典があれば、そこを起点に議論を詰められる。

---

<a id="確実"></a>
## 確実に言えること／言えないこと

### 確実（実証あり）

- HMoEは英語ベンチで、より少ない活性パラメータで均質MoEを上回る（0.68B/46.53 vs 1.23B/45.62）。
- 多言語MoEのルーティングはU字型（浅層・深層が言語特化、中層が言語非依存ハブ）。
- 中層を英語のtask expertに寄せる介入は、複数モデル・15言語超で1〜2ptの改善。
- 低リソース言語（ヘブライ語・日本語等）で深層routing collapseが起き、バランスCPTが是正しSFT単独は不十分。
- 異種expert構成（MoSTE、CDMoE）は多言語MTで均質MoEを上回る。
- shared expertの存在は低リソース言語・スクリプトに特に重要（ScriptMoE）。
- トークナイザ税（fertility）は低リソース言語に実コスト・精度ペナルティを課す。
- LLM-jp-4 32B-A3B は日本語MT-BenchでGPT-4oを上回る（7.82 vs 7.29）。

### 言えない（未検証・要注意）

- **容量不均一型HMoEが多言語に効くかどうか**（実験が存在しない）。
- **「Gini係数の高いデータ系でのみHMoEが強みを発揮する」という前提自体**（文献未確認）。
- heterogeneity戦略の最適解（hybrid vs arithmetic で報告が揺れ）。
- P-Penaltyが多言語で逆風になるかどうか（機構論上の懸念のみ）。

---

<a id="出典"></a>
## 主要出典

- Wang et al., **HMoE: Heterogeneous Mixture of Experts for Language Modeling**, EMNLP 2025（arXiv:2408.10681）
- MoDSE: Mixture of Diverse Size Experts
- Xu et al., **Towards Being Parameter-Efficient: A Stratified Sparsely Activated Transformer with Dynamic Capacity (SMoE)** , Findings of EMNLP 2023（arXiv:2305.02176）
- Bandarkar et al., **Multilingual Routing in Mixture-of-Experts**（arXiv:2510.04694）
- Chen et al., **Understanding Multilingualism in MoE LLMs: Routing Mechanism, Expert Specialization, and Layerwise Steering**（arXiv:2601.14050）
- **Mixture of Experts for Low-Resource LLMs**（arXiv:2605.17598）
- RISE: Unveiling Language Routing Isolation in Multilingual MoE Models（arXiv:2604.03592）
- RA-MoE: Routing-Aligned Fine-Tuning（arXiv:2605.28306）
- SARA: Semantically Anchored Routing Alignment（arXiv:2606.25821）
- MoE-LPR（arXiv:2408.11396, AAAI 2025）；MeLt（ACM 2026）
- NeuronMoE（EACL 2026）；MoE-CT
- MoSTE（ICIC 2026）；CDMoE（Knowledge-Based Systems）；ScriptMoE
- Alibaba, **Orchestrating Heterogeneous Experts**（arXiv:2602.00003 / WWW Companion '26）
- Marco-MoE（arXiv:2604.25578）
- The Token Tax（arXiv:2509.05486, AfriMMLU）；The African Language Tax（arXiv:2606.24460）
- LLM-jp-4（NII, 2026）；Rakuten AI 3.0（2026）

---

*本ファイルは対話内容の要約。数値・引用は各回答時点の検索結果に基づく。*