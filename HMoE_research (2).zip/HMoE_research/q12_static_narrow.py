#!/usr/bin/env python3
"""Q12: 「両方 32」セル — 分離したまま両プールを最小幅にする。

2×2 の空きセル:
                struct 32            struct 224
  payload 224   static_1x  0.684     dense224x2 0.149（共有・分離なし）
  payload 32    **static_narrow ?**  static_swapped 0.463

  幅ベクトルが 32/32/96/96/160/160/224/224 なので、「分離したまま両方 224」は作れない
  （224 は 2 本しかない）。作れる分離セルは (32,224) / (224,32) / (32,32) の 3 つ。

本実験の条件:
  static_narrow : struct→e0(32), payload→e1(32)   ← **両方 32・分離**
  static_1x     : struct→e0(32), payload→e6(224)  ← payload だけ広い
  static_swapped: struct→e6+e7(224), payload→e0+e1(32) ← struct だけ広い
  dynamic_lb    : 学習ルータ（参照）

  static_narrow vs swapped  → **struct の幅の効果**（payload は 32 で固定）
  static_narrow vs static_1x → **payload の幅の効果**（struct は 32 で固定）

予測:
  - payload に幅が必要なら static_narrow は崩壊する
  - 分離だけで足りるなら static_narrow も 0.4〜0.6 に乗る（swapped と同程度）
"""
import argparse
import json
import os
import sys

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import q10_single_expert as Q10  # noqa: E402  （import 時に Q8.forward_dispatch をパッチ）
import q8_static_dispatch as Q8  # noqa: E402

Q10.POOLS["static_narrow"] = ([(0, 1.0)], [(1, 1.0)])
# q11 を import しないと static_swapped が登録されず、Q8 の動的ルータに黙ってフォールバックする。
# 幅の記録が 224/32 になっているかで必ず確認する（今回これで 3 ランを捨てた）。
Q10.POOLS["static_swapped"] = ([(6, 0.5), (7, 0.5)], [(0, 0.5), (1, 0.5)])

OUTDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q12")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", nargs="+", default=["hard"])
    ap.add_argument("--modes", nargs="+",
                    default=["dynamic_lb", "static_1x", "static_swapped", "static_narrow"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4, 5])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--threads", type=int, default=6)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--outdir", default=None)
    args = ap.parse_args()

    global OUTDIR
    if args.outdir:
        OUTDIR = os.path.join(HERE, args.outdir)
    Q8.OUTDIR = OUTDIR
    os.makedirs(OUTDIR, exist_ok=True)
    torch.set_num_threads(args.threads)
    print(f"Q12: tasks={args.tasks} modes={args.modes} seeds={args.seeds}", flush=True)

    rows = []
    expect = {"static_narrow": (32.0, 32.0), "static_swapped": (224.0, 32.0),
              "static_1x": (32.0, 224.0)}
    for task in args.tasks:
        for mode in args.modes:
            for seed in args.seeds:
                p = os.path.join(OUTDIR, f"H+LB_{task}_{mode}_s{seed}.json")
                if args.resume and os.path.exists(p):
                    with open(p, encoding="utf-8") as f:
                        r = json.load(f)
                    if r.get("n_eval") == 1024:
                        e = r["eval"]["base"]
                        if mode in expect:
                            ws, wp = expect[mode]
                            assert abs(e["width_struct"] - ws) < 1e-6 and \
                                abs(e["width_payload"] - wp) < 1e-6, \
                                f"{mode} s{seed} の幅が設計と違う: " \
                                f"{e['width_struct']}/{e['width_payload']}"
                        print(f"  [skip] {task} {mode} s{seed}", flush=True)
                        rows.append(r)
                        continue
                r = Q8.run(task, mode, seed, args.seqs, args.epochs, args.bs, args.lr)
                rows.append(r)
                e = r["eval"]["base"]
                if mode in expect:
                    ws, wp = expect[mode]
                    assert abs(e["width_struct"] - ws) < 1e-6 and \
                        abs(e["width_payload"] - wp) < 1e-6, \
                        f"{mode} s{seed} の幅が設計と違う（プール未登録の疑い）: " \
                        f"{e['width_struct']}/{e['width_payload']}"
                print(f"  -> {task} {mode} s{seed}: "
                      f"acc pl={e['acc_payload']:.4f} iv={e['instr_valid']:.3f} "
                      f"ce pl={e['ce_payload']:.4f} "
                      f"w_st/pl={e['width_struct']:.1f}/{e['width_payload']:.1f}", flush=True)
                with open(p, "w", encoding="utf-8") as f:
                    json.dump(r, f, ensure_ascii=False, indent=2)

    with open(os.path.join(OUTDIR, "q12_results.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
    print(f"[write] {OUTDIR}", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
