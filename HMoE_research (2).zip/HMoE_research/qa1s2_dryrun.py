# -*- coding: utf-8 -*-
"""QA1S2 Step 1: 3 実装の dry-run（学習 0 epoch）と C1〜C6 校正.

設計書: `QA1S2課題設計書_幅3腕をA4bハーネスに載せDelta_ivを7seedで検定する_20261114.md`
        §1 / §4 / §7 / §9

本次の範囲
  - `a4_small_expert_act.run_one` の `widths_override` / `act_override`（後方互換）
  - 新規 `qa1s2_policy.py` の `PolicyActMoE`（3 点対照）
  - C1〜C6 の dry-run。**6 epoch × 7 seed の本番学習・確認的 `Δ_iv` は未実施**

走行前に固定した観測統計量と閾値（設計書 §7 を数値化）
  C1 `all_relu2` の gain 集計と A4b 保存値の maxdiff        < 1e-9
     既存 A4 raw / A4b matched の `evals` maxdiff（6 seed）  < 1e-9
  C2 3 腕の `gain.by_position`                              各 32 個・有限・欠損 0
     `run_one` の gain と QA1 Step 1 保存値                  < 1e-9（by_expert は 5e-5）
  C3 3 腕の合計幅                                           すべて 1024
  C4 3 腕の位置 `(l,i)` キー集合の対称差                     = 0
  C5 3 点対照の差し替え実証（本次の dry-run 版・§4 を具体化）  下記 4 条件すべて
  C6 全出力の非有限値                                         = 0

C5 の dry-run 版（設計書 §7 の `random ≤ oracle` は本番判定に委ねる）
  学習 0 epoch の初期重みでは `instr_valid` が全方策で 0 になり得るため、
  dry-run では「`topi` gather まで差し替えが効いているか」を主校正に置く:
    ① 3 方策間の `first_logits` ペア間 maxdiff がすべて > 0
    ② `oracle_typ_agreement` = 1.0（struct/input → e0、payload → e6）
    ③ `uniform_expert_coverage` = E（全 expert が選ばれる）
    ④ `random_usage_max_rel_dev` < 0.05（一様乱数の使用率偏差）
  `instr_valid(random) <= instr_valid(oracle)` と `ce_all` の大小は参考記録のみ。

出力: qa1s2_s1_metrics.json / qa1s2_s1_gain.npz / qa1s2_s1.log（すべて UTF-8）
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import a4_small_expert_act as A4        # noqa: E402
import qa1s2_policy as POL              # noqa: E402
import q1_trace_routing as Q1           # noqa: E402
from a1_activation_ffn import ActMoE    # noqa: E402

TAG = "qa1s2_s1"
W_REF = (32, 32, 96, 96, 160, 160, 224, 224)
W_MID = (96, 96, 96, 96, 160, 160, 160, 160)
W_FLAT = (128,) * 8
ARMS = {"w_ref": W_REF, "w_mid": W_MID, "w_flat": W_FLAT}
ACTS = ["relu2"] * 8
WIDTH_TOTAL = 1024
N_POS = 32
EPS_C1 = 1.0e-9
EPS_ROUND = 5.0e-5
EVAL_N = 128                 # dry-run 用。本番は 1024 系列（設計書 §4）
EVAL_SEED = 777
DRY_TAG = "_qa1s2dry"
C1_TAG = "_qa1s2c1"
C5_POLICIES = ("learned", "uniform", "random", "oracle")
C5_MAX_REL_DEV = 0.05


def flatten_numeric(o, path="root"):
    out = {}
    if isinstance(o, dict):
        for k, v in o.items():
            out.update(flatten_numeric(v, f"{path}.{k}"))
    elif isinstance(o, list):
        for j, v in enumerate(o):
            out.update(flatten_numeric(v, f"{path}[{j}]"))
    elif isinstance(o, (int, float)) and not isinstance(o, bool):
        out[path] = float(o)
    return out


def maxdiff_dict(a, b):
    fa, fb = flatten_numeric(a), flatten_numeric(b)
    keys = set(fa) | set(fb)
    miss = [k for k in keys if k not in fa or k not in fb]
    d = [abs(fa[k] - fb[k]) for k in keys if k in fa and k in fb]
    return (max(d) if d else 0.0), len(keys), miss


def gain_grid(bp, L=4, E=8):
    g = np.full((L, E), np.nan)
    for k, v in bp.items():
        l, i = (int(x) for x in k.split(","))
        g[l, i] = v
    return g


def main():
    out = {
        "tag": TAG,
        "phase": "QA1S2 Step 1 (3 implementations + C1-C6 dry-run, 0 epochs)",
        "design": "QA1S2課題設計書_幅3腕をA4bハーネスに載せDelta_ivを7seedで検定する_20261114.md",
        "no_training": True, "no_confirmatory_test": True,
    }
    out["prereg"] = {
        "W_REF": list(W_REF), "W_MID": list(W_MID), "W_FLAT": list(W_FLAT),
        "ACTS": ACTS, "WIDTH_TOTAL": WIDTH_TOTAL, "N_POS": N_POS,
        "EPS_C1": EPS_C1, "EPS_ROUND": EPS_ROUND,
        "EVAL_N": EVAL_N, "EVAL_SEED": EVAL_SEED,
        "C5_POLICIES": list(C5_POLICIES), "C5_MAX_REL_DEV": C5_MAX_REL_DEV,
        "thresholds": {
            "C1": "gain summary maxdiff < 1e-9; A4 raw vs matched evals < 1e-9 (6 seeds)",
            "C2": "each arm has 32 finite gain positions; run_one gain == QA1S2 Step1 saved",
            "C3": "all(sum(widths) == 1024)",
            "C4": "symmetric difference of position key sets == 0",
            "C5": "logits pairs differ; oracle agreement 1.0; uniform coverage E; random rel dev < 0.05",
            "C6": "nonfinite == 0",
        },
        "C5_note": (
            "設計書 §7 の instr_valid(random) <= instr_valid(oracle) は学習後でないと"
            "自明になり得るため本番判定に委ね、dry-run では差し替えの実証を主校正とする。"
            "本観測統計量と閾値は結果を見る前に本ファイル内で固定した。"
        ),
    }

    # ---- C1: 既存挙動が 1 bit も変わっていないか
    r0 = A4.run_one(arm="all_relu2", seed=0, scale=1.0, n_seqs=128, epochs=0,
                    bs=32, lr=2e-3, auxw=0.05, gain="matched", eval_every=1,
                    tag=C1_TAG)
    saved = json.loads((HERE / "data" / "a4" / "all_relu2_s0_g.json").read_text(
        encoding="utf-8"))["gain"]
    g0 = r0["gain"]
    d = {
        "n": abs(g0["n"] - int(saved["n"])),
        "min": abs(g0["min"] - float(saved["min"])),
        "max": abs(g0["max"] - float(saved["max"])),
        "mean": abs(g0["mean"] - float(saved["mean"])),
        "by_expert": max(abs(a - b) for a, b in zip(g0["by_expert"], saved["by_expert"])),
    }
    c1c = []
    for seed in range(6):
        raw = json.loads((HERE / "data" / "a4" / f"all_relu_s{seed}.json").read_text(
            encoding="utf-8"))
        g = json.loads((HERE / "data" / "a4" / f"all_relu_s{seed}_g.json").read_text(
            encoding="utf-8"))
        md, nk, miss = maxdiff_dict(raw.get("evals", []), g.get("evals", []))
        c1c.append({"seed": seed, "maxdiff": md, "n_numeric": nk,
                    "n_missing": len(miss)})
    out["C1"] = {
        "gain_summary_diff": d,
        "gain_summary_pass": bool(g0["n"] == int(saved["n"])
                                  and max(d["min"], d["max"], d["mean"]) < EPS_C1
                                  and d["by_expert"] < EPS_ROUND),
        "raw_vs_matched_evals": c1c,
        "evals_maxdiff_all": max(x["maxdiff"] for x in c1c),
        "evals_pass": bool(all(x["n_missing"] == 0 and x["maxdiff"] < EPS_C1 for x in c1c)),
        "existing_keys_present": all(k in g0 for k in
                                     ("mode", "n", "min", "max", "mean", "by_expert")),
        "pass": None,
    }
    out["C1"]["pass"] = bool(out["C1"]["gain_summary_pass"]
                             and out["C1"]["evals_pass"]
                             and out["C1"]["existing_keys_present"])

    # ---- 3 腕を widths_override / act_override で走らせる（epochs=0）
    step1 = json.loads((HERE / "qa1_s1_metrics.json").read_text(encoding="utf-8"))
    arms, grids = {}, {}
    for name, W in ARMS.items():
        r = A4.run_one(arm=name, seed=0, scale=1.0, n_seqs=128, epochs=0,
                       bs=32, lr=2e-3, auxw=0.05, gain="matched", eval_every=1,
                       tag=DRY_TAG, widths_override=W, act_override=ACTS)
        bp = r["gain"]["by_position"]
        grid = gain_grid(bp)
        grids[name] = grid
        arms[name] = {
            "widths": r["widths"], "act_i": r["act_i"],
            "width_sum": int(sum(r["widths"])),
            "n_positions": len(bp),
            "keys": sorted(bp.keys()),
            "finite": bool(np.isfinite(grid).all()),
            "by_expert": r["gain"]["by_expert"],
            "gain_min": r["gain"]["min"], "gain_max": r["gain"]["max"],
            "gain_mean": r["gain"]["mean"],
            "step1_by_expert": step1["arms"][name]["by_expert"],
            "step1_min": step1["arms"][name]["min"],
            "nparam": r["nparam"],
            "loss_hist_len": len(r["loss_hist"]),
        }
    out["arms"] = arms

    # ---- C2 / C3 / C4
    keysets = {n: set(a["keys"]) for n, a in arms.items()}
    c2_step1 = max(
        max(abs(a - b) for a, b in zip(arms[n]["by_expert"], arms[n]["step1_by_expert"]))
        for n in ARMS)
    checks = {
        "C1_unchanged": out["C1"]["pass"],
        "C2_gain_32_each": bool(all(
            a["n_positions"] == N_POS and a["finite"] for a in arms.values())),
        "C2_gain_matches_step1": bool(c2_step1 < EPS_ROUND),
        "C3_width_sum_equal": bool(all(a["width_sum"] == WIDTH_TOTAL for a in arms.values())),
        "C4_position_keys_identical": bool(all(
            keysets[n] == keysets["w_ref"] for n in ARMS)),
        "C3_act_i_all_relu2": bool(all(a["act_i"] == ACTS for a in arms.values())),
        "C3_no_training": bool(all(a["loss_hist_len"] == 0 for a in arms.values())),
    }
    out["C2_C3_C4"] = {
        "step1_by_expert_maxdiff": c2_step1,
        "key_symmetric_difference": sum(len(keysets[n] ^ keysets["w_ref"]) for n in ARMS),
        "width_sums": {n: arms[n]["width_sum"] for n in ARMS},
    }

    # ---- C5: PolicyActMoE の差し替え実証
    ev_rng = np.random.default_rng(EVAL_SEED)
    ev_seq, ev_typ = Q1.make_trace_batch(ev_rng, EVAL_N)
    model = POL.PolicyActMoE(W_REF, "relu", seed=0, act_i=ACTS, rng_seed=0)
    pol_res = {}
    for pol in C5_POLICIES:
        res = POL.eval_policy(model, ev_seq, ev_typ, pol, bs=128)
        pol_res[pol] = {
            "ce_all": res["ce_all"], "ce_payload": res["ce_payload"],
            "instr_valid": res["instr_valid"], "instr_acc": res["instr_acc"],
            "first_logits": res["first_logits"],
            "topi_shape": list(res["topi"].shape),
        }
    E = model.E
    logits_pairs = {}
    for i, p in enumerate(C5_POLICIES):
        for q in C5_POLICIES[i + 1:]:
            a, b = pol_res[p]["first_logits"], pol_res[q]["first_logits"]
            logits_pairs[f"{p}__{q}"] = float(np.max(np.abs(a - b)))
    oracle_topi = POL.eval_policy(model, ev_seq, ev_typ, "oracle", bs=128)
    expect0 = np.where(oracle_topi["typ_flat"] == Q1.TYP_PAYLOAD, E - 2, 0)
    agreement = float((oracle_topi["topi"][:, 0] == expect0).mean())
    uni_topi = POL.eval_policy(model, ev_seq, ev_typ, "uniform", bs=128)["topi"]
    coverage = int(np.unique(uni_topi).size)
    rnd_topi = POL.eval_policy(model, ev_seq, ev_typ, "random", bs=128)["topi"]
    hist = np.bincount(rnd_topi.ravel(), minlength=E).astype(np.float64)
    rel_dev = float(np.max(np.abs(hist / hist.mean() - 1.0)))

    out["C5"] = {
        "policies": {p: {k: v for k, v in pol_res[p].items()
                         if k != "first_logits"} for p in C5_POLICIES},
        "logits_pair_maxdiff": logits_pairs,
        "logits_all_pairs_differ": bool(all(v > 0 for v in logits_pairs.values())),
        "oracle_typ_agreement": agreement,
        "uniform_expert_coverage": coverage, "expected_coverage": E,
        "random_usage_hist": hist.tolist(),
        "random_usage_max_rel_dev": rel_dev,
        "reference_random_le_oracle_instr": bool(
            pol_res["random"]["instr_valid"] <= pol_res["oracle"]["instr_valid"]),
        "reference_random_ge_oracle_ce": bool(
            pol_res["random"]["ce_all"] >= pol_res["oracle"]["ce_all"]),
        "pass": bool(all(v > 0 for v in logits_pairs.values())
                     and agreement == 1.0 and coverage == E
                     and rel_dev < C5_MAX_REL_DEV),
        "note": ("学習 0 epoch の参考値は判定に使わない。設計書 §7 の "
                 "`instr_valid(random) <= instr_valid(oracle)` は 6 epoch 学習後の本番で判定する。"),
    }
    checks["C5_policy_substitution"] = out["C5"]["pass"]
    out["C5"]["policies_note"] = "first_logits は npz へ保存（独立検算用）"

    # ---- 判定と C6
    out["checks"] = checks

    def scan(o, path="root"):
        bad = []
        if isinstance(o, dict):
            for k, v in o.items():
                bad += scan(v, f"{path}.{k}")
        elif isinstance(o, list):
            for j, v in enumerate(o):
                bad += scan(v, f"{path}[{j}]")
        elif isinstance(o, float) and not np.isfinite(o):
            bad.append(path)
        return bad
    # first_logits は出力 json から除外（npz へ）
    def strip(o):
        if isinstance(o, dict):
            return {k: strip(v) for k, v in o.items() if k != "first_logits"}
        return o
    nonfinite = scan(strip(out))
    checks["C6_all_finite"] = bool(len(nonfinite) == 0)
    out["C6"] = {"nonfinite_paths": nonfinite, "pass": bool(len(nonfinite) == 0)}

    out["verdict"] = "PASS" if all(checks.values()) else "FAIL"
    out["case"] = ("全校正合格。QA1S2 §9 のゲートを通過。6 epoch × 7 seed の本番へ進める"
                   "（本番は未走行、ケース A〜D の判定はしない）"
                   if out["verdict"] == "PASS" else
                   "校正不合格。本番を起動せず実装を疑う")

    # ---- 書き出し
    (HERE / f"{TAG}_metrics.json").write_text(
        json.dumps(strip(out), ensure_ascii=False, indent=2, allow_nan=False),
        encoding="utf-8")
    arrays = {f"gain_{n}": g for n, g in grids.items()}
    for p in C5_POLICIES:
        arrays[f"logits_{p}"] = pol_res[p]["first_logits"]
    arrays["oracle_topi"] = oracle_topi["topi"].astype(np.int16)
    arrays["oracle_typ"] = oracle_topi["typ_flat"].astype(np.int8)
    arrays["uniform_topi"] = uni_topi.astype(np.int16)
    arrays["random_topi"] = rnd_topi.astype(np.int16)
    np.savez(HERE / f"{TAG}_gain.npz", **arrays)
    lines = [
        f"tag={TAG}", f"verdict={out['verdict']}",
        f"C1_gain={out['C1']['gain_summary_pass']} C1_evals={out['C1']['evals_pass']}",
        f"C2_step1_by_expert_maxdiff={c2_step1:.3e}",
        f"C3_width_sums={out['C2_C3_C4']['width_sums']}",
        f"C4_key_symdiff={out['C2_C3_C4']['key_symmetric_difference']}",
        f"C5_logits_min_pairdiff={min(logits_pairs.values()):.6f}",
        f"C5_oracle_agreement={agreement:.6f} uniform_coverage={coverage} "
        f"random_rel_dev={rel_dev:.6f}",
        f"C5_pass={out['C5']['pass']}",
        f"checks={checks}", f"case={out['case']}", "",
    ]
    (HERE / f"{TAG}.log").write_text("\n".join(lines), encoding="utf-8")
    sys.stdout.write("\n".join(lines))
    sys.stdout.flush()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        sys.stderr.write(f"[qa1s2_dryrun] ERROR {type(exc).__name__}: {exc}\n")
        sys.stderr.flush()
        raise
