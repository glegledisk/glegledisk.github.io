# -*- coding: utf-8 -*-
"""AX2 事前チェック: 凍結コーパス上の base 実行が cross-process でどの程度一致するか。"""
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

print("== json base CE ==")
for f in ("p24_layer_cost.json", "p7c_width.json"):
    p = os.path.join(HERE, f)
    if not os.path.exists(p):
        print(f, "MISSING")
        continue
    d = json.load(open(p, encoding="utf-8"))
    r = d.get("results", d)
    if "base" in r and isinstance(r["base"], dict):
        print("%-24s base ce=%.8f dce=%s" % (f, r["base"]["ce"], r["base"].get("dce")))
    else:
        print(f, "keys:", list(r)[:6])

print()
print("== npz per-token base nll cross-check ==")
z24 = np.load(os.path.join(HERE, "p24_layer_cost.npz"))
print("p24 keys:", sorted(z24.files)[:6], "... n =", z24["nll_base"].size)
b24 = z24["nll_base"].astype(np.float64)

zp7 = os.path.join(HERE, "p7c_width.npz")
if os.path.exists(zp7):
    z7 = np.load(zp7)
    k7 = [k for k in z7.files if "base" in k]
    print("p7c keys with 'base':", k7)
    if k7:
        b7 = z7[k7[0]].astype(np.float64)
        if b7.size == b24.size:
            d = b7 - b24
            print("p7c.base vs p24.nll_base: mean %+.8f  max|d| %.8f  bit-exact=%s"
                  % (d.mean(), np.abs(d).max(), bool(np.all(d == 0))))
        else:
            print("size mismatch", b7.size, b24.size)
else:
    print("p7c_width.npz MISSING")

print()
print("== p24 group dCE / convexity (from npz) ==")
names = [k[4:] for k in z24.files if k.startswith("nll_") and k != "nll_base"]
base = z24["nll_base"].astype(np.float64)
dce = {}
for n in sorted(names):
    dce[n] = float((z24["nll_" + n].astype(np.float64) - base).mean())
GROUPS = {"G0": range(0, 4), "G1": range(4, 8), "G2": range(8, 12), "G3": range(12, 16)}
for g, ls in GROUPS.items():
    c1 = dce[g + "h"]                     # 1 slot (half-width proxy in P24)
    c2 = dce[g + "s"] - dce[g + "h"]      # 2nd slot marginal
    rho = c2 / c1 if abs(c1) > 1e-12 else float("nan")
    print("%s  h %+.5f  s %+.5f  t %+.5f  rho(s/h) %.3f" % (g, dce[g + "h"], dce[g + "s"], dce[g + "t"], rho))
print("u6-analogue? p24 has no u6/u7; skip")
print()
print("== frozen corpus shape ==")
zf = np.load(os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"))
print("frozen keys:", zf.files, {k: zf[k].shape for k in zf.files})
