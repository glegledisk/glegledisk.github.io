#!/usr/bin/env python3
"""Q9a の解析: static_type の勝ちは「型分離」か「幅」か。

比較（すべて同一プロセス・同一 seed の対応差）:
  dynamic_lb    : 学習ルータ + auxw 0.05（標準）
  static_type   : struct → e0/e1(32), payload → e6/e7(224)  ※Q8 の設計
  dense224      : 全トークン → e6(224) 1 本。FFN FLOPs は static の半分
  dense224x2    : 全トークン → e6+e7(224) 0.5/0.5。**static と同 FLOPs・同パラメータ**

判定:
  static − dense224x2 が有意でなければ、**型分離は何もしていない**（幅だけの効果）。
"""
import json
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q9")
OUT = []
def w(s=""):
    print(s)
    OUT.append(s)


def st(x):
    x = np.asarray(x, float)
    n = len(x)
    m = x.mean()
    sd = x.std(ddof=1) if n > 1 else 0.0
    se = sd / np.sqrt(n) if n > 1 else 0.0
    t = m / se if se > 0 else 0.0
    p = 2 * stats.t.sf(abs(t), df=n - 1) if se > 0 else 1.0
    return m, se, t, p, int((x > 0).sum()), int((x < 0).sum())


def load(task, mode, seeds=range(6)):
    rows = []
    for s in seeds:
        p = os.path.join(DATA, f"H+LB_{task}_{mode}_s{s}.json")
        with open(p, encoding="utf-8") as f:
            rows.append(json.load(f))
    e = [r["eval"]["base"] for r in rows]
    return {
        "iv": np.array([x["instr_valid"] for x in e]),
        "acc": np.array([x["acc_payload"] for x in e]),
        "ce": np.array([x["ce_payload"] for x in e]),
        "wpl": np.array([x["width_payload"] for x in e]),
        "wst": np.array([x["width_struct"] for x in e]),
        "dead": np.array([x["dead_experts"] for x in e]),
        "H": np.array([x["usage_entropy"] for x in e]),
        "sec": np.array([r["sec"] for r in rows]),
    }


MODES = ["dynamic_lb", "static_type", "dense224", "dense224x2"]
FLOP = {"dynamic_lb": None, "static_type": 224.0, "dense224": 224.0, "dense224x2": 224.0}

for task in ["hard", "compute"]:
    if not os.path.exists(os.path.join(DATA, f"H+LB_{task}_dense224x2_s5.json")):
        w(f"[skip] {task}: まだ無い")
        continue
    d = {m: load(task, m) for m in MODES}
    w("=" * 78)
    w(f"{task.upper()}")
    w("=" * 78)
    w("\n[1] 水準（n=6）")
    w(f"  {'mode':<13} {'iv':>7} {'se':>6} {'acc_pl':>8} {'ce_pl':>8} {'w_pl':>6} "
      f"{'dead':>5} {'H':>6} {'sec':>6}")
    for m in MODES:
        v = d[m]
        w(f"  {m:<13} {v['iv'].mean():7.3f} {st(v['iv'])[1]:6.3f} {v['acc'].mean():8.4f} "
          f"{v['ce'].mean():8.4f} {v['wpl'].mean():6.1f} {v['dead'].mean():5.1f} "
          f"{v['H'].mean():6.3f} {v['sec'].mean():6.0f}")

    w("\n[2] per-seed instr_valid")
    for m in MODES:
        w(f"  {m:<13} " + ", ".join(f"{x:.3f}" for x in d[m]["iv"]))

    w("\n[3] 対応差（同一 seed, df=5）")
    pairs = [("static_type", "dense224x2"), ("static_type", "dense224"),
             ("dense224x2", "dynamic_lb"), ("static_type", "dynamic_lb"),
             ("dense224", "dynamic_lb")]
    for a, b in pairs:
        w(f"  --- {a} − {b} ---")
        for k, lab in [("iv", "instr_valid"), ("acc", "acc_payload"),
                       ("ce", "ce_payload")]:
            diff = d[a][k] - d[b][k]
            m, se, t, p, npos, nneg = st(diff)
            w(f"    {lab:<14} {m:+.4f}  se {se:.4f}  t {t:+.2f}  p {p:.4f}  "
              f"正{npos}/負{nneg}")

    w("\n[4] 判定")
    m, se, t, p, npos, nneg = st(d["static_type"]["iv"] - d["dense224x2"]["iv"])
    if p < 0.05 and m > 0:
        w(f"  static は dense224x2 に勝つ（{m:+.3f}, p={p:.4f}）→ **型分離に固有の効果がある**")
    elif p < 0.05 and m < 0:
        w(f"  static は dense224x2 に負ける（{m:+.3f}, p={p:.4f}）→ **型分離は害**")
    else:
        w(f"  static と dense224x2 は区別できない（{m:+.3f}, se {se:.3f}, p={p:.4f}）")
        w("  → **型分離は幅の言い換え。Q8 の主張は「幅 224 が幅 85 より強い」に縮む**")
    m2, se2, t2, p2, _, _ = st(d["static_type"]["iv"] - d["dense224"]["iv"])
    w(f"  （参考）static − dense224（半分の FLOPs）: {m2:+.3f}, se {se2:.3f}, p={p2:.4f}")

with open(os.path.join(HERE, "q9_analysis_out_utf8.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(OUT) + "\n")
print("\n[written] q9_analysis_out_utf8.txt")
