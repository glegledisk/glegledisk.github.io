# -*- coding: utf-8 -*-
"""P7 再解析: 窓クラスタ SE・直接対比・実 FLOPs 比較（再測定なし）

背景（2026-10-28 の批評を受けて）:
  1. per-token の paired t はトークン独立性を仮定している。独立単位は実質 48 窓で、
     P4b は「1/48 窓が 87% のコスト」を報告している。窓でクラスタした SE が要る。
  2. 「h15f が勝つ」は有意な対比と n.s. の対比を並べただけ。h15f − f2 を直接検定する。
  3. h15f の実 FLOPs 節約は 8 スロット（α=0.5 は計算を飛ばさない）。同じ実節約の f1 と比べる。
  4. 「80 倍」の分母は 0 と区別できない。比ではなく差とブートストラップ CI で出す。

出力: p7_cluster.json / p7_cluster_out_utf8.txt
"""

import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TAGS = ["p7", "p7b"]
RNG = np.random.RandomState(7)


def load():
    nll, lang = {}, None
    for tag in TAGS:
        p = os.path.join(HERE, "%s_granularity.npz" % tag)
        if not os.path.exists(p):
            continue
        z = np.load(p, allow_pickle=True)
        if lang is None:
            lang = z["lang"]
        for k in z.files:
            if k.startswith("nll_"):
                nll.setdefault(k[4:], z[k])
    return nll, lang


def stats(d, df_note=""):
    d = np.asarray(d, np.float64)
    n = d.size
    m = float(d.mean())
    sd = float(d.std(ddof=1))
    se = sd / np.sqrt(n)
    return {"mean": m, "se": se, "sd": sd, "n": int(n),
            "t": m / se if se > 0 else float("nan"),
            "ci95": [m - 1.96 * se, m + 1.96 * se],
            "mde80": 2.8 * se, "note": df_note}


def fmt(d):
    return "%+.5f (se %.5f, t %+.2f, n=%d)" % (d["mean"], d["se"], d["t"], d["n"])


def main():
    nll, lang = load()
    base = nll["base"]
    n = base.size
    nw = lang.size
    per = n // nw
    assert per * nw == n

    # (nw, per) に整形（窓×トークン）
    def mat(c):
        return nll[c].reshape(nw, per)

    lines = []
    def emit(s=""):
        lines.append(s)
        print(s, flush=True)

    emit("=== P7 再解析（窓クラスタ） n=%d tokens, %d windows, %d tok/window ===" % (n, nw, per))
    emit("")

    # ---------- 0. 設計効果 ----------
    emit("[0] トークン SE と窓クラスタ SE の比（設計効果）")
    emit("%-22s %10s %10s %8s %8s %8s" % ("対比", "tok se", "win se", "比", "t_tok", "t_win"))
    out = {"n_tokens": int(n), "n_windows": int(nw), "design_effect": {}, "tests": {}}
    pairs = [
        ("u1 - base", "u1", "base"),
        ("u05 - base", "u05", "base"),
        ("f1 - base", "f1", "base"),
        ("h15f - u1", "h15f", "u1"),
        ("f2 - u1", "f2", "u1"),
        ("h15f - f2", "h15f", "f2"),
        ("f1 - h15f", "f1", "h15f"),
        ("f1 - u05", "f1", "u05"),
    ]
    for lab, a, b in pairs:
        if a not in nll or b not in nll:
            continue
        tok = stats(nll[a] - nll[b])
        win = stats(mat(a).mean(1) - mat(b).mean(1))
        ratio = win["se"] / tok["se"] if tok["se"] > 0 else float("nan")
        emit("%-22s %10.5f %10.5f %8.2f %8.2f %8.2f"
             % (lab, tok["se"], win["se"], ratio, tok["t"], win["t"]))
        out["design_effect"][lab] = {"tok": tok, "win": win, "ratio": float(ratio)}
        out["tests"][lab] = win
    emit("")

    # ---------- 1. 主要な対比（窓クラスタで判定） ----------
    emit("[1] 主要な対比（窓クラスタ t, df=47）")
    for lab, a, b in [("h15f - u1", "h15f", "u1"),
                      ("h15f - f2", "h15f", "f2"),
                      ("f2 - u1", "f2", "u1"),
                      ("f1 - h15f", "f1", "h15f"),
                      ("f1 - u05", "f1", "u05")]:
        if lab not in out["tests"]:
            continue
        d = out["tests"][lab]
        sig = "有意" if abs(d["t"]) > 2.01 else "n.s."
        emit("    %-12s %s  MDE80 %.5f  → %s" % (lab, fmt(d), d["mde80"], sig))
    emit("")

    # ---------- 2. 実 FLOPs あたり ----------
    emit("[2] 実 FLOPs 節約あたりのコスト")
    emit("    α=0.5 は計算を飛ばさないので、実節約 = 完全に落とした expert の数だけ。")
    real = {"u1": 16, "f1": 8, "b1": 8, "f2": 16, "b2": 16, "h15f": 8,
            "u05": 0, "f05": 0, "b05": 0, "f15": 8, "b15": 8, "u15": 16}
    emit("%-6s %10s %8s %14s" % ("cond", "dCE", "real", "dCE / real slot"))
    for c in ("u1", "f1", "b1", "f2", "h15f", "u15"):
        if c not in nll:
            continue
        d = float((nll[c] - base).mean())
        r = real[c]
        emit("%-6s %10.5f %8d %14s" % (c, d, r, ("%.6f" % (d / r)) if r else "—"))
        out.setdefault("per_real_slot", {})[c] = {"dce": d, "real_slots": r,
                                                  "ratio": (d / r) if r else None}
    emit("")

    # ---------- 3. セル比のブートストラップ ----------
    emit("[3] セル比（窓ブートストラップ, 4000 回）")
    def cell(a, b=None):
        """a の per-token ΔCE（b を引く）。"""
        d = nll[a] - (nll[b] if b else base)
        return d.reshape(nw, per).mean(1)

    cells = {
        "f8a": cell("f05"),                       # 前半 8番目 前半分
        "f8b": cell("f1") - cell("f05"),          # 前半 8番目 後半分
        "f7a": cell("f15") - cell("f1"),          # 前半 7番目 前半分
        "b7b": cell("b2") - cell("b15"),          # 後半 7番目 後半分
        "b8a": cell("b05"),
    }
    out["cells"] = {}
    for k, v in cells.items():
        d = stats(v)
        emit("    %-4s %s" % (k, fmt(d)))
        out["cells"][k] = d
    # 比 b7b / f8a のブートストラップ
    num, den = cells["b7b"], cells["f8a"]
    bs = []
    for _ in range(4000):
        idx = RNG.randint(0, nw, nw)
        dd = den[idx].mean()
        if dd > 1e-9:
            bs.append(num[idx].mean() / dd)
    bs = np.array(bs)
    emit("    b7b / f8a = %.1f  95%% CI [%.1f, %.1f]（分母が 0 に近いので比は不安定）"
         % (num.mean() / den.mean(), np.percentile(bs, 2.5), np.percentile(bs, 97.5)))
    emit("    差 b7b − f8a = %s" % fmt(stats(num - den)))
    out["ratio_b7b_f8a"] = {
        "point": float(num.mean() / den.mean()),
        "ci95_boot": [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))],
        "diff": stats(num - den),
    }
    emit("")

    # ---------- 4. 事後性と多重比較 ----------
    emit("[4] 事後性")
    emit("    事前登録: 予算 8 の不等式（不成立, +0.00179 t=+1.45）")
    emit("    事後に見つかった勝ち: 予算 16 の h15f − u1")
    emit("    探索した対比: 上記 8 本 + セル 5 本。Bonferroni(8) の閾値は |t| > 2.73")
    emit("")

    # ---------- 5. 言語別（窓クラスタ） ----------
    emit("[5] 言語別（窓クラスタ）")
    is_en = np.array([x == "en" for x in lang])
    out["per_lang"] = {}
    for lab, a, b in [("h15f - u1", "h15f", "u1"), ("h15f - f2", "h15f", "f2")]:
        for lg, sel in (("en", is_en), ("ja", ~is_en)):
            d = stats(mat(a).mean(1)[sel] - mat(b).mean(1)[sel])
            emit("    %-10s %s: %s" % (lab, lg, fmt(d)))
            out["per_lang"]["%s:%s" % (lab, lg)] = d
    emit("")

    with open(os.path.join(HERE, "p7_cluster.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2, default=float)
    with open(os.path.join(HERE, "p7_cluster_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(lines) + "\n")
    print("saved: p7_cluster.json / p7_cluster_out_utf8.txt")


if __name__ == "__main__":
    main()
