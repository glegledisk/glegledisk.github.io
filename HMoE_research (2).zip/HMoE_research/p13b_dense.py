#!/usr/bin/env python3
"""P13b: 等 active FLOPs の小型 dense を、E2 と同一の手順で訓練する。

批評（2026-10-29）の 1 への回答の 3 本目。HMoE の高速経路（小 expert 群）と
同質 MoE の低 k に加えて、同じ active width の dense を並べる。

dense の作り方: RewriteMoE を E=1, k=1 で構築する。ルータの softmax が 1 次元になるので
ゲートは恒等的に 1.0 になり、単なる 2 層 MLP（幅 W）になる。実装の共有で条件が揃う。

訓練条件は E2 と同一（seqs=3000, epochs=6, bs=32, lr=2e-3, 評価は seed 777 の 2048 系列）。

出力: p13b_dense.json / p13b_dense.csv / ckpt_dense{W}_s{seed}.pt（data/e2 配下）
"""
import argparse
import csv
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, E2DIR)
from e2_rewrite_routing import (  # noqa: E402
    RewriteMoE, Adam, make_batch, to_seq, out_loss, SL, OL, V)

OUTDIR = os.path.join(E2DIR, "data", "e2")


@torch.no_grad()
def evaluate_dense(model, src, out, em, bs=128):
    n = src.shape[0]
    ce = np.zeros((n, OL), dtype=np.float32)
    hit_c = np.zeros((n, OL), dtype=bool)
    hit_e = np.zeros((n, OL), dtype=bool)
    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = to_seq(src[s], out[s])
        logits, _, _ = model(x, aux_mode="none")
        lg = logits[:, SL:SL + OL, :]
        tgt = torch.from_numpy(out[s])
        lp = F.cross_entropy(lg.reshape(-1, V), tgt.reshape(-1),
                             reduction="none").reshape(-1, OL)
        ce[s] = lp.numpy()
        pred = lg.argmax(-1).numpy()
        m = em[s]
        hit_c[s] = (pred == tgt.numpy()) & (~m)
        hit_e[s] = (pred == tgt.numpy()) & m
    mask = em
    return {
        "ce_copy": float(ce[~mask].mean()), "ce_edit": float(ce[mask].mean()),
        "ce_all": float(ce.mean()),
        "acc_copy": float(hit_c.sum() / max(1, (~mask).sum())),
        "acc_edit": float(hit_e.sum() / max(1, mask.sum())),
        "ce_seq": ce.mean(1).astype(np.float64).tolist(),
    }


def train(width, seed, n_seqs, epochs, bs, lr):
    torch.manual_seed(seed)
    rng = np.random.default_rng(1000 + seed)      # E2 と同一のデータ列
    model = RewriteMoE([width], seed=seed, topk=1)
    opt = Adam(model.params(), lr=lr)
    steps = max(1, n_seqs // bs)
    t0 = time.time()
    hist = []
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps):
            src, out, em, _ = make_batch(rng, bs)
            x = to_seq(src, out)
            logits, _, _ = model(x, aux_mode="none")
            loss = out_loss(logits, out)
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        hist.append(run / steps)
        print("    [dense W=%d s%d] ep%d/%d loss=%.4f (%.0fs)"
              % (width, seed, ep + 1, epochs, hist[-1], time.time() - t0), flush=True)
    return model, hist


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--widths", nargs="+", type=int, default=[114, 213, 256])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--n_eval", type=int, default=2048)
    args = ap.parse_args()
    torch.set_num_threads(6)

    ev_rng = np.random.default_rng(777)
    src, out, em, ks = make_batch(ev_rng, args.n_eval)

    rows = []
    for w in args.widths:
        for seed in args.seeds:
            print("\n[dense W=%d s%d]" % (w, seed), flush=True)
            model, hist = train(w, seed, args.seqs, args.epochs, args.bs, args.lr)
            r = evaluate_dense(model, src, out, em)
            r.update({"arm": "dense", "seed": seed, "cond": "dense",
                      "width": float(w), "n_eval": args.n_eval,
                      "nparam": int(sum(v.numel() for v in model.params().values())),
                      "loss_hist": hist})
            rows.append(r)
            torch.save({k: v.detach() for k, v in model.params().items()},
                       os.path.join(OUTDIR, "ckpt_dense%d_s%d.pt" % (w, seed)))
            print("  -> W=%d s%d  CE(all) %.4f  copy %.4f  edit %.4f  params %d"
                  % (w, seed, r["ce_all"], r["acc_copy"], r["acc_edit"], r["nparam"]),
                  flush=True)

    with open(os.path.join(HERE, "p13b_dense.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2, default=float)
    keys = ["arm", "seed", "cond", "width", "nparam", "ce_all", "ce_copy",
            "ce_edit", "acc_copy", "acc_edit"]
    with open(os.path.join(HERE, "p13b_dense.csv"), "w", newline="",
              encoding="utf-8") as f:
        w_ = csv.DictWriter(f, fieldnames=keys)
        w_.writeheader()
        for r in rows:
            w_.writerow({k: r[k] for k in keys})
    print("\nsaved: p13b_dense.json / p13b_dense.csv")
    os._exit(0)


if __name__ == "__main__":
    main()
