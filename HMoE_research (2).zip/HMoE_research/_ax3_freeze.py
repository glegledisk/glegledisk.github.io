# -*- coding: utf-8 -*-
"""_ax3_freeze.py — AX3 用の別コーパスを凍結する（走行前に 1 回だけ実行）。

設計書: AX3課題設計書_別コーパスで文単位決定と非線形prefill特徴による反証_20261111.md

en: data_searchtome/*_corpus.jsonl の 6 ドメインから各 4 窓（計 24 窓）。AX2 の
    wikitext2_test.txt とはファイルも内容も重複しない別テキスト。
ja: _freeze_corpus.load_corpus("ja", 400000) と同じ root *.md glob だが
    開始位置 20000 を固定（AX2 は 283728）。glob は増減するので位置の対応は
    保証せず、独立性は本番スクリプトの C2（ID 列の共通 8-gram）で判定する。

出力: corpus_ids_ax3_w24_l256.npz (en_ids / ja_ids / meta)
既存の corpus_ids_seed11_w24_l256.npz は一切書き換えない。
"""
import glob
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from _freeze_corpus import load_corpus as load_corpus_ax2  # noqa: E402

WIN, LEN = 24, 256
JA_START = 20000
DOMAINS = ("education", "finance", "law", "medicine", "natural_sciences", "social_sciences")
OUT = os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz")


def load_en():
    """6 ドメインから各 1,024 トークン分のテキストを先頭から取る。"""
    chunks = []
    used = {}
    for dom in DOMAINS:
        f = os.path.join(HERE, "data_searchtome", "%s_corpus.jsonl" % dom)
        texts = []
        with open(f, encoding="utf-8", errors="replace") as fp:
            for line in fp:
                line = line.strip()
                if not line:
                    continue
                d = json.loads(line)
                c = d.get("content")
                if isinstance(c, str) and c:
                    texts.append(c)
        txt = "\n\n".join(texts)
        if not txt:
            raise RuntimeError("empty domain: %s" % dom)
        chunks.append(txt)
        used[dom] = {"file": os.path.basename(f), "n_records": len(texts), "chars": len(txt)}
    return chunks, used


def main():
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(os.path.join(HERE, "models", "olmoe-1b-7b"))
    need = WIN * LEN

    chunks, used = load_en()
    en_parts = []
    for dom, txt in zip(DOMAINS, chunks):
        ids = tok(txt, return_tensors="pt", add_special_tokens=False).input_ids[0]
        take = 4 * LEN                     # ドメインあたり 4 窓
        if ids.numel() < take:
            raise RuntimeError("domain too short: %s (%d < %d)" % (dom, ids.numel(), take))
        en_parts.append(ids[:take].numpy().astype(np.int32))
        used[dom]["tokens"] = int(ids.numel())
        used[dom]["take"] = int(take)
        print("en %-20s tokens %7d  take %d" % (dom, ids.numel(), take))
    en_ids = np.concatenate(en_parts)
    assert en_ids.size == need, (en_ids.size, need)

    ja_txt = load_corpus_ax2("ja", 400000)
    ja_all = tok(ja_txt, return_tensors="pt", add_special_tokens=False).input_ids[0]
    if ja_all.numel() < JA_START + need:
        raise RuntimeError("ja corpus too short: %d" % ja_all.numel())
    ja_ids = ja_all[JA_START:JA_START + need].numpy().astype(np.int32)
    print("ja corpus tokens %d  start %d  take %d" % (ja_all.numel(), JA_START, need))

    meta = {
        "name": "AX3 independent corpus",
        "created": "2026-11-11",
        "windows": WIN, "len": LEN, "n_per_lang": need,
        "en": {"source": "data_searchtome/*_corpus.jsonl", "domains": used,
               "note": "AX2 の wikitext2_test.txt とは別ファイル・別テキスト"},
        "ja": {"source": "root *.md glob (_freeze_corpus.load_corpus)",
               "start": JA_START, "corpus_tokens": int(ja_all.numel()),
               "note": "AX2 と同一 glob の別スライス。位置の対応は保証しない"},
    }
    np.savez_compressed(OUT, en_ids=en_ids, ja_ids=ja_ids,
                        meta=np.array([json.dumps(meta, ensure_ascii=False)]))
    print("saved %s  en %d / ja %d" % (os.path.basename(OUT), en_ids.size, ja_ids.size))


if __name__ == "__main__":
    main()
