import math

# Table 4: z(y) = eps - k*exp(-gamma*y),  z = averaged top-1 error
down = {
    "MI ": (0.7721, 1137.3004, 9.2265),
    "EOT": (0.7776, 827.6076, 8.8125),
}
def err(k, y):
    eps, kk, g = down[k]
    return eps - kk * math.exp(-g * y)

y_mi, y_eot = 0.9016, 0.8983
print("=== downstream top-1 error at own BPB asymptote ===")
print(f"MI  @ {y_mi}: err={err('MI ', y_mi):.4f}  acc={100*(1-err('MI ', y_mi)):.2f}%")
print(f"EOT @ {y_eot}: err={err('EOT', y_eot):.4f}  acc={100*(1-err('EOT', y_eot)):.2f}%")
gap = 100 * (err("MI ", y_mi) - err("EOT", y_eot))
print(f"total accuracy gap = {gap:.2f} pt")

print("\n=== decomposition: BPB effect vs transfer-function effect ===")
# counterfactual: MI at EOT's BPB
err_mi_at_eot_bpb = err("MI ", y_eot)
acc_cf = 100 * (1 - err_mi_at_eot_bpb)
acc_mi = 100 * (1 - err("MI ", y_mi))
acc_eot = 100 * (1 - err("EOT", y_eot))
print(f"MI acc at own BPB      = {acc_mi:.2f}%")
print(f"MI acc at EOT's BPB    = {acc_cf:.2f}%   (counterfactual)")
print(f"EOT acc at own BPB     = {acc_eot:.2f}%")
print(f"  -> BPB improvement contributes      {acc_cf-acc_mi:+.2f} pt")
print(f"  -> transfer function contributes    {acc_eot-acc_cf:+.2f} pt")

print("\n=== how sensitive is the 1.9pt claim to a +-0.003 BPB error? ===")
for dy in [-0.003, 0, 0.003]:
    a = 100 * (1 - err("EOT", y_eot + dy))
    print(f"  EOT BPB {y_eot+dy:.4f} -> acc {a:.2f}%  (gap {a-acc_mi:+.2f} pt)")

print("\n=== FLOPs of the largest reported runs (1T units) ===")
for name, fu in [("Bytes", 8.811e9), ("EOT", 9.440e9)]:
    print(f"  {name}: 1e12 units x {fu:.3e} = {1e12*fu:.2e} FLOPs")
print("  crossing of the two BPB curves = 2.41e22 FLOPs")
