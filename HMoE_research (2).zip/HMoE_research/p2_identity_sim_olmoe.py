"""P2: OLMoE の最終層に identity Expert を 1 本足し、CE + λ·cost で数ステップ学習する。

全体を回すと RAM/VRAM が足りないので、**最終 2 層だけを取り出した局所モデル**で行う:
  1. フルモデルで各ウィンドウを forward し、layer 14 の入力と rotary embedding をキャッシュ
  2. layer 14/15 + final norm + lm_head の重みを safetensors から抜き出して GPU に構築
  3. layer 15 の MoE に 65 本目の identity Expert（出力 0）を足し、その router 行だけ学習
  4. loss = CE + λ·cost（cost = 1 − p_identity）

これは「layer 15 の routing が与える影響」を厳密に測る局所実験（layer 14 以前は凍結）。

実行:
  python p2_identity_sim_olmoe.py --probe
  python p2_identity_sim_olmoe.py --lams 0 0.5 2 --steps 30
"""

import argparse
import glob
import json
import os
import random
import re

import torch
import torch.nn as nn
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "olmoe-1b-7b")


def log(msg):
    print(msg, flush=True)


class MoEWithIdentity(nn.Module):
    """OlmoeSparseMoeBlock を包み、65 本目の identity Expert（出力 0）を足す。"""

    def __init__(self, block, id_row, num_experts, top_k, norm_topk, id_bias=0.0, temp=0.5):
        super().__init__()
        self.block = block
        self.id_row = id_row
        self.num_experts = num_experts
        self.top_k = top_k
        self.norm_topk = norm_topk
        self.id_bias = id_bias          # probe 用の定数バイアス（学習しない）
        self.temp = temp                # skip 判定の温度
        self.stats = {}

    def forward(self, hidden_states):
        b, s_, d = hidden_states.shape
        h = hidden_states.reshape(-1, d)
        hf = h.to(torch.float32)
        base = F.linear(hf, self.block.gate.weight.to(torch.float32))   # (N, 64) 実 Expert のみ
        probs = F.softmax(base, dim=-1)
        topv, topi = torch.topk(probs, self.top_k, dim=-1)              # (N, k)
        if self.norm_topk:
            topv = topv / topv.sum(dim=-1, keepdim=True)
        ex = self.block.experts
        ys = []
        for i in range(self.top_k):
            idx = topi[:, i]
            x = h
            gu = torch.einsum("nd,nkd->nk", x, ex.gate_up_proj[idx])
            gate, up = gu.chunk(2, dim=-1)
            y = torch.einsum("nd,nkd->nk", ex.act_fn(gate) * up, ex.down_proj[idx])
            ys.append(y)
        Y = torch.stack(ys, dim=1)                                     # (N, k, d)
        w = topv.unsqueeze(-1)
        # norm_topk_prob=False なので再正規化しない（原実装と同じ）
        out_k = (w * Y).sum(1)
        w2 = topv[:, :self.top_k - 1].unsqueeze(-1)
        out_k1 = (w2 * Y[:, :self.top_k - 1]).sum(1)
        # identity は「最下位スロットを置き換える」。重みは実 Expert 側で再正規化（希釈しない）
        tau = base.gather(1, topi[:, -1:]).squeeze(-1)                  # k 番目の実 logit
        s = torch.sigmoid((self.id_logit(hf) - tau) / self.temp)        # skip する確率（微分可能）
        out = (1 - s).unsqueeze(-1) * out_k + s.unsqueeze(-1) * out_k1
        self.stats = {
            "p_id": s.mean(),                                          # 微分可能（loss 用）
            "sel_id": (s > 0.5).detach(),
            "logits": base.detach(),
        }
        return out.to(hidden_states.dtype).view(b, s_, d)

    def id_logit(self, hf):
        return F.linear(hf, self.id_row.unsqueeze(0)).squeeze(-1) + self.id_bias


def build_local_model(windows, gpu="cuda"):
    from transformers import AutoConfig, AutoModelForCausalLM
    from transformers.models.olmoe.modeling_olmoe import OlmoeDecoderLayer, OlmoeRMSNorm
    from safetensors.torch import safe_open

    cfg = AutoConfig.from_pretrained(MODEL)
    n_layers = int(cfg.num_hidden_layers)
    last, prev = n_layers - 1, n_layers - 2

    model = AutoModelForCausalLM.from_pretrained(
        MODEL, dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "6.5GiB", "cpu": "8.0GiB"},
        offload_folder=os.path.join(HERE, "_p2_offload"),
    ).eval()

    caps, pos_cap = [], {}
    rot = model.model.rotary_emb.register_forward_hook(
        lambda m, a, o: pos_cap.__setitem__("pos", (o[0].detach().cpu(), o[1].detach().cpu())))
    for wi, ids in enumerate(windows):
        cap = {}
        hk = model.model.layers[prev].register_forward_pre_hook(
            lambda m, a, cap=cap: cap.__setitem__("h", a[0].detach().cpu()))
        with torch.no_grad():
            model(input_ids=ids.unsqueeze(0))
        hk.remove()
        caps.append(cap["h"])
        log("      captured h_%d for window %d %s" % (prev, wi, tuple(cap["h"].shape)))
    rot.remove()
    del model
    import gc
    gc.collect()
    torch.cuda.empty_cache()
    log("      full model released")

    idx = json.load(open(os.path.join(MODEL, "model.safetensors.index.json"), encoding="utf-8"))
    want = {}
    for k, f in idx["weight_map"].items():
        if k.startswith("model.layers.%d." % prev) or k.startswith("model.layers.%d." % last) \
                or k.startswith("model.norm.") or k.startswith("lm_head."):
            want.setdefault(f, []).append(k)
    sd = {}
    for f, keys in want.items():
        with safe_open(os.path.join(MODEL, f), framework="pt") as fh:
            for k in keys:
                sd[k] = fh.get_tensor(k)
    log("      extracted %d tensors" % len(sd))

    l_prev = OlmoeDecoderLayer(cfg, prev)
    l_last = OlmoeDecoderLayer(cfg, last)
    norm = OlmoeRMSNorm(cfg.hidden_size, eps=cfg.rms_norm_eps)
    head = nn.Linear(cfg.hidden_size, cfg.vocab_size, bias=False)

    def sub(prefix):
        d = {k[len(prefix):]: v for k, v in sd.items() if k.startswith(prefix)}
        ne = int(cfg.num_experts)
        if any(k.startswith("mlp.experts.0.") for k in d):
            gu = torch.stack([torch.cat([d["mlp.experts.%d.gate_proj.weight" % e],
                                         d["mlp.experts.%d.up_proj.weight" % e]], dim=0) for e in range(ne)])
            dn = torch.stack([d["mlp.experts.%d.down_proj.weight" % e] for e in range(ne)])
            for e in range(ne):
                for kk in ("gate_proj", "up_proj", "down_proj"):
                    d.pop("mlp.experts.%d.%s.weight" % (e, kk), None)
            d["mlp.experts.gate_up_proj"] = gu
            d["mlp.experts.down_proj"] = dn
        return d

    l_prev.load_state_dict(sub("model.layers.%d." % prev))
    l_last.load_state_dict(sub("model.layers.%d." % last))
    norm.load_state_dict({"weight": sd["model.norm.weight"]})
    head.weight.data = sd["lm_head.weight"].clone()

    l_prev = l_prev.to(gpu, dtype=torch.bfloat16).eval()
    l_last = l_last.to(gpu, dtype=torch.bfloat16)
    norm = norm.to(gpu, dtype=torch.float32).eval()
    head = head.to(gpu, dtype=torch.bfloat16).eval()
    for p in l_prev.parameters():
        p.requires_grad_(False)
    for p in norm.parameters():
        p.requires_grad_(False)
    for p in head.parameters():
        p.requires_grad_(False)

    id_row = nn.Parameter(torch.zeros(cfg.hidden_size, dtype=torch.float32, device=gpu))
    l_last.mlp = MoEWithIdentity(l_last.mlp, id_row, int(cfg.num_experts),
                                 int(cfg.num_experts_per_tok),
                                 bool(getattr(cfg, "norm_topk_prob", True))).to(gpu)
    for p in l_last.parameters():
        p.requires_grad_(False)
    id_row.requires_grad_(True)
    return dict(cfg=cfg, prev=l_prev, last=l_last, norm=norm, head=head,
                id_row=id_row, caps=caps, pos=pos_cap["pos"], prev_idx=prev, last_idx=last)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--steps", type=int, default=30)
    ap.add_argument("--lams", nargs="*", type=float, default=[0.0, 0.5, 2.0])
    ap.add_argument("--lr", type=float, default=0.02)
    ap.add_argument("--len", type=int, default=128)
    ap.add_argument("--windows", type=int, default=4)
    ap.add_argument("--probe", action="store_true")
    ap.add_argument("--tag", default="p2")
    args = ap.parse_args()

    torch.manual_seed(0)
    random.seed(0)

    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(MODEL)

    files = sorted(glob.glob(os.path.join(HERE, "english_version", "**", "*.md"), recursive=True))[:2]
    corpus = "\n\n".join(re.sub(r"```.*?```", " ", open(f, encoding="utf-8").read(), flags=re.S) for f in files)
    all_ids = tok(corpus, return_tensors="pt", add_special_tokens=False).input_ids[0]
    wins = []
    for _ in range(args.windows):
        st = random.randrange(0, all_ids.numel() - args.len)
        wins.append(all_ids[st:st + args.len])
    log("[1/4] %d windows x %d tokens" % (len(wins), args.len))

    log("[2/4] building local model (last 2 layers)")
    M = build_local_model(wins)

    def forward_loss(i, lam):
        ids = wins[i]
        x = M["caps"][i].to("cuda")
        p = (M["pos"][0].to("cuda"), M["pos"][1].to("cuda"))
        with torch.no_grad():
            x = M["prev"](x, position_embeddings=p, use_cache=False)
        x = M["last"](x, position_embeddings=p, use_cache=False)
        x = M["norm"](x.float())
        logits = M["head"](x.to(torch.bfloat16))
        ce = F.cross_entropy(logits[0, :-1].float(), ids[1:].to("cuda"))
        p_skip = M["last"].mlp.stats["p_id"]
        sel = M["last"].mlp.stats["sel_id"].float().mean()
        # 実際の計算削減は「k スロットのうち 1 個」なので最大 1/k
        cost = 1.0 - p_skip / M["last"].mlp.top_k
        return ce + lam * cost, ce.detach(), cost.detach(), sel

    if args.probe:
        log("[3/4] probe: identity の logit を固定したときの CE（-1e4 は identity を排除した基準）")
        with torch.no_grad():
            for val in [-1e4, 0.0, 1.0, 2.0, 5.0, 20.0]:
                M["id_row"].zero_()
                M["last"].mlp.id_bias = val
                ces, sels = [], []
                for i in range(len(wins)):
                    _, ce, _, sel = forward_loss(i, 0.0)
                    ces.append(ce.item()); sels.append(sel.item())
                log("  id_bias=%-8.1f  CE %.4f  sel %.3f" % (val, sum(ces) / len(ces), sum(sels) / len(sels)))
        return

    results = {}
    for lam in args.lams:
        M["id_row"].data.zero_()
        M["last"].mlp.id_bias = 0.0
        opt = torch.optim.SGD([M["id_row"]], lr=args.lr)
        hist = []
        for step in range(args.steps):
            opt.zero_grad(set_to_none=True)
            ces, costs, sels = [], [], []
            for i in range(len(wins)):
                L, ce, cost, sel = forward_loss(i, lam)
                (L / len(wins)).backward()
                ces.append(ce.item()); costs.append(cost.item()); sels.append(sel.item())
            gn = float(M["id_row"].grad.norm().item())
            opt.step()
            M["last"].mlp.stats = {}   # グラフ参照を解放
            hist.append({"step": step, "ce": sum(ces) / len(ces), "cost": sum(costs) / len(costs),
                         "sel": sum(sels) / len(sels), "gnorm": gn,
                         "id_row_norm": float(M["id_row"].norm().item())})
            if step % 5 == 0 or step == args.steps - 1:
                log("  lam=%.2f step %2d  CE %.4f  cost %.4f  sel %.4f  |g| %.3e  |row| %.4f"
                    % (lam, step, hist[-1]["ce"], hist[-1]["cost"], hist[-1]["sel"], gn, hist[-1]["id_row_norm"]))
        results[str(lam)] = hist

    with open(os.path.join(HERE, "%s_summary.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump({"model": MODEL, "layer": M["last_idx"], "steps": args.steps, "lr": args.lr,
                   "results": results}, fp, ensure_ascii=False, indent=2)
    log("[done] saved %s_summary.json" % args.tag)


if __name__ == "__main__":
    main()
