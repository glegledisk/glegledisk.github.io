# -*- coding: utf-8 -*-
"""QE1S6 Step 2: K=2048 sqrt + 2% uniform mix で T3 を 13 seed で再検定する.

設計書: `QE1S6課題設計書_K2048固定でsqrt写一様混合2パーセントを走行前固定する_20261116.md`
        §1〜§3、Step 1 報告 `検証報告_QE1S6S1_..._20261116.md`

本次の範囲（走行前に固定。結果を見て変更しない）
  - 13 seed × 2 条件(zipf / mixed2048) = 26 run、40 epoch、幅 224。
  - 学習・eval 3 バッチ・4 方策・収束ゲート・除外しない方針は QE1S2 run_v2 と同一。
  - 生成だけを QE1S6 の paired stream (zipf) と sqrt+2% uniform (mixed2048) へ差し替える。
  - 確認的家族は T3 の 1 本。d_s = top1_abs_share(zipf) - top1_abs_share(mixed2048)。
    ttest_rel 両側 α=0.05、Holm m=1、MDE = t.ppf(.975,12)*se、90% CI。
  - 3 点対照は診断用に保存するが確認的家族へ追加しない（設計書 §3）。

出力: qe1s6_metrics.json / qe1s6_delta.npz / qe1s6.log / qe1s6_out_utf8.txt / qe1s6_err_utf8.txt
      （すべて UTF-8、json は allow_nan=False）
"""
from __future__ import annotations

import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy import stats

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "不均一MoE-Corpus"))

import corpus_common as CC                       # noqa: E402
from corpus_common import (BATCHES_PER_EPOCH, BATCH, CHUNK, CONV_RANGE_MAX,  # noqa: E402
                           CONV_SLOPE_MAX, COPY_WINDOW, EPOCHS, EVAL_SEED_BASE,
                           LR, N_EVAL_SEQ, N_TRAIN_SEQ, POLICIES, SEEDS,
                           SEQ_LEN, SYNTAX_RATE, TAIL_K, TOP1_CONTRIB_LIMIT,
                           TRAIN_SEED_BASE, V_IDENT, V_SYNTAX, VOCAB,
                           WIDTH_LADDER, zipf_cdf)
from qe1_make_task import (INIT_SEED_BASE, N_TYPES, POS_BINS, SYNTAX_PER_TYPE,  # noqa: E402
                           QE1Corpus, QE1S4_IDENT_STREAM_OFFSET,
                           QE1S4_SYNR_STREAM_OFFSET)
from qe1s2_run import paired_stats                # noqa: E402  (allow_nan=False 規約を共有)

TAG = "qe1s6"
ALPHA = 0.05
MDE_T = float(stats.t.ppf(0.975, len(SEEDS) - 1))
CI90_T = float(stats.t.ppf(0.95, len(SEEDS) - 1))
CE_ALL_LIMIT = math.log(VOCAB)
IV_GATE_MIN = 0.10
GATE_SEED_BASE = 3000
ROBUST_SEED_BASE = EVAL_SEED_BASE + 1
N_EVAL_BATCH = BATCH
EVAL_CHUNK = CHUNK
TOP1_Q = 0.01
FREQS = ("zipf", "mixed2048")
K_SQRT = 2048
ALPHA_MAP = 0.5
EPS_MIX = 0.02
WIDTHS = tuple(WIDTH_LADDER)
ARRAY_KEYS = ("tokens", "types", "next_tok", "copy_mask", "is_syntax",
              "ident_rank", "type_draw", "a", "changed", "base")


def build_corpus(seed: int, n_seq: int, base: int, freq: str) -> QE1Corpus:
    """QE1S6 の生成経路。zipf は QE1S4 paired、mixed2048 は sqrt + 2% uniform。"""
    assert freq in FREQS, freq
    shape = (int(n_seq), SEQ_LEN)
    rng = np.random.default_rng(int(seed) + int(base))
    type_draw = rng.integers(0, N_TYPES, size=shape, dtype=np.int64)
    is_syntax = rng.random(shape) < SYNTAX_RATE

    ident_rng = np.random.default_rng(
        int(seed) + int(base) + QE1S4_IDENT_STREAM_OFFSET)
    u = ident_rng.random(shape)
    rank = np.clip(np.searchsorted(zipf_cdf(), u, side="right"), 0, V_IDENT - 1)
    if freq == "zipf":
        ident = rank
        idmod = V_IDENT
    else:
        base_ident = np.clip(
            np.floor(np.power(rank.astype(np.float64), ALPHA_MAP)
                     * (K_SQRT / np.power(V_IDENT, ALPHA_MAP))).astype(np.int64),
            0, K_SQRT - 1)
        flat = np.floor(u * K_SQRT).astype(np.int64)
        pick = ident_rng.random(shape) < EPS_MIX
        ident = np.where(pick, flat, base_ident)
        idmod = K_SQRT
    syn_r = np.random.default_rng(
        int(seed) + int(base) + QE1S4_SYNR_STREAM_OFFSET).integers(
            0, SYNTAX_PER_TYPE, size=shape, dtype=np.int64)
    syntax_id = N_TYPES + type_draw * SYNTAX_PER_TYPE + syn_r
    tokens = np.where(is_syntax, syntax_id, V_SYNTAX + ident).astype(np.int64)

    pos = np.broadcast_to(np.arange(SEQ_LEN, dtype=np.int64), shape)
    last = np.maximum.accumulate(np.where(is_syntax, pos, -1), axis=1)
    rows = np.arange(shape[0])[:, None]
    fill = np.random.default_rng(int(seed) + INIT_SEED_BASE).integers(
        0, N_TYPES, size=(shape[0], 1), dtype=np.int64)
    a = np.where(last >= 0, type_draw[rows, np.clip(last, 0, None)], fill)

    bt = np.empty(shape, dtype=np.int64)
    bt[:, :-1] = tokens[:, 1:]
    bt[:, -1] = tokens[:, 0]
    ib = bt >= V_SYNTAX
    inc = np.where(ib, V_SYNTAX + ((bt - V_SYNTAX + 1) % idmod), bt)
    lag = np.empty(shape, dtype=np.int64)
    lag[:, 2:] = tokens[:, :-2]
    lag[:, :2] = bt[:, :2]
    prev = np.empty(shape, dtype=np.int64)
    prev[:, 1:] = tokens[:, :-1]
    prev[:, 0] = bt[:, 0]
    nxt = np.select([a == 0, a == 1, a == 2, a == 3],
                    [bt, inc, lag, prev], default=bt).astype(np.int64)
    changed = nxt != bt
    cm = np.zeros(shape, dtype=bool)
    for l in range(1, COPY_WINDOW + 1):
        pt = np.zeros(shape, dtype=np.int64)
        pt[:, l:] = tokens[:, :-l]
        cm |= pt == nxt
    cm &= ~(nxt < V_SYNTAX)
    cm[:, -1] = False
    pf = np.broadcast_to(np.arange(SEQ_LEN, dtype=np.float64), shape).ravel()
    tf = type_draw.ravel().astype(np.float64)
    r = float(np.corrcoef(pf, tf)[0, 1])
    if not np.isfinite(r):
        r = 0.0
    return QE1Corpus(
        tokens=tokens, types=a.copy(), next_tok=nxt, copy_mask=cm,
        is_syntax=is_syntax, ident_rank=ident.astype(np.int16),
        pos_corr=abs(r), type_draw=type_draw.astype(np.int8),
        a=a.astype(np.int8), changed=changed, base=bt.astype(np.int16))


def run(seed: int, freq: str, device: str) -> dict:
    """QE1S2 run_v2 と同一の学習・3 eval バッチ×4 方策。生成だけ差し替える。"""
    torch.set_num_threads(1)
    torch.manual_seed(TRAIN_SEED_BASE + int(seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(TRAIN_SEED_BASE + int(seed))
    rng = np.random.default_rng(TRAIN_SEED_BASE + int(seed))
    train = build_corpus(seed, N_TRAIN_SEQ, TRAIN_SEED_BASE, freq)

    model = CC.TinyMoE(WIDTHS).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=LR)
    hist = {"ce_copy": [], "instr_valid": [], "ce_all": []}
    model.train()
    for _ in range(EPOCHS):
        ep = {k: [] for k in hist}
        for _ in range(BATCHES_PER_EPOCH):
            x, y, cm, ty, _ = CC.sample_batch(train, rng, BATCH, CHUNK)
            x, y, cm, ty = (v.to(device, non_blocking=True) for v in (x, y, cm, ty))
            logits, _, _ = model(x, policy="soft", types=ty, rng=rng)
            loss_all = F.cross_entropy(
                logits.reshape(-1, VOCAB), y.reshape(-1), reduction="none").view(y.shape)
            m = cm.reshape(-1)
            ce_copy = loss_all.reshape(-1)[m].mean() if bool(m.any()) else loss_all.mean()
            instr = ((logits.argmax(-1) == y) & cm).float().sum() / cm.float().sum().clamp(min=1.0)
            loss = loss_all.mean()
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            ep["ce_copy"].append(float(ce_copy.detach().cpu()))
            ep["instr_valid"].append(float(instr.detach().cpu()))
            ep["ce_all"].append(float(loss.detach().cpu()))
        for k in hist:
            hist[k].append(float(np.mean(ep[k])))

    tail = np.asarray(hist["instr_valid"][-min(TAIL_K, len(hist["instr_valid"])):],
                      dtype=np.float64)
    slope = float(np.polyfit(np.arange(tail.size), tail, 1)[0]) if tail.size >= 2 else 0.0
    rng_val = float(tail.max() - tail.min()) if tail.size else 0.0
    T_plus = bool(abs(slope) <= CONV_SLOPE_MAX and rng_val <= CONV_RANGE_MAX)
    k = min(TAIL_K, len(hist["ce_copy"]))
    summary = {
        "ce_copy": float(np.median(hist["ce_copy"][-k:])),
        "instr_valid": float(np.median(hist["instr_valid"][-k:])),
        "ce_all": float(np.median(hist["ce_all"][-k:])),
        "converged": T_plus, "conv_slope": slope, "conv_range": rng_val,
    }

    evals = {}
    model.eval()
    with torch.no_grad():
        for role, base in (("gate", GATE_SEED_BASE), ("main", EVAL_SEED_BASE),
                           ("robust", ROBUST_SEED_BASE)):
            c = build_corpus(seed, N_EVAL_SEQ, base, freq)
            erng = np.random.default_rng(TRAIN_SEED_BASE + int(seed))
            x, y, cm, ty, rk = CC.sample_batch(
                c, erng, min(N_EVAL_BATCH, c.tokens.shape[0]), EVAL_CHUNK)
            x, y, cm, ty = (v.to(device, non_blocking=True) for v in (x, y, cm, ty))
            head_hi, tail_lo = CC._freq_bins(c)
            rank_np = rk.detach().cpu().numpy()
            head_m = torch.from_numpy(rank_np < head_hi).to(device) & cm
            tail_m = torch.from_numpy(rank_np >= tail_lo).to(device) & cm
            ty_np = ty.detach().cpu().numpy()
            per_pol = {}
            for pol in POLICIES + ("learned",):
                logits_p, idx, _ = model(
                    x, policy=pol, types=ty,
                    rng=np.random.default_rng(TRAIN_SEED_BASE + int(seed) + 977))
                loss_all = F.cross_entropy(
                    logits_p.reshape(-1, VOCAB), y.reshape(-1), reduction="none").view(y.shape)
                correct = (logits_p.argmax(-1) == y)
                idx_np = idx.detach().cpu().numpy()
                w_chosen = np.asarray(model.widths, dtype=np.float64)[idx_np]
                ce_tok = loss_all.detach().cpu().numpy()
                cm_np = cm.detach().cpu().numpy()
                with np.errstate(invalid="ignore"):
                    ce_seq = np.where(cm_np.sum(1) > 0,
                                      (ce_tok * cm_np).sum(1) / np.maximum(cm_np.sum(1), 1),
                                      np.nan)
                ce_seq = ce_seq[np.isfinite(ce_seq)]
                s_abs = np.sort(np.abs(ce_seq))[::-1]
                ktop = max(1, int(math.ceil(TOP1_Q * s_abs.size)))
                top1 = float(s_abs[:ktop].sum() / s_abs.sum()) if s_abs.sum() > 0 else 0.0
                empty_masks = 0

                def _mean(mask):
                    nonlocal empty_masks
                    if bool(mask.any()):
                        return float(loss_all[mask].mean().cpu())
                    empty_masks += 1
                    return float(loss_all.mean().cpu())

                def _acc(mask):
                    nonlocal empty_masks
                    if bool(mask.any()):
                        return float(correct[mask].float().mean().cpu())
                    empty_masks += 1
                    return float(correct.float().mean().cpu())

                per_pol[pol] = {
                    "ce_copy": _mean(cm), "ce_all": float(loss_all.mean().cpu()),
                    "instr_valid": _acc(cm),
                    "ce_copy_by_type": [_mean(cm & (ty == j)) for j in range(N_TYPES)],
                    "ce_copy_head": _mean(head_m), "ce_copy_tail": _mean(tail_m),
                    "ce_seq": ce_seq,
                    "top1_abs_share": top1, "n_eval_series": int(ce_seq.size),
                    "n_empty_masks": int(empty_masks), "w_chosen": w_chosen,
                }
            evals[role] = {
                "per_policy": {p: {kk: vv for kk, vv in d.items()
                                   if kk not in ("ce_seq", "w_chosen")}
                               for p, d in per_pol.items()},
                "ce_seq_learned": per_pol["learned"]["ce_seq"],
                "top1_abs_share_learned": per_pol["learned"]["top1_abs_share"],
                "w_chosen_learned": per_pol["learned"]["w_chosen"],
                "meta": {"type": ty_np, "rank": rank_np, "copy_mask": cm_np},
            }
    del model
    if device.startswith("cuda") and torch.cuda.is_available():
        torch.cuda.empty_cache()
    return {"hist": hist, "summary": summary, "T_plus": T_plus, "evals": evals}


def main() -> None:
    out = {
        "tag": TAG, "phase": "QE1S6 Step 2 (production, 26 runs)",
        "design": "QE1S6課題設計書_K2048固定でsqrt写一様混合2パーセントを走行前固定する_20261116.md",
        "step1_gate": "PASS (検証報告_QE1S6S1_..._20261116.md, C1-C8 all pass, verifier 40/0)",
        "no_confirmatory_before_this_run": True,
    }
    out["prereg"] = {
        "SEEDS": list(SEEDS), "FREQS": list(FREQS), "EPOCHS": EPOCHS,
        "LR": LR, "BATCH": BATCH, "CHUNK": CHUNK,
        "BATCHES_PER_EPOCH": BATCHES_PER_EPOCH, "N_TRAIN_SEQ": N_TRAIN_SEQ,
        "N_EVAL_SEQ": N_EVAL_SEQ, "N_EVAL_BATCH": N_EVAL_BATCH,
        "WIDTHS": list(WIDTHS), "VOCAB": VOCAB, "V_IDENT": V_IDENT,
        "K_SQRT": K_SQRT, "ALPHA_MAP": ALPHA_MAP, "EPS_MIX": EPS_MIX,
        "TOP1_Q": TOP1_Q, "TOP1_CONTRIB_LIMIT": TOP1_CONTRIB_LIMIT,
        "MDE_T": MDE_T, "CI90_T": CI90_T, "ALPHA": ALPHA, "HOLM_M": 1,
        "GATE_SEED_BASE": GATE_SEED_BASE, "MAIN_SEED_BASE": EVAL_SEED_BASE,
        "ROBUST_SEED_BASE": ROBUST_SEED_BASE,
        "CE_ALL_LIMIT": CE_ALL_LIMIT, "IV_GATE_MIN": IV_GATE_MIN,
        "estimand": "d_s = top1_abs_share_s(zipf) - top1_abs_share_s(mixed2048), H0: mean d = 0",
        "test": "scipy.stats.ttest_rel, two-sided, alpha=0.05, Holm m=1",
        "mde_note": "MDE = t.ppf(0.975,12)*se = 2.1788*se. corpus_common.MDE_FACTOR(3.0545) は alpha=0.01 用で流用禁止",
        "exclusion_rule": "除外しない。E フラグ seed は主解析に残す。感度解析は探索的のみ",
        "three_point_note": "uniform/random/oracle は診断用に保存するが確認的家族へ追加しない（設計書 §3）",
        "Step1_note": "Step 1 の校正値 (ΔH, ΔP_copy) は参照値としてのみ使い、本次の確認的判定には混ぜない",
    }

    device = "cuda" if torch.cuda.is_available() else "cpu"
    out["device"] = device
    runs = {}
    t0 = time.time()
    for si, seed in enumerate(SEEDS):
        for freq in FREQS:
            r = run(seed, freq, device)
            key = f"s{seed}_{freq}"
            m = r["evals"]["main"]
            runs[key] = {
                "seed": seed, "freq": freq, "widths": list(WIDTHS),
                "summary": r["summary"], "T_plus": r["T_plus"],
                "main": {"top1_abs_share_learned": m["top1_abs_share_learned"],
                         "ce_seq_learned": m["ce_seq_learned"],
                         "per_policy": m["per_policy"]},
                "gate": {"per_policy": r["evals"]["gate"]["per_policy"]},
                "robust": {"per_policy": r["evals"]["robust"]["per_policy"]},
                "meta_main": {k: v for k, v in m["meta"].items() if k != "rank"},
            }
            sys.stdout.write(
                f"[{si*len(FREQS)+FREQS.index(freq)+1}/{len(SEEDS)*len(FREQS)}] {key} "
                f"ce_copy={r['summary']['ce_copy']:.4f} iv={r['summary']['instr_valid']:.4f} "
                f"top1={m['top1_abs_share_learned']:.6f} T+={r['T_plus']} "
                f"({time.time()-t0:.0f}s)\n")
            sys.stdout.flush()
    out["runtime_seconds"] = float(time.time() - t0)

    sz = np.asarray([runs[f"s{s}_zipf"]["main"]["top1_abs_share_learned"] for s in SEEDS])
    sm = np.asarray([runs[f"s{s}_mixed2048"]["main"]["top1_abs_share_learned"] for s in SEEDS])
    primary = paired_stats(sz, sm, "T3_top1_abs_share")
    primary["holm_m"] = 1
    primary["holm_p"] = float(min(1.0, primary["p"]))
    primary["reject"] = bool(primary["p"] < ALPHA and not primary["mean_unreliable"])
    primary["top1_share_zipf"] = float(np.median(sz))
    primary["top1_share_mixed2048"] = float(np.median(sm))
    primary["ce_seq_median_zipf"] = float(np.median([
        float(np.median(runs[f"s{s}_zipf"]["main"]["ce_seq_learned"])) for s in SEEDS]))
    primary["ce_seq_median_mixed2048"] = float(np.median([
        float(np.median(runs[f"s{s}_mixed2048"]["main"]["ce_seq_learned"])) for s in SEEDS]))
    out["primary"] = primary

    # eval ゲート（T± × E±、除外しない）
    cells = {(t, e): 0 for t in (True, False) for e in (True, False)}
    e_flags = {}
    c5_detail, c5_ok = {}, True
    for s in SEEDS:
        z = runs[f"s{s}_zipf"]
        iv_gate = z["gate"]["per_policy"]["learned"]["instr_valid"]
        ce_all = z["main"]["per_policy"]["learned"]["ce_all"]
        e_flag = bool((not np.isfinite(ce_all)) or ce_all > CE_ALL_LIMIT
                      or iv_gate in (0.0, 1.0))
        e_flags[s] = e_flag
        cells[(bool(z["T_plus"]), bool(iv_gate >= IV_GATE_MIN))] += 1
        pol = z["main"]["per_policy"]
        ok = bool(pol["random"]["instr_valid"] <= pol["oracle"]["instr_valid"])
        c5_ok &= ok
        c5_detail[f"s{s}"] = {"random": pol["random"]["instr_valid"],
                              "oracle": pol["oracle"]["instr_valid"], "pass": ok}
    classified = int(sum(cells.values()))
    out["eval_gate"] = {
        "grid": {f"T{'+' if t else '-'}E{'+' if e else '-'}": n
                 for (t, e), n in cells.items()},
        "classified_seeds": classified, "expected_seeds": len(SEEDS),
        "excluded_pairs": 0,
        "E_flag_seeds": [s for s in SEEDS if e_flags[s]],
        "non_converged_seeds": [s for s in SEEDS if not runs[f"s{s}_zipf"]["T_plus"]],
        "rule": "除外しない。E フラグ seed は主解析に残す",
    }
    out["C5_diagnostic"] = {"per_seed": c5_detail, "all_pass": bool(c5_ok),
                            "note": "3 点対照は診断記録。確認的家族（m=1）には入れない"}

    keep = [i for i, s in enumerate(SEEDS) if not e_flags[s]]
    out["sensitivity"] = {
        "kept_seeds": [SEEDS[i] for i in keep], "n_kept": len(keep),
        "result": paired_stats(sz[keep], sm[keep], "T3_sens") if len(keep) >= 3 else {},
        "rule": "探索的感度のみ。主判定は全 13 seed",
    }

    c4 = {"classification_complete": bool(classified == len(SEEDS)),
          "excluded_pairs": 0}
    c4["pass"] = bool(c4["classification_complete"] and c4["excluded_pairs"] == 0)

    def scan(o, path="root"):
        bad = []
        if isinstance(o, dict):
            for k, v in o.items():
                bad += scan(v, f"{path}.{k}")
        elif isinstance(o, list):
            for j, v in enumerate(o):
                bad += scan(v, f"{path}[{j}]")
        elif isinstance(o, float) and not np.isfinite(o):
            bad.append(path)
        return bad
    nf = scan(out)
    out["calibration"] = {"C4": c4, "C6": {"nonfinite_paths": nf,
                                           "pass": bool(len(nf) == 0)}}
    out["case"] = ("T3 は copy 統計を揃えた条件下での差を測る 1 testbed の結果。"
                   "QE1S2 の再解釈・Q-E の解決・一般化を主張しない（設計書 §3）")
    out["verdict"] = "PASS" if (c4["pass"] and len(nf) == 0) else "FAIL"

    slim = {k: {"seed": v["seed"], "freq": v["freq"], "summary": v["summary"],
                "T_plus": v["T_plus"], "main": {kk: vv for kk, vv in v["main"].items()
                                                if kk != "ce_seq_learned"},
                "gate": v["gate"], "robust": v["robust"]}
            for k, v in runs.items()}
    out["runs"] = slim
    (HERE / f"{TAG}_metrics.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    arrays = {
        "seeds": np.asarray(SEEDS), "top1_zipf": sz, "top1_mixed2048": sm,
        "top1_diff": sz - sm,
        "T_plus": np.asarray([runs[f"s{s}_zipf"]["T_plus"] for s in SEEDS]),
        "E_flag": np.asarray([e_flags[s] for s in SEEDS]),
    }
    np.savez(HERE / f"{TAG}_delta.npz", **arrays)
    t_str = "inf(null)" if primary["t"] is None else f"{primary['t']:.4f}"
    lines = [
        f"tag={TAG}", f"verdict={out['verdict']}", f"device={device}",
        f"runtime_seconds={out['runtime_seconds']:.1f}", f"n_runs={len(SEEDS)*len(FREQS)}",
        f"T3 delta={primary['delta']:.8f} se={primary['se']:.8f} t={t_str} "
        f"p={primary['p']:.6g} holm={primary['holm_p']:.6g} MDE={primary['mde']:.8f}",
        f"CI90={primary['ci90']} top1_share={primary['top1_share']:.6f} "
        f"mean_unreliable={primary['mean_unreliable']}",
        f"median zipf={primary['top1_share_zipf']:.6f} mixed={primary['top1_share_mixed2048']:.6f}",
        f"E_flag={out['eval_gate']['E_flag_seeds']} non_converged={out['eval_gate']['non_converged_seeds']}",
        f"checks=C4:{c4['pass']} C6:{len(nf)==0} C5diag:{c5_ok}", f"case={out['case']}", "",
    ]
    (HERE / f"{TAG}.log").write_text("\n".join(lines), encoding="utf-8")
    sys.stdout.write("\n".join(lines))
    sys.stdout.flush()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        sys.stderr.write(f"[qe1s6_run] ERROR {type(exc).__name__}: {exc}\n")
        sys.stderr.flush()
        raise
    else:
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)
