# -*- coding: utf-8 -*-
"""Compact report tables for S1 (reads s1_analysis JSON + npz)."""
import argparse
import json
import os

import numpy as np

import s1_analyze as A

HERE = os.path.dirname(os.path.abspath(__file__))


def fmt(st, digits=4):
    if st is None or st.get("n", 0) == 0:
        return "n=0"
    return ("%+.*f (se %.*f, t=%+.2f, p=%.4f, n=%d, MDE=%.3f)"
            % (digits, st["mean"], digits, st["se"], st["t"], st["p"], st["n"], st["mde"]))


def tail(d):
    d = np.asarray(d, dtype=float)
    d = d[np.isfinite(d)]
    if d.size == 0:
        return "n=0"
    k = max(1, int(round(0.01 * d.size)))
    top = np.sort(d)[-k:]
    share = float(top.sum() / d.sum()) if d.sum() != 0 else float("nan")
    return ("n=%d mean=%+.4f median=%+.4f max=%+.4f top1%%_share=%.2f"
            % (d.size, d.mean(), np.median(d), d.max(), share))


def qmap(recs, prompt, ab, ctype=None, value="margin"):
    return A.qmap(recs, prompt, ab, ctype, value)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--npz", default=os.path.join(HERE, "s1_core.npz"))
    ap.add_argument("--analysis", default=os.path.join(HERE, "s1_analysis.json"))
    ap.add_argument("--out", default=os.path.join(HERE, "s1_report_numbers.txt"))
    args = ap.parse_args()

    z, meta, rows, gold_tok, gold_row = A.load(args.npz)
    recs, san = A.attach_margins(z, rows, gold_tok, gold_row)
    base = [r for r in recs if r["ablation"] == "base"]
    domains = sorted(set(r["domain"] for r in rows))
    types = ("sibling", "cousin", "far")
    out = []
    w = out.append

    w("== meta ==")
    w("model=%s domains=%s entries=%d conds=%d smoke=%s" %
      (meta["model"], ",".join(meta["domains"]), meta["n_entries"], len(meta["conds"]), meta["smoke"]))
    w("calib_tokens/domain=%d mean_fwd_s=%.3f n_fwd=%d elapsed_s=%.0f" %
      (meta["calib_tokens_per_domain"], meta["mean_fwd_s"], meta["n_fwd"], meta["elapsed_s"]))
    w("proxy: rare=%s" % json.dumps(meta["proxy_check"].get("rare", {})))
    w("proxy: freq=%s" % json.dumps(meta["proxy_check"].get("freq", {})))
    w("sanity: %s" % json.dumps(san))
    w("n_queries=%d rows=%d distractor_rows=%d" %
      (len(set((r["domain"], r["query_id"]) for r in rows)), len(rows), len(recs)))
    w("")

    w("== 1. margin by prompt x type (base) ==")
    for p in ("toc", "toc_drop", "none", "shuffle", "toc_mis"):
        for t in types:
            m = qmap(base, p, "base", t)
            if m:
                w("%-9s %-7s %s" % (p, t, fmt(A.map_stats(m))))
    w("")

    w("== 2. paired prompt contrasts by type ==")
    for p1, p0 in (("toc", "none"), ("toc", "shuffle"), ("shuffle", "none"),
                   ("toc", "toc_drop"), ("toc_drop", "none"), ("toc_mis", "toc")):
        for t in types:
            a = qmap(base, p1, "base", t)
            b = qmap(base, p0, "base", t)
            d = A.diff_maps(a, b)
            if d:
                w("%-16s %-7s %s" % ("%s-%s" % (p1, p0), t, fmt(A.map_stats(d))))
                w("    tail: %s" % tail(list(d.values())))
    w("")

    w("== 3. DiD (prompt contrast, sibling - far) ==")
    for p1, p0 in (("toc", "none"), ("toc", "shuffle"), ("shuffle", "none"),
                   ("toc", "toc_drop"), ("toc_drop", "none")):
        s1, s0 = qmap(base, p1, "base", "sibling"), qmap(base, p0, "base", "sibling")
        f1, f0 = qmap(base, p1, "base", "far"), qmap(base, p0, "base", "far")
        w("%-16s %s" % ("%s-%s" % (p1, p0), fmt(A.did(s1, s0, f1, f0))))
        c1, c0 = qmap(base, p1, "base", "cousin"), qmap(base, p0, "base", "cousin")
        if c1 and c0:
            w("%-16s %s" % ("%s-%s|cousin-far" % (p1, p0), fmt(A.did(c1, c0, f1, f0))))
    w("")

    w("== 4. ablation hurt = margin(base) - margin(ab) ==")
    for p in ("toc", "none"):
        bm = {t: qmap(base, p, "base", t) for t in types}
        for a in ("g_rare", "g_freq", "g_rand", "l_rare", "l_freq", "l_rand"):
            am = {t: qmap(recs, p, a, t) for t in types}
            for t in types:
                if not am[t] or not bm[t]:
                    continue
                d = {k: bm[t][k] - am[t][k] for k in set(bm[t]) & set(am[t])}
                w("%-4s %-7s %-7s %s" % (p, a, t, fmt(A.map_stats(d))))
        w("")

    w("== 5. ablation arm contrasts (rare - control) ==")
    for p in ("toc", "none"):
        for a1, a0 in (("g_rare", "g_freq"), ("g_rare", "g_rand"),
                       ("l_rare", "l_freq"), ("l_rare", "l_rand")):
            for t in types:
                m1 = qmap(recs, p, a1, t)
                m0 = qmap(recs, p, a0, t)
                d = A.diff_maps(m0, m1)
                if d:
                    w("%-4s %-18s %-7s %s" % (p, "%s-%s" % (a1, a0), t, fmt(A.map_stats(d))))
        w("")

    w("== 6. DiD ablation (sibling - far hurt) ==")
    for p in ("toc", "none"):
        for a in ("g_rare", "g_freq", "g_rand", "l_rare", "l_freq", "l_rand"):
            sb, s = qmap(base, p, "base", "sibling"), qmap(recs, p, a, "sibling")
            fb, f = qmap(base, p, "base", "far"), qmap(recs, p, a, "far")
            keys = set(sb) & set(s) & set(fb) & set(f)
            if keys:
                d = [(sb[k] - s[k]) - (fb[k] - f[k]) for k in keys]
                w("%-4s %-7s sibling-far %s" % (p, a, fmt(A.paired(d))))
    w("")

    w("== 7. ToC x ablation interaction (hurt toc - hurt none) ==")
    for a in ("g_rare", "g_freq", "g_rand", "l_rare", "l_freq"):
        for t in types:
            b1, a1 = qmap(base, "toc", "base", t), qmap(recs, "toc", a, t)
            b0, a0 = qmap(base, "none", "base", t), qmap(recs, "none", a, t)
            keys = set(b1) & set(a1) & set(b0) & set(a0)
            if keys:
                d = [(b1[k] - a1[k]) - (b0[k] - a0[k]) for k in keys]
                w("%-7s %-7s %s" % (a, t, fmt(A.paired(d))))
    w("")

    w("== 8. routing on gold tokens (base) ==")
    for p in ("toc", "none"):
        for f, lab in (("rare_num", "rare_num"), ("rare_title", "rare_title"),
                       ("ent_num", "ent_num"), ("ent_title", "ent_title")):
            m = {}
            for r in rows:
                if r["is_gold"] and r["prompt"] == p and r["ablation"] == "base":
                    m[(r["domain"], r["query_id"])] = r[f]
            w("%-4s %-10s %s" % (p, lab, fmt(A.map_stats(m))))
        for f1, f0, lab in (("rare_num", "rare_title", "rare_num-title"),
                            ("ent_num", "ent_title", "ent_num-title"),
                            ("rare_first", "rare_last", "rare_first-last")):
            a, b = {}, {}
            for r in rows:
                if r["is_gold"] and r["prompt"] == p and r["ablation"] == "base":
                    k = (r["domain"], r["query_id"])
                    a[k] = r[f1]
                    b[k] = r[f0]
            w("%-4s %-16s %s" % (p, lab, fmt(A.map_stats(A.diff_maps(a, b)))))
    for f in ("rare_num", "rare_title", "ent_num", "ent_title"):
        a, b = {}, {}
        for r in rows:
            if r["is_gold"] and r["ablation"] == "base":
                k = (r["domain"], r["query_id"])
                if r["prompt"] == "toc":
                    a[k] = r[f]
                elif r["prompt"] == "none":
                    b[k] = r[f]
        w("toc-none %-16s %s" % (f, fmt(A.map_stats(A.diff_maps(a, b)))))
    w("")

    w("== 9. rare share at the divergence token (base) ==")
    for p in ("toc", "none"):
        for t in types:
            m = qmap(base, p, "base", t, value="rare_div")
            if m:
                w("%-4s %-7s %s" % (p, t, fmt(A.map_stats(m))))
        s = qmap(base, p, "base", "sibling", value="rare_div")
        f = qmap(base, p, "base", "far", value="rare_div")
        if s and f:
            w("%-4s sibling-far %s" % (p, fmt(A.map_stats(A.diff_maps(s, f)))))
    w("")

    w("== 10. gold title likelihood (teacher forced) ==")
    for p in ("toc", "toc_drop", "none", "shuffle", "toc_mis"):
        for f in ("mean_full", "mean_num"):
            m = {}
            for r in rows:
                if r["is_gold"] and r["prompt"] == p and r["ablation"] == "base":
                    m[(r["domain"], r["query_id"])] = r[f]
            if m:
                w("%-9s %-9s %s" % (p, f, fmt(A.map_stats(m))))
    for p1, p0 in (("toc", "none"), ("toc", "toc_drop"), ("toc", "shuffle")):
        for f in ("mean_full", "mean_num"):
            a, b = {}, {}
            for r in rows:
                if r["is_gold"] and r["ablation"] == "base":
                    k = (r["domain"], r["query_id"])
                    if r["prompt"] == p1:
                        a[k] = r[f]
                    elif r["prompt"] == p0:
                        b[k] = r[f]
            if a and b:
                w("%-16s %-9s %s" % ("%s-%s" % (p1, p0), f, fmt(A.map_stats(A.diff_maps(a, b)))))
    w("")

    w("== 11. train-count association (base) ==")
    for p in ("toc", "none"):
        tc = {}
        for r in rows:
            if r["is_gold"] and r["prompt"] == p and r["ablation"] == "base":
                tc[(r["domain"], r["query_id"])] = r["train_count"]
        for t in types:
            m = qmap(base, p, "base", t)
            xs, ys = [], []
            for k, v in m.items():
                if k in tc:
                    xs.append(tc[k])
                    ys.append(v)
            if len(xs) >= 3:
                st = A.spearman(xs, ys)
                w("%-4s %-7s rho=%+.3f p=%.4f n=%d" % (p, t, st["rho"], st["p"], st["n"]))
    w("")

    w("== 12. per-domain margin (base) ==")
    for p in ("toc", "none", "shuffle"):
        for t in types:
            m = qmap(base, p, "base", t)
            if not m:
                continue
            for d in domains:
                vals = [v for k, v in m.items() if k[0] == d]
                if vals:
                    w("%-4s %-7s %-16s %s" % (p, t, d, fmt(A.paired(vals))))
    w("")

    text = "\n".join(out)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(text + "\n")
    print(text)
    print("\nwrote", args.out)


if __name__ == "__main__":
    main()
