#!/usr/bin/env python3
"""A5: ルーティング弾性の測定（考察のための予備測定）。

1 個の expert だけを ReLU² に劣化させ、その expert の top-1 占有率がどれだけ動くかを見る。
動きの大きさ = **ルーティング弾性**。A4 では小 expert 群（2 個）で −0.169、大 expert 群で
+0.002 だった。ここでは 8 個を 1 個ずつ測って順位を作る。

見るもの
  ε_i = −(share_i(deg_ei) − share_i(all_relu))   大きいほど「劣化させると避けられる」＝主力
  Δiv_i = iv(deg_ei) − iv(all_relu)               劣化させたときの品質コスト
  使用率 share_i(all_relu)                         既存の（因果でない）重要度
  幅 w_i                                          交絡の候補（K2 で「幅は位置の代理」と分かっている）
"""
import argparse
import json
import math
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a4")


def load(fn):
    with open(os.path.join(D, fn), encoding="utf-8") as fh:
        return [r for r in json.load(fh) if "evals" in r]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", default="a5_elasticity.json")
    args = ap.parse_args()

    base = load("a4_results.json")
    probe = load("a4_results_p.json")
    base = [r for r in base if r["arm"] == "all_relu"]
    arms = sorted({r["arm"] for r in probe})
    E = len(base[0]["routing"]["usage"])
    widths = base[0]["widths"]

    print("=== 0. 構成 ===")
    print(f"  baseline all_relu: n={len(base)} seeds={sorted(r['seed'] for r in base)}")
    print(f"  probe: {len(arms)} arms, n={len(probe)//max(len(arms),1)} seeds"
          f"{sorted({r['seed'] for r in probe})}")
    print(f"  expert 数={E} widths={widths}")

    seeds = sorted({r["seed"] for r in probe} & {r["seed"] for r in base})

    def share(rows, arm, i):
        return np.array([r["routing"]["usage"][i] for r in rows
                         if r["arm"] == arm and r["seed"] in seeds])

    def iv(rows, arm):
        return np.array([r["evals"][-1]["instr_valid"] for r in rows
                         if r["arm"] == arm and r["seed"] in seeds])

    print("\n=== 1. expert ごとの弾性と品質コスト ===")
    print(f"  {'i':>2s}{'w':>5s}{'share(base)':>13s}{'share(deg)':>12s}"
          f"{'ε':>9s}{'t':>7s}{'p':>8s}{'Δiv':>8s}")
    rows_out = []
    for i in range(E):
        arm = f"deg_e{i}"
        if arm not in arms:
            continue
        s0, s1 = share(base, "all_relu", i), share(probe, arm, i)
        d = s1 - s0
        se = d.std(ddof=1) / math.sqrt(len(d))
        t, p = stats.ttest_rel(s1, s0)
        i0, i1 = iv(base, "all_relu"), iv(probe, arm)
        rows_out.append(dict(i=i, w=widths[i], share0=float(s0.mean()),
                             share1=float(s1.mean()), eps=float(-d.mean()),
                             t=float(t), p=float(p), div=float((i1 - i0).mean())))
        print(f"  {i:>2d}{widths[i]:>5d}{s0.mean():>13.4f}{s1.mean():>12.4f}"
              f"{-d.mean():>+9.4f}{t:>+7.2f}{p:>8.4f}{(i1-i0).mean():>+8.3f}")

    if not rows_out:
        print("  データが無い")
        return

    print("\n=== 2. 弾性の順位（自分の占有率がどれだけ下がったか）===")
    for k, r in enumerate(sorted(rows_out, key=lambda x: -x["eps"]), 1):
        print(f"  {k} 位: e{r['i']} (w={r['w']})  ε={r['eps']:+.4f}  "
              f"share={r['share0']:.3f}  Δiv={r['div']:+.3f}")

    # --- 2b. 8×8 の置換行列（誰を劣化させると誰に移るか）---
    print("\n=== 2b. 置換行列 Δusage[j]（行=劣化させた expert、列=占有率の変化）===")
    M = np.zeros((E, E))
    for i in range(E):
        arm = f"deg_e{i}"
        if arm not in arms:
            continue
        for j in range(E):
            M[i, j] = float((share(probe, arm, j) - share(base, "all_relu", j)).mean())
    hdr = "        " + "".join(f"{f'e{j}':>8s}" for j in range(E)) + f"{'計':>9s}"
    print(hdr)
    for i in range(E):
        cells = "".join(f"{M[i, j]:>+8.3f}" for j in range(E))
        print(f"  e{i} w{widths[i]:<4d}{cells}{M[i].sum():>+9.3f}")
    print("\n  対角（自分が避けられた量）と、移った先の最大:")
    for i in range(E):
        j = int(np.argmax(np.where(np.arange(E) == i, -9, M[i])))
        print(f"    e{i} → 自分 {M[i, i]:+.4f} / 最大の移り先 e{j} {M[i, j]:+.4f}")

    print("\n=== 3. 弾性は何の代理か（n=8 なので参考値）===")
    eps = np.array([r["eps"] for r in rows_out])
    sh = np.array([r["share0"] for r in rows_out])
    wd = np.array([r["w"] for r in rows_out])
    dv = np.array([r["div"] for r in rows_out])
    for nm, v in (("使用率 share", sh), ("幅 w", wd), ("品質コスト Δiv", dv)):
        if v.std() > 1e-12 and eps.std() > 1e-12:
            r, p = stats.pearsonr(eps, v)
            print(f"  r(ε, {nm:14s}) = {r:+.3f} (p={p:.3f})")
    # 使用率で割った弾性（「使われている割に避けられるか」）
    rel = eps / np.maximum(sh, 1e-9)
    print("\n  ε / share（使用率で正規化した弾性）:")
    for r, v in sorted(zip(rows_out, rel), key=lambda x: -x[1]):
        print(f"    e{r['i']} (w={r['w']:>3d})  ε/share = {v:+.3f}")

    # 使用率を統制した残差
    if sh.std() > 1e-12:
        A = np.vstack([np.ones_like(sh), sh]).T
        coef, *_ = np.linalg.lstsq(A, eps, rcond=None)
        res = eps - A @ coef
        print(f"\n  ε を share に回帰した残差（統制後の順位）:")
        for r, v in sorted(zip(rows_out, res), key=lambda x: -x[1]):
            print(f"    e{r['i']} (w={r['w']:>3d})  残差 = {v:+.4f}")

    out = {"experts": rows_out, "seeds": seeds, "widths": widths}
    with open(os.path.join(D, args.json), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(f"\n[write] {os.path.join(D, args.json)}")


if __name__ == "__main__":
    main()
