# -*- coding: utf-8 -*-
"""P7c 解析（統合）: α 代理は幅の代理になるか

入力: p7c_width.npz（base, split, a05, p05, p05r, p1）
      p7d_width.npz（base, split, p05f, p05b, p15f）
出力: p7c_analysis.json / p7c_analysis_out_utf8.txt

中心:
  (1) α=0.5 と実半幅のコスト差（全層・前半・後半）
  (2) 実幅で P7 の結論が生き残るか: p15f vs p1（どちらも実 16 スロット）
"""

import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TAGS = ["p7c", "p7d"]
P6C_BASE = 2.68932
P7 = {"u05": 0.00327, "f05": 0.00019, "b05": 0.00145,
      "u1": 0.01512, "h15f": 0.01072}


def stats(d):
    d = np.asarray(d, np.float64)
    n = d.size
    m = float(d.mean())
    se = float(d.std(ddof=1)) / np.sqrt(n)
    return {"mean": m, "se": se, "n": int(n),
            "t": m / se if se > 0 else float("nan"),
            "ci95": [m - 1.96 * se, m + 1.96 * se], "mde80": 2.8 * se}


def fmt(d):
    return "%+.5f (se %.5f, t %+.2f, n=%d)" % (d["mean"], d["se"], d["t"], d["n"])


def main():
    nll, lang = {}, None
    for tag in TAGS:
        p = os.path.join(HERE, "%s_width.npz" % tag)
        if not os.path.exists(p):
            continue
        z = np.load(p, allow_pickle=True)
        if lang is None:
            lang = z["lang"]
        for k in z.files:
            if k.startswith("nll_"):
                nll.setdefault(k[4:], z[k])
    base = nll["base"]
    n, nw = base.size, lang.size
    per = n // nw
    assert per * nw == n
    tok_lang = np.repeat(lang, per)

    def win(a, b):
        return (nll[a] - nll[b]).reshape(nw, per).mean(1)

    lines = []
    def emit(s=""):
        lines.append(s)
        print(s, flush=True)

    emit("=== P7c 実幅 expert（n=%d, %d 窓） ===" % (n, nw))
    emit("")
    out = {"n_tokens": int(n), "n_windows": int(nw)}

    # ---------- 0. 水準 ----------
    emit("[0] 水準（base との対応差・窓クラスタ）")
    emit("%-6s %10s %11s %9s %8s" % ("cond", "CE", "dCE", "se", "t"))
    for c in ["base", "split", "a05", "p05", "p05r", "p1", "p05f", "p05b", "p15f"]:
        if c not in nll:
            continue
        d = stats(win(c, "base"))
        emit("%-6s %10.5f %+11.5f %9.5f %+8.2f" % (c, nll[c].mean(), d["mean"], d["se"], d["t"]))
        out.setdefault("levels", {})[c] = {"ce": float(nll[c].mean()), "delta": d}
    emit("")

    # ---------- 1. 校正 ----------
    emit("[1] 校正（P6c / P7 との照合）")
    emit("    base CE %.5f vs P6c %.5f → %s"
         % (base.mean(), P6C_BASE,
            "ビット一致" if abs(float(base.mean()) - P6C_BASE) < 1e-5 else "不一致"))
    for c, key in (("a05", "u05"), ("p1", "u1")):
        if c in nll:
            v = float((nll[c] - base).mean())
            emit("    %s ΔCE %+.5f vs P7 %s %+.5f（差 %+.5f）" % (c, v, key, P7[key], v - P7[key]))
    out["calibration"] = {"base_ce": float(base.mean())}
    emit("")

    # ---------- 2. 分割の丸め ----------
    d = stats(win("split", "base"))
    emit("[2] 分割の丸め（split − base）: %s" % fmt(d))
    emit("    a05 も p05 も split 基準なので、以下の差では相殺される")
    out["split_artifact"] = d
    emit("")

    # ---------- 3. α と実幅（全層） ----------
    emit("[3] 中心: α=0.5 と実半幅（全層）")
    res = {}
    for lab, a, b in (("a05 − split", "a05", "split"), ("p05 − split", "p05", "split"),
                      ("p05 − a05", "p05", "a05"), ("p05r − split", "p05r", "split"),
                      ("p05r − p05", "p05r", "p05")):
        if a in nll and b in nll:
            d = stats(win(a, b))
            emit("    %-12s %s" % (lab, fmt(d)))
            res[lab] = d
    if "a05 − split" in res and "p05 − split" in res:
        ratio = res["p05 − split"]["mean"] / res["a05 − split"]["mean"]
        emit("    **実幅 / α = %.2f 倍**（α はコストを %.0f%% 過小評価）"
             % (ratio, 100 * (1 - 1 / ratio)))
        out["ratio_all"] = float(ratio)
    out["all"] = res
    emit("")

    # ---------- 4. 前半 / 後半 ----------
    emit("[4] 前半 / 後半（P7 の f05 / b05 との比較）")
    out["split_half"] = {}
    for h, pc, ac in (("前半", "p05f", "f05"), ("後半", "p05b", "b05")):
        if pc not in nll:
            continue
        dp = stats(win(pc, "split"))
        emit("    %s 実幅 %+.5f  vs  α %+.5f  → 比 %s"
             % (h, dp["mean"], P7[ac],
                ("%.2f" % (dp["mean"] / P7[ac])) if P7[ac] else "—（α が 0 近傍）"))
        out["split_half"][h] = {"prune": dp, "alpha_ref": P7[ac]}
    emit("")

    # ---------- 5. P7 の結論は実幅で生き残るか ----------
    emit("[5] 実幅で P7 の結論を検定（どちらも実 16 スロット）")
    if "p15f" in nll and "p1" in nll:
        d = stats(win("p15f", "p1"))
        emit("    p15f − p1 = %s" % fmt(d))
        emit("    → %s" % ("半スロット配分が実幅でも勝つ" if d["mean"] < 0 else "実幅では勝てない"))
        out["p15f_vs_p1"] = d
        # α 版の同じ対比
        emit("    参考: α 版の h15f − u1 = %+.5f（P7）" % (P7["h15f"] - P7["u1"]))
    emit("")

    # ---------- 6. FLOPs 会計 ----------
    emit("[6] FLOPs 会計（expert が層の 74.9%）")
    emit("    条件     実節約スロット  ΔCE       ΔCE/スロット")
    table = {"p1": 16, "p15f": 16, "p05": 0.5, "a05": 0.0,
             "p05f": 0.25, "p05b": 0.25}
    for c, r in table.items():
        if c not in nll:
            continue
        d = float((nll[c] - base).mean())
        emit("    %-6s %10.2f %12.5f %14s"
             % (c, r, d, ("%.6f" % (d / r)) if r else "—"))
        out.setdefault("flops", {})[c] = {"slots": r, "dce": d,
                                          "per_slot": (d / r) if r else None}
    emit("")

    # ---------- 7. 言語別 ----------
    emit("[7] 言語別（p05 − a05）")
    out["per_lang"] = {}
    if "p05" in nll and "a05" in nll:
        for lg in ("en", "ja"):
            sel = (tok_lang == lg)
            d = stats((nll["p05"][sel] - nll["a05"][sel]).reshape(nw // 2, per).mean(1))
            emit("    %s: %s" % (lg, fmt(d)))
            out["per_lang"][lg] = d

    with open(os.path.join(HERE, "p7c_analysis.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2, default=float)
    with open(os.path.join(HERE, "p7c_analysis_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(lines) + "\n")
    print("saved: p7c_analysis.json / p7c_analysis_out_utf8.txt")


if __name__ == "__main__":
    main()
