import re, sys
from markdown_it import MarkdownIt
p = sys.argv[1]
raw = open(p, encoding="utf-8").read()
for name, src in (("raw", raw), ("split-join", "\n".join(raw.split("\n")))):
    html = MarkdownIt("commonmark").enable("table").render(src)
    body = re.sub(r"<pre>.*?</pre>", "", html, flags=re.S)
    body = re.sub(r"<code>.*?</code>", "", body, flags=re.S)
    cjk = re.findall(r"[\u3040-\u30ff\u4e00-\u9fff]\s+[\u3040-\u30ff\u4e00-\u9fff]", body)
    print(f"{name}: {len(cjk)}")
    for m in re.finditer(r"[\u3040-\u30ff\u4e00-\u9fff]\s+[\u3040-\u30ff\u4e00-\u9fff]", body):
        i = m.start()
        print("   ", repr(body[max(0,i-30):i+30]))