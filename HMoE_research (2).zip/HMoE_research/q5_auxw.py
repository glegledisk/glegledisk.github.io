#!/usr/bin/env python3
"""Q5: p_pen 強度（auxw）の dose-response — 頻度仮説の最後の未操作ノブ。

背景: Q1–Q4 で「幅の配分は頻度で決まる」ことを支持する証拠が溜まった（Q3: payload 率 80→50% で
width_struct −18.7, 6/6）。その機構の実体は補助損失 p_pen
`E·Σ f_i·P_i·(dims_i/mean)` が**幅×使用率**に比例すること。ならば**その強度 auxw を直接振れば
Δ が単調に動くはず**。これが最後の未操作ノブ（Q4 §6 で「次は auxw」と書いた）。

設計: タスク・レイアウト・訓練条件を Q2 の compute（ADADSDADAS, payload 80%, T=109）に固定し、
**auxw だけ**を振る。auxw = 0 / 0.05 / 0.2、H+LB、seed 0–5 の 6 本。

予測（事前登録）
  P1（操作チェック）: auxw を上げると使用率が平坦になる（正規化エントロピー上昇）
  P2（主予測）: Δ（小 expert 選択率 payload − struct）は auxw に対して単調増加。
     auxw=0 で Δ が最小（0 近傍または負）、auxw=0.2 で最大
  P3: width_struct は auxw に対して単調減少（強いペナルティほど struct が細い側へ）
  Kill: auxw=0 で使用率が崩壊（正規化エントロピー < 0.5）した場合、Δ の値は解釈不能
        （ルータが 1 個の expert に潰れて Δ が機械的に 0 になる）。この場合は
        「auxw=0 の Δ」を機構の証拠に使わない

出力: simulation_hmoe_mmlu/data/q5/H+LB_{task}_aw{auxw}_s{seed}.json / q5_results.json
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import q2_difficulty_ladder as Q2  # noqa: E402
from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS  # noqa: E402

OUTDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q5")


def usage_entropy(usage):
    """usage: リスト（層 0 の top-1 出現数）。正規化エントロピー（0=1 個に集中, 1=完全一様）。"""
    u = np.asarray(usage, float)
    p = u / max(1.0, u.sum())
    p = p[p > 0]
    if len(p) <= 1:
        return 0.0
    return float(-(p * np.log(p)).sum() / np.log(len(u)))


def run(arm, task, seed, auxw, n_seqs, epochs, bs, lr):
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    aux_mode = "p_pen" if arm.startswith("H") else "switch"
    model = RewriteMoE(WIDTHS[arm], seed=seed)
    opt = Adam(model.params(), lr=lr)
    nparam = sum(v.numel() for v in model.params().values())

    steps_per_ep = max(1, n_seqs // bs)
    t0 = time.time()
    hist = []
    for ep in range(epochs):
        run_loss = 0.0
        for _ in range(steps_per_ep):
            seq, _ = Q2.make_trace_batch(rng, bs, task=task)
            x = torch.from_numpy(seq)
            logits, aux, _ = model(x, aux_mode=aux_mode)
            loss = Q2.trace_loss(logits, seq) + auxw * aux
            loss.backward()
            opt.step(model.params())
            run_loss += float(loss.detach())
        hist.append(run_loss / steps_per_ep)
        print(f"    [{arm} {task} aw{auxw} s{seed}] ep{ep+1}/{epochs} "
              f"loss={hist[-1]:.4f} ({time.time()-t0:.0f}s)", flush=True)

    ev_rng = np.random.default_rng(777)
    seq, typ = Q2.make_trace_batch(ev_rng, 1024, task=task)
    conds = {"base": (None, None), "force_small": (None, Q2.SMALL)}
    ev = Q2.evaluate(model, seq, typ, conds)

    # 使用率の偏り（層 0）。collapse の検出用
    for c in ("base",):
        ev[c]["usage_entropy"] = usage_entropy(ev[c]["usage_l0"])
        u = np.asarray(ev[c]["usage_l0"], float)
        ev[c]["usage_share_max"] = float(u.max() / max(1.0, u.sum()))

    out = {"arm": arm, "seed": seed, "task": task, "auxw": auxw, "nparam": nparam,
           "loss_hist": hist, "n_eval": 1024, "sec": round(time.time() - t0, 1),
           "eval": ev}
    os.makedirs(OUTDIR, exist_ok=True)
    torch.save({k: v.detach() for k, v in model.params().items()},
               os.path.join(OUTDIR, f"ckpt_{arm}_{task}_aw{auxw}_s{seed}.pt"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", default="H+LB")
    ap.add_argument("--task", default="compute")
    ap.add_argument("--auxw", nargs="+", type=float, default=[0.0, 0.05, 0.2])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4, 5])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--resume", action="store_true")
    args = ap.parse_args()

    os.makedirs(OUTDIR, exist_ok=True)
    torch.set_num_threads(6)
    print(f"task={args.task} auxw={args.auxw} seeds={args.seeds} "
          f"T={Q2.T_LEN} payload={Q2.N_DIG}/{Q2.TPI}", flush=True)

    rows = []
    for aw in args.auxw:
        tag = f"{aw:g}"
        for seed in args.seeds:
            p = os.path.join(OUTDIR, f"{args.arm}_{args.task}_aw{tag}_s{seed}.json")
            if args.resume and os.path.exists(p):
                try:
                    with open(p, encoding="utf-8") as f:
                        r = json.load(f)
                    if r.get("n_eval") == 1024:
                        print(f"  [skip] aw{tag} s{seed}", flush=True)
                        rows.append(r)
                        continue
                except (json.JSONDecodeError, OSError):
                    pass
            r = run(args.arm, args.task, seed, aw, args.seqs, args.epochs,
                    args.bs, args.lr)
            rows.append(r)
            e = r["eval"]["base"]
            print(f"  -> aw{tag} s{seed}: acc pl = {e['acc_payload']:.4f} "
                  f"small st/pl = {e['small_struct']:.3f}/{e['small_payload']:.3f} "
                  f"(Δ={e['small_payload']-e['small_struct']:+.3f}) "
                  f"wid st/pl = {e['width_struct']:.1f}/{e['width_payload']:.1f} "
                  f"H(usage)={e['usage_entropy']:.3f} "
                  f"maxshare={e['usage_share_max']:.3f}", flush=True)
            with open(p, "w", encoding="utf-8") as f:
                json.dump(r, f, ensure_ascii=False, indent=2)

    with open(os.path.join(OUTDIR, "q5_results.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
    print(f"[write] {OUTDIR}", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
