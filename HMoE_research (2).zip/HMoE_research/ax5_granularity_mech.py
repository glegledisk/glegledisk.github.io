#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX5: 文長分布を操作した粒度カーブの機構解析

設計書: AX5課題設計書_文長分布を操作した粒度カーブの機構解析_20261112.md
（走行前に分割定義・決定規則・検定族・主腕を凍結）

新規 forward 13 本:
  u7_rep / sent340_rep / global1 / uni102 / uni181 / uni340 / uni630 /
  uni1224 / shift340 / shift340b / lognorm340 / alt340 / tok_randmatch

確認的（Holm m=2, alpha=0.05, 両側）
  H1（主）: G_uni340 - G_sent340 = 0
  H2      : G_sent340 - G_shift340 = 0
操作チェック（Holm 家族の外）
  H3      : 均一長カーブの log-N トレンド

実行:
  python ax5_granularity_mech.py --dry-run
  python ax5_granularity_mech.py --tag ax5
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ax2_layer_cost import paired, holm, spearman  # noqa: E402

N_LAYERS = 16
N_WIN = 48
LEN = 256
N_EVAL = LEN - 1
N_TOK = N_WIN * N_EVAL
ALPHA = 0.05
AX3_NPZ = os.path.join(HERE, "ax3_transfer.npz")
AX4_NPZ = os.path.join(HERE, "ax4_sentence_bound.npz")
AX3_CORPUS = os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz")

SEED_SHIFT_A = 5201
SEED_LOGNORM = 5202
SEED_ALT = 5203
SEED_TOKMATCH = 5204
SEED_SHIFT_B = 5205
SEED_SHIFT_W = 5206

TEE = None


def log(msg):
    print(msg, flush=True)
    if TEE is not None:
        TEE.write(msg + "\n")
        TEE.flush()


# ---------------------------------------------------------------- partitions
def balanced_lengths(n_unit, total):
    base, rem = divmod(total, n_unit)
    lens = np.full(n_unit, base, dtype=np.int64)
    lens[:rem] += 1
    return lens


def lognorm_lengths(n_unit, total, mean, cv, seed):
    rng = np.random.RandomState(seed)
    sigma2 = math.log(1.0 + cv * cv)
    sigma = math.sqrt(sigma2)
    mu = math.log(mean) - sigma2 / 2.0
    x = rng.lognormal(mu, sigma, size=n_unit)
    x = x / x.mean() * mean
    x = np.clip(x, 1.0, 255.0)
    lens = np.floor(x).astype(np.int64)
    rem = total - int(lens.sum())
    frac = x - lens
    if rem > 0:
        order = np.argsort(-frac)
        # 端数を大きい順に +1。1 周で足りない場合は循環する。
        k = 0
        while rem > 0:
            idx = order[k % n_unit]
            if lens[idx] < 255:
                lens[idx] += 1
                rem -= 1
            k += 1
            if k > 100000:
                raise RuntimeError("lognorm adjustment did not converge")
    elif rem < 0:
        order = np.argsort(frac)
        k = 0
        need = -rem
        while need > 0:
            idx = order[k % n_unit]
            if lens[idx] > 1:
                lens[idx] -= 1
                need -= 1
            k += 1
            if k > 100000:
                raise RuntimeError("lognorm adjustment did not converge")
    assert int(lens.sum()) == total, (lens.sum(), total)
    return lens


def lengths_to_uid(lens):
    uid = np.repeat(np.arange(len(lens), dtype=np.int32), lens)
    assert uid.size == int(lens.sum())
    return uid


def length_stats(lens):
    lens = np.asarray(lens, dtype=np.float64)
    sd = float(lens.std())
    return {"n": int(lens.size), "sum": int(lens.sum()),
            "mean": float(lens.mean()), "median": float(np.median(lens)),
            "min": int(lens.min()), "max": int(lens.max()),
            "cv": float(sd / lens.mean()) if lens.mean() > 0 else float("nan"),
            "skew": float(((lens - lens.mean()) ** 3).mean() / (sd ** 3))
            if sd > 0 else 0.0,
            "p10": float(np.percentile(lens, 10)),
            "p90": float(np.percentile(lens, 90))}


# ---------------------------------------------------------------- decisions
def unit_decision(Y):
    n = Y.shape[0]
    cut = np.argmin(Y[:, N_LAYERS:], axis=1).astype(np.int8)
    Q = Y[:, :N_LAYERS].copy()
    Q[np.arange(n), cut] = -np.inf
    prot = np.argmax(Q, axis=1).astype(np.int8)
    assert (cut != prot).all(), "cut == protect"
    return cut, prot


def unit_targets(c8, c7, uid, n_unit):
    c8u = np.stack([np.bincount(uid, weights=c8[L], minlength=n_unit)
                    for L in range(N_LAYERS)], axis=1)
    c7u = np.stack([np.bincount(uid, weights=c7[L], minlength=n_unit)
                    for L in range(N_LAYERS)], axis=1)
    cnt = np.bincount(uid, minlength=n_unit).astype(np.float64)
    assert cnt.min() > 0, "empty unit"
    return np.concatenate([c8u / cnt[:, None], c7u / cnt[:, None]], axis=1)


def kmat_global(uid, cut, prot):
    """大域 uid から (16, 48*256) の k 行列。評価外の窓末 1 トークンは 7。"""
    km = np.full((N_LAYERS, N_TOK), 7, dtype=np.int8)
    ar = np.arange(N_TOK)
    km[cut[uid], ar] = 6
    km[prot[uid], ar] = 8
    km = km.reshape(N_LAYERS, N_WIN, N_EVAL)
    km = np.concatenate([km, np.full((N_LAYERS, N_WIN, 1), 7, dtype=np.int8)],
                        axis=2)
    return km.reshape(N_LAYERS, N_WIN * LEN)


def kmat_from_decisions(cut_tok, prot_tok):
    """per-token 決定から (16, 48*256) の k 行列。"""
    assert cut_tok.shape == (N_TOK,) and prot_tok.shape == (N_TOK,)
    assert (cut_tok != prot_tok).all()
    km = np.full((N_LAYERS, N_TOK), 7, dtype=np.int8)
    ar = np.arange(N_TOK)
    km[cut_tok, ar] = 6
    km[prot_tok, ar] = 8
    km = km.reshape(N_LAYERS, N_WIN, N_EVAL)
    km = np.concatenate([km, np.full((N_LAYERS, N_WIN, 1), 7, dtype=np.int8)],
                        axis=2)
    return km.reshape(N_LAYERS, N_WIN * LEN)


# ---------------------------------------------------------------- main
def main():
    global TEE
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--tag", type=str, default="ax5")
    args = ap.parse_args()
    tag = args.tag
    if not args.dry_run:
        TEE = open(os.path.join(HERE, "%s_granularity_mech_out_utf8.txt" % tag),
                   "w", encoding="utf-8")

    z4 = np.load(AX4_NPZ)
    z3 = np.load(AX3_NPZ)
    c8 = z4["c8"].astype(np.float64)
    c7 = z4["c7"].astype(np.float64)
    assert c8.shape == (N_LAYERS, N_TOK) and c7.shape == (N_LAYERS, N_TOK)
    sent = z4["sent"].astype(np.int64)
    sent_lens = np.bincount(sent)
    n_sent = int(sent_lens.size)
    assert n_sent == 340 and int(sent_lens.sum()) == N_TOK
    log("[1] c8/c7 loaded: %s / %s, sent %d units" % (c8.shape, c7.shape, n_sent))
    log("    sentence len mean %.4f cv %.4f min %d max %d"
        % (sent_lens.mean(), sent_lens.std() / sent_lens.mean(),
           sent_lens.min(), sent_lens.max()))

    # ---- C3: decision reproduction ----
    log("[2] C3 decision reproduction")
    cut_tok = np.argmin(c7, axis=0).astype(np.int8)
    Q = c8.copy()
    Q[cut_tok, np.arange(N_TOK)] = -np.inf
    prot_tok = np.argmax(Q, axis=0).astype(np.int8)
    c3 = {"tok_cut_eq": int(np.abs(cut_tok.astype(np.int16)
                                   - z3["cut_tok_o"].astype(np.int16)).max()),
          "tok_prot_eq": int(np.abs(prot_tok.astype(np.int16)
                                    - z3["prot_tok_o"].astype(np.int16)).max())}
    uid_win = np.repeat(np.arange(N_WIN, dtype=np.int32), N_EVAL)
    cut_w, prot_w = unit_decision(unit_targets(c8, c7, uid_win, N_WIN))
    c3["win_cut_eq"] = int(np.abs(cut_w.astype(np.int16)
                                  - z3["cut_w_o"].astype(np.int16)).max())
    c3["win_prot_eq"] = int(np.abs(prot_w.astype(np.int16)
                                   - z3["prot_w_o"].astype(np.int16)).max())
    cut_s, prot_s = unit_decision(unit_targets(c8, c7, sent, n_sent))
    c3["sent_cut_eq"] = int(np.abs(cut_s.astype(np.int16)
                                   - z4["cut_s"].astype(np.int16)).max())
    c3["sent_prot_eq"] = int(np.abs(prot_s.astype(np.int16)
                                    - z4["prot_s"].astype(np.int16)).max())
    assert all(v == 0 for v in c3.values()), c3
    log("    " + "  ".join("%s %d" % (k, v) for k, v in c3.items()))

    # ---- partitions ----
    log("[3] build partitions")
    parts = {}
    parts["sent340"] = {"uid": sent, "lens": sent_lens, "kind": "aligned"}
    parts["global1"] = {"uid": np.zeros(N_TOK, dtype=np.int32),
                        "lens": np.array([N_TOK], dtype=np.int64), "kind": "global"}
    uni_ns = [102, 181, 340, 630, 1224]
    for n in uni_ns:
        lens = balanced_lengths(n, N_TOK)
        parts["uni%d" % n] = {"uid": lengths_to_uid(lens), "lens": lens,
                              "kind": "uniform"}
    rng_a = np.random.RandomState(SEED_SHIFT_A)
    lens_a = rng_a.permutation(sent_lens)
    rng_b = np.random.RandomState(SEED_SHIFT_B)
    lens_b = rng_b.permutation(sent_lens)
    parts["shift340"] = {"uid": lengths_to_uid(lens_a), "lens": lens_a,
                         "kind": "shifted"}
    parts["shift340b"] = {"uid": lengths_to_uid(lens_b), "lens": lens_b,
                          "kind": "shifted"}
    lens_ln = lognorm_lengths(340, N_TOK, 36.0,
                              float(sent_lens.std() / sent_lens.mean()),
                              SEED_LOGNORM)
    parts["lognorm340"] = {"uid": lengths_to_uid(lens_ln), "lens": lens_ln,
                           "kind": "lognormal"}
    lens_alt = np.array([7, 65] * 170, dtype=np.int64)
    rng_alt = np.random.RandomState(SEED_ALT)
    lens_alt = rng_alt.permutation(lens_alt)
    parts["alt340"] = {"uid": lengths_to_uid(lens_alt), "lens": lens_alt,
                       "kind": "alternating"}
    parts["tok12240"] = {"uid": np.arange(N_TOK, dtype=np.int32),
                         "lens": np.ones(N_TOK, dtype=np.int64), "kind": "token"}

    # 追記（走行前 2026-11-12 00:20）: 窓境界の交絡を分離する窓内対照
    sent_w_lens = []
    for w in range(N_WIN):
        sw = sent[w * N_EVAL:(w + 1) * N_EVAL]
        sw = sw - sw.min()
        lw = np.bincount(sw)
        assert int(lw.sum()) == N_EVAL and int(lw.min()) >= 1
        sent_w_lens.append(lw)
    assert sum(len(lw) for lw in sent_w_lens) == 340

    def within_window_uid(lens_list):
        out, off = [], 0
        for lw in lens_list:
            m = len(lw)
            out.append(np.repeat(np.arange(m, dtype=np.int32) + off, lw))
            off += m
        uid = np.concatenate(out)
        assert uid.size == N_TOK and off == 340
        return uid

    rng_sw = np.random.RandomState(SEED_SHIFT_W)
    shiftw_lens = [rng_sw.permutation(lw) for lw in sent_w_lens]
    for a, b in zip(sent_w_lens, shiftw_lens):
        assert np.array_equal(np.sort(a), np.sort(b))
    uniw_lens = []
    for lw in sent_w_lens:
        m = len(lw)
        base, rem = divmod(N_EVAL, m)
        l2 = np.full(m, base, dtype=np.int64)
        l2[:rem] += 1
        uniw_lens.append(l2)
    parts["uni340w"] = {"uid": within_window_uid(uniw_lens),
                        "lens": np.concatenate(uniw_lens),
                        "kind": "uniform_window"}
    parts["shift340w"] = {"uid": within_window_uid(shiftw_lens),
                          "lens": np.concatenate(shiftw_lens),
                          "kind": "shifted_window"}

    c2 = {"parts": {}}
    for nm, p in parts.items():
        uid, lens = p["uid"], np.asarray(p["lens"])
        assert uid.shape == (N_TOK,)
        assert int(uid.min()) == 0 and int(uid.max()) == len(lens) - 1
        assert np.array_equal(np.bincount(uid), lens)
        assert lens.min() >= 1 and int(lens.sum()) == N_TOK
        c2["parts"][nm] = {"n_unit": int(len(lens)), "kind": p["kind"],
                           "len_stats": length_stats(lens)}
        if nm in ("shift340", "shift340b"):
            assert np.array_equal(np.sort(lens), np.sort(sent_lens))
            c2["parts"][nm]["multiset_eq_sent"] = True
        if nm in ("uni102", "uni181", "uni340", "uni630", "uni1224"):
            assert int(lens.max() - lens.min()) <= 1
        if nm == "uni340w":
            for w in range(N_WIN):
                sw = parts[nm]["uid"][w * N_EVAL:(w + 1) * N_EVAL]
                lw = np.bincount(sw - sw.min())
                assert int(lw.max() - lw.min()) <= 1
        if nm == "shift340w":
            for w in range(N_WIN):
                sw_s = sent[w * N_EVAL:(w + 1) * N_EVAL]
                sw_s = sw_s - sw_s.min()
                sw_h = parts[nm]["uid"][w * N_EVAL:(w + 1) * N_EVAL]
                sw_h = sw_h - sw_h.min()
                assert np.array_equal(np.sort(np.bincount(sw_s)),
                                      np.sort(np.bincount(sw_h)))
            c2["parts"][nm]["multiset_eq_sent_within_window"] = True
        log("    %-12s N %5d  mean %7.2f  cv %.4f  min %3d  max %4d"
            % (nm, len(lens), lens.mean(), lens.std() / lens.mean(),
               lens.min(), lens.max()))

    # ---- decisions for each partition ----
    log("[4] decisions")
    dec = {}
    for nm in ["global1", "uni102", "uni181", "uni340", "uni630", "uni1224",
               "shift340", "shift340b", "lognorm340", "alt340",
               "uni340w", "shift340w", "sent340", "tok12240"]:
        uid = parts[nm]["uid"]
        Y = unit_targets(c8, c7, uid, int(uid.max()) + 1)
        cut, prot = unit_decision(Y)
        dec[nm] = {"cut": cut, "prot": prot}
        log("    %-12s cut hist %s  prot hist %s"
            % (nm, np.bincount(cut, minlength=N_LAYERS).tolist(),
               np.bincount(prot, minlength=N_LAYERS).tolist()))

    # tok_randmatch: per-token oracle (cut, protect) 対を並べ替える
    rng_m = np.random.RandomState(SEED_TOKMATCH)
    perm = rng_m.permutation(N_TOK)
    cut_m = cut_tok[perm].astype(np.int8)
    prot_m = prot_tok[perm].astype(np.int8)
    assert (cut_m != prot_m).all()
    dec["tok_randmatch"] = {"cut": cut_m, "prot": prot_m, "per_token": True}

    # ---- k matrices / budget ----
    log("[5] k matrices / budget")
    kms = {}
    for nm, d in dec.items():
        if nm == "tok_randmatch":
            km = kmat_from_decisions(d["cut"], d["prot"])
        else:
            km = kmat_global(parts[nm]["uid"], d["cut"], d["prot"])
        kms[nm] = km
        log("    %-12s mean_k %.9f" % (nm, km.mean()))
    c4 = {"mean_k": {nm: float(km.mean()) for nm, km in kms.items()},
          "n_bad": int(sum(abs(float(km.mean()) - 7.0) > 1e-9
                           for km in kms.values()))}
    assert c4["n_bad"] == 0, c4

    # C5: decision validity (cut != protect is asserted in unit_decision)
    c5 = {"conflicts": {nm: int((d["cut"] == d["prot"]).sum())
                        for nm, d in dec.items()},
          "cut_hist": {nm: np.bincount(d["cut"], minlength=N_LAYERS).tolist()
                       for nm, d in dec.items()},
          "prot_hist": {nm: np.bincount(d["prot"], minlength=N_LAYERS).tolist()
                        for nm, d in dec.items()}}
    assert sum(c5["conflicts"].values()) == 0, c5["conflicts"]

    if args.dry_run:
        out = {"meta": {"dry_run": True, "n_tok": N_TOK},
               "C2": c2, "C3": c3, "C4": c4, "C5": c5}
        with open(os.path.join(HERE, "_ax5_dryrun.json"), "w",
                  encoding="utf-8") as fp:
            json.dump(out, fp, ensure_ascii=False, indent=2)
        log("dry-run OK: _ax5_dryrun.json")
        return

    # ---- model ----
    log("[6] load model")
    t0 = time.time()
    from transformers import AutoModelForCausalLM, AutoTokenizer
    AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    full_k = int(model.config.num_experts_per_tok)
    assert full_k == 8 and int(model.config.num_hidden_layers) == N_LAYERS
    gates = [l.mlp.gate for l in model.model.layers]
    gate_fwd = [g.forward for g in gates]
    assert all(not bool(g.norm_topk_prob) for g in gates), "norm_topk_prob must be False"
    log("      %.0f s" % (time.time() - t0))

    STATE = {"kmat": None}

    def make_masked(orig, li):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            km = STATE["kmat"]
            if km is not None and scores.shape[-1] == full_k:
                kk = km[li]
                if kk.numel() == scores.shape[0]:
                    ar = torch.arange(scores.shape[-1], device=scores.device,
                                      dtype=torch.float32)
                    scores = scores * (ar[None, :] < kk[:, None]).to(scores.dtype)
            return logits, scores, idx
        return _patched

    for i, g in enumerate(gates):
        g.forward = make_masked(gate_fwd[i], i)

    zc = np.load(AX3_CORPUS, allow_pickle=True)
    seqs = []
    for lg in ("en", "ja"):
        ids = zc[lg + "_ids"].astype(np.int64)[:N_WIN // 2 * LEN]
        for w in range(N_WIN // 2):
            seqs.append((lg, torch.from_numpy(ids[w * LEN:(w + 1) * LEN])))
    assert len(seqs) == N_WIN

    CACHE = os.path.join(HERE, "_ax5_cache_%s" % tag)
    os.makedirs(CACHE, exist_ok=True)

    def run_eval(name, native_topks=None, kmat_windows=None):
        cf = os.path.join(CACHE, "%s.npz" % name)
        if os.path.exists(cf):
            d = np.load(cf)
            nll = d["nll"].astype(np.float32)
            a1 = d["acc1"].astype(np.float32)
            if nll.size == N_TOK and a1.size == N_TOK:
                log("      %-14s CACHED  CE %.5f  top1 %.4f"
                    % (name, nll.mean(), a1.mean()))
                return {"nll": nll, "acc1": a1}
        t1 = time.time()
        if kmat_windows is not None:
            for g in gates:
                g.top_k = full_k
        else:
            STATE["kmat"] = None
            tk = full_k if native_topks is None else native_topks
            for i, g in enumerate(gates):
                g.top_k = int(tk[i] if not np.isscalar(tk) else tk)
        nll_c, a1_c = [], []
        with torch.no_grad():
            for wi, (lg, ids) in enumerate(seqs):
                if kmat_windows is not None:
                    STATE["kmat"] = torch.from_numpy(
                        kmat_windows[:, wi * LEN:(wi + 1) * LEN].astype(np.float32)
                    ).to(model.device)
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                logit = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(logit, tgt, reduction="none")
                true_l = logit.gather(1, tgt.unsqueeze(-1))
                a1_c.append(((logit > true_l).sum(-1) == 0).float().cpu().numpy())
                nll_c.append(nll.cpu().numpy())
                del out, logit
        STATE["kmat"] = None
        nll = np.concatenate(nll_c).astype(np.float32)
        a1 = np.concatenate(a1_c).astype(np.float32)
        np.savez(cf, nll=nll, acc1=a1)
        log("      %-14s CE %.5f  top1 %.4f  (%.0f s)"
            % (name, nll.mean(), a1.mean(), time.time() - t1))
        return {"nll": nll, "acc1": a1}

    log("[7] calibration forwards")
    res = {}
    r = run_eval("u7_rep", native_topks=[7] * N_LAYERS)
    res["u7_rep"] = r
    r = run_eval("sent340_rep", kmat_windows=kms["sent340"])
    res["sent340_rep"] = r

    log("[8] arms")
    arm_order = ["global1", "uni102", "uni181", "uni340", "uni630", "uni1224",
                 "shift340", "shift340b", "lognorm340", "alt340",
                 "uni340w", "shift340w", "tok_randmatch"]
    for nm in arm_order:
        res[nm] = run_eval(nm, kmat_windows=kms[nm])

    # ---- stats ----
    log("[9] stats / calibration")
    N = {k: v["nll"].astype(np.float64) for k, v in res.items()}
    u7 = N["u7_rep"]
    nll_ax4_u7 = z4["nll_u7_rep"].astype(np.float64)
    nll_ax4_sent = z4["nll_sent_oracle"].astype(np.float64)
    nll_ax3_win = z3["nll_lay_win_oracle"].astype(np.float64)
    nll_ax3_tok = z3["nll_lay_tok_oracle"].astype(np.float64)
    nll_ax4_rand = z4["nll_sent_random"].astype(np.float64)
    base_win = u7 - nll_ax3_win
    base_tok = u7 - nll_ax3_tok
    base_rand = u7 - nll_ax4_rand

    c1 = {"u7_maxdiff": float(np.abs(N["u7_rep"] - nll_ax4_u7).max()),
          "sent_maxdiff": float(np.abs(N["sent340_rep"] - nll_ax4_sent).max())}
    c1["tier"] = "A" if c1["u7_maxdiff"] == 0.0 and c1["sent_maxdiff"] == 0.0 else "FAIL"
    log("    C1 u7 %.1f  sent %.1f  tier %s"
        % (c1["u7_maxdiff"], c1["sent_maxdiff"], c1["tier"]))

    gains = {}
    for nm in ["u7_rep", "sent340_rep"] + arm_order:
        gains[nm] = paired(u7 - N[nm], N_WIN, N_EVAL)
    gains["win48"] = paired(base_win, N_WIN, N_EVAL)
    gains["tok12240"] = paired(base_tok, N_WIN, N_EVAL)
    gains["sent_random"] = paired(base_rand, N_WIN, N_EVAL)
    nll_map = dict(N)
    nll_map["win48"] = nll_ax3_win
    nll_map["tok12240"] = nll_ax3_tok
    nll_map["sent_random"] = nll_ax4_rand

    d_h1 = N["uni340"] - N["sent340_rep"]
    d_h2 = N["shift340"] - N["sent340_rep"]
    st1, st2 = paired(d_h1, N_WIN, N_EVAL), paired(d_h2, N_WIN, N_EVAL)
    ph = holm({"H1": st1["p_two"], "H2": st2["p_two"]})
    rej = {k: bool(ph[k] < ALPHA) for k in ph}
    if rej["H1"] and rej["H2"]:
        case = "A"
    elif rej["H1"] and not rej["H2"]:
        case = "B"
    elif (not rej["H1"]) and rej["H2"]:
        case = "C"
    else:
        case = "D"

    # H3: uniform family log-N trend
    uni_ns = [48, 102, 181, 340, 630, 1224]
    uni_arms = ["win48", "uni102", "uni181", "uni340", "uni630", "uni1224"]
    w = np.log(np.array(uni_ns, dtype=np.float64))
    w = w - w.mean()
    d_h3 = np.zeros(N_TOK, dtype=np.float64)
    for wk, nm in zip(w, uni_arms):
        d_h3 -= wk * nll_map[nm]    # u7 は Σw=0 で消える
    st3 = paired(d_h3, N_WIN, N_EVAL)
    h3 = {"weights": w.tolist(), "mean": st3["mean"], "se": st3["se"],
          "t": st3["t"], "p_two": st3["p_two"], "mde": st3["mde"],
          "ci95": st3["ci95"], "reject": bool(st3["p_two"] < ALPHA)}

    # C7: partition-draw noise
    st_c7 = paired(N["shift340"] - N["shift340b"], N_WIN, N_EVAL)
    c7n = {"mean": st_c7["mean"], "se": st_c7["se"], "t": st_c7["t"],
           "p_two": st_c7["p_two"], "mde": st_c7["mde"],
           "flag_partition_noise": bool(abs(st_c7["mean"])
                                        > 0.5 * abs(st2["mean"]))}

    # ---- exploratory ----
    exp = {
        "G_uniform_minus_shift": paired(N["shift340"] - N["uni340"], N_WIN, N_EVAL),
        "G_uniform_minus_lognorm": paired(N["lognorm340"] - N["uni340"], N_WIN, N_EVAL),
        "G_uniform_minus_alt": paired(N["alt340"] - N["uni340"], N_WIN, N_EVAL),
        "G_global1": paired(u7 - N["global1"], N_WIN, N_EVAL),
        "G_specific_48": paired(N["global1"] - nll_ax3_win, N_WIN, N_EVAL),
        "G_specific_340": paired(N["global1"] - N["sent340_rep"], N_WIN, N_EVAL),
        "G_specific_tok": paired(N["global1"] - nll_ax3_tok, N_WIN, N_EVAL),
        "G_tok_randmatch": paired(u7 - N["tok_randmatch"], N_WIN, N_EVAL),
        "G_assignment_tok": paired(N["tok_randmatch"] - nll_ax3_tok, N_WIN, N_EVAL),
        "G_global1_minus_win48": paired(nll_ax3_win - N["global1"], N_WIN, N_EVAL),
        "G_uniformw_minus_sent": paired(N["uni340w"] - N["sent340_rep"], N_WIN, N_EVAL),
        "G_sent_minus_shiftw": paired(N["shift340w"] - N["sent340_rep"], N_WIN, N_EVAL),
        "G_uniformw_minus_shiftw": paired(N["shift340w"] - N["uni340w"], N_WIN, N_EVAL),
        "G_shift_global_minus_window": paired(N["shift340"] - N["shift340w"], N_WIN, N_EVAL),
        "G_uni_global_minus_window": paired(N["uni340"] - N["uni340w"], N_WIN, N_EVAL),
    }

    # Jensen fit: f(L) = a + b log L + c (log L)^2 on the uniform arms
    L_uni = np.array([N_TOK / n for n in uni_ns], dtype=np.float64)
    y_uni = np.array([gains[nm]["mean"] for nm in uni_arms], dtype=np.float64)
    X = np.stack([np.ones_like(L_uni), np.log(L_uni), np.log(L_uni) ** 2], axis=1)
    coef, *_ = np.linalg.lstsq(X, y_uni, rcond=None)
    y_hat = X @ coef
    r2 = 1.0 - float(((y_uni - y_hat) ** 2).sum()
                     / ((y_uni - y_uni.mean()) ** 2).sum())

    def f_len(L):
        z = np.log(np.asarray(L, dtype=np.float64))
        return coef[0] + coef[1] * z + coef[2] * z * z

    jensen = {"coef": coef.tolist(), "r2_uniform": r2,
              "uniform_points": [{"N": int(n), "L": float(L), "G": float(g)}
                                 for n, L, g in zip(uni_ns, L_uni, y_uni)]}
    for nm in ["sent340", "shift340", "shift340b", "lognorm340", "alt340",
               "uni340w", "shift340w", "tok12240"]:
        lens = parts[nm]["lens"].astype(np.float64)
        pred = float(np.mean(f_len(lens)))
        obs = float(gains["sent340_rep" if nm == "sent340" else nm]["mean"])
        jensen[nm] = {"pred": pred, "obs": obs, "resid": obs - pred}

    # descriptive regression on random-boundary arms
    reg_arms = ([("global1", 1, 0.0)]
                + [("win48", 48, 0.0)]
                + [("uni%d" % n, n, float(parts["uni%d" % n]["lens"].std()
                                          / parts["uni%d" % n]["lens"].mean()))
                   for n in uni_ns if n != 48]
                + [("shift340", 340, float(sent_lens.std() / sent_lens.mean())),
                   ("shift340b", 340, float(sent_lens.std() / sent_lens.mean())),
                   ("lognorm340", 340, float(parts["lognorm340"]["lens"].std()
                                             / parts["lognorm340"]["lens"].mean())),
                   ("alt340", 340, float(parts["alt340"]["lens"].std()
                                         / parts["alt340"]["lens"].mean())),
                   ("uni340w", 340, float(parts["uni340w"]["lens"].std()
                                          / parts["uni340w"]["lens"].mean())),
                   ("shift340w", 340, float(parts["shift340w"]["lens"].std()
                                            / parts["shift340w"]["lens"].mean())),
                   ("tok12240", 12240, 0.0)])
    Xr = np.array([[1.0, math.log(n), cv] for _, n, cv in reg_arms])
    yr = np.array([gains[nm]["mean"] for nm, _, _ in reg_arms])
    beta, *_ = np.linalg.lstsq(Xr, yr, rcond=None)
    yh = Xr @ beta
    r2r = 1.0 - float(((yr - yh) ** 2).sum() / ((yr - yr.mean()) ** 2).sum())
    # LOO
    loo = []
    for i in range(len(yr)):
        m = np.ones(len(yr), dtype=bool)
        m[i] = False
        b_i, *_ = np.linalg.lstsq(Xr[m], yr[m], rcond=None)
        loo.append(float(yr[i] - Xr[i] @ b_i))
    loo = np.array(loo)
    r2_loo = 1.0 - float((loo ** 2).sum() / ((yr - yr.mean()) ** 2).sum())
    pred_sent = float(np.array([1.0, math.log(340),
                                float(sent_lens.std() / sent_lens.mean())]) @ beta)
    reg = {"arms": [nm for nm, _, _ in reg_arms], "beta": beta.tolist(),
           "r2": r2r, "r2_loo": r2_loo,
           "pred_sent340": pred_sent,
           "resid_sent340": float(gains["sent340_rep"]["mean"]) - pred_sent}

    # agreement / Jensen gap descriptive
    agree = {}
    for nm in ["global1", "win48", "uni102", "uni181", "uni340", "uni630",
               "uni1224", "sent340", "shift340", "shift340b", "lognorm340",
               "alt340", "uni340w", "shift340w", "tok12240"]:
        if nm == "win48":
            uid = uid_win
        elif nm == "sent340":
            uid = sent
        else:
            uid = parts[nm]["uid"]
        if nm == "win48":
            cut, prot = cut_w, prot_w
        elif nm == "tok12240":
            cut, prot = cut_tok, prot_tok
        else:
            cut, prot = dec[nm]["cut"], dec[nm]["prot"]
        agree[nm] = {
            "agree_cut": float((cut[uid] == cut_tok).mean()),
            "agree_prot": float((prot[uid] == prot_tok).mean()),
            "agree_both": float(((cut[uid] == cut_tok)
                                 & (prot[uid] == prot_tok)).mean()),
        }
    # Jensen gap (descriptive; additive c8/c7 is not used as a gain claim)
    per_c7 = float(c7[cut_tok, np.arange(N_TOK)].mean())
    per_c8 = float(c8[prot_tok, np.arange(N_TOK)].mean())
    jgap = {}
    for nm in ["global1", "win48", "uni102", "uni181", "uni340", "uni630",
               "uni1224", "sent340", "shift340", "shift340b", "lognorm340",
               "alt340", "uni340w", "shift340w"]:
        if nm == "win48":
            uid = uid_win
        elif nm == "sent340":
            uid = sent
        else:
            uid = parts[nm]["uid"]
        if nm == "win48":
            cut, prot = cut_w, prot_w
        else:
            cut, prot = dec[nm]["cut"], dec[nm]["prot"]
        uc7 = float(c7[cut[uid], np.arange(N_TOK)].mean())
        uc8 = float(c8[prot[uid], np.arange(N_TOK)].mean())
        jgap[nm] = {"cut_gap": uc7 - per_c7, "prot_gap": uc8 - per_c8,
                    "total": (uc7 - per_c7) + (uc8 - per_c8)}

    # C5 は dry-run 前に計算済み（dec のみに依存）。
    # ---- output ----
    out = {
        "meta": {"tag": tag, "windows": N_WIN, "len": LEN, "n_tok": int(N_TOK),
                 "n_arms": len(res),
                 "design": "AX5課題設計書_文長分布を操作した粒度カーブの機構解析_20261112.md",
                 "seeds": {"shift_a": SEED_SHIFT_A, "shift_b": SEED_SHIFT_B,
                           "lognorm": SEED_LOGNORM, "alt": SEED_ALT,
                           "tok_randmatch": SEED_TOKMATCH}},
        "confirmatory": {"H1_uniform_minus_sent": st1,
                         "H2_sent_minus_shift": st2,
                         "holm": ph, "reject": rej, "case": case},
        "manipulation_check_H3": h3,
        "calib": {"C1": c1, "C2": c2, "C3": c3, "C4": c4, "C5": c5,
                  "C6": {"uniform": "u7_rep", "random": "sent_random",
                         "oracle": "sent340_rep",
                         "random_gain": float(base_rand.mean()),
                         "oracle_gain": float((u7 - nll_ax4_sent).mean()),
                         "random_le_oracle": bool(base_rand.mean()
                                                  <= (u7 - nll_ax4_sent).mean())},
                  "C7": c7n},
        "probe_quality": None,
        "exploratory": {"gains": gains, "decomposition": exp, "jensen": jensen,
                        "regression": reg, "agreement": agree,
                        "jensen_gap_descriptive": jgap,
                        "granularity_curve": {
                            "global1": gains["global1"]["mean"],
                            "win48": gains["win48"]["mean"],
                            "uni102": gains["uni102"]["mean"],
                            "uni181": gains["uni181"]["mean"],
                            "uni340": gains["uni340"]["mean"],
                            "uni630": gains["uni630"]["mean"],
                            "uni1224": gains["uni1224"]["mean"],
                            "sent340": gains["sent340_rep"]["mean"],
                            "shift340": gains["shift340"]["mean"],
                            "lognorm340": gains["lognorm340"]["mean"],
                            "alt340": gains["alt340"]["mean"],
                            "tok12240": gains["tok12240"]["mean"]},
                        "window_controls": {
                            "sent340": gains["sent340_rep"]["mean"],
                            "uni340w": gains["uni340w"]["mean"],
                            "shift340w": gains["shift340w"]["mean"]}},
        "results": {k: {"ce": float(v["nll"].mean()),
                        "delta_vs_u7": float((v["nll"].astype(np.float64) - u7).mean()),
                        "top1": float(v["acc1"].mean()),
                        "mean_k": (float(kms[k].mean()) if k in kms else 7.0)}
                    for k, v in res.items()},
    }
    # C5 is recorded above; C7 is the partition-draw noise check.
    log("[10] save")
    with open(os.path.join(HERE, "%s_granularity_mech.json" % tag), "w",
              encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    np.savez_compressed(
        os.path.join(HERE, "%s_granularity_mech.npz" % tag),
        **{("nll_" + k): v["nll"] for k, v in res.items()},
        **{("acc1_" + k): v["acc1"] for k, v in res.items()},
        c8=c8, c7=c7,
        **{("uid_" + nm): p["uid"] for nm, p in parts.items()},
        **{("lens_" + nm): p["lens"] for nm, p in parts.items()},
        **{("cut_" + nm): dec[nm]["cut"] for nm in dec},
        **{("prot_" + nm): dec[nm]["prot"] for nm in dec},
        h3_weights=w,
    )
    log("")
    log("== confirmatory (Holm m=2, alpha=%.2f) ==" % ALPHA)
    log("H1 G_uni340 - G_sent340 %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
        % (st1["mean"], st1["t"], st1["p_two"], ph["H1"], st1["mde"]))
    log("H2 G_sent340 - G_shift340 %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
        % (st2["mean"], st2["t"], st2["p_two"], ph["H2"], st2["mde"]))
    log("case = %s" % case)
    log("H3 uniform log-N trend %+.8f  t %+.4f  p %.6g  MDE %.8f  reject %s"
        % (st3["mean"], st3["t"], st3["p_two"], st3["mde"], h3["reject"]))
    log("granularity curve: " + "  ".join(
        "%s %+.5f" % (k, v) for k, v in out["exploratory"]["granularity_curve"].items()))
    log("C1 %s  C4 bad %d  C7 mean %+.8f  flag %s"
        % (c1["tier"], c4["n_bad"], c7n["mean"], c7n["flag_partition_noise"]))
    log("saved: %s_granularity_mech.npz / .json" % tag)
    TEE.close()
    os._exit(0)


if __name__ == "__main__":
    main()
