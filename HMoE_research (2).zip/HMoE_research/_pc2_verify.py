#!/usr/bin/env python3
"""PC2 の検算: 平均・対応差・t・p・符号・MACs 比を json から再計算する。"""
import json
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
j = json.load(open(os.path.join(HERE, "pc2_results_n3k.json"), encoding="utf-8"))
rows = j["rows"]
by = {}
for r in rows:
    by.setdefault(r["cfg"], {})[r["seed"]] = r

print("== 水準 ==")
for cfg, d in by.items():
    ce = np.array([v["ce"] for v in d.values()])
    ci = np.array([v["ce_init"] for v in d.values()])
    acc = np.array([v["acc"] for v in d.values()])
    w = np.array([v["width_mean"] for v in d.values()])
    print("  %-14s n=%d  init %.4f  CE %.4f (sd %.4f, min %.4f, max %.4f)  acc %.4f  幅 %.1f  MACs %d  param %d"
          % (cfg, len(d), ci.mean(), ce.mean(), ce.std(ddof=1), ce.min(), ce.max(),
             acc.mean(), w.mean(), d[list(d)[0]]["macs"], d[list(d)[0]]["nparam"]))

print("\n== 対応差（scipy で再計算）==")
for a, b in [("half:prune", "half:scratch"), ("teacher", "half:scratch"),
             ("teacher", "half:prune")]:
    for key in ("ce", "ce_init", "acc"):
        A = np.array([by[a][s][key] for s in sorted(by[a])])
        B = np.array([by[b][s][key] for s in sorted(by[b])])
        d = A - B
        t, p = stats.ttest_rel(A, B)
        mde = (stats.t.ppf(0.975, len(d) - 1) + stats.t.ppf(0.8, len(d) - 1)) * d.std(ddof=1) / np.sqrt(len(d))
        print("  %-13s - %-13s %-8s Δ %+0.4f  se %.4f  t %+0.2f  p %.4f  n %d  負 %d  MDE %.4f"
              % (a, b, key, d.mean(), d.std(ddof=1) / np.sqrt(len(d)), t, p, len(d),
                 int((d < 0).sum()), mde))
    print("")

print("== 学習曲線の最終 3 epoch（ce_hist）==")
for cfg, d in by.items():
    for s in sorted(d):
        h = [x["ce"] for x in d[s]["ce_hist"]][-3:]
        print("  %-14s s%d  %s" % (cfg, s, np.round(h, 4).tolist()))
