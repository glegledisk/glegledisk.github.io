"""H1 本番グリッド: b × arm × seed。結果は h1_results.jsonl に追記。"""
import json
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
EXE = sys.executable
STEPS = "2000"

BS = [1, 4, 16]
ARMS = ["uni_k1", "uni_k2", "het_l002", "het_l005", "het_l02"]
SEEDS = [0, 1, 2]

# 幅の掃引（凸性の測定）は b=16 のみ
SWEEP = ["uni_s05", "uni_s075", "uni_s15"]

out = os.path.join(HERE, "h1_results.jsonl")
if os.path.exists(out):
    os.remove(out)

jobs = [(a, b, s) for b in BS for a in ARMS for s in SEEDS]
jobs += [(a, 16, s) for a in SWEEP for s in SEEDS]

t0 = time.time()
for i, (arm, b, seed) in enumerate(jobs, 1):
    el = time.time() - t0
    print(f"[{i}/{len(jobs)}] {arm} b={b} seed={seed}  elapsed={el/60:.1f}m", flush=True)
    r = subprocess.run([EXE, "h1_hybrid_testbed.py", "--arm", arm, "--b", str(b),
                        "--seed", str(seed), "--steps", STEPS, "--out", "h1_results.jsonl"],
                       cwd=HERE, capture_output=True, text=True, encoding="utf-8")
    if r.returncode != 0:
        print("  FAIL", r.stderr[-800:], flush=True)
    else:
        line = r.stdout.splitlines()[0]
        d = json.loads(line)
        print(f"  val={d['val']:.4f} cost={d['cost']:.3f} sec={d['sec']:.0f}", flush=True)
print("DONE", flush=True)
