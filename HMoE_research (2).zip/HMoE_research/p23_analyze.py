# -*- coding: utf-8 -*-
"""P23 解析: cap 4096 で完走率はどこまで上がるか

【設計上の注意（重要）】
P20/P23 は seed を**ラウンド先頭で 1 回だけ**打つので、問題ループを跨いで RNG が進む。
cap を変えると 1 問目が使う token 数が変わり、**2 問目以降の RNG 状態が変わる**。
したがって「同一サンプルを長く生成した」ペア比較は**1 問目でしか成立しない**
（実測: 接頭辞一致 2/25 はすべて 1 問目）。以下では
  (a) 1 問目だけ対応比較
  (b) 2 問目以降は独立標本として比率比較
を行う。

見るもの: 完走率 / `</think>` 率 / ntok / 答えあり率 / 答えあり中の正解率 / Wilson CI
出力: p23_analysis.json / p23_analysis_out_utf8.txt
"""
import json
import math
import os
import re

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = []
END = "</" + "think>"
NUM_RE = re.compile(r"\d[\d,]*")


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def wilson(k, n, z=1.96):
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return ((c - h) / d, (c + h) / d)


def ans_of(txt):
    if END not in txt:
        return None
    m = NUM_RE.findall(txt[txt.rfind(END) + len(END):])
    return m[-1].replace(",", "") if m else None


def main():
    p23 = [json.loads(l) for l in open(os.path.join(HERE, "p23_cap4096.jsonl"),
                                       encoding="utf-8") if l.strip()]
    qs = [r["q"] for r in p23]
    p20 = {}
    for line in open(os.path.join(HERE, "p20_think.jsonl"), encoding="utf-8"):
        r = json.loads(line)
        if r.get("round") == "greedy":
            continue
        if r["q"] in qs:
            p20[r["q"]] = r["samples"]
    assert len(p20) == len(qs)
    n = sum(len(r["samples"]) for r in p23)
    log("問題 %d / サンプル %d（cap 4096）" % (len(qs), n))

    # ---- 1. 接頭辞一致はどこで成立するか ----
    log("\n[1] 接頭辞一致（2048 で打ち切られたサンプル）— 問題別")
    per_q = []
    for idx, r in enumerate(p23):
        chk = [(j, s, p20[r["q"]][j]) for j, s in enumerate(r["samples"])
               if p20[r["q"]][j]["ntok"] == 2048]
        nm = sum(1 for _, s, ref in chk if s["text"].startswith(ref["text"]))
        per_q.append({"q": r["q"], "n_check": len(chk), "n_match": nm})
        log("  #%02d %-28s 検査 %d / 一致 %d" % (idx + 1, r["q"], len(chk), nm))
    tot_chk = sum(x["n_check"] for x in per_q)
    tot_match = sum(x["n_match"] for x in per_q)
    log("  合計: 一致 %d/%d" % (tot_match, tot_chk))
    log("  → 一致は #01 に集中（seed をラウンド先頭で 1 回だけ打つため、cap が変わると")
    log("     1 問目が消費する token 数が変わり、2 問目以降の RNG 状態がずれる）")

    # ---- 2. 完走率 ----
    f24 = np.array([ref["finished"] for r in p23 for ref in p20[r["q"]]], float)
    f40 = np.array([s["finished"] for r in p23 for s in r["samples"]], float)
    e24 = np.array([END in ref["text"] for r in p23 for ref in p20[r["q"]]], float)
    e40 = np.array([s["has_end"] for r in p23 for s in r["samples"]], float)
    ntok24 = np.array([ref["ntok"] for r in p23 for ref in p20[r["q"]]], float)
    ntok40 = np.array([s["ntok"] for r in p23 for s in r["samples"]], float)

    log("\n[2] 完走率・</think>率（独立標本として比較, n=%d ずつ）" % n)
    for lab, a, b in [("完走（EOS で停止）", f24, f40), ("</think> あり", e24, e40)]:
        k24, k40 = int(a.sum()), int(b.sum())
        lo24, hi24 = wilson(k24, n)
        lo40, hi40 = wilson(k40, n)
        tab = [[k40, n - k40], [k24, n - k24]]
        chi2, pchi, _, _ = stats.chi2_contingency(tab, correction=False)
        log("  %-16s cap2048 %d/%d=%.3f [%.3f, %.3f]  →  cap4096 %d/%d=%.3f [%.3f, %.3f]"
            % (lab, k24, n, k24 / n, lo24, hi24, k40, n, k40 / n, lo40, hi40))
        log("                   χ²=%.2f p=%.3g" % (chi2, pchi))
    log("  ntok: cap2048 中央 %.0f / 平均 %.0f  →  cap4096 中央 %.0f / 平均 %.0f"
        % (np.median(ntok24), ntok24.mean(), np.median(ntok40), ntok40.mean()))

    # 1 問目だけ対応比較
    r0 = p23[0]
    a0 = [ref["finished"] for ref in p20[r0["q"]]]
    b0 = [s["finished"] for s in r0["samples"]]
    log("\n  [1 問目のみ対応] %s: cap2048 完走 %d/4 → cap4096 完走 %d/4"
        % (r0["q"], sum(a0), sum(b0)))

    # ---- 3. 答えと正解率 ----
    log("\n[3] 答え領域規則（`</think>` 以降）")
    g24, g40 = [], []
    for r in p23:
        for ref in p20[r["q"]]:
            x = ans_of(ref["text"])
            g24.append(1 if (x is not None and x == r["gold"]) else 0)
        for s in r["samples"]:
            g40.append(1 if (s["correct_ans"] is True) else 0)
    a24 = [ans_of(ref["text"]) is not None for r in p23 for ref in p20[r["q"]]]
    a40 = [s["pred_ans"] is not None for r in p23 for s in r["samples"]]
    for lab, a, g in [("cap2048", a24, g24), ("cap4096", a40, g40)]:
        ans_n = int(sum(a))
        log("  %-8s 答えあり %d/%d=%.3f  正解（答えあり中）=%.3f  正解（全サンプル）=%.3f"
            % (lab, ans_n, n, ans_n / n, sum(g) / max(1, ans_n), sum(g) / n))

    # 問題単位の被覆
    cov24, cov40 = [], []
    for r in p23:
        cov24.append(1.0 if any(ans_of(x["text"]) is not None for x in p20[r["q"]]) else 0.0)
        cov40.append(1.0 if any(s["pred_ans"] is not None for s in r["samples"]) else 0.0)
    log("  問題被覆: cap2048 %d/%d → cap4096 %d/%d"
        % (int(sum(cov24)), len(cov24), int(sum(cov40)), len(cov40)))

    out = {"n_samples": n, "n_problems": len(qs),
           "prefix": {"checked": tot_chk, "matched": tot_match, "per_q": per_q},
           "finished_2048": int(f24.sum()), "finished_4096": int(f40.sum()),
           "finished_rate_2048": float(f24.mean()), "finished_rate_4096": float(f40.mean()),
           "wilson_4096": list(wilson(int(f40.sum()), n)),
           "wilson_2048": list(wilson(int(f24.sum()), n)),
           "has_end_2048": int(e24.sum()), "has_end_4096": int(e40.sum()),
           "median_ntok_2048": float(np.median(ntok24)),
           "median_ntok_4096": float(np.median(ntok40)),
           "answered_2048": int(sum(a24)), "answered_4096": int(sum(a40)),
           "acc_answered_2048": sum(g24) / max(1, sum(a24)),
           "acc_answered_4096": sum(g40) / max(1, sum(a40)),
           "coverage_problems_2048": int(sum(cov24)),
           "coverage_problems_4096": int(sum(cov40))}
    with open(os.path.join(HERE, "p23_analysis.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    with open(os.path.join(HERE, "p23_analysis_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    log("saved: p23_analysis.json")
    os._exit(0)


if __name__ == "__main__":
    main()
