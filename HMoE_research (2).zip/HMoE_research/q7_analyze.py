#!/usr/bin/env python3
"""Q7: 負荷分散損失切除（auxw=0）の集計・検定スクリプト。"""
import json
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q7")


def analyze_q7():
    results_path = os.path.join(DATA_DIR, "q7_results.json")
    if not os.path.exists(results_path):
        print("Results file not found yet.")
        return

    with open(results_path, encoding="utf-8") as f:
        res = json.load(f)

    arms = ["H+LB", "U+LB"]
    tasks = ["compute", "hard"]
    auxws = [0.0, 0.05]

    print("=" * 80)
    print("Q7: LOAD BALANCING ABLATION (auxw=0 vs 0.05) & COLLAPSE ANALYSIS")
    print("=" * 80)

    summary = {}
    for arm in arms:
        for task in tasks:
            for aw in auxws:
                key = f"{arm}_{task}_aw{aw:g}"
                runs = [r for r in res if r["arm"] == arm and r["task"] == task and abs(r["auxw"] - aw) < 1e-5]
                if len(runs) < 6:
                    print(f"Skipping {key}: only {len(runs)} runs")
                    continue

                ent = [r["eval"]["base"]["usage_entropy"] for r in runs]
                maxs = [r["eval"]["base"]["usage_share_max"] for r in runs]
                dead = [r["eval"]["base"]["dead_experts"] for r in runs]
                acc = [r["eval"]["base"]["acc_payload"] for r in runs]
                iv = [r["eval"]["base"]["instr_valid"] for r in runs]
                w_st = [r["eval"]["base"]["width_struct"] for r in runs]
                w_pl = [r["eval"]["base"]["width_payload"] for r in runs]
                deltas = [r["eval"]["base"]["small_payload"] - r["eval"]["base"]["small_struct"] for r in runs]

                summary[key] = {
                    "runs": runs,
                    "entropy": np.array(ent),
                    "maxshare": np.array(maxs),
                    "dead_experts": np.array(dead),
                    "acc_payload": np.array(acc),
                    "instr_valid": np.array(iv),
                    "width_struct": np.array(w_st),
                    "width_payload": np.array(w_pl),
                    "delta": np.array(deltas),
                }

                print(f"\n[{key}] (n={len(runs)})")
                print(f"  Entropy H   : mean={np.mean(ent):.3f}, se={stats.sem(ent):.3f}, min={np.min(ent):.3f}, max={np.max(ent):.3f}")
                print(f"  Max Share   : mean={np.mean(maxs):.3f}, se={stats.sem(maxs):.3f}, max={np.max(maxs):.3f}")
                print(f"  Dead Experts: mean={np.mean(dead):.1f}/8, max={np.max(dead)}/8")
                print(f"  Acc Payload : mean={np.mean(acc):.4f}, se={stats.sem(acc):.4f}")
                print(f"  Instr Valid : mean={np.mean(iv):.3f}, se={stats.sem(iv):.3f}")
                print(f"  Width st/pl : st={np.mean(w_st):.1f}, pl={np.mean(w_pl):.1f} (diff={np.mean(w_pl)-np.mean(w_st):+.1f})")
                print(f"  Δ           : mean={np.mean(deltas):+.3f}, se={stats.sem(deltas):.3f}")

    # Paired comparisons: aw0 minus aw0.05
    print("\n" + "=" * 80)
    print("PAIRED COMPARISONS (auxw=0 minus auxw=0.05, n=6, df=5)")
    print("=" * 80)

    for arm in arms:
        for task in tasks:
            k0 = f"{arm}_{task}_aw0"
            kb = f"{arm}_{task}_aw0.05"
            if k0 not in summary or kb not in summary:
                continue

            print(f"\n--- {arm} {task}: aw0 minus aw0.05 ---")
            for metric in ["entropy", "maxshare", "dead_experts", "acc_payload", "instr_valid", "width_payload", "width_struct", "delta"]:
                diff = summary[k0][metric] - summary[kb][metric]
                m_diff = np.mean(diff)
                se_diff = stats.sem(diff)
                t_val = m_diff / (se_diff + 1e-12)
                p_val = stats.t.sf(np.abs(t_val), df=5) * 2
                sign_str = f"{np.sum(diff > 0)}/6 正" if m_diff > 0 else f"{np.sum(diff < 0)}/6 負"
                print(f"  Δ {metric:<13}: {m_diff:+.4f} (se={se_diff:.4f}, t={t_val:+.2f}, p={p_val:.4f}, {sign_str})")

    # Save analysis summary
    out_json = {}
    for k, v in summary.items():
        out_json[k] = {
            "mean": {m: float(np.mean(arr)) for m, arr in v.items() if m != "runs"},
            "se": {m: float(stats.sem(arr)) for m, arr in v.items() if m != "runs"},
            "values": {m: arr.tolist() for m, arr in v.items() if m != "runs"}
        }

    out_path = os.path.join(DATA_DIR, "q7_analysis.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out_json, f, ensure_ascii=False, indent=2)
    print(f"\nSaved analysis to {out_path}")


if __name__ == "__main__":
    analyze_q7()
