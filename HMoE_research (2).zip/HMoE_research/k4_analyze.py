#!/usr/bin/env python3
"""K4 解析: トレース課題（Bayes CE = 0）で教師 HMoE と等計算量 dense を比べる。

見るもの
  1. 課題が飽和しているか（教師の CE と instr_valid）
  2. 収束した run だけでの ΔCE（失敗は訓練の産物なので分けて読む）
  3. 失敗の内訳と、それが平均をどう動かすか

出力: k4_analysis_out_utf8.txt / k4_analysis.json
"""
import json
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "k4_analysis_out_utf8.txt")
lines = []


def p(s=""):
    print(s, flush=True)
    lines.append(s)


def summ(d, label):
    d = np.asarray(d, float)
    n = len(d)
    m, se = float(d.mean()), float(d.std(ddof=1) / np.sqrt(n))
    t = m / se if se > 0 else float("nan")
    crit = stats.t.ppf(0.975, df=n - 1)
    coef = crit + stats.t.ppf(0.80, df=n - 1)
    return {"label": label, "n": n, "mean": m, "median": float(np.median(d)),
            "sd": float(d.std(ddof=1)), "se": se, "t": t,
            "p": float(2 * stats.t.sf(abs(t), df=n - 1)) if se > 0 else float("nan"),
            "mde": coef * se, "n_neg": int((d < 0).sum())}


def show(s):
    p("  %-18s n=%-2d 平均 %+.5f 中央値 %+.5f SD %.5f se %.5f t %+.2f p %.3f MDE %.5f 負 %d/%d"
      % (s["label"], s["n"], s["mean"], s["median"], s["sd"], s["se"], s["t"],
         s["p"], s["mde"], s["n_neg"], s["n"]))


def main():
    r = json.load(open(os.path.join(HERE, "k4_results_main.json"), encoding="utf-8"))
    rows = sorted(r["rows"], key=lambda x: x["seed"])

    p("K4: トレース課題（8 桁 × 10 命令、Bayes CE = 0）での教師 HMoE vs 等計算量 dense")
    p("")
    p("| seed | 生徒 W | CE_教師 | CE_生徒 | ΔCE | acc_p 教師/生徒 | instr 教師/生徒 |")
    p("|---:|---:|---:|---:|---:|---:|---:|")
    for x in rows:
        p("| %d | %d | %.4f | %.4f | %+.4f | %.3f / %.3f | %.3f / %.3f |"
          % (x["seed"], x["W_student"], x["teacher"]["ce_all"], x["student"]["ce_all"],
             x["delta"], x["teacher"]["acc_payload"], x["student"]["acc_payload"],
             x["teacher"]["instr_valid"], x["student"]["instr_valid"]))
    p("")

    d = np.array([x["delta"] for x in rows])
    p("== 1) 全 10 seed ==")
    a = summ(d, "全 10")
    show(a)
    p("  ※ 平均は s0（生徒が未収束, +1.0548）が単独で作る。中央値は +0.0002。")
    p("")

    p("== 2) 課題は飽和しているか ==")
    ce_t = np.array([x["teacher"]["ce_all"] for x in rows])
    iv_t = np.array([x["teacher"]["instr_valid"] for x in rows])
    iv_s = np.array([x["student"]["instr_valid"] for x in rows])
    p("  CE_教師: 中央値 %.5f / 最小 %.5f / 最大 %.5f（Bayes は 0）"
      % (np.median(ce_t), ce_t.min(), ce_t.max()))
    p("  instr_valid 教師: 中央値 %.3f / 範囲 %.3f〜%.3f" % (np.median(iv_t), iv_t.min(), iv_t.max()))
    p("  instr_valid 生徒: 中央値 %.3f / 範囲 %.3f〜%.3f" % (np.median(iv_s), iv_s.min(), iv_s.max()))
    p("  → **8/10 の教師が CE < 0.01・instr > 0.89。課題はほぼ解けている。**")
    p("  → Bayes 余裕は **0.0006 nats（中央値）**。書き換え課題（0.026）より小さい。")
    p("")

    TH = 0.5
    ok = [x for x in rows if x["teacher"]["instr_valid"] > TH and x["student"]["instr_valid"] > TH]
    bad = [x for x in rows if not (x["teacher"]["instr_valid"] > TH and x["student"]["instr_valid"] > TH)]
    p("== 3) 収束した run だけ（判定: 両方 instr_valid > %.1f） ==" % TH)
    p("  落ちた run: %s" % ", ".join(
        "s%d（%s %.3f）" % (x["seed"], "教師" if x["teacher"]["instr_valid"] <= TH else "生徒",
                           min(x["teacher"]["instr_valid"], x["student"]["instr_valid"]))
        for x in bad))
    b = summ([x["delta"] for x in ok], "収束 %d seed" % len(ok))
    show(b)
    p("  ※ 除外は事後だが、基準は各モデル自身の instr_valid（比較を見ていない）。")
    p("")

    p("== 4) 水準の比較（収束した run のみ） ==")
    for key in ("ce_all", "ce_payload", "acc_payload", "instr_valid"):
        A = np.array([x["teacher"][key] for x in ok])
        B = np.array([x["student"][key] for x in ok])
        p("  %-12s 教師 %.4f ± %.4f / 生徒 %.4f ± %.4f"
          % (key, A.mean(), A.std(ddof=1), B.mean(), B.std(ddof=1)))
    p("  MACs 比（教師/生徒）%.3f ± %.3f（W は教師の実測幅に合わせた）"
      % (np.mean([x["macs_ratio"] for x in rows]),
         np.std([x["macs_ratio"] for x in rows], ddof=1)))
    p("")

    p("== 5) 書き換え課題（K1e, 16 epoch）との対比 ==")
    p("  | 課題 | Bayes CE | 実測 CE（教師） | 余裕 | ΔCE（収束後） |")
    p("  |---|---:|---:|---:|---:|")
    p("  | 書き換え | 0.3251 | 0.3507 | 0.0256 | −0.0026 ± 0.0021（7 seed） |")
    p("  | トレース | 0 | %.4f | %.4f | %+.5f ± %.5f（%d seed） |"
      % (np.median(ce_t), np.median(ce_t), b["mean"], b["se"], b["n"]))
    p("  → **どちらも収束後は差が無い。余裕の大きさは関係なかった。**")
    p("")

    out = {"rows": rows, "all": a, "converged": b, "threshold": TH,
           "ce_teacher_median": float(np.median(ce_t))}
    with open(os.path.join(HERE, "k4_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=float)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n[write] %s" % OUT)


if __name__ == "__main__":
    main()
