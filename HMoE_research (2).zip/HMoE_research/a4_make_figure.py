#!/usr/bin/env python3
"""A4 の図。data/a4/a4_analysis.json を読むだけ。

左: 品質（instr_valid）— 部分配置の 3 本は同じで、全部に置いた 1 本だけ落ちる
右: 小 expert の占有率 — small_relu2 だけが下がる（＝ルータが避けた）
"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "MS Gothic", "sans-serif"]
matplotlib.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a4")
J = json.load(open(os.path.join(D, "a4_analysis.json"), encoding="utf-8"))
A = J["aggregate"]
ORDER = ["all_relu", "small_relu2", "large_relu2", "all_relu2"]
LABEL = {"all_relu": "全て ReLU", "small_relu2": "小に ReLU²",
         "large_relu2": "大に ReLU²", "all_relu2": "全て ReLU²"}
COL = {"all_relu": "#888888", "small_relu2": "#c44e52",
       "large_relu2": "#dd8452", "all_relu2": "#4c72b0"}

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12.6, 4.8))
xs = np.arange(len(ORDER))

iv = [A[a]["iv"] for a in ORDER]
sd = [A[a]["iv_sd"] for a in ORDER]
ax1.bar(xs, iv, yerr=sd, capsize=4, color=[COL[a] for a in ORDER],
        edgecolor="black", linewidth=0.6)
for x, v in zip(xs, iv):
    ax1.text(x, v + 0.03, f"{v:.3f}", ha="center", fontsize=9)
ax1.set_xticks(xs)
ax1.set_xticklabels([LABEL[a] for a in ORDER], fontsize=9)
ax1.set_ylabel("instr_valid（平均 ± SD, n=6）")
ax1.set_title("(a) 品質 — 部分配置はどれも同じ", fontsize=11)
ax1.grid(axis="y", alpha=0.3)
ax1.set_ylim(0, 1.0)

sh = [A[a]["small_share"] for a in ORDER]
shsd = [A[a]["small_share_sd"] for a in ORDER]
ax2.bar(xs, sh, yerr=shsd, capsize=4, color=[COL[a] for a in ORDER],
        edgecolor="black", linewidth=0.6)
for x, v in zip(xs, sh):
    ax2.text(x, v + 0.02, f"{v:.3f}", ha="center", fontsize=9)
ax2.axhline(A["all_relu"]["small_share"], color="black", ls="--", lw=1)
ax2.annotate("−0.169\n(p=0.0010, 6/6)", xy=(1, A["small_relu2"]["small_share"]),
             xytext=(1.35, 0.22), fontsize=9,
             arrowprops=dict(arrowstyle="->", color="black", lw=1.2))
ax2.set_xticks(xs)
ax2.set_xticklabels([LABEL[a] for a in ORDER], fontsize=9)
ax2.set_ylabel("小 expert の top-1 占有率")
ax2.set_title("(b) ルーティング — 小に置いたときだけ動く", fontsize=11)
ax2.grid(axis="y", alpha=0.3)
ax2.set_ylim(0, 0.75)

plt.tight_layout()
out = os.path.join(D, "a4_figure.png")
plt.savefig(out, dpi=150)
print(f"[write] {out}")
