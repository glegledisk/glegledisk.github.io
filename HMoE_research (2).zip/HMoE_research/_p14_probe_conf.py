# -*- coding: utf-8 -*-
"""P14 探索（使い捨て・_ 始め）: p_ans の飽和と span 長の影響。

問い: conf-max 選択が正解率を下げる（0.725 → 0.550）機構は何か。
  (a) p_ans はどれだけ飽和しているか（->1.0 の壁）
  (b) p_ans と span 長（n_ans）の関係（短い span ほど幾何平均が高くなるバイアス）
  (c) confmax8 はどの添字のサンプルを選ぶか、選ばれたサンプルの答トークン数
  (d) maj8 rep tok conf の AUROC CI が [0,1] に広がった原因（同点構造）
  (e) maj first-4 が first-8 を上回る (0.975 vs 0.900) はどう起きるか（flip 数）
出力: _p14_probe_out_utf8.txt（測定データは読むだけ・上書きなし）
"""

import json
import os
import numpy as np
from collections import Counter
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "_p14_probe_out_utf8.txt")


def log(m):
    print(m, flush=True)


def majority_first(sub, N):
    """p14_analyze.majority_result と同一 tie-break（同点票内で p_ans 最大）で first-N 多数決。"""
    cand = [s for s in sub[:N] if s["p_ans"] is not None and s["pred"] is not None]
    by_pred = {}
    for s in cand:
        by_pred.setdefault(s["pred"], []).append(s)
    best = None
    for pred, lst in by_pred.items():
        key = (len(lst), max(x["p_ans"] for x in lst))
        if best is None or key > best[0]:
            best = (key, pred)
    return best[1]


def main():
    buf = []

    def out(m):
        buf.append(m)
        log(m)

    recs, greedy = [], []
    with open(os.path.join(HERE, "p14_bestofn.jsonl"), encoding="utf-8") as fp:
        for line in fp:
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            if r.get("round") == "greedy":
                greedy.append(r)
            else:
                recs.append(r)

    rows = []
    for r in recs:
        for j, s in enumerate(r["samples"]):
            if s["p_ans"] is None:
                continue
            rows.append({"j": j, "gold": r["gold"], **s})
    pa = np.array([x["p_ans"] for x in rows])
    na = np.array([x["n_ans"] for x in rows], float)
    corr = np.array([x["correct"] for x in rows], bool)
    ntok = np.array([x["ntok"] for x in rows], float)
    out("n_samples=%.0f  mean p_ans=%.4f  median=%.4f  min=%.4g  max=%.6f"
        % (len(pa), pa.mean(), np.median(pa), pa.min(), pa.max()))

    out("\n--- (a) 飽和 ---")
    out("p_ans >= 0.9999: %d / %d (%.1f%%)   p_ans >= 0.999: %d (%.1f%%)"
        % (int((pa >= 0.9999).sum()), len(pa), 100 * (pa >= 0.9999).mean(),
           int((pa >= 0.999).sum()), 100 * (pa >= 0.999).mean()))
    out("uniq p_ans (round 4dp): %d / %d" 
        % (len(set(np.round(pa, 4).tolist())), len(pa)))

    out("\n--- (b) span 長と p_ans / 正解率 ---")
    for k in range(1, 6):
        m = na == k if k < 5 else na >= 5
        if m.sum() == 0:
            continue
        out("n_ans=%s: n=%-4d mean p_ans=%.4f acc=%.3f mean ntok=%.1f"
            % (str(k) if k < 5 else ">=5", int(m.sum()), pa[m].mean(),
               corr[m].mean(), ntok[m].mean()))
    rs = stats.spearmanr(na, pa)
    out("Spearman(n_ans, p_ans) = %.3f (p=%.3g)"
        % (rs.statistic, rs.pvalue))
    wl = stats.mannwhitneyu(pa[corr], pa[~corr])
    out("p_ans: 正解 mean=%.5f / 誤答 mean=%.5f / U test p=%.3g"
        % (pa[corr].mean(), pa[~corr].mean(), wl.pvalue))
    # 誤答でも「箱あり最終答」か「打ち切りスクラッチ」か（答桁数の近似: gold 桁数と n_ans 比較）
    digits_gold = np.array([len(r["gold"]) for r in recs for s in r["samples"]
                            if s["p_ans"] is not None], float)
    lenmatch = np.abs(na - digits_gold) <= 1
    out("span 長 ≈ gold 桁数（±1）: n=%d (%.1f%%)、内 正解率=%.3f / span 長が乖離: n=%d、正解率=%.3f"
        % (int(lenmatch.sum()), 100 * lenmatch.mean(), corr[lenmatch].mean(),
           int((~lenmatch).sum()), corr[~lenmatch].mean()))

    out("\n--- (c) confmax8 の選択 ---")
    pick_j = Counter()
    chosen_na, s1_na = [], []
    chosen_acc, s1_acc_l = [], []
    for r in recs:
        sub = r["samples"]
        best_j, best_p = None, -1.0
        for j, s in enumerate(sub[:8]):
            if s["p_ans"] is None or s["pred"] is None:
                continue
            if (s["p_ans"], -j) > (best_p, -(best_j or 0)):
                p_new, _ = (s["p_ans"], -j)
                if p_new > best_p:
                    best_p, best_j = p_new, j
        if best_j is None:
            continue
        pick_j[best_j] += 1
        chosen_na.append(sub[best_j]["n_ans"])
        chosen_acc.append(sub[best_j]["pred"] == r["gold"])
        s1_na.append(sub[0]["n_ans"])
        s1_acc_l.append(sub[0]["pred"] == r["gold"])
    out("選択添字の分布 N=8: %s" % dict(sorted(pick_j.items())))
    out("選ばれた n_ans mean=%.2f / s1 n_ans mean=%.2f (choice-s1 diff mean=%+.2f)"
        % (np.mean(chosen_na), np.mean(s1_na), np.mean(chosen_na) - np.mean(s1_na)))
    chosen_na, s1_na = np.array(chosen_na, float), np.array(s1_na, float)
    out("confmax8 vs s1 の paired n_ans 差: d(mean)=%+.3f, t=%.2f, p=%.3g"
        % ((chosen_na - s1_na).mean(),
           stats.ttest_1samp(chosen_na - s1_na, 0.0).statistic,
           stats.ttest_1samp(chosen_na - s1_na, 0.0).pvalue))

    out("\n--- (d) maj8 rep tok conf の同点構造 ---")
    reps = np.array([max(s["p_ans"] for s in [x for x in r["samples"][:8]
                                             if x["pred"] is not None and x["p_ans"] is not None
                                             and x["pred"] == majority_first(r["samples"], 8)])
                     for r in recs], float)
    rep_corr = np.array([majority_first(r["samples"], 8) == r["gold"] for r in recs], bool)
    out("rep conf: mean=%.6f uniq(round 6dp)=%d uniq(round 4dp)=%d n=%d"
        % (reps.mean(), len(set(np.round(reps, 6).tolist())),
           len(set(np.round(reps, 4).tolist())), len(reps)))
    out("rep conf >= 0.9999: %d / %d  /  正解 rep conf mean=%.6f  誤答 rep conf mean=%.6f"
        % (int((reps >= 0.9999).sum()), len(reps), reps[rep_corr].mean(),
           reps[~rep_corr].mean()))

    out("\n--- (e) maj first-4 vs first-8 の flip ---")
    flips = []
    for r in recs:
        sub = r["samples"]
        p4 = majority_first(sub, 4) == r["gold"]
        p8 = majority_first(sub, 8) == r["gold"]
        flips.append((p4, p8))
    f4only = sum(1 for a, b in flips if a and not b)
    f8only = sum(1 for a, b in flips if b and not a)
    out("first-4 のみ正解=%d / first-8 のみ正解=%d / 両方 or 両誤=%d"
        % (f4only, f8only, len(flips) - f4only - f8only))

    with open(OUT, "w", encoding="utf-8") as fp:
        fp.write("\n".join(buf) + "\n")
    os._exit(0)


if __name__ == "__main__":
    main()
