# -*- coding: utf-8 -*-
"""e5_60ep_full.py — 60 epoch での 7 seed 完全比較（不足分だけ実行する再開可能版）

既存:
  e5_stability_check.csv  : frozen_ffn, epochs=60, seeds 0-4
  e5_identity_60ep.csv    : frozen_identity, seeds 0-2
  e5_free_60ep.csv        : free, seeds 0-4
不足:
  frozen_ffn 5,6 / frozen_identity 3-6 / free 5,6 / sidecar 0-6

出力: e5_60ep_all.csv（逐次保存）, e5_60ep_analysis.json
"""
import os, json, time
import numpy as np
import pandas as pd
from e5_dependency_task import run

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=16, anchor_vals=(0, 1, 2, 3), d=16, epochs=60)
SEEDS = list(range(7))
ARMS = ["frozen_ffn", "frozen_identity", "free", "sidecar"]
OUT = os.path.join(HERE, "e5_60ep_all.csv")
LAMS = [0.03, 0.05, 0.08, 0.15, 0.30]

# --- 既存結果を集める ---
rows = []
st = pd.read_csv(os.path.join(HERE, "e5_stability_check.csv"))
for _, r in st[st.epochs == 60].iterrows():
    d = r.to_dict(); d["arm"] = "frozen_ffn"; rows.append(d)
for fn, arm in [("e5_identity_60ep.csv", "frozen_identity"), ("e5_free_60ep.csv", "free")]:
    d = pd.read_csv(os.path.join(HERE, fn))
    d["arm"] = arm
    rows.extend(d.to_dict("records"))

have = {(r["arm"], int(r["seed"])) for r in rows}
print(f"既存 {len(have)} 件: {sorted(have)}")

todo = [(a, s) for a in ARMS for s in SEEDS if (a, s) not in have]
print(f"追加実行 {len(todo)} 件")

t0 = time.time()
for i, (arm, s) in enumerate(todo, 1):
    r = run(arm, s, **CFG)
    r["arm"] = arm
    rows.append(r)
    pd.DataFrame(rows).to_csv(OUT, index=False)      # 逐次保存（中断に強い）
    print(f"  [{i}/{len(todo)}] {arm:16s} s{s} | CE {r['ce_all']:.4f} "
          f"| FFN {r['ffn_cost']:.3f} | acc {r['acc_all']:.4f} ({time.time()-t0:.0f}s)", flush=True)

df = pd.DataFrame(rows)
cols = ["arm", "seed", "ce_all", "acc_all", "acc_anchor", "acc_copy", "acc_dep",
        "ffn_cost", "id_rate_anchor"]
df = df[df.arm.isin(ARMS)].reindex(columns=cols)
df["obj015"] = df["ce_all"] + 0.15 * df["ffn_cost"]
df = df.sort_values(["arm", "seed"]).reset_index(drop=True)
df.to_csv(OUT, index=False)

print("\n=== 60 epoch・7 seed の完全比較 ===")
print(f"{'arm':16s} {'CE':>16s} {'FFN':>14s} {'obj(λ=.15)':>16s} {'acc':>16s} {'acc anchor':>16s}")
for a in ARMS:
    d = df[df.arm == a]
    print(f"{a:16s} {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f}  "
          f"{d['obj015'].mean():.4f}±{d['obj015'].std():.4f}  "
          f"{d['acc_all'].mean():.4f}±{d['acc_all'].std():.4f}  "
          f"{d['acc_anchor'].mean():.4f}±{d['acc_anchor'].std():.4f}")

piv = df.pivot_table(index="seed", columns="arm", values=["ce_all", "ffn_cost", "obj015", "acc_all"])

print("\n=== seed 対応差（各アーム − frozen_ffn、7 seeds） ===")
res = {}
for a in ["free", "sidecar"]:
    line = f" {a:8s}"
    for k in ("obj015", "ce_all", "ffn_cost", "acc_all"):
        d = (piv[k][a] - piv[k]["frozen_ffn"]).dropna()
        m, sd = d.mean(), d.std(ddof=1)
        t = m / (sd / np.sqrt(len(d)))
        rng = np.random.default_rng(0)
        boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(20000)])
        lo, hi = np.percentile(boot, [2.5, 97.5])
        wins = int((d < 0).sum()) if k != "acc_all" else int((d > 0).sum())
        res[f"{a}_{k}"] = {"mean": float(m), "sd": float(sd), "t": float(t),
                           "ci": [float(lo), float(hi)], "wins": wins, "n": int(len(d))}
        line += f" | {k} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {wins}/{len(d)}"
    print(line)

print("\n=== λ 感度（合成目的の平均、7 seeds） ===")
print(f"{'λ':>5s} " + "".join(f"{a:>15s}" for a in ARMS) + "   最良")
lam_tab = {}
for lam in LAMS:
    vals = {a: df[df.arm == a]["ce_all"].mean() + lam * df[df.arm == a]["ffn_cost"].mean() for a in ARMS}
    best = min(vals, key=vals.get)
    lam_tab[str(lam)] = {"vals": {k: float(v) for k, v in vals.items()}, "best": best}
    print(f"{lam:5.2f} " + "".join(f"{vals[a]:15.4f}" for a in ARMS) + f"   {best}")

ce_f = df[df.arm == "frozen_ffn"]["ce_all"].mean()
ce_r = df[df.arm == "free"]["ce_all"].mean()
ff_r = df[df.arm == "free"]["ffn_cost"].mean()
lam_star = (ce_r - ce_f) / (1.0 - ff_r)
print(f"\n free vs 全FFN の crossover λ* = {lam_star:.4f}（λ>λ* で free 優位）")

print("\n=== seed 別（free / sidecar） ===")
for a in ["free", "sidecar"]:
    d = df[df.arm == a]
    print(f" {a:8s} CE  " + " ".join(f"{x:.3f}" for x in d["ce_all"]))
    print(f" {'':8s} FFN " + " ".join(f"{x:.3f}" for x in d["ffn_cost"]))
    print(f" {'':8s} obj " + " ".join(f"{x:.3f}" for x in d["obj015"]))

json.dump({"summary": {a: {k: float(df[df.arm == a][k].mean()) for k in
                           ["ce_all", "ffn_cost", "obj015", "acc_all", "acc_anchor"]} for a in ARMS},
           "paired_vs_ffn": res, "lambda_sensitivity": lam_tab,
           "crossover_lambda": float(lam_star), "raw": rows},
          open(os.path.join(HERE, "e5_60ep_analysis.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e5_60ep_all.csv / e5_60ep_analysis.json")
