# -*- coding: utf-8 -*-
"""P15 probe: P14 の生データで「切り捨て＝答えなし」処理の効果を見る（使い捨て）

見るもの:
  1. ntok / n_ans / 打ち切り率 / 打ち切りと正解の関係
  2. p_full（生成全体の幾何平均）の判別力 — P14 は取得したが未解析
  3. 候補プールを「打ち切りでない」に限定したときの confmax / majority
  4. 桁数整合フィルタ（n_ans が gold 桁数と整合）の効果
出力: _p15_probe_out_utf8.txt
"""
import json
import os
import re
from collections import Counter

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = []


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def load(tag="p14"):
    recs, greedy = [], []
    with open(os.path.join(HERE, "%s_bestofn.jsonl" % tag), encoding="utf-8") as fp:
        for line in fp:
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            (greedy if r.get("round") == "greedy" else recs).append(r)
    return recs, greedy


def auroc(scores, labels):
    s = np.asarray(scores, float)
    y = np.asarray(labels, bool)
    ok = np.isfinite(s)
    s, y = s[ok], y[ok]
    pos, neg = s[y], s[~y]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    d = (pos[:, None] > neg[None, :]).sum() + 0.5 * (pos[:, None] == neg[None, :]).sum()
    return float(d / (len(pos) * len(neg)))


def main():
    recs, greedy = load()
    log("recs=%d greedy=%d" % (len(recs), len(greedy)))

    S = [s for r in recs for s in r["samples"]]
    log("\n[1] sample-level structure (n=%d)" % len(S))
    ntok = np.array([s["ntok"] for s in S], float)
    nans = np.array([s["n_ans"] for s in S], float)
    corr = np.array([bool(s["correct"]) for s in S])
    log("  ntok: mean=%.1f median=%.1f  ==96 (truncated): %d (%.3f)"
        % (ntok.mean(), np.median(ntok), int((ntok == 96).sum()), (ntok == 96).mean()))
    log("  n_ans: mean=%.2f median=%.1f min=%d max=%d"
        % (nans.mean(), np.median(nans), nans.min(), nans.max()))

    trunc = ntok >= 96
    log("\n  accuracy by truncation:")
    for name, m in [("truncated (ntok==96)", trunc), ("complete", ~trunc)]:
        if m.sum():
            log("    %-22s n=%-3d acc=%.4f  mean p_ans=%.4f  mean p_full=%s"
                % (name, int(m.sum()), corr[m].mean(), np.mean([S[i]["p_ans"] for i in np.where(m)[0]]),
                   "%.4f" % np.mean([S[i]["p_full"] for i in np.where(m)[0]
                                     if S[i]["p_full"] is not None])
                   if any(S[i]["p_full"] is not None for i in np.where(m)[0]) else "-"))

    log("\n  n_ans x truncation crosstab:")
    for lo, hi in [(1, 1), (2, 2), (3, 4), (5, 99)]:
        m = (nans >= lo) & (nans <= hi)
        if m.sum():
            log("    n_ans %d-%d: n=%-3d acc=%.4f  frac_trunc=%.3f  mean_p_ans=%.4f"
                % (lo, hi, int(m.sum()), corr[m].mean(), trunc[m].mean(),
                   np.mean([S[i]["p_ans"] for i in np.where(m)[0]])))

    # p_ans vs p_full の判別力（sample level, 320）
    log("\n[2] sample-level AUROC (n=%d, pos=%d)" % (len(S), int(corr.sum())))
    for name, key in [("p_ans", "p_ans"), ("p_full", "p_full")]:
        v = [s[key] if s[key] is not None else np.nan for s in S]
        log("  %-8s AUC=%.3f  (n_valid=%d)" % (name, auroc(v, corr),
                                               int(np.isfinite(np.asarray(v, float)).sum())))

    # 打ち切りを除いた sample-level AUROC
    keep = ~trunc
    for name, key in [("p_ans", "p_ans"), ("p_full", "p_full")]:
        v = [S[i][key] if S[i][key] is not None else np.nan for i in np.where(keep)[0]]
        y = corr[keep]
        log("  %-8s AUC=%.3f  (complete only, n=%d pos=%d)"
            % (name, auroc(v, y), int(keep.sum()), int(y.sum())))

    # ---- 選択規則の再計算 ----
    def confmax(sub, N, pool):
        cand = [(j, s) for j, s in enumerate(sub[:N])
                if s["p_ans"] is not None and s["pred"] is not None and pool(s)]
        if not cand:
            return None
        return max(cand, key=lambda t: (t[1]["p_ans"], -t[0]))[1]

    def confmax_pfull(sub, N, pool):
        cand = [(j, s) for j, s in enumerate(sub[:N])
                if s["p_full"] is not None and s["pred"] is not None and pool(s)]
        if not cand:
            return None
        return max(cand, key=lambda t: (t[1]["p_full"], -t[0]))[1]

    def majority(sub, N, pool):
        cand = [s for s in sub[:N] if s["pred"] is not None and pool(s)]
        if not cand:
            return None
        by = {}
        for s in cand:
            by.setdefault(s["pred"], []).append(s)
        best = None
        for pred, lst in by.items():
            key = (len(lst), max(x["p_ans"] for x in lst))
            if best is None or key > best[0]:
                best = (key, pred, lst)
        _, pred, lst = best
        return {"pred": pred, "n_pool": len(cand), "n_vote": len(lst),
                "share_pool": len(lst) / float(len(cand)),
                "share_nominal": len(lst) / float(N)}

    all_pool = lambda s: True                      # noqa: E731
    clean_pool = lambda s: s["ntok"] < 96          # 打ち切りを「答えなし」として除外
    dig_pool = lambda s: s["n_ans"] >= 3           # 桁数整合の粗い代理（gold は 5-6 桁）

    rounds = sorted(set(r["round"] for r in recs))
    P = len([r for r in recs if r["round"] == rounds[0]])
    R = len(rounds)

    def table(pool, label):
        acc = {}
        conf = {}
        cov = []
        for ri_idx, ri in enumerate(rounds):
            rec0 = [r for r in recs if r["round"] == ri]
            for i in range(P):
                sub = rec0[i]["samples"]
                g = rec0[i]["gold"]
                cm = confmax(sub, 8, pool)
                mj = majority(sub, 8, pool)
                cov.append(0 if (cm is None or mj is None) else 1)
                acc.setdefault("confmax8", []).append(np.nan if cm is None else float(cm["pred"] == g))
                conf.setdefault("confmax8", []).append(np.nan if cm is None else cm["p_ans"])
                acc.setdefault("maj8", []).append(np.nan if mj is None else float(mj["pred"] == g))
                conf.setdefault("maj8", []).append(np.nan if mj is None else mj["share_pool"])
        out = {"pool": label, "coverage": float(np.mean(cov))}
        for rule in ["confmax8", "maj8"]:
            a = np.asarray(acc[rule], float)
            c = np.asarray(conf[rule], float)
            ok = np.isfinite(a)
            out[rule] = {"n": int(ok.sum()), "acc": float(np.mean(a[ok])),
                         "conf": float(np.mean(c[ok])),
                         "gap": float(np.mean(c[ok]) - np.mean(a[ok]))}
        return out

    log("\n[3] N=8 rules under different candidate pools (pairs=%d)" % (R * P))
    rows = [table(all_pool, "all (P14 as-is)"),
            table(clean_pool, "drop truncated"),
            table(dig_pool, "n_ans>=3")]
    for r_ in rows:
        log("  %-18s cov=%.3f | confmax8 acc=%.4f conf=%.4f gap=%+.4f (n=%d)"
            % (r_["pool"], r_["coverage"], r_["confmax8"]["acc"], r_["confmax8"]["conf"],
               r_["confmax8"]["gap"], r_["confmax8"]["n"]))
        log("  %-18s           | maj8     acc=%.4f share=%.4f gap=%+.4f (n=%d)"
            % ("", r_["maj8"]["acc"], r_["maj8"]["conf"], r_["maj8"]["gap"], r_["maj8"]["n"]))

    # ---- 主要な対照: 打ち切り除外で confmax の AUROC は戻るか ----
    log("\n[4] confmax8 answer-level AUROC by pool")
    for pool, label in [(all_pool, "all"), (clean_pool, "drop trunc"), (dig_pool, "n_ans>=3")]:
        sc, y = [], []
        for ri in rounds:
            rec0 = [r for r in recs if r["round"] == ri]
            for i in range(P):
                cm = confmax(rec0[i]["samples"], 8, pool)
                if cm is None:
                    continue
                sc.append(cm["p_ans"])
                y.append(float(cm["pred"] == rec0[i]["gold"]))
        log("  %-12s AUC=%.3f (n=%d pos=%d)" % (label, auroc(sc, y), len(sc), int(sum(y))))

    # ---- p_full を選択に使う ----
    log("\n[5] confmax by p_full (mean logprob over whole generation)")
    for pool, label in [(all_pool, "all"), (clean_pool, "drop trunc")]:
        accs, confs = [], []
        for ri in rounds:
            rec0 = [r for r in recs if r["round"] == ri]
            for i in range(P):
                cm = confmax_pfull(rec0[i]["samples"], 8, pool)
                if cm is None:
                    continue
                accs.append(float(cm["pred"] == rec0[i]["gold"]))
                confs.append(cm["p_full"])
        log("  %-12s acc=%.4f  mean p_full=%.4f  AUC=%.3f (n=%d)"
            % (label, np.mean(accs), np.mean(confs), auroc(confs, accs), len(accs)))

    # ---- 多数決の票が打ち切りに汚染されているか ----
    log("\n[6] vote composition of maj8 (all pool)")
    tot, trunc_votes, trunc_win = 0, 0, 0
    for ri in rounds:
        rec0 = [r for r in recs if r["round"] == ri]
        for i in range(P):
            sub = rec0[i]["samples"][:8]
            cnt = Counter([s["pred"] for s in sub if s["pred"] is not None])
            tot += 1
            # 打ち切りサンプルの票が最多票に一致しているか
            tr = [s for s in sub if s["ntok"] >= 96 and s["pred"] is not None]
            trunc_votes += len(tr)
            if tr and cnt:
                top = cnt.most_common(1)[0][0]
                if any(s["pred"] == top for s in tr):
                    trunc_win += 1
    log("  pairs=%d  truncated votes=%d (%.3f of 8)  pairs where a truncated vote == top vote: %d (%.3f)"
        % (tot, trunc_votes, trunc_votes / (8.0 * tot), trunc_win, trunc_win / float(tot)))

    with open(os.path.join(HERE, "_p15_probe_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    os._exit(0)


if __name__ == "__main__":
    main()
