"""
H1: AR x ブロック拡散ハイブリッドにおける「不均一サイズ MoE」の交互作用（テストベッド）

文書 §3.0 の縮小版を回す。ただし 2 点、文書の設計に足りないものを足す:
  (1) コスト罰則 λ。文書 §3.2 の設計（総パラメータ一致・損失のみ）では
      不均一 MoE が「得をする理由」が存在しない。P2 の確定知見
      「律速は目的関数にコスト項 λ が無いこと」を踏まえ λ を要因に入れる。
  (2) 幅の掃引（凸性の測定）。P3b の一般則「不均一が報われる条件は
      非対称性 > 1 + 凸性比」を、サイズ軸で先に測る。

要因:
  b ∈ {1, 4, 16}            b=1 が AR（block-causal なので厳密に AR NLL に一致）
  arm:
    uni_k2   均一 8 expert (s=1.0) top-2        cost=2.0
    uni_k1   均一 8 expert (s=1.0) top-1        cost=1.0
    het_l0   不均一 top-2, λ=0
    het_l05  不均一 top-2, λ=0.05
    het_l15  不均一 top-2, λ=0.15
    uni_s05 / uni_s075 / uni_s15  幅の掃引（b=16 のみ）

主指標: 検証 ELBO（固定マスク・全アーム共通）。Δ_b = L_uni_k2(b) − L_het(b)。
"""
import argparse
import json
import os
import time

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))

V = 64
SEQ = 32
HARD_EVERY = 3      # t % 3 == 0 の位置が「難しい」（直前 2 トークン依存）
P_NOISE = 0.02      # 系列に混ぜるノイズ（完全暗記を防ぐ）
MASK_ID = V
HET_SIZES = [0.5, 0.5, 0.75, 0.75, 1.25, 1.25, 1.5, 1.5]

ARM_SPEC = {
    "uni_k1":  dict(sizes=[1.0] * 8, k=1, lam=0.0),
    "uni_k2":  dict(sizes=[1.0] * 8, k=2, lam=0.0),
    "uni_k3":  dict(sizes=[1.0] * 8, k=3, lam=0.0),
    "het_l0":  dict(sizes=HET_SIZES, k=2, lam=0.0),
    "het_l01": dict(sizes=HET_SIZES, k=2, lam=0.01),
    "het_l03": dict(sizes=HET_SIZES, k=2, lam=0.03),
    "het_l08": dict(sizes=HET_SIZES, k=2, lam=0.08),
    "het_l002": dict(sizes=HET_SIZES, k=2, lam=0.002),
    "het_l005": dict(sizes=HET_SIZES, k=2, lam=0.005),
    "het_l02": dict(sizes=HET_SIZES, k=2, lam=0.02),
    "het_l05": dict(sizes=HET_SIZES, k=2, lam=0.05),
    "uni_s05": dict(sizes=[0.5] * 8, k=2, lam=0.0),
    "uni_s075": dict(sizes=[0.75] * 8, k=2, lam=0.0),
    "uni_s15": dict(sizes=[1.5] * 8, k=2, lam=0.0),
}


# ---------------------------------------------------------------- task
def make_task():
    g = torch.Generator().manual_seed(1234)
    T1 = torch.randint(0, V, (V,), generator=g)
    T2 = torch.randint(0, V, (V, V), generator=g)
    return T1, T2


@torch.no_grad()
def gen_batch(n, T1, T2, g):
    x = torch.empty(n, SEQ, dtype=torch.long)
    x[:, 0] = torch.randint(0, V, (n,), generator=g)
    x[:, 1] = torch.randint(0, V, (n,), generator=g)
    for t in range(2, SEQ):
        if t % HARD_EVERY == 0:
            nxt = T2[x[:, t - 1], x[:, t - 2]]
        else:
            nxt = T1[x[:, t - 1]]
        x[:, t] = nxt
    flip = torch.rand(n, SEQ, generator=g) < P_NOISE
    flip[:, :2] = False
    rnd = torch.randint(0, V, (n, SEQ), generator=g)
    return torch.where(flip, rnd, x)


# ---------------------------------------------------------------- model
class FFN(nn.Module):
    def __init__(self, d, h):
        super().__init__()
        self.fc1 = nn.Linear(d, h)
        self.fc2 = nn.Linear(h, d)

    def forward(self, x):
        return self.fc2(F.gelu(self.fc1(x)))


class MoE(nn.Module):
    """不均一サイズ expert。パディングして 1 本の einsum で回す（GPU 向け）。"""

    def __init__(self, d, d_ff, sizes, k, lam):
        super().__init__()
        self.E = len(sizes)
        self.k = k
        self.lam = lam
        hs = [max(8, int(round(s * d_ff))) for s in sizes]
        H = max(hs)
        self.hs = hs
        self.W1 = nn.Parameter(torch.empty(self.E, H, d))
        self.b1 = nn.Parameter(torch.zeros(self.E, H))
        self.W2 = nn.Parameter(torch.empty(self.E, d, H))
        self.b2 = nn.Parameter(torch.zeros(self.E, d))
        nn.init.normal_(self.W1, std=0.02)
        nn.init.normal_(self.W2, std=0.02)
        m1 = torch.zeros(self.E, H)
        for e, h in enumerate(hs):
            m1[e, :h] = 1.0
        self.register_buffer("m1", m1)
        self.register_buffer("sizes", torch.tensor(sizes, dtype=torch.float32))
        self.router = nn.Linear(d, self.E, bias=False)

    def forward(self, x):
        B, Ln, D = x.shape
        N = B * Ln
        fx = x.reshape(N, D)
        logits = self.router(x)
        probs = logits.softmax(-1)
        w, idx = logits.topk(self.k, dim=-1)
        w = w.softmax(-1)
        fw = w.reshape(N, self.k)
        fi = idx.reshape(N, self.k)

        h = torch.bmm(fx.unsqueeze(0).expand(self.E, -1, -1), self.W1.transpose(1, 2))
        h = h + self.b1.unsqueeze(1)
        h = F.gelu(h) * self.m1.unsqueeze(1)
        y = torch.bmm(h, self.W2.transpose(1, 2)) + self.b2.unsqueeze(1)   # (E,N,D)
        y = y.permute(1, 0, 2)                               # (N,E,D)

        gate = torch.zeros(N, self.E, device=x.device, dtype=fx.dtype)
        gate.scatter_add_(1, fi, fw)
        out = (gate.unsqueeze(-1) * y).sum(1)

        # 活性幅 = Σ_k s_{i_k}（重み w は FLOPs に効かない。expert は k 本とも走る）
        # topk の index は微分不能なので straight-through で勾配を通す:
        #   値は hard（真の FLOPs）、勾配は soft（router 確率 × サイズ）から。
        hard = self.sizes[fi].sum(-1).mean()
        soft = self.k * (probs * self.sizes).sum(-1).mean()
        cost = hard + (soft - soft.detach())
        top1 = fi[:, 0]
        frac = torch.bincount(top1, minlength=self.E).float() / top1.numel()
        pmix = probs.reshape(-1, self.E).mean(0)
        aux = self.E * (frac * pmix).sum()
        return out.view(B, Ln, D), cost, aux, fi, fw


class Block(nn.Module):
    def __init__(self, d, nh, d_ff, sizes, k, lam):
        super().__init__()
        self.ln1 = nn.LayerNorm(d)
        self.attn = nn.MultiheadAttention(d, nh, batch_first=True)
        self.ln2 = nn.LayerNorm(d)
        self.moe = MoE(d, d_ff, sizes, k, lam)

    def forward(self, x, attn_mask):
        h = self.ln1(x)
        a, _ = self.attn(h, h, h, attn_mask=attn_mask, need_weights=False)
        x = x + a
        y, cost, aux, fi, fw = self.moe(self.ln2(x))
        return x + y, cost, aux, fi, fw


class Net(nn.Module):
    def __init__(self, d, nh, nlay, d_ff, sizes, k, lam):
        super().__init__()
        self.emb = nn.Embedding(V + 1, d)
        self.pos = nn.Parameter(torch.zeros(SEQ, d))
        self.blocks = nn.ModuleList(Block(d, nh, d_ff, sizes, k, lam) for _ in range(nlay))
        self.ln_f = nn.LayerNorm(d)
        self.head = nn.Linear(d, V, bias=False)
        nn.init.normal_(self.pos, std=0.02)

    def forward(self, x, attn_mask):
        h = self.emb(x) + self.pos
        costs, auxs, fis, fws = [], [], [], []
        for blk in self.blocks:
            h, c, a, fi, fw = blk(h, attn_mask)
            costs.append(c)
            auxs.append(a)
            fis.append(fi)
            fws.append(fw)
        return self.head(self.ln_f(h)), torch.stack(costs).mean(), torch.stack(auxs).mean(), fis, fws


def block_mask(seq, b):
    """True = 参照可。(i,j) = query i が key j を見てよい。"""
    idx = torch.arange(seq)
    blk = idx // b
    same = blk[:, None] == blk[None, :]
    past = blk[None, :] < blk[:, None]
    return same | past


# ---------------------------------------------------------------- train / eval
def diff_loss(model, x, attn_mask, gen, t_min=0.05):
    B = x.shape[0]
    t = t_min + (1.0 - t_min) * torch.rand(B, 1, generator=gen)
    m = torch.rand(B, SEQ, generator=gen) < t
    m[:, -1] = True
    m, t = m.to(x.device), t.to(x.device)
    inp = torch.where(m, torch.full_like(x, MASK_ID), x)
    logits, cost, aux, _, _ = model(inp, attn_mask)
    ce = F.cross_entropy(logits.reshape(-1, V), x.reshape(-1), reduction="none").view(B, SEQ)
    loss = (ce * m.float() / t).mean()
    return loss, cost, aux


@torch.no_grad()
def evaluate(model, xs, attn_mask):
    """固定マスクで評価（全アーム共通のマスク → paired 比較）。"""
    g = torch.Generator().manual_seed(999)
    tot, n = 0.0, 0
    for _ in range(6):
        t = 0.1 + 0.9 * torch.rand(xs.shape[0], 1, generator=g)
        m = torch.rand(xs.shape[0], SEQ, generator=g) < t
        m[:, -1] = True
        m = m.to(xs.device)
        inp = torch.where(m, torch.full_like(xs, MASK_ID), xs)
        logits, _, _, _, _ = model(inp, attn_mask)
        ce = F.cross_entropy(logits.reshape(-1, V), xs.reshape(-1), reduction="none").view(-1, SEQ)
        tot += float((ce * m.float()).sum() / m.float().sum())
        n += 1
    return tot / n


@torch.no_grad()
def diagnose(model, xs, attn_mask, b):
    """マスク率ビン別・位置種別の平均選択幅（機構解析）。"""
    g = torch.Generator().manual_seed(4242)
    buckets = [(0.0, 0.25), (0.25, 0.5), (0.5, 0.75), (0.75, 1.01)]
    acc = {(i, k): [] for i in range(len(buckets)) for k in ("hard", "easy")}
    for _ in range(6):
        t = 0.1 + 0.9 * torch.rand(xs.shape[0], 1, generator=g)
        m = torch.rand(xs.shape[0], SEQ, generator=g) < t
        m[:, -1] = True
        m = m.to(xs.device)
        t = t.to(xs.device)
        inp = torch.where(m, torch.full_like(xs, MASK_ID), xs)
        _, _, _, fis, fws = model(inp, attn_mask)
        sizes = model.blocks[0].moe.sizes
        # 最終層で見る
        fi, fw = fis[-1].view(xs.shape[0], SEQ, -1), fws[-1].view(xs.shape[0], SEQ, -1)
        width = sizes[fi].sum(-1)                            # B,L 活性幅
        pos = torch.arange(SEQ)
        hard = torch.tensor([(t_ % HARD_EVERY == 0 and t_ >= 2) for t_ in range(SEQ)]).to(xs.device)
        for bi, (lo, hi) in enumerate(buckets):
            mb = m & (t >= lo) & (t < hi)
            for kind, sel_pos in (("hard", hard), ("easy", ~hard)):
                sel = mb & sel_pos.unsqueeze(0)
                if sel.any():
                    acc[(bi, kind)].append(float(width[sel].mean()))
    out = {}
    for (bi, kind), v in acc.items():
        if v:
            out[f"{buckets[bi][0]:.2f}-{buckets[bi][1]:.2f}|{kind}"] = float(np.mean(v))
    return out


def run(arm, b, seed, steps, d, nh, nlay, d_ff, bs, lr):
    spec = ARM_SPEC[arm]
    torch.manual_seed(seed)
    np.random.seed(seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    T1, T2 = make_task()
    T1, T2 = T1.to(dev), T2.to(dev)

    model = Net(d, nh, nlay, d_ff, spec["sizes"], spec["k"], spec["lam"]).to(dev)
    nparam = sum(p.numel() for p in model.parameters())
    # 実効パラメータ（パディングを除く）。全アームで一致するはず。
    nparam_moe = nlay * sum(2 * d * h for h in model.blocks[0].moe.hs)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda s: min(1.0, s / max(1, steps * 0.05)))
    am = ~block_mask(SEQ, b).to(dev)

    gen = torch.Generator(device="cpu").manual_seed(seed * 77 + 1)
    xv = gen_batch(512, T1.cpu(), T2.cpu(), torch.Generator().manual_seed(7)).to(dev)

    t0 = time.time()
    for step in range(steps):
        x = gen_batch(bs, T1.cpu(), T2.cpu(), gen).to(dev)
        loss, cost, aux = diff_loss(model, x, am, gen)
        total = loss + 0.01 * aux + spec["lam"] * cost
        opt.zero_grad(set_to_none=True)
        total.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()
    dt = time.time() - t0

    ev = evaluate(model, xv, am)
    diag = diagnose(model, xv, am, b)
    with torch.no_grad():
        xb = gen_batch(256, T1.cpu(), T2.cpu(), torch.Generator().manual_seed(11)).to(dev)
        g = torch.Generator().manual_seed(5)
        t = torch.full((256, 1), 0.5)
        m = (torch.rand(256, SEQ, generator=g) < t).to(dev)
        inp = torch.where(m, torch.full_like(xb, MASK_ID), xb)
        logits, cost_meas, _, fis, _ = model(inp, am)
        ce = F.cross_entropy(logits.reshape(-1, V), xb.reshape(-1), reduction="none").view(-1, SEQ)
        ce50 = float((ce * m.float()).sum() / m.float().sum())
        usage = torch.bincount(fis[0][:, 0], minlength=len(spec["sizes"])).float()
        usage = (usage / usage.sum()).tolist()

    return dict(arm=arm, b=b, seed=seed, steps=steps, val=ev, ce_t50=ce50,
                cost=float(cost_meas), params=nparam, params_moe=nparam_moe,
                usage=usage, sec=dt, diag=diag,
                sizes=spec["sizes"], k=spec["k"], lam=spec["lam"])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", default="uni_k2")
    ap.add_argument("--b", type=int, default=1)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--steps", type=int, default=3000)
    ap.add_argument("--d", type=int, default=128)
    ap.add_argument("--nh", type=int, default=4)
    ap.add_argument("--nlay", type=int, default=4)
    ap.add_argument("--d_ff", type=int, default=256)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--lr", type=float, default=3e-3)
    ap.add_argument("--out", default="h1_results.jsonl")
    a = ap.parse_args()

    r = run(a.arm, a.b, a.seed, a.steps, a.d, a.nh, a.nlay, a.d_ff, a.bs, a.lr)
    print(json.dumps({k: v for k, v in r.items() if k != "diag"}, ensure_ascii=False))
    for kk, vv in r["diag"].items():
        print(f"    {kk:22s} {vv:.3f}")
    with open(os.path.join(HERE, a.out), "a", encoding="utf-8") as fp:
        fp.write(json.dumps(r, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
