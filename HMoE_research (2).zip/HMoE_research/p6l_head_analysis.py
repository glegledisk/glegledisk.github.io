# -*- coding: utf-8 -*-
"""p6l_head_analysis.py — 乖離はどれだけ「読み出しの形」をしているか（GPU 不要）

P6e で分かったこと: 最終層の乖離は 1.25 倍しか違わないのに、最大 logit の移動は 20 倍。
本解析はその乖離を **LM head の方向に分解**する。

  a1     = |<dh, ŵ_top1>| / ||dh||      top-1 方向との余弦（＝読み出し効率）
  frac1  = a1^2                          乖離エネルギーのうち top-1 方向の割合
  q10    = ||{<dh, ŵ_i>}|| / ||dh||      上位 10 本が張る部分空間への射影比
  frac10 = q10^2                         同・エネルギー割合
  invis  = 1 - frac10                    読み出しから見えない割合

注意: a1 は P6e の「Δmax/||dh||」の言い換え（独立な証拠ではない）。
新しいのは **エネルギー割合 frac1 / frac10 / invis**（乖離の何割が読み出しに乗っているか）。

出力: p6l_analysis.json / p6l_out_utf8.txt / p6l_head_proj.png
"""
import json
import math

import numpy as np

LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


def ttest(a, b):
    d = np.asarray(a, float) - np.asarray(b, float)
    n = d.size
    se = d.std(ddof=1) / math.sqrt(n)
    return float(d.mean()), float(se), float(d.mean() / se) if se > 0 else float("nan")


z = np.load("p6k_head_proj.npz", allow_pickle=True)
CONDS = ["base", "f6b8", "f6b8_rs", "f8b6", "f8b6_rs"]
OUT = {"n_tokens": int(z["base_nll"].size)}

log("tokens=%d   (npz に wnorm は保存されていない版。a1/q10 は保存済み)" % z["base_nll"].size)
log("")
log("=== 1. 水準 ===")
log("%-9s %9s %9s %9s %11s %10s %9s" %
    ("cond", "CE", "p_top1", "acc", "dlogit", "|dh|", "cos(dh,h)"))
tab = {}
for c in CONDS:
    p = z["%s_ptop1" % c].astype(float)
    y = z["%s_top1" % c].astype(float)
    tab[c] = dict(ce=float(z["%s_nll" % c].astype(float).mean()), p=float(p.mean()),
                  acc=float(y.mean()),
                  dlogit1=float(z["%s_dlogit" % c].astype(float).mean()),
                  dh=float(z["%s_dh_norm" % c].astype(float).mean()),
                  cos=float(z["%s_cos_dh" % c].astype(float).mean()))
    log("%-9s %9.5f %9.4f %9.4f %+11.5f %10.4f %+9.5f"
        % (c, tab[c]["ce"], tab[c]["p"], tab[c]["acc"], tab[c]["dlogit1"],
           tab[c]["dh"], tab[c]["cos"]))
OUT["levels"] = tab

log("")
log("=== 2. 乖離はどれだけ読み出しの形をしているか ===")
log("%-9s %10s %12s %10s %12s %12s" %
    ("cond", "a1", "frac1(%)", "q10", "frac10(%)", "invisible(%)"))
for c in CONDS[1:]:
    a1 = z["%s_a1" % c].astype(float)
    q10 = z["%s_q10" % c].astype(float)
    tab[c].update(a1=float(a1.mean()), frac1=float((a1 ** 2).mean()),
                  q10=float(q10.mean()), frac10=float((q10 ** 2).mean()))
    tab[c]["invis"] = 1.0 - tab[c]["frac10"]
    log("%-9s %10.4f %12.3f %10.4f %12.3f %12.2f"
        % (c, tab[c]["a1"], 100 * tab[c]["frac1"], tab[c]["q10"],
           100 * tab[c]["frac10"], 100 * tab[c]["invis"]))
OUT["shape"] = {c: {k: tab[c][k] for k in ("a1", "frac1", "q10", "frac10", "invis")}
                for c in CONDS[1:]}

log("")
log("=== 3. 位置の効果: f8b6 vs f6b8 ===")
for k, lab in (("dh_norm", "|dh|"), ("dlogit", "dlogit"), ("a1", "a1"), ("q10", "q10")):
    a = z["f8b6_%s" % k].astype(float)
    b = z["f6b8_%s" % k].astype(float)
    m, se, t = ttest(a, b)
    ratio = (a.mean() / b.mean()) if b.mean() != 0 else float("nan")
    log("  %-9s f8b6=%+10.5f  f6b8=%+10.5f  差 %+10.5f (t=%+8.2f)  比 %6.2f"
        % (lab, a.mean(), b.mean(), m, t, ratio))
    OUT.setdefault("pos_effect", {})[k] = dict(f8=float(a.mean()), f6=float(b.mean()),
                                               d=m, t=t, ratio=float(ratio))
for k, lab, fn in (("frac1", "frac1", lambda c: z["%s_a1" % c].astype(float) ** 2),
                   ("frac10", "frac10", lambda c: z["%s_q10" % c].astype(float) ** 2)):
    a, b = fn("f8b6"), fn("f6b8")
    m, se, t = ttest(a, b)
    log("  %-9s f8b6=%+10.5f  f6b8=%+10.5f  差 %+10.5f (t=%+8.2f)  比 %6.2f"
        % (lab, a.mean(), b.mean(), m, t, a.mean() / b.mean()))
    OUT.setdefault("pos_effect", {})[k] = dict(f8=float(a.mean()), f6=float(b.mean()),
                                               d=m, t=t, ratio=float(a.mean() / b.mean()))

log("")
log("=== 4. rescale の効果（質量を戻すと読み出し成分はどうなるか） ===")
for c, b in (("f6b8_rs", "f6b8"), ("f8b6_rs", "f8b6")):
    for k in ("dlogit", "a1", "q10"):
        a = z["%s_%s" % (c, k)].astype(float)
        bb = z["%s_%s" % (b, k)].astype(float)
        m, se, t = ttest(a, bb)
        log("  %-9s %-8s %+10.5f -> %+10.5f  (差 %+10.5f, t=%+7.2f)"
            % (c, k, bb.mean(), a.mean(), m, t))

log("")
log("=== 5. トークン単位: 読み出し成分が logit 変化を説明するか ===")
for c in CONDS[1:]:
    a1 = z["%s_a1" % c].astype(float)
    dh = z["%s_dh_norm" % c].astype(float)
    dl = z["%s_dlogit" % c].astype(float)
    log("  %-9s corr(a1, |dlogit|)=%+.3f  corr(|dh|, |dlogit|)=%+.3f"
        % (c, float(np.corrcoef(a1, np.abs(dl))[0, 1]),
           float(np.corrcoef(dh, np.abs(dl))[0, 1])))

with open("p6l_analysis.json", "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=2)
with open("p6l_out_utf8.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(LOG))

# ---------------------------------------------------------------- 図
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.3), dpi=140)
    cs = CONDS[1:]
    xs = np.arange(len(cs))
    f1 = [100 * tab[c]["frac1"] for c in cs]
    f10 = [100 * (tab[c]["frac10"] - tab[c]["frac1"]) for c in cs]
    ax[0].bar(xs, f1, 0.55, label="top-1 direction", color="C3")
    ax[0].bar(xs, f10, 0.55, bottom=f1, label="rest of top-10 span", color="C1")
    ax[0].set_xticks(xs)
    ax[0].set_xticklabels(cs, rotation=15)
    ax[0].set_ylabel("% of ||dh||^2 visible to the readout")
    ax[0].set_title("Only ~1% of the deviation reaches the readout - in every condition")
    ax[0].legend(fontsize=8)
    ax[0].grid(alpha=0.3, axis="y")

    # 右: 揺らぎの大きさは同じで、符号の揃い方だけが違う
    mean_d = [z["%s_dlogit" % c].astype(float).mean() for c in cs]
    abs_d = [np.abs(z["%s_dlogit" % c].astype(float)).mean() for c in cs]
    ax[1].bar(xs - 0.2, abs_d, 0.4, label="E|dlogit| (magnitude)", color="lightgray")
    ax[1].bar(xs + 0.2, mean_d, 0.4, label="E[dlogit] (systematic part)", color="C0")
    ax[1].axhline(0, color="k", lw=0.8)
    for x, m, a in zip(xs, mean_d, abs_d):
        ax[1].annotate("coh %+.2f" % (m / a), (x + 0.2, m), textcoords="offset points",
                       xytext=(0, 4 if m >= 0 else -12), ha="center", fontsize=8, color="C0")
    ax[1].set_xticks(xs)
    ax[1].set_xticklabels(cs, rotation=15)
    ax[1].set_ylabel("change in logit of base top-1")
    ax[1].set_title("Same fluctuation size, different sign coherence")
    ax[1].legend(fontsize=8)
    ax[1].grid(alpha=0.3, axis="y")
    fig.tight_layout()
    fig.savefig("p6l_head_proj.png")
    log("\nsaved p6l_head_proj.png")
except Exception as e:
    log("figure failed: %s" % e)
