#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX5 Step 4: 独立再計算（ax5_granularity_mech.py を import しない別経路）。

scipy.stats.ttest_rel 経路で Δ・se・t・p・Holm・MDE・件数・上位 1% 寄与率を作り直し、
npz の生配列から分割・決定・mean_k・校正・H1/H2/H3・Jensen fit・回帰を再構築して
ax5_granularity_mech.json と突合する。使い方: python _ax5_verify.py [tag]
"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats as scistats

HERE = os.path.dirname(os.path.abspath(__file__))
TAG = sys.argv[1] if len(sys.argv) > 1 else "ax5"
ALPHA = 0.05
N_LAYERS = 16
N_WIN = 48
LEN = 256
N_EVAL = LEN - 1
N_TOK = N_WIN * N_EVAL

ITEMS, MISMATCH = [], []


def chk(name, got, exp, rtol=1e-6, atol=1e-9):
    ITEMS.append(name)
    ok = False
    if isinstance(exp, (list, tuple)):
        ok = (list(np.asarray(got).ravel()) == list(np.asarray(exp).ravel()))
    elif isinstance(exp, bool) or isinstance(exp, str):
        ok = (got == exp)
    elif isinstance(exp, (int, np.integer)) and isinstance(got, (int, np.integer)):
        ok = (int(got) == int(exp))
    else:
        try:
            gf, ef = float(got), float(exp)
            if math.isnan(gf) and math.isnan(ef):
                ok = True
            else:
                ok = math.isclose(gf, ef, rel_tol=rtol, abs_tol=atol)
        except Exception:
            ok = False
    if not ok:
        MISMATCH.append((name, got, exp))


def rst(d):
    d = np.asarray(d, dtype=np.float64).ravel()
    n = d.size
    m = float(d.mean())
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    t, p = scistats.ttest_rel(d, np.zeros_like(d))
    tc975 = float(scistats.t.ppf(0.975, n - 1))
    tc95 = float(scistats.t.ppf(0.95, n - 1))
    wm = d.reshape(N_WIN, N_EVAL).mean(axis=1)
    sew = float(wm.std(ddof=1) / math.sqrt(N_WIN))
    srt = np.sort(np.abs(d))[::-1]
    k1 = max(1, int(math.ceil(0.01 * n)))
    return {"mean": m, "sd": sd, "se": se, "t": float(t), "p_two": float(p),
            "n": int(n), "df": int(n - 1), "mde": tc975 * se,
            "ci95": [m - tc975 * se, m + tc975 * se],
            "ci90": [m - tc95 * se, m + tc95 * se],
            "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
            "n_zero": int((d == 0).sum()), "median": float(np.median(d)),
            "min": float(d.min()), "max": float(d.max()),
            "se_win": sew,
            "top1_abs_share": float(srt[:k1].sum() / srt.sum())}


def holm_adj(pvals):
    ids = sorted(pvals, key=lambda k: pvals[k])
    out, run = {}, 0.0
    for i, k in enumerate(ids):
        run = max(run, (len(ids) - i) * pvals[k])
        out[k] = min(1.0, run)
    return out


def unit_targets(c8, c7, uid, n_unit):
    cnt = np.bincount(uid, minlength=n_unit).astype(np.float64)
    assert cnt.min() > 0
    a = np.stack([np.bincount(uid, weights=c8[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    b = np.stack([np.bincount(uid, weights=c7[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    return np.concatenate([a, b], axis=1)


def unit_decision(Y):
    n = Y.shape[0]
    cut = np.argmin(Y[:, N_LAYERS:], axis=1).astype(np.int8)
    Q = Y[:, :N_LAYERS].copy()
    Q[np.arange(n), cut] = -np.inf
    prot = np.argmax(Q, axis=1).astype(np.int8)
    return cut, prot


def length_stats(lens):
    lens = np.asarray(lens, dtype=np.float64)
    sd = float(lens.std())
    return {"n": int(lens.size), "sum": int(lens.sum()),
            "mean": float(lens.mean()), "median": float(np.median(lens)),
            "min": int(lens.min()), "max": int(lens.max()),
            "cv": float(sd / lens.mean()) if lens.mean() > 0 else float("nan"),
            "skew": float(((lens - lens.mean()) ** 3).mean() / (sd ** 3))
            if sd > 0 else 0.0,
            "p10": float(np.percentile(lens, 10)),
            "p90": float(np.percentile(lens, 90))}


def cmp_stats(name, s, rj):
    for f in ("mean", "sd", "se", "t", "p_two", "mde", "median",
              "se_win", "top1_abs_share"):
        if f in rj:
            chk("%s.%s" % (name, f), s[f], rj[f])
    for f in ("n", "df", "n_pos", "n_neg", "n_zero"):
        if f in rj:
            chk("%s.%s" % (name, f), s[f], rj[f])
    for f in ("min", "max"):
        if f in rj:
            chk("%s.%s" % (name, f), s[f], rj[f])
    for f in ("ci95", "ci90"):
        if f in rj:
            chk("%s.%s_lo" % (name, f), s[f][0], rj[f][0])
            chk("%s.%s_hi" % (name, f), s[f][1], rj[f][1])


def main():
    z = np.load(os.path.join(HERE, "%s_granularity_mech.npz" % TAG))
    with open(os.path.join(HERE, "%s_granularity_mech.json" % TAG),
              encoding="utf-8") as fp:
        J = json.load(fp)
    z3 = np.load(os.path.join(HERE, "ax3_transfer.npz"))
    z4 = np.load(os.path.join(HERE, "ax4_sentence_bound.npz"))

    n_tok = J["meta"]["n_tok"]
    chk("meta.n_tok", n_tok, N_TOK)
    chk("meta.n_arms", J["meta"]["n_arms"], 15)
    chk("meta.windows", J["meta"]["windows"], N_WIN)
    chk("meta.len", J["meta"]["len"], LEN)
    chk("npz.n_tok", z["nll_u7_rep"].size, N_TOK)

    c8 = z["c8"].astype(np.float64)
    c7 = z["c7"].astype(np.float64)
    chk("c8.shape", list(c8.shape), [N_LAYERS, N_TOK])
    chk("c7.shape", list(c7.shape), [N_LAYERS, N_TOK])

    # ---------------- C3: per-token / window / sentence decisions ----------------
    cut_tok = np.argmin(c7, axis=0).astype(np.int8)
    Q = c8.copy()
    Q[cut_tok, np.arange(N_TOK)] = -np.inf
    prot_tok = np.argmax(Q, axis=0).astype(np.int8)
    chk("C3.tok_cut", int(np.abs(cut_tok.astype(np.int16)
                                - z3["cut_tok_o"].astype(np.int16)).max()), 0)
    chk("C3.tok_prot", int(np.abs(prot_tok.astype(np.int16)
                                  - z3["prot_tok_o"].astype(np.int16)).max()), 0)
    uid_win = np.repeat(np.arange(N_WIN, dtype=np.int32), N_EVAL)
    cut_w, prot_w = unit_decision(unit_targets(c8, c7, uid_win, N_WIN))
    chk("C3.win_cut", int(np.abs(cut_w.astype(np.int16)
                                 - z3["cut_w_o"].astype(np.int16)).max()), 0)
    chk("C3.win_prot", int(np.abs(prot_w.astype(np.int16)
                                  - z3["prot_w_o"].astype(np.int16)).max()), 0)
    sent = z4["sent"].astype(np.int64)
    sent_lens = np.bincount(sent)
    chk("C3.sent_n", int(sent_lens.size), 340)
    cut_s, prot_s = unit_decision(unit_targets(c8, c7, sent, sent_lens.size))
    chk("C3.sent_cut", int(np.abs(cut_s.astype(np.int16)
                                  - z4["cut_s"].astype(np.int16)).max()), 0)
    chk("C3.sent_prot", int(np.abs(prot_s.astype(np.int16)
                                   - z4["prot_s"].astype(np.int16)).max()), 0)
    for k, v in J["calib"]["C3"].items():
        chk("C3.json." + k, int(v), 0)
    chk("C3.npz.sent_cut", int((z["cut_sent340"] != cut_s).sum()), 0)
    chk("C3.npz.sent_prot", int((z["prot_sent340"] != prot_s).sum()), 0)

    # ---------------- C2: partitions rebuilt from lens ----------------
    part_names = sorted(k[4:] for k in z.files if k.startswith("uid_"))
    chk("C2.n_parts", len(part_names), 14)
    lens_map = {}
    for nm in part_names:
        lens = z["lens_" + nm].astype(np.int64)
        uid = z["uid_" + nm].astype(np.int64)
        lens_map[nm] = lens
        rebuilt = np.repeat(np.arange(len(lens), dtype=np.int64), lens)
        chk("C2.uid_rebuild_" + nm, int((rebuilt != uid).sum()), 0)
        chk("C2.uid_bincount_" + nm,
            int(np.abs(np.bincount(uid) - lens).max()), 0)
        chk("C2.sum_" + nm, int(lens.sum()), N_TOK)
        chk("C2.min_" + nm, int(lens.min()), int(J["calib"]["C2"]["parts"][nm]
                                                 ["len_stats"]["min"]))
        st = length_stats(lens)
        for f, v in st.items():
            chk("C2.stats_%s_%s" % (nm, f), v,
                J["calib"]["C2"]["parts"][nm]["len_stats"][f])
        chk("C2.n_unit_" + nm, int(len(lens)),
            J["calib"]["C2"]["parts"][nm]["n_unit"])
        if nm in ("uni102", "uni181", "uni340", "uni630", "uni1224"):
            chk("C2.uniform_" + nm, int(lens.max() - lens.min()) <= 1, True)
    for nm in ("shift340", "shift340b"):
        chk("C2.multiset_" + nm,
            int((np.sort(lens_map[nm]) != np.sort(sent_lens)).sum()), 0)
        chk("C2.multiset_flag_" + nm,
            J["calib"]["C2"]["parts"][nm].get("multiset_eq_sent"), True)

    # per-window structure for the window-control arms
    def win_local(uid):
        return uid - uid.min()

    counts_sent = []
    for w in range(N_WIN):
        sw = sent[w * N_EVAL:(w + 1) * N_EVAL]
        lw = np.bincount(sw - sw.min())
        assert int(lw.min()) >= 1 and int(lw.sum()) == N_EVAL
        counts_sent.append(len(lw))
    chk("C2.sent_window_units", sum(counts_sent), 340)
    for nm in ("uni340w", "shift340w"):
        uid = z["uid_" + nm].astype(np.int64)
        for w in range(N_WIN):
            sw = uid[w * N_EVAL:(w + 1) * N_EVAL]
            loc = win_local(sw)
            lw = np.bincount(loc)
            assert int(lw.min()) >= 1 and int(lw.sum()) == N_EVAL
            if nm == "uni340w":
                chk("C2.uniw_units_w%02d" % w, int(len(lw)), counts_sent[w])
                chk("C2.uniw_flat_w%02d" % w, int(lw.max() - lw.min()) <= 1, True)
            else:
                sw_s = sent[w * N_EVAL:(w + 1) * N_EVAL]
                lws = np.bincount(sw_s - sw_s.min())
                chk("C2.shiftw_multiset_w%02d" % w,
                    int((np.sort(lw) != np.sort(lws)).sum()), 0)
    chk("C2.shiftw_flag",
        J["calib"]["C2"]["parts"]["shift340w"]
        .get("multiset_eq_sent_within_window"), True)

    # ---------------- decisions / C4 / C5 ----------------
    dec_names = sorted(k[4:] for k in z.files if k.startswith("cut_"))
    chk("dec.n", len(dec_names), 15)
    mean_k = {}
    for nm in dec_names:
        cut = z["cut_" + nm].astype(np.int64)
        prot = z["prot_" + nm].astype(np.int64)
        chk("C5.conf_" + nm, int((cut == prot).sum()),
            J["calib"]["C5"]["conflicts"][nm])
        chk("C5.cut_hist_" + nm,
            np.bincount(cut, minlength=N_LAYERS).tolist(),
            J["calib"]["C5"]["cut_hist"][nm])
        chk("C5.prot_hist_" + nm,
            np.bincount(prot, minlength=N_LAYERS).tolist(),
            J["calib"]["C5"]["prot_hist"][nm])
        if nm == "tok_randmatch":
            order = np.lexsort((prot_tok, cut_tok))
            order2 = np.lexsort((prot, cut))
            chk("dec.tokmatch_multiset",
                int((np.stack([cut_tok[order], prot_tok[order]], 1)
                     != np.stack([cut[order2], prot[order2]], 1)).sum()), 0)
            km = np.full((N_LAYERS, N_TOK), 7, dtype=np.int16)
            km[cut, np.arange(N_TOK)] = 6
            km[prot, np.arange(N_TOK)] = 8
        else:
            uid = z["uid_" + nm].astype(np.int64)
            n_unit = int(lens_map[nm].size)
            cc, pp = unit_decision(unit_targets(c8, c7, uid, n_unit))
            chk("dec.cut_" + nm, int((cc != cut).sum()), 0)
            chk("dec.prot_" + nm, int((pp != prot).sum()), 0)
            # decision values are per unit; compare after expansion
            km = np.full((N_LAYERS, N_TOK), 7, dtype=np.int16)
            km[cut[uid], np.arange(N_TOK)] = 6
            km[prot[uid], np.arange(N_TOK)] = 8
        mk = float(km.mean())
        mean_k[nm] = mk
        chk("C4.mean_k_" + nm, mk, J["calib"]["C4"]["mean_k"][nm])
        chk("C4.budget_cols_" + nm,
            int(np.abs(km.sum(axis=0) - 112).max()), 0)
        chk("C4.n6_" + nm, int((km == 6).sum()), N_TOK)
        chk("C4.n8_" + nm, int((km == 8).sum()), N_TOK)
    chk("C4.n_keys", len(J["calib"]["C4"]["mean_k"]), 15)
    chk("C4.n_bad", J["calib"]["C4"]["n_bad"], 0)
    for nm, mk in mean_k.items():
        chk("C4.abs7_" + nm, abs(mk - 7.0) <= 1e-9, True)

    # ---------------- C1 ----------------
    N = {k[4:]: z[k].astype(np.float64) for k in z.files if k.startswith("nll_")}
    A = {k[5:]: z[k].astype(np.float64) for k in z.files if k.startswith("acc1_")}
    u7 = N["u7_rep"]
    nll_ax4_u7 = z4["nll_u7_rep"].astype(np.float64)
    nll_ax4_sent = z4["nll_sent_oracle"].astype(np.float64)
    nll_ax4_rand = z4["nll_sent_random"].astype(np.float64)
    nll_ax3_win = z3["nll_lay_win_oracle"].astype(np.float64)
    nll_ax3_tok = z3["nll_lay_tok_oracle"].astype(np.float64)
    chk("C1.u7_maxdiff", float(np.abs(N["u7_rep"] - nll_ax4_u7).max()),
        J["calib"]["C1"]["u7_maxdiff"])
    chk("C1.sent_maxdiff",
        float(np.abs(N["sent340_rep"] - nll_ax4_sent).max()),
        J["calib"]["C1"]["sent_maxdiff"])
    tier = "A" if (np.abs(N["u7_rep"] - nll_ax4_u7).max() == 0.0
                   and np.abs(N["sent340_rep"] - nll_ax4_sent).max() == 0.0) \
        else "FAIL"
    chk("C1.tier", J["calib"]["C1"]["tier"], tier)

    # ---------------- results / gains ----------------
    chk("results.n", len(J["results"]), 15)
    for nm, r in J["results"].items():
        chk("arm.ce_" + nm, float(N[nm].mean()), r["ce"])
        chk("arm.delta_" + nm, float((N[nm] - u7).mean()), r["delta_vs_u7"])
        chk("arm.top1_" + nm, float(A[nm].mean()), r["top1"])
        chk("arm.mean_k_" + nm, mean_k[nm] if nm in mean_k else 7.0,
            r["mean_k"])

    nll_map = dict(N)
    nll_map["win48"] = nll_ax3_win
    nll_map["tok12240"] = nll_ax3_tok
    nll_map["sent_random"] = nll_ax4_rand
    gains = {}
    for nm in ("u7_rep", "sent340_rep", "global1", "uni102", "uni181",
               "uni340", "uni630", "uni1224", "shift340", "shift340b",
               "lognorm340", "alt340", "uni340w", "shift340w",
               "tok_randmatch", "win48", "tok12240", "sent_random"):
        gains[nm] = rst(u7 - nll_map[nm])
        cmp_stats("gain." + nm, gains[nm], J["exploratory"]["gains"][nm])
    chk("gains.n_keys", len(J["exploratory"]["gains"]), 18)

    curve = {"global1": gains["global1"]["mean"],
             "win48": gains["win48"]["mean"],
             "uni102": gains["uni102"]["mean"],
             "uni181": gains["uni181"]["mean"],
             "uni340": gains["uni340"]["mean"],
             "uni630": gains["uni630"]["mean"],
             "uni1224": gains["uni1224"]["mean"],
             "sent340": gains["sent340_rep"]["mean"],
             "shift340": gains["shift340"]["mean"],
             "lognorm340": gains["lognorm340"]["mean"],
             "alt340": gains["alt340"]["mean"],
             "tok12240": gains["tok12240"]["mean"]}
    for k, v in J["exploratory"]["granularity_curve"].items():
        chk("curve." + k, float(v), curve[k])
    wc = J["exploratory"]["window_controls"]
    chk("wc.sent340", wc["sent340"], curve["sent340"])
    chk("wc.uni340w", wc["uni340w"], gains["uni340w"]["mean"])
    chk("wc.shift340w", wc["shift340w"], gains["shift340w"]["mean"])

    # ---------------- confirmatory H1 / H2 ----------------
    d1 = N["uni340"] - N["sent340_rep"]
    d2 = N["shift340"] - N["sent340_rep"]
    s1, s2 = rst(d1), rst(d2)
    cmp_stats("H1", s1, J["confirmatory"]["H1_uniform_minus_sent"])
    cmp_stats("H2", s2, J["confirmatory"]["H2_sent_minus_shift"])
    # estimation identity: G_uni - G_sent == nll_sent - nll_uni
    chk("H1.identity",
        float((N["uni340"] - nll_ax4_sent).mean()), s1["mean"])
    chk("H2.identity",
        float((N["shift340"] - nll_ax4_sent).mean()), s2["mean"])
    ph = holm_adj({"H1": s1["p_two"], "H2": s2["p_two"]})
    for k, v in ph.items():
        chk("holm." + k, v, J["confirmatory"]["holm"][k])
    rej = {k: bool(ph[k] < ALPHA) for k in ph}
    case = ("A" if (rej["H1"] and rej["H2"]) else
            "B" if (rej["H1"] and not rej["H2"]) else
            "C" if (not rej["H1"] and rej["H2"]) else "D")
    chk("case", J["confirmatory"]["case"], case)
    for k, v in J["confirmatory"]["reject"].items():
        chk("reject." + k, bool(v), rej[k])

    # ---------------- H3 ----------------
    uni_ns = [48, 102, 181, 340, 630, 1224]
    uni_arms = ["win48", "uni102", "uni181", "uni340", "uni630", "uni1224"]
    w = np.log(np.array(uni_ns, dtype=np.float64))
    w = w - w.mean()
    chk("H3.weights_sum", float(w.sum()), 0.0, atol=1e-12)
    chk("H3.weights_npz", int(np.abs(z["h3_weights"].astype(np.float64)
                                    - w).max() > 1e-12), 0)
    d3 = np.zeros(N_TOK, dtype=np.float64)
    for wk, nm in zip(w, uni_arms):
        d3 -= wk * nll_map[nm]
    s3 = rst(d3)
    h3 = J["manipulation_check_H3"]
    for f in ("mean", "se", "t", "p_two", "mde"):
        chk("H3." + f, s3[f], h3[f])
    chk("H3.ci95_lo", s3["ci95"][0], h3["ci95"][0])
    chk("H3.ci95_hi", s3["ci95"][1], h3["ci95"][1])
    chk("H3.reject", bool(s3["p_two"] < ALPHA), h3["reject"])
    chk("H3.weights", w.tolist(), h3["weights"])

    # ---------------- C7 ----------------
    s7 = rst(N["shift340"] - N["shift340b"])
    c7j = J["calib"]["C7"]
    for f in ("mean", "se", "t", "p_two", "mde"):
        chk("C7." + f, s7[f], c7j[f])
    chk("C7.flag", bool(abs(s7["mean"]) > 0.5 * abs(s2["mean"])),
        c7j["flag_partition_noise"])

    # ---------------- C6 3-point control ----------------
    c6 = J["calib"]["C6"]
    chk("C6.random_gain", float((u7 - nll_ax4_rand).mean()), c6["random_gain"])
    chk("C6.oracle_gain", float((u7 - nll_ax4_sent).mean()), c6["oracle_gain"])
    chk("C6.random_le_oracle",
        bool((u7 - nll_ax4_rand).mean() <= (u7 - nll_ax4_sent).mean()),
        c6["random_le_oracle"])
    rand_p = rst(u7 - nll_ax4_rand)["p_two"]

    # ---------------- exploratory decomposition ----------------
    decomp = {
        "G_uniform_minus_shift": N["shift340"] - N["uni340"],
        "G_uniform_minus_lognorm": N["lognorm340"] - N["uni340"],
        "G_uniform_minus_alt": N["alt340"] - N["uni340"],
        "G_global1": u7 - N["global1"],
        "G_specific_48": N["global1"] - nll_ax3_win,
        "G_specific_340": N["global1"] - N["sent340_rep"],
        "G_specific_tok": N["global1"] - nll_ax3_tok,
        "G_tok_randmatch": u7 - N["tok_randmatch"],
        "G_assignment_tok": N["tok_randmatch"] - nll_ax3_tok,
        "G_global1_minus_win48": nll_ax3_win - N["global1"],
        "G_uniformw_minus_sent": N["uni340w"] - N["sent340_rep"],
        "G_sent_minus_shiftw": N["shift340w"] - N["sent340_rep"],
        "G_uniformw_minus_shiftw": N["shift340w"] - N["uni340w"],
        "G_shift_global_minus_window": N["shift340"] - N["shift340w"],
        "G_uni_global_minus_window": N["uni340"] - N["uni340w"]}
    for k, d in decomp.items():
        cmp_stats("decomp." + k, rst(d), J["exploratory"]["decomposition"][k])
    chk("decomp.n_keys", len(J["exploratory"]["decomposition"]), 15)

    # ---------------- Jensen fit ----------------
    L_uni = np.array([N_TOK / n for n in uni_ns], dtype=np.float64)
    y_uni = np.array([gains[nm]["mean"] for nm in uni_arms], dtype=np.float64)
    X = np.stack([np.ones_like(L_uni), np.log(L_uni), np.log(L_uni) ** 2], 1)
    coef, *_ = np.linalg.lstsq(X, y_uni, rcond=None)
    y_hat = X @ coef
    r2 = 1.0 - float(((y_uni - y_hat) ** 2).sum()
                     / ((y_uni - y_uni.mean()) ** 2).sum())
    jens = J["exploratory"]["jensen"]
    for i, c in enumerate(coef):
        chk("jensen.coef_%d" % i, coef[i], jens["coef"][i], atol=1e-10)
    chk("jensen.r2", r2, jens["r2_uniform"])
    for pt in jens["uniform_points"]:
        nn = pt["N"]
        chk("jensen.pt_L_%d" % nn, N_TOK / nn, pt["L"])
        chk("jensen.pt_G_%d" % nn, gains["win48" if nn == 48 else "uni%d" % nn]
            ["mean"], pt["G"])
    for nm in ("sent340", "shift340", "shift340b", "lognorm340", "alt340",
               "uni340w", "shift340w", "tok12240"):
        lens = lens_map[nm].astype(np.float64)
        zz = np.log(lens)
        pred = float(np.mean(coef[0] + coef[1] * zz + coef[2] * zz * zz))
        obs = float(gains["sent340_rep" if nm == "sent340" else nm]["mean"])
        chk("jensen.pred_" + nm, pred, jens[nm]["pred"])
        chk("jensen.obs_" + nm, obs, jens[nm]["obs"])
        chk("jensen.resid_" + nm, obs - pred, jens[nm]["resid"])

    # ---------------- descriptive regression ----------------
    reg_arms = [("global1", 1, 0.0), ("win48", 48, 0.0)]
    for n in uni_ns:
        if n == 48:
            continue
        lens = lens_map["uni%d" % n].astype(np.float64)
        reg_arms.append(("uni%d" % n, n, float(lens.std() / lens.mean())))
    for nm in ("shift340", "shift340b", "lognorm340", "alt340",
               "uni340w", "shift340w"):
        lens = lens_map[nm].astype(np.float64)
        reg_arms.append((nm, 340, float(lens.std() / lens.mean())))
    reg_arms.append(("tok12240", 12240, 0.0))
    Xr = np.array([[1.0, math.log(n), cv] for _, n, cv in reg_arms])
    yr = np.array([gains[nm]["mean"] for nm, _, _ in reg_arms])
    beta, *_ = np.linalg.lstsq(Xr, yr, rcond=None)
    yh = Xr @ beta
    r2r = 1.0 - float(((yr - yh) ** 2).sum() / ((yr - yr.mean()) ** 2).sum())
    loo = []
    for i in range(len(yr)):
        m = np.ones(len(yr), dtype=bool)
        m[i] = False
        b_i, *_ = np.linalg.lstsq(Xr[m], yr[m], rcond=None)
        loo.append(float(yr[i] - Xr[i] @ b_i))
    loo = np.array(loo)
    r2_loo = 1.0 - float((loo ** 2).sum() / ((yr - yr.mean()) ** 2).sum())
    pred_sent = float(np.array([1.0, math.log(340),
                                float(sent_lens.std() / sent_lens.mean())]) @ beta)
    reg = J["exploratory"]["regression"]
    chk("reg.arms", reg["arms"], [nm for nm, _, _ in reg_arms])
    for i, b in enumerate(beta):
        chk("reg.beta_%d" % i, b, reg["beta"][i], atol=1e-10)
    chk("reg.r2", r2r, reg["r2"])
    chk("reg.r2_loo", r2_loo, reg["r2_loo"])
    chk("reg.pred_sent", pred_sent, reg["pred_sent340"])
    chk("reg.resid_sent", float(gains["sent340_rep"]["mean"]) - pred_sent,
        reg["resid_sent340"])

    # ---------------- agreement / Jensen gap (descriptive) ----------------
    agree = J["exploratory"]["agreement"]
    for nm in ("global1", "win48", "uni102", "uni181", "uni340", "uni630",
               "uni1224", "sent340", "shift340", "shift340b", "lognorm340",
               "alt340", "uni340w", "shift340w", "tok12240"):
        if nm == "win48":
            uid = uid_win
        elif nm == "sent340":
            uid = sent
        else:
            uid = z["uid_" + nm].astype(np.int64)
        if nm == "win48":
            cut, prot = cut_w, prot_w
        elif nm == "tok12240":
            cut, prot = cut_tok, prot_tok
        else:
            cut = z["cut_" + nm].astype(np.int64)
            prot = z["prot_" + nm].astype(np.int64)
        chk("agree.cut_" + nm, float((cut[uid] == cut_tok).mean()),
            agree[nm]["agree_cut"])
        chk("agree.prot_" + nm, float((prot[uid] == prot_tok).mean()),
            agree[nm]["agree_prot"])
        chk("agree.both_" + nm,
            float(((cut[uid] == cut_tok) & (prot[uid] == prot_tok)).mean()),
            agree[nm]["agree_both"])

    jgap = J["exploratory"]["jensen_gap_descriptive"]
    per_c7 = float(c7[cut_tok, np.arange(N_TOK)].mean())
    per_c8 = float(c8[prot_tok, np.arange(N_TOK)].mean())
    for nm in ("global1", "win48", "uni102", "uni181", "uni340", "uni630",
               "uni1224", "sent340", "shift340", "shift340b", "lognorm340",
               "alt340", "uni340w", "shift340w"):
        if nm == "win48":
            uid = uid_win
        elif nm == "sent340":
            uid = sent
        else:
            uid = z["uid_" + nm].astype(np.int64)
        if nm == "win48":
            cut, prot = cut_w, prot_w
        else:
            cut = z["cut_" + nm].astype(np.int64)
            prot = z["prot_" + nm].astype(np.int64)
        uc7 = float(c7[cut[uid], np.arange(N_TOK)].mean())
        uc8 = float(c8[prot[uid], np.arange(N_TOK)].mean())
        chk("jgap.cut_" + nm, uc7 - per_c7, jgap[nm]["cut_gap"])
        chk("jgap.prot_" + nm, uc8 - per_c8, jgap[nm]["prot_gap"])
        chk("jgap.total_" + nm, (uc7 - per_c7) + (uc8 - per_c8),
            jgap[nm]["total"])

    # ---------------- text ----------------
    lines = ["AX5 Step 4 verify (tag=%s)" % TAG,
             "items=%d  mismatches=%d" % (len(ITEMS), len(MISMATCH))]
    lines.append("")
    lines.append("C1 u7_maxdiff %.1f  sent_maxdiff %.1f  tier %s"
                 % (J["calib"]["C1"]["u7_maxdiff"],
                    J["calib"]["C1"]["sent_maxdiff"],
                    J["calib"]["C1"]["tier"]))
    lines.append("C4 n_bad %d  mean_k range [%.9f, %.9f]"
                 % (J["calib"]["C4"]["n_bad"],
                    min(mean_k.values()), max(mean_k.values())))
    lines.append("C2 parts %d  (window controls: sent=%d units)"
                 % (len(part_names), sum(counts_sent)))
    lines.append("H1 %+.8f  se %.8f  t %+.4f  p %.6g  holm %.6g"
                 % (s1["mean"], s1["se"], s1["t"], s1["p_two"], ph["H1"]))
    lines.append("H2 %+.8f  se %.8f  t %+.4f  p %.6g  holm %.6g"
                 % (s2["mean"], s2["se"], s2["t"], s2["p_two"], ph["H2"]))
    lines.append("case %s" % case)
    lines.append("H3 %+.8f  se %.8f  t %+.4f  p %.6g  reject %s"
                 % (s3["mean"], s3["se"], s3["t"], s3["p_two"],
                    bool(s3["p_two"] < ALPHA)))
    lines.append("C7 shift340 - shift340b %+.8f  flag %s"
                 % (s7["mean"], c7j["flag_partition_noise"]))
    lines.append("C6 uniform 0 / random %+.8f (p %.4f) / oracle %+.8f"
                 % (float((u7 - nll_ax4_rand).mean()), rand_p,
                    float((u7 - nll_ax4_sent).mean())))
    for nm, got, exp in MISMATCH[:40]:
        lines.append("  MISMATCH %s: got=%r exp=%r" % (nm, got, exp))
    txt = "\n".join(lines)
    print(txt)
    with open(os.path.join(HERE, "_ax5_verify_out_utf8.txt"), "w",
              encoding="utf-8") as fp:
        fp.write(txt + "\n")


if __name__ == "__main__":
    main()
