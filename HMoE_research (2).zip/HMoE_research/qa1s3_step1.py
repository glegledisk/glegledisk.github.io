# -*- coding: utf-8 -*-
"""QA1S3 Step 1: C2 の未選択キー補完と 3 点対照の情報量診断（学習 0 epoch / CPU のみ）.

設計書: `QA1S3課題設計書_未選択キーを既定gainで補完し3点対照の情報量を回復する_20261115.md`
        §2〜§5 / §8

本次の範囲（走行前に固定。結果を見て変更しない）
  - **新規学習は 1 本も行わない**。既存 `qa1s2_metrics.json` の 21 run を再解析し、
    学習 0 epoch の dry-run で gain 校正と方策診断だけを測る。確認的 `Delta_iv` は再計算しない。
  - 案 B: `gl_full = {(l,i): gl.get((l,i), 1.0) for l in range(L) for i in range(E)}`。
    `a1_activation_ffn.py` L92 の `self.gain = 1.0` と L132 のフォールバックにより
    順伝播の数値は 1 bit も変わらないことを 3 経路で検算する。
  - C5 再定義 P1〜P6（設計書 §3）を dry-run と既存 21 run の双方へ適用する。
  - `random` の `ce_all` 発散について `gate` / `topi` 重複 / `gain` の由来を切り分ける。
    1 つに絞れない場合は `undetermined` と書く（設計書 §4）。

出力: qa1s3_step1_metrics.json / qa1s3_step1_gain.npz / qa1s3_step1.log
      （すべて UTF-8、json は allow_nan=False）
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
import torch

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "simulation_hmoe_mmlu"))
sys.path.insert(0, str(HERE / "不均一MoE-Corpus"))

import a4_small_expert_act as A4          # noqa: E402
import q1_trace_routing as Q1              # noqa: E402
import qa1s2_policy as POL                 # noqa: E402
from a1_activation_ffn import ActMoE, per_expert_rms   # noqa: E402

TAG = "qa1s3_step1"
W_REF = (32, 32, 96, 96, 160, 160, 224, 224)
W_MID = (96, 96, 96, 96, 160, 160, 160, 160)
W_FLAT = (128,) * 8
ARMS = {"w_ref": W_REF, "w_mid": W_MID, "w_flat": W_FLAT}
ACTS = ["relu2"] * 8
SEEDS = tuple(range(7))
L, E, N_POS = 4, 8, 32
CAL_SEED, CAL_N = 999, 128
EVAL_SEED, EVAL_N, EVAL_BS = 777, 128, 128
DEFAULT_GAIN = 1.0          # a1_activation_ffn.py L92 の実装定数
KAPPA = 10.0                # 設計書 §3 P5
CE_LIMIT = KAPPA * math.log(17)
RNG_SEED_OFFSET = 977
C5_POLICIES = ("learned", "uniform", "random", "oracle")
FULL_KEYS = [(l, i) for l in range(L) for i in range(E)]


class DiagPolicyActMoE(POL.PolicyActMoE):
    """_select の返り値を記録するだけの診断用サブクラス。forward は親のまま。"""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.gate_log = []

    def _select(self, logits, B, T):
        topi, gate = super()._select(logits, B, T)
        self.gate_log.append({
            "gate_max": float(gate.detach().max().cpu()),
            "gate_min": float(gate.detach().min().cpu()),
            "gate_nonfinite": int((~torch.isfinite(gate)).sum().cpu()),
            "topi_dup_rate": (float((topi[:, 0] == topi[:, 1]).float().mean().cpu())
                              if topi.shape[1] >= 2 else 0.0),
            "topi_max": int(topi.detach().max().cpu()),
            "topi_min": int(topi.detach().min().cpu()),
        })
        return topi, gate


def gain_for(arm: str, seed: int) -> dict:
    """a4_small_expert_act.run_one の gain=matched 分岐と同一手順で gl を再計算する。"""
    torch.manual_seed(seed)
    widths = ARMS[arm]
    cal_rng = np.random.default_rng(CAL_SEED)
    cal_seq, _ = Q1.make_trace_batch(cal_rng, CAL_N)
    ref = ActMoE(widths, "relu", seed=seed, act_i=["relu"] * len(widths))
    model = ActMoE(widths, "relu", seed=seed, act_i=ACTS)
    r_ref = per_expert_rms(ref, cal_seq)
    r_arm = per_expert_rms(model, cal_seq)
    gl = {k: r_ref[k] / max(r_arm.get(k, r_ref[k]), 1e-12) for k in r_ref}
    gl_full = {k: gl.get(k, DEFAULT_GAIN) for k in FULL_KEYS}
    return {"gl": gl, "gl_full": gl_full, "r_ref": r_ref, "r_arm": r_arm}


def summary_from_gl(gl: dict) -> dict:
    """a4_small_expert_act.py L129-134 と同じサマリ（補完前の gl から計算）。"""
    vals = list(gl.values())
    by_exp = [sum(gl[(l, i)] for l in range(L)) / L
              for i in range(E) if all((l, i) in gl for l in range(L))]
    return {"n": len(vals), "min": min(vals), "max": max(vals),
            "mean": sum(vals) / len(vals),
            "by_expert": [round(v, 4) for v in by_exp]}


def scan_nonfinite(o, path="root"):
    bad = []
    if isinstance(o, dict):
        for k, v in o.items():
            bad += scan_nonfinite(v, f"{path}.{k}")
    elif isinstance(o, list):
        for j, v in enumerate(o):
            bad += scan_nonfinite(v, f"{path}[{j}]")
    elif isinstance(o, float) and not np.isfinite(o):
        bad.append(path)
    return bad


def main() -> None:
    torch.set_num_threads(1)
    out = {
        "tag": TAG, "phase": "QA1S3 Step 1 (C2 completion + 3-point-control diagnostics, no training)",
        "design": "QA1S3課題設計書_未選択キーを既定gainで補完し3点対照の情報量を回復する_20261115.md",
        "no_training": True, "no_confirmatory_delta_iv": True,
    }
    out["prereg"] = {
        "ARMS": {k: list(v) for k, v in ARMS.items()}, "ACTS": ACTS,
        "SEEDS": list(SEEDS), "L": L, "E": E, "N_POS": N_POS,
        "CAL_SEED": CAL_SEED, "CAL_N": CAL_N,
        "EVAL_SEED": EVAL_SEED, "EVAL_N": EVAL_N, "EVAL_BS": EVAL_BS,
        "DEFAULT_GAIN": DEFAULT_GAIN, "KAPPA": KAPPA, "CE_LIMIT": CE_LIMIT,
        "RNG_SEED_OFFSET": RNG_SEED_OFFSET, "C5_POLICIES": list(C5_POLICIES),
        "plan_B": "gl_full = {(l,i): gl.get((l,i), 1.0) for all 32 (l,i)}",
        "plan_A_rejected": "校正系列数 128 を増やすと r_ref/r_arm の RMS が変わり C1 のビット一致が崩れるため却下",
        "summary_note": "n/min/max/mean/by_expert は補完前の gl から計算し、by_position だけを 32 個へ確定する",
    }

    existing = json.loads((HERE / "qa1s2_metrics.json").read_text(encoding="utf-8"))
    runs = {(r["arm"], r["seed"]): r for r in existing["runs"]}

    # ---- C2 復旧と無侵襲性の 3 経路検算
    c2_rows, gl_map = {}, {}
    for arm in ARMS:
        for seed in SEEDS:
            g = gain_for(arm, seed)
            gl, gl_full = g["gl"], g["gl_full"]
            gl_map[(arm, seed)] = gl_full
            ex = runs[(arm, seed)]["gain"]
            ex_bp = {tuple(int(x) for x in k.split(",")): float(v)
                     for k, v in ex["by_position"].items()}
            md_existing = max(abs(ex_bp[k] - gl_full[k]) for k in ex_bp)
            md_effective = max(abs(gl_full[k] - gl.get(k, DEFAULT_GAIN))
                               for k in FULL_KEYS)
            sm = summary_from_gl(gl)
            md_scalar = max(abs(float(sm[k]) - float(ex[k]))
                            for k in ("n", "min", "max", "mean"))
            same_len = len(sm["by_expert"]) == len(ex["by_expert"])
            md_by_expert = (max(abs(a - b) for a, b in
                                zip(sm["by_expert"], ex["by_expert"]))
                            if same_len else -1.0)
            missing = [f"{l},{i}" for (l, i) in FULL_KEYS if (l, i) not in gl]
            c2_rows[f"{arm}_s{seed}"] = {
                "n_existing_keys": len(ex_bp), "n_completed_keys": len(gl_full),
                "missing_keys_in_gl": missing,
                "maxdiff_existing_values": md_existing,
                "maxdiff_effective_gain": md_effective,
                "maxdiff_summary_scalar": md_scalar,
                "maxdiff_summary_by_expert": md_by_expert,
                "by_expert_len_match": bool(same_len),
                "recomputed_summary": sm,
                "gain_min": sm["min"], "gain_max": sm["max"],
                "all_finite": bool(np.isfinite(list(gl_full.values())).all()),
            }
    c2_all_32 = all(r["n_completed_keys"] == N_POS for r in c2_rows.values())
    c2_intrusive = all(
        r["maxdiff_existing_values"] == 0.0
        and r["maxdiff_effective_gain"] == 0.0
        and r["maxdiff_summary_scalar"] == 0.0
        and r["maxdiff_summary_by_expert"] == 0.0
        and r["by_expert_len_match"] and r["all_finite"]
        for r in c2_rows.values())
    out["C2_recovery"] = {
        "per_run": c2_rows,
        "all_32": bool(c2_all_32),
        "non_intrusive": bool(c2_intrusive),
        "pass": bool(c2_all_32 and c2_intrusive),
        "n_runs": len(c2_rows),
        "n_missing_keys_before": int(sum(N_POS - r["n_existing_keys"]
                                         for r in c2_rows.values())),
    }

    # ---- 発散の切り分け（学習 0 epoch の dry-run。代表 3 run）
    ev_rng = np.random.default_rng(EVAL_SEED)
    ev_seq, ev_typ = Q1.make_trace_batch(ev_rng, EVAL_N)
    dry = {}
    for arm in ARMS:
        widths = ARMS[arm]
        model = DiagPolicyActMoE(widths, "relu", seed=0, act_i=ACTS,
                                 rng_seed=0, policy="learned")
        model.gain_l = gl_map[(arm, 0)]
        per_pol = {}
        for pol in C5_POLICIES:
            model.gate_log = []
            r = POL.eval_policy(model, ev_seq, ev_typ, pol, bs=EVAL_BS)
            g = model.gate_log
            topi = r["topi"]
            typ_flat = r["typ_flat"]
            small = (typ_flat != Q1.TYP_PAYLOAD)
            exp_c0 = np.where(small, 0, E - 2)
            exp_c1 = np.where(small, 1, E - 1)
            oracle_agreement = (float(np.mean((topi[:, 0] == exp_c0)
                                              & (topi[:, 1] == exp_c1)))
                                if pol == "oracle" else None)
            usage = np.bincount(topi[:, 0], minlength=E).astype(np.float64)
            usage /= max(usage.sum(), 1.0)
            rel_dev = float(np.max(np.abs(usage - 1.0 / E) / (1.0 / E)))
            per_pol[pol] = {
                "ce_all": r["ce_all"], "instr_valid": r["instr_valid"],
                "first_logits": r["first_logits"],
                "gate_max": max(x["gate_max"] for x in g),
                "gate_min": min(x["gate_min"] for x in g),
                "gate_nonfinite": sum(x["gate_nonfinite"] for x in g),
                "topi_dup_rate_mean": float(np.mean([x["topi_dup_rate"] for x in g])),
                "topi_range": [min(x["topi_min"] for x in g),
                               max(x["topi_max"] for x in g)],
                "expert_coverage": int(np.unique(topi).size),
                "usage_max_rel_dev": rel_dev,
                "oracle_typ_agreement": oracle_agreement,
                "ce_all_within_limit": bool(np.isfinite(r["ce_all"])
                                            and r["ce_all"] <= CE_LIMIT),
            }
        # P1: 3 方策の first_logits ペア間 maxdiff（learned を基準に対象 3 方策）
        pairs = {}
        for a, b in (("uniform", "random"), ("uniform", "oracle"),
                     ("random", "oracle")):
            x, y = per_pol[a]["first_logits"], per_pol[b]["first_logits"]
            pairs[f"{a}_vs_{b}"] = float(np.max(np.abs(x - y)))
        dry[arm] = {
            "policies": {p: {k: v for k, v in d.items() if k != "first_logits"}
                         for p, d in per_pol.items()},
            "P1_pair_maxdiff": pairs,
            "P1_pass": bool(all(v > 0 for v in pairs.values())),
            "P2_oracle_typ_agreement": per_pol["oracle"]["oracle_typ_agreement"],
            "P2_pass": bool(per_pol["oracle"]["oracle_typ_agreement"] == 1.0),
            "P3_uniform_expert_coverage": per_pol["uniform"]["expert_coverage"],
            "P3_pass": bool(per_pol["uniform"]["expert_coverage"] == E),
            "P4_random_usage_max_rel_dev": per_pol["random"]["usage_max_rel_dev"],
            "P4_pass": bool(per_pol["random"]["usage_max_rel_dev"] < 0.05),
            "P5_pass": bool(all(d["ce_all_within_limit"] for d in per_pol.values())),
            "P6_all_tied_at_floor": bool(all(
                d["instr_valid"] in (0.0, 1.0) for d in per_pol.values())),
        }
        dry[arm]["P6_uninformative"] = dry[arm]["P6_all_tied_at_floor"]
        dry[arm]["C5_redefined_pass"] = bool(all(
            dry[arm][k] for k in ("P1_pass", "P2_pass", "P3_pass", "P4_pass", "P5_pass"))
            and not dry[arm]["P6_uninformative"])
    out["dry_run_diagnostics"] = dry

    # ---- 既存 21 run の 3 点対照を P5 / P6 で再解析
    pe = existing["policy_eval"]
    ce_by_pol = {p: [] for p in C5_POLICIES}
    floor_hits = 0
    for row in pe:
        for p in C5_POLICIES:
            ce_by_pol[p].append(float(row["policies"][p]["ce_all"]))
        if all(row["policies"][p]["instr_valid"] in (0.0, 1.0)
               for p in C5_POLICIES):
            floor_hits += 1
    out["existing_21run_reanalysis"] = {
        "n_runs": len(pe),
        "ce_all_mean_by_policy": {p: float(np.mean(v)) for p, v in ce_by_pol.items()},
        "ce_all_max_by_policy": {p: float(np.max(v)) for p, v in ce_by_pol.items()},
        "ce_all_nonfinite_by_policy": {p: int((~np.isfinite(v)).sum())
                                       for p, v in ce_by_pol.items()},
        "P5_within_limit_count": {p: int(np.sum(np.asarray(v) <= CE_LIMIT))
                                  for p, v in ce_by_pol.items()},
        "P5_pass": bool(all((np.asarray(v) <= CE_LIMIT).all()
                            for v in ce_by_pol.values())
                        and all(np.isfinite(v).all() for v in ce_by_pol.values())),
        "P6_floor_hit_runs": floor_hits,
        "P6_uninformative": bool(floor_hits == len(pe)),
        "ce_limit": CE_LIMIT,
    }

    # ---- 発散の由来（1 つに絞れなければ undetermined）
    causes = set()
    for arm, d in dry.items():
        rp = d["policies"]["random"]
        if rp["gate_nonfinite"] > 0 or rp["gate_max"] > 1e3:
            causes.add("gate")
        if rp["topi_dup_rate_mean"] > 0:
            causes.add("topi_duplication")
        if c2_rows[f"{arm}_s0"]["gain_max"] > 1e3:
            causes.add("gain")
    rean = out["existing_21run_reanalysis"]
    cause = (list(causes)[0] if len(causes) == 1 else "undetermined")
    out["divergence_diagnosis"] = {
        "candidate_causes": sorted(causes),
        "resolved_cause": cause,
        "dry_run_random_ce_all": {a: d["policies"]["random"]["ce_all"]
                                  for a, d in dry.items()},
        "production_random_ce_all_mean": rean["ce_all_mean_by_policy"]["random"],
        "production_random_ce_all_max": rean["ce_all_max_by_policy"]["random"],
        "note": ("学習 0 epoch の dry-run と学習後 ckpt では条件が異なる。"
                 "1 つに絞れない場合は undetermined と書き、推測で断定しない（設計書 §4）"),
    }

    # ---- §5 の分岐
    c2_ok = out["C2_recovery"]["pass"]
    resolved = cause != "undetermined"
    if c2_ok and resolved:
        case = ("I: C2 無侵襲性が全成立し発散の由来が確定。別 ID で gl_full を run_one へ適用し"
                "方策実装を修正したうえで 21 run を再走して C1〜C6 を再判定")
    elif c2_ok:
        case = ("II: C2 は成立するが発散の由来が未確定。方策実装の切り分けを別 ID で継続し"
                "本番再走はしない")
    else:
        case = ("III: C2 無侵襲性が崩れた。案 B を撤回し C1 を壊さない別方式を新 ID で設計。"
                "案 A（系列数増加）は再採用しない")
    out["case"] = case

    nonfinite = scan_nonfinite(out)
    out["C6"] = {"nonfinite_paths": nonfinite, "pass": bool(len(nonfinite) == 0)}
    out["verdict"] = "PASS" if c2_ok and out["C6"]["pass"] else "FAIL"

    # ---- 書き出し（first_logits は巨大なので落とす。gain 配列は独立検算用に保存）
    arrays = {}
    for (arm, seed), gl_full in gl_map.items():
        arrays[f"{arm}_s{seed}_gl_full"] = np.asarray(
            [gl_full[k] for k in FULL_KEYS], dtype=np.float64)
    arrays["full_keys_l"] = np.asarray([k[0] for k in FULL_KEYS], dtype=np.int64)
    arrays["full_keys_i"] = np.asarray([k[1] for k in FULL_KEYS], dtype=np.int64)
    np.savez(HERE / f"{TAG}_gain.npz", **arrays)
    (HERE / f"{TAG}_metrics.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    lines = [
        f"tag={TAG}", f"verdict={out['verdict']}",
        f"C2 all_32={c2_all_32} non_intrusive={c2_intrusive} pass={c2_ok}",
        f"C2 missing_keys_before={out['C2_recovery']['n_missing_keys_before']}",
        f"dry_run P1={[d['P1_pass'] for d in dry.values()]} "
        f"P5={[d['P5_pass'] for d in dry.values()]} "
        f"P6_uninformative={[d['P6_uninformative'] for d in dry.values()]}",
        f"production random ce_all mean={rean['ce_all_mean_by_policy']['random']:.6f} "
        f"max={rean['ce_all_max_by_policy']['random']:.6f} limit={CE_LIMIT:.6f}",
        f"P5_pass_production={rean['P5_pass']} P6_uninformative={rean['P6_uninformative']}",
        f"divergence_cause={cause} candidates={sorted(causes)}",
        f"C6_pass={out['C6']['pass']}", f"case={case}", "",
    ]
    (HERE / f"{TAG}.log").write_text("\n".join(lines), encoding="utf-8")
    sys.stdout.write("\n".join(lines))
    sys.stdout.flush()


if __name__ == "__main__":
    main()
