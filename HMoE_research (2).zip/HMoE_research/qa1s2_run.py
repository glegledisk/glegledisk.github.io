# -*- coding: utf-8 -*-
"""QA1S2 Step 2 本番: 幅 3 腕を A4b ハーネスに載せ Delta_iv を 7 seed で検定する.

設計書: `QA1S2課題設計書_幅3腕をA4bハーネスに載せDelta_ivを7seedで検定する_20261114.md`
        §1〜§7 / §10、Step 1 報告 `検証報告_QA1S2S1_..._20261114.md`

本次の範囲（走行前に固定。結果を見て変更しない）
  - 3 腕 × 7 seed × 6 epoch の**本番学習**と確認的 `Delta_iv`。
  - `run_one(widths_override, act_override, model_out)` で学習済み ckpt を取得し、
    `PolicyActMoE` へ `p` / `gain_l` を移植して 4 方策を同一 ckpt・同一 eval トークンで評価。
  - 3 点対照 C5 は設計書 §7 の本来定義 `instr_valid(random) <= instr_valid(oracle)` で本番判定。
  - eval 側収束ゲートは T± × E± の分類＋完全性（除外しない）。感度解析は探索的のみ。

固定量（設計書 §2 / §3 / §5 / §7）
  W_REF / W_MID / W_FLAT、`act_i = relu2 x 8`、`gain = matched`、`epochs = 6`、
  `seeds = 0..6`、`lr = 2e-3`、`bs = 32`、`auxw = 0.05`、`n_seqs = 3000`、
  `eval_every = 1`、eval バッチ `seed 777 / 1024 系列`、乱数 `seed + 977`、
  主指標 `instr_valid` の末尾 3 epoch 中央値、`ttest_rel` 両側 α = 0.05、Holm m = 1、
  `MDE = t.ppf(0.975, 6) * se`、90% CI、上位 1% 寄与率 `TOP1_CONTRIB_LIMIT`。

出力: qa1s2_metrics.json / qa1s2_delta.npz / qa1s2.log / data/a4/*_qa1s2prod.json
      （すべて UTF-8、json は allow_nan=False）
"""
from __future__ import annotations

import json
import math
import os
import sys
import time
import traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
from scipy import stats

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "simulation_hmoe_mmlu"))
sys.path.insert(0, str(HERE / "不均一MoE-Corpus"))

import a4_small_expert_act as A4          # noqa: E402
import q1_trace_routing as Q1             # noqa: E402
import qa1s2_policy as POL                # noqa: E402
from corpus_common import (CONV_RANGE_MAX, CONV_SLOPE_MAX,  # noqa: E402
                           TOP1_CONTRIB_LIMIT)

TAG = "qa1s2"
PROD_TAG = "_qa1s2prod"
W_REF = (32, 32, 96, 96, 160, 160, 224, 224)
W_MID = (96, 96, 96, 96, 160, 160, 160, 160)
W_FLAT = (128,) * 8
ARMS = {"w_ref": W_REF, "w_mid": W_MID, "w_flat": W_FLAT}
ACTS = ["relu2"] * 8
WIDTH_TOTAL = 1024
N_POS = 32

SEEDS = tuple(range(7))
EPOCHS = 6
LR = 2.0e-3
BS = 32
AUXW = 0.05
N_SEQS = 3000
EVAL_EVERY = 1
EVAL_SEED = 777
EVAL_N = 1024
TAIL_K = 3                     # 主指標の末尾 3 epoch 中央値 / 収束 tail3
ALPHA = 0.05
VOCAB_Q1 = 17                 # ln(17) = 2.8332（設計書 §5 の理論値）
CE_ALL_LIMIT = math.log(VOCAB_Q1)
IV_GATE_MIN = 0.10            # E+ の補助分類（設計書 §5）
EPS_C1 = 1.0e-9
EPS_ROUND = 5.0e-5
MDE_T = float(stats.t.ppf(0.975, len(SEEDS) - 1))     # 2.4469
CI90_T = float(stats.t.ppf(0.95, len(SEEDS) - 1))
WORKERS = 6
C5_POLICIES = ("learned", "uniform", "random", "oracle")


def flatten_numeric(o, path="root"):
    out = {}
    if isinstance(o, dict):
        for k, v in o.items():
            out.update(flatten_numeric(v, f"{path}.{k}"))
    elif isinstance(o, list):
        for j, v in enumerate(o):
            out.update(flatten_numeric(v, f"{path}[{j}]"))
    elif isinstance(o, (int, float)) and not isinstance(o, bool):
        out[path] = float(o)
    return out


def maxdiff_dict(a, b):
    fa, fb = flatten_numeric(a), flatten_numeric(b)
    keys = set(fa) | set(fb)
    miss = [k for k in keys if k not in fa or k not in fb]
    d = [abs(fa[k] - fb[k]) for k in keys if k in fa and k in fb]
    return (max(d) if d else 0.0), len(keys), miss


def tail_stats(loss_hist):
    tail = np.asarray(loss_hist[-min(TAIL_K, len(loss_hist)):], dtype=np.float64)
    if tail.size >= 2:
        slope = float(np.polyfit(np.arange(tail.size), tail, 1)[0])
    else:
        slope = 0.0
    rng = float(tail.max() - tail.min()) if tail.size else 0.0
    T = bool(abs(slope) <= CONV_SLOPE_MAX and rng <= CONV_RANGE_MAX)
    return {"slope": slope, "range": rng, "T_plus": T}


def run_job(arm, seed):
    """1 (腕, seed) を学習し、同一 ckpt で 4 方策を評価して dict を返す。"""
    import torch
    torch.set_num_threads(1)
    widths = ARMS[arm]
    box = []
    out = A4.run_one(arm=arm, seed=seed, scale=1.0, n_seqs=N_SEQS,
                     epochs=EPOCHS, bs=BS, lr=LR, auxw=AUXW, gain="matched",
                     eval_every=EVAL_EVERY, tag=PROD_TAG,
                     widths_override=widths, act_override=ACTS, model_out=box)
    trained = box[0]
    assert len(box) == 1, "model_out must carry exactly one trained ckpt"

    # ---- 学習済み ckpt を PolicyActMoE へ移植（同一重み・同一 gain_l）
    pol_model = POL.PolicyActMoE(widths, "relu", seed=seed, act_i=ACTS,
                                 rng_seed=seed, policy="learned")
    pol_model.p = trained.p                  # 参照共有（コピーしない＝同一 ckpt）
    pol_model.gain_l = dict(trained.gain_l)
    same_p = pol_model.p is trained.p
    same_gain = pol_model.gain_l == trained.gain_l

    ev_rng = np.random.default_rng(EVAL_SEED)
    ev_seq, ev_typ = Q1.make_trace_batch(ev_rng, EVAL_N)
    policy_res = {}
    for pol in C5_POLICIES:
        r = POL.eval_policy(pol_model, ev_seq, ev_typ, pol, bs=128)
        policy_res[pol] = {k: v for k, v in r.items()
                           if k not in ("first_logits", "topi", "typ_flat")}

    # ---- 主指標: instr_valid の末尾 3 epoch 中央値（設計書 §3）
    iv_series = [float(e["instr_valid"]) for e in out["evals"][-TAIL_K:]]
    iv_main = float(np.median(iv_series))
    ce_all_main = float(np.median([e["ce_all"] for e in out["evals"][-TAIL_K:]]))
    loss_hist = [float(v) for v in out["loss_hist"]]
    gate = tail_stats(loss_hist)

    # ---- E フラグ / E+（設計書 §5）。除外しない。
    e_flag = bool((not np.isfinite(ce_all_main)) or ce_all_main > CE_ALL_LIMIT
                  or iv_main in (0.0, 1.0))
    e_plus = bool(iv_main >= IV_GATE_MIN)

    return {
        "arm": arm, "seed": seed, "widths": list(widths),
        "width_sum": int(sum(widths)), "act_i": ACTS,
        "nparam": out["nparam"], "sec": out["sec"],
        "iv_series_tail": iv_series, "iv_main": iv_main,
        "ce_all_main": ce_all_main, "loss_hist": loss_hist,
        "gain": out["gain"], "routing": out["routing"],
        "T": gate, "E_flag": e_flag, "E_plus": e_plus,
        "T_plus": gate["T_plus"],
        "same_p": bool(same_p), "same_gain_l": bool(same_gain),
        "policies": policy_res,
    }


def _worker(job):
    try:
        return run_job(**job)
    except Exception:
        return {"arm": job.get("arm"), "seed": job.get("seed"),
                "error": traceback.format_exc()}


def paired_stats(a, b):
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    assert a.shape == b.shape, (a.shape, b.shape)
    n_nonfinite = int((~np.isfinite(a)).sum() + (~np.isfinite(b)).sum())
    d = a - b
    n = int(d.size)
    mean_d = float(np.nan_to_num(d.mean(), nan=0.0, posinf=0.0, neginf=0.0))
    se = float(d.std(ddof=1) / math.sqrt(n)) if n > 1 else float("nan")
    if n_nonfinite:
        se = float("nan")
    r = stats.ttest_rel(a, b)
    t = float(r.statistic)
    p = float(r.pvalue)
    # corpus_common.paired と同じ nan 規約。ただし本番は allow_nan=False で書くため
    # inf も有限値へ畳み込み、理由を note に残す（床張り付き = 分散ゼロ）。
    note = ""
    t_infinite = False
    if not np.isfinite(t) or not np.isfinite(p):
        # corpus_common.paired と同じ規約: 分散ゼロでも差が非ゼロなら棄却。
        # allow_nan=False 書込のため t は JSON null にして p=0.0 を残す。
        note = "ttest_rel nonfinite (zero variance); corpus_common.paired rule applied"
        if abs(mean_d) < 1e-15:
            t, p = 0.0, 1.0
        else:
            t, p, t_infinite = None, 0.0, True
            note += "; constant nonzero delta -> t=inf, p=0 (null t in JSON)"
    if not np.isfinite(se):
        se = 0.0
        note += "; se=0 (zero variance)"
    if n_nonfinite:
        note += f"; n_nonfinite_inputs={n_nonfinite} folded to 0 by prereg rule"
    mde = float(MDE_T * se)
    ci90 = [float(mean_d - CI90_T * se), float(mean_d + CI90_T * se)]
    d_fin = np.nan_to_num(d, nan=0.0, posinf=0.0, neginf=0.0)
    s = np.sort(np.abs(d_fin))[::-1]
    k = max(1, int(math.ceil(0.01 * n)))
    contrib = float(s[:k].sum() / s.sum()) if s.sum() > 0 else 0.0
    return {
        "n": n, "delta": mean_d, "se": se, "t": t, "p": p,
        "t_infinite": t_infinite,
        "mde": mde, "ci90": ci90, "mde_factor": MDE_T, "ci90_t": CI90_T,
        "delta_per_seed": d_fin.tolist(),
        "median_abs_delta": float(np.median(np.abs(d_fin))),
        "max_abs_delta": float(s[0]) if s.size else 0.0,
        "top1_share": contrib,
        "mean_unreliable": bool(contrib >= TOP1_CONTRIB_LIMIT),
        "holm_p": float(min(1.0, p)),       # m = 1 なので Holm は自明
        "reject": bool(p < ALPHA and not (contrib >= TOP1_CONTRIB_LIMIT)
                       and n_nonfinite == 0),
        "n_nonfinite_inputs": n_nonfinite,
        "note": note,
    }


def main() -> None:
    out = {
        "tag": TAG, "phase": "QA1S2 Step 2 (production)",
        "design": "QA1S2課題設計書_幅3腕をA4bハーネスに載せDelta_ivを7seedで検定する_20261114.md",
        "step1_gate": "PASS (検証報告_QA1S2S1_..._20261114.md, 103 items / 0 mismatch)",
        "no_confirmatory_before_this_run": True,
    }
    out["prereg"] = {
        "W_REF": list(W_REF), "W_MID": list(W_MID), "W_FLAT": list(W_FLAT),
        "ACTS": ACTS, "WIDTH_TOTAL": WIDTH_TOTAL, "N_POS": N_POS,
        "SEEDS": list(SEEDS), "EPOCHS": EPOCHS, "LR": LR, "BS": BS,
        "AUXW": AUXW, "N_SEQS": N_SEQS, "EVAL_EVERY": EVAL_EVERY,
        "EVAL_SEED": EVAL_SEED, "EVAL_N": EVAL_N, "TAIL_K": TAIL_K,
        "ALPHA": ALPHA, "VOCAB_Q1": VOCAB_Q1, "CE_ALL_LIMIT": CE_ALL_LIMIT,
        "IV_GATE_MIN": IV_GATE_MIN, "MDE_T": MDE_T, "CI90_T": CI90_T,
        "CONV_SLOPE_MAX": CONV_SLOPE_MAX, "CONV_RANGE_MAX": CONV_RANGE_MAX,
        "TOP1_CONTRIB_LIMIT": TOP1_CONTRIB_LIMIT,
        "C5_POLICIES": list(C5_POLICIES), "WORKERS": WORKERS,
        "estimand": "Delta_iv = mean_seed[iv(w_mid) - iv(w_ref)], iv = median(evals[-3:].instr_valid)",
        "test": "scipy.stats.ttest_rel, two-sided, alpha=0.05, Holm m=1",
        "primary_metric": "instr_valid (NOT ce_all / ce_seq)",
        "gate_rule": "T+ = |slope(tail3 loss_hist)| <= 0.005 and range <= 0.02; "
                     "E+ = iv_main >= 0.10; E flag = ce_all > ln(17) or nonfinite or iv in {0,1}",
        "exclusion_rule": "除外しない。E フラグ seed は主解析に残す。感度解析は探索的のみ",
        "3point_control_basis": "同一 ckpt (p と gain_l を移植)・同一 eval トークン・方策ごとに forward をやり直す",
        "shared_ckpt_note": "run_one(model_out) で取得した学習済み ActMoE の p を "
                            "PolicyActMoE へ参照共有。同一 widths/seed/act_i で構造も一致",
    }

    jobs = [dict(arm=a, seed=s) for a in ARMS for s in SEEDS]
    rows, t0 = [], time.time()
    with ProcessPoolExecutor(max_workers=WORKERS) as ex:
        futs = {ex.submit(_worker, j): j for j in jobs}
        for k, fu in enumerate(as_completed(futs), 1):
            r = fu.result()
            if "error" in r:
                out.setdefault("errors", []).append(r)
                sys.stderr.write(f"[FAIL] {r['arm']} s{r['seed']}\n{r['error']}\n")
                continue
            rows.append(r)
            sys.stdout.write(
                f"[{k}/{len(jobs)}] {r['arm']:6s} s{r['seed']} iv={r['iv_main']:.4f} "
                f"T+={r['T_plus']} E={r['E_flag']} ({r['sec']:.0f}s, "
                f"tot {time.time()-t0:.0f}s)\n")
            sys.stdout.flush()
    out["runtime_seconds"] = float(time.time() - t0)
    assert len(rows) == len(jobs), f"only {len(rows)}/{len(jobs)} runs completed"

    by_arm = {a: {r["seed"]: r for r in rows if r["arm"] == a} for a in ARMS}
    out["runs"] = [
        {k: v for k, v in r.items() if k not in ("policies",)} for r in rows
    ]
    out["policy_eval"] = [
        {"arm": r["arm"], "seed": r["seed"],
         "policies": {p: {k: v for k, v in d.items()}
                      for p, d in r["policies"].items()}}
        for r in rows
    ]

    # ---- C1〜C4 / C6 校正
    saved = json.loads((HERE / "data" / "a4" / "all_relu2_s0_g.json").read_text(
        encoding="utf-8"))["gain"]
    c1_rows = [r for r in rows if r["arm"] == "w_ref" and r["seed"] == 0]
    g0 = c1_rows[0]["gain"]
    c1 = {
        "gain_summary_diff": {
            "n": abs(g0["n"] - int(saved["n"])),
            "min": abs(g0["min"] - float(saved["min"])),
            "max": abs(g0["max"] - float(saved["max"])),
            "mean": abs(g0["mean"] - float(saved["mean"])),
            "by_expert": max(abs(a - b) for a, b in zip(g0["by_expert"], saved["by_expert"])),
        },
        "all_runs_same_p": bool(all(r["same_p"] for r in rows)),
        "all_runs_same_gain_l": bool(all(r["same_gain_l"] for r in rows)),
        "existing_keys_present": all(k in g0 for k in
                                     ("mode", "n", "min", "max", "mean", "by_expert",
                                      "by_position")),
    }
    c1["pass"] = bool(c1["gain_summary_diff"]["by_expert"] < EPS_ROUND
                      and max(c1["gain_summary_diff"][k] for k in ("n", "min", "max", "mean")) < EPS_C1
                      and c1["all_runs_same_p"] and c1["all_runs_same_gain_l"]
                      and c1["existing_keys_present"])

    keysets = {a: set(by_arm[a][0]["gain"]["by_position"].keys()) for a in ARMS}
    c2 = {
        "n_positions_per_run": {a: [len(by_arm[a][s]["gain"]["by_position"])
                                    for s in SEEDS] for a in ARMS},
        "all_32": bool(all(len(by_arm[a][s]["gain"]["by_position"]) == N_POS
                           for a in ARMS for s in SEEDS)),
        "all_finite": bool(all(np.isfinite(list(by_arm[a][s]["gain"]["by_position"].values())).all()
                               for a in ARMS for s in SEEDS)),
    }
    c2["pass"] = bool(c2["all_32"] and c2["all_finite"])
    c3 = {
        "width_sums": {a: by_arm[a][0]["width_sum"] for a in ARMS},
        "all_1024": bool(all(r["width_sum"] == WIDTH_TOTAL for r in rows)),
        "all_relu2": bool(all(r["act_i"] == ACTS for r in rows)),
        "w_ref_eq_BASE_W": bool(tuple(W_REF) == tuple(A4.BASE_W)),
        "epochs_6": bool(all(len(r["loss_hist"]) == EPOCHS for r in rows)),
    }
    c3["pass"] = bool(c3["all_1024"] and c3["all_relu2"] and c3["epochs_6"])
    symdiff = sum(len(keysets[a] ^ keysets["w_ref"]) for a in ARMS)
    cells = {(t, e): 0 for t in (True, False) for e in (True, False)}
    for r in rows:
        cells[(bool(r["T_plus"]), bool(r["E_plus"]))] += 1
    c4 = {
        "key_symmetric_difference": symdiff,
        "classification_grid": {f"T{'+' if t else '-'}E{'+' if e else '-'}": n
                                for (t, e), n in cells.items()},
        "classified_pairs": int(sum(cells.values())),
        "expected_pairs": len(rows),
        "excluded_pairs": 0,
    }
    c4["pass"] = bool(symdiff == 0 and c4["classified_pairs"] == c4["expected_pairs"]
                      and c4["excluded_pairs"] == 0)

    # ---- C5: 設計書 §7 本来の本番判定（全 seed・全腕）
    c5_detail = {}
    c5_ok_all = True
    for a in ARMS:
        for s in SEEDS:
            pr = by_arm[a][s]["policies"]
            ok = bool(pr["random"]["instr_valid"] <= pr["oracle"]["instr_valid"])
            c5_ok_all &= ok
            c5_detail[f"{a}_s{s}"] = {
                "random": pr["random"]["instr_valid"],
                "oracle": pr["oracle"]["instr_valid"],
                "pass": ok,
            }
    c5 = {"per_run": c5_detail, "all_pass": bool(c5_ok_all),
          "n_runs": len(c5_detail),
          "tie_count": int(sum(1 for d in c5_detail.values()
                               if d["random"] == d["oracle"])),
          "all_tied_at_floor": bool(all(d["random"] == d["oracle"] == 0.0
                                        for d in c5_detail.values())),
          "note": ("Step 1 の dry-run 版 4 条件は学習 0 epoch 用。本番は設計書 §7 の本来定義で判定。"
                   "全腕が instr_valid=0 に張り付いた場合は <= は自明に成立し、"
                   "校正としての情報量が無いことを tie_count / all_tied_at_floor で記録する")}
    c5["pass"] = bool(c5_ok_all)

    # ---- 確認的 Delta_iv（主解析。E フラグは除外しない）
    iv_ref = np.asarray([by_arm["w_ref"][s]["iv_main"] for s in SEEDS])
    iv_mid = np.asarray([by_arm["w_mid"][s]["iv_main"] for s in SEEDS])
    iv_flat = np.asarray([by_arm["w_flat"][s]["iv_main"] for s in SEEDS])
    primary = paired_stats(iv_mid, iv_ref)
    primary["holm_m"] = 1
    primary["iv_ref_per_seed"] = iv_ref.tolist()
    primary["iv_mid_per_seed"] = iv_mid.tolist()
    out["primary"] = primary
    out["exploratory"] = {
        "w_flat_vs_w_ref": paired_stats(iv_flat, iv_ref),
        "iv_flat_per_seed": iv_flat.tolist(),
        "note": "w_flat と gain の幅単調は探索的。有意差を主張しない（設計書 §3）",
    }

    # ---- 感度解析（事前登録。E フラグを除いた再計算。主判定には使わない）
    keep = [i for i, s in enumerate(SEEDS) if not by_arm["w_ref"][s]["E_flag"]
            and not by_arm["w_mid"][s]["E_flag"]]
    sens = paired_stats(iv_mid[keep], iv_ref[keep]) if len(keep) >= 2 else {
        "note": f"only {len(keep)} pairs remain; sensitivity not computed",
        "n": len(keep),
    }
    sens["excluded_pairs_sensitivity_only"] = len(SEEDS) - len(keep)
    out["sensitivity"] = {
        "result": sens, "kept_seeds": [SEEDS[i] for i in keep],
        "rule": "主解析からは除外しない。探索的感度としてのみ出力",
    }

    # ---- 3 点対照の記述（確認的家族には入れない）
    pol_summary = {}
    for a in ARMS:
        pol_summary[a] = {
            p: {
                "instr_valid_mean": float(np.mean([by_arm[a][s]["policies"][p]["instr_valid"]
                                                   for s in SEEDS])),
                "instr_valid_median": float(np.median([by_arm[a][s]["policies"][p]["instr_valid"]
                                                       for s in SEEDS])),
                "ce_all_mean": float(np.mean([by_arm[a][s]["policies"][p]["ce_all"]
                                              for s in SEEDS])),
            } for p in C5_POLICIES
        }
    out["three_point_control"] = pol_summary

    # ---- 判定ケース（設計書 §6 / §7）
    # §7 は「C5 が通らない場合は本番判定を止め、方策実装を疑う」と明記するため、
    # 確認的 Delta_iv の棄却如何より優先して停止する（走行前固定）。
    if not c5["pass"]:
        case = ("STOP: 設計書 §7 により本番判定を停止。C5 "
                "(`instr_valid(random) <= instr_valid(oracle)`) が不成立で、"
                "3 点対照の実装を疑う。Delta_iv は参考記録として残すが確認的判定はしない")
    elif primary["reject"]:
        case = ("A 相当: Delta_iv 棄却。幅が真の処置変数であることを支持するが、"
                "Q11 を本次ハーネスで再測していないため「Q11 非棄却のまま」は"
                "既存報告の引用に限る。1 testbed・1 モデル・1 ハーネスで一般則にしない")
    elif primary["mean_unreliable"]:
        case = ("C 相当（ただし平均が裾に支配）: 上位 1% 寄与率が "
                f"{primary['top1_share']:.4f} で {TOP1_CONTRIB_LIMIT} 以上。"
                "平均を主張に使わず MDE と 90% CI のみ併記")
    else:
        case = ("C 相当: 両方非棄却。MDE 未満。「差が無い」とは書かず "
                f"MDE {primary['mde']:.6f} と 90% CI を併記する")
    out["case"] = case
    out["case_note"] = (
        "設計書 §6 のケース B / D は本次ハーネス内の方策対照からの記述的示唆に限る"
        "（§8 により Q11 を再走しないため厳密判定は不能）。"
        "ケース A でも「幅と使用率と位置が同一の潜在量と確定」とは書かない。"
    )

    # ---- C6: 非有限値
    def scan(o, path="root"):
        bad = []
        if isinstance(o, dict):
            for k, v in o.items():
                bad += scan(v, f"{path}.{k}")
        elif isinstance(o, list):
            for j, v in enumerate(o):
                bad += scan(v, f"{path}[{j}]")
        elif isinstance(o, float) and not np.isfinite(o):
            bad.append(path)
        return bad
    nonfinite = scan(out)
    c6 = {"nonfinite_paths": nonfinite, "pass": bool(len(nonfinite) == 0)}
    out["calibration"] = {"C1": c1, "C2": c2, "C3": c3, "C4": c4,
                          "C5": c5, "C6": c6}
    checks = {k: out["calibration"][k]["pass"] for k in
              ("C1", "C2", "C3", "C4", "C5", "C6")}
    out["checks"] = checks
    out["verdict"] = "PASS" if all(checks.values()) else "FAIL"

    # ---- 書き出し
    (HERE / f"{TAG}_metrics.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False),
        encoding="utf-8")
    arrays = {
        "seeds": np.asarray(SEEDS),
        "iv_ref": iv_ref, "iv_mid": iv_mid, "iv_flat": iv_flat,
        "delta_iv_per_seed": iv_mid - iv_ref,
        "loss_hist": np.asarray([by_arm[a][s]["loss_hist"]
                                 for a in ARMS for s in SEEDS]),
        "iv_series_tail": np.asarray([by_arm[a][s]["iv_series_tail"]
                                      for a in ARMS for s in SEEDS]),
        "T_plus": np.asarray([by_arm[a][s]["T_plus"] for a in ARMS for s in SEEDS]),
        "E_flag": np.asarray([by_arm[a][s]["E_flag"] for a in ARMS for s in SEEDS]),
        "policy_iv": np.asarray([[by_arm[a][s]["policies"][p]["instr_valid"]
                                  for p in C5_POLICIES]
                                 for a in ARMS for s in SEEDS]),
        "policy_ce_all": np.asarray([[by_arm[a][s]["policies"][p]["ce_all"]
                                      for p in C5_POLICIES]
                                     for a in ARMS for s in SEEDS]),
    }
    np.savez(HERE / f"{TAG}_delta.npz", **arrays)
    t_str = "inf(null)" if primary["t"] is None else f"{primary['t']:.6f}"
    lines = [
        f"tag={TAG}", f"verdict={out['verdict']}",
        f"runtime_seconds={out['runtime_seconds']:.1f}",
        f"Delta_iv={primary['delta']:.8f} se={primary['se']:.8f} "
        f"t={t_str} p={primary['p']:.8f} n={primary['n']}",
        f"MDE={primary['mde']:.8f} CI90={primary['ci90']}",
        f"top1_share={primary['top1_share']:.6f} mean_unreliable={primary['mean_unreliable']}",
        f"C5_all_pass={c5['all_pass']} classification={c4['classification_grid']}",
        f"checks={checks}", f"case={case}", "",
    ]
    (HERE / f"{TAG}.log").write_text("\n".join(lines), encoding="utf-8")
    sys.stdout.write("\n".join(lines))
    sys.stdout.flush()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        sys.stderr.write(f"[qa1s2_run] ERROR {type(exc).__name__}: {exc}\n")
        sys.stderr.flush()
        raise
