# -*- coding: utf-8 -*-
"""QA1S6 production: collapse-rate estimand over 54 seeds x 2 arms = 108 runs.

設計書: `QA1S6課題設計書_崩壊確率をestimandにする場合の必要seed数を走行前に確定する_20261116.md`
        §1〜§3、Step 1 報告 `検証報告_QA1S6S1_..._20261116.md`

走行前に固定（結果を見て変更しない）:
  - seed 0..53 × 2 腕 (w_ref / w_mid) = 108 run。w_flat は走らない。
  - 学習条件・gain 補完・random 非復元・eval 系列は QA1S4 と同一。
  - 崩壊ラベルは QA1S5 §2 の固定規則 (spike & final_iv=0 & final_ce>0.5)。
  - estimand Δ_collapse = P(COLLAPSE|w_mid) - P(COLLAPSE|w_ref)。
  - McNemar exact binomial、両側 α=0.05。Discordant b/c を記録。
  - QA1S4 cache は条件署名が一致する seed 0..6 のみ再利用する。

出力: qa1s6_metrics.json / qa1s6_delta.npz / qa1s6.log / qa1s6_partial_metrics.json
      / qa1s6_out_utf8.txt / qa1s6_err_utf8.txt / qa1s6_cache/*
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
import traceback
from concurrent.futures import ProcessPoolExecutor, as_completed
from pathlib import Path

import numpy as np
from scipy import stats

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "simulation_hmoe_mmlu"))

import qa1s2_run as Q2                     # noqa: E402
import qa1s4_run as Q4                     # noqa: E402  (_run / cache / analyze を再利用)

TAG = "qa1s6"
PROD_TAG = "_qa1s6prod"
ARMS = ("w_ref", "w_mid")
SEEDS = tuple(range(54))                   # 設計書 §3: 54 seed
CACHE_DIR = HERE / "qa1s6_cache"
CACHE_VERSION = 1
PROD_DUP_N = 6

# QA1S5 §2 の固定規則（結果を見て変更しない）
COLLAPSE_LOSS_RATIO = 1.0
COLLAPSE_CE = 0.5
ALPHA = 0.05


def collapse_label(row: dict) -> tuple[str, bool, float, float, int]:
    loss = np.asarray(row["loss_hist"], dtype=np.float64)
    spike = bool(loss.size > 1 and float(loss[1:].max())
                 > float(loss[0]) * COLLAPSE_LOSS_RATIO)
    tail = np.asarray(row["iv_series_tail"], dtype=np.float64)
    final_iv = float(tail[-1]) if tail.size else float("nan")
    final_ce = float(np.median([float(e["ce_all"]) for e in row["evals"][-Q2.TAIL_K:]]))
    collapse = bool(spike and final_iv == 0.0 and final_ce > COLLAPSE_CE)
    return ("COLLAPSE" if collapse else "NOT_COLLAPSE"), spike, final_iv, final_ce, int(collapse)


def cache_signature(arm: str, seed: int) -> dict:
    """QA1S4 と同一条件（再現性）。設計 ID だけを S6 に変える。"""
    return {"version": CACHE_VERSION, "arm": arm, "seed": int(seed),
            "widths": list(Q4.ARMS[arm]), "epochs": Q2.EPOCHS, "lr": Q2.LR,
            "n_seqs": Q2.N_SEQS, "eval_n": Q2.EVAL_N,
            "complete_gain_map": True, "random_without_replacement": True,
            "design": "QA1S6-20261116"}


def cache_paths(arm: str, seed: int) -> tuple[Path, Path]:
    stem = f"qa1s6_{arm}_s{seed}"
    return CACHE_DIR / f"{stem}.json", CACHE_DIR / f"{stem}.npz"


def save_cache(row: dict) -> None:
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    arm, seed = row["arm"], int(row["seed"])
    jp, npzp = cache_paths(arm, seed)
    payload = {"signature": cache_signature(arm, seed),
               "row": {k: v for k, v in row.items() if k != "_raw"}}
    jt = jp.with_name(jp.name + ".tmp")
    jt.write_text(json.dumps(payload, ensure_ascii=False, indent=2, allow_nan=False),
                  encoding="utf-8")
    nt = npzp.with_name(npzp.name + ".tmp")
    with nt.open("wb") as fh:
        np.savez_compressed(fh, **row["_raw"])
    jt.replace(jp)
    nt.replace(npzp)


def load_cache(arm: str, seed: int) -> dict | None:
    jp, npzp = cache_paths(arm, seed)
    if not jp.exists() and not npzp.exists():
        return None
    if not jp.exists() or not npzp.exists():
        jp.unlink(missing_ok=True)
        npzp.unlink(missing_ok=True)
        return None
    payload = json.loads(jp.read_text(encoding="utf-8"))
    if payload.get("signature") != cache_signature(arm, seed):
        raise RuntimeError(f"QA1S6 cache signature mismatch {arm} s{seed}")
    with np.load(npzp, allow_pickle=False) as z:
        raw = {k: z[k] for k in z.files}
    return {**payload["row"], "_raw": raw}


def load_qa1s4_cache(arm: str, seed: int) -> dict | None:
    """QA1S4 の 7 seed cache を条件一致時だけ再利用する。"""
    jp, npzp = Q4.cache_paths(arm, seed)
    if not jp.exists() or not npzp.exists():
        return None
    payload = json.loads(jp.read_text(encoding="utf-8"))
    expected = Q4.cache_signature(arm, seed)
    if payload.get("signature") != expected:
        return None
    with np.load(npzp, allow_pickle=False) as z:
        raw = {k: z[k] for k in z.files}
    return {**payload["row"], "_raw": raw}


def _run_for_qa1s6(arm: str, seed: int) -> dict:
    """QA1S4 の _run を使いつつ、seed>=7 では QA1S2 baseline が無いので C1 比較をスキップする.

    QA1S4 の C1 校正（既存 QA1S2 eval/loss history との一致）は seed 0..6 で完了済みで、
    設計書 §3 は学習条件を QA1S4 と同一にするだけを要求する。seed>=7 に
    存在しない baseline json を要求するのは QA1S4 runner の 7-seed 前提であり、
    本次の estimand（崩壊確率）とは無関係なので、 Zug だけを差し替える。
    """
    if int(seed) < 7:
        return Q4._run(arm, seed, PROD_TAG)

    # seed>=7: QA1S4 の _run と同一の学習/eval を、C1 比較なしで実行する。
    import torch
    torch.set_num_threads(1)
    widths = Q4.Q2.ARMS[arm]
    box = []
    out = Q4.A4.run_one(
        arm=arm, seed=seed, scale=1.0, n_seqs=Q4.Q2.N_SEQS,
        epochs=Q4.Q2.EPOCHS, bs=Q4.Q2.BS, lr=Q4.Q2.LR, auxw=Q4.Q2.AUXW,
        gain="matched", eval_every=Q4.Q2.EVAL_EVERY, tag=PROD_TAG,
        widths_override=widths, act_override=Q4.ACTS, model_out=box,
        complete_gain_map=True)
    trained = box[0]
    model = Q4.POL.PolicyActMoE(widths, "relu", seed=seed, act_i=Q4.ACTS,
                                rng_seed=seed, policy="learned",
                                random_without_replacement=True)
    model.p = trained.p
    model.gain_l = dict(trained.gain_l)
    eval_rng = np.random.default_rng(Q4.Q2.EVAL_SEED)
    ev_seq, ev_typ = Q4.Q1.make_trace_batch(eval_rng, Q4.Q2.EVAL_N)
    raw = {p: Q4.POL.eval_policy(model, ev_seq, ev_typ, p, bs=128)
           for p in Q4.POLICIES}
    policy = {p: {"ce_all": float(r["ce_all"]), "ce_struct": float(r["ce_struct"]),
                  "ce_payload": float(r["ce_payload"]),
                  "instr_valid": float(r["instr_valid"]),
                  "instr_acc": float(r["instr_acc"])} for p, r in raw.items()}
    control_names = ("uniform", "random", "oracle")
    logits_diff = {}
    for i, a in enumerate(control_names):
        for b in control_names[i + 1:]:
            logits_diff[f"{a}_vs_{b}"] = Q4._maxdiff_numeric(
                raw[a]["first_logits"], raw[b]["first_logits"])
    p1 = bool(all(v > 0 for v in logits_diff.values()))
    oracle_topi = np.asarray(raw["oracle"]["topi"], dtype=np.int64)
    oracle_ty = np.asarray(raw["oracle"]["typ_flat"], dtype=np.int64).reshape(-1)
    expected = np.where(oracle_ty == Q4.Q1.TYP_PAYLOAD, len(Q4.ACTS) - 2, 0)
    agree = ((oracle_topi[:, 0] == expected) & (oracle_topi[:, 1] == expected + 1))
    p2_agreement = float(agree.mean()) if agree.size else 0.0
    uniform_coverage = int(np.unique(np.asarray(raw["uniform"]["topi"], dtype=np.int64)).size)
    random_topi = np.asarray(raw["random"]["topi"], dtype=np.int64)
    counts = np.bincount(random_topi[:, 0], minlength=Q4.N_POS // 4)
    share = counts / max(int(counts.sum()), 1)
    p4_dev = float(np.max(np.abs(share - 1.0 / (Q4.N_POS // 4)) / (1.0 / (Q4.N_POS // 4))))
    random_dup = float(np.mean(random_topi[:, 0] == random_topi[:, 1]))
    ce_values = [policy[p]["ce_all"] for p in Q4.POLICIES]
    p5 = bool(np.isfinite(ce_values).all() and max(ce_values) <= Q4.P5_LIMIT)
    iv_values = [policy[p]["instr_valid"] for p in Q4.POLICIES]
    p6_uninformative = bool(all(v in (0.0, 1.0) for v in iv_values))
    final_eval = out["evals"][-1]
    c7 = {"ce_all_diff": abs(float(final_eval["ce_all"]) - policy["learned"]["ce_all"]),
          "instr_valid_diff": abs(float(final_eval["instr_valid"])
                                  - policy["learned"]["instr_valid"])}
    c7["pass"] = bool(max(c7["ce_all_diff"], c7["instr_valid_diff"]) <= Q4.EPS_EVAL)
    tail_iv = [float(e["instr_valid"]) for e in out["evals"][-Q4.Q2.TAIL_K:]]
    tail_ce = [float(e["ce_all"]) for e in out["evals"][-Q4.Q2.TAIL_K:]]
    iv_main = float(np.median(tail_iv))
    ce_main = float(np.median(tail_ce))
    gate = Q4.Q2.tail_stats(out["loss_hist"])
    e_flag = bool((not np.isfinite(ce_main)) or ce_main > Q4.Q2.CE_ALL_LIMIT
                  or iv_main in (0.0, 1.0))
    e_plus = bool(iv_main >= Q4.Q2.IV_GATE_MIN)
    p_checks = {"P1_logits_distinct": p1, "P2_oracle_type_agreement": abs(p2_agreement-1.0) < 1e-12,
                "P3_uniform_coverage": uniform_coverage == Q4.N_POS // 4,
                "P4_random_usage": p4_dev < Q4.P4_MAX_REL_DEV,
                "P5_finite_and_bounded_ce": p5, "P6_not_endpoint_pinned": not p6_uninformative,
                "C7_same_checkpoint_eval": c7["pass"]}
    full_gain = out["gain"]["by_position"]
    return {
        "arm": arm, "seed": int(seed), "widths": list(widths),
        "width_sum": int(sum(widths)), "act_i": list(Q4.ACTS), "sec": float(out["sec"]),
        "loss_hist": [float(x) for x in out["loss_hist"]], "evals": out["evals"],
        "iv_series_tail": tail_iv, "iv_main": iv_main, "ce_all_main": ce_main,
        "T_plus": bool(gate["T_plus"]), "T": gate, "E_flag": e_flag, "E_plus": e_plus,
        "gain": {"mode": out["gain"]["mode"], "n": int(out["gain"]["n"]),
                 "min": float(out["gain"]["min"]), "max": float(out["gain"]["max"]),
                 "mean": float(out["gain"]["mean"]),
                 "by_expert": [float(v) for v in out["gain"]["by_expert"]],
                 "by_position": full_gain},
        "gain_key_count": len(full_gain),
        "gain_nonfinite": int(sum(not np.isfinite(v) for v in full_gain.values())),
        "same_p": bool(model.p is trained.p),
        "same_gain_l": bool(model.gain_l == trained.gain_l),
        "policies": policy,
        "P": {"logits_pair_maxdiff": logits_diff,
              "oracle_typ_agreement": p2_agreement,
              "uniform_expert_coverage": uniform_coverage,
              "random_usage_max_rel_dev": p4_dev,
              "random_topi_dup_rate": random_dup,
              "random_usage_counts": counts.astype(int).tolist(),
              "uninformative": p6_uninformative, "pass": p_checks},
        "C1_legacy_reproduction": {"pass": None, "note": "seed>=7: no QA1S2 baseline (QA1S6 design §3)"},
        "C7_final_eval_vs_policy_eval": c7,
        "_raw": {
            "first_logits": np.stack([np.asarray(raw[p]["first_logits"], dtype=np.float32)
                                       for p in Q4.POLICIES]),
            "random_topi": np.asarray(raw["random"]["topi"], dtype=np.int16),
            "oracle_topi": np.asarray(raw["oracle"]["topi"], dtype=np.int16),
            "uniform_topi": np.asarray(raw["uniform"]["topi"], dtype=np.int16),
            "typ_flat": np.asarray(raw["oracle"]["typ_flat"], dtype=np.int16),
        },
    }


def _worker(job: dict) -> dict:
    try:
        return _run_for_qa1s6(job["arm"], job["seed"])
    except Exception:
        return {"error": traceback.format_exc(), "arm": job["arm"], "seed": job["seed"]}


def write_partial(rows: list[dict], elapsed: float, n_jobs: int, n_cached: int) -> None:
    payload = {"phase": "partial", "n_done": len(rows), "n_jobs": n_jobs,
               "n_cached": n_cached, "elapsed_seconds": float(elapsed),
               "labels": {f"{r['arm']}_s{r['seed']}": collapse_label(r)[0] for r in rows}}
    p = HERE / "qa1s6_partial_metrics.json"
    t = p.with_suffix(".tmp")
    t.write_text(json.dumps(payload, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    t.replace(p)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--no-resume", action="store_true")
    ap.add_argument("--workers", type=int, default=PROD_DUP_N)
    args = ap.parse_args()

    out = {
        "tag": TAG, "phase": "QA1S6 production (collapse-rate estimand)",
        "design": "QA1S6課題設計書_崩壊確率をestimandにする場合の必要seed数を走行前に確定する_20261116.md",
        "design_s1": "検証報告_QA1S6S1_..._20261116.md (54 seed required, binom.sf check)",
        "no_seed_exclusion": True,
    }
    out["prereg"] = {
        "SEEDS": list(SEEDS), "ARMS": list(ARMS), "N_JOBS": len(SEEDS) * len(ARMS),
        "COLLAPSE_LOSS_RATIO": COLLAPSE_LOSS_RATIO, "COLLAPSE_CE": COLLAPSE_CE,
        "ESTIMAND": "Delta_collapse = P(COLLAPSE|w_mid) - P(COLLAPSE|w_ref)",
        "TEST": "McNemar exact binomial, two-sided alpha=0.05",
        "POWER_TARGET": "P(b>=6 | n=54, q=1/7) = 0.8022 (QA1S6 Step 1)",
        "WORKERS": args.workers,
        "LEARNING": "identical to QA1S4 (gain complete map, random without replacement)",
        "CACHE_REUSE": "QA1S4 cache for seed 0..6 only when signature matches",
    }

    jobs = [(arm, s) for arm in ARMS for s in SEEDS]
    rows: list[dict] = []
    errors = []
    t0 = time.time()
    n_cached = 0
    pending = []
    for arm, seed in jobs:
        row = None
        if not args.no_resume:
            row = load_cache(arm, seed)
            if row is None and seed < 7:
                row = load_qa1s4_cache(arm, seed)
                if row is not None:
                    save_cache(row)
        if row is not None:
            rows.append(row)
            n_cached += 1
        else:
            pending.append({"arm": arm, "seed": seed})
    out["n_cached"] = n_cached
    out["n_new"] = len(pending)
    print(f"[qa1s6] cached={n_cached} new={len(pending)} workers={args.workers}", flush=True)

    done = 0
    with ProcessPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(_worker, j): j for j in pending}
        for fu in as_completed(futs):
            r = fu.result()
            done += 1
            if "error" in r:
                errors.append(r)
                sys.stderr.write(f"[FAIL] {r['arm']} s{r['seed']}\n{r['error']}\n")
                sys.stderr.flush()
                continue
            rows.append(r)
            if not args.no_resume:
                save_cache(r)
            lab = collapse_label(r)[0]
            print(f"[{done}/{len(pending)}] {r['arm']} s{r['seed']} "
                  f"iv={r['iv_main']:.4f} label={lab} ({time.time()-t0:.0f}s)", flush=True)
            if done % 5 == 0:
                write_partial(rows, time.time() - t0, len(jobs), n_cached)

    out["runtime_seconds"] = float(time.time() - t0)
    out["errors"] = errors
    if errors:
        out["verdict"] = "INCOMPLETE"
        (HERE / f"{TAG}_metrics.json").write_text(
            json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        sys.stderr.write(f"[qa1s6] INCOMPLETE: {len(errors)} errors\n")
        sys.stderr.flush()
        return

    lookup = {(r["arm"], int(r["seed"])): r for r in rows}
    ordered = [(arm, s) for arm in ARMS for s in SEEDS]
    labels = {}
    for arm, s in ordered:
        row = lookup[(arm, s)]
        lab, spike, final_iv, final_ce, flag = collapse_label(row)
        labels[f"{arm}_s{s}"] = {
            "label": lab, "spike": spike, "final_iv": final_iv,
            "final_ce_all": final_ce, "collapse": flag,
            "loss_hist": [float(x) for x in row["loss_hist"]],
            "iv_series_tail": [float(x) for x in row["iv_series_tail"]],
        }
    out["labels"] = labels

    b = sum(1 for s in SEEDS
            if labels[f"w_mid_s{s}"]["collapse"] and not labels[f"w_ref_s{s}"]["collapse"])
    c = sum(1 for s in SEEDS
            if labels[f"w_ref_s{s}"]["collapse"] and not labels[f"w_mid_s{s}"]["collapse"])
    both = sum(1 for s in SEEDS
               if labels[f"w_ref_s{s}"]["collapse"] and labels[f"w_mid_s{s}"]["collapse"])
    neither = len(SEEDS) - b - c - both
    p_exact = (float(stats.binomtest(b, b + c, 0.5, alternative="two-sided").pvalue)
               if b + c > 0 else 1.0)
    n_mid = sum(1 for s in SEEDS if labels[f"w_mid_s{s}"]["collapse"])
    n_ref = sum(1 for s in SEEDS if labels[f"w_ref_s{s}"]["collapse"])
    out["confirmatory"] = {
        "estimand": "Delta_collapse = q_mid - q_ref",
        "q_mid": n_mid / len(SEEDS), "q_ref": n_ref / len(SEEDS),
        "delta_collapse": (n_mid - n_ref) / len(SEEDS),
        "b_mid_only": b, "c_ref_only": c, "both": both, "neither": neither,
        "n_discordant": b + c,
        "mcnemar_exact_p": p_exact, "alpha": ALPHA,
        "reject": bool(p_exact < ALPHA),
        "note": "McNemar は discordant pair のみを使う。b+c=0 なら p=1。",
    }

    # 既存の連続値 estimand は参考記録として残す（確認的家族へ混ぜない）
    iv_ref = np.asarray([lookup[("w_ref", s)]["iv_main"] for s in SEEDS], dtype=np.float64)
    iv_mid = np.asarray([lookup[("w_mid", s)]["iv_main"] for s in SEEDS], dtype=np.float64)
    out["reference_continuous"] = {
        "estimand": "mean_seed[iv(w_mid)-iv(w_ref)] (QA1S4 と同一、参考値のみ)",
        **Q2.paired_stats(iv_mid, iv_ref),
        "not_in_confirmatory_family": True,
    }

    def scan(o, path="root"):
        bad = []
        if isinstance(o, dict):
            for k, v in o.items():
                bad += scan(v, f"{path}.{k}")
        elif isinstance(o, list):
            for j, v in enumerate(o):
                bad += scan(v, f"{path}[{j}]")
        elif isinstance(o, float) and not np.isfinite(o):
            bad.append(path)
        return bad
    nf = scan(out)
    out["nonfinite_paths"] = nf
    out["verdict"] = "PASS" if (len(rows) == len(jobs) and len(nf) == 0) else "FAIL"

    # 軽量 npz（配列は崩壊ラベルと discordant pair だけ）
    np.savez_compressed(
        HERE / f"{TAG}_delta.npz",
        seeds=np.asarray(SEEDS, dtype=np.int64),
        collapse_mid=np.asarray([int(labels[f"w_mid_s{s}"]["collapse"]) for s in SEEDS]),
        collapse_ref=np.asarray([int(labels[f"w_ref_s{s}"]["collapse"]) for s in SEEDS]),
        final_iv_mid=np.asarray([labels[f"w_mid_s{s}"]["final_iv"] for s in SEEDS]),
        final_iv_ref=np.asarray([labels[f"w_ref_s{s}"]["final_iv"] for s in SEEDS]),
        iv_ref=iv_ref, iv_mid=iv_mid,
    )
    # 全 run の生データは JSON に残す（54×2 で数 MB）
    out["runs"] = [{k: v for k, v in r.items() if k != "_raw"} for r in rows]
    (HERE / f"{TAG}_metrics.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")

    cf = out["confirmatory"]
    lines = [
        f"tag={TAG}", f"verdict={out['verdict']}",
        f"n_runs={len(rows)} n_cached={n_cached} n_new={len(pending)} "
        f"runtime_seconds={out['runtime_seconds']:.1f}",
        f"q_mid={cf['q_mid']:.6f} q_ref={cf['q_ref']:.6f} delta={cf['delta_collapse']:.6f}",
        f"b={cf['b_mid_only']} c={cf['c_ref_only']} both={cf['both']} neither={cf['neither']}",
        f"mcnemar_exact_p={cf['mcnemar_exact_p']:.8g} alpha={ALPHA} reject={cf['reject']}",
        f"nonfinite={nf}", "",
    ]
    (HERE / f"{TAG}.log").write_text("\n".join(lines), encoding="utf-8")
    sys.stdout.write("\n".join(lines))
    sys.stdout.flush()


if __name__ == "__main__":
    main()
