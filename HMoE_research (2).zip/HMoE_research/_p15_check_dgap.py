# -*- coding: utf-8 -*-
"""P15 補助検算: dGap の規則間比較が無効であることの数値確認（使い捨て）"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
d = json.load(open(os.path.join(HERE, "p15_analysis.json"), encoding="utf-8"))
tb = {(r["pool"], r["rule"]): r for r in d["table"]}

for k in [("all", "s1"), ("clean", "confmax"), ("clean", "maj"),
          ("clean", "majnom"), ("clean", "confmaxF")]:
    r = tb[k]
    print("%-6s %-9s acc=%.4f conf=%.5f gap=%+.4f" % (k[0], k[1], r["acc"], r["conf"], r["gap"]))

print("")
print("clean confmax vs clean maj: acc %.6f vs %.6f, gap diff %+.4f"
      % (tb[("clean", "confmax")]["acc"], tb[("clean", "maj")]["acc"],
         tb[("clean", "confmax")]["gap"] - tb[("clean", "maj")]["gap"]))
s1gap = tb[("all", "s1")]["gap"]
print("s1 gap = %+.4f" % s1gap)
for rule in ["confmax", "confmaxF", "maj"]:
    g = tb[("clean", rule)]["gap"] - s1gap
    da = tb[("clean", rule)]["acc"] - tb[("all", "s1")]["acc"]
    print("  clean %-9s dGap %+.4f   -dAcc %+.4f   (差 %+.4f)" % (rule, g, -da, g + da))
