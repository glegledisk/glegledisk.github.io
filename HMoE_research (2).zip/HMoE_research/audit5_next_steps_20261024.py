# -*- coding: utf-8 -*-
"""audit5_next_steps_20261024.py
推奨作業の根拠を数値で固める:
  A. 既存の品質データ (cache_train_summary_full.csv) のアーム間比較 — 未使用の資産
  B. GPU の有無
  C. オフロードモデルの T_comp を「期待値」に直したときの overlap 比の変化
"""
import os, json
import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
SIM = os.path.join(HERE, "simulation_hmoe_mmlu")

# ---------- A. 品質 ----------
print("=== A. 既存 test_acc のアーム間比較 (5 arms x 3 seeds x 3 tasks = 9) ===")
df = pd.read_csv(os.path.join(SIM, "cache_train_summary_full.csv"))
g = df.groupby("arm")["test_acc"]
summary = g.agg(["mean", "std", "min", "max", "count"]).sort_values("mean", ascending=False)
print(summary.round(5).to_string())
print("\n 最大-最小 = %.5f (%.2f pp)" % (summary["mean"].max() - summary["mean"].min(),
                                        100*(summary["mean"].max() - summary["mean"].min())))
print(" 全体の標準偏差 = %.5f" % df["test_acc"].std())

# 対応のある検定: (seed, task) を揃えて U+LB と各アームを比較
print("\n U+LB を基準とした対応差 (seed, task で対応, n=9):")
piv = df.pivot_table(index=["seed", "task"], columns="arm", values="test_acc")
base = piv["U+LB"]
rows = []
for arm in piv.columns:
    if arm == "U+LB":
        continue
    d = piv[arm] - base
    # 対応のある t 統計量（正規近似）
    t = d.mean() / (d.std(ddof=1) / np.sqrt(len(d)))
    rows.append({"arm": arm, "delta_pp": 100*d.mean(), "sd_pp": 100*d.std(ddof=1),
                 "t": t, "n": len(d)})
print(pd.DataFrame(rows).round(4).to_string(index=False))
print(" ※ |t| < 2.3 は 5% で有意でない（df=8 の両側臨界値 2.306）")

# ---------- B. GPU ----------
print("\n=== B. GPU ===")
import torch
print(" torch.cuda.is_available() =", torch.cuda.is_available())
print(" torch version =", torch.__version__)

# ---------- C. T_comp の期待値化 ----------
print("\n=== C. T_comp を最悪値→期待値に直したときの overlap 比 ===")
d, nE, nL = 4096, 8, 32
w_u = np.array([14336]*nE, float)
w_h = np.array([4096,6963,9830,12697,15564,18431,21298,25809], float)
p_u = np.array([1.0/nE]*nE)
p_h = np.array([0.34,0.24,0.14,0.10,0.07,0.05,0.03,0.03]); p_h /= p_h.sum()
par_u, par_h = 3*d*w_u, 3*d*w_h
LBB = 8.0e9/nL
TOP_K = 2

def place(par, b_res, b_host, p):
    cur, res, byt = 0.0, [], np.zeros(len(par))
    for i in range(len(par)):
        if cur + par[i]*b_res <= LBB:
            res.append(i); cur += par[i]*b_res; byt[i] = par[i]*b_res
        else:
            byt[i] = par[i]*b_host
    return np.array(res), byt

arms = {
 "Uniform_4bit": (par_u, p_u, 0.5, 0.5),
 "Uniform_2bit": (par_u, p_u, 0.25, 0.25),
 "HMoE_4bit":    (par_h, p_h, 0.5, 0.5),
 "HMoE_2bit":    (par_h, p_h, 0.25, 0.25),
 "HMoE_Tiered":  (par_h, p_h, 1.0, 0.25),
}
print(" %-14s %6s %6s %10s %10s %10s %8s %8s" %
      ("arm","res","hit","trans_MB","comp_worst","comp_exp","ov_worst","ov_exp"))
out = {}
for name, (par, p, br, bh) in arms.items():
    res, byt = place(par, br, bh, p)
    host = [i for i in range(nE) if i not in res]
    psel = np.minimum(1.0, p*TOP_K)
    trans = sum(psel[i]*byt[i] for i in host)/1e6      # MB
    t_trans = trans*1e6/(25e9)*1e6 + 5.0               # MB -> bytes -> s -> us
    comp_worst = sum(byt[i] for i in res)/1e6          # bytes / (1000 GB/s) -> us
    comp_exp = sum(psel[i]*byt[i] for i in res)/1e6    # 同上（期待値）
    print(" %-14s %5d/8 %5.1f%% %10.2f %10.1f %10.1f %8.2f %8.2f" %
          (name, len(res), 100*p[res].sum(), trans, comp_worst, comp_exp,
           t_trans/comp_worst, t_trans/comp_exp))
    out[name] = {"res": int(len(res)), "hit": float(p[res].sum()), "trans_MB": float(trans),
                 "t_trans_us": float(t_trans), "comp_worst_us": float(comp_worst),
                 "comp_exp_us": float(comp_exp),
                 "ov_worst": float(t_trans/comp_worst), "ov_exp": float(t_trans/comp_exp),
                 "prefetch_layers_worst": float(t_trans/comp_worst),
                 "prefetch_layers_exp": float(t_trans/comp_exp)}
print("\n 先読み必要層数（= t_trans / t_comp）:")
for k, v in out.items():
    print("  %-14s 現行(最悪) %5.1f 層 → 期待値 %5.1f 層" %
          (k, v["prefetch_layers_worst"], v["prefetch_layers_exp"]))
json.dump(out, open(os.path.join(HERE, "audit5_next_steps.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved audit5_next_steps.json")
