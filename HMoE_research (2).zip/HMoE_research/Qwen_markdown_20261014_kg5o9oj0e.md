# 次世代不均一MoE専用チップ（Heterogeneous MoE Accelerator）設計構想と技術議論

**作成日**: 2026年
**テーマ**: 不均一なエキスパート（Heterogeneous MoE）を最高効率で駆動する専用ハードウェアアーキテクチャと、それによるAIモデルの進化

---

## 1. 基本アーキテクチャ（ハードウェア設計構想）
現在の「巨大な長方形の行列計算（GEMM）を一斉に処理する」GPU/TPUアーキテクチャの限界を突破するための4つの革新的設計。

### 1.1 カメレオン・コア（動的再構成可能シストリックアレイ）
*   **アイデア**: 計算ユニット（PEアレイ）の「形」を瞬時に組み替える。
*   **機能**: ルーターの判断に基づき、タイル単位でデータパスを数クロックで切り替え。大きなエキスパートには巨大な計算エンジン、小さなエキスパートには細長いエンジンを動的に構築。
*   **メリット**: パディングによる無駄をゼロにし、シリコン面積を100%活用。

### 1.2 ハードウェア・ルーター内蔵「PIM」（メモリ内計算）
*   **アイデア**: 重みを取りに行くのではなく、メモリの中で計算・ルーティングする。
*   **機能**: 3D積層技術を用い、HBMベースダイにPIMとハードウェア・ルーターを配置。トークン到着時にCPUを介さず直接ルーティングし、メモリ内で計算。
*   **メリット**: メモリ帯域のボトルネック解消。不均一なエキスパートの柔軟なメモリ配置。

### 1.3 非同期トークン・データフロー・アーキテクチャ
*   **アイデア**: 「全員一斉（同期）」をやめ、トークンが自ら最適な計算ユニットを探しに行く。
*   **機能**: グローバルクロック同期を捨て、NoC（Network on Chip）上でデータ駆動（データフロー）処理。処理完了次第、次の層へ自律的に移行。
*   **メリット**: エキスパートの処理時間差による「待ち（バブル）」を完全排除。稼働率の劇的向上。

### 1.4 ネイティブ動的スパース・テンソルコア
*   **アイデア**: 行列を「スカスカ」なまま超高速計算する。
*   **機能**: 「2:4スパース」などの静的スパースではなく、完全な動的スパース（非ゼロ要素リスト）をペナルティなしで計算。
*   **メリット**: エキスパートサイズを気にせず、有効な計算のみを実行。

---

## 2. 製造コストと歩留まりの課題（現実解）
この理想をシリコン上で実現するための製造上の壁と、それを回避する設計戦略。

### 2.1 モノリシック化の限界とレチクルサイズ
*   **課題**: 4機能を1ダイに詰め込むとレチクルサイズ限界（約800mm²）を超え、歩留まりが指数関数的に悪化。
*   **現実解**: **Chiplet & Advanced Packaging**。計算タイルは最先端プロセス、I/Oやルーターは成熟プロセスで製造し、2.5D/3Dパッケージング（CoWoS等）で統合。

### 2.2 カメレオン・コアの「配線とMUXの罠」
*   **課題**: 動的再構成のためのマルチプレクサと配線が面積を圧迫し、面積効率を悪化させる。
*   **現実解**: タイル単位の粗粒度再構成に留め、タイル間接続は**シリコンフォトニクス（光配線）**で代替。

### 2.3 PIM内蔵HBMの「KGD問題」と熱設計
*   **課題**: ロジックとDRAMの積層によるKnown Good Die (KGD) 問題と、DRAMの熱耐性限界。
*   **現実解**: ベースダイには熱を出さないルーターとキャッシュのみを配置し、演算は隣接Chipletで行う**PNM（Processing Near Memory）**アプローチを採用。

### 2.4 非同期回路のEDA/テストの壁
*   **課題**: 静的タイミング解析が不可能で、テストコストが跳ね上がる。
*   **現実解**: **GALS（Globally Asynchronous, Locally Synchronous）**。コア内部は同期、コア間は非同期とするハイブリッド構成。

---

## 3. AIモデルへの影響（コンテキスト・出力・マルチモーダル）
チップがもたらす「認知プロセス」の進化。

### 3.1 伸縮する記憶（Elastic Memory）
*   **特徴**: 固定ウィンドウではなく、重要度に応じた動的スパース化。
*   **機能**: 重要記憶はDenseに、背景知識はSparseに圧縮。PIMによる仮想メモリ的な検索。
*   **結果**: 事実上の「無限コンテキスト」を実現。

### 3.2 可変深度推論（Variable Depth Reasoning）
*   **特徴**: トークンごとの計算量（FLOPs）が動的に変化。
*   **機能**: 簡単な単語はSystem 1（極小エキスパート）で即答。複雑な推論はSystem 2（巨大エキスパート）を形成して熟考。
*   **結果**: 超長文生成でも論理破綻しない一貫性のある思考。

#### 3.2.1 深度コホート・スケジューラ（Depth-Cohort Scheduler）
バッチ内でトークンごとに停止・継続が分かれると、通常の固定幅SIMD/SIMT実行では停止済みレーンが空回りする。これを「同期をなくす」ことで解決したとはみなさず、継続トークンを短い反復境界で詰め直し、実行単位をそろえる。

*   **トークン状態**: 各トークンの隠れ状態、ループ回数、継続確率、次に必要な演算（expert IDを含む）を小さな状態記述子として保持する。反復演算中はそのトークン状態をオンチップ SRAM に置き、停止・退避・再投入のたびに HBM へ書き戻さない。
*   **深度別待ち行列**: 継続判定後、停止トークンは完了キューへ移し、継続トークンは「次の反復深度 × 演算種別 × expert/配置先」で分類したキューへ投入する。ハードウェアは同じ演算を要する複数キューからトークン状態を詰め合わせ、幅の合う実行タイルへ送る。
*   **短い待ち時間と容量上限**: コホートは目標サイズに達した時点、または最大待ち時間に達した時点で発行する。これにより小バッチの待ち行列遅延を制限し、十分なトークン数があるときは深さ別にまとめて演算器の空レーンを減らす。最大深度、キュー容量、待ち時間はソフトウェアから設定可能にする。
*   **状態容量の上限**: SRAMに保持できる反復中トークン数を明示し、上限時は新規反復の受け入れを抑制する。演算を終えた状態から解放し、必要なら低優先度キューを退避する。状態の外部退避を選ぶ場合は転送遅延と帯域を性能モデルに含め、無料の保管領域として扱わない。
*   **戻り先の追跡**: トークン記述子に要求IDと系列内位置を持たせ、異なる深さのコホートから戻った結果を正しい系列へ戻す。完了トークンは同じ要求の次の生成段階へ進め、未完了トークンだけを次のコホートに残す。
*   **局所性を含む発行判断**: キュー選択では待ち時間だけでなく、expertの配置先、転送量、現在の負荷も考慮する。小さなバッチを遠隔expertへ即時送るか、待って近接トークンとまとめるかは、設定された遅延上限内で選ぶ。配置のないexpertや満杯のキューには明示的な待機・退避経路を設ける。

この機構が扱うのは、モデルが独立に反復できる推論区間（例: ループ型ブロック内の反復FFN）である。attention が要求するトークン間集約、層境界、expert-parallel の dispatch/combine は残るため、それらの全体同期を除去するものではない。コホート化はバッチ内の深度差を吸収するスケジューリングであり、ゼロバブルや常時高稼働を保証しない。

### 3.3 モダリティ固有の脳野と非同期感覚統合
*   **特徴**: 画像・音声・テキストで異なる物理的リソース配分。
*   **機能**: 視覚は幅広アレイ、聴覚は時間軸特化アレイなど、カメレオン・コアが形状変化。
*   **結果**: 人間の脳に近い、感覚器ごとの並列処理と非同期な融合。

---

## 4. System 1（Jev）との融合
**Jev (TypeSafe AI, 2026)** とのハードウェア×ソフトウェア共進化。

### 4.1 Jevの概要
*   **定義**: テキスト生成ではなく「構造化された決定（判定・確率）」を出力するSystem Oneモデル。
*   **特徴**: 従来のLLMより200倍高速、400倍低コスト。

### 4.2 チップとの関係
*   **ハードウェア・ルーターとしてのJev**: チップ上のPIMがJev的な「超高速な扁桃体」として機能。System 2（熟考）が必要かをミリ秒で判定し、カメレオン・コアを起動。
*   **Jevons Paradox（ジェボンズの逆説）**: System 1（Jev）が安価になると、AIは過剰に内省・確認を行うようになり、System 2の需要が爆発する。このチップはその計算爆発を支える唯一のインフラとなる。

---

## 5. ツールユースの革新
現在の同期待ち・コンテキスト膨張からの解放。

### 5.1 非同期ディスパッチとゼロレイテンシ
*   **機能**: テキスト生成を介さず、PIM上のルーターが直接ツール実行キューへリクエスト。
*   **結果**: ツール呼び出し判断がマイクロ秒単位に。

### 5.2 待ち時間の消滅と投機的実行
*   **機能**: 外部APIの結果待ちの間も、非同期NoCによりメインの推論スレッドは継続。
*   **結果**: ツール実行中に思考を停止しない（並列タスク処理）。

### 5.3 コンテキスト汚染防止
*   **機能**: ツール出力（大量の検索結果）をネイティブ動的スパースコアが即座に圧縮・抽出。
*   **結果**: 10,000トークンのツール出力を取り込んでも、KVキャッシュは爆発しない。

---

## 6. ループTransformerとのシナジー
「思考の深さ（時間）」を動的にするモデルとの融合。

### 6.1 ACT（適応的計算時間）のバブル緩和
*   **課題**: トークンごとのループ回数差による同期待ち。
*   **解決案**: 深度コホート・スケジューラ（3.2.1）で、Haltしたトークンを完了キューへ抜き、継続トークンを深度・演算種別・expert配置先ごとに再編成する。次の反復は短い待ち時間またはコホート容量で発行し、深度が異なるトークンを同一固定バッチに残す割合を下げる。
*   **制約**: 改善対象は反復ブロック内のレーン利用率と反復間待ちであり、attention、層境界、all-to-all の待ち時間は別に測る。負荷が薄い場合はコホート形成自体が遅延を加えるため、待ち時間上限と即時発行の fallback が必要。

### 6.2 思考深度に応じたコア変形
*   **機能**: 自由な配線再構成ではなく、設計時に用意した少数のタイル形状（幅優先、幅狭・深パイプライン等）から、コホートの演算種別・形状・深さに合うものを選ぶ。タイル間のトークン状態移送はオンチップ SRAM と限定された gather/compact 経路で行い、形状切替は反復境界でのみ実施する。
*   **制約**: 切替可能な形状数、切替遅延、compact回路の面積・電力を実装パラメータとして明示する。専用形状の追加は常に得とは限らず、通常の固定形状タイル群を基準に比較する。

### 6.3 PIMによるループ制御
*   **機能**: Continue/Halt の判定は、反復結果が既にある演算タイル近傍で実行し、1-bit判定と状態記述子更新をコホート待ち行列へ直接反映する。判定のためだけにHBM内のPIMへ往復させない。
*   **制約**: 継続判定はモデルのACT/停止関数の意味を保つ。キュー混雑や通信費を見てトークンの継続回数そのものを勝手に変更してはならず、スケジューラは発行順とまとめ方だけを決める。

---

## 7. 情報密度適応型の入力単位とMoEルーティング
テキストを特定expertへの命令に変換するのではなく、入力の粒度・文脈表現・実行コストを分離して扱う。tokenizerやルーターの静的タグだけで実行先を固定しない。

### 7.1 ルーティング補助メタデータ
*   **機能**: 必要に応じて、byte/token範囲、予測entropy、数式・コード構造候補、境界信頼度を入力に付随させる。これらは語彙IDに埋め込んだ固定expert IDではなく、実行ごとに作る補助特徴とする。
*   **ルーティング**: 文脈hidden stateを主入力とする学習routerに、信頼度でゲートした特徴残差を加える。概念的には `z[t,e] = z_base[t,e] + confidence[t] × residual_e(features[t])`。最終選択にはrouterの学習済み判断と、後段の容量・遅延・通信制約を使う。`Math → Expert_A` のようなハードコードはしない。

### 7.2 情報密度適応型の専門家ルーティング単位
**仮説**: 入力を固定語彙のtoken数だけで扱わず、byte列の局所的不確実性と文脈から可変長のspanを作り、spanをMoEのルーティング・バッチ化単位として使う。ここでいう「情報密度」は意味的重要度そのものではなく、まず次byte予測entropyなどで測る局所的な不確実性である。高entropyは必ずしも難しい推論を意味せず、低entropyのコードや定型文が意味的に単純とも限らない。

#### 段階A: 既存token/KVを保つspan routing
*   **正準表現**: byte列、既存token ID、位置、因果attentionは維持する。その上に `[start, end)`、byte/token長、平均・最大entropy、文字種/構造候補、境界信頼度を持つ一時的なspan記述子を作る。新語彙の追加や既存embeddingの置換を最初の実験要件にしない。
*   **境界**: causal entropy predictorが予測しやすい範囲を長めのspan、不確実性が上がる境界を短めのspan候補とする。最大長・最小長・低信頼fallbackを設ける。生成時は確定済みprefixのspan境界を後から無効化しない。再分割が必要な方式は、対象request/KVを同じtokenizer・patcher版にpinするか、明示的な再計算費用を払う。
*   **専門家の選択**: 各spanの文脈表現 `h_i`、byte entropy `H_i`、長さ `L_i`、構造特徴 `q_i` を組み合わせてrouter logitを作る候補を置く。

```text
z[i,e] = w[e]·h[i] + a[e]·H[i] + b[e]·log(1 + L[i]) + u[e]·q[i]
```

最初はactive top-kを固定し、entropyだけ、長さだけ、文脈hiddenだけ、各特徴の組合せを比較する。可変top-kや異なる幅/深さのexpertは、どのspanがどれだけ品質を得るかを測った後の段階にする。expertの専門性は学習で獲得させ、意味ラベルから固定的に決めない。
*   **負荷会計**: 可変長spanを個数だけで数えると長いspanの処理量を過小評価する。同じ形状のexpertではbyte coverageまたは正準token数でload-balanceを測る。expert形状を不均一にする段階では、byte数だけでなくプロファイルしたactive FLOPs、メモリ帯域、実測service timeを容量制約に使う。
*   **計算上の境界**: 正準tokenごとにexpert FFNを実行し、span内でexpert選択だけを共有する段階Aでは、MoE router呼出し・dispatch descriptor数を `T` から `S`（正準token数`T`、span数`S`）へ下げられる可能性がある。一方、各tokenのexpert演算量とhidden payloadは概ね`O(T)`のままで、総FLOPsやall-to-all bytesが同じ割合で下がるとは限らない。境界抽出、span pooling、gather/scatterの費用も含めて測る。
*   **KV**: 段階AではKVを削減したと主張せず、token位置を維持する。KV圧縮まで狙う段階Bでは、byte/patch encoder・global patch Transformer・byte decoderを備えるlatent patch型モデルへ進む。global層の系列長が減ってもlocal encoder/decoderの状態とbyte-offset対応表が残るため、総KV/activation byteを別計測する。

#### 先行研究と、この案で残る問い
Byte Latent Transformer (BLT) はbyte entropyを使った可変長patchで主計算の頻度を調整し、Charformerは学習可能なsubword境界をモデルへ組み込んだ。2026年のbyteification研究は既存dense LLMをbyte-levelへ段階変換する方法を示したが、MoE expertの再編や本チップの実証ではない。さらに近い [EntropyMoE](https://arxiv.org/abs/2608.06398) は、BLT型のdynamic byte patchをTop-2 routing unitとし、entropy-only routerとbyte-weighted workloadを評価した。このため「entropy patchを作ってentropyでexpertを選ぶ」だけを新規性とは主張しない。

EntropyMoEのBLT-1B継続学習実験では、比較対象よりheld-out BPBが低く、downstreamは概ね同等だった。一方、評価は一つのdense初期checkpointからの2つの継続seedで、著者らはfunctional expert specializationを立証していない。長さだけを使う対照実験も未完了で、疎実装はdense BLTのおよそ2倍の学習時間を要した。次の研究寄与候補は、(1)文脈hidden＋entropy＋構造特徴の要因分離、(2)日本語・数式・コード・多言語での長さ/entropy交絡の評価、(3)span長とexpert実測コストを合わせた負荷会計、(4)不均一expert幅や可変top-kを品質/計算予算下で選ぶ方法、(5)既存MoE checkpointへの安全な適応、である。

#### 最小比較実験
同じbyte stream、初期checkpoint、学習byte数、更新数で、①既存subword + token-wise hidden router、②BLT-style patch + dense FFN、③patch + hidden-only MoE、④EntropyMoE相当のentropy-only、⑤length-only、⑥hidden + entropy + structure router、⑦entropy/lengthをシャッフルした対照を比較する。tokenizer間の品質比較はperplexityだけでなくbits-per-byte (BPB)で行う。

品質はBPBと日本語・数式・コード・綴り揺れを含むtask評価、効率はbyte/s・総学習/推論FLOPs・router calls/byte・dispatch packet数とpayload bytes・all-to-all時間・p50/p99 latency・energy/byteで評価する。専門性はexpert利用率だけで判断せず、entropy/構造別の選択差、負荷集中、expert ablation時の品質低下、routing featureをshuffleしたときの損失変化で検証する。合格条件は、同じbyte予算と品質許容幅`δ`の下で、総費用または遅延を実測改善するか、同じ費用で品質を改善することとする。

### 7.3 構造化依存グラフ（疎な依存サイドカー）
**トークン列と因果マスクは維持し、依存グラフは補助メタデータとして重ねる。** 1D列をグラフへ置き換えたり、すべての注意をグラフ辺だけに制限したりする案ではない。狙いは、トークン間の参照関係を使って「どのexpert容量が要りそうか」「どのKVを優先して残すか」「expertをどこへ置けば通信が減るか」を改善すること。

*   **グラフ表現**: ノードは既存トークン位置を参照する。辺は有向・型付き（例: 係り受け、代名詞と先行詞、コードの定義と使用、数式の変数参照）とし、信頼度を持たせる。各トークンの辺数を上限`K`で制限し、優先順位の低い候補は捨てる。サブワードへトークン化した既存語彙は変えず、単語・識別子の範囲とトークン位置の対応表を持つ。
*   **因果性と更新**: prompt prefill では利用可能な文脈から関係を推定し、生成時は現在までのprefixだけで辺を追加・更新する。将来の生成トークンを参照した辺を過去位置のルーターや予測へ渡さない。外部構文解析器が必要なら、その遅延・誤り・言語依存性も計測対象にする。
*   **HMoEルーターへの利用**: 各トークンの現行hidden stateから作る特徴と辺の型・距離・信頼度を集約し、元のロジットへ小さな学習可能残差を加える。概念的には`z[t,e] = z_base[t,e] + confidence[t] × residual_e(graph_features[t])`。最初の版では辺先の全hidden/KVを再読込せず、ノード役割などの小さなサイドカー特徴だけを使う。隣接ノードの圧縮状態も読む設計に進む場合、その状態キャッシュのbyte数と読み出し時間を別途加算する。グラフ次数が大きいだけで「難しい」と決めつけず、損失改善が計算費用に見合うと学習された場合だけ大きなexpertの確率を上げる。グラフ信頼度が低い場合は残差をゼロへ寄せ、元のルーターへ戻す。
*   **expert配置への利用**: 推論traceから、依存関係で結ばれたトークンが実際に選んだexpertの組み合わせを集計する。共起頻度と通信量が十分大きい組だけを配置の近接候補にする。グラフがルーティングを強制するのではなく、実測された共起を配置・局所キャッシュの弱い事前情報として使う。配置を変えても元のルート選択とモデル関数は保つ。
*   **KV管理への利用**: グラフ辺は既存のKV位置を参照するだけで、辺ごとにK/Vベクトルを複製しない。最初の実験ではKVを一切削らず、依存情報を付けるメタデータ費用だけを測る。次段階でのみ、同一のKV byte予算の下で「直近トークン + attention heavy hitter + 高信頼な参照先」を保持候補にし、低得点候補を退避・圧縮する。依存辺は保持の補助点であって、無制限の固定保持を意味しない。辺で指された情報をKVから落とすと参照情報だけでは内容を復元できないため、品質低下を必ず評価する。

#### 計算量・容量の見積もり
系列長を`N`、1トークンあたり最大辺数を`K`、辺インデックス・型・信頼度の格納幅をそれぞれ`b_idx`, `b_type`, `b_conf` byte、行ポインタ幅を`b_ptr` byteとすると、グラフサイドカー容量はおおよそ

```text
M_graph ≈ N × K × (b_idx + b_type + b_conf) + (N + 1) × b_ptr
```

となる（アラインメント、逆辺、ブロック索引は別途加算）。グラフ特徴を`L_moe`層のルーターへ集約する追加計算は、特徴幅を`d_g`として概ね`O(L_moe × N × K × d_g)`。隣接ノードの圧縮hidden sketchを保存する設計なら、さらに`M_sketch = N × L_moe × d_g × b_sketch` byte（量子化/圧縮後幅`b_sketch`）を加える。辺候補を見つける構文解析・関係予測の費用も別項として実測する。通常の因果attentionは変更しないので、その計算量もKV本体容量もこの方式だけでは減らない。グラフattentionに置き換えた場合の理論計算量は`O(|E| × d)`へ下げられるが、疎アクセスの不規則性、カーネル効率、グラフ予測費用があるため、理論上の辺数削減を実速度向上と同一視しない。

#### 性能向上の仮説と限界
1. **品質**: 遠距離の照応・定義使用関係をルーターの容量判断に補助できれば、重要な参照関係を含む処理で大きなexpertを適切に使える可能性がある。ただし既存のattentionも依存を学習できるため、改善は未検証仮説。
2. **計算効率**: 易しいトークンを小expertへ保ち、難しい文脈に大きな容量を割り当てる判断を助け、平均activated parametersを下げられる可能性がある。ルーター残差の計算・グラフ予測が節約分を超えないことが条件。
3. **通信**: 共起traceを配置へ反映し、expert間all-to-allの通信を減らせる可能性がある。グラフだけで配置を決めず、実際のsource/destination、転送byte、負荷、品質を含めて決める。
4. **KV容量**: 固定byte予算内で不要な過去KVをより安全に置き換えられるかを検証する。グラフメタデータ自体は追加容量を使い、KV削減率も品質も保証しない。

#### 検証順序
1. **基準trace**: HMoEの元ルーターと通常attention/KVを固定し、分野別品質、per-token expert選択、activated parameters、負荷、dispatch/combine通信量、KV容量を記録する。
2. **グラフルーターのみ**: attentionとKVを変えず、ベースライン、信頼度なし、信頼度付きのルーターを比較する。評価は言語モデリング損失に加え、照応・コード定義使用・数学記号参照などの長距離依存タスクを含める。
3. **配置のみ**: ルーターを固定し、グラフ関係つきroute traceによるexpert配置で通信時間と負荷が変わるかを比較する。
4. **KV方策**: 最後にKV byte予算を固定して比較し、長文想起精度、困難例の誤答、p50/p95遅延、throughput、graph metadata込みの総メモリを測る。

すべての段階でグラフ抽出時間、`M_graph`、ルーターの追加演算、品質差`δ`を報告する。採用条件は、事前に定めた品質下限（例: `Score >= Score_base - δ`）を満たしつつ、activated FLOPs、all-to-all時間、または総KV byteのいずれかを実測で改善すること。

### 7.4 計算時間メタデータ
*   **機能**: `[Compute_Budget: High]` フラグにより、ループTransformerのACT（思考深さ）を事前制御。

### 7.5 学習誘起型の専門分担とHMoE協調設計
**設計命題**: expertを「数学担当」「コード担当」のように人が先に分類するのではなく、次token損失を下げる学習を通じて、routerの選択領域とexpertの処理関数が同時に分化するかを検証する。ただし、学習すれば必ず人間に読める分野別expertができる、という主張ではない。ここでまず狙うのは、入力条件ごとに再現性のある**機能的な損失低減**がexpertまたはexpert群に生じることである。

#### ルーティングと専門性は何を指すか
層`l`のtoken表現を`h_t`、router重みを`W_r`、expert関数を`F_e(·; θ_e)`とすると、代表的なtop-k MoEは概念的に次のように書ける。

```text
g_t = W_r h_t + b_r
p_t = softmax(g_t)
S_t = TopK(p_t, k)
y_t = h_t + Σ(e ∈ S_t) p[t,e] F_e(h_t; θ_e)
L = L_next-token + β L_balance + λ C_hardware
```

次token損失から選ばれたexpertの重み`θ_e`とrouterのゲート重みへ学習信号が戻り、各expertは自分に届いた表現・誤差の分布に合わせて変化する。routerもその出力が損失を下げるか、負荷制約に適合するかを学ぶ。したがって分担は、routerだけ、またはexpert重みだけから生じるのではなく、**表現`h`・選択`S`・expert関数`F`の共適応**である。top-kの離散選択と負荷制約の勾配経路は実装依存なので、使用するゲート勾配、補助損失、noiseやcapacity/drop規則を実験条件として明記する。

「専門性」は少なくとも次の4段階に分ける。ルート利用の偏りだけを上位の機能性の証拠にしない。

*   **ルーティング分化**: 入力の表現・文脈が変わると選択されるexpertが変わる。
*   **機能的分化**: 特定条件下でexpertを除去・置換すると、その条件の損失やタスク性能が悪化し、別条件とは異なる因果的寄与がある。
*   **意味的解釈可能性**: 「算術」「構文」のような人間のラベルで選択傾向を説明できる。これは追加の強い性質で、機能的分化に必須とは限らない。
*   **計算資源上の分化**: 品質寄与・頻度・service timeに応じて異なる幅、精度、配置を与えても品質制約を満たす。これは意味分野の分化とは別に測る。

#### 固有ベクトルとの関係
固有ベクトルやSVDは、ある層・データ集合におけるhidden stateの分散方向を記述する**分析基底**になり得る。線形routerでは`g = W_r h`なので、表現が似たtokenはlogitも似やすく、同じexpert群へ集まりやすい。データ行列`H = UΣVᵀ`の右特異ベクトル`V`を使い、routerがどの表現方向を拾うか、負荷分散損失で共有方向の影響が弱まるかを調べられる。

しかし標準MoEの学習が固有分解を実行してexpertを作るわけではない。**1本の固有ベクトルが1人のexpertに対応する保証はない**。routerのlogit領域は重なり得て、expert関数は非線形であり、expert ID自体も同じ重みとrouter行を一緒に置換すれば変わらないラベルである。加えて`V`は層・文脈・コーパス・学習段階で変わり得る。したがって固有方向は、初期化候補または機構解析として扱い、分担形成の原因や意味ラベルとして先に固定しない。2026年のpreprint [The Myth of Expert Specialization](https://arxiv.org/abs/2604.09780)は、線形routerの選択がhidden-state幾何と強く関係し、load-balance lossが共有方向を抑える機構を理論・複数モデル分析で示す一方、route patternの人間可読性やpromptから生成rolloutへの安定性は弱いと報告している。preprintの理論仮定・評価範囲を越えて一般法則とはみなさない。

#### 学習で分担が形成される仮説と崩れ方
1. **初期の探索と選択**: 学習初期のrouteはrouter初期化が作る暫定分割で、均等とは限らない。初期化、router noise、top-k、バッチ内の表現多様性で最初の負荷差が変わる。
2. **誤差に応じた局所適応**: expertが受け取ったtoken/文脈の誤差統計に応じて別々に更新され、ある入力領域での損失低下が生じる。
3. **正のフィードバック**: よく選ばれたexpertは多く学び、さらに選ばれる可能性がある。極端になると他expertが学習機会を失うexpert starvation / route collapseとなる。load-balance損失は利用の偏りを抑えるが、均等利用は機能的分担や効率の証明ではない。
4. **重複と協働**: 同じexpertが一般的な構文・推論計算を担い、他が周辺の細部を補う構成や、単独expertではなく複数層にまたがるexpert群の協働もあり得る。全expertを独立した分野担当とみなさない。
5. **過剰分化・分布移動**: 狭いデータへ過適応すると、分担が再現しない、文脈変更でrouteが変わる、OODで有用なexpertを選べない可能性がある。routerを性能報酬で直接最適化する[研究](https://aclanthology.org/2025.findings-emnlp.1282/)でも、知識の重なりを残して過剰専門化による性能崩壊を抑える案が報告されている。

先行研究の結論は一枚岩ではない。[DeepSeekMoE](https://aclanthology.org/2024.acl-long.70/)は細分化expertとshared expertで柔軟な組合せ・共有知識を設けた。2026年の[ACL Findings研究](https://aclanthology.org/2026.findings-acl.110/)は10モデルを調べてdomain-specific expertの証拠とtraining-free steeringを報告する一方、同年の[ACL研究](https://aclanthology.org/2026.acl-long.665/)は複数expertからなるdomain-invariantな中核群がrouting massの多くを占めると報告し、[EACL研究](https://aclanthology.org/2026.eacl-long.104/)はexpert単体より層をまたぐ共活性グループの専門性を分析した。対象モデル・入力長・route統計・因果介入が違うため、これらを合成して「必ず分野別分担ができる」とは結論しない。

#### 不均一MoEチップとの協調方法
物理的なexpertサイズをデータを見ずに固定し、その差を「学習済み専門性」と呼ぶのは避ける。提案する段階は次の通り。

1. **論理expertで基準学習**: まず同形状expertで品質とrouteを学習する。shared/generalist経路を含む構成も比較し、利用率だけでなくexpert・expert群の因果的寄与を取る。
2. **寄与とコストを同時にプロファイル**: 各expertの条件別ablation損失、route共起、token/byte coverage、FLOPs、メモリ帯域、実測service time、通信量を集める。高負荷は需要・配置・不適切routingのどれでも起こり得るので、負荷だけでexpertを大型化しない。
3. **容量を段階的に不均一化**: 冗長expertの統合、寄与の高い機能領域への容量追加、専門性が異なるexpertの分割を候補として、同等FLOPs/品質の対照を置いてfine-tuneする。分割・統合時には重みとoptimizer state、router ID、route記録を整合させ、同期バリアと新しいmodel manifestを使う。
4. **routerと物理schedulerを分ける**: 学習routerはタスク損失に基づく論理expert選択を学ぶ。物理schedulerは同じ論理関数の配置・複製・実行順序を、SLOと資源制約内で決める。実測costをrouter目的へ入れる実験では品質制約`L_task ≤ L_base + δ`を置き、cost penaltyだけで品質を犠牲にさせない。論理expert IDと物理タイルIDは分離する。
5. **循環バイアスを監視**: 近い・大きい・速いexpertが選ばれやすくなり、より多く勾配を得てさらに選ばれる一方、遅い・小さいexpertがstarveする自己強化はHMoE co-design固有の主要仮説である。物理速度だけのrouter bias、expert別勾配量、route品質、overflow、service timeを分けて観測する。利用率均等化をexpertサイズにかかわらず適用しない。

#### 機能的分担を判定する実験
同一checkpoint、データbyte数、optimizer/token budget、総active FLOPsで、(A) dense FFN、(B)等形状MoE、(C)shared expert併設、(D)潜在表現のクラスタ/PCA方向でrouterを初期化した案、(E)同じ構成のランダム初期化、(F) cost-aware router、(G)不均一expertを比較する。PCA案は初期化のablationであって、固有ベクトル由来を前提にしない。最低3 seed、複数domain、prompt prefillと生成decode、層別・データ順序別に追跡し、小バッチ/低多様性も独立に振る。

各条件でroute utilization・entropy・domain mutual informationを記録するが、次を主要判定にする。

*   **因果寄与**: expertを一体ずつ、および共活性group単位で除去/置換し、全体とdomain別のNLL・task品質差`ΔL`を測る。routerを再routeさせた場合とroute固定の場合を分け、迂回効果とexpert関数の寄与を混同しない。
*   **分担と汎化**: 同一入力のseed間route一致、学習/検証/OOD間の選択とablation寄与、語彙や表層形式を統制したdomain差を比較する。意味的に読める名前を後付けするだけでは専門性の証拠としない。
*   **ハードウェア価値**: expert別のtoken/byte負荷でなく、実測service time・FLOPs・通信・p50/p99 latency・energy/byteを報告し、容量・配置最適化なしの等形状MoEに対する純改善を示す。

採用条件は、(1)品質が事前設定した`δ`内、(2)分担が複数seed/domainで再現または因果寄与として確認できる、(3)異種サイズ割当が同等品質・同等計算予算の等形状対照よりシステム指標を改善する、の3条件とする。routeの均等化、PCA軸への整列、専門的な名前付けだけでは合格としない。

---

## 8. 学習プロセスの進化（Neuroevolutionary Training）
「静的な最適化」から「生態系のような進化」へ。

### 8.1 非同期・イベント駆動型更新
*   **機能**: バッチ全体を待たず、トークン通過後に即座に局所更新（Asynchronous SGD）。
*   **メリット**: 小さなエキスパートは高速反復学習、巨大エキスパートは深い学習。

### 8.2 進化するトポロジー（分裂・統合）
*   **機能**: 負荷の高いエキスパートは物理的に**分裂（Split）**し、使われないエキスパートは**統合（Merge）/剪定（Prune）**。
*   **メリット**: 事前設計不要。データ分布に応じた脳領域の自律的肥大化。

### 8.3 ハードウェア認識型ルーティング学習
*   **機能**: ルーターが「正解率」だけでなく「電力・レイテンシ・メモリ帯域」を報酬として学習（RLHW）。
*   **メリット**: 環境（ハードウェア制約）に適応して賢さを調整するメタ認知能力の獲得。

### 8.4 PIMによるインメモリ最適化
*   **機能**: オプティマイザ（Adam等）の計算をHBMベースダイ内のPIM回路で直接実行。
*   **メリット**: 勾配・重み・モメンタムをメモリから出さず、学習速度を物理限界まで向上。

### 8.5 推論優先の学習・推論混在
MoE専用チップは学習と推論の両方を実行できるが、同じ演算器・メモリ・ネットワークを無制御に共有しても両立するわけではない。実用上の第一目標は、**対話推論の遅延目標を守りながら、空き資源で小規模な継続学習を進めること**とする。

#### 第一段階: frozen base + expert別adapter学習
*   **重みの共有**: 基盤モデルと各expert本体は読み取り専用で学習・推論から共有する。学習側はexpert別LoRA/adapterと必要なrouter adapterのみを更新する。これにより基盤重みの二重化を避け、学習forwardとservingが同一の基準snapshotを参照できる。
*   **版の固定**: 学習は現行adapter版`A_v`から候補`A_(v+1)`を作る。推論要求は開始時にmodel-version ID（base、router、expert adapter、配置表）を固定し、終了まで同じ版を使う。KV cacheも版に紐付け、新版を使う要求へ旧版KVを流用しない。候補版は検証後に新規要求向けとして切り替え、実行中要求が終わるまで旧版を保持する。
*   **限定した即時更新**: optimizer stepの途中で推論が見る重みを書き換えない。要求・KVとadapterの版整合を保ち、要求単位の一貫したモデルを提供する。完全なexpert本体やrouterを更新する場合は別の版管理・copy-on-write容量が必要であり、adapter学習と同じ軽さとはみなさない。

#### ハードウェア資源の分け方
1. **推論の最低保証枠**: 行列タイル時間、HBM帯域、KV用メモリ、dispatch/combine用NoC仮想チャネルに推論の最低予約を置く。学習は残余枠を使い、応答遅延の予測値が目標へ近づいたら新規学習microbatchの投入を止める。
2. **メモリの弾性プール**: 基盤重みはread-only共有し、adapter/gradient/optimizer state、保存activation、KV cacheを別の割当カテゴリとして追跡する。推論負荷の増加時は、GPU/チップ内処理中のactivationには触れず、安全に再計算できる学習activationから確保領域を返す。返したactivationはbackward時に再計算し、その分の学習遅延を明示的に負担する。KVとoptimizer stateを暗黙に上書きしない。
3. **MoE通信の優先度制御**: 推論のtoken dispatch/combineを学習のgradient all-reduce/reduce-scatterより優先する。学習通信へ帯域credit上限を設け、推論が低負荷の間にのみ未使用帯域を利用させる。遅い・大きいexpertを更新中でも全requestをそのexpertへ即時集約する設計にはせず、既存router選択と容量制約を維持する。
4. **microbatch境界での停止・再開**: 学習は小さなmicrobatchで進め、停止する場合はbackward/optimizerの整合点で一時停止する。進行中kernelやcollectiveの途中で演算状態を破棄しない。adapter更新のoptimizer stateとgradient accumulationは、学習を止めても保持する。
5. **電力・熱の上限**: 推論の遅延予約と学習の持続稼働が同時にチップの電力/熱包絡を超えないよう、学習の周波数・並列度を絞る。演算枠とHBM枠を別々に制御し、電力制限による推論遅延も実測する。

#### 全重み学習との区別
全expertの事前学習・全重みfine-tuningでは、基盤重み更新候補に加えてgradient、optimizer state、backward用activation、分散collectiveが必要になる。推論のKVと帯域競合も加わるため、単一チップで対話SLOを守る常時同時実行の標準構成にはしない。低負荷時だけの時間共有、または独立した学習chiplet群・ノードでの学習を優先する。更新を推論へ反映する場合は、完成したcheckpoint/expert世代を一貫した版として公開し、部分更新expertと旧routerの混在を禁止する。

#### 性能目標と検証条件
設計目標は次の制約付き最適化として置く。

```text
maximize   training_tokens_per_second
subject to p99(TTFT) <= SLO_TTFT
           p99(TPOT) <= SLO_TPOT
           peak_memory <= physical_memory
           validation_quality >= frozen_baseline - δ
```

評価では、推論のみ、学習のみ、単純な時分割、固定資源分割、提案する弾性分割を比較する。短/長promptとKV長、低/高到着率、expertごとの負荷偏り、adapter rank、学習microbatchを振り、推論p50/p99 TTFT・TPOT、学習tokens/sと収束、KV/optimizer/activationの各memory peak、dispatchとgradient collectiveの待ち時間、電力・温度を同時に記録する。推論SLOや品質制約を外すときは追加学習を抑え、効果がなければ独立資源へ分離する。

### 8.6 学習・推論混在で予想されるMoE固有の事故（未実証）
以下はこの専用チップで観測済みの故障ではなく、MoEの条件付きルーティングとexpert並列の性質、および本案の共有キュー・配置変更・資源予約から導く検証仮説である。「MoE特化チップでのみ」と厳密に限定できる現象ではない。GPU上のMoEにも起きうるが、expert別の物理タイル、dispatch/combine回路、配置表、近接メモリを一体化すると、故障がハードウェア境界に現れやすくなる。

1. **全体予約をすり抜けるhot expert渋滞**: 学習microbatchと推論要求が同じexpertへ偏ると、チップ全体では演算器が空いていても、そのexpertのタイル、重みバンク、dispatch経路だけが飽和しうる。expert-parallelの同期区間では最も遅いexpertが層の完了を遅らせ、推論のp99遅延と学習activationの生存時間が同時に伸びる。KV増加とactivation保持がメモリ圧を強める二次的な悪化も予測される。推論の最低保証はチップ全体のFLOPsだけでなくexpert別キュー、HBMバンク、NoC経路にも設定し、expert別の待ち時間と到着率を監視する。凍結expertの複製先へ安全に逃がせる場合と、学習中expertの勾配同期が必要な場合は分ける。MoE推論の負荷偏りとstragglerは既存研究でも報告されている ([AMoE](https://arxiv.org/abs/2505.08944), [LLEP](https://arxiv.org/abs/2601.17111), [PROBE](https://arxiv.org/abs/2602.00509))。
2. **混在バッチの容量超過・学習信号の汚染**: 学習用と推論用tokenを同じexpert容量枠へ詰める実装では、一方の急増が他方の枠を奪う。固定容量を超えたtokenを暗黙にdrop/bypassすると、推論出力の劣化だけでなく、学習でexpertを通らないtokenが生じ、意図しない勾配・負荷統計になる。MoEにはtoken-dropless実装もあるため必然ではないが、固定容量方式では実際に容量超過が設計上の論点となる ([Switch Transformer](https://arxiv.org/abs/2101.03961))。モード別の容量・overflow規則を持ち、学習tokenはdropせずbackpressure、推論tokenは期限付きqueue/明示的な再試行または安全なreplicaへ送り、drop数を必ず記録する。学習routerのload-balance lossには学習tokenだけを使い、推論のroute統計を混ぜない。
3. **forwardのrouteとbackward再計算の不一致**: KV圧迫時に学習activationを捨てて再計算する場合、元のforwardとは異なるrouter版、top-k expert、gate値、token順序、capacity/drop mask、配置epochで再実行すると、再計算したactivation/勾配が別のexpertに対応し、誤勾配が静かに蓄積しうる。microbatchごとに論理expert ID、gate値または再現に必要なroute情報、overflow mask、乱数状態、router/重み版を保存し、同じ論理routeを再現する。expertを物理タイル間で移す場合も、forwardからbackward完了までは配置epochを固定するか、論理IDから当時の配置への対応を保持する。
4. **expert単位の部分更新・量子化replicaの世代混在**: expertごとに更新頻度が違うため、expert重み・adapter・router・量子化キャッシュを個別にin-place更新すると、推論要求が新旧expertを混ぜたモデルを参照しうる。個々のexpertの更新完了だけでは公開せず、model manifestに全expert/adapter/router/quantization/layoutの世代を列挙し、完全に準備できた世代を要求境界で一括公開する。旧世代はその版をpinした要求とKVが解放されるまで保持する。frozen base + adapterであっても、expert別adapter bankの部分公開を禁止する。
5. **遅れて返るexpert結果の誤結合**: hot expertで遅れたdispatch結果が、再利用済みtoken slotへ到着すると、別requestのtokenや学習microbatchへ結合される実装バグが起こりうる。出力誤りに加え、request間の結果混同にもつながる。各dispatch descriptorにmode、request/microbatch ID、論理expert ID、model/placement epoch、slot generationを持たせ、combine時に全て照合する。不一致は破棄して明示エラーにし、黙って結合しない。
6. **推論優先制御が学習collectiveの進捗を止める**: EP学習ではMoE層のforward/backwardにall-to-allが入り、参加デバイス間で完了を待つ。本案の推論優先schedulerがcollective途中の一部chipletだけを長く停止すると、残りがbufferを保持したまま待ち続け、学習の停滞・資源保持・KV圧迫へ連鎖する。MoE学習のforward/backwardでall-to-allが反復され、実測上大きなstep比率を占める例が報告されている ([Expert Coupling](https://arxiv.org/abs/2610.09372))。推論は新規microbatchの投入を絞って優先し、開始済みcollectiveにはbounded progressを保証する。学習を停止・再開する安全点はdispatch/combineとgradient collectiveが完了した境界に限定する。
7. **平均電力では見えない局所熱・帯域の連鎖**: route hotspotが特定expertのchiplet/HBM bankに集中すると、チップ全体の電力枠内でも局所温度・電力密度・帯域競合が先に限界へ達し、該当expertだけが遅くなってさらにqueueが伸びる可能性がある。これは構成からの予測であり、専用チップ実測はない。chiplet/bank単位の温度・電力・queue滞留を監視し、推論SLOに影響する前にそのexpert向け学習投入を絞る。

優先すべき安全不変条件は、(a)全tokenにmode/request/microbatch IDとmodel・配置世代を持たせる、(b)学習と推論のdispatch容量・統計を分離する、(c)route再計算で同じ論理expert選択を保証する、(d)世代更新を要求境界で原子的に公開する、(e)expert別の負荷とcollectiveの進捗を監視する、の5点とする。検証では同一hot expertへの同時集中、capacity超過、route/配置更新の直前直後、遅延completion、activation再計算、collective中の推論バーストを意図的に発生させ、参照実行との出力・勾配一致、drop/誤結合ゼロ、推論SLO、学習進捗を確認する。

---

## 総括
このアーキテクチャは、AIを「巨大な行列計算機」から、**「環境とタスクに応じて物理構造を最適化する認知器官」**へと進化させる。

*   **コンテキスト**: 伸縮自在の有機的記憶。
*   **思考**: 「ひらめき（System 1）」と「熟考（System 2）」の使い分け。
*   **ツール**: 思考を止めない非同期な環境相互作用。
*   **学習**: ハードウェアと共に成長する神経進化。

**「不均一であること」は弱点ではなく、知能の本質である。**
このチップは、その本質をシリコン上で初めて許容するアーキテクチャである。

## 参考資料（7.2、7.3、7.5、8.5、8.6）

1. Wang et al., [HMoE: Heterogeneous Mixture of Experts for Language Modeling](https://arxiv.org/abs/2408.10681) — expertサイズの不均一化と、トークンの難易度に合わせた容量配分。
2. Zhang et al., [H2O: Heavy-Hitter Oracle for Efficient Generative Inference of Large Language Models](https://arxiv.org/abs/2306.14048) — 最近のトークンとattention heavy hitterを保持するKV eviction方策。
3. Tomczak and Kuppannagari, [Longer Attention Span: Increasing Transformer Context Length with Sparse Graph Processing Techniques](https://arxiv.org/abs/2502.01659) — 疎attentionをグラフ処理として実装する際の計算量と実装効率。
4. Gulhane et al., [Expert Coupling in MoE Pretraining: Reducing All-to-All Overhead with Correlated Placement and Token Shuffling](https://arxiv.org/abs/2610.09372) — expert共起に基づく配置とtoken移動の研究。依存グラフトークンの有効性を直接検証した研究ではなく、配置最適化に使うtrace相関の参考。8.6節ではEP学習のforward/backward all-to-allの根拠としても参照。
5. Li et al., [LeMix: Unified Scheduling for LLM Training and Inference on Multi-GPU Systems](https://arxiv.org/abs/2507.21276) — LLM servingと継続学習を同じmulti-GPU node群へ配置し、予測/メモリ認識スケジューリングを行う研究。専用MoEチップ上のRTL実装ではない。
6. Yang et al., [MOLT: A Fine-Grained GPU Memory Sharing System for LLM Serving with Opportunistic Fine-Tuning](https://arxiv.org/abs/2610.05748) — frozen baseとPEFTを用い、推論のKV需要に応じてfine-tuning activation memoryを返し、backward時に再計算する2026年のプレプリント。フルexpert重み学習にそのまま一般化できない。
7. Rajbhandari et al., [ZeRO: Memory Optimizations Toward Training Trillion Parameter Models](https://arxiv.org/abs/1910.02054) — 学習状態のメモリと分散配置に関する基礎資料。
8. Fedus et al., [Switch Transformers: Scaling to Trillion Parameter Models with Simple and Efficient Sparsity](https://arxiv.org/abs/2101.03961) — expert容量、token overflow/drop、およびload-balance loss。
9. Wang et al., [Toward Cost-Efficient Serving of Mixture-of-Experts with Asynchrony](https://arxiv.org/abs/2505.08944) — 推論時のexpert負荷偏り、straggler、同期待ち。
10. Nguyen et al., [Least-Loaded Expert Parallelism: Load Balancing An Imbalanced Mixture-of-Experts](https://arxiv.org/abs/2601.17111) — 学習後・推論時にも残る負荷偏りと過負荷expert。
11. Zhu et al., [PROBE: Co-Balancing Computation and Communication in MoE Inference via Real-Time Predictive Prefetching](https://arxiv.org/abs/2602.00509) — serving中にhotspot位置が移動し、計算偏りとnetwork congestionが連動する問題。
12. Pagnoni et al., [Byte Latent Transformer: Patches Scale Better Than Tokens](https://aclanthology.org/2025.acl-long.453/) — byte entropyによる可変長patchとbyte-level modeling。
13. Tay et al., [Charformer: Fast Character Transformers via Gradient-based Subword Tokenization](https://arxiv.org/abs/2106.12672) — byte/characterから学習可能なsubword単位を構成する手法。
14. Minixhofer et al., [Retrofitting language models to operate over bytes](https://www.nature.com/articles/s41586-026-11111-4) — 既存dense subword LLMをbyte/latent-patch型へ変換する2段階byteification。MoE変換や専用ハードウェアの実証ではない。
15. Liu et al., [EntropyMoE: Entropy-Aware Sparse Expert Routing for Tokenizer-Free LLMs](https://arxiv.org/abs/2608.06398) — dynamic byte patchをTop-2 MoE routing unitにし、entropy-only routingとbyte-weighted負荷会計を評価した2026年のプレプリント。
16. Zeng et al., [AdaMoE: Token-Adaptive Routing with Null Experts for Mixture-of-Experts Language Models](https://arxiv.org/abs/2406.13233) — tokenごとに実行expert数を変えるadaptive routing。byte patch粒度との組合せは別問題。
17. Wang, Hayou, and Nalisnick, [The Myth of Expert Specialization in MoEs: Why Routing Reflects Geometry, Not Necessarily Domain Expertise](https://arxiv.org/abs/2604.09780) — 線形router・hidden-state幾何、load-balance lossとroutingの関係を分析した2026年preprint。expert分担の解釈可能性には慎重な結論。
18. Do, Le, and Tran, [Do Domain-specific Experts exist in MoE-based LLMs?](https://aclanthology.org/2026.findings-acl.110/) — 10モデルを評価しdomain-specific expertの存在とtraining-free steeringを報告したACL Findings 2026。
19. Tang et al., [Specialization through Collaboration: Understanding Expert Interaction in Mixture-of-Expert Large Language Models](https://aclanthology.org/2026.eacl-long.104/) — expert単体に限らず、層をまたぐ共活性groupをdictionary learningで分析したEACL 2026。
20. Wang et al., [The Illusion of Specialization: Unveiling the Domain-Invariant “Standing Committee” in Mixture-of-Experts Models](https://aclanthology.org/2026.acl-long.665/) — domain間で共通するexpert groupと周辺専門expertを分析したACL 2026。
21. Kim and Kang, [Exploration-Driven Reinforcement Learning for Expert Routing Improvement in Mixture-of-Experts Language Models](https://aclanthology.org/2025.findings-emnlp.1282/) — routing alternativeを探索し、知識重複を残して過剰専門化による崩壊を抑えるrouter学習法、Findings EMNLP 2025。
