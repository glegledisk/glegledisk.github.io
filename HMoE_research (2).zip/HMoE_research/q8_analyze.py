#!/usr/bin/env python3
"""Q8: 静的型ディスパッチ HMoE の集計・検定スクリプト。"""
import json
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q8")


def analyze_q8():
    results_path = os.path.join(DATA_DIR, "q8_results.json")
    if not os.path.exists(results_path):
        print("Results file not found yet.")
        return

    with open(results_path, encoding="utf-8") as f:
        res = json.load(f)

    tasks = ["compute", "hard"]
    modes = ["dynamic_lb", "dynamic_no_lb", "static_type"]

    print("=" * 80)
    print("Q8: STATIC TYPE-DISPATCHED HMOE ANALYSIS")
    print("=" * 80)

    summary = {}
    for task in tasks:
        for mode in modes:
            key = f"{task}_{mode}"
            runs = [r for r in res if r["task"] == task and r["mode"] == mode]
            if len(runs) < 6:
                print(f"Skipping {key}: only {len(runs)} runs")
                continue

            acc = [r["eval"]["base"]["acc_payload"] for r in runs]
            ce = [r["eval"]["base"]["ce_payload"] for r in runs]
            iv = [r["eval"]["base"]["instr_valid"] for r in runs]
            w_st = [r["eval"]["base"]["width_struct"] for r in runs]
            w_pl = [r["eval"]["base"]["width_payload"] for r in runs]
            deltas = [r["eval"]["base"]["small_payload"] - r["eval"]["base"]["small_struct"] for r in runs]

            summary[key] = {
                "runs": runs,
                "acc_payload": np.array(acc),
                "ce_payload": np.array(ce),
                "instr_valid": np.array(iv),
                "width_struct": np.array(w_st),
                "width_payload": np.array(w_pl),
                "delta": np.array(deltas),
            }

            print(f"\n[{key}] (n={len(runs)})")
            print(f"  Acc Payload : mean={np.mean(acc):.4f}, se={stats.sem(acc):.4f}")
            print(f"  CE Payload  : mean={np.mean(ce):.4f}, se={stats.sem(ce):.4f}")
            print(f"  Instr Valid : mean={np.mean(iv):.3f}, se={stats.sem(iv):.3f}")
            print(f"  Width st/pl : st={np.mean(w_st):.1f}, pl={np.mean(w_pl):.1f}")
            print(f"  Δ           : mean={np.mean(deltas):+.3f}, se={stats.sem(deltas):.3f}")

    # Paired comparisons: static_type minus dynamic_lb, static_type minus dynamic_no_lb
    print("\n" + "=" * 80)
    print("PAIRED COMPARISONS (n=6, df=5)")
    print("=" * 80)

    for task in tasks:
        for baseline in ["dynamic_lb", "dynamic_no_lb"]:
            k_stat = f"{task}_static_type"
            k_base = f"{task}_{baseline}"
            if k_stat not in summary or k_base not in summary:
                continue

            print(f"\n--- {task}: static_type minus {baseline} ---")
            for metric in ["instr_valid", "acc_payload", "ce_payload", "width_payload", "width_struct", "delta"]:
                diff = summary[k_stat][metric] - summary[k_base][metric]
                m_diff = np.mean(diff)
                se_diff = stats.sem(diff)
                t_val = m_diff / (se_diff + 1e-12)
                p_val = stats.t.sf(np.abs(t_val), df=5) * 2
                sign_str = f"{np.sum(diff > 0)}/6 正" if m_diff > 0 else f"{np.sum(diff < 0)}/6 負"
                print(f"  Δ {metric:<13}: {m_diff:+.4f} (se={se_diff:.4f}, t={t_val:+.2f}, p={p_val:.4f}, {sign_str})")

    # Save to json
    out_json = {}
    for k, v in summary.items():
        out_json[k] = {
            "mean": {m: float(np.mean(arr)) for m, arr in v.items() if m != "runs"},
            "se": {m: float(stats.sem(arr)) for m, arr in v.items() if m != "runs"},
            "values": {m: arr.tolist() for m, arr in v.items() if m != "runs"}
        }

    out_path = os.path.join(DATA_DIR, "q8_analysis.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(out_json, f, ensure_ascii=False, indent=2)
    print(f"\nSaved analysis to {out_path}")


if __name__ == "__main__":
    analyze_q8()
