# -*- coding: utf-8 -*-
"""P16 補助: 報告に載せる MDE80 を JSON から取り出す（使い捨て）"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
d = json.load(open(os.path.join(HERE, "p16_analysis.json"), encoding="utf-8"))
for lv, v in d["levels"].items():
    for t in v["tests"]:
        if t["name"] in ("clean/confmax - s1", "clean/maj - s1", "all/confmax - s1"):
            print("%-6s %-20s dAcc=%+.4f se=%.4f t=%+.2f p=%.4g n=%d mde80=%.4f"
                  % (lv, t["name"], t["acc"]["mean"], t["acc"]["se"], t["acc"]["t"],
                     t["acc"]["p"], t["acc"]["n"], t["acc"]["mde80"]))
