# -*- coding: utf-8 -*-
"""e5_validate_testbed.py — E5 が「ルーティング／サイドカー」のテストベッドとして機能するかの検証

容量プローブの結論: d=64 では Attention の softmax が非線形性を担い FFN が冗長（ΔCE 0.068）。
d=16 まで落とすと FFN が本質的になる（ΔCE 0.396、acc_anchor 0.514 vs 0.190）。

そこで d=16, A=16, anchor_vals=(0,1,2,3)（アンカー 20%）で 5 アームを比較する:
  frozen_ffn      : 常に FFN（上限）
  frozen_identity : 常に恒等（下限）
  free            : ルータが自由に学習
  sidecar         : ルータ + 依存構造の明示特徴（アンカー条件・依存条件の 2 次元）
  oracle          : 正解のアンカー列を PLAN として入力（参照）

判定基準:
  - free が frozen_ffn に近づき、FFN コストが下がる  -> ルータが配分を学習できた
  - sidecar が free より良い                          -> 明示特徴が効く（サイドカーの実証）
  - どちらも frozen_identity に近い                   -> 配分を学習できていない
"""
import os, json, time
import numpy as np
import pandas as pd
from e5_dependency_task import run

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=16, anchor_vals=(0, 1, 2, 3), d=16)
ARMS = ["frozen_ffn", "frozen_identity", "free", "sidecar", "oracle"]
SEEDS = [0, 1, 2]

rows = []
t0 = time.time()
for arm in ARMS:
    for s in SEEDS:
        r = run(arm, s, **CFG)
        rows.append(r)
        print(f"  {arm:16s} s{s} | acc {r['acc_all']:.4f} "
              f"(copy {r.get('acc_copy',0):.3f}/anchor {r.get('acc_anchor',0):.3f}/dep {r.get('acc_dep',0):.3f}) "
              f"| CE {r['ce_all']:.4f} | FFN {r['ffn_cost']:.3f} "
              f"| ID率 anchor {r.get('id_rate_anchor',0):.3f}", flush=True)
    print(f"    ({time.time()-t0:.0f}s)", flush=True)

df = pd.DataFrame(rows)
df.to_csv(os.path.join(HERE, "e5_validate_testbed.csv"), index=False)

print("\n=== E5 テストベッド検証（3 seeds 平均±SD） ===")
print(f"{'arm':16s} {'acc':>16s} {'acc anchor':>16s} {'CE':>16s} {'FFN cost':>16s} {'ID率(anchor)':>13s}")
for arm in ARMS:
    d = df[df.arm == arm]
    print(f"{arm:16s} {d['acc_all'].mean():.4f}±{d['acc_all'].std():.4f}  "
          f"{d['acc_anchor'].mean():.4f}±{d['acc_anchor'].std():.4f}  "
          f"{d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f}  "
          f"{d['id_rate_anchor'].mean():.3f}")

ffn = df[df.arm == "frozen_ffn"]["ce_all"].mean()
idn = df[df.arm == "frozen_identity"]["ce_all"].mean()
free = df[df.arm == "free"]["ce_all"].mean()
side = df[df.arm == "sidecar"]["ce_all"].mean()
print(f"\n FFN の寄与（上限-下限）      : {idn - ffn:+.4f} nats")
print(f" free が回収した割合          : {100*(idn - free)/(idn - ffn):5.1f}%")
print(f" sidecar が回収した割合       : {100*(idn - side)/(idn - ffn):5.1f}%")
print(f" sidecar - free               : {side - free:+.4f} nats（負なら sidecar が優位）")

json.dump({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in CFG.items()},
           "summary": [{k: float(df[df.arm == a][k].mean()) for k in
                        ["acc_all", "acc_anchor", "acc_dep", "ce_all", "ffn_cost", "id_rate_anchor"]}
                       | {"arm": a} for a in ARMS],
           "ffn_contribution": float(idn - ffn),
           "free_recovery_pct": float(100*(idn - free)/(idn - ffn)),
           "sidecar_recovery_pct": float(100*(idn - side)/(idn - ffn)),
           "raw": rows},
          open(os.path.join(HERE, "e5_validate_testbed.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e5_validate_testbed.csv / .json")
