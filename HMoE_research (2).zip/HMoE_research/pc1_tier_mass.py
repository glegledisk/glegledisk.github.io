#!/usr/bin/env python3
"""PC1: 生徒 HMoE 蒸留の事前チェック（1）階層質量の分散（2）w x share の一定性

素材: simulation_hmoe_mmlu/data/e2 の H+LB ckpt（幅 32/32/96/96/160/160/224/224, top-2, 4 層, d=128）
評価: P13 と同一（rng 777, n=2048）で校正を取る（CE_all 0.4399 / width 161 が目標）。

(1) 階層質量: 4 層 x 4 階層（32/96/160/224）について
    - 平均・トークン間 SD・CV
    - 位置で説明される分散の割合 eta2_pos（系列内 47 位置の一元配置）
    - copy/edit で説明される割合 eta2_edit
    - 階層分布のエントロピー（有効階層数）
    - 幅の逆数 1/W を正規化した分布との一致（L1, JS）
    - トークンごとの JS(m_t, m_bar) の平均
(2) w x share: expert 8 本 x 4 層の出現率 share と幅 w の関係
    - w*share の CV、Spearman(w, share)、log(share) ~ log(w) の傾き（-1 なら share ∝ 1/w）
出力: pc1_tier_mass.json / pc1_tier_mass_out_utf8.txt
"""
import json
import math
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, E2DIR)
from e2b_rewrite_routing_fixed import (  # noqa: E402
    RewriteMoE, make_batch, to_seq, SL, OL, V, WIDTHS)

OUTDIR = os.path.join(E2DIR, "data", "e2b")
TIERS = [(0, 1), (2, 3), (4, 5), (6, 7)]


def forward_gates(model, idx, k=2):
    """p13_hmoe_path.forward_forced の自然版。ゲート（8 次元、top-k 以外 0）を返す。"""
    p = model.p
    B, T = idx.shape
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    gates_l = []
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
        topv, topi = logits.topk(k, dim=1)
        gate = torch.softmax(
            torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
        gates_l.append(gate.detach())
        y = torch.zeros_like(h)
        for i in range(model.E):
            tok, slot = (topi == i).nonzero(as_tuple=True)
            if tok.numel() == 0:
                continue
            x = h[tok]
            h1 = F.relu(F.linear(x, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
            y.index_add_(0, tok,
                         F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                         * gate[tok, i].unsqueeze(1))
        h = h + y
    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, V)
    return out, gates_l


def eta2(vals, groups):
    """一元配置の分散説明率。vals (N,), groups (N,) int"""
    gm = vals.mean()
    ss_tot = ((vals - gm) ** 2).sum()
    ss_b = 0.0
    for g in np.unique(groups):
        m = groups == g
        ss_b += m.sum() * (vals[m].mean() - gm) ** 2
    return float(ss_b / max(ss_tot, 1e-30))


def js(p, q):
    p = np.clip(p, 1e-12, 1)
    q = np.clip(q, 1e-12, 1)
    m = 0.5 * (p + q)
    return float(0.5 * (p * np.log(p / m)).sum() + 0.5 * (q * np.log(q / m)).sum())


@torch.no_grad()
def main():
    torch.set_num_threads(6)
    n_eval = 2048
    ev_rng = np.random.default_rng(777)
    src, out, em, ks = make_batch(ev_rng, n_eval)
    print("eval: n=%d  OUT=%d  k_mean=%.2f  edit率=%.3f"
          % (src.shape[0], OL, ks.mean(), em.mean()), flush=True)

    res = {"n_eval": n_eval, "tiers": [list(t) for t in TIERS],
           "widths": list(WIDTHS["H+LB"]), "per_seed": {}}

    for seed in (0, 1, 2):
        path = os.path.join(OUTDIR, "ckpt_H+LB_s%d.pt" % seed)
        if not os.path.exists(path):
            print("  [skip] %s" % path)
            continue
        model = RewriteMoE(WIDTHS["H+LB"], seed=seed)
        model.p = {k: v for k, v in torch.load(path, map_location="cpu").items()}
        for k in model.p:
            model.p[k].requires_grad_(False)

        E, L = model.E, model.L
        onehot = np.zeros((E, len(TIERS)), dtype=np.float32)
        for gi, (a, b) in enumerate(TIERS):
            onehot[a:b + 1, gi] = 1.0

        mass = np.zeros((n_eval, OL, L, len(TIERS)), dtype=np.float32)
        occ = np.zeros((L, E), dtype=np.float64)
        gmass = np.zeros((L, E), dtype=np.float64)
        pair = np.zeros((L, len(TIERS), len(TIERS)), dtype=np.float64)
        ce_all = np.zeros((n_eval, OL), dtype=np.float32)
        width = np.zeros((n_eval, OL), dtype=np.float32)
        dims = np.array(model.dims, float)
        ntok = 0

        bs = 128
        for i in range(0, n_eval, bs):
            s = slice(i, min(i + bs, n_eval))
            x = to_seq(src[s], out[s])
            logits, gates_l = forward_gates(model, x, k=2)
            B = x.shape[0]
            lg = logits[:, SL:SL + OL, :]
            tgt = torch.from_numpy(out[s])
            ce_all[s] = F.cross_entropy(
                lg.reshape(-1, V), tgt.reshape(-1), reduction="none"
            ).reshape(-1, OL).numpy()
            for l, g in enumerate(gates_l):
                g3 = g.reshape(B, x.shape[1], E).numpy()[:, SL:SL + OL, :]
                mass[s, :, l, :] = g3 @ onehot
                occ[l] += (g3 > 0).sum((0, 1))
                gmass[l] += g3.sum((0, 1))
                # 幅: top-2 の和
                topi = np.argsort(-g3, axis=-1)[:, :, :2]
                width[s] += dims[topi].sum(-1)
                # 選ばれた top-2 がどの階層ペアか（順不同）
                ti = np.array([np.searchsorted([b for a, b in TIERS], topi[:, :, j])
                               for j in range(2)])
                lo = np.minimum(ti[0], ti[1])
                hi = np.maximum(ti[0], ti[1])
                for gg in range(len(TIERS)):
                    for hh in range(gg, len(TIERS)):
                        pair[l, gg, hh] += float(((lo == gg) & (hi == hh)).sum())
            ntok += B * OL

        width /= L
        res["per_seed"][seed] = {
            "ce_all": float(ce_all.mean()),
            "width": float(width.mean()),
            "width_p10": float(np.percentile(width, 10)),
            "width_p90": float(np.percentile(width, 90)),
            "share": (occ / ntok).round(5).tolist(),
            "gate_mass": (gmass / ntok).round(5).tolist(),
        }
        print("\n[s%d] CE_all %.4f  width %.1f [%.0f, %.0f]"
              % (seed, ce_all.mean(), width.mean(),
                 np.percentile(width, 10), np.percentile(width, 90)), flush=True)

        # --- (1) 階層質量 ---
        pos = np.tile(np.arange(OL), n_eval)              # (n*OL,)
        edt = em.reshape(-1)                              # (n*OL,)
        mbar = mass.mean((0, 1))                          # (L, G)
        tier_rows = []
        for l in range(L):
            for gi, (a, b) in enumerate(TIERS):
                v = mass[:, :, l, gi].reshape(-1)
                row = {
                    "layer": l, "tier": gi, "width": WIDTHS["H+LB"][a],
                    "mean": float(v.mean()), "sd": float(v.std(ddof=1)),
                    "cv": float(v.std(ddof=1) / max(v.mean(), 1e-12)),
                    "eta2_pos": eta2(v, pos), "eta2_edit": eta2(v, edt),
                }
                tier_rows.append(row)
        res["per_seed"][seed]["tier"] = tier_rows

        # 幅の逆数を正規化した分布
        wg = np.array([WIDTHS["H+LB"][a] for a, b in TIERS], float)
        p_w = (1.0 / wg) / (1.0 / wg).sum()
        ent = -(np.clip(mbar, 1e-12, 1) * np.log(np.clip(mbar, 1e-12, 1))).sum(1)
        # トークンごとの JS(m_t, m_bar)。位置平均を取らず per-(token,pos) で計算する
        eps = 1e-12
        q = np.clip(mbar, eps, 1)[None, None, :, :]          # (1,1,L,G)
        pp = np.clip(mass, eps, 1)                            # (n,OL,L,G)
        mm = 0.5 * (pp + q)
        js_all = 0.5 * (pp * np.log(pp / mm)).sum(-1) + 0.5 * (q * np.log(q / mm)).sum(-1)
        js_all = js_all.mean(-1)                              # (n,OL) 層平均
        js_pos = js_all.mean(0)                               # (OL,) 位置ごと

        def js_vec(a, b):
            a = np.clip(a, eps, 1)
            b = np.clip(b, eps, 1)
            m = 0.5 * (a + b)
            return (0.5 * (a * np.log(a / m)).sum(-1)
                    + 0.5 * (b * np.log(b / m)).sum(-1))

        mbar_p = mass.mean(0)                                 # (OL,L,G) 位置平均
        js_between_pos = float(js_vec(mbar_p, mbar[None]).mean())   # 位置間
        js_within_pos = float(js_vec(mass, mbar_p[None]).mean())    # 位置内（内容＋雑音）
        # 系列平均（位置を潰したとき）
        mbar_s = mass.mean(1)                                 # (n,L,G)
        js_series = float(js_vec(mbar_s, mbar[None]).mean())
        # 内容: 出力文字（29 種）で説明される割合
        chr_grp = out.reshape(-1)
        eta2_chr = float(np.mean([eta2(mass[:, :, l, gi].reshape(-1), chr_grp)
                                  for l in range(L) for gi in range(len(TIERS))]))
        res["per_seed"][seed]["tier_summary"] = {
            "mbar": mbar.round(5).tolist(),
            "width_implied": p_w.round(5).tolist(),
            "l1_vs_width_implied": float(np.abs(mbar - p_w[None, :]).mean()),
            "js_vs_width_implied": float(np.mean([js(mbar[l], p_w) for l in range(L)])),
            "entropy": ent.round(4).tolist(),
            "eff_tiers": np.exp(ent).round(3).tolist(),
            "js_token_vs_mean": float(js_all.mean()),
            "js_token_p90": float(np.percentile(js_all, 90)),
            "js_series_vs_mean": js_series,
            "js_between_pos": js_between_pos,
            "js_within_pos": js_within_pos,
            "eta2_char_mean": eta2_chr,
            "js_pos_min": float(js_pos.min()),
            "js_pos_max": float(js_pos.max()),
            "js_by_pos": js_pos.round(5).tolist(),
            "eta2_pos_mean": float(np.mean([r["eta2_pos"] for r in tier_rows])),
            "eta2_edit_mean": float(np.mean([r["eta2_edit"] for r in tier_rows])),
            "cv_mean": float(np.mean([r["cv"] for r in tier_rows])),
            "sd_mean": float(np.mean([r["sd"] for r in tier_rows])),
        }
        print("  tier mbar(層平均) %s  vs 1/W %s"
              % (np.round(mbar.mean(0), 3).tolist(), np.round(p_w, 3).tolist()), flush=True)
        for l in range(L):
            print("    L%d mbar %s  H=%.3f" % (l, np.round(mbar[l], 3).tolist(), ent[l]),
                  flush=True)
        print("  eta2_pos %.3f  eta2_edit %.3f  CV(median) %.3f  eff_tiers %.2f"
              % (res["per_seed"][seed]["tier_summary"]["eta2_pos_mean"],
                 res["per_seed"][seed]["tier_summary"]["eta2_edit_mean"],
                 float(np.median([r["cv"] for r in tier_rows])),
                 float(np.exp(ent).mean())), flush=True)
        print("  JS(token,mean) mean %.4f  p90 %.4f  |  位置間 %.4f  位置内 %.4f  系列平均 %.4f"
              % (js_all.mean(), np.percentile(js_all, 90), js_between_pos,
                 js_within_pos, js_series), flush=True)
        print("  eta2_char %.4f   JS pos [%.4f, %.4f]"
              % (eta2_chr, js_pos.min(), js_pos.max()), flush=True)
        for l in range(L):
            print("    L%d tier-pair %s" % (l, np.round(
                pair[l] / pair[l].sum(), 2).tolist()), flush=True)

        # --- (2) w x share ---
        sh = occ / ntok
        w = np.array(WIDTHS["H+LB"], float)
        ws = (sh * w[None, :])
        lw = np.tile(np.log(w), L)
        ls = np.log(np.clip(sh, 1e-9, None)).reshape(-1)
        b = float(np.polyfit(lw, ls, 1)[0])
        rho = float(np.corrcoef(
            np.argsort(np.argsort(w))[None, :].repeat(L, 0).reshape(-1),
            np.argsort(np.argsort(sh, axis=1), axis=1).reshape(-1))[0, 1])
        res["per_seed"][seed]["wshare"] = {
            "w_x_share_cv": float(ws.std() / ws.mean()),
            "w_x_share_rows": ws.round(4).tolist(),
            "spearman_w_share": rho,
            "slope_logshare_logw": b,
            "share_rows": sh.round(4).tolist(),
        }
        res["per_seed"][seed]["tier_pair"] = (
            pair / pair.sum(axis=(1, 2), keepdims=True)).round(4).tolist()
        print("  w*share CV %.3f  spearman(w,share) %+.3f  slope(log share ~ log w) %+.3f"
              % (ws.std() / ws.mean(), rho, b), flush=True)
        print("  小 expert(e0,e1) の平均選択率: %s   (P13 §3: s0 .43/.50/.59/.86)"
              % np.round(sh[:, :2].mean(1), 3).tolist(), flush=True)

    with open(os.path.join(HERE, "pc1_tier_mass.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2, default=float)

    # 集計（seed 平均）
    print("\n=== seed 平均 ===", flush=True)
    keys = ["eta2_pos_mean", "eta2_edit_mean", "eta2_char_mean", "cv_mean", "sd_mean",
            "js_token_vs_mean", "js_between_pos", "js_within_pos", "js_series_vs_mean",
            "l1_vs_width_implied", "js_vs_width_implied"]
    for k in keys:
        vals = [res["per_seed"][s]["tier_summary"][k] for s in res["per_seed"]]
        print("  %-22s %s  mean %.4f" % (k, np.round(vals, 4).tolist(), np.mean(vals)),
              flush=True)
    for k in ["w_x_share_cv", "spearman_w_share", "slope_logshare_logw"]:
        vals = [res["per_seed"][s]["wshare"][k] for s in res["per_seed"]]
        print("  %-22s %s  mean %.4f" % (k, np.round(vals, 4).tolist(), np.mean(vals)),
              flush=True)
    print("\nsaved: pc1_tier_mass.json", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
