# 批判的レビュー：『MoEキャッシュと不均一性』調査文の引用検証

**対象**: 2026-10-17 受領の長文テキスト（「結論から言うと、サイズ・構造の不均一は…」）
**検証日**: 2026-10-17
**手法**: 文中の全引用（arXiv ID 17件・システム名・サーベイ名）を arXiv abstract/HTML・HuggingFace・GitHub issue で一次確認。数値は原文と逐条照合。

---

## 0. 総合判定

| 観点 | 評価 |
|---|---|
| 引用の実在率 | ○ 21件中17件が実在確認 |
| 主要数値の正確性 | △ 実在論文の数値はほぼ正確。ただし3系統は出典不明の数値 |
| 推論の骨格 | ○ 結論の方向性は一次資料で支持される |
| 細部の帰着 | △ 5箇所に誤り・誇張・取り違え |
| 自己申告した不確実性の誠実さ | ✗ 「最重要の要検証点」と自称した llama.cpp RFC の数値列が実在しない |

**要約**: 骨格は健全。ただし (i) llama.cpp RFC の測定値列、(ii) Flash-MoE の3数値は出典が実在しない（捏造の疑い）、(iii) SparseFlow と「A Survey of Efficient Storage Management in LLM Serving」は実在確認できず。この3点を除けば、主張の大半は一次資料で支持される。引用文の「不確実性」セクションが挙げる3点のうち2点（k·L の崖の規模依存性、shared expert の相殺未定量）は本当のギャップだが、3点目の「最重要の要検証点」は Evidence ごと差し替えが必要。

---

## 1. 検証結果一覧

### A群：確認済み（そのまま使える）

| 引用 | 検証結果 |
|---|---|
| arXiv:2509.02408 "Cache Management for MoE LLMs (extended)" | **実在**（Angelopoulos, Marchal, Obrecht, Simon; Inria/LORIA 系; 2025-09, Springer 版 DOI あり）。§2.1 に "we assume that all experts produce data of the same size" が verbatim で存在。LLRU = Layered LRU（last-round index ⌊(t−τ)/ℓ⌋ で evict、同値は層距離で tie-break）も確認。Llama トレースで LRU 比 **約15% fewer faults**（§5.2, k=200）も verbatim。 https://arxiv.org/abs/2509.02408 |
| arXiv:2605.05899 VisMMoE | **実在**（Cheng Xu 他; 2026-05）。§3.4.2 "pre-partition this space into fixed-size slabs, each storing one expert"（cudaMalloc・断片化回避）確認。§3.4.1 "Shared experts, which show near-100% hit rates, remain permanently pinned" 確認。 https://arxiv.org/abs/2605.05899 |
| arXiv:2411.01433 HOBBIT | **実在**（Tang, Liu, Hou 他; SJTU）。トークンごとの high/low 精度動的選択（ゲート magnitudo プロキシ、T1=0.6/T2=0.9 → 67%/30%/3%）確認。ミスコスト B_l/B_h·C（int4 は fp16 の4倍）verbatim。**expert 4 のダイバージェンス例も実在**（LFU は expert 4 のミスが少ないが LHU はトータルペナルティで勝つ）。方策名は **LHU = "Least High-precision Frequently Used"**。 https://arxiv.org/abs/2411.01433 |
| arXiv:2308.14352 EdgeMoE | **実在**（Yi, Guo, Wei 他; BUPT）。INT2/4/8 の expert 別 offline 割当確認。"activation frequency across experts is purposely trained to be balanced" で頻度ベースのキャッシュは限定的、という趣旨 verbatim。上位20%の活性化パスが全トークンの99%超を説明（P(E3=5｜E1=3,E2=1)=87.1% 等）確認。"smallest possible model size = fastest loading" も verbatim。 https://arxiv.org/abs/2308.14352 |
| DyMoE (2026) | **同定できた**: arXiv:2603.19172（Yuegui Huang, Zhiyuan Fang, Weiqi Luo 他; 2026-03）。実行時の 4/2/0-bit 動的割当（**0-bit = expert skipping**、評価は 4/2 と 4/0）、層深度の cosine スケジュール（初期層ほど高精度）、拡張 LRU の "No Duplication" 規則（同一 expert は1形式のみ保持）すべて確認。TTFT **3.44〜22.7倍削減**（22.7× は Fiddler 対 Mixtral-8x7B@24GB）、TPOT 最大 14.58×。 https://arxiv.org/abs/2603.19172 |
| Quantization as Cache Amplification (Kavin Kumar, Neural Metrics) | **実在・全数値確認**。HuggingFace データセット `mkvn/quantization-cache-amplification`（11ページ論文+コード+生トレース int16[16,49152,8]+再現 Space `mkvn/moe-expert-cache-cliff`）。k·L=128/1024（OLMoE-1B-7B, k=8, L=16, 64 experts/layer）、LRU 0.0% @ 2%/5%/10% → 128 で 25.3%、popularity-pinned 22.9% @10%、1.51bit で 22.02 vs 25.54（13.8%改善）、1T は解析投影で非実行——すべて verbatim。RTX A500 ラップトップ計測、Zipf s=0.65。**「Neural Metrics」は HF ページの byline として実在**（ニュースレター本体のサイトは不明）。引用文の「参考扱い」は妥当。 https://huggingface.co/datasets/mkvn/quantization-cache-amplification |
| arXiv:2608.15383 ExactMoE | **実在**（Amjad Saab 単著; 2026-08, "Every Expert Counts: ExactMoE for Memory-Efficient W4A16 Inference"）。routed expert を W4 単一表現で pinned host/GPU cache の双方に置き、ミス時に dequant/repack 不要は verbatim。容量超過時は resident waves に分割して fused MARLIN kernel で実行（"wave-based fused execution"）。注意: W4 は routed experts のみ（router/attention/head は BF16）、"Exact" は BF16 同値ではない。 https://arxiv.org/abs/2608.15383 |
| arXiv:2609.13537 VAMP | **実在**（"Dynamic HBM Repartitioning for Multi-Turn MoE Serving"; 2026-09）。"TP2: expert weights occupy 72.0 GiB and the baseline KV-cache pool 8.02 GiB" verbatim（2×H100 PCIe, Qwen3-Next-80B, 94 GiB）。ただし VAMP 自体は**不均衡を解消する側**の論文（CUDA VMM で expert weight 領域を KV 化、KV pool 8.0→18.5–21.8 GiB/GPU、TTFT p90 26.1 s→1.10 s @ offload 15%）。 https://arxiv.org/abs/2609.13537 |
| arXiv:2604.17695 MoE-nD | **実在**（"Per-Layer Mixture-of-Experts Routing for Multi-Axis KV Cache Compression"）。層ごとに (eviction-ratio, K-bits, V-bits) をグローバル予算下で greedy 選択、verbatim。 https://arxiv.org/abs/2604.17695 |
| arXiv:2509.08342 MoEpic | **実在**。expert を上下（top/bottom）に垂直分割し hot expert の top をキャッシュ、層別 VRAM 予算+分割比を fixed-point iteration（divide-and-conquer）で配分。レイテンシ 37.5–65.7% 削減。 https://arxiv.org/abs/2509.08342 |
| arXiv:2512.12990 SliceMoE | **実在**（KAIST; DAC 2026）。ビットスライス粒度 + Calibration-Free Asymmetric Matryoshka Quantization で重複なしの混合精度。引用文の記述と一致。 https://arxiv.org/abs/2512.12990 |
| MoDSE (EMNLP 2024 Industry) | **実在・ID 補完**: arXiv:2409.12210（Xiaomi）。ペア (9216,1024)(8192,2048)(6144,4096)(5120,5120)、h=5120 で和 2h=10240（Eq.8）確認。総パラメータ維持も確認。難トークン（高CE損失）の top-1 選択: 大 6215 vs 小 3085 ≒ **2.02倍**（難しいトークンに限った数値である点は本文の通り）。 https://arxiv.org/abs/2409.12210 |
| HMoE (arXiv:2408.10681) | **実在・全項目確認**（Tencent Hunyuan + Tokyo Tech + SJTU; EMNLP 2025）。P-Penalty = expert 隠れ次元 h_ffn で重み付けた負荷均衡損失（"When the model employs more large experts, the loss rises"）確認。Top-P（p=0.6、可変活性数、router-entropy loss、Top-K より良いと評価）確認。サイズ近傍 expert の類似性クラスタリング確認。小 expert の協調参加・"smaller experts collaborate more"・「小 expert の役割は shared expert に近づく」も確認。**本プロジェクトの基盤論文の引用は正確。** https://arxiv.org/abs/2408.10681 |
| arXiv:2608.12103 | **実在・数値 verbatim**（"Who Should Own the Expert Cache? Kernel-Managed Tiering for Trillion-Parameter MoE Inference"; Yuan Si 他; 2026-08）。"At B = 8 with k = 16, it hits 0.5% while LFU reaches 12.7%" 確認（static frequency は 9.8%）。ただし**ハードウェア実測ではなくルータートレース追跡のシミュレーション**（Qwen3-30B-A3B / DeepSeek-V3-671B / Kimi-K3 E=896、1.45TB モデルは GH200 で replay）。B=8 は最小実測容量 C=64GB より小さい設定。引用文の「別系統の実測と独立に一致」は「独立した追跡実験と一致」に修正すべき。 https://arxiv.org/abs/2608.12103 |

### B群：論文は実在するが文脈・粒度の修正が必要

| 引用 | 検証結果 |
|---|---|
| arXiv:2509.02408 の競争比 | 式 **k−ℓ+1 は正しい**（Theorem 3.2: 任意の決定的 layered paging algorithm の競争比は k−ℓ+1 以上）。ただし **k = キャッシュ容量、ℓ = 層数**（＝ experts-per-token ではない）。引用文は §2 で k を「1トークンが触れる expert 数（top-k）」として使っており記号が衝突。Theorem 3.3（LRU の比は ℓ｜k+1 のとき k 以上）も併記価値あり。 |
| 同論文の将来課題 | **「variable expert sizes」は将来課題として挙げられていない**（将来課題は bound gap の縮小・1層複数 expert・learning-augmented 版）。等サイズ前提の明示（§2.1 verbatim）から「不均一化は枠外」という引用文の論点自体は成立するが、「将来課題として挙げている」という記述は削除が必要。 |
| HOBBIT の15% | 「LHU で LFU 比ミスペナルティ約15%減」は **Fig. 11 の手抜き例に限った値**。一般設定の ablation（§5.5.3, Fig. 18）では **LRU 比 4.69–8.68%、LFU 比 2.13–4.19%** の削減。引用文の表は「例示では最大15%」と書くか一般値を書くべき。 |
| EdgeMoE の 0.44% / 0.59% | 数値は実在するが、**2モデルではなく1モデル（ST-base-8）の1層内の2 expert**（SAMsum, Rouge-2 指標）の INT2 量子化時の低下幅。引用文の「例 0.44% vs 0.59%」は対象を取り違えている。 |
| Fate (arXiv:2502.12224) | **実在**（Sun Yat-sen 大, "Fast Edge Inference of MoE via Cross-Layer Gate"）。層を浅い方から優先する "shallow-favoring expert caching"（層内 evict は per-layer ARC）、hit rate 99.08%。ただし動機は**浅い層の予fetch精度が低い**（routing 重み分布の判別性が低い → 誤予測をキャッシュで補う必要）こと。引用文の「カバレッジが広い」という根拠は**論文に存在しない**（「予測困難」は正しい）。 |
| arXiv:2505.16056（SRP/SCH 論文） | **実在**（Fudan, "Not All Models Suit Expert Offloading: On Local Routing Consistency of MoE Models"; v1 2025-05, v4 2026-02; **ICLR 2026 採択の事実確認は取れず**、arXiv preprint として引用すべき）。重要な取り違え3点: (1) **SRP/SCH は手法ではなくメトリクス**（SRP = "Segment Routing Best Performance"、SCH = "Segment Cache Best Hit Rate"）；(2) 引用文の「ルータの決定性を下げる」は gloss——論文の該当表現は "settings like shared experts that decrease expert combination space can lead to low local routing consistency" および "the bypass effect"（"more information is processed by shared experts, making the real MoE part less important"）；(3) **「SRP/SCH の4分類」は誤読**——4グループは実モデルを SRP 特性で分類したもので、shared expert 手法の分類ではない。共有 expert が local routing consistency を下げる点（toy: shared expert 1個で 43.56→41.38、2個で 38.79）と、論文の追加知見「多くのモデルは active experts の約2倍のキャッシュ容量で効果と効率のバランスが取れる」は引用文に新規に盛り込める。 https://arxiv.org/abs/2505.16056 |
| VAMP の位置づけ | 数値は正確（A群）だが、**VAMP は「不均衡を実測して報告した論文」ではなく「不均衡を動的再パーティションで解消する論文」**。引用文の「間接的にプレフィックスヒット率を押し下げる」という推論は筋として成立するが、VAMP を不均衡の証拠として引くときは「同論文は同時に解消手段も提示している」と添えるべき。 |
| DyMoE の精度表記 | 「4/2/0 bit」は正しいが、**0-bit は expert skipping**（スキップ）であり省ビットではない。評価は "4/2" と "4/0" 構成。TTFT 22.7× は DyMoE(4/0) vs Fiddler（Mixtral-8x7B, 24GB）という条件下の値。 https://arxiv.org/abs/2603.19172 |

### C群：実在が確認できない / 数値が出典に存在しない

| 引用 | 検証結果 |
|---|---|
| **llama.cpp "MoE expert cache RFC" の実測値** | **Issue #20757（"Two-tier GPU+RAM expert cache for MoE offload"）は実在するが、引用文の数値列は存在しない**。coverage 11.7%/18.7%/25.5%/30.6% → hit 約50%/55%/63%/70%、帯域+75%、decode+6% はスレッド内に一切出てこない（GitHub 全文検索でもヒットせず）。**引用文が「最重要の要検証点」とした Evidence が虚偽**。スレッドの実測値は別物（次§2-1）。 https://github.com/ggml-org/llama.cpp/issues/20757 |
| **Flash-MoE の3数値** | 実在する FlashMoE（arXiv:2601.17063, 2026-01, "Reducing SSD I/O Bottlenecks via ML-Based Cache Replacement for MoE Inference on Edge Devices"）には**量子化の記述がなく**、expert は full precision の .pt ファイルとして保存される。「hot 上位25%を4bit・cold を2bit（各44%縮小）」「ディスク全体−34%」「OSページキャッシュヒット率約71%」は**すべて論文に存在しない**（なお4bit は fp16 比75%縮小であって44%ではない。論文の "34.2%" は LRU の再 fetch 率）。同論文の実数値: LRU ~73% vs Belady 86%、FlashMoE は LRU 比 +21%・LFU 比 +51%（OLMoE-1B-7B）、最大 2.6× 高速化。引用文の3数値は捏造疑い。なお同系統名の別論文 "FlashMoE: Fast Distributed MoE in a Single Kernel"（arXiv:2506.04667, NeurIPS'25）は通信カーネルで無関係。 https://arxiv.org/abs/2601.17063 |
| **SparseFlow** | **実在確認できず**。"per-layer LRU + byte budget + lease" を採る MoE オフロード/キャッシュシステムとして arXiv・GitHub・Google でヒットしない。候補: ExpertFlow（予測的 expert キャッシュ、2024）や MoE-CORE（arXiv:2610.01950, 2026-10）との混同の可能性。そのまま引用してはならない。 |
| **"A Survey of Efficient Storage Management in LLM Serving"（2026）** | **実在確認できず**。arXiv タイトル検索・Google/Bing でヒットせず。最寄りは "Taming the Titans: A Survey of Efficient LLM Inference Serving"（arXiv:2504.19720）だが、MoE 節は expert 配置・負荷分散のみで、引用文の粒度（whole/sub-expert/layer/neuron）分析は含まれない。引用文の粒度整理は**独自の総合として書くべき**（内容自体は妥当な定式化）。 |
| **DyMoE / Flash-MoE / SparseFlow / Diff-MoE の arXiv ID** | DyMoE は arXiv:2603.19172 として同定済み（A群）。Flash-MoE は arXiv:2601.17063（C群の通り中身不一致）。**Diff-MoE は「Diff-MoE: Diffusion Transformer with Time-Aware and Space-Adaptive Experts」という拡散モデル論文で、MoE キャッシュ論文ではない**——引用文が層別優先キャッシュの例に挙げているのは誤り。trio "VisMMOE/Fate/Diff-MoE" のうち層別優先キャッシュに該当するのは Fate のみ。 |

---

## 2. 重大な修正が必要な3点

### 2.1 llama.cpp RFC の数値列（引用文の「最重要の要検証点」）

Issue #20757 に投稿された**実在する**数値は以下の通り:

- スレッド主（PoC 実装、RTX PRO 2000 8GB, GPT-OSS-120B）: 定常状態 hit rate 約98–100%（SLRU+admission filter で +8–15pp）、"~15–20% of experts handle ~80% of tokens"
- martinalderson（Vulkan PoC, RX 9070 XT）: hit rate 47%（100 tok）→ 67%（500+ tok）、tg1024 27.9→35.1 tok/s（**+26% decode**）
- JigSawPT: live task の 68.6% coverage で +26%、coverage 上限 80.4% で 92.3 tok/s、gpt-oss-120B で +31.6% decode
- 匿名（mmap シミュレーション, Qwen3-30B-A3B）: hit_avg 98.84%（Q4_K_M）

**評価**: 引用文の「coverage 11.7%→50%、18.7%→55%、25.5%→63%、30.6%→70%、飽和なしの線形、帯域+75%、decode+6%」はこのスレッドに存在しない。**引用文の結論方向（「Zipf 的偏りがあるから小キャッシュで十分」という通説への反証）は、JigSawPT の coverage–decode 曲線や martinalderson の +26% といった実在数値で組み直せる**。Evidence の総差し替えが必要。

### 2.2 Flash-MoE の数値（捏造疑い）

「hot 上位25%を4bit・cold を2bit（各44%縮小）」「expert ディスク全体−34%」「OSページキャッシュヒット率約71%」は実在論文（arXiv:2601.17063）に存在しない。引用文の §2 表の Flash-MoE 行は、実論文の内容（ML ベースキャッシュ置換で LRU 比 +21%、LFU 比 +51%、最大2.6×）に差し替えるか、行ごと削除すべき。混合精度の実例は HOBBIT / EdgeMoE / DyMoE / SliceMoE / Quantization-as-Cache-Amplification で既に足りている。

### 2.3 SparseFlow とサーベイ論文

- SparseFlow は混同の可能性が高い。MoE-CORE（arXiv:2610.01950, 2026-10）は新しく出た論文で未調査——キャッシュ管理の最新動向として別途確認を推奨。
- サーベイ論文は実在しない。粒度のトレードオフ整理（whole-expert ↔ sub-expert/layer/neuron）は引用文自身の総合として再記述すれば内容は通る。

---

## 3. 細部の訂正（B群の要約と書き換え）

| # | 引用文の記述 | 訂正後 |
|---|---|---|
| 1 | 競争比下界 k−ℓ+1 | 式は正。ただし k=容量、ℓ=層数。§2 の top-k の k と記号が衝突するため変数名を変える（例: 容量 K、層数 ℓ、下界 K−ℓ+1） |
| 2 | 「variable expert sizes を将来課題として挙げている」 | 削除（挙げられていない）。等サイズ前提からの論点は §2.1 の verbatim 引用で支える |
| 3 | HOBBIT「LFU比 約15%減」 | 「例示（Fig.11）では最大15%、一般設定では LRU 比 4.7–8.7% / LFU 比 2.1–4.2%」 |
| 4 | EdgeMoE「重要度＝INT2時の精度低下、例 0.44% vs 0.59%」 | 「1モデル内の expert 間の比較（ST-base-8, SAMsum, Rouge-2）」 |
| 5 | Fate「浅い層を優先ピン（予測困難・カバレッジが広い）」 | 「予測困難（routing 分布の判別性が低く誤予測をキャッシュで補う必要がある）は正。「カバレッジが広い」は論文根拠なし」 |
| 6 | SRP/SCH「論文（ICLR 2026）」の4点 | (i) SRP/SCH はメトリクス名（Segment Routing Best Performance / Segment Cache Best Hit Rate）、(ii) "bypass effect" は verbatim だが「ルータの決定性」は gloss、(iii) 4分類はモデル分類で shared expert 手法分類ではない、(iv) venue は arXiv preprint（ICLR 2026 採択は未確認） |
| 7 | VAMP「不均衡を実測」 | 数値は正確。ただし VAMP は解消手段を出す論文。証拠として引くなら「不均衡は実測されているが、同時に動的再パーティションで解消可能とされる」 |
| 8 | 2608.12103「別系統の実測と独立に一致」 | 「独立した追跡シミュレーションと一致」（B=8 は最小実測容量未満の設定、k=16 は最大規模 E=896 の点） |

---

## 4. 推論部分の評価（検証とは別に、論理の強弱）

引用文の結論骨格は一次資料で支持される:

1. **「ヒット率指標そのものが信用できない」** — HOBBIT の expert-4 例、k·L の崖（LRU 0.0%）が具体的な実例として機能。○
2. **混合精度→ミスコスト低減** — HOBBIT のペナルティ枠組みで裏付けられ、EdgeMoE の「頻度ベースは効かない」も verbatim。○
3. **shared expert の二重効果** — 2505.16056 が combination space 縮小 → local routing consistency 低下を実測（toy 数字あり）。引用文の「相殺関係は未測定」という指摘は**本当のギャップ**。○
4. **異サイズ MoE × キャッシュの実測不在** — 今回の一次資料調査でも実測文献は見つからず。引用文の「最大のギャップ」指摘は妥当。◎（= 白地）
5. **k·L の崖の定数の頑健性** — 引用文自身が懸念する通り、数値は OLMoE 単一モデル＋自主公開。2608.12103 も追跡シミュレーション扱いが正しく、頑健性は未検証のまま。ただし定量化の方向性（「容量の下限基準は個数割合ではなく k·L」）は Quantization-as-Cache-Amplification の負結果（fp16 流列には 116 GB/s 必要に対し実測 88.2 GB/s）とも整合し、無視できない示唆。△
6. **「均一精度なら ExactMoE が最も単純」** — W4 単一表現・wave 実行の仕様から支持。○

---

## 5. 本プロジェクト（不均一MoE）への含意

- **HMoE の引用（arXiv:2408.10681）は全項目正確**。P-Penalty（大 expert の過剰活性化を h_ffn 重みで罰する）、Top-P 可変活性、サイズ類似性クラスタリング、小 expert の協調・shared 化傾向——企画書の該用はそのまま使える。
- 引用文の「P-Penalty は人気分布を均一化する方向に働くため、スキュー＝ヒット率の源泉と逆向き」という推論は、HMoE 論文の負荷均衡損失の性質と整合する**仮説**であり、（4）の白地を埋める最初の反証可能予測として使える。例: HMoE 系モデルでは同容量の LRU が均一 MoE よりヒット率で不利になる/ならない。
- ORR 実験（`次の探索トピック_決定_20261017`）とは別軸の話だが、キャッシュ断絶のギャップは「不均一 MoE を実システムに載せるときのコスト」として企画の Risk リストに1行追加できる。

---

## 6. 差し替え推奨テキスト（抜粋）

- **llama.cpp の箇所**: 「llama.cpp の MoE expert cache 議論（Issue #20757）でのコミュニティ計測: hit rate 47%→67%（+26% decode, martinalderson）、live task coverage 68.6% で +26%・上限 80.4%（JigSawPT）、定常状態 98–100%（スレッド主 PoC）。『小キャッシュで十分』という通説は、coverage–decode が線形に近い振る舞いを見せる限り支持されない。」
- **Flash-MoE の行**: 「FlashMoE（arXiv:2601.17063）: ML ベースのキャッシュ置換で LRU 比 hit +21%・LFU 比 +51%（OLMoE-1B-7B）、最大 2.6×。量子化は行わない。」
- **SparseFlow の行**: 削除または MoE-CORE（arXiv:2610.01950, 未調査）の確認後に差し替え。
- **サーベイの箇所**: 「粒度のトレードオフ（全体 expert / sub-expert / layer / neuron）は本調査の総合であり——単一サーベイへの帰属にはできない——」

---

## 付録: 検証中に新たに同定・発見した文献（引用文に無い）

| 文献 | 内容 | 用途 |
|---|---|---|
| arXiv:2603.19172 DyMoE | 動的 4/2/0-bit + layer cosine + no-duplication キャッシュ | 混合精度キャッシュの最新例（引用文はIDなし） |
| arXiv:2409.12210 MoDSE | 異サイズ expert ペア（和 2h 固定） | 引用文にIDなし |
| arXiv:2505.16056 | SRP/SCH メトリクス、shared expert の local routing consistency 低下 | shared expert 二重効果の定量部 |
| arXiv:2610.01950 MoE-CORE | 2026-10 の MoE システム（未調査） | キャッシュ管理の最新動向 |
| llama.cpp PR #27861 | Qwen3.8-Flash-Next で +31% throughput（主張値） | 実装側の最新動向 |
| arXiv:2506.04667 FlashMoE (NeurIPS'25) | 同名の別システム（単一カーネル分散 MoE） | FlashMoE 名称衝突の回避用 |
