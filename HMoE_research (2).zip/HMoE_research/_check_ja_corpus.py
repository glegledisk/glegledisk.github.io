# -*- coding: utf-8 -*-
"""_check_ja_corpus.py — baseline CE が P3 と一致しない原因の切り分け

p3/p6a の ja コーパスは「プロジェクト内 *.md を sorted glob して先頭 400k 文字」。
新しい .md が増えると内容が変わる。どのファイルが境界にいるかを確認する。
"""
import glob
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
max_chars = 400000
files = [f for f in sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True))
         if "english_version" not in f]
print("md files:", len(files))

cum = 0
parts = []
for f in files:
    try:
        with open(f, "r", encoding="utf-8") as fp:
            txt = fp.read()
    except Exception:
        continue
    txt = re.sub(r"```.*?```", " ", txt, flags=re.S)
    txt = re.sub(r"<!--.*?-->", " ", txt, flags=re.S)
    txt = re.sub(r"^\s*\|[-: ]+\|.*$", " ", txt, flags=re.M)
    before = cum
    parts.append((os.path.basename(f), len(txt)))
    cum += len(txt)
    if cum >= max_chars:
        print("  STOP at %-70s (cum %d, file %d chars)" % (os.path.basename(f), cum, len(txt)))
        break

corpus = "\n\n".join(["x"])  # placeholder
total = sum(p[1] for p in parts) + 2 * (len(parts) - 1)
print("corpus chars (approx, with separators): %d  (cap %d)" % (total, max_chars))
print("truncated:", total >= max_chars)

# 今日追加されたファイルが含まれているか
import datetime
for name, n in parts:
    p = os.path.join(HERE, name)
    mt = datetime.datetime.fromtimestamp(os.path.getmtime(p))
    if mt.strftime("%Y%m%d") == "20261027":
        print("  TODAY: %-70s %d chars" % (name, n))

print("\n最初の 5 ファイル:")
for name, n in parts[:5]:
    print("  %-70s %d" % (name, n))
print("最後の 5 ファイル:")
for name, n in parts[-5:]:
    print("  %-70s %d" % (name, n))
