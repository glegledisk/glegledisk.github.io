#!/usr/bin/env python3
"""P19: 並走（fan-out）で expert 負荷は偏るか（考察 §7 予測 2）

予測（`考察_HMoEとサブエージェントPro_Ultraモード_20261029.md` §3 / §7 予測 2）:
  fan-out 時に HMoE は幅が不均一なので、均一 MoE より負荷偏りが大きい。
  反証: 同等なら fan-out 干渉の懸念は落ちる。

測る対象（E2b の訓練済みモデル。data/e2b/ckpt_{U+LB,H+LB}_s{0,1,2}.pt）
  U+LB : 幅 128 × 8（均一）, switch aux
  H+LB : 幅 32/32/96/96/160/160/224/224, p_pen aux
  4 層・top-2・d_model 128・系列 95（SRC47 + SEP + OUT47）

負荷の 3 つの見方（混同しない）
  (a) 選択率の偏り   : expert ごとの割当トークン数（幅を無視）
  (b) FLOPs の偏り   : 幅で重み付けした仕事量。均一 MoE では構成上ゼロ
  (c) expert 並列効率: 8 expert が並列に走るときの makespan = max 仕事量。
                       efficiency = mean(work) / max(work)。1.0 が完全分散

異種 workload: k（置換数）= 0 / 1 / 2 / 4 の 4 種。mixed = 4 種を等数混ぜたバッチ。
  → 「混ぜると偏るか」を homogeneous の加重平均と比べる。

最重要の検査（fan-out 干渉の本体）:
  同じ系列を「単独（batch=1）」と「異種 mixed バッチの中」で走らせ、**選択 expert が
  一致するか**を assert する。一致するなら routing はトークン独立で、
  fan-out 干渉は routing には存在しない（残るのは workload 構成比の効果だけ）。

出力: p19_fanout.json / p19_out_utf8.txt
"""
import json
import os
import sys

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
SIM = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, SIM)

from e2b_rewrite_routing_fixed import (  # noqa: E402
    RewriteMoE, WIDTHS, to_seq, V, SL, OL, SEQ)

OUTDIR = os.path.join(SIM, "data", "e2b")
ARMS = ["U+LB", "H+LB"]
SEEDS = [0, 1, 2]
KS = [0, 1, 2, 4]
N_PER = 64
OUT = []


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def load_model(arm, seed):
    m = RewriteMoE(WIDTHS[arm], seed=seed)
    sd = torch.load(os.path.join(OUTDIR, "ckpt_%s_s%d.pt" % (arm, seed)),
                    map_location="cpu")
    for k, v in sd.items():
        assert m.p[k].shape == v.shape, (k, m.p[k].shape, v.shape)
        with torch.no_grad():
            m.p[k].copy_(v)
    return m


def make_fixed_k(rng, n, k):
    """k を固定した書き換え系列。k=0 は完全コピー。"""
    src = rng.integers(0, V, size=(n, SL))
    out = src.copy()
    for i in range(n):
        if k == 0:
            continue
        pos = rng.choice(OL, size=k, replace=False)
        for p in pos:
            alt = int(rng.integers(0, V - 1))
            if alt >= out[i, p]:
                alt += 1
            out[i, p] = alt
    return src, out


def analyse(idxs, widths):
    """idxs: list(L) of (B,T,k) long。OUT 区間だけを見る。"""
    w = torch.tensor(widths, dtype=torch.float64)
    L = len(idxs)
    per_tok = torch.zeros(idxs[0].shape[0], OL, dtype=torch.float64)
    work = torch.zeros(len(widths), dtype=torch.float64)      # 幅重み付き
    count = torch.zeros(len(widths), dtype=torch.float64)     # 素の割当数
    for l in range(L):
        ix = idxs[l][:, SL + 1:, :]                            # (B, OL, k)
        per_tok += w[ix].sum(-1)
        for j in range(ix.shape[-1]):
            e = ix[:, :, j].reshape(-1)
            work.index_add_(0, e, w[e])
            count.index_add_(0, e, torch.ones_like(e, dtype=torch.float64))
    n_tok = idxs[0].shape[0] * OL
    share_flops = work / work.sum()
    share_sel = count / count.sum()
    eff = float(work.mean() / work.max())
    return {
        "flops_per_token_mean": float(per_tok.mean()),
        "flops_per_token_cv": float(per_tok.std() / per_tok.mean()),
        "flops_per_token_min": float(per_tok.min()),
        "flops_per_token_max": float(per_tok.max()),
        "share_flops": [float(x) for x in share_flops],
        "share_sel": [float(x) for x in share_sel],
        "max_share_flops": float(share_flops.max()),
        "max_share_sel": float(share_sel.max()),
        "parallel_eff": eff,
        "n_tokens": int(n_tok),
    }


def main():
    torch.set_grad_enabled(False)
    res = {"arms": {}, "invariance": {}}

    for arm in ARMS:
        widths = list(WIDTHS[arm])
        res["arms"][arm] = {"widths": widths, "seeds": {}}
        log("\n=== %s (widths=%s) ===" % (arm, widths))
        for seed in SEEDS:
            model = load_model(arm, seed)
            rng = np.random.default_rng(1000 + seed)
            per_k = {}
            for k in KS:
                src, out = make_fixed_k(rng, N_PER, k)
                seq = to_seq(src, out)
                logits, aux, idxs = model(seq, need_idx=True)
                # 妥当性: copy_acc / edit_acc
                pred = logits[:, SL:SL + OL, :].argmax(-1).numpy()
                mask = out != src
                copy_acc = float((pred[~mask] == out[~mask]).mean()) if (~mask).any() else float("nan")
                edit_acc = float((pred[mask] == out[mask]).mean()) if mask.any() else float("nan")
                r = analyse(idxs, widths)
                r["copy_acc"] = copy_acc
                r["edit_acc"] = edit_acc
                per_k[k] = r
                log("  s%d k=%d  flops/tok=%.1f (cv %.3f)  max_share(flops)=%.3f "
                    "max_share(sel)=%.3f  par_eff=%.3f  copy=%.3f edit=%s"
                    % (seed, k, r["flops_per_token_mean"], r["flops_per_token_cv"],
                       r["max_share_flops"], r["max_share_sel"], r["parallel_eff"],
                       copy_acc, "%.3f" % edit_acc if edit_acc == edit_acc else "-"))

            # ---- mixed バッチ: 4 種を等数 ----
            srcs, outs = [], []
            for k in KS:
                s, o = make_fixed_k(rng, N_PER // len(KS), k)
                srcs.append(s)
                outs.append(o)
            src_m = np.concatenate(srcs, 0)
            out_m = np.concatenate(outs, 0)
            seq_m = to_seq(src_m, out_m)
            _, _, idxs_m = model(seq_m, need_idx=True)
            mix = analyse(idxs_m, widths)
            # 構成比どおりの予測（トークン独立なら一致するはず）
            pred_mean = float(np.mean([per_k[k]["flops_per_token_mean"] for k in KS]))
            log("  s%d mixed  flops/tok=%.1f (cv %.3f)  par_eff=%.3f  "
                "homogeneous の単純平均=%.1f（差 %+.2f）"
                % (seed, mix["flops_per_token_mean"], mix["flops_per_token_cv"],
                   mix["parallel_eff"], pred_mean,
                   mix["flops_per_token_mean"] - pred_mean))

            # ---- 不変性: 単独 vs mixed で選択 expert が一致するか ----
            n_probe = 8
            idx_single = []
            for i in range(n_probe):
                _, _, ix = model(to_seq(src_m[i:i + 1], out_m[i:i + 1]), need_idx=True)
                idx_single.append([t[0] for t in ix])
            same = 0
            for i in range(n_probe):
                ok = all(torch.equal(idx_single[i][l], idxs_m[l][i]) for l in range(len(idxs_m)))
                same += int(ok)
            log("  s%d invariance (batch=1 vs mixed batch): %d/%d identical"
                % (seed, same, n_probe))

            res["arms"][arm]["seeds"][str(seed)] = {
                "per_k": {str(k): per_k[k] for k in KS},
                "mixed": mix,
                "mixed_pred_mean": pred_mean,
                "invariance_identical": same, "invariance_n": n_probe}

    # ---- 集計: H vs U（seed 対応） ----
    log("\n[summary] per-seed comparison (H+LB vs U+LB)")
    log("  %-6s %-4s %10s %10s %10s %10s" %
        ("metric", "k", "U", "H", "H-U", "H/U"))
    agg = {}
    for k in KS:
        for metric in ["flops_per_token_mean", "flops_per_token_cv",
                       "max_share_flops", "max_share_sel", "parallel_eff"]:
            u = [res["arms"]["U+LB"]["seeds"][str(s)]["per_k"][str(k)][metric] for s in SEEDS]
            h = [res["arms"]["H+LB"]["seeds"][str(s)]["per_k"][str(k)][metric] for s in SEEDS]
            d = np.array(h) - np.array(u)
            agg["%s|k%d" % (metric, k)] = {"U": float(np.mean(u)), "H": float(np.mean(h)),
                                           "diff": float(np.mean(d)),
                                           "diff_se": float(np.std(d, ddof=1) / np.sqrt(len(d)))
                                           if len(d) > 1 else float("nan")}
            log("  %-18s %-4d %10.4f %10.4f %+10.4f %10s"
                % (metric, k, np.mean(u), np.mean(h), np.mean(d),
                   "%.2f" % (np.mean(h) / np.mean(u)) if np.mean(u) else "-"))
    res["agg"] = agg

    with open(os.path.join(HERE, "p19_fanout.json"), "w", encoding="utf-8") as fp:
        json.dump(res, fp, ensure_ascii=False, indent=2)
    with open(os.path.join(HERE, "p19_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    log("saved: p19_fanout.json")


if __name__ == "__main__":
    main()
