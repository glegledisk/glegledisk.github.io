#!/usr/bin/env python3
"""Q4b: 容量ノブ（d_model）で payload 正解率 0.8 前後を作れるか。

Q4 で「×m を上げる」ノブは崖だった（×5 0.999 → ×6 0.988 → ×7 0.329、0.7–0.9 の点が無い）。
本スクリプトは別ノブ、**モデル容量（d_model）** を下げて 0.8 前後を狙う。
タスク（hard = ×3）とレイアウト（payload 80%, T=109）は Q2/Q4 と同一なので、
結果はそのままラダーに接続できる。

Q2 のハーネスを import して使う（make_trace_batch / trace_loss / evaluate はそのまま）。
run_arm だけ d_model を渡せるように置き換える。

出力: simulation_hmoe_mmlu/data/q4b/H+LB_{task}_d{dmodel}_s{seed}.json
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import q2_difficulty_ladder as Q2  # noqa: E402
from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS  # noqa: E402

OUTDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q4b")


def run(arm, task, seed, d_model, n_seqs, epochs, bs, lr, auxw):
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    aux_mode = "p_pen" if arm.startswith("H") else "switch"
    model = RewriteMoE(WIDTHS[arm], d_model=d_model, seed=seed)
    opt = Adam(model.params(), lr=lr)
    nparam = sum(v.numel() for v in model.params().values())

    steps_per_ep = max(1, n_seqs // bs)
    t0 = time.time()
    hist = []
    for ep in range(epochs):
        run_loss = 0.0
        for _ in range(steps_per_ep):
            seq, _ = Q2.make_trace_batch(rng, bs, task=task)
            x = torch.from_numpy(seq)
            logits, aux, _ = model(x, aux_mode=aux_mode)
            loss = Q2.trace_loss(logits, seq) + auxw * aux
            loss.backward()
            opt.step(model.params())
            run_loss += float(loss.detach())
        hist.append(run_loss / steps_per_ep)
        print(f"    [{arm} {task} d{d_model} s{seed}] ep{ep+1}/{epochs} "
              f"loss={hist[-1]:.4f} ({time.time()-t0:.0f}s)", flush=True)

    ev_rng = np.random.default_rng(777)
    seq, typ = Q2.make_trace_batch(ev_rng, 1024, task=task)
    conds = {"base": (None, None), "force_small": (None, Q2.SMALL)}
    ev = Q2.evaluate(model, seq, typ, conds)
    out = {"arm": arm, "seed": seed, "task": task, "d_model": d_model,
           "nparam": nparam, "loss_hist": hist, "n_eval": 1024,
           "sec": round(time.time() - t0, 1), "eval": ev}
    os.makedirs(OUTDIR, exist_ok=True)
    torch.save({k: v.detach() for k, v in model.params().items()},
               os.path.join(OUTDIR, f"ckpt_{arm}_{task}_d{d_model}_s{seed}.pt"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arm", default="H+LB")
    ap.add_argument("--task", default="hard")
    ap.add_argument("--dmodel", nargs="+", type=int, default=[64, 80, 96])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--auxw", type=float, default=0.05)
    ap.add_argument("--resume", action="store_true")
    args = ap.parse_args()

    os.makedirs(OUTDIR, exist_ok=True)
    torch.set_num_threads(6)
    print(f"task={args.task} d_model={args.dmodel} seeds={args.seeds}", flush=True)

    rows = []
    for d in args.dmodel:
        for seed in args.seeds:
            p = os.path.join(OUTDIR, f"{args.arm}_{args.task}_d{d}_s{seed}.json")
            if args.resume and os.path.exists(p):
                with open(p, encoding="utf-8") as f:
                    r = json.load(f)
                if r.get("n_eval") == 1024:
                    print(f"  [skip] d{d} s{seed}", flush=True)
                    rows.append(r)
                    continue
            r = run(args.arm, args.task, seed, d, args.seqs, args.epochs,
                    args.bs, args.lr, args.auxw)
            rows.append(r)
            e = r["eval"]["base"]
            print(f"  -> d{d} s{seed}: acc pl = {e['acc_payload']:.4f} "
                  f"instr = {e['instr_valid']:.3f} "
                  f"small st/pl = {e['small_struct']:.3f}/{e['small_payload']:.3f} "
                  f"(Δ={e['small_payload']-e['small_struct']:+.3f}) "
                  f"wid st/pl = {e['width_struct']:.1f}/{e['width_payload']:.1f} "
                  f"nparam={r['nparam']}", flush=True)
            with open(p, "w", encoding="utf-8") as f:
                json.dump(r, f, ensure_ascii=False, indent=2)

    with open(os.path.join(OUTDIR, "q4b_results.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
    print(f"[write] {OUTDIR}", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
