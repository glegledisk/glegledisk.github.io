# -*- coding: utf-8 -*-
import json

with open("ax10_shift_avg.json", encoding="utf-8") as f:
    d = json.load(f)

print("=== Confirmatory ===")
for k, v in d["confirmatory"].items():
    if isinstance(v, dict) and "mean" in v:
        print(f"{k}: mean={v['mean']:+.8f} se={v['se']:.8f} t={v['t']:+.4f} p={v['p_two']:.6g} MDE={v['mde']:.8f}")
        print(f"  CI95: [{v['ci95'][0]:+.8f}, {v['ci95'][1]:+.8f}]")
        print(f"  CI90: [{v['ci90'][0]:+.8f}, {v['ci90'][1]:+.8f}]")
        print(f"  n_pos={v['n_pos']} n_neg={v['n_neg']} median={v['median']:+.8f} top1_share={v['top1_abs_share']:.5f}")

print("holm:", d["confirmatory"]["holm"])
print("reject:", d["confirmatory"]["reject"])
print("case:", d["confirmatory"]["case"])

print("\n=== Calibration ===")
for k, v in d["calib"].items():
    print(f"{k}: {v}")

print("\n=== Exploratory ===")
print("decomp102:", d["exploratory"]["decomposition_N102"])
print("decomp181:", d["exploratory"]["decomposition_N181"])
print("draw102:", {k: v for k, v in d["exploratory"]["draw_stats_102"].items() if k != "values"})
print("draw181:", {k: v for k, v in d["exploratory"]["draw_stats_181"].items() if k != "values"})
print("flat:", d["exploratory"]["flat"])

print("N181 tests:")
for k, v in d["exploratory"]["N181_tests"].items():
    print(f"  {k}: mean={v['mean']:+.8f} se={v['se']:.8f} t={v['t']:+.4f} p={v['p_two']:.6g} MDE={v['mde']:.8f}")

print("cross_N_spearman:", d["exploratory"]["cross_N_spearman"])
print("G_shiftmean102:", d["exploratory"]["G_shiftmean102"])
print("G_shiftmean181:", d["exploratory"]["G_shiftmean181"])
