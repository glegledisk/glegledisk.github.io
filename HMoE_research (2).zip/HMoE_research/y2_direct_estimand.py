#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Y2: 中心命題（保留 1）の直接検定。estimand を「不均一性の主効果 Dbar」に固定。

事前登録: `Y2課題設計書_estimandを主効果Dbarに固定しparams揃え60seedで中心命題を直接検定_20261110.md`
腕・estimand・delta・n・Holm・ゲート・校正・判定規則はすべて実行前に固定。

★ Y1 の本命 P1 = d_1024 - d_688 は d_W = theta + phi*W の下で 336*phi となり、
  不均一性の主効果 theta を代数消去する。本次は Dbar = (d_1024 + d_688)/2 を
  主 estimand に置く。各括弧内で幅和 W が一致するため params 主効果は消える。

確認的ファミリ (Holm m=2, alpha=0.05):
  T1 = Dbar の両側 paired t
  T2 = Dbar の TOST 等価 (delta=0.05)

腕: H_1024 / U_1024 / H_688 / U_688 (+ 各 oracle)。
  H_1024 / U_688 の seed 100..159 は Z3 の ckpt を C1 ビット再現で流用。
  U_1024 / H_688 の seed 100..159 のみ新規訓練 (120 走行)。
R_1024 / R_688 は既存 seed 0..7 のみ（位置対照・探索的）。

出力: y2_results.json / y2_delta.npz / y2_analysis.json / y2_calib.json /
      y2_train.json / y2_out_utf8.txt / simulation_hmoe_mmlu/data/y2/ckpt_*.pt
"""
import argparse
import hashlib
import json
import math
import os
import sys
import time

import numpy as np
import torch
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# ★ Y1 が q8/q2/e2 を正しい順で import 済み。Y1 経由で測器を流用する。
import y1_equal_macs_2x2 as Y1            # noqa: E402

Q2, Q8 = Y1.Q2, Y1.Q8
assert Y1.E2.SEQ == 128
assert tuple(Y1.WIDTHS_A["U_1024"]) == (128,) * 8
assert sum(Y1.WIDTHS_A["H_688"]) == 688

DATA = os.path.join(HERE, "simulation_hmoe_mmlu", "data")
W2DIR = os.path.join(DATA, "w2")
Y1DIR = os.path.join(DATA, "y1")
Z1DIR = os.path.join(DATA, "z1")
Z2DIR = os.path.join(DATA, "z2")
Z3DIR = os.path.join(DATA, "z3")
Y2DIR = os.path.join(DATA, "y2")
Y2SMOKEDIR = os.path.join(DATA, "y2_smoke")
ACTIVE_Y2DIR = Y2DIR

ARMS = ("H_1024", "U_1024", "H_688", "U_688")
ORACLE_ARMS = tuple(f"oracle_{a}" for a in ARMS)
ALL_ARMS = ARMS + ORACLE_ARMS
NEW_ARCHS = ("U_1024", "H_688")
REUSED_ARCHS = ("H_1024", "U_688")
R_ARMS = ("R_1024", "R_688")
LEGACY_SEEDS = tuple(range(8))
SEEDS_CONFIRM = tuple(range(100, 160))
SEEDS_SMOKE = (100,)

# 設計書 §3 / §4 の固定値。結果を見て変更しない。
DELTA_TOST = 0.05
DELTA_SENSITIVITY = (0.04141674564862646, 0.03)
ALPHA = 0.05
TAU_LOSS, TAU_IV, TAU_CE = 0.30, 0.10, 0.50
MIN_CONVERGED = 108                  # 90% of 120 new runs
E_FLAG_CAP = 6
EVAL_SEED, EVAL_SEED_GATE, EVAL_SEED_ROB = 777, 779, 778
N_EVAL = 1024
EPOCHS = Y1.EPOCHS                   # 6
TRAIN_LOG = os.path.join(HERE, "y2_train.json")

assert len(SEEDS_CONFIRM) == 60
assert EPOCHS == 6 and Y1.N_EVAL == N_EVAL


# ---------------------------------------------------------------------------
# ckpt の出所（走らせる前に固定）
# ---------------------------------------------------------------------------
def ckpt_path(arch, seed, active_dir=None):
    if arch not in Y1.WIDTHS_A:
        raise ValueError(f"未登録の腕: {arch}")
    if seed in LEGACY_SEEDS:
        if arch == "H_1024":
            return os.path.join(W2DIR, f"ckpt_H_s{seed}.pt")
        if arch == "U_1024":
            return os.path.join(W2DIR, f"ckpt_U_s{seed}.pt")
        if arch == "R_1024":
            return os.path.join(W2DIR, f"ckpt_R_s{seed}.pt")
        return os.path.join(Y1DIR, f"ckpt_{arch}_s{seed}.pt")
    if seed not in SEEDS_CONFIRM:
        raise ValueError(f"未登録の seed: {seed}")
    if arch in REUSED_ARCHS:
        return os.path.join(Z3DIR, f"ckpt_{arch}_s{seed}.pt")
    if arch in NEW_ARCHS:
        return os.path.join(active_dir or ACTIVE_Y2DIR,
                            f"ckpt_{arch}_s{seed}.pt")
    raise ValueError(f"seed {seed} に ckpt 出所が未定義の腕: {arch}")


def load_arch(arch, seed, active_dir=None):
    path = ckpt_path(arch, seed, active_dir)
    td = torch.load(path, map_location="cpu")
    model = Y1.build_model(arch, seed)
    assert set(td.keys()) == set(model.p.keys()), \
        f"{arch} s{seed}: ckpt キー不一致"
    for kk in td:
        assert tuple(td[kk].shape) == tuple(model.p[kk].shape), \
            f"{arch} s{seed}: {kk} の形が違う"
    clean = {k: v.detach().clone() for k, v in td.items()}
    return model, clean


def fingerprint(path):
    """ckpt の軽量フィンガープリント（全テンソル先頭 64 float ずつ）。"""
    td = torch.load(path, map_location="cpu")
    h = hashlib.sha256()
    for k in sorted(td.keys()):
        h.update(k.encode("utf-8"))
        v = np.ascontiguousarray(
            td[k].detach().cpu().numpy(), dtype="<f4").reshape(-1)[:64]
        h.update(v.tobytes())
    return h.hexdigest()


def train_one(arch, seed, epochs=EPOCHS, save_path=None):
    """Y1.train_one と完全同一の訓練（forward_generic）だが保存先を明示する。

    Y1.train_one は ACTIVE_Y1DIR に書くため、そのまま使うと校正用の
    seed 0..7 の ckpt 出所を汚す。本次は save_path を必須にした複製を使う。
    """
    if arch not in Y1.WIDTHS_A:
        raise ValueError(f"未登録の腕: {arch}")
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    model = Y1.build_model(arch, seed)
    assert tuple(model.dims) == tuple(Y1.WIDTHS_A[arch])
    opt = Y1.Adam(model.params(), lr=Y1.LR)
    nparam = int(sum(v.numel() for v in model.params().values()))
    steps = max(1, Y1.SEQS // Y1.BS)
    hist = []
    t0 = time.time()
    for _ in range(epochs):
        run = 0.0
        for __ in range(steps):
            xs, ty = Q2.make_trace_batch(rng, Y1.BS, task="hard")
            x = torch.from_numpy(xs)
            t = torch.from_numpy(ty)
            logits, aux, _ = Y1.forward_generic(model, x, typ=t, k=2)
            loss = Q2.trace_loss(logits, xs) + Y1.AUXW * aux
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        hist.append(float(run / steps))
    params = {k: v.detach().clone() for k, v in model.params().items()}
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        torch.save({k: v.detach() for k, v in params.items()}, save_path)
    row = {"arch": arch, "seed": seed, "widths": list(Y1.WIDTHS_A[arch]),
           "nparam": nparam, "loss_hist": hist,
           "backend": "forward_generic",
           "sec": round(time.time() - t0, 1)}
    return row, params


def gate_eval(arch, seed, seq_gate, typ_gate, active_dir):
    """eval 側ゲート測定（Z3 継承）。"""
    model, clean = load_arch(arch, seed, active_dir)
    Y1.fresh(model, clean)
    m, x = Y1.evaluate_generic(model, seq_gate, typ_gate, k=2)
    iv = float(m["instr_valid"])
    ce = float(np.mean(x["ce_seq"]))
    finite = bool(np.isfinite(iv) and np.isfinite(ce)
                  and np.isfinite(x["ce_seq"]).all())
    return {"iv_gate": iv, "ce_seq_gate": ce,
            "n_eval": int(len(x["ce_seq"])), "finite": finite,
            "in_range": bool(finite and 0.0 <= iv <= 1.0)}


def evaluate_arm(arch, seed, seq, typ, active_dir, oracle=False):
    model, clean = load_arch(arch, seed, active_dir)
    if oracle:
        info = Y1.apply_oracle(model, clean)
    else:
        Y1.fresh(model, clean)
        info = {"n_zeroed": 0, "keys": []}
    m, x = Y1.evaluate_generic(model, seq, typ, k=2)
    return model, clean, m, x, info


# ---------------------------------------------------------------------------
# 統計（設計書 §4）
# ---------------------------------------------------------------------------
def paired(d):
    d = np.asarray(d, dtype=float)
    n = len(d)
    mean = float(d.mean())
    sd = float(d.std(ddof=1)) if n > 1 else float("nan")
    se = sd / math.sqrt(n) if n > 1 else float("nan")
    df = n - 1
    if df > 0 and se and np.isfinite(se) and se > 0:
        t = mean / se
        p = float(2 * stats.t.sf(abs(t), df))
        mde = float(stats.t.ppf(0.975, df) * se)
        ci90 = [float(mean - stats.t.ppf(0.95, df) * se),
                float(mean + stats.t.ppf(0.95, df) * se)]
        ci95 = [float(mean - stats.t.ppf(0.975, df) * se),
                float(mean + stats.t.ppf(0.975, df) * se)]
    else:
        t, p, mde = 0.0, 1.0, float("nan")
        ci90 = [mean, mean]
        ci95 = [mean, mean]
    return {"delta": mean, "sd": sd, "se": se, "t": float(t), "p": p,
            "n": n, "df": df, "mde": mde, "ci90": ci90, "ci95": ci95,
            "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
            "per_seed": [float(v) for v in d]}


def tost(d, margin):
    r = paired(d)
    if not (np.isfinite(r["se"]) and r["se"] > 0):
        return {"margin": float(margin), "p_low": 1.0, "p_high": 1.0,
                "p_tost": 1.0, "equivalent_raw": False,
                "delta": r["delta"], "se": r["se"], "ci90": r["ci90"]}
    p_low = float(stats.t.sf((r["delta"] + margin) / r["se"], r["df"]))
    p_high = float(stats.t.cdf((r["delta"] - margin) / r["se"], r["df"]))
    p_tost = max(p_low, p_high)
    ci = r["ci90"]
    return {"margin": float(margin), "p_low": p_low, "p_high": p_high,
            "p_tost": p_tost,
            "equivalent_raw": bool(p_tost < ALPHA
                                   and ci[0] > -margin and ci[1] < margin),
            "delta": r["delta"], "se": r["se"], "ci90": ci}


def holm2(pairs):
    order = sorted(pairs, key=lambda kv: kv[1])
    run, out = 0.0, {}
    for rank, (name, p) in enumerate(order):
        run = max(run, min(1.0, (len(order) - rank) * p))
        out[name] = {"p_raw": float(p), "p_holm": float(run),
                     "rank": rank + 1, "m": len(order)}
    return out


# ---------------------------------------------------------------------------
# 校正
# ---------------------------------------------------------------------------
def _item(name, arch, seed, field, want, got, ok):
    try:
        diff = abs(float(want) - float(got))
    except (TypeError, ValueError):
        diff = 0.0 if ok else 1.0
    return {"check": name, "arch": arch, "seed": seed, "field": field,
            "want": want, "got": got, "abs_diff": float(diff),
            "bit_match": bool(ok)}


def calibration_c1(ce_main, iv_main, seeds, log):
    """Z3 の H_1024 / U_688 を本次プロセスで再評価し z3_delta.npz と照合。"""
    z = np.load(os.path.join(HERE, "z3_delta.npz"), allow_pickle=True)
    za = [str(a) for a in z["arms"]]
    zs = [int(s) for s in z["seeds"]]
    items = []
    for arm in REUSED_ARCHS:
        i = [str(a) for a in ce_main["arms"]].index(arm)
        zi = za.index(arm)
        for j, s in enumerate(seeds):
            k = zs.index(s)
            ref_ce = z["ce_seq"][zi][k]
            ref_iv = float(z["iv"][zi][k])
            got_ce = ce_main["ce_seq"][i][j]
            got_iv = float(iv_main[i][j])
            d_ce = float(np.abs(got_ce - ref_ce).max())
            d_iv = abs(got_iv - ref_iv)
            items.append(_item("C1_z3_ce_seq", arm, s, "max_abs_ce_seq",
                               0.0, d_ce, d_ce < 1e-12))
            items.append(_item("C1_z3_iv", arm, s, "abs_iv",
                               0.0, d_iv, d_iv < 1e-12))
    out = {"n": len(items), "all_bit_match": all(x["bit_match"] for x in items)}
    log(f"C1 (Z3 ビット再現): {out}")
    return items, out


def calibration_c2(active_dir, log, do_repro=True):
    """新規 2 腕 s100 を 6 epoch 再訓練し本次 ckpt と全テンソル比較。"""
    items = []
    if not do_repro:
        return items, {"skipped": True, "all_bit_match": True}
    for arch in NEW_ARCHS:
        _, params = train_one(arch, 100, epochs=EPOCHS, save_path=None)
        orig = torch.load(ckpt_path(arch, 100, active_dir), map_location="cpu")
        diff = 0.0
        assert set(orig.keys()) == set(params.keys())
        for kk in orig:
            diff = max(diff, float((orig[kk] - params[kk]).abs().max()))
        items.append(_item("C2_repro", arch, 100, "all_params_max_abs",
                           0.0, diff, diff < 1e-12))
    out = {"n": len(items), "all_bit_match": all(x["bit_match"] for x in items)}
    log(f"C2 (6 epoch 再訓練): {out}")
    return items, out


def calibration_c3(log):
    items = []
    for arch in ARMS:
        m = Y1.build_model(arch, 100)
        nparam = int(sum(v.numel() for v in m.params().values()))
        expect = 1346877 if sum(Y1.WIDTHS_A[arch]) == 1024 else 1001469
        items.append(_item("C3", arch, 100, "nparam", expect, nparam,
                           nparam == expect))
        items.append(_item("C3", arch, 100, "widths",
                           str(list(Y1.WIDTHS_A[arch])), str(list(m.dims)),
                           list(m.dims) == list(Y1.WIDTHS_A[arch])))
    raised = 0
    try:
        ckpt_path("__unknown__", 100)
    except ValueError:
        raised += 1
    items.append(_item("C3", "-", 100, "unknown_raises", 1, raised,
                       raised == 1))
    out = {"n": len(items), "all_bit_match": all(x["bit_match"] for x in items)}
    log(f"C3: {out}")
    return items, out


def calibration_c5(seq, typ, active_dir, log):
    """forward_generic と Q8.forward_dispatch(dynamic_lb) のビット一致。"""
    model, clean = load_arch("H_1024", 100, active_dir)
    Y1.fresh(model, clean)
    x = torch.from_numpy(seq[:32])
    t = torch.from_numpy(typ[:32])
    with torch.no_grad():
        a, auxa, ia = Q8.forward_dispatch(model, x, typ=t, mode="dynamic_lb")
        b, auxb, ib = Y1.forward_generic(model, x, typ=t, k=2)
    dl = float((a - b).abs().max())
    da = abs(float(auxa) - float(auxb))
    di = float(max(float((u != v).float().max()) for u, v in zip(ia, ib)))
    items = [
        _item("C5", "H_1024", 100, "logits", 0.0, dl, dl < 1e-12),
        _item("C5", "H_1024", 100, "aux_and_topi", 0.0, da + di,
              da + di < 1e-12),
    ]
    out = {"n": len(items), "all_bit_match": all(x["bit_match"] for x in items),
           "max_abs_logits": dl, "max_abs_aux": da, "max_abs_topi": di}
    log(f"C5 (backend ビット一致): {out}")
    return items, out


def calibration_c6(seq, typ, log):
    """本次 evaluator の seed 0..7 が Y1 の P3 配列と全要素一致するか。"""
    y = np.load(os.path.join(HERE, "y1_delta.npz"), allow_pickle=True)
    ya = [str(a) for a in y["arms"]]
    ys = [int(s) for s in y["seeds"]]
    ih, iu = ya.index("H_1024"), ya.index("U_1024")
    mine_ce, mine_iv = [], []
    for s in LEGACY_SEEDS:
        vals = {}
        for arm in ("H_1024", "U_1024"):
            model, clean = load_arch(arm, s)
            Y1.fresh(model, clean)
            m, x = Y1.evaluate_generic(model, seq, typ, k=2)
            vals[arm] = (x["ce_seq"], float(m["instr_valid"]))
        mine_ce.append(vals["H_1024"][0] - vals["U_1024"][0])
        mine_iv.append(vals["H_1024"][1] - vals["U_1024"][1])
    mine_ce = np.asarray(mine_ce)
    mine_iv = np.asarray(mine_iv)
    cols = [ys.index(s) for s in LEGACY_SEEDS]
    ref_ce = y["ce_seq"][ih][cols] - y["ce_seq"][iu][cols]
    ref_iv = y["iv"][ih][cols] - y["iv"][iu][cols]
    d_ce = float(np.abs(mine_ce - ref_ce).max())
    d_iv = float(np.abs(mine_iv - ref_iv).max())
    ok = bool(d_ce < 1e-12 and d_iv < 1e-12)
    item = _item("C6_y1_p3_bitmatch", "P3", -1, "max_abs", 0.0,
                 max(d_ce, d_iv), ok)
    out = {"n_values": int(mine_ce.size + mine_iv.size),
           "max_abs_ce_seq": d_ce, "max_abs_iv": d_iv, "bit_match": ok}
    log(f"C6 (Y1 P3 ビット一致): {out}")
    return [item], out


def calibration_c7p(new_seeds, active_dir, log):
    """新規 120 ckpt が既存 ckpt のいずれとも衝突せず、新規内重複も 0。"""
    existing = set()
    n_existing = 0
    for d in (W2DIR, Y1DIR, Z1DIR, Z2DIR, Z3DIR):
        if not os.path.isdir(d):
            continue
        for f in sorted(os.listdir(d)):
            if f.startswith("ckpt_") and f.endswith(".pt"):
                existing.add(fingerprint(os.path.join(d, f)))
                n_existing += 1
    newfp = set()
    collisions = []
    for s in new_seeds:
        for a in NEW_ARCHS:
            fp = fingerprint(ckpt_path(a, s, active_dir))
            if fp in existing:
                collisions.append(f"{a}_s{s}")
            newfp.add(fp)
    n_new = len(new_seeds) * len(NEW_ARCHS)
    out = {"n_existing_all_dirs": n_existing, "n_new_ckpt": n_new,
           "n_unique_fingerprints": len(newfp),
           "duplicate_within_new": int(n_new - len(newfp)),
           "collisions_with_existing": collisions,
           "bit_match": bool(not collisions and n_new == len(newfp))}
    log(f"C7': {out}")
    return [_item("C7p_new_ckpt_uniqueness", "-", -1, "bit_match",
                  True, out["bit_match"], out["bit_match"])], out


def calibration_c8(seq_gate, typ_gate, active_dir, log):
    """gate 779 の同一 ckpt 2 回評価がビット一致するか。"""
    vals = []
    for _ in range(2):
        model, clean = load_arch("U_1024", 100, active_dir)
        Y1.fresh(model, clean)
        m, x = Y1.evaluate_generic(model, seq_gate, typ_gate, k=2)
        vals.append((float(m["instr_valid"]),
                     np.asarray(x["ce_seq"], dtype=np.float64)))
    d_iv = abs(vals[0][0] - vals[1][0])
    d_ce = float(np.abs(vals[0][1] - vals[1][1]).max())
    ok = bool(d_iv < 1e-12 and d_ce < 1e-12)
    items = [_item("C8_gate_bit_repro_iv", "U_1024", 100, "max_abs",
                   0.0, d_iv, ok),
             _item("C8_gate_bit_repro_ce", "U_1024", 100, "max_abs",
                   0.0, d_ce, ok)]
    out = {"max_abs_iv": d_iv, "max_abs_ce_seq": d_ce, "bit_match": ok}
    log(f"C8: {out}")
    return items, out


def calibration_c9(iv_main, rows, log):
    """床ラベル iv_main < 0.10 を独立 2 実装で再計算し一致を確認。"""
    idx = {a: i for i, a in enumerate(ARMS)}
    ivmap = {(r["arm"], int(r["seed"])): float(r["instr_valid"])
             for r in rows if r["arm"] in ARMS}
    diffs = []
    for j in range(iv_main.shape[1]):
        s = int(SEEDS_CONFIRM[j]) if iv_main.shape[1] == 60 else 100
        for a in ARMS:
            if (a, s) in ivmap:
                diffs.append(abs(float(iv_main[idx[a]][j])
                                 - ivmap[(a, s)]))
    d = max(diffs) if diffs else 0.0
    ok = bool(d < 1e-12 and len(diffs) == iv_main.shape[1] * len(ARMS))
    items = [_item("C9_floor_label_two_impl", "-", -1, "max_abs",
                   0.0, d, ok),
             _item("C9_floor_label_count", "-", -1, "n_compared",
                   iv_main.shape[1] * len(ARMS), len(diffs), ok)]
    out = {"n_compared": len(diffs), "max_abs": d, "bit_match": ok}
    log(f"C9: {out}")
    return items, out


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=list(SEEDS_CONFIRM))
    ap.add_argument("--train_seeds", nargs="+", type=int,
                    default=list(SEEDS_CONFIRM))
    ap.add_argument("--tag", default="y2")
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--n_eval", type=int, default=N_EVAL)
    ap.add_argument("--epochs", type=int, default=EPOCHS)
    ap.add_argument("--reuse", action="store_true")
    ap.add_argument("--train_only", action="store_true")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--no_repro", action="store_true")
    args = ap.parse_args()

    global ACTIVE_Y2DIR
    ACTIVE_Y2DIR = Y2SMOKEDIR if args.smoke else Y2DIR
    train_log = os.path.join(HERE, "y2_smoke_train.json") \
        if args.smoke else TRAIN_LOG
    if args.smoke:
        args.seeds = list(SEEDS_SMOKE)
        args.train_seeds = list(SEEDS_SMOKE)
        args.epochs = 1
    torch.set_num_threads(args.threads)
    torch.manual_seed(12345)
    os.makedirs(ACTIVE_Y2DIR, exist_ok=True)

    tag = args.tag
    LOG = os.path.join(HERE, f"{tag}_out_utf8.txt")
    if os.path.exists(LOG):
        os.remove(LOG)

    def log(msg):
        print(msg, flush=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")

    for s in args.seeds:
        assert s in LEGACY_SEEDS or s in SEEDS_CONFIRM, \
            f"未登録の評価 seed: {s}"
    for s in args.train_seeds:
        assert s in SEEDS_CONFIRM, f"未登録の訓練 seed: {s}"
    if not args.smoke:
        assert list(args.seeds) == list(SEEDS_CONFIRM), \
            "確認標本は seed 100..159 の 60 個で固定"
        assert args.epochs == EPOCHS and args.n_eval == N_EVAL
    log(f"Y2: threads={args.threads} arms={list(ALL_ARMS)} "
        f"eval_seeds={len(args.seeds)} train_seeds={len(args.train_seeds)} "
        f"reuse={args.reuse} train_only={args.train_only} "
        f"resume={args.resume} smoke={args.smoke}")
    log(f"  固定値: estimand=Dbar delta_TOST={DELTA_TOST} ALPHA={ALPHA} "
        f"Holm m=2 tau_iv={TAU_IV} tau_ce={TAU_CE} "
        f"main={EVAL_SEED} gate={EVAL_SEED_GATE} rob={EVAL_SEED_ROB}")

    seq, typ = Q2.make_trace_batch(np.random.default_rng(EVAL_SEED),
                                   args.n_eval, task="hard")
    seq_gate, typ_gate = Q2.make_trace_batch(
        np.random.default_rng(EVAL_SEED_GATE), args.n_eval, task="hard")
    seq_rob, typ_rob = Q2.make_trace_batch(
        np.random.default_rng(EVAL_SEED_ROB), args.n_eval, task="hard")
    log(f"eval batch: main={seq.shape} gate={seq_gate.shape} "
        f"rob={seq_rob.shape} SPAN={Y1.SPAN}")

    # ---------------- 新規 2 腕の訓練＋訓練直後の gate 評価 ----------------
    by_key = {}
    if (args.resume or args.reuse) and os.path.exists(train_log):
        with open(train_log, encoding="utf-8") as f:
            for r in json.load(f).get("rows", []):
                by_key[(r["arch"], int(r["seed"]))] = r
        log(f"  [restore] {os.path.basename(train_log)} から "
            f"{len(by_key)} 走行を復元")

    def save_train():
        rows = [by_key[k] for k in sorted(by_key)]
        with open(train_log, "w", encoding="utf-8") as f:
            json.dump({"rows": rows, "args": vars(args)},
                      f, ensure_ascii=False, indent=2, default=float)

    for seed in args.train_seeds:
        for arch in NEW_ARCHS:
            key = (arch, seed)
            path = ckpt_path(arch, seed, ACTIVE_Y2DIR)
            row = by_key.get(key)
            already = bool((args.resume or args.reuse) and row
                           and row.get("gate") and os.path.exists(path))
            if not already:
                row, _ = train_one(arch, seed, epochs=args.epochs,
                                   save_path=path)
                row["gate"] = gate_eval(arch, seed, seq_gate, typ_gate,
                                        ACTIVE_Y2DIR)
                by_key[key] = row
                save_train()
                log(f"  [train] {arch} s{seed} backend={row['backend']} "
                    f"loss[-1]={row['loss_hist'][-1]:.4f} {row['sec']}s | "
                    f"gate iv={row['gate']['iv_gate']:.4f} "
                    f"ce={row['gate']['ce_seq_gate']:.5f}")
            else:
                log(f"  [skip] {arch} s{seed} ckpt/gate あり")

    train_rows = [by_key[k] for k in sorted(by_key)]
    if args.train_only:
        log(f"train_only 完了: {os.path.basename(train_log)} 累計 "
            f"{len(train_rows)} 走行")
        os._exit(0)

    if not args.smoke:
        need = {(a, s) for a in NEW_ARCHS for s in SEEDS_CONFIRM}
        assert need.issubset(set(by_key)), \
            f"訓練行が不足: {len(need - set(by_key))} 件"
        for k in need:
            assert by_key[k].get("gate") is not None, f"gate 欠損: {k}"

    # ---------------- 本番評価 ----------------
    na, ns = len(ALL_ARMS), len(args.seeds)
    aa = {a: i for i, a in enumerate(ALL_ARMS)}
    iv = np.full((na, ns), np.nan)
    ce_all = np.full((na, ns), np.nan)
    act_w = np.full((na, ns), np.nan)
    instr_seq = np.zeros((na, ns, args.n_eval), dtype=np.int8)
    ce_seq = np.zeros((na, ns, args.n_eval), dtype=np.float64)
    nparam_arr = np.zeros(na, dtype=np.int64)
    rows = []
    t0 = time.time()
    for arm in ALL_ARMS:
        base = arm[len("oracle_"):] if arm.startswith("oracle_") else arm
        oracle = arm.startswith("oracle_")
        for seed in args.seeds:
            _, clean, m, x, info = evaluate_arm(
                base, seed, seq, typ, ACTIVE_Y2DIR, oracle=oracle)
            i, j = aa[arm], args.seeds.index(seed)
            iv[i, j] = m["instr_valid"]
            ce_all[i, j] = m["ce_all"]
            act_w[i, j] = m["active_width"]
            instr_seq[i, j] = x["instr_seq"]
            ce_seq[i, j] = x["ce_seq"]
            nparam_arr[i] = int(sum(v.numel() for v in clean.values()))
            rows.append({"arm": arm, "arch": base, "seed": seed, **m,
                         "n_zeroed": info["n_zeroed"],
                         "nparam": int(nparam_arr[i]),
                         "ckpt": os.path.relpath(
                             ckpt_path(base, seed, ACTIVE_Y2DIR), HERE)})
            log(f"  {arm:<18s} s{seed:3d} iv={m['instr_valid']:.4f} "
                f"ce={m['ce_all']:.5f} actW={m['active_width']:.1f}")
    log(f"本番評価 {na * ns} 件: {time.time() - t0:.0f}s")

    # gate 779（4 腕）
    iv_gate = np.full((len(ARMS), ns), np.nan)
    ce_gate = np.full((len(ARMS), ns), np.nan)
    for i, arm in enumerate(ARMS):
        for j, seed in enumerate(args.seeds):
            model, clean = load_arch(arm, seed, ACTIVE_Y2DIR)
            Y1.fresh(model, clean)
            m, x = Y1.evaluate_generic(model, seq_gate, typ_gate, k=2)
            iv_gate[i, j] = m["instr_valid"]
            ce_gate[i, j] = float(np.mean(x["ce_seq"]))

    # ロバストネス 778（4 腕）
    ce_seq_rob = np.zeros((len(ARMS), ns, args.n_eval), dtype=np.float64)
    iv_rob = np.full((len(ARMS), ns), np.nan)
    for i, arm in enumerate(ARMS):
        for j, seed in enumerate(args.seeds):
            model, clean = load_arch(arm, seed, ACTIVE_Y2DIR)
            Y1.fresh(model, clean)
            m, x = Y1.evaluate_generic(model, seq_rob, typ_rob, k=2)
            ce_seq_rob[i, j] = x["ce_seq"]
            iv_rob[i, j] = m["instr_valid"]

    # R 腕（seed 0..7 のみ・探索的位置対照）
    r_ce = {}
    for arm in R_ARMS:
        vals = []
        for s in LEGACY_SEEDS:
            model, clean = load_arch(arm, s)
            Y1.fresh(model, clean)
            m, x = Y1.evaluate_generic(model, seq, typ, k=2)
            vals.append(float(np.mean(x["ce_seq"])))
        r_ce[arm] = vals

    # ---------------- 校正（主判定の前に全項目を確定） ----------------
    tc = time.time()
    calib = []
    c1_items, c1 = calibration_c1(
        {"arms": np.array(ALL_ARMS, dtype=object), "ce_seq": ce_seq},
        iv, args.seeds, log)
    calib += c1_items
    c2_items, c2 = calibration_c2(ACTIVE_Y2DIR, log,
                                  do_repro=not args.no_repro)
    calib += c2_items
    c3_items, c3 = calibration_c3(log)
    calib += c3_items
    c5_items, c5 = calibration_c5(seq, typ, ACTIVE_Y2DIR, log)
    calib += c5_items
    c6_items, c6 = calibration_c6(seq, typ, log)
    calib += c6_items
    c7_items, c7 = calibration_c7p(
        list(SEEDS_SMOKE) if args.smoke else list(SEEDS_CONFIRM),
        ACTIVE_Y2DIR, log)
    calib += c7_items
    c8_items, c8 = calibration_c8(seq_gate, typ_gate, ACTIVE_Y2DIR, log)
    calib += c8_items
    c9_items, c9 = calibration_c9(iv[:len(ARMS)], rows, log)
    calib += c9_items
    ok_calib = all(x["bit_match"] for x in calib)
    cal = {"items": calib, "n": len(calib), "all_bit_match": ok_calib,
           "C1": c1, "C2": c2, "C3": c3, "C5": c5, "C6": c6,
           "C7p": c7, "C8": c8, "C9": c9}
    with open(os.path.join(HERE, f"{tag}_calib.json"), "w",
              encoding="utf-8") as f:
        json.dump(cal, f, ensure_ascii=False, indent=2, default=float)
    log(f"校正 総項目: {sum(1 for x in calib if x['bit_match'])}/"
        f"{len(calib)} all={ok_calib} ({time.time() - tc:.0f}s)")
    if not ok_calib:
        log("校正が落ちたので本番を走らせない。原因を調べること。")
        os._exit(1)

    # ---------------- 保存 ----------------
    with open(os.path.join(HERE, f"{tag}_results.json"), "w",
              encoding="utf-8") as f:
        json.dump({"rows": rows, "train_rows": train_rows,
                   "args": vars(args), "arms": list(ALL_ARMS),
                   "seeds": list(args.seeds),
                   "estimand": "Dbar = (d_1024 + d_688)/2",
                   "delta_tost": DELTA_TOST,
                   "eval_seeds": {"main": EVAL_SEED, "gate": EVAL_SEED_GATE,
                                  "rob": EVAL_SEED_ROB},
                   "r_arms_ce_seq": r_ce},
                  f, ensure_ascii=False, indent=2, default=float)
    np.savez_compressed(
        os.path.join(HERE, f"{tag}_delta.npz"),
        arms=np.array(ALL_ARMS, dtype=object), seeds=np.array(args.seeds),
        iv=iv, ce_all=ce_all, active_width=act_w,
        instr_seq=instr_seq, ce_seq=ce_seq, nparam=nparam_arr,
        rob_arms=np.array(ARMS, dtype=object),
        ce_seq_rob=ce_seq_rob, iv_rob=iv_rob,
        gate_arms=np.array(ARMS, dtype=object),
        iv_gate=iv_gate, ce_seq_gate=ce_gate)

    # ---------------- 主解析 ----------------
    H1, U1 = aa["H_1024"], aa["U_1024"]
    H6, U6 = aa["H_688"], aa["U_688"]
    d1024 = ce_seq[H1].mean(axis=1) - ce_seq[U1].mean(axis=1)
    d688 = ce_seq[H6].mean(axis=1) - ce_seq[U6].mean(axis=1)
    dbar = 0.5 * (d1024 + d688)
    p1 = d1024 - d688
    r_dbar = paired(dbar)
    r_p1 = paired(p1)
    t1 = tost(dbar, DELTA_TOST)
    holm = holm2([("T1_two_sided", r_dbar["p"]),
                  ("T2_tost", t1["p_tost"])])
    t1_rej = bool(holm["T1_two_sided"]["p_holm"] < ALPHA)
    t2_rej = bool(holm["T2_tost"]["p_holm"] < ALPHA
                  and t1["p_tost"] < ALPHA and t1["equivalent_raw"])

    # ゲート（★ 再利用腕の loss は z3_train.json にしか無い）
    loss_by = {(r["arch"], int(r["seed"])): r["loss_hist"][-1]
               for r in train_rows if r.get("loss_hist")}
    z3log = os.path.join(HERE, "z3_train.json")
    if os.path.exists(z3log):
        with open(z3log, encoding="utf-8") as f:
            for r in json.load(f).get("rows", []):
                if r["arch"] in REUSED_ARCHS and r.get("loss_hist"):
                    loss_by.setdefault((r["arch"], int(r["seed"])),
                                       r["loss_hist"][-1])
    loss_flat = np.array([r["loss_hist"][-1] for r in train_rows],
                         dtype=float)
    n_conv = int((loss_flat < TAU_LOSS).sum()) if loss_flat.size else 0
    med_loss = float(np.median(loss_flat)) if loss_flat.size else None
    if args.smoke:
        g1 = {"n": int(loss_flat.size), "median_last_loss": med_loss,
              "n_below_030": n_conv, "required": 0,
              "pass": bool(loss_flat.size > 0)}
    else:
        g1 = {"n": int(loss_flat.size), "median_last_loss": med_loss,
              "n_below_030": n_conv, "required": MIN_CONVERGED,
              "pass": bool(loss_flat.size >= 2 * len(SEEDS_CONFIRM)
                           and med_loss is not None
                           and med_loss < TAU_LOSS
                           and n_conv >= MIN_CONVERGED)}
    bad_gate = []
    for i, arm in enumerate(ARMS):
        for j, s in enumerate(args.seeds):
            if not (np.isfinite(iv_gate[i, j])
                    and 0.0 <= iv_gate[i, j] <= 1.0
                    and np.isfinite(ce_gate[i, j])):
                bad_gate.append(f"{arm}_s{s}")
    g2 = {"n_expected": len(ARMS) * ns, "n_bad": len(bad_gate),
          "bad": bad_gate, "pass": bool(not bad_gate)}
    cells_te = {a: {"T+E+": 0, "T+E-": 0, "T-E+": 0, "T-E-": 0}
                for a in ARMS}
    for i, arm in enumerate(ARMS):
        for j, s in enumerate(args.seeds):
            loss = loss_by.get((arm, s), float("nan"))
            tplus = bool(np.isfinite(loss) and loss < TAU_LOSS)
            eplus = bool(np.isfinite(iv_gate[i, j])
                         and iv_gate[i, j] >= TAU_IV)
            cells_te[arm][("T+" if tplus else "T-")
                          + ("E+" if eplus else "E-")] += 1
    g3 = {"cells": cells_te, "n_excluded_from_primary": 0, "pass": True}
    ce_main_mean = ce_seq[[H1, U1, H6, U6]].mean(axis=2)
    eflag = (ce_main_mean > TAU_CE) | (ce_gate > TAU_CE)
    eflag_list = {ARMS[i]: [int(s) for s, f in
                            zip(args.seeds, eflag[i]) if f]
                  for i in range(len(ARMS))}
    g4 = {"flags": eflag_list,
          "n": {a: len(v) for a, v in eflag_list.items()},
          "cap": E_FLAG_CAP,
          "pass": bool(all(len(v) <= E_FLAG_CAP
                           for v in eflag_list.values()))}
    g5 = {}
    for arm in ARMS:
        o = aa[f"oracle_{arm}"]
        dd = (ce_seq[o] - ce_seq[aa[arm]]).mean(axis=1)
        g5[arm] = {"min_delta_ce_seq": float(dd.min()),
                   "mean_delta_ce_seq": float(dd.mean()),
                   "n_below_030": int((dd < 0.30).sum()),
                   "pass": bool(dd.min() >= 0.30)}
    g6 = {"Tplus_Eminus": {a: cells_te[a]["T+E-"] for a in ARMS},
          "pass": True}
    aw = {a: float(act_w[aa[a]].mean()) for a in ARMS}
    c4 = {"active_width_mean": aw,
          "delta_1024": aw["H_1024"] - aw["U_1024"],
          "delta_688": aw["H_688"] - aw["U_688"],
          "equal_macs_diagonal_rel_diff":
              abs(aw["H_1024"] - aw["U_688"])
              / max(1e-12, 0.5 * (aw["H_1024"] + aw["U_688"])),
          "record_only": True, "pass": True}
    hard_ok = bool(g1["pass"] and g2["pass"] and g4["pass"]
                   and all(v["pass"] for v in g5.values()) and ok_calib)
    if not hard_ok:
        case = "E"
    elif t1_rej and r_dbar["delta"] < 0:
        case = "A"
    elif t1_rej and r_dbar["delta"] > 0:
        case = "B"
    elif t2_rej:
        case = "C"
    else:
        case = "D"

    # ---------------- 探索的 ----------------
    sens = {str(m): tost(dbar, m) for m in DELTA_SENSITIVITY}
    p2 = ce_seq[H1].mean(axis=1) - ce_seq[U6].mean(axis=1)
    d_rob = 0.5 * ((ce_seq_rob[0] - ce_seq_rob[1]).mean(axis=1)
                   + (ce_seq_rob[2] - ce_seq_rob[3]).mean(axis=1))
    # Δactive_width を共変量とした直接効果の感度（OLS）
    da = 0.5 * ((act_w[H1] - act_w[U1]) + (act_w[H6] - act_w[U6]))
    if ns >= 3 and np.std(da) > 1e-12:
        X = np.column_stack([np.ones(ns), da])
        beta, *_ = np.linalg.lstsq(X, dbar, rcond=None)
        resid = dbar - X @ beta
        s2 = float(resid @ resid) / (ns - 2)
        cov = s2 * np.linalg.inv(X.T @ X)
        se_b0 = float(math.sqrt(cov[0, 0]))
        se_b1 = float(math.sqrt(cov[1, 1]))
        t_b1 = float(beta[1] / se_b1) if se_b1 > 0 else 0.0
        mediation = {"intercept_beta0": float(beta[0]),
                     "se_beta0": se_b0,
                     "slope_beta1": float(beta[1]), "se_beta1": se_b1,
                     "t_beta1": t_b1,
                     "p_beta1": float(2 * stats.t.sf(abs(t_b1), ns - 2)),
                     "delta_active_width_mean": float(da.mean())}
    else:
        mediation = {"skipped": True, "delta_active_width_mean":
                     float(da.mean()) if da.size else None}
    # 床率（McNemar・探索的）
    floor_rates = {}
    for lab, (ih, iu) in {"W1024": (H1, U1), "W688": (H6, U6)}.items():
        fh, fu = iv[ih] < TAU_IV, iv[iu] < TAU_IV
        b = int((fh & ~fu).sum())
        c = int((~fh & fu).sum())
        floor_rates[lab] = {
            "p_H": float(fh.mean()), "p_U": float(fu.mean()),
            "cells": {"both": int((fh & fu).sum()), "H_only": b,
                      "U_only": c, "neither": int((~fh & ~fu).sum())},
            "mcnemar_p": float(stats.binomtest(b, b + c, 0.5).pvalue)
            if b + c > 0 else None}
    # 位置対照（R 腕・8 seed）
    yd = np.load(os.path.join(HERE, "y1_delta.npz"), allow_pickle=True)
    ya = [str(a) for a in yd["arms"]]
    yc = yd["ce_seq"].mean(axis=2)
    pos = {}
    for lab, h, u, r in (("W1024", "H_1024", "U_1024", "R_1024"),
                         ("W688", "H_688", "U_688", "R_688")):
        hh = yc[ya.index(h)]
        pos[lab] = {"d_H_minus_U_n8": float((hh - yc[ya.index(u)]).mean()),
                    "d_H_minus_R_n8": float(
                        (hh - np.asarray(r_ce[r])).mean())}
    exploratory = {
        "delta_sensitivity": sens,
        "d_1024": paired(d1024), "d_688": paired(d688),
        "P1_interaction_at_n60": r_p1,
        "P2_equal_macs_diagonal": paired(p2),
        "Dbar_robustness_seed778": paired(d_rob),
        "direct_effect_active_width_adjusted": mediation,
        "floor_rate_mcnemar": floor_rates,
        "position_control_R_8seed": pos,
        "note": "すべて探索的。確認的ファミリは T1/T2 の Holm m=2 のみ。",
    }

    analysis = {
        "calibration": {"n": len(calib), "all_bit_match": ok_calib,
                        "C1": c1, "C2": c2, "C3": c3, "C5": c5,
                        "C6": c6, "C7p": c7, "C8": c8, "C9": c9},
        "primary": {
            "estimand": "Dbar = (d_1024 + d_688)/2",
            "n": int(ns), "seeds": list(args.seeds),
            "Dbar": r_dbar,
            "T1_two_sided": {"p_raw": r_dbar["p"],
                             "p_holm": holm["T1_two_sided"]["p_holm"],
                             "reject": t1_rej},
            "T2_tost": {**t1, "p_holm": holm["T2_tost"]["p_holm"],
                        "reject": t2_rej},
            "holm": holm,
            "d1024_per_seed": [float(v) for v in d1024],
            "d688_per_seed": [float(v) for v in d688],
        },
        "exploratory": exploratory,
        "gates": {"G1_train_convergence": g1, "G2_gate_finiteness": g2,
                  "G3_TxE_classification": g3, "G4_E_flag": g4,
                  "G5_oracle_sensitivity": g5, "G6_Tplus_Eminus": g6},
        "C4_active_width": c4,
        "baseline": {a: {"iv": float(iv[aa[a]].mean()),
                         "ce_all": float(ce_all[aa[a]].mean()),
                         "active_width": aw[a],
                         "nparam": int(nparam_arr[aa[a]])}
                     for a in ARMS},
        "verdict": {"case": case, "T1_reject": t1_rej, "T2_reject": t2_rej,
                    "hard_gates_ok": hard_ok,
                    "calibration_ok": ok_calib,
                    "claim_permitted": bool(case in ("A", "B", "C")),
                    "z1_rule3_still_forbidden": True},
        "meta": {"threads": args.threads, "n_eval": args.n_eval,
                 "eval_seed": EVAL_SEED, "eval_seed_gate": EVAL_SEED_GATE,
                 "eval_seed_rob": EVAL_SEED_ROB, "epochs": args.epochs,
                 "seqs": Y1.SEQS, "bs": Y1.BS, "lr": Y1.LR,
                 "auxw": Y1.AUXW, "seeds": list(args.seeds),
                 "arms": list(ALL_ARMS), "n_rows": len(rows),
                 "n_train": len(train_rows), "smoke": args.smoke,
                 "delta_tost": DELTA_TOST, "alpha": ALPHA,
                 "e_flag_cap": E_FLAG_CAP},
    }
    with open(os.path.join(HERE, f"{tag}_analysis.json"), "w",
              encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2, default=float)

    log("")
    log(f"== 主解析 n={ns}: Dbar={r_dbar['delta']:+.6f} "
        f"se={r_dbar['se']:.6f} t={r_dbar['t']:+.3f} "
        f"両側p={r_dbar['p']:.6g} MDE={r_dbar['mde']:.6f} "
        f"90%CI={r_dbar['ci90']} 符号 {r_dbar['n_pos']}正/"
        f"{r_dbar['n_neg']}負")
    log(f"== TOST delta={DELTA_TOST}: p_low={t1['p_low']:.6g} "
        f"p_high={t1['p_high']:.6g} p_tost={t1['p_tost']:.6g} "
        f"Holm={holm['T2_tost']['p_holm']:.6g} "
        f"equivalent={t1['equivalent_raw']}")
    log(f"== Holm T1={holm['T1_two_sided']['p_holm']:.6g} "
        f"T2={holm['T2_tost']['p_holm']:.6g}")
    log(f"== 探索的 P1(n=60)={r_p1['delta']:+.6f} p={r_p1['p']:.6g} "
        f"MDE={r_p1['mde']:.6f}")
    log(f"== gates G1={g1['pass']} G2={g2['pass']} G4={g4['pass']} "
        f"G5={ {k: v['pass'] for k, v in g5.items()} } "
        f"C4(record)={c4['equal_macs_diagonal_rel_diff']:.4f}")
    log(f"== case={case} verdict={analysis['verdict']}")
    log(f"saved: {tag}_results.json / {tag}_delta.npz / "
        f"{tag}_analysis.json / {tag}_calib.json")
    os._exit(0)


if __name__ == "__main__":
    main()
