# -*- coding: utf-8 -*-
"""_md_diag2_20261107.py — 残存 ** の前後を HTML で確認する使い捨て診断。"""
import re
import sys
from markdown_it import MarkdownIt

path = sys.argv[1]
lines = open(path, encoding="utf-8").read().split("\n")
md = MarkdownIt("commonmark").enable("table")
html = md.render("\n".join(lines))
for m in re.finditer(r"\*\*", html):
    a, b = max(0, m.start() - 90), min(len(html), m.end() + 90)
    print(repr(html[a:b]))
    print("---")
