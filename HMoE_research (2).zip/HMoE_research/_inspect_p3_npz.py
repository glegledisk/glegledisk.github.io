import numpy as np, json, sys

for f in ["p3_topk_nll.npz", "p3b_alloc_nll.npz", "p4_adaptive_nll.npz"]:
    print("=" * 60)
    print(f)
    d = np.load(f, allow_pickle=True)
    for k in d.files:
        a = d[k]
        try:
            print(f"  {k:24s} shape={str(a.shape):16s} dtype={a.dtype}")
        except Exception as e:
            print(f"  {k}: {e}")
    d.close()
