#!/usr/bin/env python3
"""Q9a: dense224 対照 — static_type の勝ちは「型分離」か「幅」か。

背景:
  Q8 の static_type は payload（80%）を幅 224 の expert 2 本に固定し、struct を幅 32 に落とす。
  しかし比較相手の dynamic_lb は payload 幅 85.2 で、static は 2.63 倍の幅を持つ。
  等幅の対照が無いので「型分離の効果」と「単に幅が大きい効果」が分離できない。
  （P13 は「等 active 幅では dense が最良」を測っている）

対照 2 つ:
  dense224   : 全トークンを幅 224 の単一 FFN（e6）に通す。gate=1.0、k=1。
               → static と同じ「1 トークンあたり幅 224」だが FFN FLOPs は半分（専門家 1 本）。
  dense224x2 : 全トークンを e6 と e7 の 0.5/0.5 混合に通す。gate=0.5、k=2。
               → static と**同一のパラメータ・同一の FLOPs**。違いは「型で分けるか」だけ。

判定:
  - dense224x2 が static_type と同等以上なら、**型分離は何もしていない**（幅だけの効果）。
  - dense224（半分の FLOPs）が static と同等なら、static は 2 本目の expert を無駄にしている。
  - どちらも static に負けるなら、型分離に固有の効果がある（初めて Q8 の主張が立つ）。

実装:
  q8_static_dispatch を import し、`forward_dispatch` をラップして dense モードだけ差し替える。
  dynamic_lb / dynamic_no_lb / static_type は **Q8 の関数オブジェクトをそのまま通す**ので、
  同一 seed なら Q8 の json とビット一致する（別実装による 1e-9 の分岐を避ける）。
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import q2_difficulty_ladder as Q2  # noqa: E402
from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS  # noqa: E402
import q8_static_dispatch as Q8  # noqa: E402

OUTDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q9")

# dense モードの定義: (使う expert のリスト, 各 expert の gate)
DENSE = {
    "dense224": ([6], [1.0]),        # 幅 224 × 1 本
    "dense224x2": ([6, 7], [0.5, 0.5]),  # 幅 224 × 2 本（static と同 FLOPs）
}


def forward_dense(model, idx, mode):
    """全トークンを固定の expert 集合に通す。attention は Q8 と同一。"""
    p = model.p
    B, T = idx.shape
    experts, gates = DENSE[mode]
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    idx_l = []

    # topi は (BT, 2) で記録する（evaluate_q8 が [:, :, 0] を top-1 として読むため）
    topi = torch.full((B * T, 2), experts[0], dtype=torch.int64)
    if len(experts) > 1:
        topi[:, 1] = experts[1]
    gate = torch.zeros((B * T, model.E), dtype=h.dtype)
    for e, g in zip(experts, gates):
        gate[:, e] = g

    aux_sum = torch.zeros(())
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        y = torch.zeros_like(h)
        for e in experts:
            x_tok = h
            h1 = F.relu(F.linear(x_tok, p[f"l{l}.e{e}.w1"], p[f"l{l}.e{e}.b1"]))
            y = y + F.linear(h1, p[f"l{l}.e{e}.w2"], p[f"l{l}.e{e}.b2"]) * gate[:, e].unsqueeze(1)

        h = h + y
        aux_sum = aux_sum + torch.zeros(())
        idx_l.append(topi.reshape(B, T, 2))

    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, -1)
    return out, aux_sum / model.L, idx_l


# --- Q8 の forward をラップする（dense 以外は元の関数をそのまま呼ぶ）---
_orig_forward = Q8.forward_dispatch


def patched_forward(model, idx, typ=None, mode="dynamic_lb"):
    if mode in DENSE:
        return forward_dense(model, idx, mode)
    return _orig_forward(model, idx, typ=typ, mode=mode)


Q8.forward_dispatch = patched_forward
Q8.OUTDIR = OUTDIR


def run_dense(task, mode, seed, n_seqs, epochs, bs, lr):
    """Q8.run と同じ手順。dense モードでも auxw=0 になる。"""
    return Q8.run(task, mode, seed, n_seqs, epochs, bs, lr)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", nargs="+", default=["compute", "hard"])
    ap.add_argument("--modes", nargs="+", default=["dense224", "dense224x2"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4, 5])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--outdir", default=None)
    ap.add_argument("--threads", type=int, default=6)
    args = ap.parse_args()

    global OUTDIR
    if args.outdir:
        OUTDIR = os.path.join(HERE, args.outdir)
        Q8.OUTDIR = OUTDIR
    os.makedirs(OUTDIR, exist_ok=True)
    torch.set_num_threads(args.threads)
    print(f"Q9a: tasks={args.tasks} modes={args.modes} seeds={args.seeds}", flush=True)

    rows = []
    for task in args.tasks:
        for mode in args.modes:
            for seed in args.seeds:
                p = os.path.join(OUTDIR, f"H+LB_{task}_{mode}_s{seed}.json")
                if args.resume and os.path.exists(p):
                    with open(p, encoding="utf-8") as f:
                        r = json.load(f)
                    if r.get("n_eval") == 1024:
                        print(f"  [skip] {task} {mode} s{seed}", flush=True)
                        rows.append(r)
                        continue
                r = run_dense(task, mode, seed, args.seqs, args.epochs, args.bs, args.lr)
                rows.append(r)
                e = r["eval"]["base"]
                print(f"  -> {task} {mode} s{seed}: "
                      f"acc pl={e['acc_payload']:.4f} iv={e['instr_valid']:.3f} "
                      f"ce pl={e['ce_payload']:.4f} "
                      f"w_st/pl={e['width_struct']:.1f}/{e['width_payload']:.1f} "
                      f"H={e['usage_entropy']:.3f}", flush=True)
                with open(p, "w", encoding="utf-8") as f:
                    json.dump(r, f, ensure_ascii=False, indent=2)

    with open(os.path.join(OUTDIR, "q9_results.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
    print(f"[write] {OUTDIR}", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
