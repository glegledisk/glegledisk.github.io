# -*- coding: utf-8 -*-
"""AX9 Step 4: 独立再計算（ax9_cross_ckpt.py を import しない別経路）。

scipy.stats.ttest_rel 経由で Δ・se・t・p・Holm・MDE・TOST・上位 1% 寄与率を作り直し、
ablate forward の生 NLL から c8 / c7 を、np.add.at で単位平均と cut / protect を再構成して
<tag>_cross_ckpt.json と突合する。使い方: python _ax9_verify.py [tag]
"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats as scistats

HERE = os.path.dirname(os.path.abspath(__file__))
TAG = sys.argv[1] if len(sys.argv) > 1 else "ax9"
ALPHA = 0.05
N_LAYERS = 16
MIN_SENT = 8
RAND_SEEDS = (1201, 1202, 1203)
DELTA_TOST = 0.005

ITEMS, MISMATCH = [], []


def chk(name, got, exp, rtol=1e-6, atol=1e-9):
    ITEMS.append(name)
    ok = False
    if isinstance(exp, (list, tuple)):
        try:
            ok = (len(got) == len(exp) and all(
                math.isclose(float(a), float(b), rel_tol=rtol, abs_tol=atol)
                for a, b in zip(got, exp)))
        except Exception:
            ok = (list(got) == list(exp))
    elif isinstance(exp, (bool, str)):
        ok = (got == exp)
    elif isinstance(exp, (int, np.integer)) and isinstance(got, (int, np.integer)):
        ok = (int(got) == int(exp))
    else:
        try:
            ok = math.isclose(float(got), float(exp), rel_tol=rtol, abs_tol=atol)
        except Exception:
            ok = False
    if not ok:
        MISMATCH.append((name, got, exp))


def rst(d, tok_per_win=255):
    """paired stats の独立実装（scipy ttest_rel 経由）。"""
    d = np.asarray(d, dtype=np.float64).ravel()
    n = d.size
    m = float(d.mean())
    t, p = scistats.ttest_rel(d, np.zeros_like(d))
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    df = n - 1
    tc975 = float(scistats.t.ppf(0.975, df))
    tc95 = float(scistats.t.ppf(0.95, df))
    wm = d.reshape(-1, tok_per_win).mean(axis=1)
    sew = float(wm.std(ddof=1) / math.sqrt(wm.size))
    srt = np.sort(np.abs(d))[::-1]
    k1 = max(1, int(math.ceil(0.01 * n)))
    return {"mean": m, "sd": sd, "se": se, "t": float(t), "p_two": float(p),
            "df": df, "mde": tc975 * se,
            "ci95": [m - tc975 * se, m + tc975 * se],
            "ci90": [m - tc95 * se, m + tc95 * se],
            "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
            "median": float(np.median(d)), "se_win": sew,
            "top1_abs_share": float(srt[:k1].sum() / srt.sum())}


def holm_adj(pvals):
    ids = sorted(pvals, key=lambda k: pvals[k])
    out, run = {}, 0.0
    for i, k in enumerate(ids):
        run = max(run, (len(ids) - i) * pvals[k])
        out[k] = min(1.0, run)
    return out


def tost_indep(st, delta):
    m, se, df = st["mean"], st["se"], st["df"]
    p_low = float(scistats.t.sf((m + delta) / se, df))
    p_high = float(scistats.t.cdf((m - delta) / se, df))
    p_tost = max(p_low, p_high)
    lo, hi = st["ci90"]
    return {"p_low": p_low, "p_high": p_high, "p_tost": p_tost,
            "equivalent": bool(p_tost < ALPHA and lo > -delta and hi < delta)}


def decision_from_Y(Y):
    cut = np.argmin(Y[:, N_LAYERS:], axis=1).astype(np.int8)
    Q = Y[:, :N_LAYERS].copy()
    Q[np.arange(Y.shape[0]), cut] = -np.inf
    prot = np.argmax(Q, axis=1).astype(np.int8)
    return cut, prot


def Y_indep(c8, c7, uid, n_unit):
    cnt = np.zeros(n_unit, dtype=np.float64)
    np.add.at(cnt, uid, 1.0)
    assert cnt.min() > 0
    a = np.zeros((n_unit, N_LAYERS), dtype=np.float64)
    b = np.zeros((n_unit, N_LAYERS), dtype=np.float64)
    for L in range(N_LAYERS):
        ta = np.zeros(n_unit, dtype=np.float64)
        tb = np.zeros(n_unit, dtype=np.float64)
        np.add.at(ta, uid, c8[L])
        np.add.at(tb, uid, c7[L])
        a[:, L], b[:, L] = ta / cnt, tb / cnt
    return np.concatenate([a, b], axis=1)


def budget_indep(uid, cut, prot, n_tok, nw, n_eval):
    km = np.full((N_LAYERS, n_tok), 7.0, dtype=np.float64)
    for u in range(len(cut)):
        sel = (uid == u)
        km[cut[u], sel] = 6.0
        km[prot[u], sel] = 8.0
    kmw = km.reshape(N_LAYERS, nw, n_eval)
    kmw = np.concatenate([kmw, np.full((N_LAYERS, nw, 1), 7.0)], axis=2)
    return float(kmw.mean()), int(kmw.sum(axis=0).max())


def random_decision_indep(seed, n_unit):
    rng = np.random.RandomState(seed)
    cut = rng.randint(0, N_LAYERS, size=n_unit).astype(np.int8)
    draw = rng.randint(0, N_LAYERS - 1, size=n_unit)
    return cut, (draw + (draw >= cut)).astype(np.int8)


def grams8(x):
    return set(tuple(int(v) for v in x[i:i + 8]) for i in range(len(x) - 7))


def overlap8(a, b):
    gb = grams8(b)
    return float(np.mean([tuple(int(v) for v in a[i:i + 8]) in gb
                         for i in range(len(a) - 7)]))


def finite_bad(obj, path="root"):
    bad = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            bad += finite_bad(v, path + "/" + str(k))
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            bad += finite_bad(v, path + "/%d" % i)
    elif isinstance(obj, (float, np.floating)) and not np.isfinite(obj):
        bad.append(path)
    return bad


def main():
    J = json.load(open(os.path.join(HERE, "%s_cross_ckpt.json" % TAG), encoding="utf-8"))
    z = np.load(os.path.join(HERE, "%s_cross_ckpt.npz" % TAG))
    meta = J["meta"]
    n_tok = int(meta["n_tok"])
    nw = int(meta["windows"])
    n_eval = int(meta["len"]) - 1
    c8, c7 = z["c8"].astype(np.float64), z["c7"].astype(np.float64)
    sent = z["sent"].astype(np.int64)
    N = {k[4:]: z[k].astype(np.float64) for k in z.files if k.startswith("nll_")}
    u7 = N["u7"]
    assert c8.shape == (N_LAYERS, n_tok) and u7.shape == (n_tok,)

    # ---- meta ----
    chk("meta.n_tok", n_tok, sent.size)
    chk("meta.windows", nw, sent.size // n_eval)
    chk("meta.n_sent", int(meta["n_sent"]), int(sent.max()) + 1)
    chk("meta.n_new_forwards", int(meta["n_new_forwards"]), 45)
    chk("meta.n_nll_arrays", len(N), 45)

    # ---- 1. c8 / c7 を ablate forward から独立再計算 ----
    for L in range(N_LAYERS):
        chk("c8.L%02d" % L, float(np.abs(
            c8[L] - (N["ab7_%02d" % L] - N["base_cap"])).max()), 0.0, atol=1e-12)
        chk("c7.L%02d" % L, float(np.abs(
            c7[L] - (N["ab6_%02d" % L] - N["ab7_%02d" % L])).max()), 0.0, atol=1e-12)

    # ---- 2. gains 全腕 ----
    for nm, rj in J["gains"].items():
        s = rst(u7 - N[nm], n_eval)
        for key, val in s.items():
            if key in rj:
                chk("gain.%s.%s" % (nm, key), rj[key], val)

    # ---- 3. 確認的検定を生配列から再構成 ----
    d1 = u7 - N["sent_probe"]
    d2 = N["sent_probe"] - N["sent_oracle"]
    conf = J["confirmatory"]
    s1, s2 = rst(d1, n_eval), rst(d2, n_eval)
    for key, s in (("S1_probe", s1), ("S2_gap", s2)):
        rj = conf[key]
        for k, val in s.items():
            if k in rj:
                chk("confirm.%s.%s" % (key, k), rj[k], val)
        chk("confirm.%s.n" % key, rj["n"], n_tok)
        chk("confirm.%s.df" % key, rj["df"], n_tok - 1)
    ph = holm_adj({"S1": s1["p_two"], "S2": s2["p_two"]})
    for k, v in ph.items():
        chk("holm." + k, conf["holm"][k], v)
        chk("reject." + k, conf["reject"][k], bool(v < ALPHA))
    rej = {k: bool(v < ALPHA) for k, v in ph.items()}
    if rej["S1"] and s1["mean"] > 0:
        case = "A"
    elif rej["S1"] and s1["mean"] < 0:
        case = "D"
    elif not rej["S1"] and rej["S2"]:
        case = "B"
    else:
        case = "C"
    chk("case", conf["case"], case)

    # ---- 4. TOST ----
    eq = tost_indep(s1, DELTA_TOST)
    for k, v in eq.items():
        chk("tost." + k, conf["tost"][k], v)
    chk("tost.delta", conf["tost"]["delta"], DELTA_TOST)

    # ---- 5. 決定の独立再構成 ----
    parts = {nm[4:]: z[nm].astype(np.int64) for nm in z.files if nm.startswith("uid_")}
    assert set(parts) == {"sent", "uni48", "uni340"}, set(parts)
    n_s = int(parts["sent"].max()) + 1
    dec = {}
    for nm, uid in parts.items():
        n_unit = int(uid.max()) + 1
        Yr = Y_indep(c8, c7, uid, n_unit)
        chk("Y.%s.shape0" % nm, int(z["Y_" + nm].shape[0]), n_unit)
        chk("Y.%s.maxdiff" % nm,
            float(np.abs(z["Y_" + nm].astype(np.float64) - Yr).max()), 0.0, atol=1e-12)
        c, p = decision_from_Y(Yr)
        chk("dec.%s.cut" % nm, int(np.abs(z["cut_" + nm].astype(np.int64) - c).max()), 0)
        chk("dec.%s.prot" % nm, int(np.abs(z["prot_" + nm].astype(np.int64) - p).max()), 0)
        dec[nm] = (c, p)
        cp, pp = decision_from_Y(z["pred_" + nm].astype(np.float64))
        chk("dec.%s_probe.cut" % nm,
            int(np.abs(z["cut_" + nm + "_probe"].astype(np.int64) - cp).max()), 0)
        chk("dec.%s_probe.prot" % nm,
            int(np.abs(z["prot_" + nm + "_probe"].astype(np.int64) - pp).max()), 0)
        dec[nm + "_probe"] = (cp, pp)
        for key in (nm, nm + "_probe"):
            mk, slots = budget_indep(uid, *dec[key], n_tok, nw, n_eval)
            chk("budget.%s.mean_k" % key, J["calib"]["C3"]["mean_k"][key], mk)
            chk("budget.%s.slots" % key, slots, 112)
    # random 3 腕の seed 再現
    for i, seed in enumerate(RAND_SEEDS):
        nm = "sent_random" if i == 0 else "sent_random_s%d" % (i + 1)
        c, p = random_decision_indep(seed, n_s)
        chk("dec.%s.cut" % nm, int(np.abs(z["cut_" + nm].astype(np.int64) - c).max()), 0)
        chk("dec.%s.prot" % nm, int(np.abs(z["prot_" + nm].astype(np.int64) - p).max()), 0)
        mk, slots = budget_indep(parts["sent"], c, p, n_tok, nw, n_eval)
        chk("budget.%s.mean_k" % nm, J["calib"]["C3"]["mean_k"][nm], mk)
        chk("budget.%s.slots" % nm, slots, 112)

    # ---- 6. 文 ID・校正 ----
    uniq = np.unique(sent)
    chk("sent.contiguity", int(np.array_equal(uniq, np.arange(uniq.size))), 1)
    chk("sent.min_len", int(np.bincount(sent).min() >= MIN_SENT), 1)
    seen, cross = set(), 0
    for w in range(nw):
        sw = set(np.unique(sent[w * n_eval:(w + 1) * n_eval]).tolist())
        cross += len(sw & seen)
        seen |= sw
    chk("sent.cross_window", cross, 0)
    chk("C3.no_cross_window", J["calib"]["C3"]["no_cross_window"], True)
    chk("C3.n_bad", int(J["calib"]["C3"]["n_bad"]), 0)
    chk("C4.n_bad", int(J["calib"]["C4"]["n_bad"]), 0)
    for nm, v in J["calib"]["C5"]["conflicts"].items():
        chk("C5.conflict." + nm, int(v), 0)
    chk("C5.cut_hist_sum", sum(J["calib"]["C5"]["cut_hist_sent"]), n_s)

    # ---- 7. C1: 同一プロセス内のビット一致（AX6 方式）----
    c1 = J["calib"]["C1"]
    chk("C1.base_maxdiff", float(c1["base_maxdiff"]),
        float(np.abs(N["base_cap"] - N["base_rep"]).max()))
    chk("C1.u7_maxdiff", float(c1["u7_maxdiff"]),
        float(np.abs(u7 - N["u7_rep"]).max()))
    chk("C1.tier", c1["tier"], "A")
    chk("C1.scope", c1["scope"], "smoke_en6" if bool(meta["smoke"]) else "full_48")

    # ---- 8. C2: 8-gram 非重複 ----
    z3 = np.load(os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz"), allow_pickle=True)
    z6 = np.load(os.path.join(HERE, "corpus_ids_ax6_w24_l256.npz"), allow_pickle=True)
    ov = {lg: overlap8(z3[lg + "_ids"], z6[lg + "_ids"]) for lg in ("en", "ja")}
    chk("C2.overlap_en", J["calib"]["C2"]["overlap_en"], ov["en"])
    chk("C2.overlap_ja", J["calib"]["C2"]["overlap_ja"], ov["ja"])
    chk("C2.pass", J["calib"]["C2"]["pass"], bool(ov["en"] < 0.05 and ov["ja"] < 0.20))

    # ---- 9. C6 / C7 ----
    c6 = J["calib"]["C6"]
    chk("C6.random_gain", c6["random_gain"], J["gains"]["sent_random"]["mean"])
    chk("C6.oracle_gain", c6["oracle_gain"], J["gains"]["sent_oracle"]["mean"])
    chk("C6.probe_gain", c6["probe_gain"], s1["mean"])
    chk("C6.random_le_oracle", c6["random_le_oracle"],
        bool(J["gains"]["sent_random"]["mean"] <= J["gains"]["sent_oracle"]["mean"]))
    c7c = J["calib"]["C7"]
    chk("C7.observed", c7c["observed"],
        J["exploratory"]["probe_quality"]["sent"]["max_abs_rho"])
    chk("C7.n_perm", int(c7c["n_perm"]), 100)
    chk("C7.judgement", c7c["judgement"], "record_only")

    # ---- 10. 探索量・独立 ckpt 参照 ----
    ex = J["exploratory"]
    chk("ex.boundary_diff", ex["boundary_probe_diff"],
        J["gains"]["sent_probe"]["mean"] - J["gains"]["uni340_probe"]["mean"])
    chk("ex.granularity_diff", ex["granularity_probe_diff"],
        J["gains"]["sent_probe"]["mean"] - J["gains"]["uni48_probe"]["mean"])
    rg = ex["random_seed_gains"]
    chk("ex.seed_spread", ex["random_seed_spread"], max(rg) - min(rg))
    for nm, g in (("sent_random", rg[0]), ("sent_random_s2", rg[1]),
                  ("sent_random_s3", rg[2])):
        chk("ex.seed_gain." + nm, g, J["gains"][nm]["mean"])
    z4 = np.load(os.path.join(HERE, "ax4_sentence_bound.npz"))
    u4 = z4["nll_u7_rep"].astype(np.float64)
    chk("ex.ax4.G_sent_probe", ex["ax4_reference"]["G_sent_probe"],
        float((u4 - z4["nll_sent_probe"].astype(np.float64)).mean()))
    chk("ex.ax4.gap", ex["ax4_reference"]["gap"],
        float((z4["nll_sent_probe"].astype(np.float64)
               - z4["nll_sent_oracle"].astype(np.float64)).mean()))
    z8 = np.load(os.path.join(HERE, "ax8_feasible_probe.npz"))
    u8 = z8["nll_u7_rep"].astype(np.float64)
    chk("ex.ax8.G_sent_probe", ex["ax8_reference"]["G_sent_probe"],
        float((u8 - z8["nll_sent_probe"].astype(np.float64)).mean()))
    chk("ex.ax8.gap", ex["ax8_reference"]["gap"],
        float((z8["nll_sent_probe"].astype(np.float64)
               - z8["nll_sent_oracle"].astype(np.float64)).mean()))

    # ---- 11. 非有限値 ----
    chk("nonfinite.count", len(finite_bad(J)), 0)

    print("AX9 Step 4 verify (tag=%s)" % TAG)
    print("items=%d  mismatches=%d" % (len(ITEMS), len(MISMATCH)))
    for name, got, exp in MISMATCH[:40]:
        print("  MISMATCH %s: got=%r exp=%r" % (name, got, exp))
    sys.exit(1 if MISMATCH else 0)


if __name__ == "__main__":
    main()
