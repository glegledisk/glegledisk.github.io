# QA1S2 課題設計書: 幅 3 腕を A4b ハーネスに載せ、`Δ_iv` を 7 seed で検定する

- 日付: 2026-11-14（`QA1課題設計書_保留8は二重に消化済みで残る位置固定幅操作1腕でQA同一性を検定する_20261114.md` §9 の Step 2）
- ステータス: **設計確定・未走行**（本設計書は 1 本も走らせない）
- 区分: **QA1S2**。Step 1 で固定した腕定義をそのまま引き継ぐが、本番の適用経路を新たに定義するため別 ID を立てた
- 関連: `検証報告_QA1S1_gain32個保存で幅か層位置かを分離しC1-C4全合格_既存ハーネスのneed_hiddens不整合も復旧_20261114.md`、`QA1課題設計書_..._20261114.md` §3〜§8 / §9、`検証報告_A4b_gain補正_20261102.md`、`検証報告_Q10_2本平均は要らない_20261031.md`、`検証報告_Q11_型の割り当ては必須ではない_20261031.md`、`a4_small_expert_act.py`、`a1_activation_ffn.py`、`不均一MoE-Corpus/corpus_common.py` P1、`Z3課題設計書_..._20261109.md` §4、`AGENTS.md` §0-6 / §2 / §3 / §8 / §11
- 出力: 本設計書のみ（新規測定なし）

---

## 0. 背景と Step 1 から引き継いだ残課題

Step 1（`検証報告_QA1S1_...`）は C1 / C2 / C3 / C4 / C6 全合格で、`gain[(l,i)]` の 32 個を 3 腕ぶん保存した。A4b §7 限界 3 の「幅か層位置かを分離できない」は解消している。ただし本番へ進むには、Step 1 が意図的に触れなかった 4 点を走行前に固定する必要がある。

| 項目 | Step 1 の状態 | 本次の扱い |
|---|---|---|
| 幅ベクトルの適用経路 | `run_one` は `widths_of(arm, scale)` で arm 名から幅を決めるため 3 腕を載せられない | §1 で `widths_override` を追加 |
| 活性化と gain 補正 | Step 1 は `all_relu2` の gain を測ったが、本番腕の `act_i` が未定義 | §2 で全腕 `relu2` ＋ `gain = matched` に固定 |
| 3 点対照（C5） | 本番走行を要するため対象外だった | §4 で実装方式を固定 |
| seed 範囲 | 校正は `CAL_SEED = 0` の 1 seed | §3 で 0..6 の 7 seed に固定（Q10 / Q11 の 0..5 を含む） |

あわせて既存ハーネスの `need_hiddens` 不整合は Step 1 で復旧済み（`a1_activation_ffn.py` の返り値 3 値は不変）。本次はその修正後の経路だけを使う。

---

## 1. 腕と適用経路（走行前に凍結）

Step 1 で固定した 3 腕を再確認し、変更しない。

| 腕 | 幅ベクトル | 合計 | e0/e1 | e6/e7 | 役割 |
|---|---|---:|---:|---:|---|
| `w_ref` | `(32,32,96,96,160,160,224,224)` ＝ `BASE_W` | 1024 | 32 | 224 | 基準（Q10 `static_1x` と同型） |
| `w_mid` | `(96,96,96,96,160,160,160,160)` | 1024 | 96 | 160 | 幅のみ操作（主腕） |
| `w_flat` | `(128,)*8` | 1024 | 128 | 128 | 幅差を消した対照（探索的） |

位置 `(l,i)` は 4 層 × 8 expert の 32 個で 3 腕まったく同じ（Step 1 の C3 で対称差 0 を確認済み）。

> **適用経路（1 行）**: `a4_small_expert_act.run_one` に `widths_override=None` 引数を 1 つ追加し、`None` なら既存の `widths_of(arm, scale)` をそのまま使い、タプルが渡されたときだけ `widths = tuple(widths_override)` へ差し替える。既存 arm の挙動は 1 bit も変えない。

`arm` 名は `w_ref` / `w_mid` / `w_flat` をそのまま使うが、`acts_for()` は未知 arm で `ValueError` を投げるため、`act_i` も引数で上書きできるようにする（`act_override=None`）。両方とも後方互換の省略可能引数で、既存の A4 / A4b 呼び出しには影響しない。C1 で既存 `all_relu2_s0_g.json` とのビット一致を再検算する。

---

## 2. 動かす量と固定する量

- **動かす量**: 幅ベクトルだけ（3 腕）。位置 `(l,i)`、活性化、gain 補正、初期重み、データ、seed、optimizer はすべて腕間で同一。
- **固定する量**: `act_i = ["relu2"] * 8`（全腕）、`gain = "matched"`、`epochs = 6`、`seeds = (0,1,2,3,4,5,6)`、`lr = 2e-3`、`bs = 32`、`auxw = 0.05`、`n_seqs = 3000`、`eval_every = 1`、評価バッチ `seed 777 / 1024 系列`、3 点対照、`Δ_iv` の estimand、Holm 家族 m = 1、判定ケース、全閾値。**すべて走行前に固定**。
- **なぜ全腕 `relu2` か**: QA1 の処置変数は幅であって活性化ではない。Step 1 が測った gain は全 expert ReLU² の分岐 RMS を ReLU 参照へ揃える係数であり、全腕を `relu2` ＋ `matched` にすることで**幅の違いだけが残る**。全 ReLU にすると gain は全 1.0 になり Step 1 の 32 個が使えず、初期化スケールの差が幅と交絡する（A4b の教訓）。
- **なぜ 7 seed か**: 設計書 §4 の `seed ≥ 7` 要件を満たしつつ、Q10 / Q11 の `0..5` を内含することで §8 限界 3 の「seed 範囲が揃わない」を緩和する。ただし 6 seed 目を足しただけなので、**Q11 との直接比較は依然として独立標本**であり有意差は主張しない（ケース D の扱い）。

---

## 3. 確認的検定（走行前に固定）

| 項目 | 定義 |
|---|---|
| 主指標 | `instr_valid` の**末尾 3 epoch 中央値**（`evals[-3:]`。`a1_activation_ffn.evaluate` が返す有界指標） |
| estimand | `Δ_iv = mean_seed[ iv(w_mid) − iv(w_ref) ]`（同一 seed の paired 差、n = 7） |
| 検定 | `scipy.stats.ttest_rel`、両側、α = 0.05 |
| 必須併記 | `Δ / se / t / p / n / MDE / 90% CI`、`MDE = t.ppf(0.975, n-1) × se ≈ 2.4469 × se` |
| 多重比較 | 確認的家族 **m = 1**。Holm は自明。事後的に第 2 の確認的検定を足さない |
| 頑健性 | 上位 1% 寄与率・中央値・最大値を出し、平均が裾に支配されていないか確認（§7-5）。`mean_unreliable` なら平均を主張に使わない |
| 探索的 | `w_flat`、`gain` の幅単調（Step 1 の `η²_width 0.637` 対 `η²_layer 0.201`）、Q11 との記述比較。**有意差を主張しない** |

`ce_seq` / `ce_all` は主判定に置かない（A4b §0-5「gain 補正は CE の裾を重くする」、MEMORY の罠）。補助記録にとどめる。

---

## 4. 3 点対照の実装方式（C5・走行前に固定）

設計書 §3 の 3 点対照は Q1 系の静的割当腕（`dynamic_lb` / `static_type` / 乱数）だったが、本次は A4b ハーネス（`ActMoE`）で統一する。Q10 / Q11 は再走しない（§8）。

> **方式（1 行）**: `ActMoE` を継承した `PolicyActMoE` が `forward` を上書きし、`policy ∈ {learned, uniform, random, oracle}` に応じて層ごとの `topi` と `gate` を差し替える。学習は `learned` だけで行い、評価は**同一 ckpt・同一 eval トークン・同一走行内**で 3 方策を同時に走らせる（`corpus_common.POLICIES` の作法）。

- `uniform`: 全 expert へ等しい gate（top-k 構造を保つため `topi` は一様に選ぶ）。
- `random`: 型 `typ` と独立な一様乱数で expert を選ぶ。乱数ストリームは `seed + 977` で走行前に固定。
- `oracle`: `typ`（struct / payload）から expert を直指定（struct → 小幅群、payload → 大幅群）。Q1 の `static_type` 相当。
- **方策ごとに forward をやり直す**。1 回の logits を使い回すと全方策で loss / correct が同一になり対照が崩れる（`corpus_common.run_model` §329-331 の罠）。
- 差し替えは `gate_of` だけでは足りない。`ActMoE.forward` は `topi == i` で expert を gather しているため、`topi` 自体も差し替える必要がある。これを `PolicyActMoE.forward` の責務とする。
- C5 の合格条件は `instr_valid(random) ≤ instr_valid(oracle)`。3 点対照は**校正であって確認的家族には入れない**。

---

## 5. eval 側収束ゲート（除外しない・走行前に固定）

QA1 設計書には eval 側ゲートの明示が無かったが、MEMORY の罠「収束ゲートは訓練前に固定」に従い本次で固定する。Z3 §4 の形（分類＋完全性）を継承する。

| 記号 | 本次の定義 | 出所 |
|---|---|---|
| `T+` | `\|slope(tail3 loss_hist)\| ≤ 0.005` かつ `range(tail3 loss_hist) ≤ 0.02` | `corpus_common.CONV_SLOPE_MAX` / `CONV_RANGE_MAX` を継承（値を新しく作らない） |
| `E+` | 主バッチの `instr_valid ≥ 0.10` | Z3 G2 の有界指標としての閾値を補助分類にのみ継承 |
| E フラグ | `ce_all > ln(VOCAB_Q1) = ln(17) = 2.8332`、非有限値、または `instr_valid` が 0 / 1 に張り付いた場合 | Q1 系の語彙 17 から決まる理論値。Z3 の `τ_ce = 0.50` は 6 epoch / 語彙 17 の別スケールなので使わない |
| 分類 | `T± × E±` の 2×2 を可視化して数える | Z3 §4-1 |

- **除外はしない**。E フラグ seed は主解析に残し、扱うのは事前登録した感度解析（E フラグを除いた `Δ_iv` 再計算）だけ。除外ペア数は Step 4 で 0 を assert する。
- 主指標は常に主バッチの末尾 3 epoch 中央値で定義し、gate バッチの数値へ事後差し替えしない。
- 床ラベルは本次では定義しない（比率検定をしないため）。

---

## 6. 判定ケース（QA1 §5 を継承・走行前に凍結）

| ケース | 条件 | 読み |
|---|---|---|
| **A** | `Δ_iv` 棄却、Q11 の位置操作は非棄却のまま | 幅が真の処置変数。Q-A 統合を支持し、Q-D の estimand は幅に置く |
| **B** | 幅操作と位置操作が同じ符号・同じ大きさ | 3 つは別変数で Q-A の統合は誤り |
| **C** | 両方非棄却 | MDE 未満。「差が無い」とは書かず MDE と 90% CI を併記 |
| **D** | Q11 を本次ハーネスで再測したとき位置操作のみ棄却 | 位置が真の処置変数。Q11 の 6 seed 結果が seed 範囲依存だった可能性を記録 |

ケース A でも「幅と使用率と位置が同一の潜在量と確定」とは書かない。1 testbed・1 モデル・1 ハーネスであり、Q-E（QE1S2）が解けていない限り外部妥当性を持たない（地図 §3-5 / §4）。ケース D の「再測」は Q11 の再走を意味せず、本次ハーネス内の方策対照からの記述的示唆に限る（§8 の禁止を継承）。

---

## 7. 校正（観測統計量と閾値の両方を明示・AX10 指摘）

| ID | 観測統計量 | 合格条件 |
|---|---|---|
| C1 | `all_relu2` の gain 集計と A4b 保存 `all_relu2_s0_g.json` の maxdiff、`widths_override=None` の既存挙動 | `< 1e-9`、既存 arm の `evals` ビット一致 |
| C2 | 3 腕の `gain.by_position` の個数・有限性・キー集合 | 各 32 個、非有限 0、欠損 0（Step 1 の C2 を継承） |
| C3 | 3 腕の合計幅と `w_ref` / `w_mid` の等しさ | すべて 1024、`maxdiff 0` |
| C4 | 腕間の位置 `(l,i)` 一致と `T± × E±` 分類の完全性 | 対称差 0、分類漏れ 0、除外ペア 0 |
| C5 | 3 点対照 `instr_valid(random) ≤ instr_valid(oracle)` | `≤`（全 seed で成立） |
| C6 | 全出力の非有限値 | `0`（`allow_nan=False`、書込前に走査して assert） |

Step 1 の C1a / C1b / C1c（すべて `maxdiff 0.0`）は本次でも同じ手順で再検算し、`widths_override` / `act_override` / `need_hiddens` 修正が既存数値を動かしていないことを確認する。C5 が通らない場合は本番判定を止め、方策実装を疑う。

---

## 8. 禁止事項（QA1 §7 を継承）

- 保留 1 を退役させない／Z1 §4 規則 3 を解除しない
- 「差が無い」「中心命題が偽 / 確認された」と書かない
- 絶対 CE を過去報告と直接比較しない（§8）
- 一次評価の絶対値を実装可能な性能として書かない（§7-4）
- 単一 seed・単一スライスを確定知見として `MEMORY.md` に書かない（§11）
- 結果を見てから検定族・主腕・腕の幅・分割定義・seed 範囲を変えない
- **Q10 / Q11 を再走しない**（§8「表にある罠を再調査しない」）。保存 NLL を本次の forward 実測と混ぜない
- 既存 `.md` を書き換えない（§0-6）

---

## 9. 限界

1. **新規測定は 1 本もしていない**。設計書であり、数値はすべて Step 1 / A4b / Q10 / Q11 / `corpus_common.py` の一次ソースからの引用。
2. `Δ_iv` の検出力は未知。Q10 / Q11 は 6 seed で MDE 0.341 / 0.585 と粗く、7 seed でも同帯に留まる可能性がある。非棄却ならケース C として MDE を併記する。
3. Q11 と seed 範囲が完全には揃わない（0..5 は共有、6 は本次のみ）。「幅 vs 位置」の直接比較は独立標本で、有意差は主張しない。
4. `w_flat` は合計幅を保ちつつ均等化するため容量会計が変わる（QA1 §8 限界 5）。探索的のみ。
5. gain 補正の「正しさ」自体は検証していない（A4b §7 限界 5）。別の統制（学習率調整など）で結果が変わりうる。
6. `PolicyActMoE` は新規実装で、3 方策が `topi` gather まで正しく差し替わるかは未検証。C5 がその校正を兼ねる。
7. `need_hiddens=True` を要する W5b 系経路は Step 1 で復旧していない。本次は 3 値返却を要する A4 / A4b / QA1 系だけを使う。
8. 1 testbed・1 モデル・1 ハーネス。Q-E が未解決の間は一般則にしない。
9. 本設計書は `STATE.md` §3 の状態を変更しない（現役 0 / 保留 1 未決着・保留 4〜11 不変）。保留 8 の退役判断はユーザー判断として保留のまま。

---

## 10. 実行計画

- **本次は走行しない**。Step 1 として `widths_override` / `act_override` / `PolicyActMoE` の 3 点を実装し、C1〜C6 の dry-run（学習 0 epoch）を別ファイルで用意する。**C5 が通ってから** 6 epoch × 7 seed の本番へ進む。ゲートを飛ばして本番を起動しない。
- 出力は `qa1s2_*.json` / `.npz` / UTF-8 ログに揃え、Step 4 の独立検算を別実装で用意する（§3）。
- QE1S2 と並行してよいが、両者を「Q-E と Q-A が同時に解けた」とまとめて主張しない（別 estimand・別ハーネス）。

---

## 11. 再現（設計のみ・走行なし）

```powershell
$p = "C:\Users\gochu\.workbuddy-ai\binaries\python\envs\gpu\Scripts\python.exe"
$wd = "C:\Users\gochu\WorkBuddy AI\不均一MoE"
$env:PYTHONIOENCODING = "utf-8"
Set-Location $wd
& $p "_md_check.py" "$wd\QA1S2課題設計書_幅3腕をA4bハーネスに載せDelta_ivを7seedで検定する_20261114.md"
```

**実装メモ**: 日本語の軟改行は構文崩壊を生む。ヘッダは `- ` 箇条書きにして CJK 間のソフト改行を避け、閉じ `**` の直前を `）` / `」` / `。` にしない（AX10 / EF1 / EF1G1 で実測した `_md_check.py` の罠）。腕名は `w_ref` / `w_mid` / `w_flat` で統一し、Q9b というラベルを使わない（2 つの意味が混在するため）。

---

## 追記（2026-11-14 23:26）: Step 1 完了 — 3 実装で C1〜C6 全合格、C5 は dry-run 版へ具体化

- ユーザ「QA1S2 の 3 実装 dry-run」に対し `qa1s2_policy.py`（新規 `PolicyActMoE` ＋ `eval_policy`）/ `qa1s2_dryrun.py` / `_qa1s2_verify.py` と `検証報告_QA1S2S1_3実装でC1-C6全合格_PolicyActMoEの差し替えを実証_20261114.md`（lint 合格）を作成した。**6 epoch × 7 seed の本番学習・確認的 `Δ_iv` は未実施**。独立検算 103 項目・0 不一致。出力は `qa1s2_s1_metrics.json` / `qa1s2_s1_gain.npz` / `qa1s2_s1.log` / `_qa1s2_verify.json` / `data/a4/*_s0_qa1s2*.json`。
- 実装: ①`a4_small_expert_act.run_one` に `widths_override=None` / `act_override=None` を追加（後方互換、C1 で既存挙動 1 bit 不変を確認）②`qa1s2_policy.py` の `PolicyActMoE` は `forward` を上書きして層ごとの `topi` と `gate` を差し替える（§4 のとおり `gate_of` だけでは不十分）。返り値は既存と同じ 3 値。乱数は `seed + 977` で `reset_rng()` により方策評価ごとに初期化 ③`eval_policy` は `model.typ_batch` をバッチごとにセットして oracle へ型を渡し、方策ごとに forward をやり直す。
- 結果: C1 は `all_relu2` の gain 集計が A4b 保存値とビット一致＋A4 raw / matched の `evals` が 6 seed すべて `maxdiff 0.0`。C2 は 3 腕 32 個＋**`run_one(widths_override)` 経由の gain が Step 1 直接測定と `by_expert` maxdiff `0.0`**（適用経路の等価性を実証）。C3 は幅 `1024 × 3`・全腕 `relu2`・学習 0 ステップ。C4 はキー対称差 0。C6 は非有限値 0 で **全合格 `verdict = PASS`**。**§9 の「C5 が通ってから本番」ゲートを通過**。本番未走行なのでケース A〜D 判定はしない。
- **★ §7 の C5 を dry-run 版へ具体化（本追記をもって正とする）**: 学習 0 epoch の初期重みでは `instr_valid` が全 4 方策で `0.0` になり、§7 の `instr_valid(random) ≤ instr_valid(oracle)` は自明に成立して校正として無意味になることが観測された。よって dry-run 版の C5 を次の 4 条件へ置き換えた（結果を見る前に `qa1s2_dryrun.py` の `prereg` として固定）: ①3 方策間の `first_logits` ペア間 maxdiff がすべて > 0（実測最小 `1.484389`）②`oracle_typ_agreement = 1.0` ③`uniform_expert_coverage = 8` ④`random_usage_max_rel_dev < 0.05`（実測 `0.043005`）。**§7 本来の `random ≤ oracle` は 6 epoch 学習後の本番判定に委ねる**。参考記録: `ce_all` は learned 2.742089 / uniform 2.725699 / random 2.761175 / oracle 2.778874 で oracle が最も悪い（初期重みで型強制割当が不利なことの記録であり実装不良の証拠ではない。`oracle_typ_agreement = 1.0`）。
- Step 2（本番）へ引き継ぐ留意: ①`PolicyActMoE` を訓練に使うなら勾配が `topi` 差し替えで壊れないかを追加校正する ②`uniform` は k = E に実質拡張するため eval 時間が 8 倍になる ③`random_usage_max_rel_dev` は本番 1024 系列なら約 1/8 に縮むと期待される（dry-run 128 系列の小標本ゆらぎ）④eval 1024 系列 × 7 seed × 3 腕の本番走行時間を見積もってから起動する。
- 状態: 現役 0 / 保留 1 未決着・保留 4〜11 不変、Z1 §4 規則 3 は解除せず、`STATE.md` §3 は変更しない。保留 8 の退役判断は引き続きユーザー判断として保留。QE1S2 は Step 1 完了済み（C7 合格）で 3 検定の本番へ進めるが、本番走行は別途設計書の確認と指示を待つ。

---

## 追記（2026-11-15）: Step 2 本番の走行前固定（結果を見る前に登録）

本追記は `qa1s2_run.py` の `prereg` と同一内容を設計書側にも残すもので、**新規測定の結果を含まない**。

- **同一 ckpt の実装**: `a4_small_expert_act.run_one` に省略可能な `model_out` 引数を 1 つ追加し、学習済み `ActMoE` を呼び出し側へ渡す（`None` なら既存挙動は 1 bit も変わらない）。`PolicyActMoE` を同じ `widths` / `seed` / `act_i` で構築し、`p` を参照共有、`gain_l` をコピーして同一 ckpt とする。C1 で `same_p` / `same_gain_l` を全走行で確認する。
- **走行数**: 3 腕 × 7 seed = **21 run**（`ProcessPoolExecutor` 6 並列）。各 run は 6 epoch の学習＋4 方策 × 1024 系列の eval。eval トークンは `default_rng(777)` で全走行共通、`random` の乱数は `seed + 977` を `reset_rng()` で方策評価ごとに初期化する。
- **C5 の本番判定**: Step 1 の dry-run 版 4 条件ではなく、§7 の本来定義 `instr_valid(random) ≤ instr_valid(oracle)` を全 21 run で判定する。**§7 の「C5 が通らない場合は本番判定を止め、方策実装を疑う」をケース判定より優先して適用**し、`STOP` として記録する。あわせて `tie_count` / `all_tied_at_floor` を記録し、全腕が `instr_valid = 0` に張り付いて `≤` が自明に成立した場合は校正として情報量が無いことを明示する（Step 1 追記の引継ぎ）。
- **収束ゲート**: `T+` は `loss_hist` 末尾 3 点の `|slope| ≤ 0.005` かつ `range ≤ 0.02`（`corpus_common.CONV_*` を継承）、`E+` は主バッチ `instr_valid ≥ 0.10`、E フラグは `ce_all > ln(17) = 2.8332` / 非有限 / `instr_valid ∈ {0,1}`。`T± × E±` は分類のみで**除外しない**。`excluded_pairs = 0` を C4 で assert し、E フラグを除いた `Δ_iv` 再計算は探索的感度としてのみ出力する。
- **統計**: `Δ_iv` は `ttest_rel` 両側 α = 0.05、Holm m = 1、`MDE = t.ppf(0.975,6) × se = 2.446912 × se`、90% CI は `t.ppf(0.95,6) = 1.943180`。上位 1% 寄与率が `TOP1_CONTRIB_LIMIT = 0.50` 以上なら平均を主張に使わない（§7-5）。`ce_seq` / `ce_all` は補助記録のみ。
- **非有限値の規約**: QE1S2 追記と同じく `corpus_common.paired` 準拠。分散ゼロで差が非ゼロなら棄却（`t` は JSON `null` ＋ `t_infinite`）、差 0 なら `p = 1`。`json.dump(allow_nan=False)` を全出力に適用する。
- **既存コードの変更は最小**: `a4_small_expert_act.run_one` へ `model_out` を追加したのみ（`widths_override` / `act_override` は Step 1 で追加済み）。`a1_activation_ffn.py` / `qa1s2_policy.py` は本次で書き換えない。
- **ケース B / D の扱い**: §6 のケース B / D は Q11 を再走しない（§8）ため本次ハーネス内の方策対照からの記述的示唆に限り、厳密判定は不能として報告書の限界に書く。
