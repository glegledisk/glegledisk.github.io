import re, sys
from markdown_it import MarkdownIt
src = open(sys.argv[1], encoding="utf-8").read()
html = MarkdownIt("commonmark").enable("table").render(src)
body = re.sub(r"<pre>.*?</pre>", "", html, flags=re.S)
body = re.sub(r"<code>.*?</code>", "", body, flags=re.S)
hits = [m.start() for m in re.finditer(r"\*\*", body)]
print(f"literal ** in rendered body: {len(hits)}")
for h in hits[:10]:
    print("   ...", repr(body[max(0, h-70):h+70]))