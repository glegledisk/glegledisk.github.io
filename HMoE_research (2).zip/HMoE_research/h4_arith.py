"""H4: 算術課題（部分点があり、計算の深さで難易度が段階的になるテストベッド）。

## なぜ算術か

H1〜H3 で分かったこと:
  - 表引き（lookup）課題は**全か無か**。4,096 エントリは幅 1.0 でも完全に解け、
    16,384 エントリは幅 6.0 でも全く学習しない。**崖であって坂ではない**。
  - したがって dCE/dwidth が段階的に負になる領域が存在せず、
    「容量の限界価値」を測る道具にならない。
  - しかも expert の幅を 6 倍にしても崖は動かない（d_model 2 倍・深さ 2 倍でも同じ）。

算術は**部分点がある**。桁上がりや繰り上がりのように、一部の入力だけ正解できる状態が
自然に生じる。さらに演算の深さ（1 演算 / 2 演算 / 3 演算）で難易度を連続的に変えられる。

## 設計

法 p = 31（素数）。九九の表は 961 エントリで、記憶としては易しい。
したがって律速は**記憶ではなく計算**になる（H3 で記憶は幅で動かないと分かっているため、
意図的に記憶を易しくして計算に寄せる）。

  SEQ=32。偶数位置 = cue（i.i.d. 一様、常に可視・マスクしない）、奇数位置 = 内容（マスク対象）。
  内容の i 番目（位置 2i+1）は cue の関数。c = cue[i], a = cue[i-1], b = cue[i-2],
  d = cue[i-3], e = cue[i-4]（添字は 16 で剰余）:

      i%4 == 0  add   : (c + a) mod p                    1 演算・軽
      i%4 == 1  mul   : (c * a) mod p                    1 演算
      i%4 == 2  dot   : (c*a + b*d) mod p                2 演算
      i%4 == 3  chain : ((c*a + b)*d + e) mod p          3 演算・重

## 見たいこと

  1. 難易度の順序が意図どおりか（add < mul < dot < chain）を **CE で検証**する。
     H1/H3 ではラベルが実測と逆だったので、ここは必ず確認する。
  2. 幅を増やすと CE が下がるか。下がるなら**どの型で下がるか**。
     chain だけ下がって add が平坦なら、容量の限界価値が位置で違う＝配分の余地がある。
"""
import argparse
import json
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

from h3_bigvocab import Net, block_mask, sample_mask, diff_loss, evaluate, SEQ, P_NCUE

HERE = os.path.dirname(os.path.abspath(__file__))
TYPES = ("add", "mul", "dot", "chain")


# ---------------------------------------------------------------- task
@torch.no_grad()
def gen_batch(n, p, g):
    cue = torch.randint(0, p, (n, P_NCUE), generator=g)
    x = torch.empty(n, SEQ, dtype=torch.long)
    x[:, 0::2] = cue
    # 参照する cue は必ず「自分より前」にする。剰余で wrap すると後のブロックの cue を
    # 参照することになり、block-causal マスクで見えなくなる（i=0 で実際に起きた）。
    for i in range(P_NCUE):
        c = cue[:, i]
        a = cue[:, max(0, i - 1)]
        b = cue[:, max(0, i - 2)]
        d = cue[:, max(0, i - 3)]
        e = cue[:, max(0, i - 4)]
        m = i % 4
        if m == 0:
            v = (c + a) % p
        elif m == 1:
            v = (c * a) % p
        elif m == 2:
            v = (c * a + b * d) % p
        else:
            v = ((c * a + b) * d + e) % p
        x[:, 2 * i + 1] = p + v
    return x


def type_mask(p):
    """内容位置ごとの型（0..3）。SEQ 長のテンソル。"""
    m = torch.full((SEQ,), -1, dtype=torch.long)
    for i in range(P_NCUE):
        m[2 * i + 1] = i % 4
    return m


# ---------------------------------------------------------------- eval
@torch.no_grad()
def ce_by_type(model, xs, am, mask_id, p, t_bins=True):
    g = torch.Generator().manual_seed(555)
    dev = xs.device
    tm = type_mask(p).to(dev)
    buckets = [(0.0, 0.25), (0.25, 0.5), (0.5, 0.75), (0.75, 1.01)] if t_bins else [(0.0, 1.01)]
    acc = {}
    for _ in range(6):
        m, t = sample_mask(xs.shape[0], 0.1, g, dev)
        inp = torch.where(m, torch.full_like(xs, mask_id), xs)
        logits, _, _, _, _ = model(inp, am)
        ce = F.cross_entropy(logits.reshape(-1, logits.shape[-1]), xs.reshape(-1),
                             reduction="none").view(-1, SEQ)
        for lo, hi in buckets:
            mb = m & (t >= lo) & (t < hi)
            for ti, tn in enumerate(TYPES):
                sel = mb & (tm == ti).unsqueeze(0)
                if sel.any():
                    key = f"{lo:.2f}|{tn}" if t_bins else tn
                    acc.setdefault(key, []).append(float(ce[sel].mean()))
    return {k: float(np.mean(v)) for k, v in acc.items()}


# ---------------------------------------------------------------- run
def mup_init(model, d):
    """幅に依存しない初期化。H3 では W1/W2 を std=0.02 固定にしていたため、
    出力 y = Σ_{j<H} h_j W2_j の大きさが sqrt(H) で増え、広いモデルほど
    活性が大きく／不安定になっていた（lr=3e-3 で幅 4.0 が崩壊した原因）。
    1/sqrt(fan_in) に直すと幅によらず O(1) になる。"""
    for blk in model.blocks:
        moe = blk.moe
        with torch.no_grad():
            for e, h in enumerate(moe.hs):
                moe.W1[e, :h].normal_(0.0, (1.0 / d) ** 0.5)
                moe.W2[e, :, :h].normal_(0.0, (1.0 / h) ** 0.5)
                moe.b1[e, :h].zero_()
                moe.b2[e].zero_()


def run_one(p, s, b, seed, steps, d, nh, nlay, d_ff, bs, lr, k, eval_t_bins=False):
    torch.manual_seed(seed)
    np.random.seed(seed)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    n_class = 2 * p + 1
    mask_id = 2 * p

    model = Net(n_class, d, nh, nlay, d_ff, [s] * 8, k).to(dev)
    mup_init(model, d)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=0.01)
    sched = torch.optim.lr_scheduler.LambdaLR(opt, lambda i: min(1.0, i / max(1, steps * 0.05)))
    am = ~block_mask(b).to(dev)
    gen = torch.Generator(device="cpu").manual_seed(seed * 77 + 1)
    xv = gen_batch(512, p, torch.Generator().manual_seed(7)).to(dev)

    t0 = time.time()
    for _ in range(steps):
        x = gen_batch(bs, p, gen).to(dev)
        loss, cost, aux = diff_loss(model, x, am, gen, mask_id)
        opt.zero_grad(set_to_none=True)
        (loss + 0.01 * aux).backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        opt.step()
        sched.step()

    val = evaluate(model, xv, am, mask_id)
    cells = ce_by_type(model, xv, am, mask_id, p, t_bins=eval_t_bins)
    return dict(p=p, s=s, width=k * s, b=b, seed=seed, steps=steps, lr=lr, val=val,
                cells=cells, sec=time.time() - t0,
                params=sum(q.numel() for q in model.parameters()))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--p", type=int, default=31)
    ap.add_argument("--widths", default="0.5,1.0,2.0,3.0")
    ap.add_argument("--b", type=int, default=16)
    ap.add_argument("--seeds", default="0")
    ap.add_argument("--steps", type=int, default=3000)
    ap.add_argument("--d", type=int, default=128)
    ap.add_argument("--nh", type=int, default=4)
    ap.add_argument("--nlay", type=int, default=4)
    ap.add_argument("--d_ff", type=int, default=256)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--k", type=int, default=2)
    ap.add_argument("--t_bins", action="store_true")
    ap.add_argument("--out", default="h4_arith.jsonl")
    a = ap.parse_args()

    out = os.path.join(HERE, a.out)
    if os.path.exists(out):
        os.remove(out)
    for s in [float(x) for x in a.widths.split(",")]:
        for seed in [int(x) for x in a.seeds.split(",")]:
            r = run_one(a.p, s, a.b, seed, a.steps, a.d, a.nh, a.nlay,
                        a.d_ff, a.bs, a.lr, a.k, a.t_bins)
            print(json.dumps({k: v for k, v in r.items() if k != "cells"}, ensure_ascii=False), flush=True)
            for kk in sorted(r["cells"]):
                print(f"    {kk:16s} {r['cells'][kk]:.4f}", flush=True)
            with open(out, "a", encoding="utf-8") as fp:
                fp.write(json.dumps(r, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
