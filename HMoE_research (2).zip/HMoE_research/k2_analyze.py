#!/usr/bin/env python3
"""K2 解析: 教師の expert 幅は、教師非依存の層別を統制しても生徒の誤りを説明するか。

k2_tokens.npz（k2_measure.py の出力）だけを使う。再測定なし。

検定の設計
  y        : 生徒の per-token CE（主）/ 教師の CE / 両者の差（副）
  統制変数 : edit（データから決まる）, run（コピー連長の bucket）, pos（位置 dummy）
             → すべて教師を見ずに計算できる
  説明変数 : 教師の expert 幅（層平均の top-2 幅の和）を z 化
  推論     : 系列（2048 クラスタ）単位のクラスタ頑健 SE

  「幅が頻度を統制しても効くか」の、この testbed での読み替え:
  OUT は一様乱数なので **トークン頻度に変動が無い**。代わりに統制するのは
  「その位置が編集か」「コピー連長」「位置」で、いずれも教師非依存。

出力: k2_analysis_out_utf8.txt / k2_analysis.json
"""
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "k2_analysis_out_utf8.txt")
lines = []


def p(s=""):
    print(s, flush=True)
    lines.append(s)


def zscore(x):
    x = np.asarray(x, dtype=np.float64)
    return (x - x.mean()) / x.std()


def dummies(x, drop_first=True):
    """整数配列 -> one-hot（drop_first で最初の水準を落とす）。"""
    u = np.unique(x)
    if drop_first:
        u = u[1:]
    return np.stack([(x == v).astype(np.float64) for v in u], 1) if len(u) else \
        np.zeros((len(x), 0))


def ols_cluster(y, X, groups, n_groups):
    """OLS + クラスタ頑健 SE。groups は 0..n_groups-1 の整数（部分集合でも可）。"""
    XtX_inv = np.linalg.pinv(X.T @ X)
    beta = XtX_inv @ (X.T @ y)
    e = y - X @ beta
    n, k = X.shape
    sc = X * e[:, None]
    S = np.stack([np.bincount(groups, weights=sc[:, j], minlength=n_groups)
                  for j in range(k)], 1)
    meat = S.T @ S
    V = XtX_inv @ meat @ XtX_inv * (n_groups / (n_groups - 1.0))
    se = np.sqrt(np.maximum(np.diag(V), 0))
    r2 = 1 - (e @ e) / ((y - y.mean()) @ (y - y.mean()))
    return beta, se, r2


def auc(score, label):
    """rank ベースの AUC（同順位は平均ランク）。"""
    score = np.asarray(score, dtype=np.float64)
    label = np.asarray(label).astype(bool)
    order = np.argsort(score, kind="mergesort")
    ranks = np.empty(len(score), dtype=np.float64)
    s = score[order]
    i = 0
    while i < len(s):
        j = i
        while j + 1 < len(s) and s[j + 1] == s[i]:
            j += 1
        ranks[order[i:j + 1]] = (i + j) / 2.0 + 1.0
        i = j + 1
    n1 = label.sum()
    n0 = len(label) - n1
    if n1 == 0 or n0 == 0:
        return float("nan")
    return float((ranks[label].sum() - n1 * (n1 + 1) / 2.0) / (n1 * n0))


def build_controls(d, pos_dum=True, tok_dum=False):
    cols = [d["edit"].astype(np.float64)[:, None]]
    cols.append(dummies(d["run_bucket"]))
    if pos_dum:
        cols.append(dummies(d["pos"]))
    else:
        cols.append(d["pos"][:, None].astype(np.float64))
    if tok_dum:
        cols.append(dummies(d["tgt"]))
        cols.append(dummies(d["src"]))
    return np.concatenate([np.ones((len(d["edit"]), 1))] + cols, 1)


def main():
    z = np.load(os.path.join(HERE, "k2_tokens.npz"))
    seeds = [0, 1, 2]
    students = [161, 128]
    res = {}

    # 共通の層別変数
    pos = z["pos"].reshape(-1).astype(np.int64)
    run = z["run"].reshape(-1).astype(np.int64)
    edit = z["edit"].reshape(-1).astype(np.int64)
    tgt = z["tgt"].reshape(-1).astype(np.int64)
    src = z["src"].reshape(-1).astype(np.int64)
    run_bucket = np.where(edit == 1, 0,
                          np.where(run <= 4, 1, np.where(run <= 11, 2,
                                   np.where(run <= 23, 3, 4))))
    n_groups = z["pos"].shape[0]
    seq_idx = np.repeat(np.arange(n_groups), z["pos"].shape[1])
    base = {"pos": pos, "run": run, "edit": edit, "tgt": tgt, "src": src,
            "run_bucket": run_bucket}

    p("K2: 教師の幅が生徒の誤りを説明するか（統制: edit / コピー連長 / 位置）")
    p("トークン数 %d（%d 系列 × 47）  edit 率 %.4f" % (len(pos), n_groups, edit.mean()))
    p("run bucket の分布: 編集 %d / 1-4 %d / 5-11 %d / 12-23 %d / 24+ %d"
      % tuple([int((run_bucket == b).sum()) for b in range(5)]))
    p("")

    for w in students:
        p("=" * 78)
        p("生徒 dense%d" % w)
        p("=" * 78)
        rows = []
        for s in seeds:
            ce_s = z["ce_s%d/s%d" % (w, s)].reshape(-1).astype(np.float64)
            ce_t = z["ce_t/s%d" % s].reshape(-1).astype(np.float64)
            err_s = z["err_s%d/s%d" % (w, s)].reshape(-1)
            wsum = z["w_sum/s%d" % s].reshape(-1).astype(np.float64)
            wlast = z["w_last/s%d" % s].reshape(-1).astype(np.float64)
            zw = zscore(wsum)
            zwl = zscore(wlast)

            d = dict(base)
            Xc = build_controls(d)
            X1 = np.concatenate([Xc, zw[:, None]], 1)
            X2 = np.concatenate([build_controls(d, tok_dum=True), zw[:, None]], 1)
            X3 = np.concatenate([Xc, zwl[:, None]], 1)

            out = {"seed": s}
            # (a) 単相関
            out["r_w_ces"] = float(np.corrcoef(wsum, ce_s)[0, 1])
            out["r_w_cet"] = float(np.corrcoef(wsum, ce_t)[0, 1])
            out["r_w_errs"] = float(np.corrcoef(wsum, err_s.astype(float))[0, 1])
            # (b) 統制後の係数
            b1, se1, r2_1 = ols_cluster(ce_s, X1, seq_idx, n_groups)
            b0, se0, r2_0 = ols_cluster(ce_s, Xc, seq_idx, n_groups)
            out["b_w_ces"] = float(b1[-1])
            out["t_w_ces"] = float(b1[-1] / se1[-1])
            out["dR2_ces"] = float(r2_1 - r2_0)
            out["R2_ctrl_ces"] = float(r2_0)
            b2, se2, r2_2 = ols_cluster(ce_s, X2, seq_idx, n_groups)
            out["b_w_ces_tok"] = float(b2[-1])
            out["t_w_ces_tok"] = float(b2[-1] / se2[-1])
            b3, se3, _ = ols_cluster(ce_s, X3, seq_idx, n_groups)
            out["b_wlast_ces"] = float(b3[-1])
            out["t_wlast_ces"] = float(b3[-1] / se3[-1])
            # (c) 教師側
            bt, set_, r2t1 = ols_cluster(ce_t, X1, seq_idx, n_groups)
            bt0, _, r2t0 = ols_cluster(ce_t, Xc, seq_idx, n_groups)
            out["b_w_cet"] = float(bt[-1])
            out["t_w_cet"] = float(bt[-1] / set_[-1])
            out["dR2_cet"] = float(r2t1 - r2t0)
            # (d) 差（移りにくさ）
            gap = ce_s - ce_t
            bg, seg, r2g1 = ols_cluster(gap, X1, seq_idx, n_groups)
            bg0, _, r2g0 = ols_cluster(gap, Xc, seq_idx, n_groups)
            out["b_w_gap"] = float(bg[-1])
            out["t_w_gap"] = float(bg[-1] / seg[-1])
            out["dR2_gap"] = float(r2g1 - r2g0)
            # (e) AUC（err_s の順位づけ）
            pred0 = Xc @ np.linalg.pinv(Xc.T @ Xc) @ (Xc.T @ ce_s)
            pred1 = X1 @ np.linalg.pinv(X1.T @ X1) @ (X1.T @ ce_s)
            out["auc_ctrl"] = auc(pred0, err_s)
            out["auc_ctrl_w"] = auc(pred1, err_s)
            out["auc_w_only"] = auc(wsum, err_s)
            out["auc_run_only"] = auc(-run.astype(float), err_s)
            out["auc_edit_only"] = auc(edit.astype(float), err_s)
            out["base_err"] = float(err_s.mean())
            out["d_auc"] = float(out["auc_ctrl_w"] - out["auc_ctrl"])

            # (f) 10 分位の当て方
            q = np.quantile(wsum, 0.9)
            top = wsum >= q
            bot = wsum <= np.quantile(wsum, 0.1)
            out["top10_w_share_tok"] = float(top.mean())
            out["top10_w_share_ce"] = float(ce_s[top].sum() / ce_s.sum())
            out["top10_w_mean_ce"] = float(ce_s[top].mean())
            out["bot10_w_share_ce"] = float(ce_s[bot].sum() / ce_s.sum())
            out["bot50_w_mean_ce"] = float(ce_s[wsum <= np.quantile(wsum, 0.5)].mean())
            out["edit_share_ce"] = float(ce_s[edit == 1].sum() / ce_s.sum())
            out["shortrun_share_ce"] = float(
                ce_s[run_bucket == 1].sum() / ce_s.sum())
            out["shortrun_share_tok"] = float((run_bucket == 1).mean())

            # (g) 幅は edit を当てられるか（当てられないなら「編集で重み付け」の代理にならない）
            out["r_w_edit"] = float(np.corrcoef(wsum, edit.astype(float))[0, 1])
            out["auc_w_edit"] = auc(wsum, edit)
            out["w_sd"] = float(wsum.std())
            out["r_w_pos"] = float(np.corrcoef(wsum, pos.astype(float))[0, 1])
            out["r_w_run"] = float(np.corrcoef(wsum, run.astype(float))[0, 1])

            # (h) copy トークンだけに絞った統制（edit は誰も解けないので除く）
            c = edit == 0
            Xc_c = build_controls({k2_: v[c] for k2_, v in d.items()})
            X1_c = np.concatenate([Xc_c, zw[c][:, None]], 1)
            b_c, se_c, r2_c1 = ols_cluster(ce_s[c], X1_c, seq_idx[c], n_groups)
            _, _, r2_c0 = ols_cluster(ce_s[c], Xc_c, seq_idx[c], n_groups)
            out["b_w_ces_copy"] = float(b_c[-1])
            out["t_w_ces_copy"] = float(b_c[-1] / se_c[-1])
            out["dR2_ces_copy"] = float(r2_c1 - r2_c0)
            out["auc_ctrl_copy"] = auc(
                Xc_c @ np.linalg.pinv(Xc_c.T @ Xc_c) @ (Xc_c.T @ ce_s[c]), err_s[c])
            out["auc_ctrl_w_copy"] = auc(
                X1_c @ np.linalg.pinv(X1_c.T @ X1_c) @ (X1_c.T @ ce_s[c]), err_s[c])
            out["auc_w_copy"] = auc(wsum[c], err_s[c])
            out["err_copy"] = float(err_s[c].mean())
            out["err_edit"] = float(err_s[edit == 1].mean())
            out["d_auc_copy"] = float(out["auc_ctrl_w_copy"] - out["auc_ctrl_copy"])

            rows.append(out)
            p("  s%d  相関 r(w,CE_s) %+.3f / r(w,CE_t) %+.3f / r(w,edit) %+.3f"
              " / r(w,pos) %+.3f / r(w,run) %+.3f  (幅 SD %.1f)" %
              (s, out["r_w_ces"], out["r_w_cet"], out["r_w_edit"],
               out["r_w_pos"], out["r_w_run"], out["w_sd"]))
            p("       統制後 β_w(CE_s) %+.4f (t %+.1f)  ΔR² %+.6f（統制のみ R² %.3f）"
              % (out["b_w_ces"], out["t_w_ces"], out["dR2_ces"], out["R2_ctrl_ces"]))
            p("       トークン dummy 追加 %+.4f (t %+.1f) / 最終層の幅 %+.4f (t %+.1f)"
              % (out["b_w_ces_tok"], out["t_w_ces_tok"],
                 out["b_wlast_ces"], out["t_wlast_ces"]))
            p("       教師側 β_w(CE_t) %+.4f (t %+.1f) / 差 β_w %+.4f (t %+.1f)"
              % (out["b_w_cet"], out["t_w_cet"], out["b_w_gap"], out["t_w_gap"]))
            p("       AUC(err_s): 統制のみ %.4f → +幅 %.4f（Δ %+.4f）"
              % (out["auc_ctrl"], out["auc_ctrl_w"],
                 out["auc_ctrl_w"] - out["auc_ctrl"]))
            p("                    幅単独 %.4f / 連長単独 %.4f / 編集単独 %.4f"
              % (out["auc_w_only"], out["auc_run_only"], out["auc_edit_only"]))
            p("       copy のみ: β_w %+.4f (t %+.1f) ΔR² %+.6f / AUC %.4f→%.4f（幅単独 %.4f）"
              " / 誤り率 copy %.4f vs edit %.4f"
              % (out["b_w_ces_copy"], out["t_w_ces_copy"], out["dR2_ces_copy"],
                 out["auc_ctrl_copy"], out["auc_ctrl_w_copy"], out["auc_w_copy"],
                 out["err_copy"], out["err_edit"]))
            p("       幅は edit を当てられるか: AUC %.4f（1.0 が完全）"
              % out["auc_w_edit"])
            p("       CE 質量: 幅上位10%%（トークンの %.1f%%）が %.1f%% / 下位10%% が %.1f%%"
              " / 編集（%.1f%%）が %.1f%% / 連長1-4（%.1f%%）が %.1f%%"
              % (100 * out["top10_w_share_tok"], 100 * out["top10_w_share_ce"],
                 100 * out["bot10_w_share_ce"],
                 100 * edit.mean(), 100 * out["edit_share_ce"],
                 100 * out["shortrun_share_tok"], 100 * out["shortrun_share_ce"]))
            p("")

        keys = ["b_w_ces", "t_w_ces", "dR2_ces", "b_w_cet", "t_w_cet", "dR2_cet",
                "b_w_gap", "t_w_gap", "dR2_gap", "auc_ctrl", "auc_ctrl_w",
                "auc_w_only", "auc_run_only", "auc_edit_only", "r_w_ces", "r_w_cet",
                "r_w_edit", "auc_w_edit", "b_w_ces_copy", "t_w_ces_copy",
                "dR2_ces_copy", "auc_ctrl_copy", "auc_ctrl_w_copy", "auc_w_copy",
                "err_copy", "err_edit", "w_sd", "r_w_pos", "r_w_run",
                "d_auc", "d_auc_copy"]
        p("  -- dense%d の seed 平均（n=3） --" % w)
        for k in keys:
            v = np.array([r[k] for r in rows])
            if k.startswith("dR2"):
                p("     %-14s %.3e ± %.3e  (3/3 同符号: %s)"
                  % (k, v.mean(), v.std(ddof=1) / np.sqrt(3),
                     "yes" if (v > 0).all() or (v < 0).all() else "no"))
            else:
                p("     %-14s %+.4f ± %.4f  (3/3 同符号: %s)"
                  % (k, v.mean(), v.std(ddof=1) / np.sqrt(3),
                     "yes" if (v > 0).all() or (v < 0).all() else "no"))
        p("")
        res["dense%d" % w] = rows

    with open(os.path.join(HERE, "k2_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2, default=float)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\n[write] %s" % OUT)


if __name__ == "__main__":
    main()
