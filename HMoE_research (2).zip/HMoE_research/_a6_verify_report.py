# -*- coding: utf-8 -*-
"""_a6_verify_report.py — 検証報告_A6 の数値を一次データから引き直して突合する。"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a4")
ok, bad = [], []


def chk(name, got, want, tol=5e-3):
    if abs(got - want) <= tol * max(1.0, abs(want)):
        ok.append(f"  OK  {name}: {got:.6g} (report {want})")
    else:
        bad.append(f"  NG  {name}: {got:.6g} != report {want}")


rows = []
for fn in ("a4_results.json", "a4_results_w.json", "a4_results_p.json"):
    p = os.path.join(D, fn)
    if os.path.exists(p):
        rows += [r for r in json.load(open(p, encoding="utf-8")) if "evals" in r]
base = [r for r in rows if r["arm"] == "all_relu"]
W = base[0]["widths"]
TOT = sum(W)

# --- 1. 曲線の各点 ---
PTS = {
    "all_relu": (0.000, 0.0219, 0.643, 0.000, None),
    "deg_e6": (0.219, 0.0355, 0.502, -0.108, 0.493),
    "deg_e7": (0.219, 0.0105, 0.801, +0.190, 0.098),
    "large_relu2": (0.438, 0.0206, 0.688, +0.045, 0.744),
    "wide4": (0.750, 0.0088, 0.845, +0.202, 0.026),
    "wide6": (0.938, 0.0221, 0.582, -0.061, 0.529),
    "all_relu2": (1.000, 0.0651, 0.121, -0.522, 0.0005),
    "small_relu2": (0.062, 0.0211, 0.632, -0.011, 0.905),
}
IDX = {"all_relu": [], "deg_e6": [6], "deg_e7": [7], "large_relu2": [6, 7],
       "wide4": [4, 5, 6, 7], "wide6": [2, 3, 4, 5, 6, 7], "all_relu2": list(range(8)),
       "small_relu2": [0, 1]}
for a, (ws, ce, iv, div, p) in PTS.items():
    rs = [r for r in rows if r["arm"] == a]
    if not rs:
        bad.append(f"  NG  アームが無い: {a}")
        continue
    chk(f"幅シェア {a}", sum(W[i] for i in IDX[a]) / TOT, ws, tol=1e-3)
    chk(f"CE {a}", float(np.mean([r["evals"][-1]["ce_all"] for r in rs])), ce, tol=5e-3)
    chk(f"instr {a}", float(np.mean([r["evals"][-1]["instr_valid"] for r in rs])), iv, tol=5e-3)
    seeds = sorted({r["seed"] for r in rs} & {r["seed"] for r in base})
    if a != "all_relu":
        m = {r["seed"]: r["evals"][-1]["instr_valid"] for r in rs}
        bm = {r["seed"]: r["evals"][-1]["instr_valid"] for r in base}
        x = np.array([m[s] for s in seeds])
        y = np.array([bm[s] for s in seeds])
        chk(f"Δinstr {a}", float((x - y).mean()), div, tol=1e-2)
        if p is not None:
            t, pv = stats.ttest_rel(x, y)
            chk(f"p {a}", float(pv), p, tol=5e-2)

# --- 2. wide4 の seed 別（6/6 正）---
w4 = {r["seed"]: r["evals"][-1]["instr_valid"] for r in rows if r["arm"] == "wide4"}
b0 = {r["seed"]: r["evals"][-1]["instr_valid"] for r in base}
d = np.array([w4[s] - b0[s] for s in sorted(set(w4) & set(b0))])
chk("wide4 の正の seed 数", int((d > 0).sum()), 6, tol=0)
chk("wide4 Δ 最大", float(d.max()), 0.428, tol=2e-2)
chk("wide4 Δ 最小", float(d.min()), 0.013, tol=5e-2)

# --- 3. ルーティング ---
def usage(a):
    rs = [r for r in rows if r["arm"] == a]
    return np.array([r["routing"]["usage"] for r in rs]).mean(0)


U = {a: usage(a) for a in ("all_relu", "wide4", "wide6", "all_relu2")}
chk("e4..e7 all_relu", float(U["all_relu"][4:].sum()), 0.1973, tol=1e-3)
chk("e4..e7 wide4", float(U["wide4"][4:].sum()), 0.1589, tol=1e-3)
chk("e4..e7 wide6", float(U["wide6"][4:].sum()), 0.1549, tol=1e-3)
chk("e4..e7 all_relu2", float(U["all_relu2"][4:].sum()), 0.2045, tol=1e-3)
chk("e2+e3 all_relu", float(U["all_relu"][2:4].sum()), 0.2377, tol=1e-3)
chk("e2+e3 wide4", float(U["wide4"][2:4].sum()), 0.2876, tol=1e-3)
chk("e2+e3 wide6", float(U["wide6"][2:4].sum()), 0.2076, tol=1e-3)
chk("e0+e1 all_relu", float(U["all_relu"][:2].sum()), 0.5651, tol=1e-3)
chk("e0+e1 wide6", float(U["wide6"][:2].sum()), 0.6375, tol=1e-3)

# --- 4. 幅の合計と k=4 の内訳 ---
chk("総幅", TOT, 1024, tol=0)
chk("e4..e7 の幅", sum(W[4:]), 768, tol=0)
chk("e6,e7 の幅", sum(W[6:]), 448, tol=0)

# --- 5. A1 の dead 率（スパース性の棄却に引用）---
a1 = json.load(open(os.path.join(HERE, "data", "a1", "a1_analysis.json"), encoding="utf-8"))
chk("A1 relu の dead", a1["aggregate"]["relu"]["dead"], 0.580, tol=1e-2)
chk("A1 relu2 の dead", a1["aggregate"]["relu2"]["dead"], 0.588, tol=1e-2)
chk("A1 relu_w067 − relu", [c for c in a1["contrasts"]
                            if c["a"] == "relu_w067" and c["b"] == "relu"
                            and c["metric"] == "instr_valid"][0]["mean"], 0.147, tol=2e-2)

print("\n".join(ok))
if bad:
    print("\n".join(bad))
    print(f"\nFAIL: {len(bad)} 件")
    sys.exit(1)
print(f"\nPASS: {len(ok)} 件すべて報告書と一致")
