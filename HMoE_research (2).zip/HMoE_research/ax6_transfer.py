#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX6: 別コーパスで per-token 限界コストを測り直し、log-N 対比が再現するかを検証する

設計書: AX6課題設計書_別コーパスでper-token限界コストを測り直しlog-N対比が再現するかを検証する_20261112.md
（走行前に分割定義・決定規則・検定族・主腕を凍結）

新規 forward 44 本 = base / base_rep / u7 / ab7_L×16 / ab6_L×16 /
  uni48 / uni102 / uni181 / uni340 / uni630 / uni1224 / global1 / tok12240 / rand340

確認的（Holm m=2, alpha=0.05, 両側）
  K1（主）: C_new = Σ_k w_k G_new(N_k) = 0   （AX5 と同一の log-N 対比）
  K2      : G_new(1224) - G_new(48) = 0

実行:
  python ax6_transfer.py --dry-run
  python ax6_transfer.py --smoke --tag ax6smoke
  python ax6_transfer.py --tag ax6
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ax2_layer_cost import paired, holm  # noqa: E402  純関数のみ

N_LAYERS = 16
ALPHA = 0.05
H3_NS = [48, 102, 181, 340, 630, 1224]
H3_ARMS = ["uni48", "uni102", "uni181", "uni340", "uni630", "uni1224"]
SEED_RAND = 6201
FROZEN_AX6 = os.path.join(HERE, "corpus_ids_ax6_w24_l256.npz")
FROZEN_AX3 = os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz")
AX5_JSON = os.path.join(HERE, "ax5_granularity_mech.json")

TEE = None


def log(msg):
    print(msg, flush=True)
    if TEE is not None:
        TEE.write(msg + "\n")
        TEE.flush()


# ---------------------------------------------------------------- 分割・決定
def uniform_lengths(n_unit, total):
    base, rem = divmod(total, n_unit)
    lens = np.full(n_unit, base, dtype=np.int64)
    lens[:rem] += 1
    return lens


def lengths_to_uid(lens):
    return np.repeat(np.arange(len(lens), dtype=np.int32), lens)


def unit_targets(c8, c7, uid, n_unit):
    cnt = np.bincount(uid, minlength=n_unit).astype(np.float64)
    assert cnt.min() > 0
    a = np.stack([np.bincount(uid, weights=c8[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    b = np.stack([np.bincount(uid, weights=c7[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    return np.concatenate([a, b], axis=1)


def unit_decision(Y):
    cut = np.argmin(Y[:, N_LAYERS:], axis=1).astype(np.int8)
    Q = Y[:, :N_LAYERS].copy()
    Q[np.arange(Y.shape[0]), cut] = -np.inf
    prot = np.argmax(Q, axis=1).astype(np.int8)
    assert (cut != prot).all()
    return cut, prot


def kmat_from_units(uid, cut, prot, n_tok):
    km = np.full((N_LAYERS, n_tok), 7, dtype=np.int8)
    for u in range(len(cut)):
        sel = (uid == u)
        km[cut[u], sel] = 6
        km[prot[u], sel] = 8
    return km


def to_windows(kmat_eval, nw, n_eval, ln, pad_val=7):
    km = kmat_eval.reshape(N_LAYERS, nw, n_eval)
    km = np.concatenate([km, np.full((N_LAYERS, nw, 1), pad_val, dtype=np.int8)], axis=2)
    return km.reshape(N_LAYERS, nw * ln)


def grams8(x):
    return set(tuple(int(v) for v in x[i:i + 8]) for i in range(len(x) - 7))


def overlap8(a, b):
    gb = grams8(b)
    return float(np.mean([tuple(int(v) for v in a[i:i + 8]) in gb
                         for i in range(len(a) - 7)]))


def load_ax6(n_win, ln):
    z = np.load(FROZEN_AX6, allow_pickle=True)
    seqs = []
    for lang in ("en", "ja"):
        ids = torch.from_numpy(z[lang + "_ids"].astype(np.int64))
        assert ids.numel() >= n_win * ln
        for w in range(n_win):
            seqs.append((lang, ids[w * ln:(w + 1) * ln]))
    return seqs


def assert_finite(obj, path="root"):
    bad = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            bad += assert_finite(v, path + "/" + str(k))
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            bad += assert_finite(v, path + "/%d" % i)
    elif isinstance(obj, float) and (math.isnan(obj) or math.isinf(obj)):
        bad.append(path)
    elif isinstance(obj, np.floating) and not np.isfinite(obj):
        bad.append(path)
    return bad


# ---------------------------------------------------------------- main
def main():
    global TEE
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--tag", type=str, default="ax6")
    args = ap.parse_args()
    tag = args.tag
    TEE = open(os.path.join(HERE, "%s_transfer_out_utf8.txt" % tag), "w", encoding="utf-8")

    n_win = 3 if args.smoke else args.windows
    ln, n_eval = args.len, args.len - 1
    nw, n_tok = 2 * n_win, 2 * n_win * n_eval

    log("[1] corpus / partitions")
    seqs = load_ax6(n_win, ln)
    lang = np.array([lg for lg, _ in seqs])
    z3 = np.load(FROZEN_AX3, allow_pickle=True)
    z6 = np.load(FROZEN_AX6, allow_pickle=True)
    ov = {lg: overlap8(z3[lg + "_ids"], z6[lg + "_ids"]) for lg in ("en", "ja")}
    log("    windows %d  eval tokens %d  overlap8 en %.6f ja %.6f" % (nw, n_tok, ov["en"], ov["ja"]))

    parts = {}
    parts["global1"] = np.zeros(n_tok, dtype=np.int32)
    parts["uni48"] = np.repeat(np.arange(nw, dtype=np.int32), n_eval)
    for n in (102, 181, 340, 630, 1224):
        parts["uni%d" % n] = lengths_to_uid(uniform_lengths(n, n_tok))
    parts["tok12240"] = np.arange(n_tok, dtype=np.int32)
    parts["rand340"] = parts["uni340"].copy()
    for nm, uid in parts.items():
        assert uid.shape == (n_tok,) and uid.min() == 0
        assert np.array_equal(np.unique(uid), np.arange(uid.max() + 1)), nm
    log("    parts: " + "  ".join("%s=%d" % (k, int(v.max()) + 1) for k, v in parts.items()))

    # H3 重み（AX5 と同一かを C7 で照合）
    w = np.log(np.array(H3_NS, dtype=np.float64))
    w -= w.mean()
    with open(AX5_JSON, encoding="utf-8") as fp:
        J5 = json.load(fp)
    w_ax5 = np.array(J5["manipulation_check_H3"]["weights"], dtype=np.float64)
    c7_ok = bool(np.abs(w - w_ax5).max() < 1e-12 and abs(w.sum()) < 1e-12)
    log("    H3 weights match AX5: %s  (maxdiff %.2e)" % (c7_ok, np.abs(w - w_ax5).max()))

    if args.dry_run:
        log("    dry-run OK (no model, no forward)")
        TEE.close()
        return

    log("[2] load model")
    t0 = time.time()
    from transformers import AutoModelForCausalLM, AutoTokenizer
    AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    full_k = int(model.config.num_experts_per_tok)
    assert full_k == 8 and int(model.config.num_hidden_layers) == N_LAYERS
    gates = [l.mlp.gate for l in model.model.layers]
    gate_fwd = [g.forward for g in gates]
    log("    %.0f s" % (time.time() - t0))

    STATE = {"kmat": None}

    def make_masked(orig, li):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            km = STATE["kmat"]
            if km is not None and scores.shape[-1] == full_k:
                kk = km[li]
                if kk.numel() == scores.shape[0]:
                    ar = torch.arange(scores.shape[-1], device=scores.device, dtype=torch.float32)
                    scores = scores * (ar[None, :] < kk[:, None]).to(scores.dtype)
            return logits, scores, idx
        return _patched

    for i, g in enumerate(gates):
        g.forward = make_masked(gate_fwd[i], i)

    cache_dir = os.path.join(HERE, "_ax6_cache_%s" % tag)
    os.makedirs(cache_dir, exist_ok=True)

    def run_eval(name, native_topks=None, kmat_windows=None):
        cf = os.path.join(cache_dir, name + ".npz")
        if os.path.exists(cf):
            c = np.load(cf)
            log("    %-14s CACHED CE %.5f" % (name, float(c["nll"].mean())))
            return {"nll": c["nll"], "acc1": c["acc1"]}
        t1 = time.time()
        if kmat_windows is not None:
            for g in gates:
                g.top_k = full_k
        else:
            STATE["kmat"] = None
            tk = full_k if native_topks is None else native_topks
            for i, g in enumerate(gates):
                g.top_k = int(tk[i] if not np.isscalar(tk) else tk)
        nll_c, a1_c = [], []
        with torch.no_grad():
            for wi, (lg, ids) in enumerate(seqs):
                if kmat_windows is not None:
                    STATE["kmat"] = torch.from_numpy(
                        kmat_windows[:, wi * ln:(wi + 1) * ln].astype(np.float32)
                    ).to(model.device)
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                logit = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(logit, tgt, reduction="none")
                true_l = logit.gather(1, tgt.unsqueeze(-1))
                a1_c.append(((logit > true_l).sum(-1) == 0).float().cpu().numpy())
                nll_c.append(nll.cpu().numpy())
                del out, logit
        STATE["kmat"] = None
        nll = np.concatenate(nll_c).astype(np.float32)
        a1 = np.concatenate(a1_c).astype(np.float32)
        np.savez_compressed(cf, nll=nll, acc1=a1)
        log("    %-14s CE %.5f  top1 %.4f  (%.0f s)"
            % (name, nll.mean(), a1.mean(), time.time() - t1))
        return {"nll": nll, "acc1": a1}

    # ---- native 35 本 ----
    log("[3] native forwards (35)")
    res = {}
    native = [("base", [full_k] * N_LAYERS), ("base_rep", [full_k] * N_LAYERS),
              ("u7", [7] * N_LAYERS)]
    for L in range(N_LAYERS):
        native.append(("ab7_%02d" % L, [7 if i == L else full_k for i in range(N_LAYERS)]))
    for L in range(N_LAYERS):
        native.append(("ab6_%02d" % L, [6 if i == L else full_k for i in range(N_LAYERS)]))
    for nm, tk in native:
        res[nm] = run_eval(nm, native_topks=tk)

    N = {k: v["nll"].astype(np.float64) for k, v in res.items()}
    c8 = np.stack([N["ab7_%02d" % L] - N["base"] for L in range(N_LAYERS)])
    c7 = np.stack([N["ab6_%02d" % L] - N["ab7_%02d" % L] for L in range(N_LAYERS)])
    log("    c8 mean %.6f  c7 mean %.6f" % (c8.mean(), c7.mean()))

    # ---- 決定 ----
    log("[4] decisions")
    dec = {}
    for nm, uid in parts.items():
        nu = int(uid.max()) + 1
        if nm == "rand340":
            rng = np.random.RandomState(SEED_RAND)
            cut = rng.randint(0, N_LAYERS, size=nu).astype(np.int8)
            draw = rng.randint(0, N_LAYERS - 1, size=nu)
            prot = (draw + (draw >= cut)).astype(np.int8)
            assert (cut != prot).all()
        else:
            cut, prot = unit_decision(unit_targets(c8, c7, uid, nu))
        dec[nm] = (cut, prot)

    mask_arms = []
    for nm, uid in parts.items():
        cut, prot = dec[nm]
        km = to_windows(kmat_from_units(uid, cut, prot, n_tok), nw, n_eval, ln, 7)
        mask_arms.append((nm, km))
        log("    %-12s N=%5d  mean_k %.6f" % (nm, len(cut), km.mean()))

    log("[5] mask forwards (9)")
    for nm, km in mask_arms:
        res[nm] = run_eval(nm, kmat_windows=km)

    # ---- 統計 ----
    log("[6] stats / calibration")
    N = {k: v["nll"].astype(np.float64) for k, v in res.items()}
    u7 = N["u7"]
    gains = {}
    for nm in list(parts) + ["base", "base_rep"]:
        gains[nm] = paired(u7 - N[nm], nw, n_eval)

    d_k1 = np.zeros(n_tok, dtype=np.float64)
    for wk, nm in zip(w, H3_ARMS):
        d_k1 -= wk * N[nm]
    st1 = paired(d_k1, nw, n_eval)
    st2 = paired(N["uni48"] - N["uni1224"], nw, n_eval)
    ph = holm({"K1": st1["p_two"], "K2": st2["p_two"]})
    rej = {k: bool(ph[k] < ALPHA) for k in ph}
    if rej["K1"] and st1["mean"] > 0 and rej["K2"] and st2["mean"] > 0:
        case = "A"
    elif rej["K1"] and st1["mean"] > 0:
        case = "B"
    elif rej["K1"] and st1["mean"] < 0:
        case = "D"
    else:
        case = "C"

    calib = {}
    c1 = {"base_maxdiff": float(np.abs(N["base_rep"] - N["base"]).max())}
    c1["tier"] = "SKIP" if args.smoke else ("A" if c1["base_maxdiff"] == 0.0 else "FAIL")
    calib["C1"] = c1
    calib["C2"] = {"overlap8_en": ov["en"], "overlap8_ja": ov["ja"],
                   "threshold": {"en": 0.05, "ja": 0.20},
                   "pass": bool(ov["en"] < 0.05 and ov["ja"] < 0.20)}
    mean_k = {nm: float(km.mean()) for nm, km in mask_arms}
    mk_bad = {k: v for k, v in mean_k.items() if abs(v - 7.0) > 1e-9}
    replay = {}
    for nm, uid in parts.items():
        if nm == "rand340":
            continue
        c_re, p_re = unit_decision(unit_targets(c8, c7, uid, int(uid.max()) + 1))
        replay[nm] = int(bool((dec[nm][0] == c_re).all() and (dec[nm][1] == p_re).all()))
    calib["C3"] = {"mean_k": mean_k, "n_bad": len(mk_bad),
                   "decision_replay": replay}
    calib["C4"] = {"n_bad": len(mk_bad), "slots_per_token": 112}
    conflicts = {nm: int((cut == prot).sum()) for nm, (cut, prot) in dec.items()}
    calib["C5"] = {"conflicts": conflicts,
                   "cut_hist_uni340": np.bincount(dec["uni340"][0], minlength=N_LAYERS).tolist()}
    calib["C6"] = {"uniform": "u7", "random": "rand340", "oracle": "tok12240",
                   "random_gain": gains["rand340"]["mean"],
                   "oracle_gain": gains["tok12240"]["mean"],
                   "random_le_oracle": bool(gains["rand340"]["mean"]
                                            <= gains["tok12240"]["mean"])}
    calib["C7"] = {"weights": w.tolist(), "ax5_weights": w_ax5.tolist(),
                   "maxdiff": float(np.abs(w - w_ax5).max()),
                   "sum": float(w.sum()), "pass": c7_ok}

    # AX5 との独立標本比較（探索的・検定しない）
    j5_curve = J5["exploratory"]["granularity_curve"]
    comparison = {}
    for n, nm in zip(H3_NS, H3_ARMS):
        key = {"48": "win48", "102": "uni102", "181": "uni181",
               "340": "uni340", "630": "uni630", "1224": "uni1224"}[str(n)]
        comparison[str(n)] = {"ax5": float(j5_curve[key]),
                              "ax6": float(gains[nm]["mean"])}
    h3_ax5 = J5["manipulation_check_H3"]["mean"]

    out = {
        "meta": {"tag": tag, "smoke": bool(args.smoke), "windows": nw, "len": ln,
                 "n_tok": int(n_tok), "n_arms": len(res),
                 "design": "AX6課題設計書_別コーパスでper-token限界コストを測り直しlog-N対比が再現するかを検証する_20261112.md",
                 "seed_rand": SEED_RAND, "h3_ns": H3_NS},
        "confirmatory": {"K1_h3_contrast": st1, "K2_endpoints": st2,
                         "holm": ph, "reject": rej, "case": case},
        "calib": calib, "gains": gains,
        "exploratory": {"granularity_curve": {nm: gains[nm]["mean"] for nm in H3_ARMS},
                        "comparison_with_ax5": comparison,
                        "h3_ax5": h3_ax5, "h3_ax6": st1["mean"],
                        "top1_abs_share_K1": st1["top1_abs_share"],
                        "top1_abs_share_K2": st2["top1_abs_share"]},
    }
    bad = assert_finite(out)
    assert not bad, "非有限値が JSON に混入: %s" % bad[:8]

    log("[7] save")
    with open(os.path.join(HERE, "%s_transfer.json" % tag), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2, allow_nan=False)
    save = {("nll_" + k): v["nll"] for k, v in res.items()}
    save.update({("acc1_" + k): v["acc1"] for k, v in res.items()})
    save.update({"c8": c8, "c7": c7, "w": w, "lang": lang})
    save.update({("uid_" + k): v for k, v in parts.items()})
    for nm, (cut, prot) in dec.items():
        save["cut_" + nm] = cut
        save["prot_" + nm] = prot
    np.savez_compressed(os.path.join(HERE, "%s_transfer.npz" % tag), **save)

    log("")
    log("== confirmatory (Holm m=2, alpha=%.2f) ==" % ALPHA)
    log("K1 H3 contrast %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
        % (st1["mean"], st1["t"], st1["p_two"], ph["K1"], st1["mde"]))
    log("K2 G1224-G48   %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
        % (st2["mean"], st2["t"], st2["p_two"], ph["K2"], st2["mde"]))
    log("case = %s   (AX5 H3 %+.8f)" % (case, h3_ax5))
    log("curve: " + "  ".join("%s %+.5f" % (k, v)
                              for k, v in out["exploratory"]["granularity_curve"].items()))
    log("calib: C1 %s  C2 %s (en %.4f/ja %.4f)  C3 bad %d  C6 %s  C7 %s"
        % (c1["tier"], calib["C2"]["pass"], ov["en"], ov["ja"],
           calib["C3"]["n_bad"], calib["C6"]["random_le_oracle"], c7_ok))
    log("saved: %s_transfer.npz / .json  (non-finite check OK)" % tag)
    TEE.close()
    os._exit(0)


if __name__ == "__main__":
    main()
