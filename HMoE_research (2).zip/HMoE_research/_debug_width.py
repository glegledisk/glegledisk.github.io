# -*- coding: utf-8 -*-
"""_debug_width.py — 差し替え forward が NaN を出す原因を切り分ける（使い捨て）"""
import os
import types

import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "olmoe-1b-7b")

from transformers import AutoModelForCausalLM

m = AutoModelForCausalLM.from_pretrained(MODEL, torch_dtype=torch.bfloat16,
                                         device_map="cpu", low_cpu_mem_usage=True).eval()
blk = m.model.layers[0].mlp
exp = blk.experts
print("num_experts attr:", getattr(exp, "num_experts", "MISSING"))
print("act_fn:", getattr(exp, "act_fn", "MISSING"))
print("gate_up_proj:", tuple(exp.gate_up_proj.shape), "down:", tuple(exp.down_proj.shape))

torch.manual_seed(0)
N = 32
h = torch.randn(N, 2048, dtype=torch.bfloat16)
top_idx = torch.stack([torch.randperm(64)[:8] for _ in range(N)])
w = torch.rand(N, 8, dtype=torch.bfloat16) * 0.1

ref = exp(h, top_idx, w)
print("ref finite:", torch.isfinite(ref).all().item(), "mean", ref.float().mean().item())


def make_forward(mode, half_idx):
    def fwd(self, hidden_states, top_k_index, top_k_weights):
        final = torch.zeros_like(hidden_states)
        K = top_k_index.shape[-1]
        d_ff = self.down_proj.shape[-1]
        with torch.no_grad():
            mask = F.one_hot(top_k_index, num_classes=self.num_experts + 1).permute(2, 1, 0)
            hit = torch.greater(mask.sum(dim=(-1, -2)), 0).nonzero()
        for ei in hit:
            e = int(ei[0])
            if e == self.num_experts:
                continue
            pos, tok = torch.where(mask[e])
            is_r8 = (pos == K - 1)
            gu = self.gate_up_proj[e]
            dn = self.down_proj[e]
            keep = ~is_r8
            if keep.any():
                x = hidden_states[tok[keep]]
                g, u = F.linear(x, gu).chunk(2, dim=-1)
                hh = F.linear(self.act_fn(g) * u, dn)
                hh = hh * top_k_weights[tok[keep], pos[keep], None]
                final.index_add_(0, tok[keep], hh.to(final.dtype))
            if not is_r8.any() or mode == "skip":
                continue
            x = hidden_states[tok[is_r8]]
            if mode == "full":
                g, u = F.linear(x, gu).chunk(2, dim=-1)
                hh = F.linear(self.act_fn(g) * u, dn)
            else:
                hi = half_idx.to(gu.device)
                g = F.linear(x, gu[hi])
                u = F.linear(x, gu[d_ff + hi])
                hh = F.linear(self.act_fn(g) * u, dn[:, hi])
            hh = hh * top_k_weights[tok[is_r8], pos[is_r8], None]
            final.index_add_(0, tok[is_r8], hh.to(final.dtype))
        return final
    return fwd


half_idx = torch.arange(512)
for mode in ("full", "prune", "skip"):
    fn = make_forward(mode, half_idx)
    got = fn(exp, h, top_idx, w)
    d = (got.float() - ref.float()).abs().max().item()
    print("%-6s finite=%s  maxdiff=%.5f  mean=%.5f"
          % (mode, torch.isfinite(got).all().item(), d, got.float().mean().item()))

# どこで NaN になるか: 枝ごとの出力を確認
e0 = int(top_idx[0, 0])
pos, tok = torch.where(F.one_hot(top_idx, num_classes=65).permute(2, 1, 0)[e0])
print("expert", e0, "pairs", pos.tolist(), tok.tolist())
x = h[tok]
gu = exp.gate_up_proj[e0]
g, u = F.linear(x, gu).chunk(2, dim=-1)
print("gate finite", torch.isfinite(g).all().item(), "up finite", torch.isfinite(u).all().item())
print("act(gate) finite", torch.isfinite(exp.act_fn(g)).all().item())
