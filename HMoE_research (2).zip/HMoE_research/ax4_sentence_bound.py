#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX4: 実際の文境界での oracle 上限と決定単位の粒度の効果

設計書: AX4課題設計書_実際の文境界でのoracle上限と粒度の効果_20261111.md
（走行前に文境界定義・決定規則・検定族・校正を凍結）

AX3 と同一コーパス・同一保存配列を使い、決定単位だけを変える。
新規 forward 8 本 = base_rep / u7_rep / sent_oracle / sent_random /
sent_probe / sent2_oracle / sent4_oracle / sent_nl_oracle

確認的（Holm m=3, alpha=0.05, 両側）
  V1（主）: G_sent_oracle - G_win_oracle = 0      （粒度 48 → 340 の効果）
  V2      : G_sent_oracle = 0
  V3      : G_sent_oracle - G_tok_oracle = 0

実行:
  python ax4_sentence_bound.py --smoke --tag ax4smoke
  python ax4_sentence_bound.py --tag ax4
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ax2_layer_cost import (  # noqa: E402  純関数のみ
    paired, tost, holm, spearman, gate_stats, randproj, shift_within, movavg,
)

N_LAYERS = 16
H_STRATA = (0, 5, 10, 15)
FEAT_PER_LAYER = 71
NHIST = 9
LAM = 10.0
ALPHA = 0.05
MIN_SENT = 8
BOUND_PERIOD = (2, 15, 32, 4340)
BOUND_NL = (2, 15, 32, 187, 4340)
RAND_SEED = 1201
PERM_SEED = 4400
NPERM = 100
AX3_NPZ = os.path.join(HERE, "ax3_transfer.npz")
AX3_CORPUS = os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz")

TEE = None


def log(msg):
    print(msg, flush=True)
    if TEE is not None:
        TEE.write(msg + "\n")
        TEE.flush()


# ---------------------------------------------------------------- 文境界
def build_sent_ids(ids, bset, n_win, ln, minlen=MIN_SENT):
    """窓内完結・最小文長の文 ID を返す。境界トークンは文末に含める。"""
    n = len(ids)
    sent = np.zeros(n, dtype=np.int32)
    sid, lens, n_merged = 0, [], 0
    for w in range(n_win):
        seg = ids[w * ln:(w + 1) * ln]
        ends = np.where(np.isin(seg, list(bset)))[0]
        cuts, start = [], 0
        for e in ends:
            if e + 1 - start >= minlen:
                cuts.append([start, e + 1])
                start = e + 1
        if start < ln:
            if cuts:
                cuts[-1][1] = ln
                n_merged += 1
            else:
                cuts.append([0, ln])
        for a, b in cuts:
            sent[w * ln + a:w * ln + b] = sid
            lens.append(b - a)
            sid += 1
    lens = np.array(lens)
    assert sent.shape == (n,) and np.array_equal(np.unique(sent), np.arange(sid))
    assert lens.min() >= minlen, lens.min()
    return sent, lens, n_merged


def sent_ids_tok(sent, n_win, n_eval):
    """文 ID (窓トークン列 256) → 評価トークン列 255 へ変換。"""
    out = np.zeros(n_win * n_eval, dtype=np.int32)
    for w in range(n_win):
        out[w * n_eval:(w + 1) * n_eval] = sent[w * 256:w * 256 + n_eval]
    return out


def group_units(sid, k, n_win, n_eval):
    """窓内ローカル文 ID を k 個まとめる（窓をまたがない）。"""
    out = np.zeros_like(sid)
    off = 0
    for w in range(n_win):
        sl = slice(w * n_eval, (w + 1) * n_eval)
        sw = sid[sl]
        lo = sw - sw.min()
        out[sl] = off + lo // k
        off = int(out[sl].max()) + 1
    return out


# ---------------------------------------------------------------- 予測器
def ridge_loo(W, Y, lam=LAM):
    n = W.shape[0]
    pred = np.zeros_like(Y, dtype=np.float64)
    for f in range(n):
        tr = np.arange(n) != f
        Xtr, Xte = W[tr], W[f:f + 1]
        mu, sd = Xtr.mean(0), Xtr.std(0) + 1e-8
        A, B = (Xtr - mu) / sd, (Xte - mu) / sd
        ym = Y[tr].mean(0)
        d = A.shape[1]
        if d <= A.shape[0]:
            w = np.linalg.solve(A.T @ A + lam * np.eye(d), A.T @ (Y[tr] - ym))
        else:
            a = np.linalg.solve(A @ A.T + lam * np.eye(A.shape[0]), Y[tr] - ym)
            w = A.T @ a
        pred[f] = (B @ w + ym)[0]
    return pred


def unit_targets(c8, c7, sid, n_unit):
    """(16, n_tok) → (n_unit, 32) の単位平均 c8 / c7。"""
    c8u = np.stack([np.bincount(sid, weights=c8[L], minlength=n_unit)
                    for L in range(N_LAYERS)], axis=1)
    c7u = np.stack([np.bincount(sid, weights=c7[L], minlength=n_unit)
                    for L in range(N_LAYERS)], axis=1)
    cnt = np.bincount(sid, minlength=n_unit).astype(np.float64)
    assert cnt.min() > 0
    return np.concatenate([c8u / cnt[:, None], c7u / cnt[:, None]], axis=1)


def unit_decision(Y):
    n = Y.shape[0]
    cut = np.argmin(Y[:, N_LAYERS:], axis=1).astype(np.int8)
    Q = Y[:, :N_LAYERS].copy()
    Q[np.arange(n), cut] = -np.inf
    prot = np.argmax(Q, axis=1).astype(np.int8)
    assert (cut != prot).all()
    return cut, prot


def kmat_from_units(sid, cut, prot, n_tok):
    km = np.full((N_LAYERS, n_tok), 7, dtype=np.int8)
    for u in range(len(cut)):
        sel = (sid == u)
        km[cut[u], sel] = 6
        km[prot[u], sel] = 8
    return km


def to_windows(kmat_eval, nw, n_eval, ln, pad_val=7):
    km = kmat_eval.reshape(N_LAYERS, nw, n_eval)
    km = np.concatenate([km, np.full((N_LAYERS, nw, 1), pad_val, dtype=np.int8)], axis=2)
    return km.reshape(N_LAYERS, nw * ln)


# ---------------------------------------------------------------- main
def main():
    global TEE
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--tag", type=str, default="ax4")
    args = ap.parse_args()
    tag = args.tag
    TEE = open(os.path.join(HERE, "%s_sentence_bound_out_utf8.txt" % tag), "w", encoding="utf-8")

    n_win = 3 if args.smoke else args.windows
    ln = args.len
    n_eval = ln - 1
    nw = 2 * n_win
    n_tok = nw * n_eval

    z3 = np.load(AX3_NPZ)
    if n_tok != z3["nll_u7"].size:
        # smoke では AX3 の先頭 n_tok トークンだけを使う（全配列を同じ長さで切る）
        sl = slice(0, n_tok)
        c8 = z3["c8"][:, sl].astype(np.float64)
        c7 = z3["c7"][:, sl].astype(np.float64)
        base_ax3 = z3["nll_base"][sl].astype(np.float64)
        u7_ax3 = z3["nll_u7"][sl].astype(np.float64)
        win_oracle_ax3 = z3["nll_lay_win_oracle"][sl].astype(np.float64)
        tok_oracle_ax3 = z3["nll_lay_tok_oracle"][sl].astype(np.float64)
        win_mlp_ax3 = z3["nll_lay_win_mlp"][sl].astype(np.float64)
        lang = z3["lang"][:nw]
    else:
        c8 = z3["c8"].astype(np.float64)
        c7 = z3["c7"].astype(np.float64)
        base_ax3 = z3["nll_base"].astype(np.float64)
        u7_ax3 = z3["nll_u7"].astype(np.float64)
        win_oracle_ax3 = z3["nll_lay_win_oracle"].astype(np.float64)
        tok_oracle_ax3 = z3["nll_lay_tok_oracle"].astype(np.float64)
        win_mlp_ax3 = z3["nll_lay_win_mlp"].astype(np.float64)
        lang = z3["lang"]

    log("[1/8] sentence boundaries")
    zc = np.load(AX3_CORPUS, allow_pickle=True)
    ids_all, sent_all, sent_nl_all = [], [], []
    stats = {}
    for lg in ("en", "ja"):
        ids = zc[lg + "_ids"].astype(np.int64)[:n_win * ln]
        ids_all.append(ids)
        s, lens, nm = build_sent_ids(ids, BOUND_PERIOD, n_win, ln)
        snl, lens_nl, nm_nl = build_sent_ids(ids, BOUND_NL, n_win, ln)
        sent_all.append(sent_ids_tok(s, n_win, n_eval))
        sent_nl_all.append(sent_ids_tok(snl, n_win, n_eval))
        stats[lg] = {"n_sent": int(lens.size), "mean_len": float(lens.mean()),
                     "median_len": float(np.median(lens)), "min_len": int(lens.min()),
                     "max_len": int(lens.max()), "n_merged": int(nm),
                     "n_sent_nl": int(lens_nl.size), "mean_len_nl": float(lens_nl.mean())}
        log("      %s n_sent %d  mean %.1f  median %.1f  max %d"
            % (lg, lens.size, lens.mean(), np.median(lens), lens.max()))
    # 言語ごとの文 ID を連結（en 側の ID を ja 側の末尾へずらす）
    off = int(sent_all[0].max()) + 1
    sent = np.concatenate([sent_all[0], sent_all[1] + off]).astype(np.int32)
    off_nl = int(sent_nl_all[0].max()) + 1
    sent_nl = np.concatenate([sent_nl_all[0], sent_nl_all[1] + off_nl]).astype(np.int32)
    n_sent = int(sent.max()) + 1
    n_sent_nl = int(sent_nl.max()) + 1
    sent2 = group_units(sent, 2, nw, n_eval)
    sent4 = group_units(sent, 4, nw, n_eval)
    log("      total n_sent %d / nl %d / 2-merge %d / 4-merge %d"
        % (n_sent, n_sent_nl, int(sent2.max()) + 1, int(sent4.max()) + 1))
    # C2
    c2 = {"stats": stats, "n_sent": n_sent, "n_sent_nl": n_sent_nl,
          "n_2merge": int(sent2.max()) + 1, "n_4merge": int(sent4.max()) + 1}
    for nm, sid in (("sent", sent), ("sent_nl", sent_nl), ("sent2", sent2), ("sent4", sent4)):
        uniq = np.unique(sid)
        c2["ok_" + nm] = bool(sid.shape == (n_tok,) and uniq.size == sid.max() + 1
                              and np.array_equal(uniq, np.arange(sid.max() + 1))
                              and np.bincount(sid).min() >= 1)
        assert c2["ok_" + nm], "文 ID の連続性 NG: " + nm
    # C2: 窓またぎ検証（同一文 ID が 2 つ以上の窓に現れないこと）
    no_cross = True
    seen = set()
    for w in range(nw):
        sw = set(np.unique(sent[w * n_eval:(w + 1) * n_eval]).tolist())
        if sw & seen:
            no_cross = False
        seen |= sw
    c2["no_cross_window"] = bool(no_cross)
    assert no_cross, "文が窓をまたいでいる"

    log("[2/8] load model")
    t0 = time.time()
    from transformers import AutoModelForCausalLM, AutoTokenizer
    AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    d_model = int(model.config.hidden_size)
    full_k = int(model.config.num_experts_per_tok)
    assert full_k == 8 and int(model.config.num_hidden_layers) == N_LAYERS
    gates = [l.mlp.gate for l in model.model.layers]
    gate_fwd = [g.forward for g in gates]
    log("      %.0f s" % (time.time() - t0))

    STATE = {"kmat": None}

    def make_masked(orig, li):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            km = STATE["kmat"]
            if km is not None and scores.shape[-1] == full_k:
                kk = km[li]
                if kk.numel() == scores.shape[0]:
                    ar = torch.arange(scores.shape[-1], device=scores.device, dtype=torch.float32)
                    scores = scores * (ar[None, :] < kk[:, None]).to(scores.dtype)
            return logits, scores, idx
        return _patched

    for i, g in enumerate(gates):
        g.forward = make_masked(gate_fwd[i], i)

    CAP = {"on": False, "g": None, "h": None}

    def gate_hook(li):
        def fn(module, inp, out):
            if CAP["on"]:
                CAP["g"][li] = out[0].detach().float().cpu()
        return fn

    def mlp_hook(s):
        def fn(module, inp, out):
            if CAP["on"]:
                CAP["h"][s] = inp[0].detach().float().cpu()[0]
        return fn

    handles = [g.register_forward_hook(gate_hook(i)) for i, g in enumerate(gates)]
    handles += [model.model.layers[s].mlp.register_forward_hook(mlp_hook(s)) for s in H_STRATA]
    Rs = {s: torch.from_numpy(randproj(d_model, 256, seed=100 + s)) for s in H_STRATA}

    seqs = []
    for lg, ids in zip(("en", "ja"), ids_all):
        for w in range(n_win):
            seqs.append((lg, torch.from_numpy(ids[w * ln:(w + 1) * ln])))
    assert len(seqs) == nw

    def run_eval(name, native_topks=None, capture=False, kmat_windows=None):
        t1 = time.time()
        if kmat_windows is not None:
            for g in gates:
                g.top_k = full_k
        else:
            STATE["kmat"] = None
            tk = full_k if native_topks is None else native_topks
            for i, g in enumerate(gates):
                g.top_k = int(tk[i] if not np.isscalar(tk) else tk)
        nll_c, a1_c = [], []
        capG = [None] * N_LAYERS
        capH = {s: None for s in H_STRATA}
        ent_c, in_c = [], []
        G_big = np.zeros((N_LAYERS, n_tok, 64), dtype=np.float32) if capture else None
        H_big = np.zeros((len(H_STRATA), n_tok, 256), dtype=np.float32) if capture else None
        CAP["on"] = capture
        CAP["g"], CAP["h"] = capG, capH
        with torch.no_grad():
            for wi, (lg, ids) in enumerate(seqs):
                if kmat_windows is not None:
                    STATE["kmat"] = torch.from_numpy(
                        kmat_windows[:, wi * ln:(wi + 1) * ln].astype(np.float32)
                    ).to(model.device)
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                logit = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(logit, tgt, reduction="none")
                true_l = logit.gather(1, tgt.unsqueeze(-1))
                a1_c.append(((logit > true_l).sum(-1) == 0).float().cpu().numpy())
                nll_c.append(nll.cpu().numpy())
                if capture:
                    p = torch.softmax(logit, dim=-1)
                    ent_c.append(-(p * torch.log(p + 1e-12)).sum(-1).cpu().numpy())
                    in_c.append(x[0, :-1].cpu().numpy())
                    sl = slice(wi * n_eval, (wi + 1) * n_eval)
                    for i in range(N_LAYERS):
                        G_big[i, sl] = capG[i].numpy()[:n_eval]
                    for si, s in enumerate(H_STRATA):
                        H_big[si, sl] = capH[s].numpy()[:n_eval] @ Rs[s].numpy()
                del out, logit
        STATE["kmat"] = None
        CAP["on"] = False
        nll = np.concatenate(nll_c).astype(np.float32)
        a1 = np.concatenate(a1_c).astype(np.float32)
        log("      %-18s CE %.5f  top1 %.4f  (%.0f s)"
            % (name, nll.mean(), a1.mean(), time.time() - t1))
        r = {"nll": nll, "acc1": a1}
        if capture:
            r.update({"G": G_big, "H": H_big, "ent": np.concatenate(ent_c),
                      "in_ids": np.concatenate(in_c)})
        return r

    log("[3/8] calibration forwards")
    res = {}
    r = run_eval("base_rep", native_topks=[full_k] * N_LAYERS, capture=True)
    cap = r
    res["base_rep"] = {k: v for k, v in r.items() if k in ("nll", "acc1")}
    r = run_eval("u7_rep", native_topks=[7] * N_LAYERS)
    res["u7_rep"] = {k: v for k, v in r.items() if k in ("nll", "acc1")}

    # ---- 文集約 prefill 特徴 S（124 列）----
    log("[4/8] sentence features / probes")
    G_big, H_big = cap["G"], cap["H"]
    nll_b = res["base_rep"]["nll"].astype(np.float64)
    ent = cap["ent"].astype(np.float64)
    a1 = res["base_rep"]["acc1"].astype(np.float64)
    cnt = np.bincount(sent, minlength=n_sent).astype(np.float64)
    S_cols = []
    for L in range(N_LAYERS):
        gs = gate_stats(G_big[L]).astype(np.float64)      # (n_tok, 7)
        S_cols.append(np.stack([np.bincount(sent, weights=gs[:, j], minlength=n_sent) / cnt
                                for j in range(7)], axis=1))
    S_gstat = np.concatenate(S_cols, axis=1)              # (n_sent, 112)
    S_stat = []
    for j in range(n_sent):
        m = (sent == j)
        nb, eb, ab = nll_b[m], ent[m], a1[m]
        S_stat.append([nb.mean(), nb.std(), np.percentile(nb, 90), nb.max(), np.median(nb),
                       eb.mean(), eb.std(), ab.mean(), ab.std(),
                       float(np.abs(np.diff(nb)).mean()) if nb.size > 1 else 0.0])
    S_stat = np.array(S_stat)
    S_pos = np.stack([np.arange(n_sent) % max(1, stats["en"]["n_sent"]),
                      np.repeat([0.0, 1.0], [stats["en"]["n_sent"], stats["ja"]["n_sent"]])],
                     axis=1) if n_sent == stats["en"]["n_sent"] + stats["ja"]["n_sent"] else \
        np.stack([np.arange(n_sent) % max(1, n_sent // 2), np.zeros(n_sent)], axis=1)
    S = np.concatenate([S_gstat, S_stat, S_pos], axis=1)
    assert S.shape[1] == 124, S.shape
    log("      S %s" % (S.shape,))

    Y_sent = unit_targets(c8, c7, sent, n_sent)
    pred_sent = ridge_loo(S, Y_sent)
    q_sent = {"r2": 1.0 - float(((Y_sent - pred_sent) ** 2).sum()
                                / ((Y_sent - Y_sent.mean(0)) ** 2).sum()),
              "rho": [spearman(Y_sent[:, j], pred_sent[:, j]) for j in range(32)]}

    # C6: 100 回 permutation の帰無分布（64→32 統計量の最大値）
    rng = np.random.RandomState(PERM_SEED)
    null = []
    for it in range(NPERM):
        p = rng.permutation(n_sent)
        Yp = Y_sent[p]
        pr = ridge_loo(S, Yp)
        null.append(max(abs(spearman(Yp[:, j], pr[:, j])) for j in range(32)))
        if (it + 1) % 25 == 0:
            log("      perm %d/%d" % (it + 1, NPERM))
    null = np.array(null)
    obs_perm = max(abs(spearman(Y_sent[:, j], pred_sent[:, j])) for j in range(32))
    p95_null = float(np.percentile(null, 95))
    c6 = {"n_perm": NPERM, "null_mean": float(null.mean()),
          "null_p95": p95_null, "null_max": float(null.max()),
          "observed": float(obs_perm), "pass": bool(obs_perm < p95_null)}

    # ---- 決定 ----
    log("[5/8] decisions")
    cut_s, prot_s = unit_decision(Y_sent)
    Y_nl = unit_targets(c8, c7, sent_nl, n_sent_nl)
    cut_nl, prot_nl = unit_decision(Y_nl)
    n2, n4 = int(sent2.max()) + 1, int(sent4.max()) + 1
    Y2 = unit_targets(c8, c7, sent2, n2)
    Y4 = unit_targets(c8, c7, sent4, n4)
    cut2, prot2 = unit_decision(Y2)
    cut4, prot4 = unit_decision(Y4)
    rng_r = np.random.RandomState(RAND_SEED)
    cut_r = rng_r.randint(0, N_LAYERS, size=n_sent).astype(np.int8)
    draw = rng_r.randint(0, N_LAYERS - 1, size=n_sent)
    prot_r = (draw + (draw >= cut_r)).astype(np.int8)
    cut_p, prot_p = unit_decision(pred_sent)

    def km_of(sid, cut, prot):
        return to_windows(kmat_from_units(sid, cut, prot, n_tok), nw, n_eval, ln, 7)

    arms = [
        ("sent_oracle", km_of(sent, cut_s, prot_s)),
        ("sent_random", km_of(sent, cut_r, prot_r)),
        ("sent_probe", km_of(sent, cut_p, prot_p)),
        ("sent2_oracle", km_of(sent2, cut2, prot2)),
        ("sent4_oracle", km_of(sent4, cut4, prot4)),
        ("sent_nl_oracle", km_of(sent_nl, cut_nl, prot_nl)),
    ]
    for nm, km in arms:
        log("      %-18s mean_k %.6f" % (nm, km.mean()))

    log("[6/8] forward arms")
    for nm, km in arms:
        r = run_eval(nm, kmat_windows=km)
        res[nm] = {k: v for k, v in r.items() if k in ("nll", "acc1")}

    # ---- 統計 ----
    log("[7/8] stats / calibration")
    N = {k: v["nll"].astype(np.float64) for k, v in res.items()}
    u7 = N["u7_rep"]
    for k, v in res.items():
        assert v["nll"].shape == (n_tok,) and np.isfinite(v["nll"]).all()
    d_v1 = win_oracle_ax3 - N["sent_oracle"]      # G_sent - G_win
    d_v2 = u7 - N["sent_oracle"]                  # G_sent
    d_v3 = tok_oracle_ax3 - N["sent_oracle"]      # G_sent - G_tok
    st1, st2, st3 = paired(d_v1, nw, n_eval), paired(d_v2, nw, n_eval), paired(d_v3, nw, n_eval)
    ph = holm({"V1": st1["p_two"], "V2": st2["p_two"], "V3": st3["p_two"]})
    rej = {k: bool(ph[k] < ALPHA) for k in ph}
    m1 = st1["mean"]
    if not rej["V2"]:
        case = "D"
    elif rej["V1"] and m1 > 0:
        case = "A"
    elif rej["V1"] and m1 < 0:
        case = "C"
    else:
        case = "B"

    calib = {}
    c1 = {"base_maxdiff": float(np.abs(N["base_rep"] - base_ax3).max()),
          "u7_maxdiff": float(np.abs(N["u7_rep"] - u7_ax3).max())}
    if args.smoke:
        c1["tier"] = "SKIP"
        c1["reason"] = "smoke は en 3 + ja 3 で AX3 先頭 1530 トークン（en 6 窓）と並ばない"
    else:
        c1["tier"] = "A" if c1["base_maxdiff"] == 0.0 and c1["u7_maxdiff"] == 0.0 else "FAIL"
    calib["C1"] = c1
    calib["C2"] = c2
    mean_k = {"base_rep": 8.0, "u7_rep": 7.0}
    for nm, km in arms:
        mean_k[nm] = float(km.mean())
    calib["C3"] = {"mean_k": mean_k, "n_bad": int(sum(abs(v - 7.0) > 1e-9
                                                      for k, v in mean_k.items() if k not in ("base_rep",)))}
    calib["C4"] = {"uniform": "u7_rep", "random": "sent_random", "oracle": "sent_oracle",
                   "random_le_oracle": bool((u7 - N["sent_random"]).mean()
                                            <= (u7 - N["sent_oracle"]).mean())}
    conflicts = {}
    for nm, cut, prot in (("sent", cut_s, prot_s), ("nl", cut_nl, prot_nl),
                          ("2merge", cut2, prot2), ("4merge", cut4, prot4),
                          ("probe", cut_p, prot_p)):
        conflicts[nm] = int((cut == prot).sum())
    calib["C5"] = {"conflicts": conflicts,
                   "cut_hist": np.bincount(cut_s, minlength=N_LAYERS).tolist(),
                   "prot_hist": np.bincount(prot_s, minlength=N_LAYERS).tolist()}
    calib["C6"] = c6

    # 粒度カーブ（探索的）
    gains = {"sent_oracle": paired(u7 - N["sent_oracle"], nw, n_eval),
             "sent_random": paired(u7 - N["sent_random"], nw, n_eval),
             "sent_probe": paired(u7 - N["sent_probe"], nw, n_eval),
             "sent2_oracle": paired(u7 - N["sent2_oracle"], nw, n_eval),
             "sent4_oracle": paired(u7 - N["sent4_oracle"], nw, n_eval),
             "sent_nl_oracle": paired(u7 - N["sent_nl_oracle"], nw, n_eval),
             "win_oracle_ax3": paired(u7_ax3 - win_oracle_ax3, nw, n_eval),
             "tok_oracle_ax3": paired(u7_ax3 - tok_oracle_ax3, nw, n_eval),
             "win_mlp_ax3": paired(u7_ax3 - win_mlp_ax3, nw, n_eval)}
    curve = {"window_48": gains["win_oracle_ax3"]["mean"],
             "sent4_85": gains["sent4_oracle"]["mean"],
             "sent2_170": gains["sent2_oracle"]["mean"],
             "sent_340": gains["sent_oracle"]["mean"],
             "sent_nl_630": gains["sent_nl_oracle"]["mean"],
             "per_token_12240": gains["tok_oracle_ax3"]["mean"]}
    out = {
        "meta": {"tag": tag, "smoke": bool(args.smoke), "windows": nw, "len": ln,
                 "n_tok": int(n_tok), "n_arms": len(res),
                 "design": "AX4課題設計書_実際の文境界でのoracle上限と粒度の効果_20261111.md"},
        "confirmatory": {"V1_sent_minus_win": st1, "V2_sent": st2,
                         "V3_sent_minus_tok": st3, "holm": ph,
                         "reject": rej, "case": case},
        "calib": calib, "probe_quality": q_sent,
        "exploratory": {"gains": gains, "granularity_curve": curve,
                        "top1_abs_share_V1": st1["top1_abs_share"],
                        "top1_abs_share_V2": st2["top1_abs_share"]},
        "results": {k: {"ce": float(v["nll"].mean()),
                        "delta_vs_u7": float((v["nll"].astype(np.float64) - u7).mean()),
                        "top1": float(v["acc1"].mean()), "mean_k": mean_k.get(k)}
                    for k, v in res.items()},
    }
    log("[8/8] save")
    with open(os.path.join(HERE, "%s_sentence_bound.json" % tag), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    np.savez_compressed(
        os.path.join(HERE, "%s_sentence_bound.npz" % tag),
        **{("nll_" + k): v["nll"] for k, v in res.items()},
        **{("acc1_" + k): v["acc1"] for k, v in res.items()},
        c8=c8, c7=c7, sent=sent, sent_nl=sent_nl, sent2=sent2, sent4=sent4,
        S=S, Y_sent=Y_sent, pred_sent=pred_sent, lang=lang,
        cut_s=cut_s, prot_s=prot_s, cut_p=cut_p, prot_p=prot_p,
        cut_r=cut_r, prot_r=prot_r, cut2=cut2, prot2=prot2,
        cut4=cut4, prot4=prot4, cut_nl=cut_nl, prot_nl=prot_nl)
    log("")
    log("== confirmatory (Holm m=3, alpha=%.2f) ==" % ALPHA)
    log("V1 G_sent - G_win %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
        % (m1, st1["t"], st1["p_two"], ph["V1"], st1["mde"]))
    log("V2 G_sent        %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
        % (st2["mean"], st2["t"], st2["p_two"], ph["V2"], st2["mde"]))
    log("V3 G_sent - G_tok %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
        % (st3["mean"], st3["t"], st3["p_two"], ph["V3"], st3["mde"]))
    log("case = %s" % case)
    log("granularity curve: " + "  ".join("%s %+.5f" % (k, v) for k, v in curve.items()))
    log("calib: C1 %s  C3 bad %d  C4 %s  C6 %s"
        % (c1["tier"], calib["C3"]["n_bad"], calib["C4"]["random_le_oracle"], c6["pass"]))
    log("saved: %s_sentence_bound.npz / .json" % tag)
    TEE.close()
    os._exit(0)


if __name__ == "__main__":
    main()
