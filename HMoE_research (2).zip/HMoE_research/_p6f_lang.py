import numpy as np, math
z = np.load("p6k_head_proj.npz", allow_pickle=True)
lang = z["lang"]; n = z["base_nll"].size
tok_lang = np.repeat(lang, n // lang.size)      # トークン単位の言語ラベル
print("n=%d  en=%d ja=%d" % (n, (tok_lang=="en").sum(), (tok_lang=="ja").sum()))
def t(a):
    a = np.asarray(a, float); se = a.std(ddof=1)/math.sqrt(a.size)
    return a.mean(), se, a.mean()/se
print("=== coherence の言語別（E[dl]/E|dl|） ===")
print("%-9s %-4s %10s %10s %8s %8s" % ("cond","lang","E[dl]","E|dl|","coh","t"))
for c in ["f6b8","f6b8_rs","f8b6","f8b6_rs"]:
    d = z["%s_dlogit" % c].astype(float)
    for u in ("en","ja"):
        dd = d[tok_lang==u]; mm,se,tt = t(dd)
        print("%-9s %-4s %+10.4f %10.4f %+8.3f %+8.2f" % (c,u,dd.mean(),np.abs(dd).mean(),dd.mean()/np.abs(dd).mean(),tt))
print()
print("=== Δ(f8b6 - f6b8) の言語別 ===")
for k in ("dlogit","a1","q10","dh_norm","ptop1"):
    d = z["f8b6_%s" % k].astype(float) - z["f6b8_%s" % k].astype(float)
    for u in ("en","ja"):
        mm,se,tt = t(d[tok_lang==u])
        print("  %-8s %-3s Δ=%+10.5f (t=%+7.2f)" % (k,u,mm,tt))