#!/usr/bin/env python3
"""K1g: 16 epoch での「等計算量」と「1.15 倍」のギャップを測り直す。

動機
  逆向き蒸留の考察で「dense256 → HMoE のギャップ 0.0723」を分解したが、その 0.0723 は
  **6 epoch / 6 スレッド（P13）**の値で、等計算量の対応点は dense161 だった。
  ところが **16 epoch では教師の実測幅が 160.9 → 188.1 に増える**（k1c_results_e16.json）。
  したがって
    (a) K1e の dense161 は「等計算量」ではなく **6% 少ない**点だった（MACs 431,104 vs 458,752）
    (b) 16 epoch の等計算量点は dense188 である
    (c) dense256 は教師の **1.152 倍**（1.226 倍ではない）
  この 3 点を測り直さないと、0.050〜0.072 の外挿は潰せない。

やること
  教師は K1e の ckpt（`ckpt_teacher_s*_e16.pt`）を**読むだけ**（再訓練しない）。
  各 seed で 2 本の dense を 16 epoch 訓練する:
    - W = round(W_teacher)  … 厳密な等計算量（ΔW=0 の対照）
    - W = 256               … 1.152 倍（dense256 → HMoE のギャップ）
  同一評価系列（seed 777, 2048 本）で per-sequence の対応差を取る。
  訓練条件は K1/K1e と同一（3000 系列, bs 32, lr 2e-3, 1 スレッド, 同一 seed・同一データ順）。

検算
  読み込んだ教師の CE が `k1c_results_e16.json` の `ce_t` と一致するかを seed ごとに出す
  （一致しなければ reload が忠実でない＝以下の比較は無効）。

出力: k1g_results_<tag>.json / k1g_ce_seq_<tag>.npz / k1g_out_utf8_<tag>.txt
"""
import argparse
import json
import os
import sys
import time
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

D_MODEL, N_LAYERS, N_EXP = 128, 4, 8
W256 = 256


def macs(W):
    """P13 と同じ会計（E=8 固定）。W=97/180/256 で 365,568 / 450,560 / 528,384 を再現。"""
    return N_LAYERS * (4 * D_MODEL * D_MODEL + 2 * D_MODEL * W + D_MODEL * N_EXP)


def log_path(tag):
    suf = ("_" + tag) if tag else ""
    return os.path.join(HERE, "k1g_out_utf8%s.txt" % suf)


def worker(job):
    seed, seqs, epochs, n_eval, tag = job
    import numpy as np
    import torch
    from p13c_retrain import (E2DIR, WIDTHS, RewriteMoE, make_batch, run_cond,
                              train_dense)

    torch.set_num_threads(1)
    t0 = time.time()
    outdir = os.path.join(E2DIR, "data", "k1")

    # --- 教師を ckpt から復元 ---
    tm = RewriteMoE(WIDTHS["H+LB"], seed=seed)
    path = os.path.join(outdir, "ckpt_teacher_s%d_e16.pt" % seed)
    sd = torch.load(path, map_location="cpu")
    for k, v in tm.params().items():
        v.data.copy_(sd[k])

    ev = np.random.default_rng(777)
    src, out, em, _ = make_batch(ev, n_eval)
    rt = run_cond(tm, src, out, em, None, 2)
    ce_t = np.array(rt["ce_seq"], dtype=np.float64)
    w_t = float(rt["width"])

    # --- dense を 2 本 ---
    w_match = int(round(w_t))
    targets = [("matched", w_match), ("w256", W256)]
    res = {"seed": seed, "ce_t": float(rt["ce_all"]), "w_teacher": w_t,
           "macs_t": macs(w_t), "ce_copy_t": rt["ce_copy"], "ce_edit_t": rt["ce_edit"],
           "widths": {}}
    seqs_out = {"teacher:s%d" % seed: ce_t}
    for key, w in targets:
        dm = train_dense(w, seed, seqs, epochs, 32, 2e-3)
        rs = run_cond(dm, src, out, em, None, 1)
        ce_s = np.array(rs["ce_seq"], dtype=np.float64)
        d = ce_s - ce_t
        se = float(d.std(ddof=1) / np.sqrt(len(d)))
        res["widths"][key] = {
            "w": w, "ce_s": float(rs["ce_all"]),
            "ce_copy_s": rs["ce_copy"], "ce_edit_s": rs["ce_edit"],
            "macs_s": macs(w), "macs_ratio": macs(w) / macs(w_t),
            "delta": float(d.mean()), "se_seq": se,
            "t_seq": float(d.mean() / se) if se > 0 else float("nan"),
            "n_neg_seq": int((d < 0).sum()), "n_eval": len(d),
        }
        seqs_out["dense%d:s%d" % (w, seed)] = ce_s
        torch.save({k: v.detach() for k, v in dm.params().items()},
                   os.path.join(outdir, "ckpt_dense%d_s%d_%s.pt" % (w, seed, tag or "k1g")))

    res["sec"] = round(time.time() - t0, 1)
    return res, seqs_out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=list(range(10)))
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=16)
    ap.add_argument("--n_eval", type=int, default=2048)
    ap.add_argument("--tag", type=str, default="e16w")
    args = ap.parse_args()

    suf = ("_" + args.tag) if args.tag else ""
    LOG = log_path(args.tag)
    if os.path.exists(LOG):
        os.remove(LOG)

    def log(msg):
        print(msg, flush=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")

    log("K1g: 16 epoch の等計算量点と 1.15 倍点を測り直す（教師は ckpt から復元）")
    log("seeds=%s workers=%d seqs=%d epochs=%d n_eval=%d tag=%s"
        % (args.seeds, args.workers, args.seqs, args.epochs, args.n_eval, suf))
    log("MACs 会計: 4·(4·128² + 2·128·W + 128·8) → W=97/180/256 で 365,568 / 450,560 / 528,384")
    log("")

    ref = json.load(open(os.path.join(HERE, "k1c_results_e16.json"), encoding="utf-8"))
    ref_t = {r["seed"]: r["ce_t"] for r in ref["rows"]}

    t0 = time.time()
    jobs = [(s, args.seqs, args.epochs, args.n_eval, args.tag) for s in args.seeds]
    rows, seqs_all = [], {}
    part = os.path.join(HERE, "k1g_partial%s.json" % suf)
    with Pool(processes=args.workers) as pool:
        for r, sq in pool.imap_unordered(worker, jobs):
            rows.append(r)
            seqs_all.update(sq)
            log("  s%-2d  W_t %5.1f  CE_t %.4f (K1e %.4f, 差 %+.4f)  %s  (%.0fs)"
                % (r["seed"], r["w_teacher"], r["ce_t"], ref_t.get(r["seed"], float("nan")),
                   r["ce_t"] - ref_t.get(r["seed"], r["ce_t"]),
                   "  ".join("W%d: CE %.4f Δ %+.4f" % (v["w"], v["ce_s"], v["delta"])
                             for v in r["widths"].values()),
                   r["sec"]))
            with open(part, "w", encoding="utf-8") as f:
                json.dump({"rows": rows}, f, ensure_ascii=False, indent=2, default=float)
    rows.sort(key=lambda r: r["seed"])

    import numpy as np
    log("")
    log("== 検算: 復元した教師が K1e と一致するか ==")
    diffs = np.array([r["ce_t"] - ref_t[r["seed"]] for r in rows if r["seed"] in ref_t])
    log("  CE_t の差: 平均 %+.5f  SD %.5f  最大 %.5f（n=%d）"
        % (diffs.mean(), diffs.std(ddof=1) if len(diffs) > 1 else 0.0,
           np.abs(diffs).max(), len(diffs)))
    log("  → |差| < 1e-4 なら reload は忠実（以下の比較は有効）")

    keys = [k for k in ("matched", "w256") if any(k in r["widths"] for r in rows)]
    agg = {}
    log("")
    log("== 集計（n=%d, epochs=%d） ==" % (len(rows), args.epochs))
    for k in keys:
        d = np.array([r["widths"][k]["delta"] for r in rows if k in r["widths"]])
        n = len(d)
        if n < 2:
            log("  %-7s n=%d では se が出ない（スキップ）" % (k, n))
            continue
        se = float(d.std(ddof=1) / np.sqrt(n))
        coef = {2: 5.36, 5: 3.49}.get(n - 1, 2.95 if n < 12 else 2.85)
        sel = [r for r in rows if k in r["widths"]]
        ce_s = np.array([r["widths"][k]["ce_s"] for r in sel])
        ce_t = np.array([r["ce_t"] for r in sel])
        ratio = np.array([r["widths"][k]["macs_ratio"] for r in sel])
        ws = np.array([r["widths"][k]["w"] for r in sel], dtype=float)
        agg[k] = {"delta_mean": float(d.mean()), "median": float(np.median(d)),
                  "sd": float(d.std(ddof=1)), "se": se,
                  "t": float(d.mean() / se), "n": n, "mde": coef * se,
                  "n_neg": int((d < 0).sum()),
                  "ce_s_mean": float(ce_s.mean()), "ce_t_mean": float(ce_t.mean()),
                  "w_mean": float(ws.mean()),
                  "macs_ratio_mean": float(ratio.mean()),
                  "macs_ratio_min": float(ratio.min()), "macs_ratio_max": float(ratio.max()),
                  "per_seed": d.tolist()}
        log("  %-7s W %5.1f  MACs 比 %.3f (%.3f〜%.3f)  CE_s %.4f / CE_t %.4f  Δ %+.4f  "
            "中央値 %+.4f  se %.4f  t %+.2f  %d/%d 負  MDE %.4f"
            % (k, ws.mean(), ratio.mean(), ratio.min(), ratio.max(),
               ce_s.mean(), ce_t.mean(), d.mean(), np.median(d), se, d.mean() / se,
               int((d < 0).sum()), n, coef * se))

    log("")
    log("== 6 epoch（P13）との対比 ==")
    log("  P13: dense256 − HMoE = 0.3676 − 0.4399 = +0.0723（MAC 比 1.226, 6ep/6t, 教師幅 160.9）")
    log("  ここ: w256（MAC 比 ~1.15, 16ep/1t, 教師幅 ~188）")
    log("  注: プロトコルが違う（6 スレッド vs 1 スレッド）ので絶対 CE は直接比べない。")
    log("      **同じ表の w256 − matched の差**が、16 epoch での「1.15 倍の代金」である。")
    log("      matched が 0 と区別できなければ、アーキテクチャ差はゼロ（K1e の再確認）。")

    out = {"rows": rows, "epochs": args.epochs, "agg": agg,
           "calib": {"ce_t_diff_mean": float(diffs.mean()),
                     "ce_t_diff_absmax": float(np.abs(diffs).max()), "n": len(diffs)},
           "args": vars(args)}
    with open(os.path.join(HERE, "k1g_results%s.json" % suf), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2, default=float)
    np.savez_compressed(os.path.join(HERE, "k1g_ce_seq%s.npz" % suf),
                        **{k: v.astype(np.float32) for k, v in seqs_all.items()})
    log("")
    log("[write] k1g_results%s.json / k1g_ce_seq%s.npz  壁時計 %.0f 分"
        % (suf, suf, (time.time() - t0) / 60))
    os._exit(0)


if __name__ == "__main__":
    main()
