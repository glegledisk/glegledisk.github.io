# -*- coding: utf-8 -*-
"""P14 解析: best-of-N / 多数決の較正劣化の検定（測定は p14_bestofn.py）

問い（修復可能性考察 §4-4 の予測, 未検証）:
  「N 個から argmax で選ぶと p は上がる。正解率の上昇より p の上昇が大きく、
   較正ギャップが広がる（質量欠落と同型の選択バイアス）。」

検定設計:
  対照 = 1 サンプル（sample#1）/ 選択器 = conf-max（N=2,4,8）
        ＋ 多数決（vote share と代表トークン確信度の両方）/ oracle（上限）
  同一 (round, problem) で対応差を取り、scipy.stats.ttest_1samp(Δ, 0) で検定する。
  解答レベル AUROC は bootstrap CI（2000 回、seed 固定）。
単位: (round, problem)。2 ラウンド × 20 問 = 40 ペア。greedy のみ 20 問。
"""

import argparse
import json
import os
import re
from collections import Counter

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))


def log(m):
    print(m, flush=True)


def load(tag="p14"):
    samples_recs, greedy = [], []
    with open(os.path.join(HERE, "%s_bestofn.jsonl" % tag), encoding="utf-8") as fp:
        for line in fp:
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            if r.get("round") == "greedy":
                greedy.append(r)
            else:
                samples_recs.append(r)
    return samples_recs, greedy


def auroc(scores, labels):
    s = np.asarray(scores, float)
    y = np.asarray(labels, bool)
    ok = np.isfinite(s)
    s, y = s[ok], y[ok]
    pos, neg = s[y], s[~y]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    d = (pos[:, None] > neg[None, :]).sum() + 0.5 * (pos[:, None] == neg[None, :]).sum()
    return float(d / (len(pos) * len(neg)))


def auroc_ci(scores, labels, n_boot=2000, seed=0):
    rng = np.random.default_rng(seed)
    s = np.asarray(scores, float)
    y = np.asarray(labels, bool)
    ok = np.isfinite(s)
    s, y = s[ok], y[ok]
    vals = []
    for _ in range(n_boot):
        idx = rng.integers(0, len(s), len(s))   # 同じ index で s と y を一緒に引く
        #                    （旧実装は別々に引き直していて CI が壊れていた）
        vals.append(auroc(s[idx], y[idx]))
    return (float(np.nanpercentile(vals, 2.5)),
            float(np.nanpercentile(vals, 97.5)),
            int(len(np.asarray(scores, float)) - ok.sum()))   # 除外数


def confmax_sample(sub, N):
    """first N から p_ans 最大のサンプル（同点は先頭）。無効は除く。"""
    cand = [(j, s) for j, s in enumerate(sub[:N])
            if s["p_ans"] is not None and s["pred"] is not None]
    if not cand:
        return None
    return max(cand, key=lambda t: (t[1]["p_ans"], -t[0]))[1]


def majority_result(sub, N):
    """多数決: 得票数最大。同点は「同点票の中で最も p_ans の高い回答」で切る。
    戻り値: {"pred", "share"(=cnt/名目N), "rep_conf"(=当該回答の票の中で p_ans 最大値)}。"""
    cand = [s for s in sub[:N] if s["p_ans"] is not None and s["pred"] is not None]
    if not cand:
        return None
    by_pred = {}
    for s in cand:
        by_pred.setdefault(s["pred"], []).append(s)
    best = None
    for pred, lst in by_pred.items():
        key = (len(lst), max(x["p_ans"] for x in lst))
        if best is None or key > best[0]:
            best = (key, pred, lst)
    _, pred, lst = best
    rep = max(lst, key=lambda s: s["p_ans"])
    return {"pred": pred, "share": len(lst) / float(N), "rep_conf": rep["p_ans"]}


def paired(arr):
    a = np.asarray(arr, float)
    assert np.all(np.isfinite(a)), "nan in paired input"
    mean = float(np.mean(a))
    se = float(np.std(a, ddof=1) / np.sqrt(len(a)))
    if len(a) > 1 and np.std(a, ddof=1) > 0:
        t, p = stats.ttest_1samp(a, 0.0)
        mde = float(2.802 * np.std(a, ddof=1) / np.sqrt(len(a)))   # 80% power MDE
    else:
        t, p, mde = float("nan"), float("nan"), float("nan")
    return {"mean": mean, "se": se, "t": float(t), "p": float(p),
            "n": int(len(a)), "mde80": mde}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="p14")
    args = ap.parse_args()

    recs, greedy = load(args.tag)

    # ---- 検査 ----
    rounds = sorted(set(r["round"] for r in recs))
    n_prob = len({r["q"] for r in recs if r["round"] == 0})
    assert len(recs) == len(rounds) * n_prob, len(recs)
    assert all(len(r["samples"]) == 8 for r in recs)
    n_valid = sum(1 for r in recs for s in r["samples"] if s["p_ans"] is not None)
    n_total = len(recs) * 8
    invalid_rate = 1.0 - n_valid / float(n_total)
    assert invalid_rate < 0.10, "invalid rate too high: %.3f" % invalid_rate
    for r in recs:                     # gold の独立再計算（q 文字列から）
        m = re.match(r"Compute (\d+) \+ (\d+)\.", r["q"])
        assert m and str(int(m.group(1)) + int(m.group(2))) == r["gold"], r["q"]
    assert len(greedy) == n_prob, len(greedy)
    assert all(g["p_ans"] is not None and g["correct"] is not None for g in greedy)
    log("check ok: rounds=%s n_prob=%d valid_rate=%.4f (%d/%d) greedy=%d"
        % (rounds, n_prob, 1 - invalid_rate, n_valid, n_total, len(greedy)))

    # ---- 検査 2: 再トークン化の忠実度と生成の再現性 ----
    n_retok_bad = (sum(1 for r in recs for s in r["samples"] if s.get("retok") is False)
                   + sum(1 for g in greedy if g.get("retok") is False))
    log("retok mismatch (decode→re-encode が生成列と不一致): %d / %d"
        % (n_retok_bad, n_total + len(greedy)))
    arch = os.path.join(HERE, "_p14_bestofn_offbyone_20261029.jsonl")
    det_desc = "archived offbyone run not found; determinism check skipped"
    if os.path.exists(arch):
        arch_map, arch_greedy = {}, {}
        with open(arch, encoding="utf-8") as fp:
            for line in fp:
                ra = json.loads(line)
                if ra.get("round") == "greedy":
                    arch_greedy[ra["q"]] = ra["pred"]
                else:
                    arch_map[(ra["round"], ra["q"])] = [s["pred"] for s in ra["samples"]]
        n_same = sum(1 for r in recs
                     if (r["round"], r["q"]) in arch_map
                     and [s["pred"] for s in r["samples"]] == arch_map[(r["round"], r["q"])])
        g_same = sum(1 for g in greedy if arch_greedy.get(g["q"]) == g["pred"])
        det_desc = ("sampling determinism vs offbyone run (同一seed): recs identical=%d/%d, greedy identical=%d/%d"
                    % (n_same, len(recs), g_same, len(greedy)))
        log(det_desc)
    else:
        log(det_desc)

    P, R = n_prob, len(rounds)
    N_GRID = (2, 4, 8)

    # ---- 規則ごとの (acc, conf) 配列を張る ----
    acc = {"s1": np.full((R, P), np.nan), "confmax": {N: np.full((R, P), np.nan) for N in N_GRID},
           "maj": {N: np.full((R, P), np.nan) for N in N_GRID},
           "oracle": {N: np.full((R, P), np.nan) for N in N_GRID}}
    conf = {"s1": np.full((R, P), np.nan), "confmax": {N: np.full((R, P), np.nan) for N in N_GRID},
            "maj": {N: np.full((R, P), np.nan) for N in N_GRID}}
    maj_rep = np.full((R, P), np.nan)

    for ri, ri_idx in [(ri, k) for k, ri in enumerate(rounds)]:
        rec0 = [r for r in recs if r["round"] == ri]
        for i in range(P):
            r = rec0[i]
            sub = r["samples"]
            s1 = sub[0]
            assert s1["p_ans"] is not None and s1["pred"] is not None, (r["q"], s1)
            acc["s1"][ri_idx, i] = s1["correct"]
            conf["s1"][ri_idx, i] = s1["p_ans"]
            for N in N_GRID:
                cm = confmax_sample(sub, N)
                assert cm is not None, (r["q"], N)
                acc["confmax"][N][ri_idx, i] = float(cm["pred"] == r["gold"])
                conf["confmax"][N][ri_idx, i] = cm["p_ans"]
                mj = majority_result(sub, N)
                assert mj is not None, (r["q"], N)
                acc["maj"][N][ri_idx, i] = float(mj["pred"] == r["gold"])
                conf["maj"][N][ri_idx, i] = mj["share"]
                if N == 8:
                    maj_rep[ri_idx, i] = mj["rep_conf"]
                acc["oracle"][N][ri_idx, i] = float(any(s["correct"] for s in sub[:N]))

    def flat(a):
        return a.reshape(-1)

    # ---- 表 1: 規則 × N の (acc, conf, gap) ----
    # 注意: s1 は (R,P) 配列そのもの（旧実装は acc["s1"][1] と書いて round1 行だけを
    # 集計していた → 表1 の s1 行が n=20 になっていた）。
    def add_row(rule, N, a_, c_):
        a_ = np.asarray(a_, float)
        ok = np.isfinite(a_)
        row = {"rule": rule, "N": N, "n": int(ok.sum()),
               "acc": float(np.mean(a_[ok])),
               "conf": None, "lp": None, "gap": None}
        if c_ is not None:
            c_ = np.asarray(c_, float)[ok]
            row["conf"] = float(np.mean(c_))
            row["lp"] = float(np.mean(np.log(np.clip(c_, 1e-300, 1.0))))
            row["gap"] = row["conf"] - row["acc"]
        rows.append(row)
        return row

    rows = []
    add_row("s1", 1, acc["s1"], conf["s1"])
    for N in N_GRID:
        add_row("confmax", N, acc["confmax"][N], conf["confmax"][N])
        add_row("maj", N, acc["maj"][N], conf["maj"][N])
    for N in N_GRID:
        add_row("oracle", N, acc["oracle"][N], None)
    g_acc = np.array([g["correct"] for g in greedy], float)
    g_conf = np.array([g["p_ans"] for g in greedy], float)
    greedy_row = add_row("greedy", 1, g_acc, g_conf)

    log("\n[表1] rule x N (conf: s1/confmax/greedy=p_ans, maj=vote share(名目N分母); lp=平均 ln p_ans/トークン)")
    for r_ in rows:
        log("  %-8s N=%-2s n=%-3d acc=%.4f conf=%s lp=%s gap=%s"
            % (r_["rule"], r_["N"], r_["n"], r_["acc"],
               "   -  " if r_["conf"] is None else "%.4f" % r_["conf"],
               "   -  " if r_["lp"] is None else "%+.3f" % r_["lp"],
               "   -  " if r_["gap"] is None else "%+.4f" % r_["gap"]))

    # ---- 検算: N=8 多数決の正解率を独立な Counter 経路で数え直す ----
    mj_ok = mj_bad = mj_tie = 0
    for ri_idx, ri in enumerate(rounds):
        rec0 = [r for r in recs if r["round"] == ri]
        for i in range(P):
            votes = Counter([s["pred"] for s in rec0[i]["samples"]
                             if s["pred"] is not None])
            if not votes:
                continue
            top, cnt = votes.most_common(1)[0]
            if sum(1 for v in votes.values() if v == cnt) > 1:
                mj_tie += 1           # 同点は tie-break の差と比較しない
                continue
            base = float(top == rec0[i]["gold"])
            if base == acc["maj"][8][ri_idx, i]:
                mj_ok += 1
            else:
                mj_bad += 1
    log("majority N=8 recount (非同点のみ): agree=%d disagree=%d tie=%d"
        % (mj_ok, mj_bad, mj_tie))
    assert mj_bad == 0, "independent recount of majority N=8 disagrees"

    # ---- 表 2: 対応差の検定（pooled R*P ペア）----
    s1_acc, s1_conf = flat(acc["s1"]), flat(conf["s1"])
    tests = []

    def add_test(name, a2, c2, a1, c1):
        d_conf = np.asarray(c2, float) - np.asarray(c1, float)
        d_acc = np.asarray(a2, float) - np.asarray(a1, float)
        d_gap = d_conf - d_acc
        a2i = np.asarray(a2).astype(bool)
        a1i = np.asarray(a1).astype(bool)
        w10 = int(np.sum(a2i & ~a1i))     # rule のみ正解
        w01 = int(np.sum(~a2i & a1i))     # s1 のみ正解
        mc_p = (float(stats.binomtest(w10, w10 + w01, 0.5).pvalue)
                if (w10 + w01) > 0 else float("nan"))
        tests.append({"name": name, "conf": paired(d_conf), "acc": paired(d_acc),
                      "gap": paired(d_gap),
                      "mcnemar": {"w_rule": w10, "w_base": w01, "p": mc_p}})

    for N in N_GRID:
        add_test("confmax%d - s1" % N, flat(acc["confmax"][N]), flat(conf["confmax"][N]),
                 s1_acc, s1_conf)
    # 多数決 vs s1: (i) conf=得票率（N=1 で構成上 1.0 になるので構成依存 — P8 §4 の注意）
    add_test("maj8 - s1 (share)", flat(acc["maj"][8]), flat(conf["maj"][8]),
             s1_acc, np.ones_like(s1_conf))
    # (ii) conf=代表トークン確信度（多数決回答の中で最良サンプルの p_ans）
    add_test("maj8 - s1 (rep tok conf)", flat(acc["maj"][8]), maj_rep.reshape(-1),
             s1_acc, s1_conf)

    # 検算: dGap 恒等式（dConf − dAcc == dGap の平均）を確認
    for t_ in tests:
        assert abs(t_["gap"]["mean"] - (t_["conf"]["mean"] - t_["acc"]["mean"])) < 1e-9, \
            t_["name"]

    log("\n[表2] paired diffs (n=%d)" % (R * P))
    for t_ in tests:
        mc = t_["mcnemar"]
        log("  %-26s dConf=%+.4f (se %+.4f, t=%+.2f, p=%.4g) | dAcc=%+.4f (t=%+.2f, McN %d/%d p=%.4g) | dGap=%+.4f (t=%+.2f, p=%.4g, MDE80 %.4f)"
            % (t_["name"], t_["conf"]["mean"], t_["conf"]["se"], t_["conf"]["t"],
               t_["conf"]["p"], t_["acc"]["mean"], t_["acc"]["t"],
               mc["w_rule"], mc["w_base"], mc["p"],
               t_["gap"]["mean"], t_["gap"]["t"], t_["gap"]["p"], t_["gap"]["mde80"]))

    # ---- 表 3: 解答レベル AUROC ----
    log("\n[表3] answer-level AUROC (bootstrap 2000, seed 0)")
    aurocs = []

    def one_auc(name, s_, y_):
        lo, hi, n_excl = auroc_ci(s_, y_)
        a_ = auroc(s_, y_)
        s_f = np.asarray(s_, float)[np.isfinite(np.asarray(s_, float))]
        aurocs.append({"name": name, "auc": a_, "ci": [lo, hi],
                       "n_excluded": n_excl,
                       "n_pos": int(np.sum(np.asarray(y_, bool))),
                       "n_neg": int(len(s_f) - int(np.sum(np.asarray(y_, bool)))),
                       "n_unique": int(len(set(s_f.tolist())))})
        log("  %-26s AUC=%.3f [%.3f, %.3f] (excluded=%d, pos=%d neg=%d uniq=%d)"
            % (name, a_, lo, hi, n_excl,
               aurocs[-1]["n_pos"], aurocs[-1]["n_neg"], aurocs[-1]["n_unique"]))

    one_auc("sample1 p_ans", s1_conf, s1_acc)
    for N in N_GRID:
        one_auc("confmax%d p_ans" % N, flat(conf["confmax"][N]), flat(acc["confmax"][N]))
    one_auc("maj8 vote share", flat(conf["maj"][8]), flat(acc["maj"][8]))
    one_auc("maj8 rep tok conf", maj_rep.reshape(-1), flat(acc["maj"][8]))
    one_auc("greedy p_ans", g_conf, g_acc)

    # ---- ブロック4: 単調変換で水準は動かせ、順序と選択は不変（P10/P11 型の確認）----
    # 注意: p_ans が 0.9999+ に飽和するため logit-based の写像は fp32/clip で全 Saturation
    # して失敗した（旧実装は argmax 不変=False と誤報）。冪写像 c^3 は float64 で飽和しない。
    c8, a8 = flat(conf["confmax"][8]), flat(acc["confmax"][8]).astype(bool)
    c8w = c8 ** 3.0                                          # 単調増加写像（飽和なし）
    same_agg = (c8w >= np.max(c8w)) == (c8 == np.max(c8))
    auc_before, auc_after = auroc(c8, a8), auroc(c8w, a8)
    assert abs(auc_before - auc_after) < 1e-9, "AUC changed under monotone map"
    gap_before = float(np.mean(c8) - np.mean(a8.astype(float)))
    gap_after = float(np.mean(c8w) - np.mean(a8.astype(float)))
    log("\n[ブロック4] 冪写像 c→c^3: argmax 不変=%s / AUC %.4f -> %.4f（不変の確認） / gap %+.4f -> %+.4f（水準は写像で動く）"
        % (bool(np.all(same_agg)), auc_before, auc_after, gap_before, gap_after))

    # ---- ブロック5: P9 形式の再現表（新規ランダム描画のためビット一致は求めない）----
    log("\n[ブロック5] P9-style table (fresh draws)")
    sub_rng = np.random.default_rng(11)
    p9_rows = []
    for N in N_GRID:
        p1_l, pn_l, maj_l, sh_l = [], [], [], []
        for ri in rounds:
            rec0 = [r for r in recs if r["round"] == ri]
            for i in range(P):
                sub = rec0[i]["samples"]
                use = sub if N == max(N_GRID) else \
                    [sub[j] for j in sub_rng.choice(len(sub), N, replace=False)]
                corr = [bool(s["correct"]) for s in use]
                p1_l.append(corr[0])
                pn_l.append(any(corr))
                votes = Counter([s["pred"] for s in use if s["pred"] is not None])
                if votes:
                    top, cnt = votes.most_common(1)[0]
                    maj_l.append(top == rec0[i]["gold"])
                    sh_l.append(cnt / float(N))
                else:
                    maj_l.append(False)
                    sh_l.append(0.0)
        p9_rows.append({"N": N, "pass@1": float(np.mean(p1_l)), "pass@N": float(np.mean(pn_l)),
                        "majority": float(np.mean(maj_l)), "share": float(np.mean(sh_l))})
        log("  N=%d pass@1=%.3f pass@N=%.3f majority=%.3f share=%.3f"
            % (N, np.mean(p1_l), np.mean(pn_l), np.mean(maj_l), np.mean(sh_l)))

    # ---- 検算: greedy argmax-slack（採点位置規約が正しければ ≈0）----
    slacks = [g.get("slack") for g in greedy if g.get("slack") is not None]
    slack_desc = None
    if slacks:
        slack_desc = {"mean": float(np.mean(slacks)), "max": float(np.max(slacks)),
                      "n": len(slacks)}
        log("\n[検算] greedy argmax-slack: mean=%.6f max=%.6f (n=%d, ≈0 が正しい規約の証拠)"
            % (slack_desc["mean"], slack_desc["max"], len(slacks)))
        assert np.mean(slacks) < 0.05, \
            "greedy argmax-slack too large — scoring position convention suspect"

    summary = {"n_prob": P, "rounds": rounds, "n_pairs": R * P,
               "invalid_rate": float(invalid_rate),
               "n_retok_mismatch": n_retok_bad,
               "determinism": det_desc,
               "slack": slack_desc,
               "table1": rows, "greedy": greedy_row, "tests": tests,
               "aurocs": aurocs,
               "monotone": {"argmax_unchanged": bool(np.all(same_agg)),
                            "auc_before": auc_before, "auc_after": auc_after,
                            "gap_before": gap_before, "gap_after": gap_after},
               "p9_style": p9_rows}
    with open(os.path.join(HERE, "%s_analysis.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    log("saved: %s_analysis.json" % args.tag)
    os._exit(0)


if __name__ == "__main__":
    main()
