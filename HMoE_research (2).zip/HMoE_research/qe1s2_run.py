# -*- coding: utf-8 -*-
"""QE1S2 Step 2 本番: 生成則 v2 で 3 検定を 13 seed・収束後に走らせる.

設計書: `QE1S2課題設計書_初期型を系列一様にしてaの境界効果を除き3検定を収束後に走らせる_20261114.md`
        §1〜§7 / §9、Step 1 報告 `検証報告_QE1S2S1_..._20261114.md`

既存 `corpus_common.run_model` は `make_corpus` を直呼びし eval も 1 バッチのみなので、
本次は**既存モジュールを書き換えず**に `run_v2` を本ファイルへ実装する。
  - train / eval コーパスは `qe1_make_task.make_task(init_type="uniform")` の生成則 v2。
  - eval は設計書 §4 の 3 バッチ（gate = seed+3000 / 主 = 2000 / ロバストネス = 2001）。
  - 方策ごとに forward をやり直し、系列別 `ce_copy` を保存（T3 の top1_abs_share 用）。
  - 学習ループ・収束判定・`w_chosen` は `corpus_common.run_model` と同一定義を踏襲。

走行前に固定した 3 検定の estimand（設計書 §3 を数式どおり実装。n = 13, paired）
  T1 K2 回帰 : d_s = R2(X_full -> w_chosen)_s - R2(X_base -> w_chosen)_s (seed 単位 LOO)
               主指標 mean_s d_s、帰無 mean d = 0。ttest_rel(r2_full, r2_base)
  T2 幅ラダー: d_s = rho_s = Spearman(WIDTH_LADDER, ce_copy_s(W))、主指標 mean_s rho_s
               帰無 mean rho = 0。ttest_rel(rho, zeros)
  T3 頻度集計: d_s = top1_abs_share_s(zipf) - top1_abs_share_s(uniform)
               主指標 median_s top1_abs_share_s(zipf) を記述併記、帰無「一様頻度と同帯」
               ttest_rel(share_zipf, share_uniform)
  Holm m = 3、両側 α = 0.05、`MDE = t.ppf(0.975,12) * se`、90% CI を必須併記。
  **`corpus_common.MDE_FACTOR = 3.0545`（α=0.01 用）は流用しない**。

構成（1 seed あたり 6 run_model 相当。走行前に代数的最適化を固定）
  A: WIDTH_LADDER / zipf    -> T1 (w_chosen, meta) + T2@W=224 + T3-zipf + 3 点対照 + 本体 eta2_edit
  B: WIDTH_LADDER / uniform -> T3-uniform
  C..F: ladder_widths(32/64/96/160) / zipf -> T2 の残り 4 点
  （ladder_widths(224) == WIDTH_LADDER なので A と共有。estimand・数値は不変）

出力: qe1s2_metrics.json / qe1s2_delta.npz / qe1s2.log（すべて UTF-8、allow_nan=False）
"""
from __future__ import annotations

import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F
from scipy import stats

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "不均一MoE-Corpus"))

import corpus_common as CC                       # noqa: E402
from corpus_common import (BATCHES_PER_EPOCH, BATCH, CHUNK, CONV_RANGE_MAX,  # noqa: E402
                           CONV_SLOPE_MAX, COPY_WINDOW, EPOCHS, EVAL_SEED_BASE,
                           LR, N_EVAL_SEQ, N_TRAIN_SEQ, N_TYPES, POLICIES,
                           SEEDS, SEQ_LEN, TAIL_K, TOP1_CONTRIB_LIMIT,
                           TRAIN_SEED_BASE, V_IDENT, VOCAB, WIDTH_LADDER,
                           holm, r2_loo, sample_batch, zipf_cdf)
from corpus_a_content import build_features     # noqa: E402
from corpus_t_width import ladder_widths        # noqa: E402
from qe1_make_task import (EDIT_RULES, EPS_EDIT, EPS_EDIT_MI, EPS_POS,  # noqa: E402
                           INIT_SEED_BASE, N_CALIB_SEQ, POS_BINS, SYNTAX_RATE,
                           SYNTAX_PER_TYPE, calibrate, eta2_categorical,
                           joint_table, make_task, mi_over_entropy, pos_bins,
                           r2_group)

TAG = "qe1s2"
ALPHA = 0.05
MDE_T = float(stats.t.ppf(0.975, len(SEEDS) - 1))   # 2.1788
CI90_T = float(stats.t.ppf(0.95, len(SEEDS) - 1))
CE_ALL_LIMIT = math.log(VOCAB)                      # ln(12288) = 9.4141
IV_GATE_MIN = 0.10
GATE_SEED_BASE = 3000                              # 設計書 §4: eval gate = seed + 3000
ROBUST_SEED_BASE = EVAL_SEED_BASE + 1              # 2001
N_EVAL_BATCH = BATCH                               # 16 系列（P1 の BATCH を継承）
EVAL_CHUNK = CHUNK                                 # 64
TOP1_Q = 0.01
INIT_MODE = "uniform"                              # 生成則 v2（Step 1 C7 合格）
FREQS = ("zipf", "uniform")
CONFIGS = (("A_zipf", WIDTH_LADDER, "zipf"),
           ("B_uniform", WIDTH_LADDER, "uniform"),
           ("C_w32", ladder_widths(32), "zipf"),
           ("D_w64", ladder_widths(64), "zipf"),
           ("E_w96", ladder_widths(96), "zipf"),
           ("F_w160", ladder_widths(160), "zipf"))
assert tuple(ladder_widths(WIDTH_LADDER[-1])) == tuple(WIDTH_LADDER), \
    "ladder_widths(224) must equal WIDTH_LADDER for config sharing"


def _corpus(seed, freq, base, task_kwargs=None):
    task_kwargs = {} if task_kwargs is None else dict(task_kwargs)
    return make_task(seed, N_EVAL_SEQ, base=base, freq=freq,
                     init_type=INIT_MODE, **task_kwargs)


def run_v2(seed, widths, freq, device, task_kwargs=None):
    """corpus_common.run_model と同一の学習＋3 eval バッチ×4 方策。生成則 v2 を載せる。"""
    task_kwargs = {} if task_kwargs is None else dict(task_kwargs)
    torch.set_num_threads(1)
    torch.manual_seed(TRAIN_SEED_BASE + int(seed))
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(TRAIN_SEED_BASE + int(seed))
    rng = np.random.default_rng(TRAIN_SEED_BASE + int(seed))
    train = make_task(seed, N_TRAIN_SEQ, base=TRAIN_SEED_BASE,
                      freq=freq, init_type=INIT_MODE, **task_kwargs)

    model = CC.TinyMoE(widths).to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=LR)
    hist = {"ce_copy": [], "instr_valid": [], "ce_all": []}
    model.train()
    for _ in range(EPOCHS):
        ep = {k: [] for k in hist}
        for _ in range(BATCHES_PER_EPOCH):
            x, y, cm, ty, _ = sample_batch(train, rng, BATCH, CHUNK)
            x, y, cm, ty = (v.to(device, non_blocking=True) for v in (x, y, cm, ty))
            logits, _, _ = model(x, policy="soft", types=ty, rng=rng)
            loss_all = F.cross_entropy(
                logits.reshape(-1, VOCAB), y.reshape(-1), reduction="none").view(y.shape)
            m = cm.reshape(-1)
            ce_copy = loss_all.reshape(-1)[m].mean() if bool(m.any()) else loss_all.mean()
            instr = ((logits.argmax(-1) == y) & cm).float().sum() / cm.float().sum().clamp(min=1.0)
            loss = loss_all.mean()
            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()
            ep["ce_copy"].append(float(ce_copy.detach().cpu()))
            ep["instr_valid"].append(float(instr.detach().cpu()))
            ep["ce_all"].append(float(loss.detach().cpu()))
        for k in hist:
            hist[k].append(float(np.mean(ep[k])))

    # ---- 収束（corpus_common.run_model と同一。除外はしない）
    tail = np.asarray(hist["instr_valid"][-min(TAIL_K, len(hist["instr_valid"])):],
                      dtype=np.float64)
    if tail.size >= 2:
        slope = float(np.polyfit(np.arange(tail.size), tail, 1)[0])
    else:
        slope = 0.0
    rng_val = float(tail.max() - tail.min()) if tail.size else 0.0
    T_plus = bool(abs(slope) <= CONV_SLOPE_MAX and rng_val <= CONV_RANGE_MAX)
    k = min(TAIL_K, len(hist["ce_copy"]))
    summary = {
        "ce_copy": float(np.median(hist["ce_copy"][-k:])),
        "instr_valid": float(np.median(hist["instr_valid"][-k:])),
        "ce_all": float(np.median(hist["ce_all"][-k:])),
        "converged": T_plus, "conv_slope": slope, "conv_range": rng_val,
    }

    # ---- 3 評価バッチ（設計書 §4）。方策ごとに forward をやり直す。
    evals = {}
    model.eval()
    with torch.no_grad():
        for role, base in (("gate", GATE_SEED_BASE), ("main", EVAL_SEED_BASE),
                           ("robust", ROBUST_SEED_BASE)):
            # gate の RNG seed を `seed + 3000` にするため base = 3000 を渡す
            c = _corpus(seed, freq, base, task_kwargs=task_kwargs)
            # corpus_common.run_model の eval と同じ初期状態から、コーパス base だけを
            # 変えて 3 バッチを引く（設計書 §4 の役割分離。過去の eval スライス順を維持）。
            erng = np.random.default_rng(TRAIN_SEED_BASE + int(seed))
            x, y, cm, ty, rk = sample_batch(c, erng, min(N_EVAL_BATCH, c.tokens.shape[0]),
                                            EVAL_CHUNK)
            x, y, cm, ty, rk = (v.to(device, non_blocking=True) for v in (x, y, cm, ty, rk))
            head_hi, tail_lo = CC._freq_bins(c)
            rank_np = rk.detach().cpu().numpy()
            head_m = torch.from_numpy(rank_np < head_hi).to(device) & cm
            tail_m = torch.from_numpy(rank_np >= tail_lo).to(device) & cm
            ty_np = ty.detach().cpu().numpy()
            per_pol = {}
            for pol in POLICIES + ("learned",):
                logits_p, idx, _ = model(x, policy=pol, types=ty,
                                         rng=np.random.default_rng(
                                             TRAIN_SEED_BASE + int(seed) + 977))
                loss_all = F.cross_entropy(
                    logits_p.reshape(-1, VOCAB), y.reshape(-1), reduction="none").view(y.shape)
                correct = (logits_p.argmax(-1) == y)
                idx_np = idx.detach().cpu().numpy()
                w_chosen = np.asarray(model.widths, dtype=np.float64)[idx_np]

                # 系列別 ce_copy（copy_mask 位置の CE 系列平均）。T3 の top1_abs_share 用。
                ce_tok = loss_all.detach().cpu().numpy()
                cm_np = cm.detach().cpu().numpy()
                with np.errstate(invalid="ignore"):
                    ce_seq = np.where(cm_np.sum(1) > 0,
                                      (ce_tok * cm_np).sum(1) / np.maximum(cm_np.sum(1), 1),
                                      np.nan)
                ce_seq = ce_seq[np.isfinite(ce_seq)]
                s_abs = np.sort(np.abs(ce_seq))[::-1]
                ktop = max(1, int(math.ceil(TOP1_Q * s_abs.size)))
                top1_abs_share = float(s_abs[:ktop].sum() / s_abs.sum()) if s_abs.sum() > 0 else 0.0

                # 空マスクは nan にせず全体平均へフォールバックする。
                # corpus_common.run_model の ce_copy と同じ規約で、C6 の allow_nan=False
                # 書込を保証する（補助指標なので estimand には使わない）。
                empty_masks = 0

                def _mean(mask):
                    nonlocal empty_masks
                    if bool(mask.any()):
                        return float(loss_all[mask].mean().cpu())
                    empty_masks += 1
                    return float(loss_all.mean().cpu())

                def _acc(mask):
                    nonlocal empty_masks
                    if bool(mask.any()):
                        return float(correct[mask].float().mean().cpu())
                    empty_masks += 1
                    return float(correct.float().mean().cpu())

                per_pol[pol] = {
                    "ce_copy": _mean(cm),
                    "ce_all": float(loss_all.mean().cpu()),
                    "instr_valid": _acc(cm),
                    "ce_copy_by_type": [_mean(cm & (ty == j)) for j in range(N_TYPES)],
                    "ce_copy_head": _mean(head_m), "ce_copy_tail": _mean(tail_m),
                    "ce_seq": ce_seq,
                    "ce_seq_median": float(np.median(ce_seq)) if ce_seq.size else float("nan"),
                    "top1_abs_share": top1_abs_share,
                    "n_eval_series": int(ce_seq.size),
                    "n_empty_masks": int(empty_masks),
                    "w_chosen": w_chosen,
                }
            evals[role] = {
                "per_policy": {p: {kk: vv for kk, vv in d.items()
                                   if kk not in ("ce_seq", "w_chosen")}
                               for p, d in per_pol.items()},
                "ce_seq_learned": per_pol["learned"]["ce_seq"],
                "top1_abs_share_learned": per_pol["learned"]["top1_abs_share"],
                "w_chosen_learned": per_pol["learned"]["w_chosen"],
                "meta": {
                    "pos": np.broadcast_to(np.arange(x.shape[1], dtype=np.float64), x.shape),
                    "type": ty_np, "rank": rank_np, "token": x.detach().cpu().numpy(),
                    "copy_mask": cm_np,
                    "pos_corr_eval": c.pos_corr,
                },
            }
    del model
    if device.startswith("cuda") and torch.cuda.is_available():
        torch.cuda.empty_cache()
    return {"hist": hist, "summary": summary, "T_plus": T_plus, "evals": evals,
            "widths": list(widths), "pos_corr_train": train.pos_corr}


def paired_stats(a, b, label):
    a = np.asarray(a, dtype=np.float64)
    b = np.asarray(b, dtype=np.float64)
    assert a.shape == b.shape, (label, a.shape, b.shape)
    n_nonfinite = int((~np.isfinite(a)).sum() + (~np.isfinite(b)).sum())
    d = a - b
    n = int(d.size)
    mean_d = float(np.nan_to_num(d.mean(), nan=0.0, posinf=0.0, neginf=0.0))
    se = float(d.std(ddof=1) / math.sqrt(n)) if n > 1 else float("nan")
    if n_nonfinite:
        se = float("nan")
    r = stats.ttest_rel(a, b)
    t, p = float(r.statistic), float(r.pvalue)
    # corpus_common.paired と同じ nan 規約。allow_nan=False 書込のため inf も畳み込む。
    note = ""
    t_infinite = False
    if not np.isfinite(t) or not np.isfinite(p):
        # corpus_common.paired と同じ規約: 分散ゼロでも差が非ゼロなら棄却。
        # ただし allow_nan=False 書込のため t は JSON null にして p=0.0 を残す。
        note = "ttest_rel nonfinite (zero variance); corpus_common.paired rule applied"
        if abs(mean_d) < 1e-15:
            t, p = 0.0, 1.0
        else:
            t, p, t_infinite = None, 0.0, True
            note += "; constant nonzero delta -> t=inf, p=0 (null t in JSON)"
    if not np.isfinite(se):
        se = 0.0
        note += "; se=0 (zero variance)"
    if n_nonfinite:
        note += f"; n_nonfinite_inputs={n_nonfinite} folded to 0 by prereg rule"
    d_fin = np.nan_to_num(d, nan=0.0, posinf=0.0, neginf=0.0)
    s = np.sort(np.abs(d_fin))[::-1]
    k = max(1, int(math.ceil(0.01 * n)))
    contrib = float(s[:k].sum() / s.sum()) if s.sum() > 0 else 0.0
    return {
        "label": label, "n": n, "delta": mean_d, "se": se, "t": t, "p": p,
        "t_infinite": t_infinite,
        "note": note, "n_nonfinite_inputs": n_nonfinite,
        "mde": float(MDE_T * se), "mde_factor": MDE_T,
        "ci90": [float(mean_d - CI90_T * se), float(mean_d + CI90_T * se)],
        "ci90_t": CI90_T, "d_per_seed": d_fin.tolist(),
        "median_abs_delta": float(np.median(np.abs(d_fin))),
        "max_abs_delta": float(s[0]) if s.size else 0.0,
        "top1_share": contrib,
        "mean_unreliable": bool(contrib >= TOP1_CONTRIB_LIMIT),
    }


def main() -> None:
    out = {
        "tag": TAG, "phase": "QE1S2 Step 2 (production)",
        "design": "QE1S2課題設計書_初期型を系列一様にしてaの境界効果を除き3検定を収束後に走らせる_20261114.md",
        "step1_gate": "PASS (検証報告_QE1S2S1_..._20261114.md, 67 items / 0 mismatch, C7 19.995x down)",
        "step1_note": "Step 1 は別 ID の別 estimand。本次の数値と「改善」として連結しない",
    }
    out["prereg"] = {
        "INIT_MODE": INIT_MODE, "INIT_SEED_BASE": INIT_SEED_BASE,
        "SEEDS": list(SEEDS), "EPOCHS": EPOCHS, "LR": LR, "BATCH": BATCH,
        "CHUNK": CHUNK, "BATCHES_PER_EPOCH": BATCHES_PER_EPOCH,
        "N_TRAIN_SEQ": N_TRAIN_SEQ, "N_EVAL_SEQ": N_EVAL_SEQ,
        "N_EVAL_BATCH": N_EVAL_BATCH, "EVAL_CHUNK": EVAL_CHUNK,
        "WIDTH_LADDER": list(WIDTH_LADDER), "VOCAB": VOCAB, "V_IDENT": V_IDENT,
        "SEQ_LEN": SEQ_LEN, "TAIL_K": TAIL_K,
        "CONV_SLOPE_MAX": CONV_SLOPE_MAX, "CONV_RANGE_MAX": CONV_RANGE_MAX,
        "TOP1_CONTRIB_LIMIT": TOP1_CONTRIB_LIMIT, "TOP1_Q": TOP1_Q,
        "GATE_SEED_BASE": GATE_SEED_BASE, "MAIN_SEED_BASE": EVAL_SEED_BASE,
        "ROBUST_SEED_BASE": ROBUST_SEED_BASE,
        "CE_ALL_LIMIT": CE_ALL_LIMIT, "IV_GATE_MIN": IV_GATE_MIN,
        "ALPHA": ALPHA, "MDE_T": MDE_T, "CI90_T": CI90_T, "HOLM_M": 3,
        "CONFIGS": [{"name": n, "widths": list(w), "freq": f} for n, w, f in CONFIGS],
        "n_runs": len(CONFIGS) * len(SEEDS),
        "estimands": {
            "T1_K2": "d_s = R2(X_full -> w_chosen)_s - R2(X_base -> w_chosen)_s (LOO), H0: mean d = 0",
            "T2_ladder": "d_s = Spearman(WIDTH_LADDER, ce_copy_s(W)), H0: mean rho = 0",
            "T3_freq": "d_s = top1_abs_share_s(zipf) - top1_abs_share_s(uniform), H0: uniform と同帯",
        },
        "test": "scipy.stats.ttest_rel, two-sided, alpha=0.05, Holm m=3",
        "mde_note": "MDE = t.ppf(0.975,12)*se = 2.1788*se. corpus_common.MDE_FACTOR(3.0545) は alpha=0.01 用なので流用禁止",
        "gate_rule": "T+ = |slope(tail5 instr_valid)| <= 0.005 and range <= 0.02; "
                     "E+ = iv_gate >= 0.10; E flag = ce_all > ln(VOCAB) or nonfinite or iv_gate in {0,1}",
        "exclusion_rule": "除外しない。E フラグ seed は主解析に残す。感度解析は事前登録の探索的のみ",
        "primary_metric_note": "ce_seq / ce_all の平均は主判定に置かない。上位 1% 寄与率が 0.50 超なら平均を主張に使わない",
        "eta2_edit_body": "学習後 w_chosen へ R2(pos x a) - R2(pos)。Step 1 の生成的代理 0.28928417 との比較は探索的",
        "sharing_note": "ladder_widths(224) == WIDTH_LADDER なので config A を T2@224 / T1 / T3-zipf で共有。estimand と数値は不変",
    }

    device = "cuda" if torch.cuda.is_available() else "cpu"
    out["device"] = device

    # ---- 走行前 C1 / C2 / C3 / C7（設計書 §6。C7 が通らなければケース C で 3 検定を起動しない）
    s1_metrics = json.loads((HERE / "qe1s2_s1_metrics.json").read_text(encoding="utf-8"))
    step1_proxy = float(s1_metrics["C3"]["step1_eta2"])          # 0.2892841697368182
    step1_c7 = float(s1_metrics["C7"]["v2_uniform"]["eta2_a_pos"])  # 9.5341e-05
    c = make_task(0, N_CALIB_SEQ, base=TRAIN_SEED_BASE, freq="zipf",
                  init_type=INIT_MODE)
    s1 = np.load(HERE / "qe1_s1_arrays.npz")
    c1 = {k: int(np.max(np.abs(np.asarray(getattr(c, k), dtype=np.int64)
                               - np.asarray(s1[k], dtype=np.int64))))
          for k in ("type_draw", "tokens", "is_syntax")}
    cal = calibrate(c, "typed_edit_v2_zipf")
    c7_eta2 = eta2_categorical(c.a, pos_bins(c.tokens.shape), POS_BINS, N_TYPES)
    t7 = joint_table(pos_bins(c.tokens.shape), c.a, POS_BINS, N_TYPES)
    c7_mi = mi_over_entropy(t7)
    pre = {
        "C1_type_draw_tokens_is_syntax_maxdiff_vs_step1": c1,
        "C1_pass": bool(max(c1.values()) == 0),
        "C2_eta2_type_pos": cal["C2_eta2_type_pos"],
        "C2_mi_type_pos_norm": cal["C2_mi_type_pos_norm"],
        "C2_pass": bool(cal["C2_eta2_type_pos"] < EPS_POS
                        and cal["C2_mi_type_pos_norm"] < EPS_POS),
        "C3_eta2_edit_given_pos": cal["C3_eta2_edit_given_pos"],
        "C3_mi_edit_norm": cal["C3_mi_edit_norm"],
        "C3_pass": bool(cal["C3_eta2_edit_given_pos"] > EPS_EDIT
                        and cal["C3_mi_edit_norm"] > EPS_EDIT_MI),
        "C7_eta2_a_pos": float(c7_eta2), "C7_mi_a_pos_norm": float(c7_mi),
        "C7_pass": bool(c7_eta2 < EPS_POS and c7_mi < EPS_POS),
        "step1_C7_eta2_a_pos_reference": step1_c7,
        "negative_control_eta2_edit": None,
    }
    from corpus_common import make_corpus as _old_make_corpus
    from qe1_make_task import QE1Corpus
    old = _old_make_corpus(0, N_CALIB_SEQ, base=TRAIN_SEED_BASE)
    ctr = QE1Corpus(tokens=old.tokens, types=old.types, next_tok=old.next_tok,
                    copy_mask=old.copy_mask, is_syntax=old.is_syntax,
                    ident_rank=old.ident_rank, pos_corr=old.pos_corr,
                    type_draw=old.types.astype(np.int8), a=old.types.astype(np.int8),
                    changed=(old.next_tok != old.tokens).astype(bool),
                    base=old.tokens.astype(np.int16))
    pre["negative_control_eta2_edit"] = calibrate(ctr, "corpus_common_make_corpus")[
        "C3_eta2_edit_given_pos"]
    pre["negative_control_ratio"] = float(
        cal["C3_eta2_edit_given_pos"] / max(pre["negative_control_eta2_edit"], 1e-300))
    out["pre_calibration"] = pre
    pre_all = bool(pre["C1_pass"] and pre["C2_pass"] and pre["C3_pass"] and pre["C7_pass"])
    if not pre_all:
        out["verdict"] = "CASE_C"
        out["case"] = ("設計書 §5 ケース C: 走行前 C1/C2/C3/C7 が不合格。"
                       "3 検定は起動せず課題設計が律速と報告")
        (HERE / f"{TAG}_metrics.json").write_text(
            json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
        (HERE / f"{TAG}.log").write_text("verdict=CASE_C\n", encoding="utf-8")
        sys.stdout.write("verdict=CASE_C (pre-calibration failed)\n")
        return

    # ---- 本番走行（in-process 順次。GPU は 1 つだけ保持）
    t0 = time.time()
    runs = {}
    for si, seed in enumerate(SEEDS):
        for name, widths, freq in CONFIGS:
            key = f"s{seed}_{name}"
            r = run_v2(seed, widths, freq, device)
            # npz へ入れる最小限だけ保持し、巨大的な配列は統計へ落とす
            m = r["evals"]["main"]
            g = r["evals"]["gate"]
            runs[key] = {
                "seed": seed, "config": name, "widths": list(widths), "freq": freq,
                "summary": r["summary"], "T_plus": r["T_plus"],
                "pos_corr_train": r["pos_corr_train"],
                "pos_corr_eval_main": m["meta"]["pos_corr_eval"],
                "main": {"top1_abs_share_learned": m["top1_abs_share_learned"],
                         "ce_seq_learned": m["ce_seq_learned"],
                         "per_policy": m["per_policy"]},
                "gate": {"per_policy": g["per_policy"]},
                "robust": {"per_policy": r["evals"]["robust"]["per_policy"]},
                "w_chosen_learned": m["w_chosen_learned"],
                "meta_main": {k: v for k, v in m["meta"].items() if k != "pos"},
            }
            sys.stdout.write(
                f"[{si*len(CONFIGS)+list(n for n,_,_ in CONFIGS).index(name)+1}/"
                f"{len(SEEDS)*len(CONFIGS)}] {key} ce_copy={r['summary']['ce_copy']:.4f} "
                f"iv={r['summary']['instr_valid']:.4f} T+={r['T_plus']} "
                f"({time.time()-t0:.0f}s)\n")
            sys.stdout.flush()
    out["runtime_seconds"] = float(time.time() - t0)

    # ---- 3 検定の seed 単位統計量
    # T1: K2 回帰（config A の主バッチ w_chosen / meta から build_features -> r2_loo）
    Xb, Xf, yb = [], [], []
    for s in SEEDS:
        r = runs[f"s{s}_A_zipf"]
        w = r["w_chosen_learned"]
        meta = {"pos": np.broadcast_to(np.arange(EVAL_CHUNK, dtype=np.float64),
                                       (N_EVAL_BATCH, EVAL_CHUNK)),
                **r["meta_main"]}
        xb, xf, _, _ = build_features(meta, w)
        Xb.append(xb)
        Xf.append(xf)
        yb.append(np.asarray(w, dtype=np.float64).ravel())
    r2_full = r2_loo(Xf, yb)
    r2_base = r2_loo(Xb, yb)
    t1 = paired_stats(r2_full, r2_base, "T1_K2_deltaR2")

    # T2: 幅ラダー Spearman（5 点。W=224 は config A を共有）
    ladder_keys = ("C_w32", "D_w64", "E_w96", "F_w160", "A_zipf")
    rho = []
    for s in SEEDS:
        ce = [runs[f"s{s}_{k}"]["main"]["per_policy"]["learned"]["ce_copy"]
              for k in ladder_keys]
        rho.append(float(np.nan_to_num(
            stats.spearmanr(WIDTH_LADDER, ce).statistic, nan=0.0)))
    t2 = paired_stats(np.asarray(rho), np.zeros(len(SEEDS)), "T2_ladder_rho")
    t2["rho_per_seed"] = rho
    t2["mean_ce_curve"] = [float(np.mean([
        runs[f"s{s}_{k}"]["main"]["per_policy"]["learned"]["ce_copy"] for s in SEEDS
    ])) for k in ladder_keys]

    # T3: 頻度集計（zipf vs uniform の top1_abs_share paired 差）
    sz = np.asarray([runs[f"s{s}_A_zipf"]["main"]["top1_abs_share_learned"] for s in SEEDS])
    su = np.asarray([runs[f"s{s}_B_uniform"]["main"]["top1_abs_share_learned"] for s in SEEDS])
    t3 = paired_stats(sz, su, "T3_freq_top1_abs_share")
    t3["median_top1_abs_share_zipf"] = float(np.median(sz))
    t3["median_top1_abs_share_uniform"] = float(np.median(su))
    t3["ce_seq_median_zipf"] = float(np.median([
        float(np.median(runs[f"s{s}_A_zipf"]["main"]["ce_seq_learned"])) for s in SEEDS]))

    pvals = np.nan_to_num(np.asarray([t1["p"], t2["p"], t3["p"]], dtype=np.float64),
                          nan=1.0, posinf=1.0, neginf=0.0)
    hp = holm(pvals)
    for st, ph in zip((t1, t2, t3), hp):
        st["holm_p"] = float(ph)
        st["reject"] = bool(ph < ALPHA and not st["mean_unreliable"])
    out["confirmatory"] = {
        "family": {"method": "Holm", "m": 3, "alpha": ALPHA,
                   "raw_p": pvals.tolist(), "holm_p": hp.tolist()},
        "T1_K2": t1, "T2_ladder": t2, "T3_freq": t3,
        "n_rejected": int(sum(st["reject"] for st in (t1, t2, t3))),
    }

    # ---- 本体 eta2_edit（探索的。学習済み w_chosen の分散分解）
    body = []
    for s in SEEDS:
        r = runs[f"s{s}_A_zipf"]
        w = np.asarray(r["w_chosen_learned"], dtype=np.float64)
        a = np.asarray(r["meta_main"]["type"], dtype=np.int64)
        pb = np.broadcast_to((np.arange(EVAL_CHUNK, dtype=np.int64) * POS_BINS // EVAL_CHUNK),
                             a.shape).astype(np.int64)
        codes = (pb * N_TYPES + a)
        body.append(float(r2_group(w, codes, POS_BINS * N_TYPES)
                          - r2_group(w, pb, POS_BINS)))
    out["exploratory"] = {
        "eta2_edit_body_per_seed": body,
        "eta2_edit_body_mean": float(np.mean(body)),
        "step1_generative_proxy_reference": step1_proxy,
        "note": "PC 定義の本体は学習済みルーティング質量の分散比。Step 1 の代理とは別 estimand",
    }

    # ---- eval 側ゲート（§4）: T± x E± の分類＋完全性。除外しない。
    cells = {(t, e): 0 for t in (True, False) for e in (True, False)}
    e_flags = {}
    c5_detail, c5_ok = {}, True
    for s in SEEDS:
        A = runs[f"s{s}_A_zipf"]
        iv_gate = A["gate"]["per_policy"]["learned"]["instr_valid"]
        ce_all = A["main"]["per_policy"]["learned"]["ce_all"]
        e_flag = bool((not np.isfinite(ce_all)) or ce_all > CE_ALL_LIMIT
                      or iv_gate in (0.0, 1.0))
        e_flags[s] = e_flag
        cells[(bool(A["T_plus"]), bool(iv_gate >= IV_GATE_MIN))] += 1
        pol = A["main"]["per_policy"]
        ok = bool(pol["random"]["instr_valid"] <= pol["oracle"]["instr_valid"])
        c5_ok &= ok
        c5_detail[f"s{s}"] = {"random": pol["random"]["instr_valid"],
                              "oracle": pol["oracle"]["instr_valid"], "pass": ok}
    classified = int(sum(cells.values()))
    out["eval_gate"] = {
        "grid": {f"T{'+' if t else '-'}E{'+' if e else '-'}": n
                 for (t, e), n in cells.items()},
        "classified_seeds": classified, "expected_seeds": len(SEEDS),
        "excluded_pairs": 0,
        "E_flag_seeds": [s for s in SEEDS if e_flags[s]],
        "T_plus_seeds": [s for s in SEEDS if runs[f"s{s}_A_zipf"]["T_plus"]],
        "non_converged_seeds": [s for s in SEEDS
                                if not runs[f"s{s}_A_zipf"]["T_plus"]],
        "rule": "除外しない。E フラグ seed は主解析に残す（設計書 §4）",
    }
    out["C5_three_point_control"] = {
        "per_seed": c5_detail, "all_pass": bool(c5_ok),
        "rule": "instr_valid(random) <= instr_valid(oracle) を全 seed で",
    }

    # ---- 感度解析（事前登録。E フラグ seed を除いた 3 検定再計算。主判定には使わない）
    keep = [i for i, s in enumerate(SEEDS) if not e_flags[s]]
    sens = {}
    if len(keep) >= 3:
        sens = {
            "T1_K2": paired_stats(r2_full[keep], r2_base[keep], "T1_sens"),
            "T2_ladder": paired_stats(np.asarray(rho)[keep], np.zeros(len(keep)), "T2_sens"),
            "T3_freq": paired_stats(sz[keep], su[keep], "T3_sens"),
        }
    out["sensitivity"] = {
        "kept_seeds": [SEEDS[i] for i in keep], "n_kept": len(keep),
        "results": sens,
        "rule": "探索的感度のみ。主判定は全 13 seed の confirmatory",
    }

    # ---- 校正 C4 / C6 とケース判定
    c4 = {"classification_complete": bool(classified == len(SEEDS)),
          "excluded_pairs": 0,
          "E_flag_arm_imbalance": int(sum(e_flags.values()))}
    c4["pass"] = bool(c4["classification_complete"] and c4["excluded_pairs"] == 0)
    checks = {
        "C1": pre["C1_pass"], "C2": pre["C2_pass"], "C3": pre["C3_pass"],
        "C4": c4["pass"], "C5": bool(c5_ok), "C7": pre["C7_pass"],
    }

    def scan(o, path="root"):
        bad = []
        if isinstance(o, dict):
            for k, v in o.items():
                bad += scan(v, f"{path}.{k}")
        elif isinstance(o, list):
            for j, v in enumerate(o):
                bad += scan(v, f"{path}[{j}]")
        elif isinstance(o, float) and not np.isfinite(o):
            bad.append(path)
        return bad
    nonfinite = scan(out)
    checks["C6"] = bool(len(nonfinite) == 0)
    out["calibration"] = {
        "pre": pre, "C4": c4, "C5": out["C5_three_point_control"],
        "C6": {"nonfinite_paths": nonfinite, "pass": bool(len(nonfinite) == 0)},
        "checks": checks,
    }

    n_rej = out["confirmatory"]["n_rejected"]
    # 設計書 §5 ケース C の条件は「C2 / C3 / C7 が通らない」に限定される。
    # C5（3 点対照）は §6 の校正記録であり、§5 に停止条件の記載が無いため
    # ケース判定には混ぜず warnings として残す（結果を見る前の走行前固定）。
    case_gates = {k: checks[k] for k in ("C1", "C2", "C3", "C4", "C6", "C7")}
    all_gates = all(case_gates.values())
    out["C5_warning"] = {
        "pass": checks["C5"],
        "rule": "設計書 §6 C5 = 校正記録。§5 ケース A〜D の判定には含めない",
        "note": ("random / oracle は学習済みルータとは別方策で同一 ckpt を再評価するため、"
                 "oracle が劣ることは起こりうる。3 点対照は下限・上限の記録であって"
                 "確認的家族の成立条件ではない（AGENTS.md §7-3）"),
    }
    if not all_gates:
        failed = [k for k, v in case_gates.items() if not v]
        case = (f"C: 走行前 / 走行後校正 {failed} が不合格。3 検定の結果は参考記録とし、"
                "課題設計または eval ゲートが律速と報告")
    elif n_rej >= 1:
        case = ("A: C2/C3/C7 合格かつ収束後に 3 検定の >= 1 が棄却。"
                "「データ側が律速」を支持するが 1 testbed・1 モデル・1 課題の結果として扱い、"
                "Q-E が解けたと確定知見にしない（設計書 §5 / §11）")
    else:
        case = ("B: 収束後も 3 検定すべて非棄却。地図 §3-5 の反証条件が発動。"
                "律速は課題設計か容量で、Q-E を「外部妥当性のハブ」と呼ぶのは誤り。"
                "「差が無い」とは書かず MDE と 90% CI を併記")
    if out["eval_gate"]["non_converged_seeds"]:
        case += (" ／ ケース D 候補: 未収束 seed あり。eval ゲート自体を疑う手掛かりとして"
                 "感度解析に記録（Z3 との直接比較は別ハーネスなので行わない）")
    out["case"] = case
    out["verdict"] = "PASS" if all_gates else "FAIL"

    # ---- 書き出し（重い配列は落とす）
    slim = {k: {"seed": v["seed"], "config": v["config"], "widths": v["widths"],
                "freq": v["freq"], "summary": v["summary"], "T_plus": v["T_plus"],
                "pos_corr_train": v["pos_corr_train"],
                "pos_corr_eval_main": v["pos_corr_eval_main"],
                "main": {kk: vv for kk, vv in v["main"].items()
                         if kk != "ce_seq_learned"},
                "gate": v["gate"], "robust": v["robust"],
                "w_chosen_shape": list(np.asarray(v["w_chosen_learned"]).shape)}
            for k, v in runs.items()}
    out["runs"] = slim
    (HERE / f"{TAG}_metrics.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False),
        encoding="utf-8")
    arrays = {
        "seeds": np.asarray(SEEDS),
        "r2_full": r2_full, "r2_base": r2_base, "dR2": r2_full - r2_base,
        "rho": np.asarray(rho),
        "top1_share_zipf": sz, "top1_share_uniform": su,
        "top1_share_diff": sz - su,
        "eta2_edit_body": np.asarray(body),
        "T_plus": np.asarray([runs[f"s{s}_A_zipf"]["T_plus"] for s in SEEDS]),
        "E_flag": np.asarray([e_flags[s] for s in SEEDS]),
    }
    # ce_seq は copy 可能系列数が run ごとに可変なので ragged にせず seed 別キーへ。
    for s in SEEDS:
        arrays[f"ce_seq_A_zipf_s{s}"] = np.asarray(
            runs[f"s{s}_A_zipf"]["main"]["ce_seq_learned"], dtype=np.float64)
    np.savez(HERE / f"{TAG}_delta.npz", **arrays)
    def ts(st):
        return "inf(null)" if st["t"] is None else f"{st['t']:.4f}"
    lines = [
        f"tag={TAG}", f"verdict={out['verdict']}", f"device={device}",
        f"runtime_seconds={out['runtime_seconds']:.1f}",
        f"n_runs={len(CONFIGS)*len(SEEDS)}",
        f"T1 dR2={t1['delta']:.8f} se={t1['se']:.8f} t={ts(t1)} "
        f"p={t1['p']:.6g} holm={t1['holm_p']:.6g} MDE={t1['mde']:.8f}",
        f"T2 rho={t2['delta']:.8f} se={t2['se']:.8f} t={ts(t2)} "
        f"p={t2['p']:.6g} holm={t2['holm_p']:.6g} MDE={t2['mde']:.8f}",
        f"T3 dtop1={t3['delta']:.8f} se={t3['se']:.8f} t={ts(t3)} "
        f"p={t3['p']:.6g} holm={t3['holm_p']:.6g} MDE={t3['mde']:.8f}",
        f"n_rejected={n_rej} grid={out['eval_gate']['grid']}",
        f"eta2_edit_body_mean={out['exploratory']['eta2_edit_body_mean']:.8f}",
        f"checks={checks} C5_warning_pass={checks['C5']}",
        f"case_gates={case_gates}", f"case={case}", "",
    ]
    (HERE / f"{TAG}.log").write_text("\n".join(lines), encoding="utf-8")
    sys.stdout.write("\n".join(lines))
    sys.stdout.flush()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        sys.stderr.write(f"[qe1s2_run] ERROR {type(exc).__name__}: {exc}\n")
        sys.stderr.flush()
        raise
    else:
        # AGENTS.md §6-4: CUDA 終了時ハングを避ける。書込は main() 内で完了済み。
        sys.stdout.flush()
        sys.stderr.flush()
        os._exit(0)
