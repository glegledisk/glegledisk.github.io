"""
P4c: トークンごとに k を変える（適応 k）の厳密測定

方式:
  ルータは常に top-8 を選び、**k_j を超えるスロットの重みを 0 にする**。
  重み 0 の Expert は出力に寄与しないので、品質は「k_j 個だけ使った」場合と厳密に一致する
  （計算は削れないが、品質の測定は正確。FLOPs は mean_k から解析的に出す）。

決定規則:
  uniform7 : 全トークン k=7（予算 mean_k=7 の基準）
  uniform6 : 全トークン k=6
  oracle50 : 真の d_j 上位 50% を k=8、残り k=6（予算 mean_k=7）
  probe50  : probe 予測の上位 50% を k=8、残り k=6（予算 mean_k=7）
  random50 : ランダム 50%（予算 mean_k=7）
  mask7    : 全トークン k=7 をマスク方式で実現（uniform7 と一致するはず＝実装検証）

実行:
  python p4c_adaptive_k.py --windows 24 --len 256
"""

import argparse
import json
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

from p3_topk_quality_olmoe import load_corpus

HERE = os.path.dirname(os.path.abspath(__file__))


def log(msg):
    print(msg, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--seed", type=int, default=11)
    ap.add_argument("--pred", type=str, default="probe_all", help="probe の予測キー")
    ap.add_argument("--pred-file", type=str, default="p4_preds.npz", help="予測の npz")
    ap.add_argument("--rules", type=str, default=None,
                    help="実行する規則をカンマ区切りで指定（既定は全部）")
    ap.add_argument("--ref-nll", type=str, default=None,
                    help="基準（均一 top-7）の per-token NLL を npz から読む。指定時は uniform7 を回さない")
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[1/5] loading")
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    n_layers = int(model.config.num_hidden_layers)
    full_k = int(model.config.num_experts_per_tok)
    gates = [layer.mlp.gate for layer in model.model.layers]

    # ---- トークンごとの k を差し込むパッチ（インスタンス forward を包む）----
    STATE = {"k": None}

    def _make_patched(orig):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            k = STATE["k"]
            if k is not None and scores.shape[-1] == full_k:
                kk = k.to(scores.device).to(torch.float32)
                if kk.numel() == scores.shape[0]:
                    ar = torch.arange(scores.shape[-1], device=scores.device, dtype=torch.float32)
                    mask = (ar[None, :] < kk[:, None]).to(scores.dtype)
                    scores = scores * mask
            return logits, scores, idx
        return _patched

    for g in gates:
        g.forward = _make_patched(g.forward)
    log("      patched %d gates (per-token k)" % len(gates))

    log("[2/5] corpus")
    rng = np.random.RandomState(args.seed)
    seqs, lang_of = [], []
    for lang in ("en", "ja"):
        txt = load_corpus(lang)
        ids = tok(txt, return_tensors="pt", add_special_tokens=False).input_ids[0]
        need = args.windows * args.len
        start = 0 if ids.numel() < need else int(rng.randint(0, ids.numel() - need))
        block = ids[start:start + need]
        for w in range(args.windows):
            seqs.append(block[w * args.len:(w + 1) * args.len])
            lang_of.append(lang)
        log("      %s: using [%d, %d)" % (lang, start, start + need))
    lang_arr = np.array(lang_of)
    n_win = len(seqs)

    log("[3/5] decisions")
    pr = np.load(os.path.join(HERE, args.pred_file))
    d_j = pr["d_j"]
    pred = pr[args.pred]
    assert d_j.size == n_win * (args.len - 1), "予測と窓数が合わない"
    # (n_win, len-1) に整形し、最後の位置は k=6 で埋める
    dmat = d_j.reshape(n_win, args.len - 1)
    pmat = pred.reshape(n_win, args.len - 1)

    def pad(mat, val):
        return np.concatenate([mat, np.full((n_win, 1), val)], axis=1)

    def topk_k(mat, f, lo=6, hi=8):
        """mat の上位 f を hi、残りを lo にした k 行列。"""
        out = np.full(mat.shape, lo, dtype=np.float32)
        m = int(round(f * mat.size))
        order = np.argsort(-mat.ravel())
        keep = np.zeros(mat.size, bool)
        keep[order[:m]] = True
        out.ravel()[keep] = hi
        return out

    rng2 = np.random.RandomState(7)
    decs = {}
    decs["uniform6"] = np.full((n_win, args.len), 6, dtype=np.float32)
    decs["uniform7"] = np.full((n_win, args.len), 7, dtype=np.float32)
    decs["mask7"] = np.full((n_win, args.len), 7, dtype=np.float32)
    decs["oracle50"] = pad(topk_k(dmat, 0.5), 6)
    decs["probe50"] = pad(topk_k(pmat, 0.5), 6)
    rand = rng2.rand(n_win, args.len - 1)
    decs["random50"] = pad(topk_k(rand, 0.5), 6)

    if args.rules:
        keep_rules = [s.strip() for s in args.rules.split(",") if s.strip()]
        if "uniform7" not in keep_rules and not args.ref_nll:
            keep_rules = ["uniform7"] + keep_rules
        decs = {k: v for k, v in decs.items() if k in keep_rules}

    for k, v in decs.items():
        log("      %-9s mean_k %.3f  (k=8 の割合 %.3f)" % (k, v.mean(), (v == 8).mean()))

    log("[4/5] forward")
    res = {}
    for name, kmat in decs.items():
        t0 = time.time()
        # uniform 系は本来の top_k 経路（マスクなし）で回す。mask7 と一致すれば実装検証になる。
        if name.startswith("uniform"):
            for g in gates:
                g.top_k = int(kmat[0, 0])
            STATE["k"] = None
        else:
            for g in gates:
                g.top_k = full_k
        nll_c, a1_c = [], []
        with torch.no_grad():
            for wi, ids in enumerate(seqs):
                if not name.startswith("uniform"):
                    STATE["k"] = torch.from_numpy(kmat[wi])
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                lg = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll_c.append(F.cross_entropy(lg, tgt, reduction="none").float().cpu().numpy())
                rank = (lg > lg.gather(1, tgt.unsqueeze(-1))).sum(dim=-1) + 1
                a1_c.append((rank == 1).float().cpu().numpy())
                del out, lg, rank
        STATE["k"] = None
        nll = np.concatenate(nll_c)
        a1 = np.concatenate(a1_c)
        res[name] = {"nll": nll, "acc1": a1, "mean_k": float(kmat.mean())}
        log("      %-9s CE %.5f  top1 %.4f  mean_k %.3f  (%.0f s)"
            % (name, nll.mean(), a1.mean(), kmat.mean(), time.time() - t0))

    log("[5/5] paired vs uniform7")
    if args.ref_nll:
        ref = np.load(os.path.join(HERE, args.ref_nll))
        base = ref["uniform7"]
        log("      reference loaded from %s (CE %.5f)" % (args.ref_nll, base.mean()))
    else:
        base = res["uniform7"]["nll"]
    out = {"pred": args.pred, "n_tokens": int(base.size), "results": {}}
    for name, r in res.items():
        d = r["nll"] - base
        se = d.std(ddof=1) / np.sqrt(d.size)
        out["results"][name] = {
            "ce": float(r["nll"].mean()), "ppl": float(np.exp(r["nll"].mean())),
            "top1": float(r["acc1"].mean()), "mean_k": r["mean_k"],
            "delta_vs_uniform7": float(d.mean()), "se": float(se),
            "t": float(d.mean() / se) if se > 0 else None,
        }
    log("")
    log("%-9s %6s %10s %10s %9s %8s" % ("rule", "mean_k", "CE", "dCE(u7)", "t", "top1"))
    for name in decs:
        r = out["results"][name]
        log("%-9s %6.3f %10.5f %+10.5f %9s %8.4f"
            % (name, r["mean_k"], r["ce"], r["delta_vs_uniform7"],
               ("%+.1f" % r["t"]) if r["t"] is not None else "", r["top1"]))

    tag = "".join(c if (c.isalnum() or c in "-_") else "_" for c in args.pred)[:40]
    with open(os.path.join(HERE, "p4_adaptive_results_%s.json" % tag), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    np.savez_compressed(os.path.join(HERE, "p4_adaptive_nll_%s.npz" % tag),
                        **{k: v["nll"] for k, v in res.items()}, lang=lang_arr)
    log("saved p4_adaptive_results_%s.json / p4_adaptive_nll_%s.npz" % (tag, tag))


if __name__ == "__main__":
    main()
