# -*- coding: utf-8 -*-
"""思考終端トークンの特定（使い捨て）"""
import json
import os

from transformers import AutoTokenizer

HERE = os.path.dirname(os.path.abspath(__file__))
tok = AutoTokenizer.from_pretrained(os.path.join(HERE, "models", "qwen3-0.6b"))

v = tok.get_vocab()
hits = [(t, i) for t, i in v.items() if "think" in t.lower()]
print("tokens containing 'think': %d" % len(hits))
for t, i in hits[:10]:
    print("  %r -> %d  special=%s  in_added=%s"
          % (t, i, t in tok.all_special_tokens,
             t in getattr(tok, "additional_special_tokens", [])))

if hits:
    tid = hits[0][1]
    print("\ndecode(skip_special_tokens=True) :", repr(tok.decode([tid], skip_special_tokens=True)))
    print("decode(skip_special_tokens=False):", repr(tok.decode([tid], skip_special_tokens=False)))

# テンプレートの該当部分
tpl = tok.chat_template or ""
for line in tpl.split("\n"):
    if "think" in line.lower():
        print("TPL:", line.strip()[:160])

print("\nall_special_tokens sample:", tok.all_special_tokens[:12])
print("eos:", tok.eos_token, tok.eos_token_id)
