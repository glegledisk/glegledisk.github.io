#!/usr/bin/env python3
"""P13 の解析: 学習済み HMoE / 同質 MoE 低 k / 小型 dense の 3 者を等 active FLOPs で比べる。

入力: p13_hmoe_path.json（H+LB, U+LB）/ p13b_dense.json（dense）
出力: p13_analysis.json / p13_analysis_out_utf8.txt

FLOPs 会計（1 トークン・1 層あたり MAC）:
  attention 4 d^2 + router E d + expert 2 d W      d=128, E=8
  → 総 FLOPs は W に比例する部分と定数部分に分かれる。**expert 幅は全体の 4〜5 割**なので、
    幅の比をそのまま速度比にしない（P7c と同じ罠）。
"""
import json
import math
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
D, E, L = 128, 8, 4


def macs(W):
    """1 トークンあたりの総 MAC（4 層）。"""
    return L * (4 * D * D + E * D + 2 * D * W)


def load():
    r = json.load(open(os.path.join(HERE, "p13_hmoe_path.json"), encoding="utf-8"))
    out = {}
    for k, v in r.items():
        out[k] = v
    return out


def emit(s=""):
    print(s, flush=True)


def main():
    R = load()
    arms = ["H+LB", "U+LB"]
    seeds = [0, 1, 2]
    lines = []

    def log(s=""):
        emit(s)
        lines.append(s)

    log("=" * 78)
    log("[1] 自然な動作点（交絡なし）— active width と CE")
    log("%-6s %-5s %6s %8s %8s %8s %9s %9s"
        % ("arm", "cond", "W", "CE_all", "CE_copy", "copy", "MACs/tok", "対U base"))
    main_pts = {}
    for arm in arms:
        for cond in ("top1", "base"):
            rows = [R["%s:s%d:%s" % (arm, s, cond)] for s in seeds
                    if "%s:s%d:%s" % (arm, s, cond) in R]
            if not rows:
                continue
            W = np.mean([r["width"] for r in rows])
            ce = np.mean([r["ce_all"] for r in rows])
            cec = np.mean([r["ce_copy"] for r in rows])
            acc = np.mean([r["acc_copy"] for r in rows])
            log("%-6s %-5s %6.1f %8.4f %8.4f %8.4f %9.0f"
                % (arm, cond, W, ce, cec, acc, macs(W)))
            main_pts[(arm, cond)] = {"W": W, "ce": ce, "ce_copy": cec, "acc": acc,
                                     "macs": macs(W),
                                     "per_seed_ce": [r["ce_all"] for r in rows],
                                     "per_seed_W": [r["width"] for r in rows]}

    log("")
    log("[2] 等 FLOPs 対比（seed 別、系列対応）")
    for cond in ("top1", "base"):
        h = main_pts.get(("H+LB", cond))
        u = main_pts.get(("U+LB", cond))
        if not h or not u:
            continue
        log("  %s: HMoE W=%.0f (%.0f MACs) vs 均一 W=%.0f (%.0f MACs) → MAC 比 %.3f"
            % (cond, h["W"], h["macs"], u["W"], u["macs"], h["macs"] / u["macs"]))
        for s in seeds:
            a = R.get("H+LB:s%d:%s" % (s, cond))
            b = R.get("U+LB:s%d:%s" % (s, cond))
            if not a or not b:
                continue
            x = np.array(a["ce_seq"])
            y = np.array(b["ce_seq"])
            d = x - y
            se = d.std(ddof=1) / math.sqrt(d.size)
            log("    s%d: ΔCE(H−U) %+.4f  se %.4f  t %+.1f  (W %.0f vs %.0f) %s"
                % (s, d.mean(), se, d.mean() / se, a["width"], b["width"],
                   "H 勝ち" if d.mean() < 0 else "U 勝ち"))

    log("")
    log("[3] 層別の小 expert（幅 32）使用率 — 「小 expert が主役」はどの層か")
    log("     %-6s %-3s %6s %6s %6s %6s   %6s"
        % ("arm", "s", "L0", "L1", "L2", "L3", "L3−L0"))
    for arm in arms:
        for s in seeds:
            r = R.get("%s:s%d:base" % (arm, s))
            if not r:
                continue
            u = np.array(r["usage"])           # (L, E)
            small = u[:, [0, 1]].sum(1)        # 幅 32 の 2 個（U+LB では単に expert 0,1）
            log("     %-6s %-3d %6.2f %6.2f %6.2f %6.2f   %+6.2f"
                % (arm, s, small[0], small[1], small[2], small[3],
                   small[3] - small[0]))

    log("")
    log("[4] 固定部分集合の制限コスト（交絡あり: ゲート再正規化 + 層の専門化）")
    log("     %-6s %-4s %6s %8s   %s" % ("arm", "cond", "W", "CE_all", "seed 別 CE"))
    for arm in arms:
        for cond in ("s1", "s2", "m2", "u2", "q4", "l2", "r2"):
            rows = [R["%s:s%d:%s" % (arm, s, cond)] for s in seeds
                    if "%s:s%d:%s" % (arm, s, cond) in R]
            if not rows:
                continue
            log("     %-6s %-4s %6.0f %8.4f   %s"
                % (arm, cond, np.mean([r["width"] for r in rows]),
                   np.mean([r["ce_all"] for r in rows]),
                   " ".join("%.3f" % r["ce_all"] for r in rows)))

    # 交換可能性の検定: {2,3} / {6,7} / random が同一か
    log("")
    log("[5] 大 expert は交換可能か（{2,3} と {6,7} と random の CE が一致するか）")
    for arm in arms:
        for s in seeds:
            vals = {}
            for cond in ("u2", "l2", "r2"):
                r = R.get("%s:s%d:%s" % (arm, s, cond))
                if r:
                    vals[cond] = (r["ce_all"], r["force"])
            if len(vals) == 3:
                v = list(vals.values())
                same = max(x[0] for x in v) - min(x[0] for x in v)
                log("     %-6s s%d: %s  最大差 %.2e %s"
                    % (arm, s,
                       "  ".join("%s=%s→%.4f" % (c, vals[c][1], vals[c][0])
                                 for c in ("u2", "l2", "r2")),
                       same, "← 完全一致" if same < 1e-6 else ""))

    # dense
    dpath = os.path.join(HERE, "p13b_dense.json")
    if os.path.exists(dpath):
        Dn = json.load(open(dpath, encoding="utf-8"))
        log("")
        log("[6] 等 FLOPs の小型 dense（同一手順で訓練）")
        log("     %-8s %6s %8s %8s %9s %10s"
            % ("W", "params", "CE_all", "CE_copy", "MACs/tok", "vs HMoE同W"))
        byw = {}
        for r in Dn:
            byw.setdefault(r["width"], []).append(r)
        for w in sorted(byw):
            rows = byw[w]
            log("     %-8d %6d %8.4f %8.4f %9.0f"
                % (w, rows[0]["nparam"],
                   np.mean([r["ce_all"] for r in rows]),
                   np.mean([r["ce_copy"] for r in rows]), macs(w)))
            byw[w] = {"ce": np.mean([r["ce_all"] for r in rows]),
                      "ce_copy": np.mean([r["ce_copy"] for r in rows]),
                      "acc": np.mean([r["acc_copy"] for r in rows]),
                      "per_seed": [r["ce_all"] for r in rows],
                      "nparam": rows[0]["nparam"]}

        log("")
        log("[7] 3 者比較（seed 別、系列対応の ΔCE）")
        # HMoE の動作点に最も近い dense 幅を選ぶ
        for cond, dw in (("top1", 97), ("base", 180)):
            for arm in arms:
                for s in seeds:
                    a = R.get("%s:s%d:%s" % (arm, s, cond))
                    if not a:
                        continue
                    dr = [r for r in Dn if r["width"] == dw and r["seed"] == s]
                    if not dr:
                        continue
                    x = np.array(a["ce_seq"])
                    y = np.array(dr[0]["ce_seq"])
                    d = x - y
                    se = d.std(ddof=1) / math.sqrt(d.size)
                    log("     %-5s vs dense%d (%s s%d): ΔCE %+.4f se %.4f t %+.1f  W %.0f/%.0f  %s"
                        % (arm, dw, cond, s, d.mean(), se, d.mean() / se,
                           a["width"], dw, "MoE 勝ち" if d.mean() < 0 else "dense 勝ち"))

        out_dense = {str(w): v for w, v in byw.items()}
    else:
        out_dense = None

    with open(os.path.join(HERE, "p13_analysis.json"), "w", encoding="utf-8") as f:
        json.dump({"main": {"%s:%s" % k: v for k, v in main_pts.items()},
                   "dense": out_dense},
                  f, ensure_ascii=False, indent=2, default=float)
    with open(os.path.join(HERE, "p13_analysis_out_utf8.txt"), "w",
              encoding="utf-8") as f:
        f.write("\n".join(lines))
    print("\nsaved: p13_analysis.json / p13_analysis_out_utf8.txt")


if __name__ == "__main__":
    main()
