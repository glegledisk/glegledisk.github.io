"""
P4a: 適応 k のための特徴量キャプチャ（1 forward パス）

目的:
  「ある位置 j で、そのトークンに計算を割く価値があるか」を、
  **その位置で実際に入手できる信号**から予測できるかを測るための素材を集める。

因果律:
  位置 j の FFN に入る直前の隠れ状態 h_{l,j} は token 0..j のみに依存する（合法）。
  予測したいのは NLL_j（= token j+1 の予測困難度）と d_j（= top-6 に削ったときの CE 増分）。
  d_j は token j+1 に依存するので、これは「未来の予測」。

保存（p4_feats.npz）:
  gate_l{0..15}   (n, 64)   float32  ルータ logit（各層・各位置）
  h{0,4,8,12,15}  (n, 2048) float16  隠れ状態
  nll             (n,)                baseline (top-8) の per-token NLL
  ent             (n,)                出力分布のエントロピー
  top1            (n,)                baseline の argmax が当たったか
  tokid           (n,)                次トークンの ID（予測対象）
  curid           (n,)                現トークンの ID
  win             (n,)                ウィンドウ番号
  pos             (n,)                ウィンドウ内位置
  lang            (n,)                'en'/'ja'

実行:
  python p4a_capture.py --windows 24 --len 256
"""

import argparse
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

from p3_topk_quality_olmoe import load_corpus

HERE = os.path.dirname(os.path.abspath(__file__))
H_LAYERS = [0, 4, 8, 12, 15]


def log(msg):
    print(msg, flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--seed", type=int, default=11, help="P3 と同じスライス")
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[1/4] loading")
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    n_layers = int(model.config.num_hidden_layers)
    n_experts = int(model.config.num_experts)

    gates = [layer.mlp.gate for layer in model.model.layers]
    captured = {}

    def make_hook(i):
        def hook(module, inp, out):
            captured[i] = out[0].detach().float().cpu()
        return hook
    for i, g in enumerate(gates):
        g.register_forward_hook(make_hook(i))

    log("[2/4] corpus")
    rng = np.random.RandomState(args.seed)
    seqs, lang_of = [], []
    for lang in ("en", "ja"):
        txt = load_corpus(lang)
        ids = tok(txt, return_tensors="pt", add_special_tokens=False).input_ids[0]
        need = args.windows * args.len
        start = 0 if ids.numel() < need else int(rng.randint(0, ids.numel() - need))
        block = ids[start:start + need]
        for w in range(args.windows):
            seqs.append(block[w * args.len:(w + 1) * args.len])
            lang_of.append(lang)
        log("      %s: using [%d, %d)" % (lang, start, start + need))

    log("[3/4] forward")
    out = {("gate_%d" % i): [] for i in range(n_layers)}
    for l in H_LAYERS:
        out["h%d" % l] = []
    out["nll"], out["ent"], out["top1"] = [], [], []
    out["tokid"], out["curid"], out["win"], out["pos"] = [], [], [], []

    t0 = time.time()
    with torch.no_grad():
        for wi, ids in enumerate(seqs):
            x = ids.unsqueeze(0).to(model.device)
            res = model(input_ids=x, use_cache=False, output_hidden_states=True)
            lg = res.logits[0, :-1].float()          # (255, V) 位置 j が token j+1 を予測
            tgt = x[0, 1:]
            nll = F.cross_entropy(lg, tgt, reduction="none")
            p = torch.softmax(lg, dim=-1)
            ent = -(p * torch.log(p + 1e-9)).sum(-1)
            am = lg.argmax(-1)
            for i in range(n_layers):
                # gate の出力は既に (N, 64) に平坦化されている（(1, S, d) ではない）
                out["gate_%d" % i].append(captured[i][:-1].numpy())
            for l in H_LAYERS:
                out["h%d" % l].append(res.hidden_states[l][0, :-1].float().half().cpu().numpy())
            out["nll"].append(nll.cpu().numpy())
            out["ent"].append(ent.cpu().numpy())
            out["top1"].append((am == tgt).float().cpu().numpy())
            out["tokid"].append(tgt.cpu().numpy())
            out["curid"].append(x[0, :-1].cpu().numpy())
            out["win"].append(np.full(255, wi, dtype=np.int32))
            out["pos"].append(np.arange(255, dtype=np.int32))
            del res, lg, p, ent, am
            if (wi + 1) % 8 == 0:
                log("      %d/%d windows (%.0f s)" % (wi + 1, len(seqs), time.time() - t0))

    arrs = {}
    for k, v in out.items():
        arrs[k] = np.concatenate(v, axis=0)
    arrs["lang"] = np.array([lang_of[w] for w in arrs["win"]])
    np.savez_compressed(os.path.join(HERE, "p4_feats.npz"), **arrs)
    log("[4/4] saved p4_feats.npz")
    log("      n = %d, gate dim %d, h dim %d"
        % (arrs["nll"].size, arrs["gate_0"].shape[-1], arrs["h8"].shape[-1]))
    log("      nll mean %.5f  ent mean %.4f  top1 %.4f"
        % (arrs["nll"].mean(), arrs["ent"].mean(), arrs["top1"].mean()))


if __name__ == "__main__":
    main()
