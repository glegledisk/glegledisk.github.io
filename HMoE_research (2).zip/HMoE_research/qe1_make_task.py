# -*- coding: utf-8 -*-
"""QE1 Step 1: 位置独立な型 edit を持つ課題の生成と C2 / C3 校正.

設計書: `QE1課題設計書_内容が位置と独立な課題で3検定を収束後に再走する_20261114.md`
        §3（課題 1 行定義）/ §7（校正）/ §10（Step 1）

本次の範囲
  - 新規課題 `typed_edit` の生成スクリプトと、走行前の C2 / C3 校正だけ。
  - **学習・GPU・3 検定の本番は一切走らせない**（§10）。numpy のみ。
  - `corpus_common.py` の P0 諸元を import して継承する（閾値を再定義しない規約）。

走行前に固定する観測統計量と閾値（設計書 §7 の `ε_pos` / `ε_edit` を数値化）
  C1 同一 seed 2 回生成のビット一致                     maxdiff == 0
  C2 `eta2_type_pos` < 1e-3 かつ `mi_type_pos_norm` < 1e-3
  C3 `eta2_edit_given_pos` > 5e-2 かつ `mi_edit_norm` > 1e-1
  C6 非有限値 0（json は allow_nan=False）

C3 の読み替え（§3 の `η²_edit` を走行前校正で測れる形に具体化）
  PC §7 の `η²_edit` は「学習済みルーティング質量の線形分散分解」なので学習が要る。
  Step 1 では測れないため、`η²_edit` を「位置ビンを統制した後に実効 edit 則 `a` が
  予測対象の copy 可否 `copy_mask` を説明する分散比」として生成的に定義する。
  これは「内容が位置と独立な寄与を持つか」の**上限の校正**であって、
  モデルが実際に学習することの保証ではない（設計書 §2「予測可能性は測らない」）。
  学習後のルーティング質量に対する本体の `η²_edit` は Step 2 以降で測る。

出力: qe1_s1_metrics.json / qe1_s1_arrays.npz / qe1_s1.log（すべて UTF-8）
"""
from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / "不均一MoE-Corpus"))
from corpus_common import (  # noqa: E402
    COPY_WINDOW,
    EVAL_SEED_BASE,
    N_EVAL_SEQ,
    N_TRAIN_SEQ,
    N_TYPES,
    SEQ_LEN,
    SYNTAX_RATE,
    TRAIN_SEED_BASE,
    TYPE_NAMES,
    TYPE_WIDTH,
    V_IDENT,
    V_SYNTAX,
    VOCAB,
    ZIPF_ALPHA,
    Corpus,
    zipf_cdf,
)

# =====================================================================
# 走行前固定（QE1 §2 / §7 / §10）。結果を見て変更しない。
# =====================================================================
TAG = "qe1_s1"
N_CALIB_SEQ = N_TRAIN_SEQ            # 4000 系列 = 1,024,000 トークン
CALIB_SEED = 0
POS_BINS = 16                       # C2 / C3 の位置ビン数
EPS_POS = 1.0e-3                    # C2: η²_type,pos と MI_norm の上側閾値
EPS_EDIT = 5.0e-2                   # C3: η²_edit の下側閾値
EPS_EDIT_MI = 1.0e-1                # C3: MI_norm の下側閾値
EDIT_LAG = 2                        # edit 則 type=2 の参照 lag
INIT_SEED_BASE = 3000               # QE1S2 生成則 v2 用の独立 RNG ストリーム（走行前固定）
QE1S4_IDENT_STREAM_OFFSET = 11000   # QE1S4 common-random-number ident stream
QE1S4_SYNR_STREAM_OFFSET = 12000    # QE1S4 syntax-internal-ID stream
SYNTAX_PER_TYPE = (V_SYNTAX - N_TYPES) // N_TYPES   # (288-4)/4 = 71
SYNTAX_ID_MAX = N_TYPES + SYNTAX_PER_TYPE * N_TYPES  # 288 == V_SYNTAX
assert SYNTAX_ID_MAX == V_SYNTAX, "syntax ID の分割が P0 語彙と不一致"
assert len(TYPE_WIDTH) == N_TYPES
assert SEQ_LEN % POS_BINS == 0

# edit 則（a の水準 = type_draw と同一の 4 水準）
EDIT_RULES = ("copy", "inc", "lag", "prev")


@dataclass
class QE1Corpus(Corpus):
    """`Corpus` 互換 + QE1 固有の配列。

    `types` には**実効 edit 則 `a`** を入れる。Step 2 で `corpus_common.sample_batch`
    が `c.types` を `ty` として返し、`oracle` policy が `TYPE_WIDTH[ty]` を指せるように
    するための互換措置。C2 の対象は位置独立な生割当 `type_draw` の方である。
    """

    type_draw: np.ndarray = field(default_factory=lambda: np.zeros((0, 0), np.int8))
    a: np.ndarray = field(default_factory=lambda: np.zeros((0, 0), np.int8))
    changed: np.ndarray = field(default_factory=lambda: np.zeros((0, 0), bool))
    base: np.ndarray = field(default_factory=lambda: np.zeros((0, 0), np.int16))


def make_task(seed: int, n_seq: int, base: int = TRAIN_SEED_BASE,
              freq: str = "zipf", init_type: str = "zero",
              ident_vocab_size: int = V_IDENT,
              paired_frequency: bool = False) -> QE1Corpus:
    """位置独立な型割当 + 型依存の edit 則を持つ課題を 1 つ作る。

    生成規則（走行前に凍結）
      1. `type_draw ~ Uniform{0..3}` を (n_seq, SEQ_LEN) に i.i.d. 割当（位置独立）。
      2. `is_syntax ~ Bernoulli(SYNTAX_RATE)`（P0 の 0.25 を維持）。
         syntax 位置のトークン ID を `N_TYPES + type_draw*71 + r` で符号化する。
         → **型が入力トークンから一意に読める**（11/01 考察 §5 の条件 A）。
         ident 位置は `V_SYNTAX + ident_rank`（zipf / uniform 切替可能）。
      3. 実効 edit 則 `a[t]` = 位置 t 以前で最も近い syntax(cue) の型。
         cue 未観測の系列先頭は `a = 0` (copy) に固定（境界効果は探索的記録）。
      4. 予測対象 `next_tok[t]` を `a[t]` に従って `base[t] = tokens[t+1]` から編集:
           0 copy : base のまま
           1 inc  : ident なら (base+1) mod V_IDENT（syntax は base のまま）
           2 lag  : tokens[t+1-EDIT_LAG]
           3 prev : tokens[t]
      5. `copy_mask` は P0 と同じく直近 COPY_WINDOW=32 に next_tok が現れるか。
    """
    rng = np.random.default_rng(int(seed) + int(base))
    shape = (int(n_seq), SEQ_LEN)

    type_draw = rng.integers(0, N_TYPES, size=shape, dtype=np.int64)
    is_syntax = rng.random(shape) < SYNTAX_RATE

    ident_vocab_size = int(ident_vocab_size)
    if not (1 <= ident_vocab_size <= V_IDENT):
        raise ValueError(f"ident_vocab_size must be in [1,{V_IDENT}]")
    if paired_frequency:
        if freq not in ("zipf", "uniform_k"):
            raise ValueError("paired_frequency supports only zipf / uniform_k")
        # S4: use the same U[0,1) variates for both distributions so only the
        # ident mapping changes. The default path below remains bit-identical.
        ident_rng = np.random.default_rng(
            int(seed) + int(base) + QE1S4_IDENT_STREAM_OFFSET)
        ident_u = ident_rng.random(shape)
        if freq == "zipf":
            ident = np.searchsorted(zipf_cdf(), ident_u, side="right")
            ident = np.clip(ident, 0, V_IDENT - 1)
            id_modulus = V_IDENT
        else:
            ident = np.floor(ident_u * ident_vocab_size).astype(np.int64)
            id_modulus = ident_vocab_size
        syn_r_rng = np.random.default_rng(
            int(seed) + int(base) + QE1S4_SYNR_STREAM_OFFSET)
        syn_r = syn_r_rng.integers(0, SYNTAX_PER_TYPE, size=shape, dtype=np.int64)
    elif freq == "zipf":
        ident = np.searchsorted(zipf_cdf(), rng.random(shape), side="right")
        ident = np.clip(ident, 0, V_IDENT - 1)
        id_modulus = V_IDENT
        syn_r = rng.integers(0, SYNTAX_PER_TYPE, size=shape, dtype=np.int64)
    elif freq == "uniform":
        ident = rng.integers(0, V_IDENT, size=shape, dtype=np.int64)
        id_modulus = V_IDENT
        syn_r = rng.integers(0, SYNTAX_PER_TYPE, size=shape, dtype=np.int64)
    elif freq == "uniform_k":
        raise ValueError("uniform_k requires paired_frequency=True")
    else:
        raise ValueError(f"unknown freq: {freq}")
    ident = np.asarray(ident, dtype=np.int64)
    syntax_id = N_TYPES + type_draw * SYNTAX_PER_TYPE + syn_r
    assert int(syntax_id.max()) < V_SYNTAX and int(syntax_id.min()) >= N_TYPES
    tokens = np.where(is_syntax, syntax_id, V_SYNTAX + ident).astype(np.int64)

    # ---- 実効 edit 則 a（直近 cue の型を forward fill）
    # QE1S2 生成則 v2: cue 未観測位置の初期値を 0 固定 (zero) から
    # 系列ごとの init_type[i] ~ Uniform(4) (uniform) へ切り替えられる。
    # RNG は rng とは別ストリームなので、zero 側の消費順・全配列は 1 bit も変わらない。
    pos_grid = np.broadcast_to(np.arange(SEQ_LEN, dtype=np.int64), shape)
    last_cue = np.maximum.accumulate(np.where(is_syntax, pos_grid, -1), axis=1)
    rows = np.arange(shape[0])[:, None]
    if init_type == "zero":
        fill = 0
    elif init_type == "uniform":
        rng_init = np.random.default_rng(int(seed) + INIT_SEED_BASE)
        fill = rng_init.integers(0, N_TYPES, size=(shape[0], 1), dtype=np.int64)
    else:
        raise ValueError(f"unknown init_type: {init_type}")
    a = np.where(last_cue >= 0, type_draw[rows, np.clip(last_cue, 0, None)], fill)
    a = np.asarray(a, dtype=np.int64)

    # ---- 予測対象
    base = np.empty(shape, dtype=np.int64)
    base[:, :-1] = tokens[:, 1:]
    base[:, -1] = tokens[:, 0]
    is_ident_base = base >= V_SYNTAX
    inc = np.where(is_ident_base,
                   V_SYNTAX + ((base - V_SYNTAX + 1) % id_modulus), base)
    lag = np.empty(shape, dtype=np.int64)
    lag[:, EDIT_LAG:] = tokens[:, :-EDIT_LAG]
    lag[:, :EDIT_LAG] = base[:, :EDIT_LAG]
    prev = np.empty(shape, dtype=np.int64)
    prev[:, 1:] = tokens[:, :-1]
    prev[:, 0] = base[:, 0]
    next_tok = np.select([a == 0, a == 1, a == 2, a == 3],
                         [base, inc, lag, prev], default=base).astype(np.int64)
    changed = (next_tok != base)

    # ---- copy_mask（P0 と同定義。next_syntax は編集後の next_tok から判定）
    next_syntax = next_tok < V_SYNTAX
    copy_mask = np.zeros(shape, dtype=bool)
    for l in range(1, COPY_WINDOW + 1):
        prev_tok = np.zeros(shape, dtype=np.int64)
        prev_tok[:, l:] = tokens[:, :-l]
        copy_mask |= (prev_tok == next_tok)
    copy_mask &= ~next_syntax
    copy_mask[:, -1] = False

    # ---- C2 用の位置相関（既存 make_corpus と意味を揃え type_draw で測る）
    pos_f = np.broadcast_to(np.arange(SEQ_LEN, dtype=np.float64), shape).ravel()
    ty_f = type_draw.ravel().astype(np.float64)
    r = float(np.corrcoef(pos_f, ty_f)[0, 1])
    if not np.isfinite(r):
        r = 0.0

    return QE1Corpus(
        tokens=tokens, types=a.copy(), next_tok=next_tok,
        copy_mask=copy_mask, is_syntax=is_syntax, ident_rank=ident,
        pos_corr=abs(r),
        type_draw=type_draw.astype(np.int8), a=a.astype(np.int8),
        changed=changed, base=base.astype(np.int16),
    )


# =====================================================================
# 観測統計量（走行前に固定。別実装で Step 4 検算する）
# =====================================================================
def pos_bins(shape) -> np.ndarray:
    return np.broadcast_to(
        (np.arange(SEQ_LEN, dtype=np.int64) * POS_BINS // SEQ_LEN), shape
    ).astype(np.int64)


def r2_group(y: np.ndarray, codes: np.ndarray, n_groups: int) -> float:
    """群平均で説明される分散比 R²。one-way ANOVA の η² と同じ。"""
    y = np.asarray(y, dtype=np.float64).ravel()
    codes = np.asarray(codes, dtype=np.int64).ravel()
    cnt = np.bincount(codes, minlength=n_groups).astype(np.float64)
    tot = np.bincount(codes, weights=y, minlength=n_groups)
    mu = tot / np.maximum(cnt, 1.0)
    ss_between = float(np.sum(cnt * (mu - y.mean()) ** 2))
    ss_total = float(np.sum((y - y.mean()) ** 2))
    return ss_between / ss_total if ss_total > 0 else 0.0


def joint_table(x: np.ndarray, y: np.ndarray, nx: int, ny: int) -> np.ndarray:
    x = np.asarray(x, dtype=np.int64).ravel()
    y = np.asarray(y, dtype=np.int64).ravel()
    return np.bincount(x * ny + y, minlength=nx * ny).reshape(nx, ny).astype(np.float64) / x.size


def mi_over_entropy(table: np.ndarray) -> float:
    """I(X;Y) / H(Y)。table は (nx, ny) の同時確率。"""
    px = table.sum(1)
    py = table.sum(0)
    with np.errstate(divide="ignore", invalid="ignore"):
        outer = px[:, None] * py[None, :]
        term = np.where((table > 0) & (outer > 0),
                        table * np.log(table / np.maximum(outer, 1e-300)), 0.0)
        mi = float(np.sum(term))
        hy = float(-np.sum(np.where(py > 0, py * np.log(np.maximum(py, 1e-300)), 0.0)))
    return mi / hy if hy > 0 else 0.0


def eta2_categorical(values: np.ndarray, bins: np.ndarray,
                     n_bins: int, n_levels: int) -> float:
    """名目変数 values の one-hot に対する η²（位置ビンによる分散比）。"""
    v = np.asarray(values, dtype=np.int64).ravel()
    b = np.asarray(bins, dtype=np.int64).ravel()
    onehot = np.eye(n_levels, dtype=np.float64)[v]
    grand = onehot.mean(0)
    ss_between = 0.0
    for k in range(n_bins):
        m = b == k
        if m.any():
            ss_between += float(m.sum()) * float(((onehot[m].mean(0) - grand) ** 2).sum())
    ss_total = float(((onehot - grand) ** 2).sum())
    return ss_between / ss_total if ss_total > 0 else 0.0


def calibrate(c: QE1Corpus, label: str) -> dict:
    """C2 / C3 の観測統計量を 1 コーパスについて全部測る。"""
    shape = c.tokens.shape
    pb = pos_bins(shape)
    n = int(np.prod(shape))
    cm = c.copy_mask.astype(np.float64)

    # ---- C2: 位置独立な生割当 type_draw と位置の関係
    eta2_type_pos = eta2_categorical(c.type_draw, pb, POS_BINS, N_TYPES)
    t_pos = joint_table(pb, c.type_draw, POS_BINS, N_TYPES)   # I(pos; type)/H(type)
    mi_type_pos_norm = mi_over_entropy(t_pos)

    # ---- C3: 位置を統制した後の実効 edit 則の寄与（copy 可否 against a）
    codes_full = (pb * N_TYPES + c.a.astype(np.int64)).ravel()
    r2_full = r2_group(cm, codes_full, POS_BINS * N_TYPES)
    r2_pos = r2_group(cm, pb, POS_BINS)
    eta2_edit_given_pos = r2_full - r2_pos
    t_edit = joint_table(c.a, c.changed.astype(np.int64), N_TYPES, 2)
    mi_edit_norm = mi_over_entropy(t_edit)
    p_changed = float(c.changed.mean())

    # ---- 探索的（確認的判定には使わない）
    eta2_a_pos = eta2_categorical(c.a, pb, POS_BINS, N_TYPES)
    w_oracle = np.asarray(TYPE_WIDTH, dtype=np.float64)[c.a.astype(np.int64)]
    r2_w_full = r2_group(w_oracle, codes_full, POS_BINS * N_TYPES)
    r2_w_pos = r2_group(w_oracle, pb, POS_BINS)
    p_cue_seen = float((np.maximum.accumulate(
        np.where(c.is_syntax, np.broadcast_to(np.arange(SEQ_LEN), shape), -1),
        axis=1) >= 0).mean())

    by_type = {}
    for k in range(N_TYPES):
        m = (c.a == k)
        by_type[EDIT_RULES[k]] = {
            "frac": float(m.mean()),
            "p_changed": float(c.changed[m].mean()) if m.any() else 0.0,
            "p_copyable": float(c.copy_mask[m].mean()) if m.any() else 0.0,
        }

    return {
        "label": label,
        "n_tokens": n,
        "n_seq": int(shape[0]),
        "C2_eta2_type_pos": float(eta2_type_pos),
        "C2_mi_type_pos_norm": float(mi_type_pos_norm),
        "C2_pos_corr_abs": float(c.pos_corr),
        "C3_eta2_edit_given_pos": float(eta2_edit_given_pos),
        "C3_r2_full": float(r2_full),
        "C3_r2_pos_only": float(r2_pos),
        "C3_mi_edit_norm": float(mi_edit_norm),
        "C3_p_changed": p_changed,
        "C3_eta2_oracle_upper": float(r2_w_full - r2_w_pos),
        "exploratory_eta2_a_pos": float(eta2_a_pos),
        "exploratory_p_cue_seen": p_cue_seen,
        "by_edit_rule": by_type,
        "finite_ok": bool(
            np.isfinite([eta2_type_pos, mi_type_pos_norm, eta2_edit_given_pos,
                         mi_edit_norm, p_changed, eta2_a_pos, p_cue_seen]).all()
        ),
    }


def main() -> None:
    out = {"tag": TAG, "phase": "QE1 Step 1 (task generation + C2/C3 calibration)",
           "design": "QE1課題設計書_内容が位置と独立な課題で3検定を収束後に再走する_20261114.md",
           "no_training": True, "no_gpu": True}
    out["prereg"] = {
        "N_CALIB_SEQ": N_CALIB_SEQ, "CALIB_SEED": CALIB_SEED,
        "SEQ_LEN": SEQ_LEN, "V_SYNTAX": V_SYNTAX, "V_IDENT": V_IDENT,
        "VOCAB": VOCAB, "ZIPF_ALPHA": ZIPF_ALPHA, "SYNTAX_RATE": SYNTAX_RATE,
        "SYNTAX_PER_TYPE": SYNTAX_PER_TYPE, "COPY_WINDOW": COPY_WINDOW,
        "N_TYPES": N_TYPES, "TYPE_WIDTH": list(TYPE_WIDTH),
        "TYPE_NAMES": list(TYPE_NAMES), "EDIT_RULES": list(EDIT_RULES),
        "EDIT_LAG": EDIT_LAG, "POS_BINS": POS_BINS,
        "EPS_POS": EPS_POS, "EPS_EDIT": EPS_EDIT, "EPS_EDIT_MI": EPS_EDIT_MI,
        "TRAIN_SEED_BASE": TRAIN_SEED_BASE, "EVAL_SEED_BASE": EVAL_SEED_BASE,
        "N_TRAIN_SEQ": N_TRAIN_SEQ, "N_EVAL_SEQ": N_EVAL_SEQ,
        "stat_definitions": {
            "C2_eta2_type_pos": "one-hot(type_draw) の位置ビン間分散 / 全分散",
            "C2_mi_type_pos_norm": "I(pos_bin; type_draw) / H(type_draw)",
            "C3_eta2_edit_given_pos": "R2(copy_mask ~ pos_bin x a) - R2(copy_mask ~ pos_bin)",
            "C3_mi_edit_norm": "I(a; changed) / H(changed), changed = (next_tok != base)",
            "C3_eta2_oracle_upper": "R2(TYPE_WIDTH[a] ~ pos_bin x a) - R2(TYPE_WIDTH[a] ~ pos_bin)",
        },
        "thresholds": {
            "C1_maxdiff": 0.0,
            "C2": "eta2_type_pos < EPS_POS and mi_type_pos_norm < EPS_POS",
            "C3": "eta2_edit_given_pos > EPS_EDIT and mi_edit_norm > EPS_EDIT_MI",
            "C6": "nonfinite == 0",
        },
        "threshold_rationale": (
            "n=1,024,000 / 16 pos bins / 4 types の帰無期待 η² は約 4.4e-5。"
            "EPS_POS=1e-3 はその 23 倍で、Q2 hard 型の完全位置依存 (η²≈1) を確実に検出する。"
            "EPS_EDIT=5e-2 は PC §7 の e2 観測 η²_edit=0.000 と偶然帯 (≈6e-5) の 800 倍以上。"
            "閾値は生成結果を見る前に本ファイル内で固定した。"
        ),
    }

    # ---- 主コーパス（zipf・確認的）
    c = make_task(CALIB_SEED, N_CALIB_SEQ, base=TRAIN_SEED_BASE, freq="zipf")
    cal = calibrate(c, "typed_edit_zipf")
    out["primary"] = cal

    # ---- C1: 同一 seed の 2 回生成がビット一致するか
    c2 = make_task(CALIB_SEED, N_CALIB_SEQ, base=TRAIN_SEED_BASE, freq="zipf")
    maxdiff = 0
    for name in ("tokens", "types", "next_tok", "copy_mask", "is_syntax",
                 "ident_rank", "type_draw", "a", "changed", "base"):
        d = int(np.max(np.abs(np.asarray(getattr(c, name), dtype=np.int64)
                              - np.asarray(getattr(c2, name), dtype=np.int64))))
        maxdiff = max(maxdiff, d)
    out["C1"] = {"reproducible_maxdiff": maxdiff, "pass": bool(maxdiff == 0)}

    # ---- C2 / C3 判定
    p = cal
    checks = {
        "C1_reproducible": bool(maxdiff == 0),
        "C2_position_independence": bool(p["C2_eta2_type_pos"] < EPS_POS
                                         and p["C2_mi_type_pos_norm"] < EPS_POS),
        "C3_edit_contribution": bool(p["C3_eta2_edit_given_pos"] > EPS_EDIT
                                     and p["C3_mi_edit_norm"] > EPS_EDIT_MI),
        "C6_all_finite": bool(p["finite_ok"]),
    }
    verdict = "PASS" if all(checks.values()) else "FAIL"
    out["checks"] = checks
    out["verdict"] = verdict
    out["case"] = ("C2/C3 合格。Step 2 の 3 検定へ進める（ただし本判断は"
                   "生成的な上限の校正であり、学習後の η²_edit を保証しない）"
                   if verdict == "PASS" else
                   "QE1 §6 ケース C: 課題設計が律速。3 検定は走らせない")

    # ---- negative control: 既存 corpus_common.make_corpus に同じ統計量を適用
    from corpus_common import make_corpus  # noqa: E402
    old = make_corpus(CALIB_SEED, N_CALIB_SEQ, base=TRAIN_SEED_BASE)
    ctr = QE1Corpus(
        tokens=old.tokens, types=old.types, next_tok=old.next_tok,
        copy_mask=old.copy_mask, is_syntax=old.is_syntax,
        ident_rank=old.ident_rank, pos_corr=old.pos_corr,
        type_draw=old.types.astype(np.int8), a=old.types.astype(np.int8),
        changed=(old.next_tok != old.tokens).astype(bool),
        base=old.tokens.astype(np.int16),
    )
    out["negative_control_existing_corpus"] = calibrate(ctr, "corpus_common_make_corpus")

    # ---- 探索的: 頻度分布 uniform（設計書 §2 ② / §9 限界 5 の分離記録）
    cu = make_task(CALIB_SEED, N_CALIB_SEQ, base=TRAIN_SEED_BASE, freq="uniform")
    out["exploratory_uniform_freq"] = calibrate(cu, "typed_edit_uniform")

    # ---- 探索的: eval 側 seed（同一生成則が eval でも壊れないか）
    ce = make_task(CALIB_SEED, N_EVAL_SEQ, base=EVAL_SEED_BASE, freq="zipf")
    out["exploratory_eval_seed"] = calibrate(ce, "typed_edit_zipf_evalseed")

    # ---- C6: 出力全体の非有限値
    def scan(o, path="root"):
        bad = []
        if isinstance(o, dict):
            for k, v in o.items():
                bad += scan(v, f"{path}.{k}")
        elif isinstance(o, float) and not np.isfinite(o):
            bad.append(path)
        return bad
    out["C6"] = {"nonfinite_paths": scan(out), "pass": len(scan(out)) == 0}

    # ---- 書き出し（UTF-8 / allow_nan=False / npz は独立検算用）
    jp = HERE / f"{TAG}_metrics.json"
    jp.write_text(json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False),
                  encoding="utf-8")
    np.savez(
        HERE / f"{TAG}_arrays.npz",
        type_draw=c.type_draw, a=c.a, pos_bin=pos_bins(c.tokens.shape).astype(np.int8),
        copy_mask=c.copy_mask, changed=c.changed, next_tok=c.next_tok.astype(np.int16),
        base=c.base, ident_rank=c.ident_rank.astype(np.int16), is_syntax=c.is_syntax,
        tokens=c.tokens.astype(np.int16),
    )
    lines = [
        f"tag={TAG}",
        f"verdict={verdict}",
        f"C1_maxdiff={maxdiff}",
        f"C2_eta2_type_pos={p['C2_eta2_type_pos']:.8f} (eps {EPS_POS})",
        f"C2_mi_type_pos_norm={p['C2_mi_type_pos_norm']:.8f} (eps {EPS_POS})",
        f"C3_eta2_edit_given_pos={p['C3_eta2_edit_given_pos']:.8f} (eps {EPS_EDIT})",
        f"C3_mi_edit_norm={p['C3_mi_edit_norm']:.8f} (eps {EPS_EDIT_MI})",
        f"C3_p_changed={p['C3_p_changed']:.8f}",
        f"negative_control_eta2_edit={out['negative_control_existing_corpus']['C3_eta2_edit_given_pos']:.8f}",
        f"checks={checks}",
        f"case={out['case']}",
        "",
    ]
    (HERE / f"{TAG}.log").write_text("\n".join(lines), encoding="utf-8")
    sys.stdout.write("\n".join(lines))
    sys.stdout.flush()


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        sys.stderr.write(f"[qe1_make_task] ERROR {type(exc).__name__}: {exc}\n")
        sys.stderr.flush()
        raise
