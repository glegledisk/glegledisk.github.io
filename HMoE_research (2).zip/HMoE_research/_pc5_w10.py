# -*- coding: utf-8 -*-
"""w=10 の検算: 水準・対応差・clip 交絡の分離・前回 sweep との校正。"""
import json
import os
import re

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))


def load(tag):
    p = os.path.join(HERE, "pc2_results_%s.json" % tag)
    by = {}
    if not os.path.exists(p):
        return by
    for r in json.load(open(p, encoding="utf-8"))["rows"]:
        by.setdefault(r["cfg"], {})[r["seed"]] = r
    return by


by = load("n15k_w10")
prev = load("n15k_kdsweep")


def parse(cfg):
    m = re.search(r"\+kd_w([0-9.]+)_T([0-9.]+)", cfg)
    mc = re.search(r"_clip([0-9.]+)", cfg)
    return ((float(m.group(1)), float(m.group(2))) if m else (None, None),
            float(mc.group(1)) if mc else 5.0)


print("== 水準（N=1.5e4, per_key=2, 10ep, lr 5e-4, n=2, 生徒 W=512, 教師 W=1024）==")
print("  %-34s %7s %7s %7s %7s %6s %9s %11s"
      % ("cfg", "CE", "sd", "acc", "clip設定", "発動", "KD ep1→10", "幅"))
order = [c for c in by if c not in ("half:scratch", "half:prune")]
order.sort(key=lambda c: (parse(c)[0][0] or 0, parse(c)[1]))
for cfg in ["half:scratch"] + order + (["half:prune"] if "half:prune" in by else []):
    d = by[cfg]
    ce = np.array([v["ce"] for v in d.values()])
    acc = np.array([v["acc"] for v in d.values()])
    cl = np.mean([v["n_clip"] for v in d.values()])
    kd1 = np.mean([v["ce_hist"][0]["kd"] for v in d.values()
                   if v["ce_hist"][0]["kd"] is not None])
    kd10 = np.mean([v["ce_hist"][-1]["kd"] for v in d.values()
                    if v["ce_hist"][-1]["kd"] is not None])
    w = np.mean([v["width_mean"] for v in d.values()])
    print("  %-34s %7.4f %7.4f %7.4f %7.0f %6.0f %9s %11.1f"
          % (cfg, ce.mean(), ce.std(ddof=1) if len(ce) > 1 else float("nan"),
             acc.mean(), parse(cfg)[1], cl,
             ("%.3f→%.3f" % (kd1, kd10)) if kd1 == kd1 else "-", w))

print("\n== 各腕 − scratch（同一プロセス・同一 seed）==")
base = {s: v["ce"] for s, v in by.get("half:scratch", {}).items()}
for cfg in order + (["half:prune"] if "half:prune" in by else []):
    d = by[cfg]
    ks = sorted(set(d) & set(base))
    x = np.array([d[k]["ce"] for k in ks])
    y = np.array([base[k] for k in ks])
    diff = x - y
    t, p = stats.ttest_rel(x, y)
    se = diff.std(ddof=1) / np.sqrt(len(diff))
    (w, T), cl = parse(cfg)
    print("  %-34s ΔCE %+0.4f  se %.4f  t %+0.2f  p %.4f  n %d  負 %d"
          % (cfg, diff.mean(), se, t, p, len(diff), int((diff < 0).sum())))

print("\n== clip 交絡の分離（w=10, T=1 だけ）==")
w10 = [c for c in order if parse(c)[0] == (10.0, 1.0)]
w10.sort(key=lambda c: parse(c)[1])
for c in w10:
    d = by[c]
    print("  clip %-4.0f  CE %.4f  acc %.4f  発動 %5.0f/4680 (%.1f%%)  KD loss ep10 %.3f"
          % (parse(c)[1], np.mean([v["ce"] for v in d.values()]),
             np.mean([v["acc"] for v in d.values()]),
             np.mean([v["n_clip"] for v in d.values()]),
             100 * np.mean([v["n_clip"] for v in d.values()]) / 4680,
             np.mean([v["ce_hist"][-1]["kd"] for v in d.values()])))

print("\n== 校正: 前回 sweep との一致（同じ条件の腕）==")
for cfg in ["half:scratch", "half:prune", "half:scratch+kd_w3.0_T1.0"]:
    if cfg in by and cfg in prev:
        a = np.array([by[cfg][s]["ce"] for s in sorted(by[cfg])])
        b = np.array([prev[cfg][s]["ce"] for s in sorted(prev[cfg])])
        print("  %-30s 今回 %.4f  前回 %.4f  差 %+.4f"
              % (cfg, a.mean(), b.mean(), a.mean() - b.mean()))
