#!/usr/bin/env python3
"""A2 の図。data/a2/a2_analysis.json と a2_results.json を読むだけ。"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "MS Gothic", "sans-serif"]
matplotlib.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a2")
J = json.load(open(os.path.join(D, "a2_analysis.json"), encoding="utf-8"))
rows = [r for r in json.load(open(os.path.join(D, "a2_results.json"), encoding="utf-8"))
        if "evals" in r]
A = J["aggregate"]
ORDER = ["sm_norm", "sig_norm", "sig_raw", "sm_raw"]
COL = {"sm_norm": "#4c72b0", "sig_norm": "#dd8452", "sig_raw": "#55a868", "sm_raw": "#c44e52"}

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.0, 4.8))

# --- (a) 質量の軌跡 ---
E = len(A["sm_norm"]["mass_by_ep"])
xs = np.arange(1, E + 1)
for a in ORDER:
    ys = [A[a]["mass_init"]] + A[a]["mass_by_ep"]
    ax1.plot(np.arange(0, E + 1), ys, "o-", color=COL[a], label=a, lw=2, ms=7)
ax1.axhline(1.0, color="black", ls="--", lw=1)
ax1.text(0.05, 1.02, "正規化版 = 1.000（構成的）", fontsize=8)
ax1.set_xticks(np.arange(0, E + 1))
ax1.set_xticklabels(["初期"] + [f"ep{k}" for k in range(1, E + 1)])
ax1.set_ylabel("ゲート質量 Σg（層平均）")
ax1.set_title("(a) 質量は両側から 1.0 に収束する", fontsize=11)
ax1.legend(fontsize=9)
ax1.grid(alpha=0.3)

# --- (b) seed 別の instr_valid ---
for i, a in enumerate(ORDER):
    v = [r["evals"][-1]["instr_valid"] for r in rows if r["arm"] == a]
    jitter = np.linspace(-0.12, 0.12, len(v))
    ax2.scatter(np.full(len(v), i) + jitter, v, s=60, color=COL[a],
                edgecolor="black", linewidth=0.6, zorder=3)
    ax2.hlines(np.median(v), i - 0.25, i + 0.25, color="black", lw=2)
ax2.set_xticks(range(len(ORDER)))
ax2.set_xticklabels([f"{a}\n(mass={A[a]['mass_mean']:.2f})" for a in ORDER], fontsize=9)
ax2.set_ylabel("instr_valid（seed 別、6 seed）")
ax2.set_title("(b) 中央値は同じで、裾だけが違う", fontsize=11)
ax2.grid(axis="y", alpha=0.3)
ax2.set_ylim(0, 1)

plt.tight_layout()
out = os.path.join(D, "a2_figure.png")
plt.savefig(out, dpi=150)
print(f"[write] {out}")
