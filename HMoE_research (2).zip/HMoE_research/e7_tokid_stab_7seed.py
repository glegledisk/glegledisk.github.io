# -*- coding: utf-8 -*-
"""e7_tokid_stab_7seed.py — tokid + 安定化の組合せ（tail リスク低減）

## 動機（A4 報告書 §7-1）
A4 で分かったこと:
  - free_entropy は typical seed では tokid 並み（s5 除外で obj 0.2374 vs tokid 0.2355）だが、
    **1/7 seed で壊滅的失敗（CE 1.93、acc 0.732＝未学習）**。entropy 報酬が「全部恒等」の
    退化に落ちるのを助長したと推定。
  - free_balance は FFN cost を安定化（SD 0.091→0.056）するが品質変化なし。
  - free_tokid は有意な品質改善（CE −0.062 vs frozen_ffn）だが FFN cost の seed 間 SD が最大（0.103）。

## 仮説
**H-T1（tail リスク）**: シグナル（tokid）があれば、entropy 報酬の壊滅的失敗を防げる。
  router が fr/rr を FFN に残せるので、FFN が勾配を受け続け、退化しない。
**H-T2（安定化）**: tokid に balance を足すと FFN cost の seed 間分散が下がる。

## アーム（A4 の tokid を baseline として同 seed で比較）
| バリアント | 構成 |
|---|---|
| `tokid_entropy` | tokid 特徴 + entropy 報酬（β=0.05、A4 と同一） |
| `tokid_balance` | tokid 特徴 + balance 損失（β=0.1、A4 と同一） |

判定:
  1. **tail リスク**: 7 seed の最大 CE と「CE > 0.5 の seed 数」。tokid_entropy が 0 なら H-T1 支持。
  2. **typical**: 合成目的（λ=0.15）が tokid（0.2355）を下回るか（seed 対応検定）。
  3. **安定性**: FFN cost の SD。tokid_balance が tokid（0.103）を下回るか。
  4. **最適方針への接近**: FFN cost が 0.425 に近づくか。

baseline: e7_stabilize_7seed.csv（tokid / entropy / balance）、e7_routing_7seed.csv（frozen_ffn / free）
"""
import os, json, time
import numpy as np
import pandas as pd
import torch
from e7_stabilize_task import run, make_lookup_table, ROLE_NAME

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)), d=64, epochs=60)
SEEDS = list(range(7))
OUT = os.path.join(HERE, "e7_tokid_stab_7seed.csv")
LAMS = [0.03, 0.05, 0.08, 0.15, 0.30]
DEV = "cuda" if torch.cuda.is_available() else "cpu"
tab = make_lookup_table(64)

# 組合せアームの spec（e7_stabilize_task.run に直接渡す）
ARMS = {
    "tokid_entropy": dict(route="free", router="linear", stab="entropy", extra="tokid"),
    "tokid_balance": dict(route="free", router="linear", stab="balance", extra="tokid"),
}

rows = []
if os.path.exists(OUT):
    rows = pd.read_csv(OUT).to_dict("records")
have = {(r["variant"], int(r["seed"])) for r in rows}
print(f"device: {DEV}  既存 {len(have)} 件")

todo = [(v, s) for v in ARMS for s in SEEDS if (v, s) not in have]
print(f"追加実行 {len(todo)} 件")

t0 = time.time()
for i, (v, s) in enumerate(todo, 1):
    r = run(v, s, table=tab, device=DEV, spec=ARMS[v], **CFG)
    rows.append(r)
    pd.DataFrame(rows).to_csv(OUT, index=False)
    print(f"  [{i}/{len(todo)}] {v:14s} s{s} | CE {r['ce_all']:.4f} | FFN {r['ffn_cost']:.3f} "
          f"| acc {r['acc_all']:.4f} (ff {r['acc_ff']:.3f} / fr {r['acc_fr']:.3f} / rr {r['acc_rr']:.3f}) "
          f"| {time.time()-t0:.0f}s", flush=True)

df = pd.DataFrame(rows)
df["obj015"] = df["ce_all"] + 0.15 * df["ffn_cost"]
df = df.sort_values(["variant", "seed"]).reset_index(drop=True)
df.to_csv(OUT, index=False)

# baseline 読み込み
a4 = pd.read_csv(os.path.join(HERE, "e7_stabilize_7seed.csv"))
a4["obj015"] = a4["ce_all"] + 0.15 * a4["ffn_cost"]
e7 = pd.read_csv(os.path.join(HERE, "e7_routing_7seed.csv"))
e7["obj015"] = e7["ce_all"] + 0.15 * e7["ffn_cost"]
REF = {
    "frozen_ffn": e7[e7.arm == "frozen_ffn"].set_index("seed"),
    "free": e7[e7.arm == "free"].set_index("seed"),
    "free_entropy": a4[a4.variant == "free_entropy"].set_index("seed"),
    "free_balance": a4[a4.variant == "free_balance"].set_index("seed"),
    "free_tokid": a4[a4.variant == "free_tokid"].set_index("seed"),
}
ALL = ["frozen_ffn", "free", "free_entropy", "free_balance", "free_tokid", "tokid_entropy", "tokid_balance"]

print("\n=== tokid + 安定化の比較（60 epoch・7 seed, d=64, E7 課題, λ=0.15） ===")
print(f"{'arm':16s} {'CE':>16s} {'FFN':>14s} {'obj(λ=.15)':>16s} {'acc':>16s} "
      + " ".join(f"{'acc '+nm:>10s}" for nm in ROLE_NAME.values()))
for a in ALL:
    d = df[df.variant == a].set_index("seed") if a in ARMS else REF[a]
    print(f"{a:16s} {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f}  "
          f"{d['obj015'].mean():.4f}±{d['obj015'].std():.4f}  "
          f"{d['acc_all'].mean():.4f}±{d['acc_all'].std():.4f}  "
          + " ".join(f"{d['acc_'+nm].mean():10.4f}" for nm in ROLE_NAME.values()))

print("\n=== tail リスク（7 seed の最大 CE / CE>0.5 の seed 数 / CE SD） ===")
tail = {}
for a in ALL:
    d = df[df.variant == a].set_index("seed") if a in ARMS else REF[a]
    mx, nbad, sd = float(d["ce_all"].max()), int((d["ce_all"] > 0.5).sum()), float(d["ce_all"].std())
    tail[a] = {"max_ce": mx, "n_catastrophic": nbad, "ce_sd": sd}
    print(f" {a:16s} max CE {mx:.4f}  CE>0.5 の seed {nbad}/7  CE SD {sd:.4f}  "
          f"FFN SD {d['ffn_cost'].std():.3f}")


def paired(d_new, d_base, key):
    d = (d_new[key] - d_base[key]).dropna()
    m, sd = d.mean(), d.std(ddof=1)
    t = m / (sd / np.sqrt(len(d))) if sd > 0 else float("nan")
    rng = np.random.default_rng(0)
    boot = np.array([rng.choice(d.values, len(d), replace=True).mean() for _ in range(20000)])
    lo, hi = np.percentile(boot, [2.5, 97.5])
    return m, lo, hi, t, int((d < 0).sum()), len(d)


print("\n=== seed 対応検定（各組合せ − free_tokid）: 安定化を足す効果 ===")
res_tokid = {}
for a in ARMS:
    da = df[df.variant == a].set_index("seed")
    for k in ("obj015", "ce_all", "ffn_cost"):
        m, lo, hi, t, w, n = paired(da, REF["free_tokid"], k)
        res_tokid[f"{a}_vs_tokid_{k}"] = {"mean": float(m), "ci": [float(lo), float(hi)], "t": float(t), "wins": w}
        print(f" {a:14s} {k:9s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {w}/{n}")

print("\n=== seed 対応検定（各組合せ − frozen_ffn） ===")
res_ffn = {}
for a in ARMS:
    da = df[df.variant == a].set_index("seed")
    for k in ("obj015", "ce_all", "ffn_cost"):
        m, lo, hi, t, w, n = paired(da, REF["frozen_ffn"], k)
        res_ffn[f"{a}_vs_ffn_{k}"] = {"mean": float(m), "ci": [float(lo), float(hi)], "t": float(t), "wins": w}
        print(f" {a:14s} {k:9s} {m:+.4f} [{lo:+.4f},{hi:+.4f}] t={t:+.2f} {w}/{n}")

print("\n=== ルータの役割別 id_rate ===")
print(f"{'arm':16s} " + " ".join(f"{'id '+nm:>10s}" for nm in ROLE_NAME.values()) + f" {'FFN cost':>10s}")
route = {}
for a in ALL:
    d = df[df.variant == a].set_index("seed") if a in ARMS else REF[a]
    print(f"{a:16s} " + " ".join(f"{d['id_rate_'+nm].mean():10.3f}" for nm in ROLE_NAME.values())
          + f" {d['ffn_cost'].mean():10.3f}")
    route[a] = {nm: float(d['id_rate_'+nm].mean()) for nm in ROLE_NAME.values()}

print("\n=== 役割別 CE ===")
print(f"{'arm':16s} {'ce_ff':>8s} {'ce_fr':>8s} {'ce_rr':>8s} {'acc_rr':>8s}")
for a in ALL:
    d = df[df.variant == a].set_index("seed") if a in ARMS else REF[a]
    print(f"{a:16s} {d['ce_ff'].mean():8.4f} {d['ce_fr'].mean():8.4f} {d['ce_rr'].mean():8.4f} "
          f"{d['acc_rr'].mean():8.4f}")

print("\n=== λ 感度（合成目的） ===")
print(f"{'λ':>5s} " + "".join(f"{a:>15s}" for a in ["frozen_ffn", "free_tokid", "tokid_entropy", "tokid_balance"]))
lam_tab = {}
for lam in LAMS:
    vals = {}
    for a in ["frozen_ffn", "free_tokid"]:
        d = REF[a]
        vals[a] = d["ce_all"].mean() + lam * d["ffn_cost"].mean()
    for a in ARMS:
        d = df[df.variant == a]
        vals[a] = d["ce_all"].mean() + lam * d["ffn_cost"].mean()
    lam_tab[str(lam)] = {k: float(x) for k, x in vals.items()}
    print(f"{lam:5.2f} " + "".join(f"{vals[a]:15.4f}" for a in vals))

ce_f = REF["frozen_ffn"]["ce_all"].mean()
print("\n=== crossover λ*（vs 全FFN） ===")
for a in ARMS:
    d = df[df.variant == a]
    ce_r, ff_r = d["ce_all"].mean(), d["ffn_cost"].mean()
    print(f" {a:14s} λ* = {(ce_r - ce_f)/(1.0 - ff_r):+.4f}")

print("\n=== seed 別（CE / FFN cost / id_rr） ===")
for a in ALL:
    d = (df[df.variant == a] if a in ARMS else REF[a]).sort_index()
    print(f" {a:16s} CE  " + " ".join(f"{x:.3f}" for x in d["ce_all"]))
    print(f" {'':16s} FFN " + " ".join(f"{x:.3f}" for x in d["ffn_cost"]))
    print(f" {'':16s} idRR" + " ".join(f"{x:.3f}" for x in d["id_rate_rr"]))

json.dump({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in CFG.items()},
           "device": DEV, "ent_beta": 0.05, "bal_beta": 0.1,
           "summary": {a: {k: float((df[df.variant == a] if a in ARMS else REF[a])[k].mean())
                           for k in ["ce_all", "ffn_cost", "obj015", "acc_all",
                                     "ce_ff", "ce_fr", "ce_rr", "id_rate_ff", "id_rate_fr", "id_rate_rr"]}
                       for a in ALL},
           "tail": tail, "paired_vs_tokid": res_tokid, "paired_vs_ffn": res_ffn,
           "router_id_rates": route, "lambda_sensitivity": lam_tab, "raw": rows},
          open(os.path.join(HERE, "e7_tokid_stab_7seed.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e7_tokid_stab_7seed.csv / .json")
