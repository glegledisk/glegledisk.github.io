"""較正: λ のスケールと収束を b=16, seed 0, 2000 step で確認する。"""
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
EXE = sys.executable

ARMS = ["het_l0", "het_l002", "het_l005", "het_l02", "het_l05"]
out = os.path.join(HERE, "h1_calib.jsonl")
if os.path.exists(out):
    os.remove(out)

for arm in ARMS:
    print(f"=== {arm} ===", flush=True)
    r = subprocess.run([EXE, "h1_hybrid_testbed.py", "--arm", arm, "--b", "16",
                        "--seed", "0", "--steps", "2000", "--out", "h1_calib.jsonl"],
                       cwd=HERE, capture_output=True, text=True, encoding="utf-8")
    print(r.stdout[-1500:], flush=True)
    if r.returncode != 0:
        print(r.stderr[-2000:], flush=True)
