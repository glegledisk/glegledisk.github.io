#!/usr/bin/env python3
"""診断: 強制部分集合で expert の重みが本当に切り替わっているか。"""
import json
import math
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, E2DIR)
from e2_rewrite_routing import RewriteMoE, make_batch, to_seq, SL, OL, V, WIDTHS  # noqa

OUTDIR = os.path.join(E2DIR, "data", "e2")


def main():
    torch.set_num_threads(4)
    arm, seed = "H+LB", 1
    model = RewriteMoE(WIDTHS[arm], seed=seed)
    model.p = {k: v for k, v in torch.load(
        os.path.join(OUTDIR, "ckpt_%s_s%d.pt" % (arm, seed)),
        map_location="cpu").items()}
    for k in model.p:
        model.p[k].requires_grad_(False)

    # 1. expert 重みそのものが違うか
    print("[1] expert 重みの相違（layer 0）")
    w = [model.p["l0.e%d.w1" % i] for i in range(8)]
    for i in range(8):
        for j in range(i + 1, 8):
            if i < 3 and j < 8:
                d = float((w[i][:32] - w[j][:32]).abs().max()) if w[i].shape[0] >= 32 and w[j].shape[0] >= 32 else float("nan")
                print("    e%d vs e%d  max|Δw1| = %.4e" % (i, j, d))

    # 2. 同じ入力に対する expert 出力そのもの
    rng = np.random.default_rng(0)
    x = torch.randn(64, 128) * 0.5
    print("\n[2] 同一入力 64 本に対する expert 出力のノルムと相互差（layer 0）")
    outs = {}
    for i in range(8):
        h1 = F.relu(F.linear(x, model.p["l0.e%d.w1" % i], model.p["l0.e%d.b1" % i]))
        o = F.linear(h1, model.p["l0.e%d.w2" % i], model.p["l0.e%d.b2" % i])
        outs[i] = o
        print("    e%d  width=%3d  ||o||=%.4f" % (i, WIDTHS[arm][i], o.norm(dim=1).mean()))
    for (i, j) in [(2, 3), (2, 6), (6, 7), (3, 7)]:
        print("    max|o_%d − o_%d| = %.4e" % (i, j, float((outs[i] - outs[j]).abs().max())))

    # 3. 実際の forward で per-token CE が違うか
    ev = np.random.default_rng(777)
    src, out, em, _ = make_batch(ev, 64)
    xin = to_seq(src, out)
    tgt = torch.from_numpy(out)

    def ce_for(force):
        p = model.p
        B, T = xin.shape
        h = p["emb.w"][xin] + p["pos.w"][:T].unsqueeze(0)
        h = h.reshape(B * T, -1)
        causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
        gates_seen = []
        for l in range(model.L):
            hb = h.reshape(B, T, -1)
            q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
            kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
            v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
            att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
            att = att.masked_fill(causal, float("-inf")).softmax(-1)
            o = (att @ v).transpose(1, 2).reshape(B, T, -1)
            h = hb + F.linear(o, p[f"l{l}.o.w"])
            h = h.reshape(B * T, -1)
            logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
            topi = torch.tensor(list(force), dtype=torch.long).expand(h.shape[0], -1)
            topv = logits.gather(1, topi)
            gate = torch.softmax(
                torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
            gates_seen.append(gate.mean(0)[list(force)].tolist())
            y = torch.zeros_like(h)
            for i in range(model.E):
                tok, slot = (topi == i).nonzero(as_tuple=True)
                if tok.numel() == 0:
                    continue
                xx = h[tok]
                h1 = F.relu(F.linear(xx, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
                y.index_add_(0, tok,
                             F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                             * gate[tok, slot].unsqueeze(1))
            h = h + y
        lo = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, V)
        lg = lo[:, SL:SL + OL, :]
        lp = F.cross_entropy(lg.reshape(-1, V), tgt.reshape(-1), reduction="none")
        return float(lp.mean()), gates_seen, h

    print("\n[3] forward の CE とゲート（layer 0 の平均ゲート重み）")
    hs = {}
    for force in [(2, 3), (6, 7), (4, 6), (0, 1)]:
        c, g, hh = ce_for(force)
        hs[force] = hh
        print("    force=%-8s CE %.6f  gate(L0)=%s" % (str(force), c,
                                                      ["%.3f" % v for v in g[0]]))
    print("\n    最終隠れ状態の差:")
    for f in [(6, 7), (4, 6)]:
        print("    max|h_(2,3) − h_%-8s| = %.4e" % (str(f), float((hs[(2, 3)] - hs[f]).abs().max())))

    os._exit(0)


if __name__ == "__main__":
    main()
