# -*- coding: utf-8 -*-
"""
P6a: 決定損失の下で「計算の価値」はどこにあるか（H1 の検証）

H1（考察_HMoEと決定モデルJev_20261027.md §6）:
    決定モデルでは計算の価値が閾値近傍で最大になり、p<0.1 ではゼロ。
    反証条件: 価値が最難関（低 p）で最大になる＝CE 型。

設計:
  Jev の Noul（確率つき yes/no）＋ 閾値分流（p>=τ なら自動、未満は人へ）を
  言語モデルの次トークン予測に写像する。2 つの「質問」を同時に測る。

  Q1 commit  : p = p_top1,  y = 1{argmax が正解}
               → 「自信があるから自動で出す／自信が無いから人に回す」
  Q2 top5    : p = top-5 の確率質量, y = 1{正解が top-5 に入る}
               → 「候補集合を確定して出す／人に回す」

  コスト: 自動で出して外したら c_W=1、人に回したら c_A=1-τ。
  最適規則は commit iff p >= τ（c_W(1-p) < c_A の解）。

  各トークン j、各 τ について realized cost を計算し、k を削ったときの
  差分 v_j(τ) = cost_j(τ; k_low) - cost_j(τ; k_high) を「計算の価値」とする。
  v>0 なら計算が助けた、v<0 なら計算が損をした（＝賭けに負けた）。

出力:
  p6a_decision_curve.npz / p6a_decision_curve.json / p6a_decision_curve.png
  p6a_out_utf8.txt

実行:
  python p6a_decision_curve.py --windows 24 --len 256 --ks 8,7,6,4
"""

import argparse
import json
import math
import os
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = []


def decision_cost(p, y, tau):
    """閾値分流の realized cost（1 判断あたり）。

    規則: p >= tau なら自動で出す（commit）、そうでなければ人に回す（abstain）。
    コスト: commit して外したら 1、abstain なら (1 - tau)、当たれば 0。
    tau = 1 - c_A/c_W は「commit と abstain が無差別になる確率」なので、
    この規則は c_W=1, c_A=1-tau の下での最適規則になっている。
    """
    p = np.asarray(p, float)
    y = np.asarray(y, float)
    commit = p >= tau
    return commit * (1.0 - y) + (1.0 - tau) * (~commit)


def log(msg):
    print(msg, flush=True)
    LOG.append(str(msg))


def load_corpus(lang, max_chars=400000):
    """p3_topk_quality_olmoe.py と同一のコーパス（スライスも同一にする）。"""
    import glob
    import re
    if lang == "en":
        return load_wikitext2()
    files = [f for f in sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True))
             if "english_version" not in f]
    parts = []
    for f in files:
        try:
            with open(f, "r", encoding="utf-8") as fp:
                txt = fp.read()
        except Exception:
            continue
        txt = re.sub(r"```.*?```", " ", txt, flags=re.S)
        txt = re.sub(r"<!--.*?-->", " ", txt, flags=re.S)
        txt = re.sub(r"^\s*\|[-: ]+\|.*$", " ", txt, flags=re.M)
        parts.append(txt)
        if sum(len(p) for p in parts) >= max_chars:
            break
    return "\n\n".join(parts)


WT_CACHE = os.path.join(HERE, "wikitext2_test.txt")


def load_wikitext2(n_rows=2000, cache=WT_CACHE):
    if os.path.exists(cache) and os.path.getsize(cache) > 100000:
        with open(cache, "r", encoding="utf-8") as fp:
            return fp.read()
    import urllib.request
    rows = []
    off = 0
    while off < n_rows:
        u = ("https://datasets-server.huggingface.co/rows?dataset=Salesforce%2Fwikitext"
             "&config=wikitext-2-raw-v1&split=test&offset=" + str(off) + "&length=100")
        try:
            d = json.loads(urllib.request.urlopen(u, timeout=90).read())
        except Exception as e:
            log("      wikitext fetch failed at %d: %s" % (off, e))
            break
        rs = d.get("rows", [])
        if not rs:
            break
        rows.extend(r["row"]["text"] for r in rs)
        off += 100
    txt = "\n\n".join(rows)
    with open(cache, "w", encoding="utf-8") as fp:
        fp.write(txt)
    return txt


def ttest_rel(a, b):
    d = np.asarray(a, float) - np.asarray(b, float)
    n = d.size
    sd = d.std(ddof=1)
    se = sd / math.sqrt(n) if n > 1 else float("nan")
    t = d.mean() / se if se > 0 else float("nan")
    return float(d.mean()), float(se), float(t)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--ks", type=str, default="8,7,6,4")
    ap.add_argument("--seed", type=int, default=11, help="P3 と同一スライス")
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()

    ks = [int(x) for x in args.ks.split(",")]
    rng = np.random.RandomState(args.seed)
    import torch
    torch.manual_seed(args.seed)

    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[1/4] loading %s" % args.model)
    t0 = time.time()
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      loaded in %.0f s" % (time.time() - t0))

    n_layers = int(model.config.num_hidden_layers)
    FULL_K = int(model.config.num_experts_per_tok)
    gates = [layer.mlp.gate for layer in model.model.layers]
    log("      layers=%d full_k=%d" % (n_layers, FULL_K))

    # ---- コーパス（P3 と同一スライス） ----
    log("[2/4] building corpus (seed=%d)" % args.seed)
    seqs = []
    n_win = 1 if args.smoke else args.windows
    for lang in ("en", "ja"):
        txt = load_corpus(lang)
        ids = tok(txt, return_tensors="pt", add_special_tokens=False).input_ids[0]
        if ids.numel() < args.len:
            log("      %s: too short -> SKIP" % lang)
            continue
        need = n_win * args.len
        start = 0 if ids.numel() < need else int(rng.randint(0, ids.numel() - need))
        block = ids[start:start + need]
        for w in range(n_win):
            seqs.append((lang, block[w * args.len:(w + 1) * args.len]))
        log("      %s: [%d, %d)" % (lang, start, start + need))
    n_tok = len(seqs) * args.len
    log("      %d windows x %d = %d tokens" % (len(seqs), args.len, n_tok))
    lang_arr = np.array([s[0] for s in seqs])

    # ---- forward ----
    log("[3/4] forward")
    store = {}
    for k in ks:
        for i, g in enumerate(gates):
            g.top_k = k
        t1 = time.time()
        ch = {key: [] for key in ("nll", "ptop1", "top1", "mass5", "in5")}
        with torch.no_grad():
            for lang, ids in seqs:
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                lg = out.logits[0, :-1].float()          # (L, V)
                tgt = x[0, 1:]
                # softmax を実体化しない（(L,V) の float32 softmax は 51MB×2 で OOM の主因）
                logZ = torch.logsumexp(lg, dim=-1)                        # (L,)
                true_l = lg.gather(1, tgt.unsqueeze(-1)).squeeze(-1)      # (L,)
                nll = logZ - true_l
                rank = (lg > true_l.unsqueeze(-1)).sum(dim=-1) + 1        # 真のトークンの順位
                top1_l, top1 = lg.max(dim=-1)
                ptop1 = torch.exp(top1_l - logZ)
                top5_l = torch.topk(lg, 5, dim=-1).values
                mass5 = torch.exp(torch.logsumexp(top5_l, dim=-1) - logZ)
                ch["nll"].append(nll.cpu().numpy())
                ch["ptop1"].append(ptop1.cpu().numpy())
                ch["top1"].append((rank == 1).float().cpu().numpy())
                ch["mass5"].append(mass5.cpu().numpy())
                ch["in5"].append((rank <= 5).float().cpu().numpy())
                del out, lg, logZ, true_l, rank, top5_l
                if torch.cuda.is_available():
                    torch.cuda.empty_cache()
        store[k] = {key: np.concatenate(v) for key, v in ch.items()}
        log("      k=%d  CE %.5f  top1 %.4f  p_top1 %.4f  mass5 %.4f  in5 %.4f  (%.0f s)"
            % (k, store[k]["nll"].mean(), store[k]["top1"].mean(),
               store[k]["ptop1"].mean(), store[k]["mass5"].mean(),
               store[k]["in5"].mean(), time.time() - t1))

    base = ks[0]
    log("      baseline check: CE=%.5f (P3 報告値 2.60047)" % store[base]["nll"].mean())

    np.savez_compressed(
        os.path.join(HERE, "p6a_decision_curve.npz"),
        lang=lang_arr,
        **{("k%d_%s" % (k, key)): store[k][key] for k in ks for key in store[k]})

    # ---- 解析 ----
    log("[4/4] decision analysis")
    TAU = [0.5, 0.6, 0.7, 0.8, 0.9, 0.95]
    EDGES = np.round(np.arange(0.0, 1.0001, 0.1), 2)
    out = {"n_tokens": int(n_tok), "ks": ks, "tau": TAU,
           "baseline_ce": float(store[base]["nll"].mean())}

    def conf(q, k):
        return store[k]["ptop1"] if q == "Q1" else store[k]["mass5"]

    def lab(q, k):
        return store[k]["top1"] if q == "Q1" else store[k]["in5"]

    res = {}
    for q in ("Q1", "Q2"):
        pname = "ptop1" if q == "Q1" else "mass5"
        p8 = store[base][pname]
        b = np.clip(np.digitize(p8, EDGES) - 1, 0, len(EDGES) - 2)
        res[q] = {"edges": EDGES.tolist(), "by_tau": {}}
        log("")
        log("=== %s (confidence = %s) ===" % (q, pname))
        log("confidence 分布: " + " ".join(
            "%.1f-%.1f:%d" % (EDGES[i], EDGES[i + 1], int((b == i).sum()))
            for i in range(len(EDGES) - 1)))
        for tau in TAU:
            row = {"loss": {}, "v_by_bin": [], "v_total": None}
            for k in ks:
                row["loss"][str(k)] = float(decision_cost(conf(q, k), lab(q, k), tau).mean())
            c_hi = decision_cost(conf(q, base), lab(q, base), tau)
            c_lo = decision_cost(conf(q, ks[-1]), lab(q, ks[-1]), tau)
            v = c_lo - c_hi
            for i in range(len(EDGES) - 1):
                m = b == i
                if m.sum() == 0:
                    row["v_by_bin"].append(None)
                    continue
                row["v_by_bin"].append(dict(
                    lo=float(EDGES[i]), hi=float(EDGES[i + 1]), n=int(m.sum()),
                    v=float(v[m].mean()), pos=float((v[m] > 1e-9).mean()),
                    neg=float((v[m] < -1e-9).mean()),
                    zero=float((np.abs(v[m]) <= 1e-9).mean())))
            m, se, t = ttest_rel(c_lo, c_hi)
            row["v_total"] = dict(mean=m, se=se, t=t,
                                  pos=float((v > 1e-9).mean()),
                                  neg=float((v < -1e-9).mean()))
            best = max((x for x in row["v_by_bin"] if x), key=lambda x: x["v"])
            row["peak"] = best
            res[q]["by_tau"][str(tau)] = row
            log("tau=%.2f  loss k%d=%.5f k%d=%.5f  V_total=%+.6f (t=%+.2f)  "
                "助けた %.1f%% / 損した %.1f%%  ピーク bin %.1f-%.1f (V=%+.6f)"
                % (tau, base, row["loss"][str(base)], ks[-1], row["loss"][str(ks[-1])],
                   row["v_total"]["mean"], row["v_total"]["t"],
                   100 * row["v_total"]["pos"], 100 * row["v_total"]["neg"],
                   best["lo"], best["hi"], best["v"]))
        # CE の参照: 同じ p ビンでの ΔCE（k=8 -> k=4）
        dce = store[ks[-1]]["nll"] - store[base]["nll"]
        ce_bins = []
        for i in range(len(EDGES) - 1):
            m = b == i
            ce_bins.append(None if m.sum() == 0 else
                           dict(lo=float(EDGES[i]), hi=float(EDGES[i + 1]),
                                n=int(m.sum()), v=float(dce[m].mean())))
        res[q]["ce_by_bin"] = ce_bins
        bestc = max((x for x in ce_bins if x), key=lambda x: x["v"])
        res[q]["ce_peak"] = bestc
        log("CE 参照: ピーク bin %.1f-%.1f (dCE=%+.5f)"
            % (bestc["lo"], bestc["hi"], bestc["v"]))
    out["results"] = res

    with open(os.path.join(HERE, "p6a_decision_curve.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    with open(os.path.join(HERE, "p6a_out_utf8.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(LOG))

    # ---- 図 ----
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.3), dpi=140)
        for q, col in (("Q1", "C0"), ("Q2", "C3")):
            bins = [x for x in res[q]["by_tau"]["0.8"]["v_by_bin"] if x]
            xs = [(x["lo"] + x["hi"]) / 2 for x in bins]
            ax[0].plot(xs, [x["v"] for x in bins], "o-", color=col,
                       label="%s, tau=0.8" % q)
            cb = [x for x in res[q]["ce_by_bin"] if x]
            ax[1].plot([(x["lo"] + x["hi"]) / 2 for x in cb], [x["v"] for x in cb],
                       "s--", color=col, label="%s dCE" % q)
        ax[0].axvline(0.8, color="gray", ls=":", lw=1)
        ax[0].axhline(0, color="gray", lw=0.6)
        ax[0].set_xlabel("baseline confidence p (k=8)")
        ax[0].set_ylabel("value of compute  v = cost(k=%d) - cost(k=%d)" % (ks[-1], base))
        ax[0].set_title("Decision loss: value concentrates at the threshold")
        ax[0].legend(fontsize=8)
        ax[0].grid(alpha=0.3)
        ax[1].set_xlabel("baseline confidence p (k=%d)" % base)
        ax[1].set_ylabel("dCE (k=%d -> k=%d)" % (base, ks[-1]))
        ax[1].set_title("CE: value is at the low-confidence end")
        ax[1].legend(fontsize=8)
        ax[1].grid(alpha=0.3)
        fig.tight_layout()
        fig.savefig(os.path.join(HERE, "p6a_decision_curve.png"))
        log("saved p6a_decision_curve.png")
    except Exception as e:
        log("figure failed: %s" % e)

    log("done")
    import sys
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
