"""
P3: top-8 -> top-k に削ったときの品質（実推論）

問い: P2b で「層ごとに最下位 Expert を落としても CE は ±0.01 nats」だった。
     それは 1 層ずつの局所測定。**全 16 層で同時に削ると品質はどうなるか。**
     さらに top-7 / 6 / 4 / 2 / 1 まで削って、品質が壊れる境界を探す。

実装:
  OlmoeTopKRouter.forward は self.top_k を参照するので、
  gate.top_k を書き換えるだけで厳密な top-k 介入になる（再実装なし・同一コードパス）。
  norm_topk_prob=False なので再正規化は起きない＝落とした Expert の重みぶん
  FFN 出力がそのまま縮む。この「捨てた確率質量」も同時に測る。

統計:
  同一トークン上での **paired 差** (NLL_k - NLL_8) を主統計量にする。
  token 単位の CE は分散が大きい（sd ~3 nats）ので、独立平均では 8000 token でも
  SE 0.03 程度にしかならない。paired 差なら桁で小さくなる。

出力:
  p3_topk_summary.json     k ごとの CE / PPL / ΔCE / paired t / 質量
  p3_topk_nll.npz          k ごとの per-token NLL（再解析用）
  p3_topk_by_lang.csv      言語別

実行:
  python p3_topk_quality_olmoe.py --windows 16 --len 256 --ks 8,7,6,4,2,1
"""

import argparse
import glob
import json
import os
import re
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_ID = "allenai/OLMoE-1B-7B-0924"


def log(msg):
    print(msg, flush=True)


def load_corpus(lang, max_chars=400000):
    """ja: プロジェクト内 Markdown / en: wikitext-2 test（標準ベンチマーク）。"""
    if lang == "en":
        return load_wikitext2()
    files = [f for f in sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True))
             if "english_version" not in f]
    parts = []
    for f in files:
        try:
            with open(f, "r", encoding="utf-8") as fp:
                txt = fp.read()
        except Exception:
            continue
        txt = re.sub(r"```.*?```", " ", txt, flags=re.S)
        txt = re.sub(r"<!--.*?-->", " ", txt, flags=re.S)
        txt = re.sub(r"^\s*\|[-: ]+\|.*$", " ", txt, flags=re.M)
        parts.append(txt)
        if sum(len(p) for p in parts) >= max_chars:
            break
    return "\n\n".join(parts)


WT_CACHE = os.path.join(HERE, "wikitext2_test.txt")


def load_wikitext2(n_rows=2000, cache=WT_CACHE):
    """wikitext-2-raw-v1 test を datasets-server から取得してキャッシュする。"""
    if os.path.exists(cache) and os.path.getsize(cache) > 100000:
        with open(cache, "r", encoding="utf-8") as fp:
            return fp.read()
    import urllib.request
    rows = []
    off = 0
    while off < n_rows:
        u = ("https://datasets-server.huggingface.co/rows?dataset=Salesforce%2Fwikitext"
             "&config=wikitext-2-raw-v1&split=test&offset=" + str(off) + "&length=100")
        try:
            d = json.loads(urllib.request.urlopen(u, timeout=90).read())
        except Exception as e:
            log("      wikitext fetch failed at %d: %s" % (off, e))
            break
        rs = d.get("rows", [])
        if not rs:
            break
        rows.extend(r["row"]["text"] for r in rs)
        off += 100
    txt = "\n\n".join(rows)
    with open(cache, "w", encoding="utf-8") as fp:
        fp.write(txt)
    log("      wikitext-2 test: %d rows, %d chars cached" % (len(rows), len(txt)))
    return txt


def paired_stats(a, b):
    """a - b の平均・SE・t（同一要素の対応あり差）。"""
    d = np.asarray(a, dtype=np.float64) - np.asarray(b, dtype=np.float64)
    n = d.size
    m = float(d.mean())
    sd = float(d.std(ddof=1)) if n > 1 else float("nan")
    se = sd / np.sqrt(n) if n > 1 else float("nan")
    t = m / se if se and se > 0 else float("nan")
    return {"mean": m, "se": se, "t": t, "n": int(n), "sd": sd,
            "ci95": [m - 1.96 * se, m + 1.96 * se] if se and se > 0 else None}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=16, help="言語あたりのウィンドウ数")
    ap.add_argument("--len", type=int, default=256, help="ウィンドウのトークン長")
    ap.add_argument("--ks", type=str, default="8,7,6,4,2,1")
    ap.add_argument("--seed", type=int, default=11, help="P1 と別のスライスを使う")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--rescale", action="store_true",
                    help="top-k を削ったあと k=8 と同じ確率質量に再スケール（出力スケールを固定し内容だけ削る）")
    ap.add_argument("--cut-layers", type=str, default="all",
                    help="top-k を適用する層の範囲。'all' か '0-7' / '0-3,12-15' のような指定")
    ap.add_argument("--tag", type=str, default="p3")
    args = ap.parse_args()

    ks = [int(x) for x in args.ks.split(",")]
    rng = np.random.RandomState(args.seed)
    torch.manual_seed(args.seed)

    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[1/5] loading tokenizer/model: " + args.model)
    t0 = time.time()
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=torch.bfloat16,
        device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      loaded in %.0f s" % (time.time() - t0))
    try:
        dm = {str(k): str(v) for k, v in model.hf_device_map.items()}
        log("      device_map: %s" % json.dumps(dm))
    except Exception:
        dm = {}

    n_experts = int(model.config.num_experts)
    n_layers = int(model.config.num_hidden_layers)
    d_model = int(model.config.hidden_size)
    d_ff = int(model.config.intermediate_size)
    log("      experts=%d layers=%d d=%d d_ff=%d" % (n_experts, n_layers, d_model, d_ff))

    gates = [layer.mlp.gate for layer in model.model.layers]
    for g in gates:
        if not hasattr(g, "top_k"):
            raise RuntimeError("gate に top_k がない（transformers の実装が変わった可能性）")

    FULL_K = int(model.config.num_experts_per_tok)

    # --cut-layers: どの層に top-k 削減を適用するか（他は k=8 のまま）
    if args.cut_layers.strip().lower() in ("all", "", "0-15"):
        CUT = set(range(n_layers))
    else:
        CUT = set()
        for part in args.cut_layers.split(","):
            part = part.strip()
            if "-" in part:
                a, b = part.split("-")
                CUT.update(range(int(a), int(b) + 1))
            elif part:
                CUT.add(int(part))
    log("      cut layers: %d/%d %s" % (len(CUT), n_layers,
                                        "all" if len(CUT) == n_layers else sorted(CUT)))

    # --rescale: 削ったあとに「k=8 のときと同じ確率質量」へ戻す介入。
    #   これで FFN 出力の大きさを固定し、落とした Expert の「内容」だけを測れる。
    #   注意: device_map="auto" では accelerate が各モジュールの forward を
    #   インスタンス属性として差し替えるため、**クラス側のパッチは効かない**。
    #   インスタンスの forward を包み直す必要がある。
    if args.rescale:
        FULL_K = int(model.config.num_experts_per_tok)

        def _make_rescaled(orig):
            def _patched(hidden_states):
                logits, scores, idx = orig(hidden_states)
                if scores.shape[-1] < FULL_K:
                    probs = torch.softmax(logits.float(), dim=-1)
                    m_full = torch.topk(probs, FULL_K, dim=-1).values.sum(-1, keepdim=True)
                    m_now = scores.float().sum(-1, keepdim=True).clamp_min(1e-9)
                    scores = (scores.float() * (m_full / m_now)).to(scores.dtype)
                return logits, scores, idx
            return _patched

        for g in gates:
            g.forward = _make_rescaled(g.forward)
        log("      RESCALE mode: 削減後 k=8 と同じ確率質量へ再スケール（FULL_K=%d, %d gates）"
            % (FULL_K, len(gates)))

    # ---- ルーティング統計を取るフック（選択された top-k 重みの和＝保持した確率質量）----
    route_stats = {"mass": [], "rank_last": []}

    def make_hook(layer_idx):
        def hook(module, inp, out):
            scores = out[1]           # (N, k) top-k 重み
            idx = out[2]              # (N, k) top-k Expert index
            route_stats["mass"].append(scores.detach().float().sum(-1).cpu())
            route_stats["rank_last"].append(idx.detach()[:, -1].cpu())
        return hook

    handles = [g.register_forward_hook(make_hook(i)) for i, g in enumerate(gates)]

    # ---- コーパス ----
    log("[2/5] building corpus")
    seqs = []
    n_win = 1 if args.smoke else args.windows
    for lang in ("en", "ja"):
        txt = load_corpus(lang)
        ids = tok(txt, return_tensors="pt", add_special_tokens=False).input_ids[0]
        if ids.numel() < args.len:
            log("      %s: only %d tokens -> SKIP" % (lang, ids.numel()))
            continue
        need = n_win * args.len
        if ids.numel() < need:
            start = 0
        else:
            start = int(rng.randint(0, ids.numel() - need))
        block = ids[start:start + need]
        for w in range(n_win):
            seqs.append((lang, block[w * args.len:(w + 1) * args.len]))
        log("      %s: corpus %d tokens, using [%d, %d)" % (lang, ids.numel(), start, start + need))
    log("      %d windows x %d tokens = %d tokens" % (len(seqs), args.len, len(seqs) * args.len))

    # ---- 各 k で forward ----
    results = {}
    nll_store = {}
    lang_store = []
    for lang, _ in seqs:
        lang_store.append(lang)
    lang_arr = np.array(lang_store)

    def run_k(k):
        for i, g in enumerate(gates):
            g.top_k = k if i in CUT else FULL_K
        route_stats["mass"].clear()
        route_stats["rank_last"].clear()
        nll_chunks, acc1_chunks, acc5_chunks, mrr_chunks = [], [], [], []
        t_start = time.time()
        with torch.no_grad():
            for wi, (lang, ids) in enumerate(seqs):
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                lg = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(lg, tgt, reduction="none")
                # 下流寄りの指標（追加コストなし）: top-1 / top-5 / MRR
                tgt_v = tgt.unsqueeze(-1)
                true_l = lg.gather(1, tgt_v)
                rank = (lg > true_l).sum(dim=-1) + 1          # 真のトークンの順位
                acc1_chunks.append((rank == 1).float().cpu().numpy())
                acc5_chunks.append((rank <= 5).float().cpu().numpy())
                mrr_chunks.append((1.0 / rank.float()).cpu().numpy())
                nll_chunks.append(nll.float().cpu().numpy())
                del out, lg, rank
        nll = np.concatenate(nll_chunks)
        mass = torch.cat(route_stats["mass"]).numpy()
        rank_last = torch.stack(route_stats["rank_last"]).numpy()   # (layers, N)
        dt = time.time() - t_start
        acc1 = np.concatenate(acc1_chunks)
        acc5 = np.concatenate(acc5_chunks)
        mrr = np.concatenate(mrr_chunks)
        log("      k=%2d  CE %.5f  PPL %8.3f  top1 %.4f  top5 %.4f  MRR %.4f  mass %.4f  (%.0f s)"
            % (k, nll.mean(), float(np.exp(nll.mean())), acc1.mean(), acc5.mean(), mrr.mean(), mass.mean(), dt))
        return {"nll": nll, "mass": mass, "rank_last": rank_last,
                "acc1": acc1, "acc5": acc5, "mrr": mrr}

    log("[3/5] forward passes")
    for k in ks:
        if k > n_experts:
            log("      skip k=%d (> num_experts)" % k)
            continue
        results[k] = run_k(k)
    for h in handles:
        h.remove()

    # ---- 集計 ----
    log("[4/5] paired statistics")
    base_k = ks[0]
    base_nll = results[base_k]["nll"]
    summary = {
        "model": args.model,
        "seed": args.seed,
        "windows_per_lang": n_win,
        "window_len": args.len,
        "n_tokens": int(base_nll.size),
        "n_experts": n_experts,
        "n_layers": n_layers,
        "rescale": bool(args.rescale),
        "cut_layers": sorted(CUT),
        "n_cut_layers": len(CUT),
        "device_map": dm,
        "results": {},
    }
    for k in ks:
        if k not in results:
            continue
        nll = results[k]["nll"]
        row = {
            "ce": float(nll.mean()),
            "ppl": float(np.exp(nll.mean())),
            "top1": float(results[k]["acc1"].mean()),
            "top5": float(results[k]["acc5"].mean()),
            "mrr": float(results[k]["mrr"].mean()),
            "mass_kept": float(results[k]["mass"].mean()),
            "n_tokens": int(nll.size),
            "per_lang": {},
        }
        for lang in ("en", "ja"):
            sel = (lang_arr == lang)
            # 言語別はウィンドウ単位の平均 CE で見る（token 数が等しいので単純平均でよい）
            ce_l = float(nll.reshape(len(seqs), -1)[sel].mean())
            row["per_lang"][lang] = {"ce": ce_l, "ppl": float(np.exp(ce_l))}
        if k != base_k:
            st = paired_stats(nll, base_nll)
            row["delta_ce"] = st
            row["ppl_ratio"] = float(np.exp(st["mean"]))
            row["delta_top1"] = paired_stats(results[k]["acc1"], results[base_k]["acc1"])
            row["delta_mrr"] = paired_stats(results[k]["mrr"], results[base_k]["mrr"])
            row["per_lang_delta"] = {}
            for lang in ("en", "ja"):
                sel = (lang_arr == lang)
                a = nll.reshape(len(seqs), -1)[sel].ravel()
                b = base_nll.reshape(len(seqs), -1)[sel].ravel()
                row["per_lang_delta"][lang] = paired_stats(a, b)
        summary["results"][str(k)] = row

    # top-k を削ったときの「捨てた確率質量」
    for k in ks:
        if k not in results:
            continue
        m = float(results[k]["mass"].mean())
        summary["results"][str(k)]["dropped_mass"] = 1.0 - m

    # k=8 のとき「8 番目に選ばれた Expert」の分布（層別）
    if base_k in results:
        rl = results[base_k]["rank_last"]        # (n_windows*n_layers, N) window-major
        n_win_total = len(seqs)
        rl = rl.reshape(n_win_total, n_layers, -1).transpose(1, 0, 2).reshape(n_layers, -1)
        hist = []
        for L in range(rl.shape[0]):
            counts = np.bincount(rl[L], minlength=n_experts) / rl.shape[1]
            top = np.argsort(-counts)[:3]
            hist.append({
                "layer": L,
                "top3": [[int(i), float(counts[i])] for i in top],
                "n_experts_used": int((counts > 0.001).sum()),
                "max_share": float(counts.max()),
            })
        summary["rank8_expert_hist"] = hist
        allc = np.bincount(rl.reshape(-1), minlength=n_experts) / rl.size
        summary["rank8_expert_overall"] = {
            "max_share": float(allc.max()),
            "argmax": int(allc.argmax()),
            "n_used_gt_0.1pct": int((allc > 0.001).sum()),
            "n_used_gt_1pct": int((allc > 0.01).sum()),
        }

    # ---- 保存 ----
    np.savez_compressed(os.path.join(HERE, "%s_topk_nll.npz" % args.tag),
                        **{"k%d" % k: results[k]["nll"] for k in ks if k in results},
                        **{"k%d_top1" % k: results[k]["acc1"] for k in ks if k in results},
                        lang=lang_arr)
    with open(os.path.join(HERE, "%s_topk_summary.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)

    with open(os.path.join(HERE, "%s_topk_by_lang.csv" % args.tag), "w", encoding="utf-8") as fp:
        fp.write("k,ce,ppl,delta_ce,delta_se,delta_t,top1,top5,mrr,dtop1,dmrr,ce_en,ce_ja,mass_kept,dropped_mass\n")
        for k in ks:
            if k not in results:
                continue
            r = summary["results"][str(k)]
            d = r.get("delta_ce", {})
            dt1 = r.get("delta_top1", {})
            dm = r.get("delta_mrr", {})
            fp.write("%d,%.6f,%.4f,%s,%s,%s,%.5f,%.5f,%.5f,%s,%s,%.6f,%.6f,%.5f,%.5f\n" % (
                k, r["ce"], r["ppl"],
                ("%.6f" % d["mean"]) if d else "",
                ("%.6f" % d["se"]) if d else "",
                ("%.2f" % d["t"]) if d else "",
                r["top1"], r["top5"], r["mrr"],
                ("%+.6f" % dt1["mean"]) if dt1 else "",
                ("%+.6f" % dm["mean"]) if dm else "",
                r["per_lang"]["en"]["ce"], r["per_lang"]["ja"]["ce"],
                r["mass_kept"], r["dropped_mass"]))

    # ---- 表示 ----
    log("")
    log("=== SUMMARY (baseline k=%d, %d tokens) ===" % (base_k, summary["n_tokens"]))
    log("%4s %10s %10s %11s %8s %9s %9s %9s %9s" % ("k", "CE", "PPL", "dCE", "t", "top1", "top5", "MRR", "mass"))
    for k in ks:
        if k not in results:
            continue
        r = summary["results"][str(k)]
        d = r.get("delta_ce", {})
        log("%4d %10.5f %10.3f %11s %8s %9.4f %9.4f %9.4f %9.4f" % (
            k, r["ce"], r["ppl"],
            ("%+.5f" % d["mean"]) if d else "  (base)",
            ("%+.1f" % d["t"]) if d else "",
            r["top1"], r["top5"], r["mrr"], r["mass_kept"]))
    log("")
    log("saved: %s_topk_summary.json / %s_topk_nll.npz / %s_topk_by_lang.csv"
        % (args.tag, args.tag, args.tag))


if __name__ == "__main__":
    main()
