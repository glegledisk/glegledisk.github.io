"""
P1: 実 MoE の dead zone 検証（allenai/OLMoE-1B-7B-0924）

問い: 学習済み MoE のルータに「logit b のゼロ計算 Expert（identity）」を追加したとき、
     top-k に入る（＝コスト圧力の勾配が届く）トークンの割合はどれだけか。

根拠（テストベッドの確定知見, 2026-10-25）:
  - in-zone 率とオフロード率（id_rate）が全アーム・全 seed で完全一致（max 差 0.0000）
  - identity logit が top-k 外だとコスト勾配が届かず、方策は初期値で凍結する
  - バイアス b=1.0 で凍結は解けた（id_ff 0.451→0.665、CE 不変）
  → 実 MoE でも in-zone 率が ~0 なら dead zone は構造（訓練の産物ではない）

出力（プロジェクトルート）:
  p1_olmoe_logits_layer{L}.npy   層別の生 router logits（n_tokens × 64）
  p1_olmoe_by_layer.csv          層別サマリ
  p1_olmoe_summary.json          全体サマリ
  p1_olmoe_margin.png            閾値分布・必要バイアス

実行:
  python p1_deadzone_probe_olmoe.py --windows 8 --len 256 --smoke
"""

import argparse
import glob
import json
import os
import random
import re
import sys

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL_ID = "allenai/OLMoE-1B-7B-0924"


def log(msg):
    print(msg, flush=True)


def load_corpus(lang, max_chars=400000):
    """プロジェクト内の Markdown から自然テキストを集める（英語版 / 日本語版）。"""
    if lang == "en":
        files = sorted(glob.glob(os.path.join(HERE, "english_version", "**", "*.md"), recursive=True))
    else:
        files = [f for f in sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True))
                 if "english_version" not in f]
    parts = []
    for f in files:
        try:
            with open(f, "r", encoding="utf-8") as fp:
                txt = fp.read()
        except Exception:
            continue
        # コードフェンス・HTML コメント・テーブル区切りを落とす
        txt = re.sub(r"```.*?```", " ", txt, flags=re.S)
        txt = re.sub(r"<!--.*?-->", " ", txt, flags=re.S)
        txt = re.sub(r"^\s*\|[-: ]+\|.*$", " ", txt, flags=re.M)
        parts.append(txt)
        if sum(len(p) for p in parts) >= max_chars:
            break
    return "\n\n".join(parts)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=MODEL_ID, help="モデル ID またはローカルパス")
    ap.add_argument("--windows", type=int, default=8, help="言語あたりのウィンドウ数")
    ap.add_argument("--len", type=int, default=256, help="ウィンドウのトークン長")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--smoke", action="store_true", help="1 ウィンドウだけ実行（動作確認）")
    ap.add_argument("--no-quant", action="store_true", help="（互換用）量子化しない")
    ap.add_argument("--tag", type=str, default="olmoe", help="出力ファイルの接頭辞")
    ap.add_argument("--gpu-gib", type=float, default=7.2, help="GPU に載せる上限 GiB")
    ap.add_argument("--cpu-gib", type=float, default=9.0, help="CPU に載せる上限 GiB")
    ap.add_argument("--quant", action="store_true",
                    help="bnb 8bit を使う（Expert が nn.Parameter 直持ちの OLMoE では実質効かない）")
    args = ap.parse_args()

    rng = random.Random(args.seed)
    torch.manual_seed(args.seed)

    from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

    log("[1/4] loading tokenizer/model: " + args.model)
    tok = AutoTokenizer.from_pretrained(args.model)
    load_kwargs = dict(torch_dtype=torch.bfloat16)
    if args.quant:
        qconf = BitsAndBytesConfig(load_in_8bit=True)
        load_kwargs.update(quantization_config=qconf, device_map="auto")
    else:
        # OLMoE の Expert は nn.Parameter 直持ちなので bnb では量子化されない。
        # 8GB VRAM / 16GB RAM に収めるため accelerate で GPU+CPU 分割配置する。
        max_mem = {0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib}
        load_kwargs.update(device_map="auto", max_memory=max_mem,
                           offload_folder=os.path.join(HERE, "_p1_offload"))
    model = AutoModelForCausalLM.from_pretrained(args.model, **load_kwargs)
    model.eval()
    try:
        log("      device_map: %s" % {k: str(v) for k, v in model.hf_device_map.items()})
    except Exception:
        pass

    n_experts = int(model.config.num_experts)
    top_k = int(model.config.num_experts_per_tok)
    n_layers = int(model.config.num_hidden_layers)
    log("      experts=%d top_k=%d layers=%d" % (n_experts, top_k, n_layers))

    # ルータ（gate: OlmoeTopKRouter）へ forward hook を掛け、生 logits を層別に捕まえる。
    # gate.forward は (router_logits, router_scores, router_indices) を返す。
    captured = {}
    handles = []

    def make_hook(layer_idx):
        def hook(module, inp, out):
            z = out[0] if isinstance(out, (tuple, list)) else out
            captured[layer_idx] = z.detach().to(torch.float32).cpu()
        return hook

    n_gate = 0
    for i, layer in enumerate(model.model.layers):
        gate = getattr(layer.mlp, "gate", None)
        if gate is None:
            raise RuntimeError("layer %d に mlp.gate が見つからない" % i)
        handles.append(gate.register_forward_hook(make_hook(i)))
        n_gate += 1
    log("      hooked %d router gates" % n_gate)

    # コーパス
    log("[2/4] building corpus")
    corpora = {}
    for lang in ("en", "ja"):
        txt = load_corpus(lang)
        ids = tok(txt, return_tensors="pt", add_special_tokens=False).input_ids[0]
        log("      %s: %d tokens (vocab %d)" % (lang, ids.numel(), tok.vocab_size))
        corpora[lang] = ids

    n_win = 1 if args.smoke else args.windows
    windows = []  # (lang, start)
    for lang, ids in corpora.items():
        L = ids.numel()
        for w in range(n_win):
            if L <= args.len:
                start = 0
            else:
                start = rng.randrange(0, L - args.len)
            windows.append((lang, ids[start:start + args.len]))
    log("      %d windows x %d tokens" % (len(windows), args.len))

    # forward
    log("[3/4] forward passes")
    per_layer = {i: [] for i in range(n_layers)}
    lang_of_token = []
    with torch.no_grad():
        for wi, (lang, win) in enumerate(windows):
            captured.clear()
            input_ids = win.unsqueeze(0).to(model.device)
            _ = model(input_ids=input_ids, use_cache=False)
            ntok = captured[0].reshape(-1, n_experts).shape[0]
            for i in range(n_layers):
                z = captured[i].reshape(-1, n_experts)   # (tokens, experts)
                per_layer[i].append(z.numpy().astype(np.float32))
            lang_of_token.extend([lang] * ntok)
            log("      window %d/%d (%s) done" % (wi + 1, len(windows), lang))
            if args.smoke and wi == 0:
                break
    lang_of_token = np.array(lang_of_token)

    for h in handles:
        h.remove()

    log("[4/4] computing statistics")
    # b の候補（生 logit 単位）と、目標 in-zone 率
    b_grid = [0.0, 0.5, 1.0, 2.0, 3.0, 5.0]
    targets = [0.01, 0.05, 0.10, 0.25, 0.50]

    layer_rows = []
    all_tau = []
    all_z = []
    per_lang_tau = {lang: [] for lang in sorted(set(lang_of_token.tolist()))}
    expert_rows = []
    for i in range(n_layers):
        Z = np.concatenate(per_layer[i], axis=0)          # (n_tokens, n_experts)
        tau = np.partition(Z, n_experts - top_k, axis=1)[:, n_experts - top_k]  # k 番目に大きい logit
        sigma = float(Z.std())
        # top-k 内に入った expert の割合（ルータの実際の使用分布）
        order = np.argsort(-Z, axis=1)
        selected = np.zeros_like(Z, dtype=bool)
        rows = np.arange(Z.shape[0])[:, None]
        selected[rows, order[:, :top_k]] = True
        # softmax 側の統計
        P = np.exp(Z - Z.max(axis=1, keepdims=True))
        P /= P.sum(axis=1, keepdims=True)
        Ps = np.sort(P, axis=1)[:, ::-1]
        row = {
            "layer": i,
            "n_tokens": int(Z.shape[0]),
            "tau_mean": float(tau.mean()),
            "tau_median": float(np.median(tau)),
            "tau_p05": float(np.quantile(tau, 0.05)),
            "tau_p95": float(np.quantile(tau, 0.95)),
            "z_mean": float(Z.mean()),
            "z_std": sigma,
            "z_max_mean": float(Z.max(axis=1).mean()),
            "n_logit_pos_mean": float((Z > 0).sum(axis=1).mean()),
            "p_max_mean": float(Ps[:, 0].mean()),
            "p_k_mean": float(Ps[:, top_k - 1].mean()),
            "frac_logit_pos": float((Z > 0).mean()),
            "inzone_b0": float((0.0 >= tau).mean()),
        }
        for e in range(n_experts):
            expert_rows.append({
                "layer": i, "expert": e,
                "mean_logit": float(Z[:, e].mean()),
                "frac_selected": float(selected[:, e].mean()),
            })
        for b in b_grid:
            row["inzone_b%.1f" % b] = float((b >= tau).mean())
        for q in targets:
            row["bstar_q%.2f" % q] = float(np.quantile(tau, q))
        # 中立初期化: 新 Expert の logit を「そのトークンの 64 logit の平均」にした場合
        zmean_tok = Z.mean(axis=1)
        row["inzone_zmean"] = float((zmean_tok >= tau).mean())
        layer_rows.append(row)
        all_tau.append(tau)
        all_z.append(Z)
        for lang in per_lang_tau:
            sel = (lang_of_token == lang)
            if sel.any():
                per_lang_tau[lang].append(tau[sel])

    TAU = np.concatenate(all_tau)
    Z = np.concatenate(all_z, axis=0)
    sigma_all = float(Z.std())
    summary = {
        "model": args.model,
        "n_experts": n_experts,
        "top_k": top_k,
        "n_layers": n_layers,
        "n_tokens_total": int(TAU.shape[0]),
        "n_windows": len(windows),
        "window_tokens": args.len,
        "languages": sorted(set(lang_of_token.tolist())),
        "z_std_all": sigma_all,
        "z_mean_all": float(Z.mean()),
        "tau_mean": float(TAU.mean()),
        "tau_median": float(np.median(TAU)),
        "tau_p01": float(np.quantile(TAU, 0.01)),
        "tau_p05": float(np.quantile(TAU, 0.05)),
        "tau_p95": float(np.quantile(TAU, 0.95)),
        "tau_p99": float(np.quantile(TAU, 0.99)),
        "frac_tau_le_0": float((TAU <= 0).mean()),
        "inzone_b0": float((0.0 >= TAU).mean()),
        "inzone_grid": {},
        "bstar": {},
        "bstar_sigma": {},
        "by_language": {},
    }
    for b in b_grid:
        summary["inzone_grid"][str(b)] = float((b >= TAU).mean())
    for q in targets:
        summary["bstar"]["%.2f" % q] = float(np.quantile(TAU, q))
        summary["bstar_sigma"]["%.2f" % q] = float(np.quantile(TAU, q) / sigma_all)
    for lang, taus in per_lang_tau.items():
        T = np.concatenate(taus)
        summary["by_language"][lang] = {
            "n_tokens": int(T.shape[0]),
            "tau_mean": float(T.mean()),
            "tau_median": float(np.median(T)),
            "z_std": None,
            "inzone_b0": float((0.0 >= T).mean()),
            "inzone_b1.0": float((1.0 >= T).mean()),
            "bstar_q0.10": float(np.quantile(T, 0.10)),
            "bstar_q0.50": float(np.quantile(T, 0.50)),
        }

    # 生 logits を保存（後段解析用）
    for i in range(n_layers):
        np.save(os.path.join(HERE, "p1_%s_logits_layer%02d.npy" % (args.tag, i)),
                np.concatenate(per_layer[i], axis=0))

    # CSV
    import csv
    cols = ["layer", "n_tokens", "tau_mean", "tau_median", "tau_p05", "tau_p95",
            "z_mean", "z_std", "z_max_mean", "n_logit_pos_mean", "p_max_mean", "p_k_mean",
            "frac_logit_pos", "inzone_b0", "inzone_zmean"]
    cols += ["inzone_b%.1f" % b for b in b_grid]
    cols += ["bstar_q%.2f" % q for q in targets]
    with open(os.path.join(HERE, "p1_%s_by_layer.csv" % args.tag), "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=cols)
        w.writeheader()
        for r in layer_rows:
            w.writerow(r)

    with open(os.path.join(HERE, "p1_%s_experts.csv" % args.tag), "w", newline="", encoding="utf-8") as fp:
        w = csv.DictWriter(fp, fieldnames=["layer", "expert", "mean_logit", "frac_selected"])
        w.writeheader()
        for r in expert_rows:
            w.writerow(r)

    with open(os.path.join(HERE, "p1_%s_summary.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)

    # 図
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(1, 3, figsize=(15, 4.2))
        ax = axes[0]
        ax.hist(TAU, bins=80, color="#85B7EB", edgecolor="#185FA5", linewidth=0.3)
        ax.axvline(0.0, color="#A32D2D", lw=1.5, ls="--", label="identity logit b = 0")
        ax.set_title("distribution of selection threshold (k-th largest logit)")
        ax.set_xlabel("tau = k-th largest router logit")
        ax.set_ylabel("tokens")
        ax.legend(fontsize=8)

        ax = axes[1]
        bs = np.linspace(min(TAU.min(), 0.0) - 0.5, max(TAU.max(), 1.0) + 0.5, 200)
        rates = [(b >= TAU).mean() for b in bs]
        ax.plot(bs / sigma_all, rates, color="#185FA5", lw=2)
        ax.set_xlabel("bias b (in units of logit std = %.2f)" % sigma_all)
        ax.set_ylabel("in-zone rate (P(identity in top-%d))" % top_k)
        ax.set_title("in-zone rate vs bias")
        ax.grid(alpha=0.3)

        ax = axes[2]
        ls = [r["layer"] for r in layer_rows]
        ax.plot(ls, [r["inzone_b0"] for r in layer_rows], "o-", color="#185FA5", label="b = 0")
        ax.plot(ls, [r["inzone_b%.1f" % b_grid[2]] for r in layer_rows], "s-", color="#993C1D", label="b = 1.0")
        ax.set_xlabel("layer")
        ax.set_ylabel("in-zone rate")
        ax.set_title("in-zone rate by layer")
        ax.set_ylim(-0.02, 1.02)
        ax.legend(fontsize=8)
        ax.grid(alpha=0.3)
        fig.tight_layout()
        fig.savefig(os.path.join(HERE, "p1_%s_margin.png" % args.tag), dpi=130)
        log("      saved p1_%s_margin.png" % args.tag)
    except Exception as e:
        log("      plot skipped: %r" % e)

    log("")
    log("=== SUMMARY ===")
    log("  tokens: %d, layers: %d, experts: %d, top_k: %d" % (TAU.shape[0], n_layers, n_experts, top_k))
    log("  logit std: %.3f, mean: %.3f" % (sigma_all, Z.mean()))
    log("  tau: mean %.3f, median %.3f, p05 %.3f, p95 %.3f" % (TAU.mean(), np.median(TAU), np.quantile(TAU, .05), np.quantile(TAU, .95)))
    log("  in-zone rate at b=0: %.5f" % summary["inzone_b0"])
    for b in b_grid:
        log("  in-zone rate at b=%.1f: %.5f" % (b, summary["inzone_grid"][str(b)]))
    for q in targets:
        log("  b* for in-zone %.0f%%: %.3f (= %.2f sigma)" % (q * 100, summary["bstar"]["%.2f" % q], summary["bstar_sigma"]["%.2f" % q]))
    for lang, d in summary["by_language"].items():
        log("  [%s] n=%d tau_median=%.3f inzone_b0=%.5f" % (lang, d["n_tokens"], d["tau_median"], d["inzone_b0"]))


if __name__ == "__main__":
    main()
