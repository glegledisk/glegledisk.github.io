# -*- coding: utf-8 -*-
"""e7_catastrophe_recover.py — 壊滅は「回復可能な transient」か「不可逆な崩壊」か。

## 診断で分かったこと（e7_catastrophe_diag）
壊滅は warmup ではなく**訓練終盤の 1〜数ステップ**で起きる:
  wb3_s7: ep58 val_ce 0.046（健全）→ ep59 **1.406**、gnorm 0.68→7.13
  wb4_s8: ep57 0.114 → ep58 0.458 → ep59 **2.398**
warmup 中の状態（ep10）は健全で、warm bias なしの同 seed（tokid_ent 0.093）も健全。
→ 「壊滅的 seed」は warmup バイアスの問題ではなく、**終盤の高信頼・記憶飽和領域での
   突発的な破壊イベント**の可能性が高い。

## 本実験（3 ラン）
| ラン | 問い |
|---|---|
| wb3_s7 ep75 | 60 epoch で打ち切ったから壊れて見えるだけか（ep60 以降で回復するか） |
| wb4_s8 ep75 | 同上（より深い崩壊からの回復） |
| wb3_s7 lr=1e-3 | 学習率を下げると破壊イベント自体が起きなくなるか（最適化の不安定性の証拠） |

dparam_l2 / dparam_max（1 epoch のパラメータ更新量）も記録し、「壊したステップ」の
大きさを直接測る。
"""
import json
import os
import time

import numpy as np
import torch

from e7_stabilize_task import run, make_lookup_table

HERE = os.path.dirname(os.path.abspath(__file__))
DEV = "cuda" if torch.cuda.is_available() else "cpu"
tab = make_lookup_table(64)
CFG = dict(L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)), d=64)
SPEC_FREE = dict(route="free", router="linear", stab="entropy", extra="tokid")

RUNS = {
    "wb3_s7_e75": dict(variant="sp_wb3_w10", seed=7, warm_bias=3.0, epochs=75),
    "wb4_s8_e75": dict(variant="sp_wb4_w10", seed=8, warm_bias=4.0, epochs=75),
    "wb3_s7_lr1e3": dict(variant="sp_wb3_w10", seed=7, warm_bias=3.0, epochs=60, lr=1e-3),
}

out = {}
t0 = time.time()
for name, cfg in RUNS.items():
    r = run(cfg["variant"], cfg["seed"], table=tab, device=DEV, spec=SPEC_FREE,
            lam_cost=0.15, ent_beta=0.05, warmup=10, lam_post=0.15,
            warm_bias=cfg["warm_bias"], lr=cfg.get("lr", 3e-3), trace=True,
            epochs=cfg["epochs"], **CFG)
    tr = json.loads(r["trace"])
    out[name] = {"result": {k: v for k, v in r.items() if k not in ("trace", "probe_log")},
                 "trace": tr}
    print(f"[{name:14s}] CE {r['ce_all']:.4f}  FFN {r['ffn_cost']:.3f}  "
          f"acc {r['acc_all']:.4f}  ({time.time()-t0:.0f}s)", flush=True)

json.dump(out, open(os.path.join(HERE, "e7_catastrophe_recover.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)

COLS = ["train_ce", "val_ce", "ce_rr", "ffn_cost", "idmass_ff", "tr_margin_p50_ff",
        "gnorm_router", "dparam_l2", "dparam_max", "theta_l2"]
for name, d in out.items():
    print(f"\n-- {name} --  ep " + " ".join(f"{c[:9]:>9s}" for c in COLS))
    for rec in d["trace"]:
        if rec["epoch"] >= 54:
            print(f"      {rec['epoch']:3d} " + " ".join(
                "     None" if rec.get(c) is None else f"{rec[c]:9.4f}" for c in COLS))

print("\n=== 要約 ===")
for name, d in out.items():
    tr = d["trace"]
    v = [x["val_ce"] for x in tr]
    print(f" {name:14s} 最終 {v[-1]:.4f}  最終5epoch {['%.3f' % x for x in v[-5:]]}  "
          f"max {max(v):.3f}(ep{v.index(max(v))})")
