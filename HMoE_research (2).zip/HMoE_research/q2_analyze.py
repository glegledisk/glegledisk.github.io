#!/usr/bin/env python3
"""Q2 の解析: 難度ラダー（copy → compute → hard → harder）× 小 expert 選択の Δ。

Q1 の結果（simulation_hmoe_mmlu/data/q1）と Q2 の結果（data/q2）を組み合わせて
難度 dose-response を組む。**copy/compute は Q1 の生 json をそのまま読む**
（同一ハーネス・同一 seed・同一ハイパーパラメータなので合成してよい。再訓練しない）。

検算（AGENTS §7）
  - Δ は生 json から small_payload − small_struct として再計算（記憶で書かない）
  - Q1 既知値（H compute +0.290 / copy +0.728 / U compute −0.232）との照合
  - n_eval == 1024 の assert（smoke の混入を防ぐ）
  - 平均が裾に支配されていないか: err_top1pct_share を併記

出力: simulation_hmoe_mmlu/data/q2/q2_analysis.json + 標準出力の表
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
Q1DIR = os.path.join(E2DIR, "data", "q1")
Q2DIR = os.path.join(E2DIR, "data", "q2")

# Q1 産: copy / compute。Q2 産: hard / harder
SOURCES = {
    ("H+LB", "copy"): Q1DIR,
    ("H+LB", "compute"): Q1DIR,
    ("H+LB", "hard"): Q2DIR,
    ("H+LB", "harder"): Q2DIR,
    ("U+LB", "compute"): Q1DIR,
    ("U+LB", "hard"): Q2DIR,
    ("U+LB", "harder"): Q2DIR,
}
LADDER = ["copy", "compute", "hard", "harder"]
DEPTH = {"copy": 0, "compute": 1, "hard": 2, "harder": 3}   # 解析上の順序番号
SEEDS = [0, 1, 2]

# Q1 報告書の値（測定器の校正照合用）
Q1_KNOWN = {
    ("H+LB", "compute"): {"d_small_mean": 0.290, "d_width_mean": -28.9,
                          "acc_payload": 0.966, "small_struct": 0.380, "small_payload": 0.670},
    ("H+LB", "copy"): {"d_small_mean": 0.728, "acc_payload": 0.998},
    ("U+LB", "compute"): {"d_small_mean": -0.232},
}


def load(arm, task):
    d = SOURCES[(arm, task)]
    rows = []
    for s in SEEDS:
        p = os.path.join(d, f"{arm}_{task}_s{s}.json")
        if not os.path.exists(p):
            return None
        with open(p, encoding="utf-8") as f:
            r = json.load(f)
        assert r["n_eval"] == 1024, f"{p}: n_eval={r['n_eval']}（smoke 混入を疑う）"
        rows.append(r)
    return rows


def stat(xs):
    a = np.asarray(xs, dtype=float)
    n = len(a)
    m = float(a.mean())
    sd = float(a.std(ddof=1)) if n > 1 else float("nan")
    se = sd / np.sqrt(n) if n > 1 else float("nan")
    t = m / se if se and se > 0 else float("nan")
    return m, sd, se, t


def summarize(arm, task, rows):
    base = [r["eval"]["base"] for r in rows]
    d = [b["small_payload"] - b["small_struct"] for b in base]
    dw = [b["width_payload"] - b["width_struct"] for b in base]
    m, sd, se, t = stat(d)
    m_ap, _, se_ap, t_ap = stat([b["acc_payload"] for b in base])
    rec = {
        "arm": arm, "task": task, "depth": DEPTH[task], "n_seed": len(rows),
        "acc_payload_mean": m_ap, "acc_payload_se": se_ap,
        "acc_payload": [b["acc_payload"] for b in base],
        "ce_payload_mean": float(np.mean([b["ce_payload"] for b in base])),
        "ce_payload": [b["ce_payload"] for b in base],
        "acc_struct_mean": float(np.mean([b["acc_struct"] for b in base])),
        "small_struct": [b["small_struct"] for b in base],
        "small_payload": [b["small_payload"] for b in base],
        "d_small": d, "d_small_mean": m, "d_small_sd": sd, "d_small_se": se, "d_small_t": t,
        "sign_positive": int(sum(x > 0 for x in d)),
        "d_width": dw, "d_width_mean": float(np.mean(dw)),
        "width_struct": [b["width_struct"] for b in base],
        "width_payload": [b["width_payload"] for b in base],
        "err_top1pct_share": [b.get("err_top1pct_share", float("nan")) for b in base],
        "first_err_mean": [b.get("first_err_mean", float("nan")) for b in base],
        # 0-1 系（k 削減・強制）は構成条件ごとに
        "seq_valid": {c: [r["eval"][c]["seq_valid"] for r in rows]
                      for c in rows[0]["eval"]},
        "payload_acc_cond": {c: [r["eval"][c]["acc_payload"] for r in rows]
                             for c in rows[0]["eval"]},
        "layer_small_payload": [b["small_payload_l"] for b in base],
        "layer_small_struct": [b["small_struct_l"] for b in base],
    }
    if "acc_payload_bydigit" in base[0]:
        rec["acc_payload_bydigit"] = [b["acc_payload_bydigit"] for b in base]
        rec["small_payload_bydigit"] = [b["small_payload_bydigit"] for b in base]
        rec["ce_payload_bydigit"] = [b["ce_payload_bydigit"] for b in base]
        # 桁内相関: 難しい桁ほど広く送られるか（numerate はレベル内・seed 平均）
        acc_d = np.mean([b["acc_payload_bydigit"] for b in base], axis=0)
        sm_d = np.mean([b["small_payload_bydigit"] for b in base], axis=0)
        if np.std(acc_d) > 1e-9 and np.std(sm_d) > 1e-9:
            rec["digit_corr_acc_vs_small"] = float(np.corrcoef(acc_d, sm_d)[0, 1])
        rec["acc_payload_bydigit_mean"] = acc_d.tolist()
        rec["small_payload_bydigit_mean"] = sm_d.tolist()
    return rec


def main():
    out = {"ladder": {}, "configs": {}, "paired": {}}

    for (arm, task) in SOURCES:
        rows = load(arm, task)
        if rows is None:
            print(f"[skip] {arm} {task}: seed ファイルが揃っていない")
            continue
        rec = summarize(arm, task, rows)
        out["configs"][f"{arm}_{task}"] = rec
        out["ladder"].setdefault(arm, {})[task] = rec

    # ---- 校正照合: Q1 既知値との一致 ----
    ALIAS = {"acc_payload": "acc_payload_mean"}
    calib = {}
    for key, kv in Q1_KNOWN.items():
        name = f"{key[0]}_{key[1]}"
        if name not in out["configs"]:
            continue
        rec = out["configs"][name]
        ok = True
        for k, v in kv.items():
            rk = ALIAS.get(k, k)
            got = float(np.mean(rec[rk])) if isinstance(rec.get(rk), list) else rec.get(rk)
            if got is None:
                print(f"[ERROR] 校正キー不明 {name}.{k}")
                ok = False
                continue
            tol = 0.051 if k == "d_width_mean" else 5e-3
            delta = abs(got - v)
            calib[f"{name}.{k}"] = {"report": v, "recompute": got, "absdiff": delta}
            if delta > tol:
                ok = False
                print(f"[WARN] 校正ズレ {name}.{k}: 報告 {v} vs 再計算 {got:.6f}")
        if ok:
            print(f"[calib] {name}: Q1 報告値と一致 ✓")
    out["calibration"] = calib

    # ---- 実配色 3 点対照（Q1 対応差の再現） ----
    cfg = out["configs"]
    def paired(name, a, b, key="d_small"):
        ra, rb = cfg.get(f"{name}_{a}"), cfg.get(f"{name}_{b}")
        if ra is None or rb is None:
            return None
        diff = np.array(ra[key]) - np.array(rb[key])
        m, sd, se, t = stat(diff)
        return {"a": a, "b": b, "diff": diff.tolist(), "mean": m, "sd": sd, "se": se,
                "t": t, "n": int(len(diff)),
                "n_negative": int((diff < 0).sum()), "n_positive": int((diff > 0).sum())}

    out["paired"]["P_hard_minus_compute"] = paired("H+LB", "hard", "compute")
    out["paired"]["P_harder_minus_hard"] = paired("H+LB", "harder", "hard")
    out["paired"]["P_compute_minus_copy"] = paired("H+LB", "compute", "copy")
    out["paired"]["U_hard_minus_compute"] = paired("U+LB", "hard", "compute")

    # ---- 事前: dose-response の単調性（隣接レベル差、seed 対応） ----
    trend = {}
    for arm in ("H+LB", "U+LB"):
        lv = [t for t in LADDER if f"{arm}_{t}" in out["configs"]]
        for i in range(len(lv) - 1):
            p = paired(arm, lv[i + 1], lv[i])
            if p:
                trend[f"{arm}.{lv[i+1]}_minus_{lv[i]}"] = p
    out["trend"] = trend

    with open(os.path.join(Q2DIR, "q2_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    # ---- 表の出力 ----
    for arm in ("H+LB", "U+LB"):
        lv = [t for t in LADDER if f"{arm}_{t}" in out["configs"]]
        if not lv:
            continue
        print(f"\n===== {arm} 難度ラダー (n_seed=3) =====")
        print(f"{'task':8s} {'acc_pl':>7s} {'ce_pl':>7s} {'small_st':>8s} {'small_pl':>8s} "
              f"{'Δ':>7s} {'se':>6s} {'t':>6s} {'正':>4s} {'widΔ':>7s} {'tp1%':>6s}")
        for t in lv:
            r = out["configs"][f"{arm}_{t}"]
            print(f"{t:8s} {r['acc_payload_mean']:7.3f} {r['ce_payload_mean']:7.3f} "
                  f"{np.mean(r['small_struct']):8.3f} {np.mean(r['small_payload']):8.3f} "
                  f"{r['d_small_mean']:+7.3f} {r['d_small_se']:6.3f} {r['d_small_t']:+6.2f} "
                  f"{r['sign_positive']:3d}/3 {r['d_width_mean']:+7.1f} "
                  f"{np.mean(r['err_top1pct_share']):6.3f}")
        print("  per-seed Δ: ",
              {t: [f"{x:+.3f}" for x in out["configs"][f"{arm}_{t}"]["d_small"]] for t in lv})
        print("  per-seed acc_payload: ",
              {t: [f"{x:.3f}" for x in out["configs"][f"{arm}_{t}"]["acc_payload"]] for t in lv})

    # 桁別（Q2 産のみ）
    for name, rec in out["configs"].items():
        if "acc_payload_bydigit_mean" not in rec:
            continue
        print(f"\n--- {name}: payload 桁別（MSD→LSD） ---")
        acc = rec["acc_payload_bydigit_mean"]
        sm = rec["small_payload_bydigit_mean"]
        print("  acc  by digit: " + " ".join(f"{x:.2f}" for x in acc))
        print("  small by digit: " + " ".join(f"{x:.2f}" for x in sm))
        if "digit_corr_acc_vs_small" in rec:
            print(f"  桁内相関 (acc, small share) r = {rec['digit_corr_acc_vs_small']:+.3f} (n=8 桁)")

    # 構成条件の payload 正解率（0-1 系の増幅）
    print("\n===== payload 正解率（条件別） =====")
    for name, rec in out["configs"].items():
        pc = rec["payload_acc_cond"]
        sv = rec["seq_valid"]
        line = "  ".join(f"{c}: toks {np.mean(pc[c]):.3f}/seq {np.mean(sv[c]):.3f}"
                         for c in pc if c in ("base", "k1", "f1", "b1",
                                              "force_small", "force_wide"))
        print(f"{name}: {line}")

    print("\n===== 対応差（同一 seed） =====")
    for k, p in out["paired"].items():
        if p is None:
            continue
        print(f"{k}: mean {p['mean']:+.3f}  se {p['se']:.3f}  t {p['t']:+.2f}  "
              f"負 {p['n_negative']}/{p['n']}  正 {p['n_positive']}/{p['n']}"
              f"   diff: {' '.join(f'{x:+.3f}' for x in p['diff'])}")

    print(f"\n[write] {Q2DIR}\\q2_analysis.json")


if __name__ == "__main__":
    main()
    sys.exit(0)
