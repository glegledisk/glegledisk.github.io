#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX2: 16 層粒度の per-token コスト測定と層軸の因果的 predictor

設計書: AX2課題設計書_16層粒度のper-tokenコスト測定と層軸の因果的predictor_20261111.md
（走行前に決定規則・検定族・校正を凍結。実装はこの設計書に従う）

腕 42 本 = native 35 + mask 7
  native: base / u7 / u6 / ab7_L×16 / ab6_L×16   （gates[L].top_k を直接変更）
  mask  : mask7 / tok_oracle50 / tok_probe50 /
          lay_swap_oracle / lay_swap_probe / lay_swap_oracle_cond / lay_swap_probe_cond
          （全層 gate を wrap、slot >= k の重みを 0。norm_topk_prob=False なので
            マスク k は native top-k と選択重みが一致する）

確認的（Holm m=3, alpha=0.05, 両側）
  T1: G_lay_oracle = CE(u7) - CE(lay_swap_oracle) = 0
  T2: G_lay_probe  = CE(u7) - CE(lay_swap_probe)  = 0   ← 主目的（AX1 限界4の解消）
  T3: |G_lay_probe - G_tok_probe50| < 0.01 の TOST

層内因果: 層 L のターゲット c8_L / c7_L の特徴は層 0..L のみ。
d_j は P4b 慣例（位置因果・層方向は理想化）。

実行:
  python ax2_layer_cost.py --smoke --tag ax2smoke   # ドライラン（2 窓）
  python ax2_layer_cost.py --tag ax2                # 本番（42 forward + probe）
"""

import argparse
import json
import math
import os
import sys
import time
import types

import numpy as np
import torch
import torch.nn.functional as F
from scipy import stats as scistats

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from p7c_width import load_frozen  # noqa: E402

N_FOLD = 5
H_STRATA = (0, 5, 10, 15)
LAM = 10.0
ALPHA = 0.05
DELTA_TOST = 0.01
PERM_SEED = 777
PERM_TARGETS = ("c8_00", "c8_15", "c7_08", "d_j")
FEAT_PER_LAYER = 71          # gate 64 + gstat 7
NHIST = 9

TEE = None


def log(msg):
    print(msg, flush=True)
    if TEE is not None:
        TEE.write(msg + "\n")
        TEE.flush()


# ---------------------------------------------------------------- statistics
def paired(d, n_win, tok_per_win):
    """paired per-token statistics（AX1 と同一実装）。d は float64, shape (N,)。"""
    d = np.asarray(d, dtype=np.float64).ravel()
    n = d.size
    m = float(d.mean())
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    t = m / se if se > 0 else float("nan")
    p_two = float(2.0 * scistats.t.sf(abs(t), n - 1)) if se > 0 else float("nan")
    tcrit975 = float(scistats.t.ppf(0.975, n - 1))
    tcrit95 = float(scistats.t.ppf(0.95, n - 1))
    mde = tcrit975 * se
    ci95 = [m - tcrit975 * se, m + tcrit975 * se]
    ci90 = [m - tcrit95 * se, m + tcrit95 * se]
    wm = d.reshape(n_win, tok_per_win).mean(axis=1)
    se_win = float(wm.std(ddof=1) / math.sqrt(n_win))
    t_win = m / se_win if se_win > 0 else float("nan")
    p_win = float(2.0 * scistats.t.sf(abs(t_win), n_win - 1)) if se_win > 0 else float("nan")
    srt = np.sort(np.abs(d))[::-1]
    k1 = max(1, int(math.ceil(0.01 * n)))
    top1_abs = float(srt[:k1].sum() / srt.sum())
    signed_sum = float(d.sum())
    idx = np.argsort(np.abs(d))[::-1][:k1]
    top1_signed = float(d[idx].sum() / signed_sum) if signed_sum != 0 else float("nan")
    return {
        "mean": m, "sd": sd, "se": se, "t": t, "p_two": p_two,
        "n": int(n), "df": int(n - 1), "mde": mde, "ci95": ci95, "ci90": ci90,
        "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
        "n_zero": int((d == 0).sum()), "median": float(np.median(d)),
        "min": float(d.min()), "max": float(d.max()),
        "se_win": se_win, "t_win": t_win, "p_win_two": p_win,
        "top1_abs_share": top1_abs, "top1_signed_share": top1_signed,
    }


def tost(st, delta):
    """TOST for H0: |mean| >= delta（AX1 と同一実装）。"""
    m, se, df = st["mean"], st["se"], st["df"]
    p_low = float(scistats.t.sf((m + delta) / se, df))
    p_high = float(scistats.t.cdf((m - delta) / se, df))
    p_tost = max(p_low, p_high)
    lo, hi = st["ci90"]
    equivalent = bool((p_tost < ALPHA) and (lo > -delta) and (hi < delta))
    return {"delta": delta, "p_low": p_low, "p_high": p_high,
            "p_tost": p_tost, "ci90": [lo, hi], "equivalent": equivalent}


def holm(pvals):
    """Holm step-down（AX1 と同一実装）。"""
    ids = sorted(pvals, key=lambda k: pvals[k])
    m = len(ids)
    out, running = {}, 0.0
    for i, key in enumerate(ids):
        val = (m - i) * pvals[key]
        running = max(running, val)
        out[key] = min(1.0, running)
    return out


# ---------------------------------------------------------------- probe
def spearman(a, b):
    ra = np.argsort(np.argsort(a)).astype(np.float64)
    rb = np.argsort(np.argsort(b)).astype(np.float64)
    ra -= ra.mean()
    rb -= rb.mean()
    den = np.sqrt((ra ** 2).sum() * (rb ** 2).sum())
    return float((ra * rb).sum() / den) if den > 0 else float("nan")


def ridge_fit_predict(Xtr, ytr, Xte, lam=LAM):
    mu = Xtr.mean(0)
    sd = Xtr.std(0) + 1e-8
    A = (Xtr - mu) / sd
    B = (Xte - mu) / sd
    ym = ytr.mean()
    d = A.shape[1]
    if d <= A.shape[0]:
        w = np.linalg.solve(A.T @ A + lam * np.eye(d), A.T @ (ytr - ym))
    else:
        a = np.linalg.solve(A @ A.T + lam * np.eye(A.shape[0]), ytr - ym)
        w = A.T @ a
    return B @ w + ym


def cv_predict(X, y, groups, lam=LAM):
    pred = np.zeros(len(y))
    for f in range(N_FOLD):
        te = (groups % N_FOLD) == f
        tr = ~te
        if te.any():
            pred[te] = ridge_fit_predict(X[tr], y[tr], X[te], lam)
    return pred


def randproj(n_in, n_out, seed=0):
    rng = np.random.RandomState(seed)
    return (rng.randn(n_in, n_out) / np.sqrt(n_out)).astype(np.float32)


def gate_stats(G):
    """ルータ logit (n, 64) の要約 7 統計（P4b と同一）。"""
    z = G.astype(np.float64)
    p = np.exp(z - z.max(1, keepdims=True))
    p /= p.sum(1, keepdims=True)
    top8 = np.sort(p, axis=1)[:, -8:]
    return np.stack([
        z.max(1), z.mean(1), z.std(1),
        top8.sum(1),
        -(p * np.log(p + 1e-12)).sum(1),
        (z > 0).sum(1).astype(np.float64),
        z.max(1) - np.median(z, axis=1),
    ], axis=1)


def shift_within(x, k, fill, pos):
    out = np.full_like(x, fill, dtype=np.float64)
    out[k:] = x[:-k]
    out[:k] = fill
    out[pos < k] = fill
    return out


def movavg(x, k, fill, win):
    out = np.empty_like(x, dtype=np.float64)
    for w in np.unique(win):
        sel = np.where(win == w)[0]
        xs = x[sel]
        c = np.concatenate([[0.0], np.cumsum(xs)])
        for i in range(len(xs)):
            lo = max(0, i - k)
            cnt = i - lo
            out[sel[i]] = (c[i] - c[lo]) / cnt if cnt > 0 else fill
    return out


# ---------------------------------------------------------------- main
def main():
    global TEE
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--tag", type=str, default="ax2")
    args = ap.parse_args()
    tag = args.tag
    TEE = open(os.path.join(HERE, "%s_layer_cost_out_utf8.txt" % tag), "w", encoding="utf-8")

    n_win = 1 if args.smoke else args.windows
    ln = args.len
    n_eval = ln - 1

    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[1/8] load model")
    t0 = time.time()
    AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      %.0f s" % (time.time() - t0))

    n_layers = int(model.config.num_hidden_layers)
    d_model = int(model.config.hidden_size)
    full_k = int(model.config.num_experts_per_tok)
    assert full_k == 8 and n_layers == 16, "想定外のモデル構成"
    gates = [l.mlp.gate for l in model.model.layers]
    gate_fwd = [g.forward for g in gates]
    log("      layers=%d d_model=%d full_k=%d" % (n_layers, d_model, full_k))

    # --- マスク wrapper（常時装着。kmat=None は素通しで bit 等価）---
    STATE = {"kmat": None}

    def make_masked(orig, li):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            km = STATE["kmat"]
            if km is not None and scores.shape[-1] == full_k:
                kk = km[li]
                if kk.numel() == scores.shape[0]:
                    ar = torch.arange(scores.shape[-1], device=scores.device, dtype=torch.float32)
                    mask = (ar[None, :] < kk[:, None]).to(scores.dtype)
                    scores = scores * mask
            return logits, scores, idx
        return _patched

    for i, g in enumerate(gates):
        g.forward = make_masked(gate_fwd[i], i)

    # --- 特徴収集 hook（base 実行のみ有効・読み取り専用）---
    CAP = {"on": False, "g": None, "h": None}

    def gate_hook(li):
        def fn(module, inp, out):
            if CAP["on"]:
                CAP["g"][li] = out[0].detach().float().cpu()
        return fn

    def mlp_hook(s):
        def fn(module, inp, out):
            if CAP["on"]:
                CAP["h"][s] = inp[0].detach().float().cpu()[0]
        return fn

    handles = [g.register_forward_hook(gate_hook(i)) for i, g in enumerate(gates)]
    handles += [model.model.layers[s].mlp.register_forward_hook(mlp_hook(s)) for s in H_STRATA]
    Rs = {s: torch.from_numpy(randproj(d_model, 256, seed=100 + s)) for s in H_STRATA}

    log("[2/8] corpus")
    seqs = load_frozen(n_win, ln)
    lang = np.array([lg for lg, _ in seqs])
    log("      %d windows, %d eval tokens" % (len(seqs), len(seqs) * n_eval))

    n_tok = len(seqs) * n_eval

    # --- 評価ループ ---
    def run_eval(name, native_topks=None, capture=False, kmat_windows=None):
        t1 = time.time()
        if kmat_windows is not None:
            for g in gates:
                g.top_k = full_k
        else:
            STATE["kmat"] = None
            if native_topks is None:
                for g in gates:
                    g.top_k = full_k
            else:
                for i, g in enumerate(gates):
                    g.top_k = int(native_topks[i])
        nll_c, a1_c = [], []
        capG = [None] * n_layers
        capH = {s: None for s in H_STRATA}
        ent_c, in_c, tgt_c = [], [], []
        G_big = np.zeros((n_layers, n_tok, 64), dtype=np.float32) if capture else None
        H_big = np.zeros((len(H_STRATA), n_tok, 256), dtype=np.float32) if capture else None
        CAP["on"] = capture
        CAP["g"] = capG
        CAP["h"] = capH
        with torch.no_grad():
            for wi, (lg_lang, ids) in enumerate(seqs):
                if kmat_windows is not None:
                    STATE["kmat"] = torch.from_numpy(
                        kmat_windows[:, wi * ln:(wi + 1) * ln].astype(np.float32)
                    ).to(model.device)
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                logit = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(logit, tgt, reduction="none")
                true_l = logit.gather(1, tgt.unsqueeze(-1))
                a1_c.append(((logit > true_l).sum(-1) == 0).float().cpu().numpy())
                nll_c.append(nll.cpu().numpy())
                if capture:
                    p = torch.softmax(logit, dim=-1)
                    ent_c.append(-(p * torch.log(p + 1e-12)).sum(-1).cpu().numpy())
                    in_c.append(x[0, :-1].cpu().numpy())
                    tgt_c.append(tgt.cpu().numpy())
                    sl = slice(wi * n_eval, (wi + 1) * n_eval)
                    for i in range(n_layers):
                        G_big[i, sl] = capG[i].numpy()[:n_eval]
                    for si, s in enumerate(H_STRATA):
                        H_big[si, sl] = capH[s].numpy()[:n_eval] @ Rs[s].numpy()
                del out, logit
        STATE["kmat"] = None
        CAP["on"] = False
        nll = np.concatenate(nll_c).astype(np.float32)
        a1 = np.concatenate(a1_c).astype(np.float32)
        log("      %-20s CE %.5f  top1 %.4f  (%.0f s)"
            % (name, nll.mean(), a1.mean(), time.time() - t1))
        out = {"nll": nll, "acc1": a1}
        if capture:
            out.update({"G": G_big, "H": H_big, "ent": np.concatenate(ent_c),
                        "in_ids": np.concatenate(in_c), "tgt": np.concatenate(tgt_c)})
        return out

    # --- native 腕 35 本 ---
    native_arms = [("base", [full_k] * n_layers), ("u7", [7] * n_layers), ("u6", [6] * n_layers)]
    for L in range(n_layers):
        native_arms.append(("ab7_%02d" % L, [7 if i == L else full_k for i in range(n_layers)]))
    for L in range(n_layers):
        native_arms.append(("ab6_%02d" % L, [6 if i == L else full_k for i in range(n_layers)]))

    log("[3/8] native forwards (%d arms)" % len(native_arms))
    res = {}
    cap = None
    for ai, (name, topks) in enumerate(native_arms):
        r = run_eval(name, native_topks=topks, capture=(name == "base"))
        res[name] = {k: v for k, v in r.items() if k in ("nll", "acc1")}
        if name == "base":
            cap = r
        if (ai + 1) % 8 == 0:
            np.savez_compressed(os.path.join(HERE, "%s_layer_cost_partial.npz" % tag),
                                **{("nll_" + k): v["nll"] for k, v in res.items()})

    # --- 特徴量 ---
    log("[4/8] features")
    wi_arr = np.repeat(np.arange(len(seqs)), n_eval)
    pos = np.tile(np.arange(n_eval), len(seqs)).astype(np.float64)
    G_big, H_big = cap["G"], cap["H"]
    nll_base = res["base"]["nll"].astype(np.float64)
    ent = cap["ent"].astype(np.float64)
    t1a = res["base"]["acc1"].astype(np.float64)
    in_ids = cap["in_ids"]

    prev_nll = shift_within(nll_base, 1, nll_base.mean(), pos)
    prev_ent = shift_within(ent, 1, ent.mean(), pos)
    prev_t1 = shift_within(t1a, 1, t1a.mean(), pos)
    ma8 = movavg(nll_base, 8, nll_base.mean(), wi_arr)
    ma32 = movavg(nll_base, 32, nll_base.mean(), wi_arr)
    ma64 = movavg(nll_base, 64, nll_base.mean(), wi_arr)
    freq = np.zeros(n_tok)
    for w in np.unique(wi_arr):
        sel = np.where(wi_arr == w)[0]
        seen = {}
        for idx, tid in zip(sel, in_ids[sel]):
            seen[int(tid)] = seen.get(int(tid), 0) + 1
            freq[idx] = seen[int(tid)]
    freq = np.log1p(freq)
    hist = np.stack([prev_nll, prev_ent, prev_t1, ma8, ma32, ma64, freq,
                     pos, np.log1p(pos)], axis=1)

    nfeat = n_layers * FEAT_PER_LAYER + len(H_STRATA) * 256 + NHIST
    hcol0 = n_layers * FEAT_PER_LAYER
    X = np.zeros((n_tok, nfeat), dtype=np.float32)
    for l in range(n_layers):
        X[:, FEAT_PER_LAYER * l:FEAT_PER_LAYER * l + 64] = G_big[l]
        X[:, FEAT_PER_LAYER * l + 64:FEAT_PER_LAYER * (l + 1)] = gate_stats(G_big[l]).astype(np.float32)
    for si, s in enumerate(H_STRATA):
        X[:, hcol0 + 256 * si:hcol0 + 256 * (si + 1)] = H_big[si]
    X[:, hcol0 + 256 * len(H_STRATA):] = hist.astype(np.float32)
    hist_col = hcol0 + 256 * len(H_STRATA)
    log("      X %s  (%.0f MB)" % (X.shape, X.nbytes / 1e6))

    def cols_for_layer(L):
        cs = list(range(0, FEAT_PER_LAYER * (L + 1)))
        for si, s in enumerate(H_STRATA):
            if s <= L:
                cs += list(range(hcol0 + 256 * si, hcol0 + 256 * (si + 1)))
        cs += list(range(hist_col, nfeat))
        return np.array(cs)

    tok_layers = (0, 4, 8, 12, 15)
    cols_tok = []
    for l in tok_layers:
        cols_tok += list(range(FEAT_PER_LAYER * l, FEAT_PER_LAYER * (l + 1)))
    cols_tok += list(range(hcol0, nfeat))
    cols_tok = np.array(cols_tok)

    # --- ターゲットと probe ---
    log("[5/8] probes (33 targets, %d-fold window CV)" % N_FOLD)
    c8 = np.stack([res["ab7_%02d" % L]["nll"].astype(np.float64) - nll_base for L in range(n_layers)])
    c7 = np.stack([res["ab6_%02d" % L]["nll"].astype(np.float64) - res["ab7_%02d" % L]["nll"].astype(np.float64)
                   for L in range(n_layers)])
    d_j = res["u6"]["nll"].astype(np.float64) - nll_base

    targets = {}
    for L in range(n_layers):
        targets["c8_%02d" % L] = (c8[L], cols_for_layer(L))
        targets["c7_%02d" % L] = (c7[L], cols_for_layer(L))
    targets["d_j"] = (d_j, cols_tok)

    oof, probe_q = {}, {}
    for name, (y, cs) in targets.items():
        Xs = X[:, cs].astype(np.float64)
        pred = cv_predict(Xs, y, wi_arr, LAM)
        oof[name] = pred
        r2 = 1.0 - float(((y - pred) ** 2).sum() / ((y - y.mean()) ** 2).sum())
        probe_q[name] = {"spearman": spearman(y, pred), "r2": r2, "n_feat": int(cs.size)}
        log("      %-8s rho %.4f  R2 %.4f  (d=%d)" % (name, probe_q[name]["spearman"], r2, cs.size))
    oof_mat = np.stack([oof["c8_%02d" % L] for L in range(n_layers)]
                       + [oof["c7_%02d" % L] for L in range(n_layers)] + [oof["d_j"]], axis=1)
    target_names = list(targets)

    rng_perm = np.random.RandomState(PERM_SEED)
    perm = rng_perm.permutation(n_tok)
    perm_stats = {}
    for name in PERM_TARGETS:
        y, cs = targets[name]
        Xs = X[:, cs].astype(np.float64)
        pred = cv_predict(Xs, y[perm], wi_arr, LAM)
        perm_stats[name] = spearman(y[perm], pred)
        log("      perm %-8s |rho| %.5f" % (name, abs(perm_stats[name])))

    np.savez_compressed(os.path.join(HERE, "%s_layer_cost_partial.npz" % tag),
                        **{("nll_" + k): v["nll"] for k, v in res.items()},
                        X=X, oof=oof_mat.astype(np.float32), wi=wi_arr.astype(np.int16))

    # --- 決定（走行前に凍結した規則）---
    log("[6/8] decisions")
    c8f, c7f = c8.astype(np.float32), c7.astype(np.float32)
    cut_o = np.argmin(c7f, axis=0).astype(np.int8)
    arange_t = np.arange(n_tok)
    conflict_o = int((np.argmax(c8f, axis=0) == cut_o).sum())
    c8_masked = c8f.copy()
    c8_masked[cut_o, arange_t] = -np.inf
    prot_o = np.argmax(c8_masked, axis=0).astype(np.int8)
    tie_min_o = int(((c7f == c7f.min(axis=0, keepdims=True)).sum(axis=0) > 1).sum())
    tie_max_o = int(((c8f == c8f.max(axis=0, keepdims=True)).sum(axis=0) > 1).sum())
    assert (cut_o != prot_o).all(), "oracle で cut == protect が発生（設計書 §4 の除外規則のバグ）"
    kmat_o = np.full((n_layers, n_tok), 7, dtype=np.int8)
    kmat_o[cut_o, arange_t] = 6
    kmat_o[prot_o, arange_t] = 8

    pc8 = oof_mat[:, :n_layers].T.astype(np.float32)
    pc7 = oof_mat[:, n_layers:2 * n_layers].T.astype(np.float32)
    cut_p = np.argmin(pc7, axis=0).astype(np.int8)
    conflict_p = int((np.argmax(pc8, axis=0) == cut_p).sum())
    pc8_masked = pc8.copy()
    pc8_masked[cut_p, arange_t] = -np.inf
    prot_p = np.argmax(pc8_masked, axis=0).astype(np.int8)
    tie_min_p = int(((pc7 == pc7.min(axis=0, keepdims=True)).sum(axis=0) > 1).sum())
    tie_max_p = int(((pc8 == pc8.max(axis=0, keepdims=True)).sum(axis=0) > 1).sum())
    assert (cut_p != prot_p).all(), "probe で cut == protect が発生（設計書 §4 の除外規則のバグ）"
    kmat_p = np.full((n_layers, n_tok), 7, dtype=np.int8)
    kmat_p[cut_p, np.arange(n_tok)] = 6
    kmat_p[prot_p, np.arange(n_tok)] = 8

    cond_o = (c8f.max(axis=0) - c7f.min(axis=0)) > 0
    kmat_co = np.where(cond_o[None, :], kmat_o, np.int8(7)).astype(np.int8)
    cond_p = (pc8.max(axis=0) - pc7.min(axis=0)) > 0
    kmat_cp = np.where(cond_p[None, :], kmat_p, np.int8(7)).astype(np.int8)

    def topk_k(mat, f, lo=6, hi=8):
        """P4c と同一の 50% ルール。"""
        out = np.full(mat.shape, lo, dtype=np.float32)
        m = int(round(f * mat.size))
        order = np.argsort(-mat.ravel())
        keep = np.zeros(mat.size, bool)
        keep[order[:m]] = True
        out.ravel()[keep] = hi
        return out

    dmat = d_j.astype(np.float32).reshape(len(seqs), n_eval)
    kv_o = topk_k(dmat, 0.5)
    pdm = oof["d_j"].astype(np.float32).reshape(len(seqs), n_eval)
    kv_p = topk_k(pdm, 0.5)

    def to_windows(kmat_eval=None, kvec=None, pad_val=7):
        if kvec is not None:
            kv = np.concatenate([kvec, np.full((len(seqs), 1), pad_val, dtype=np.float32)], axis=1)
            km = np.tile(kv[None, :, :], (n_layers, 1, 1))
        else:
            km = kmat_eval.reshape(n_layers, len(seqs), n_eval)
            pad = np.full((n_layers, len(seqs), 1), pad_val, dtype=kmat_eval.dtype)
            km = np.concatenate([km, pad], axis=2)
        return km.reshape(n_layers, len(seqs) * ln)

    mask_arms = [
        ("mask7", to_windows(kvec=np.full((len(seqs), n_eval), 7, dtype=np.float32), pad_val=7)),
        ("tok_oracle50", to_windows(kvec=kv_o, pad_val=6)),
        ("tok_probe50", to_windows(kvec=kv_p, pad_val=6)),
        ("lay_swap_oracle", to_windows(kmat_eval=kmat_o, pad_val=7)),
        ("lay_swap_probe", to_windows(kmat_eval=kmat_p, pad_val=7)),
        ("lay_swap_oracle_cond", to_windows(kmat_eval=kmat_co, pad_val=7)),
        ("lay_swap_probe_cond", to_windows(kmat_eval=kmat_cp, pad_val=7)),
    ]
    for name, km in mask_arms:
        log("      %-20s mean_k %.6f" % (name, km.mean()))

    log("[7/8] mask forwards (%d arms)" % len(mask_arms))
    for name, km in mask_arms:
        r = run_eval(name, kmat_windows=km)
        res[name] = {k: v for k, v in r.items() if k in ("nll", "acc1")}

    # --- 統計 ---
    log("[8/8] stats / calibration / save")
    nll = {k: v["nll"].astype(np.float64) for k, v in res.items()}
    for k, v in res.items():
        assert v["nll"].shape == (n_tok,) and np.isfinite(v["nll"]).all() and (v["nll"] >= 0).all(), \
            "配列健全性 NG: %s" % k

    st1 = paired(nll["u7"] - nll["lay_swap_oracle"], len(seqs), n_eval)
    st2 = paired(nll["u7"] - nll["lay_swap_probe"], len(seqs), n_eval)
    st3 = paired(nll["tok_probe50"] - nll["lay_swap_probe"], len(seqs), n_eval)
    to3 = tost(st3, DELTA_TOST)
    ph = holm({"T1": st1["p_two"], "T2": st2["p_two"], "T3": to3["p_tost"]})
    rej = {k: bool(ph[k] < ALPHA) for k in ph}
    g1, g2 = st1["mean"], st2["mean"]
    if rej["T2"] and g2 > 0:
        case = "A"
    elif rej["T1"] and g1 > 0 and not rej["T2"]:
        case = "B"
    elif (not rej["T1"]) and (not rej["T2"]) and rej["T3"]:
        case = "C"
    elif rej["T1"] and g1 < 0:
        case = "D"
    else:
        case = "UNLISTED"

    # 校正
    calib = {}
    z24 = np.load(os.path.join(HERE, "p24_layer_cost.npz"))
    b24 = z24["nll_base"].astype(np.float64)
    if res["base"]["nll"].shape == b24.shape:
        d_c1 = res["base"]["nll"].astype(np.float64) - b24
        calib["C1"] = {"maxdiff": float(np.abs(d_c1).max()), "meandiff": float(d_c1.mean()),
                       "tier": "A" if np.abs(d_c1).max() == 0.0 else
                               ("B" if abs(d_c1.mean()) <= 1e-3 and np.abs(d_c1).max() <= 0.05 else "FAIL")}
    else:
        calib["C1"] = {"tier": "SKIP", "reason": "shape mismatch (smoke: %s vs p24 %s)"
                       % (res["base"]["nll"].shape, b24.shape)}
    d_c2 = res["mask7"]["nll"].astype(np.float64) - nll["u7"]
    c2_tier = "A" if np.abs(d_c2).max() == 0.0 else \
              ("A'" if abs(d_c2.mean()) <= 0.002 else "FAIL")
    c2_p4c = {}
    try:
        zp4 = np.load(os.path.join(HERE, "p4_adaptive_nll.npz"))
        dp4 = zp4["mask7"].astype(np.float64) - zp4["uniform7"].astype(np.float64)
        c2_p4c = {"meandiff": float(dp4.mean()), "sd": float(dp4.std(ddof=1)),
                  "abs_med": float(np.median(np.abs(dp4))), "max": float(np.abs(dp4).max())}
    except Exception:
        c2_p4c = {"unavailable": True}
    calib["C2"] = {"meandiff": float(d_c2.mean()), "maxdiff": float(np.abs(d_c2).max()),
                   "sd": float(d_c2.std(ddof=1)), "tier": c2_tier, "p4c_precedent": c2_p4c}
    j24 = json.load(open(os.path.join(HERE, "p24_layer_cost.json"), encoding="utf-8"))
    c3_bad = []
    for cname, rj in j24["results"].items():
        arr = z24["nll_" + cname].astype(np.float64)
        if abs(float(arr.mean()) - rj["ce"]) > 1e-6 or abs(float((arr - b24).mean()) - rj["dce"]) > 1e-6:
            c3_bad.append(cname)
    calib["C3"] = {"n_conds": len(j24["results"]), "n_bad": len(c3_bad), "bad": c3_bad}
    calib["C4"] = {"n_arms": len(res), "n_tok": int(n_tok), "lang_order_ok":
                   bool(np.all(lang[:len(seqs) // 2] == "en") and np.all(lang[len(seqs) // 2:] == "ja"))}
    mean_k = {"base": 8.0, "u7": 7.0, "u6": 6.0}
    for L in range(n_layers):
        mean_k["ab7_%02d" % L] = (15 * 8 + 7) / 16
        mean_k["ab6_%02d" % L] = (15 * 8 + 6) / 16
    for name, km in mask_arms:
        mean_k[name] = float(km.mean())
    exp_mk = dict(mean_k)
    m_half = int(round(0.5 * n_tok))
    tok_mk = (m_half * 2 + n_tok * 6 + len(seqs) * 6) / (n_tok + len(seqs))
    exp_mk["tok_oracle50"] = exp_mk["tok_probe50"] = tok_mk
    exp_mk["mask7"] = 7.0
    exp_mk["lay_swap_oracle"] = exp_mk["lay_swap_probe"] = 7.0
    exp_mk["lay_swap_oracle_cond"] = exp_mk["lay_swap_probe_cond"] = 7.0
    mk_bad = {k: (v, exp_mk[k]) for k, v in mean_k.items() if abs(v - exp_mk[k]) > 1e-9}
    calib["C5"] = {"mean_k": mean_k, "expected": exp_mk, "n_bad": len(mk_bad), "bad": mk_bad}
    calib["C6"] = {"perm_stats": perm_stats,
                   "max_abs_rho": float(max(abs(v) for v in perm_stats.values())),
                   "pass": bool(max(abs(v) for v in perm_stats.values()) < 0.02)}
    calib["C7"] = {"conflict_oracle": conflict_o, "conflict_probe": conflict_p,
                   "tie_min_oracle": tie_min_o, "tie_max_oracle": tie_max_o,
                   "tie_min_probe": tie_min_p, "tie_max_probe": tie_max_p,
                   "swap_rate_oracle_cond": float(cond_o.mean()),
                   "swap_rate_probe_cond": float(cond_p.mean()),
                   "cut_hist_oracle": np.bincount(cut_o, minlength=16).tolist(),
                   "prot_hist_oracle": np.bincount(prot_o, minlength=16).tolist(),
                   "cut_hist_probe": np.bincount(cut_p, minlength=16).tolist(),
                   "prot_hist_probe": np.bincount(prot_p, minlength=16).tolist()}

    # 探索的
    c8_mean = c8.mean(axis=1).tolist()
    c7_mean = c7.mean(axis=1).tolist()
    rho_L = []
    for L in range(n_layers):
        rho_L.append(float(c7_mean[L] / c8_mean[L]) if abs(c8_mean[L]) > 1e-12 else float("nan"))
    rho_glob = float((nll["u6"].mean() - nll["u7"].mean()) / (nll["u7"].mean() - nll["base"].mean()))
    GROUPS = {"G0": range(0, 4), "G1": range(4, 8), "G2": range(8, 12), "G3": range(12, 16)}
    additivity = {}
    for gname, ls in GROUPS.items():
        try:
            s24 = float((z24["nll_" + gname + "s"].astype(np.float64) - b24).mean())
            additivity[gname] = {"sum_ab7": float(c8[ls].sum(axis=0).mean()), "p24_s": s24}
        except KeyError:
            pass
    results_arm = {}
    for k, v in res.items():
        results_arm[k] = {
            "ce": float(v["nll"].mean()), "top1": float(v["acc1"].mean()),
            "delta_vs_u7": float((v["nll"].astype(np.float64) - nll["u7"]).mean()),
            "mean_k": mean_k.get(k),
        }
    exploratory = {
        "G_tok_oracle": paired(nll["u7"] - nll["tok_oracle50"], len(seqs), n_eval),
        "G_tok_probe50": paired(nll["u7"] - nll["tok_probe50"], len(seqs), n_eval),
        "G_lay_oracle_maskref": paired(nll["mask7"] - nll["lay_swap_oracle"], len(seqs), n_eval),
        "G_lay_probe_maskref": paired(nll["mask7"] - nll["lay_swap_probe"], len(seqs), n_eval),
        "G_tok_oracle_maskref": paired(nll["mask7"] - nll["tok_oracle50"], len(seqs), n_eval),
        "G_tok_probe50_maskref": paired(nll["mask7"] - nll["tok_probe50"], len(seqs), n_eval),
        "G_lay_oracle_cond": paired(nll["u7"] - nll["lay_swap_oracle_cond"], len(seqs), n_eval),
        "G_lay_probe_cond": paired(nll["u7"] - nll["lay_swap_probe_cond"], len(seqs), n_eval),
        "capture_ratio_probe_over_oracle": float(g2 / g1) if abs(g1) > 1e-12 else float("nan"),
        "c8_mean": c8_mean, "c7_mean": c7_mean, "rho_L": rho_L, "rho_glob": rho_glob,
        "additivity_p24": additivity,
    }

    out = {
        "meta": {"tag": tag, "smoke": bool(args.smoke), "windows": len(seqs), "len": ln,
                 "n_tok": int(n_tok), "n_arms": len(res), "target_names": target_names,
                 "oof_columns": ["c8_%02d" % L for L in range(n_layers)]
                                + ["c7_%02d" % L for L in range(n_layers)] + ["d_j"],
                 "design": "AX2課題設計書_16層粒度のper-tokenコスト測定と層軸の因果的predictor_20261111.md"},
        "results": results_arm,
        "confirmatory": {"T1_lay_oracle": st1, "T2_lay_probe": st2,
                         "T3_lay_probe_vs_tok_probe": st3, "T3_tost": to3,
                         "holm": ph, "reject": rej, "case": case},
        "calib": calib,
        "probe_quality": probe_q,
        "exploratory": exploratory,
    }
    with open(os.path.join(HERE, "%s_layer_cost.json" % tag), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    np.savez_compressed(
        os.path.join(HERE, "%s_layer_cost.npz" % tag),
        **{("nll_" + k): v["nll"] for k, v in res.items()},
        **{("acc1_" + k): v["acc1"] for k, v in res.items()},
        c8=c8, c7=c7, d_j=d_j,
        oof=oof_mat, X=X, wi=wi_arr.astype(np.int16), lang=lang,
        cut_o=cut_o, prot_o=prot_o, cut_p=cut_p, prot_p=prot_p,
        cond_o=cond_o, cond_p=cond_p)
    os.remove(os.path.join(HERE, "%s_layer_cost_partial.npz" % tag))

    log("")
    log("== confirmatory (Holm m=3, alpha=%.2f) ==" % ALPHA)
    log("T1 G_lay_oracle  %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f" %
        (g1, st1["t"], st1["p_two"], ph["T1"], st1["mde"]))
    log("T2 G_lay_probe   %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f" %
        (g2, st2["t"], st2["p_two"], ph["T2"], st2["mde"]))
    log("T3 diff %+.8f  p_tost %.6g  holm %.6g  equiv %s  ci90 [%.8f, %.8f]" %
        (st3["mean"], to3["p_tost"], ph["T3"], to3["equivalent"], to3["ci90"][0], to3["ci90"][1]))
    log("case = %s" % case)
    log("calib: C1 %s (maxdiff %.6g)  C2 %s  C3 bad %d  C6 %s" %
        (calib["C1"]["tier"], calib["C1"].get("maxdiff", float("nan")), calib["C2"]["tier"],
         calib["C3"]["n_bad"], calib["C6"]["pass"]))
    log("saved: %s_layer_cost.npz / .json" % tag)
    TEE.close()
    os._exit(0)


if __name__ == "__main__":
    main()
