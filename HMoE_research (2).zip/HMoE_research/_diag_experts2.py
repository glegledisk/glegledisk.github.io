#!/usr/bin/env python3
"""診断 2: 各層の y（expert 寄与）のノルムと、期待どおりの expert が使われているか。"""
import math
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, E2DIR)
from e2_rewrite_routing import RewriteMoE, make_batch, to_seq, SL, OL, V, WIDTHS  # noqa

OUTDIR = os.path.join(E2DIR, "data", "e2")


def main():
    torch.set_num_threads(4)
    arm, seed = "H+LB", 1
    model = RewriteMoE(WIDTHS[arm], seed=seed)
    model.p = {k: v for k, v in torch.load(
        os.path.join(OUTDIR, "ckpt_%s_s%d.pt" % (arm, seed)),
        map_location="cpu").items()}
    for k in model.p:
        model.p[k].requires_grad_(False)
    p = model.p

    ev = np.random.default_rng(777)
    src, out, em, _ = make_batch(ev, 32)
    xin = to_seq(src, out)
    B, T = xin.shape
    tgt = torch.from_numpy(out)
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)

    def run(force, l_only=None):
        h = p["emb.w"][xin] + p["pos.w"][:T].unsqueeze(0)
        h = h.reshape(B * T, -1)
        for l in range(model.L):
            hb = h.reshape(B, T, -1)
            q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
            kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
            v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
            att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
            att = att.masked_fill(causal, float("-inf")).softmax(-1)
            o = (att @ v).transpose(1, 2).reshape(B, T, -1)
            h = hb + F.linear(o, p[f"l{l}.o.w"])
            h = h.reshape(B * T, -1)
            logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
            topi = torch.tensor(list(force), dtype=torch.long).expand(h.shape[0], -1)
            topv = logits.gather(1, topi)
            gate = torch.softmax(
                torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
            y = torch.zeros_like(h)
            for i in range(model.E):
                tok, slot = (topi == i).nonzero(as_tuple=True)
                if tok.numel() == 0:
                    continue
                xx = h[tok]
                h1 = F.relu(F.linear(xx, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
                contrib = F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                y.index_add_(0, tok, contrib * gate[tok, slot].unsqueeze(1))
            if l == 0:
                print("      L0: ||h||=%.3f  ||y||=%.4f  h1 非零率=%.3f  "
                      "experts hit=%s"
                      % (h.norm(dim=1).mean(), y.norm(dim=1).mean(),
                         float((h1 != 0).float().mean()),
                         sorted(set(topi[0].tolist()))))
            h = h + y
            if l_only == l:
                return h
        lo = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, V)
        lg = lo[:, SL:SL + OL, :]
        lp = F.cross_entropy(lg.reshape(-1, V), tgt.reshape(-1), reduction="none")
        return h, float(lp.mean()), lo

    print("[A] force 別の y ノルムと CE")
    outs = {}
    for force in [(2, 3), (6, 7), (0, 1)]:
        print("    force=%s" % str(force))
        h, ce, lo = run(force)
        outs[force] = (h, lo)
        print("      -> CE %.6f  ||h_final||=%.4f" % (ce, h.norm(dim=1).mean()))

    print("\n[B] 出力ロジットの差")
    print("    max|logits(2,3) − logits(6,7)| = %.4e"
          % float((outs[(2, 3)][1] - outs[(6, 7)][1]).abs().max()))
    print("    max|logits(2,3) − logits(0,1)| = %.4e"
          % float((outs[(2, 3)][1] - outs[(0, 1)][1]).abs().max()))

    print("\n[C] 自然ルーティングとの比較（model.forward）")
    logits, _, _ = model(xin, aux_mode="none")
    lg = logits[:, SL:SL + OL, :]
    lp = F.cross_entropy(lg.reshape(-1, V), tgt.reshape(-1), reduction="none")
    print("    base CE %.6f" % float(lp.mean()))
    print("    max|logits(base) − logits(2,3)| = %.4e"
          % float((logits - outs[(2, 3)][1]).abs().max()))

    os._exit(0)


if __name__ == "__main__":
    main()
