"""AX1 probe: inspect saved per-token NLL arrays for axis-separation feasibility.

Read-only. No new measurements. Writes a UTF-8 text report.
"""
import os
import json
import numpy as np

ROOT = os.path.dirname(os.path.abspath(__file__))

NPZ_FILES = [
    "p3_topk_nll.npz",
    "p3b_alloc_nll.npz",
    "p4_adaptive_nll.npz",
    "p24_layer_cost.npz",
    "corpus_ids_seed11_w24_l256.npz",
    "p3rs2_topk_nll.npz",
    "p3c8a_topk_nll.npz",
    "p3c8b_topk_nll.npz",
]
JSON_FILES = [
    "p3_topk_summary.json",
    "p3b_alloc_summary.json",
    "p24_analysis.json",
    "p24_layer_cost.json",
]

out = []


def emit(s=""):
    out.append(str(s))


emit("=== AX1 PROBE (read-only) ===")
emit("ROOT=" + ROOT)
emit()

loaded = {}
for fn in NPZ_FILES:
    p = os.path.join(ROOT, fn)
    if not os.path.exists(p):
        emit("MISSING npz: " + fn)
        continue
    z = np.load(p, allow_pickle=False)
    loaded[fn] = z
    emit("NPZ " + fn)
    for k in z.files:
        a = z[k]
        if a.dtype.kind in "fc":
            stat = "mean=%.8f sd=%.8f min=%.6f max=%.6f nan=%d" % (
                float(np.nanmean(a)), float(np.nanstd(a)),
                float(np.nanmin(a)), float(np.nanmax(a)),
                int(np.isnan(a).sum()))
        else:
            stat = "first=%s" % (repr(a.ravel()[:4].tolist()))
        emit("  %-24s shape=%-14s dtype=%-10s %s" % (k, str(a.shape), str(a.dtype), stat))
    emit()

emit("=== elementwise identity checks (max abs diff) ===")


def get(fn, key):
    if fn not in loaded or key not in loaded[fn].files:
        return None
    a = loaded[fn][key]
    if a.dtype.kind not in "fc":
        return None
    return np.asarray(a, dtype=np.float64).ravel()


def cmp(label, fn1, k1, fn2, k2):
    a, b = get(fn1, k1), get(fn2, k2)
    if a is None or b is None:
        emit("  %-58s SKIP (missing)" % label)
        return
    if a.shape != b.shape:
        emit("  %-58s SHAPE MISMATCH %s vs %s" % (label, a.shape, b.shape))
        return
    d = np.abs(a - b)
    emit("  %-58s n=%d maxdiff=%.12g exact_equal=%s" %
         (label, a.size, float(np.nanmax(d)), bool(np.array_equal(a, b))))


cmp("P3 k8  vs P3b base", "p3_topk_nll.npz", "k8", "p3b_alloc_nll.npz", "base")
cmp("P3 k7  vs P3b u7", "p3_topk_nll.npz", "k7", "p3b_alloc_nll.npz", "u7")
cmp("P3 k8  vs P4 ?", "p3_topk_nll.npz", "k8", "p4_adaptive_nll.npz", "uniform8")
cmp("P3 k7  vs P4 uniform7", "p3_topk_nll.npz", "k7", "p4_adaptive_nll.npz", "uniform7")
cmp("P3 k6  vs P4 uniform6", "p3_topk_nll.npz", "k6", "p4_adaptive_nll.npz", "uniform6")
cmp("P3b u7 vs P4 uniform7", "p3b_alloc_nll.npz", "u7", "p4_adaptive_nll.npz", "uniform7")
cmp("P3b base vs P24 base", "p3b_alloc_nll.npz", "base", "p24_layer_cost.npz", "nll_base")
emit()

emit("=== JSON summaries (keys + selected values) ===")
for fn in JSON_FILES:
    p = os.path.join(ROOT, fn)
    if not os.path.exists(p):
        emit("MISSING json: " + fn)
        continue
    with open(p, "r", encoding="utf-8") as f:
        j = json.load(f)
    emit("JSON " + fn + " top keys=" + repr(list(j.keys())[:12]))
    s = json.dumps(j, ensure_ascii=False)
    emit("  bytes=%d  head=%s" % (len(s.encode("utf-8")), s[:900]))
    emit()

with open(os.path.join(ROOT, "_ax1_probe_out.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(out) + "\n")
print("AX1 probe done, lines=%d" % len(out))
