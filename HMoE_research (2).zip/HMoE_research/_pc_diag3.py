#!/usr/bin/env python3
"""pc1b の forward_gates と model.forward を同一バッチで比べる。"""
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import q2_difficulty_ladder as Q2
from e2b_rewrite_routing_fixed import RewriteMoE, WIDTHS
from pc1b_tier_mass_q import forward_gates

p = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q12b",
                 "ckpt_H+LB_hard_dynamic_lb_s0.pt")
m = RewriteMoE(WIDTHS["H+LB"], seed=0)
m.p = {k: v for k, v in torch.load(p, map_location="cpu").items()}
for k in m.p:
    m.p[k].requires_grad_(False)

rng = np.random.default_rng(777)
seq, typ = Q2.make_trace_batch(rng, 256, task="hard")
x = torch.from_numpy(seq)
T = seq.shape[1]
sl = slice(Q2.TRACE0 - 1, T - 1)
tgt = torch.from_numpy(seq[:, Q2.TRACE0:])


def ce(logits):
    lg = logits[:, sl, :len(Q2.VOCAB)]
    return float(F.cross_entropy(lg.reshape(-1, len(Q2.VOCAB)), tgt.reshape(-1)))


with torch.no_grad():
    a, _, _ = m(x, aux_mode="none")
    b, _ = forward_gates(m, x, k=2)
    print("model.forward  CE %.5f   forward_gates CE %.5f" % (ce(a), ce(b)))
    print("logits 差の最大 %.3e" % float((a - b).abs().max()))
os._exit(0)
