# -*- coding: utf-8 -*-
"""e7_ffn_necessity.py — E7 で FFN が本質的に必要になるかを検定する（事前ゲート）

問い: E7（全位置がランダム表を参照し、頻度だけが違う課題）では、d=64 でも FFN が必須か。
      E6 の「free が全 FFN を Pareto 支配」が「易しい位置を恒等に逃らせた」機構だとすると、
      E7 では全位置が表を参照するため FFN の寄与がまだ大きいかどうかが前提になる。

  判定基準（60 epoch、4 seeds、E6 の e6_ffn_necessity.py と同じ）:
    ΔCE = CE(frozen_identity) − CE(frozen_ffn)
      > 0.30  → FFN が本質的に必要。E7 は有効なテストベッド。→ 本実験（4 アーム 7 seed）へ
      0.05〜0.30 → 部分的に必要。容量との兼ね合い。
      < 0.05  → Attention で代替できる。E7 も失敗（周波数スキューの再設計が必要）。

  参照:
    E6（ランダム表, アンカー 25%）: d=64 で ΔCE = 0.2894（frozen_identity 0.3606 − frozen_ffn 0.0712）
"""
import os, json, time
import numpy as np
import pandas as pd
import torch
from e7_weaksep_task import run, make_lookup_table, ROLE_NAME

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)), d=64, epochs=60)
ARMS = ["frozen_ffn", "frozen_identity"]
SEEDS = [0, 1, 2, 3]
OUT = os.path.join(HERE, "e7_ffn_necessity.csv")
DEV = "cuda" if torch.cuda.is_available() else "cpu"
tab = make_lookup_table(64)

rows = []
if os.path.exists(OUT):
    rows = pd.read_csv(OUT).to_dict("records")
have = {(r["arm"], int(r["seed"])) for r in rows}

t0 = time.time()
for arm in ARMS:
    for s in SEEDS:
        if (arm, s) in have:
            continue
        r = run(arm, s, table=tab, device=DEV, **CFG)
        r["arm"] = arm
        rows.append(r)
        pd.DataFrame(rows).to_csv(OUT, index=False)
        print(f"  {arm:16s} s{s} | CE {r['ce_all']:.4f} | acc {r['acc_all']:.4f} "
              f"(ff {r['acc_ff']:.3f} / fr {r['acc_fr']:.3f} / rr {r['acc_rr']:.3f}) "
              f"| FFN {r['ffn_cost']:.3f} | {time.time()-t0:.0f}s", flush=True)

df = pd.DataFrame(rows)
print("\n=== E7（全位置ルックアップ, 頻度スキュー 75/25）, d=64, 60 epoch, device:", DEV, "===")
for a in ARMS:
    d = df[df.arm == a]
    print(f" {a:16s} n={len(d)}  CE {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"acc {d['acc_all'].mean():.4f}  "
          + " ".join(f"{nm} {d[f'acc_{nm}'].mean():.3f}" for nm in ROLE_NAME.values()))

piv = df.pivot_table(index="seed", columns="arm", values="ce_all")
if {"frozen_ffn", "frozen_identity"}.issubset(piv.columns):
    diff = (piv["frozen_identity"] - piv["frozen_ffn"]).dropna()
    print(f"\n FFN の寄与 ΔCE = {diff.mean():+.4f} ± {diff.std(ddof=1):.4f} "
          f"(n={len(diff)}, 各 seed: {[round(x,4) for x in diff.values]})")
    print("\n === 比較 ===")
    print("  E4 copy 課題            : d=64 で 0.008")
    print("  E5 (a+b) mod A          : d=16 で 0.2616 / d=64 で 0.0280")
    print("  E6 ランダム表（ anchor 25%）: d=64 で 0.2894")
    print(f"  E7 全位置参照＋頻度スキュー : d=64 で {diff.mean():+.4f}  ← 本測定")
    # 役割別の FFN 寄与（E7 独自の診断）
    print("\n === 役割別の FFN 寄与（frozen_identity − frozen_ffn の CE 差） ===")
    for nm in ROLE_NAME.values():
        p2 = df.pivot_table(index="seed", columns="arm", values=f"ce_{nm}")
        d2 = (p2["frozen_identity"] - p2["frozen_ffn"]).dropna()
        print(f"  {nm}: ΔCE = {d2.mean():+.4f}  (CE_ffn {df[df.arm=='frozen_ffn'][f'ce_{nm}'].mean():.3f} "
              f"/ CE_identity {df[df.arm=='frozen_identity'][f'ce_{nm}'].mean():.3f})")
    json.dump({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in CFG.items()},
               "device": DEV,
               "dce_mean": float(diff.mean()), "dce_sd": float(diff.std(ddof=1)),
               "n": int(len(diff)),
               "ce_ffn": float(piv["frozen_ffn"].mean()),
               "ce_id": float(piv["frozen_identity"].mean()),
               "raw": rows},
              open(os.path.join(HERE, "e7_ffn_necessity.json"), "w", encoding="utf-8"),
              indent=2, ensure_ascii=False)
print("\nsaved e7_ffn_necessity.csv / .json")
