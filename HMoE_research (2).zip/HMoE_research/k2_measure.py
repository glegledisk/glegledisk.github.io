#!/usr/bin/env python3
"""K2 測定: 教師の expert 幅が、教師非依存の層別を統制しても生徒の誤りを説明するか。

K1 のチェックポイントを読み直すだけ（**再訓練なし**）。

各トークン（2048 系列 × 47 = 96,256）で記録する量
  ce_t / ce_s   : 教師・生徒の per-token CE
  err_t / err_s : argmax の誤り（0/1）
  w_sum         : 教師が選んだ top-2 expert の幅の和（run_cond の width と同じ定義）
  w_top1        : top-1 expert の幅
  pos           : OUT 内の位置 0..46
  run           : その位置を含むコピー連長（編集位置は 0）
  dist_edit     : 最寄りの編集位置までの距離（編集なら 0）
  edit          : 編集か（= SRC と OUT が違う。データから計算できる＝教師非依存）
  tgt / src     : 目標トークン id / 参照トークン id

出力: k2_tokens.npz（キーは "<student>/<seed>/<量>"）
"""
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from p13c_retrain import (  # noqa: E402
    E2DIR, forward_forced, make_batch, to_seq, RewriteMoE, WIDTHS, SL, OL, V,
)

OUTDIR = os.path.join(E2DIR, "data", "k1")
OUT = os.path.join(HERE, "k2_tokens.npz")


def load_moe(widths, seed, path, topk):
    m = RewriteMoE(widths, seed=seed, topk=topk)
    sd = torch.load(path, map_location="cpu")
    for k, v in sd.items():
        assert m.p[k].shape == v.shape, (k, m.p[k].shape, v.shape)
        with torch.no_grad():
            m.p[k].copy_(v)
    return m


def run_lengths(mask):
    """P13 と同じ定義: 非編集の連続区間の長さ（編集位置は 0）。"""
    n, L = mask.shape
    rl = np.zeros((n, L), dtype=np.int16)
    for b in range(n):
        j = 0
        while j < L:
            if not mask[b, j]:
                k2 = j
                while k2 < L and not mask[b, k2]:
                    k2 += 1
                rl[b, j:k2] = k2 - j
                j = k2
            else:
                j += 1
    return rl


def dist_to_edit(mask):
    n, L = mask.shape
    idx = np.arange(L)
    d = np.zeros((n, L), dtype=np.int16)
    for b in range(n):
        e = idx[mask[b]]
        if e.size == 0:
            d[b] = L
        else:
            d[b] = np.abs(idx[:, None] - e[None, :]).min(1)
    return d


@torch.no_grad()
def collect(model, src, out, em, k, bs=128):
    n = src.shape[0]
    ce = np.zeros((n, OL), dtype=np.float32)
    err = np.zeros((n, OL), dtype=bool)
    wsum = np.zeros((n, OL), dtype=np.float32)
    wtop = np.zeros((n, OL), dtype=np.float32)
    wlast = np.zeros((n, OL), dtype=np.float32)
    dims = np.array(model.dims, float)
    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = to_seq(src[s], out[s])
        logits, idx_l = forward_forced(model, x, force=None, k=k)
        lg = logits[:, SL:SL + OL, :]
        tgt = torch.from_numpy(out[s])
        lp = F.cross_entropy(lg.reshape(-1, V), tgt.reshape(-1),
                             reduction="none").reshape(-1, OL)
        ce[s] = lp.numpy()
        err[s] = (lg.argmax(-1).numpy() != tgt.numpy())
        # 層平均（run_cond の "width" と同じ定義）と、最終層だけの値
        acc = np.zeros((s.stop - s.start, OL), dtype=np.float32)
        for ti in idx_l:
            a = ti.numpy()[:, SL:SL + OL, :]
            acc += dims[a].sum(-1)
        wsum[s] = acc / len(idx_l)
        a = idx_l[-1].numpy()[:, SL:SL + OL, :]
        wlast[s] = dims[a].sum(-1)
        wtop[s] = dims[a[:, :, 0]]
    return ce, err, wsum, wtop, wlast


def main():
    torch.set_num_threads(1)
    ev = np.random.default_rng(777)
    src, out, em, ks = make_batch(ev, 2048)
    print("eval n=%d edit率=%.4f" % (src.shape[0], em.mean()), flush=True)

    rl = run_lengths(em)
    de = dist_to_edit(em)
    store = {}
    seeds = [0, 1, 2]
    students = [161, 128]

    for seed in seeds:
        tp = os.path.join(OUTDIR, "ckpt_teacher_s%d.pt" % seed)
        tm = load_moe(WIDTHS["H+LB"], seed, tp, 2)
        ce_t, err_t, wsum, wtop, wlast = collect(tm, src, out, em, 2)
        store["ce_t/s%d" % seed] = ce_t
        store["err_t/s%d" % seed] = err_t
        store["w_sum/s%d" % seed] = wsum
        store["w_top1/s%d" % seed] = wtop
        store["w_last/s%d" % seed] = wlast
        print("  teacher s%d  CE %.4f  width %.1f（層平均） 最終層 %.1f"
              % (seed, ce_t.mean(), wsum.mean(), wlast.mean()), flush=True)
        for w in students:
            dp = os.path.join(OUTDIR, "ckpt_dense%d_s%d.pt" % (w, seed))
            dm = load_moe([w], seed, dp, 1)
            ce_s, err_s, _, _, _ = collect(dm, src, out, em, 1)
            store["ce_s%d/s%d" % (w, seed)] = ce_s
            store["err_s%d/s%d" % (w, seed)] = err_s
            print("  dense%d s%d  CE %.4f" % (w, seed, ce_s.mean()), flush=True)

    store["pos"] = np.tile(np.arange(OL, dtype=np.int16), (src.shape[0], 1))
    store["run"] = rl
    store["dist_edit"] = de
    store["edit"] = em.astype(np.int8)
    store["tgt"] = out.astype(np.int8)
    store["src"] = src.astype(np.int8)
    np.savez_compressed(OUT, **{k: v.astype(np.float32) if v.dtype.kind == "f"
                                else v for k, v in store.items()})
    print("[write] %s  (%d keys, %d tokens)" % (OUT, len(store), src.size))


if __name__ == "__main__":
    main()
