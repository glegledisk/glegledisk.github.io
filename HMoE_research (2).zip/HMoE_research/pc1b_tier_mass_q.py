#!/usr/bin/env python3
"""PC1b: 事前チェック (1)(2) を収束済み HMoE で回す（Q12b の dynamic_lb, 6 seed）。

素材: simulation_hmoe_mmlu/data/q12b/ckpt_H+LB_hard_dynamic_lb_s{0..5}.pt
      （幅 32/32/96/96/160/160/224/224, top-2, 4 層, d=128, 6 epoch, payload acc ~0.99）
データ: q2.make_trace_batch(task="hard") — 構造トークン（op, '='）と payload（8 桁）が
        明示的にラベル付けされているので、内容の代理が「桁」でなく「型」で取れる。

(1) 階層質量の分散: 位置・型で説明される割合、JS の分解、1/W との一致
(2) w x share: 出現率と幅の関係
出力: pc1b_tier_mass_q.json
"""
import json
import math
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import q2_difficulty_ladder as Q2  # noqa: E402  （E2.SEQ=128 を設定）
from e2b_rewrite_routing_fixed import RewriteMoE, WIDTHS  # noqa: E402

TIERS = [(0, 1), (2, 3), (4, 5), (6, 7)]
TYP_INPUT, TYP_STRUCT, TYP_PAYLOAD = 0, 1, 2
OUTDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q12b")


def forward_gates(model, idx, k=2):
    p = model.p
    B, T = idx.shape
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    gates_l = []
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
        topv, topi = logits.topk(k, dim=1)
        gate = torch.softmax(
            torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
        gates_l.append(gate.detach())
        y = torch.zeros_like(h)
        for i in range(model.E):
            tok, slot = (topi == i).nonzero(as_tuple=True)
            if tok.numel() == 0:
                continue
            x = h[tok]
            h1 = F.relu(F.linear(x, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
            y.index_add_(0, tok,
                         F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                         * gate[tok, i].unsqueeze(1))
        h = h + y
    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, p["head.w"].shape[0])
    return out, gates_l


def eta2(vals, groups):
    gm = vals.mean()
    ss_tot = ((vals - gm) ** 2).sum()
    ss_b = 0.0
    for g in np.unique(groups):
        m = groups == g
        ss_b += m.sum() * (vals[m].mean() - gm) ** 2
    return float(ss_b / max(ss_tot, 1e-30))


def js_vec(a, b, eps=1e-12):
    a = np.clip(a, eps, 1)
    b = np.clip(b, eps, 1)
    m = 0.5 * (a + b)
    return (0.5 * (a * np.log(a / m)).sum(-1)
            + 0.5 * (b * np.log(b / m)).sum(-1))


@torch.no_grad()
def main():
    torch.set_num_threads(6)
    n_eval = 1024
    rng = np.random.default_rng(777)
    seq, typ = Q2.make_trace_batch(rng, n_eval, task="hard")
    T = seq.shape[1]
    sl = slice(Q2.TRACE0 - 1, T - 1)          # 予測する h の位置
    typ_t = typ[:, Q2.TRACE0:]                # 対応する目標トークンの型
    print("eval n=%d  T=%d  slice=%s  struct率=%.3f payload率=%.3f"
          % (n_eval, T, sl, (typ_t == TYP_STRUCT).mean(), (typ_t == TYP_PAYLOAD).mean()),
          flush=True)

    E = 8
    onehot = np.zeros((E, len(TIERS)), dtype=np.float32)
    for gi, (a, b) in enumerate(TIERS):
        onehot[a:b + 1, gi] = 1.0
    wg = np.array([WIDTHS["H+LB"][a] for a, b in TIERS], float)
    p_w = (1.0 / wg) / (1.0 / wg).sum()

    res = {"n_eval": n_eval, "source": "q12b dynamic_lb hard", "per_seed": {}}
    for seed in range(6):
        path = os.path.join(OUTDIR, "ckpt_H+LB_hard_dynamic_lb_s%d.pt" % seed)
        if not os.path.exists(path):
            continue
        model = RewriteMoE(WIDTHS["H+LB"], seed=seed)
        model.p = {k: v for k, v in torch.load(path, map_location="cpu").items()}
        for k in model.p:
            model.p[k].requires_grad_(False)
        L = model.L
        mass = np.zeros((n_eval, T - Q2.TRACE0, L, len(TIERS)), dtype=np.float32)
        occ = np.zeros((L, E))
        ntok = 0
        ce = []
        for i in range(0, n_eval, 128):
            s = slice(i, min(i + 128, n_eval))
            x = torch.from_numpy(seq[s])
            logits, gl = forward_gates(model, x, k=2)
            lg = logits[:, sl, :len(Q2.VOCAB)]
            tgt = torch.from_numpy(seq[s][:, Q2.TRACE0:])
            ce.append(F.cross_entropy(lg.reshape(-1, len(Q2.VOCAB)),
                                      tgt.reshape(-1)).item())
            B = x.shape[0]
            for l, g in enumerate(gl):
                g3 = g.reshape(B, T, E).numpy()[:, sl, :]
                mass[s, :, l, :] = g3 @ onehot
                occ[l] += (g3 > 0).sum((0, 1))
            ntok += B * (T - Q2.TRACE0)

        mbar = mass.mean((0, 1))
        pos = np.tile(np.arange(T - Q2.TRACE0), n_eval)
        edt = typ_t.reshape(-1)
        rows = []
        for l in range(L):
            for gi in range(len(TIERS)):
                v = mass[:, :, l, gi].reshape(-1)
                rows.append({"layer": l, "tier": gi, "width": WIDTHS["H+LB"][TIERS[gi][0]],
                             "mean": float(v.mean()), "sd": float(v.std(ddof=1)),
                             "eta2_pos": eta2(v, pos), "eta2_typ": eta2(v, edt)})
        js_all = js_vec(mass, mbar[None]).mean(-1)              # (n, T')
        mbar_p = mass.mean(0)
        js_btw = float(js_vec(mbar_p, mbar[None]).mean())
        js_wth = float(js_vec(mass, mbar_p[None]).mean())
        js_ser = float(js_vec(mass.mean(1), mbar[None]).mean())
        m_struct = mass[typ_t == TYP_STRUCT].mean(0)
        m_pay = mass[typ_t == TYP_PAYLOAD].mean(0)
        sh = occ / ntok
        w = np.array(WIDTHS["H+LB"], float)
        ws = sh * w[None, :]
        lw = np.tile(np.log(w), L)
        ls = np.log(np.clip(sh, 1e-9, None)).reshape(-1)
        res["per_seed"][seed] = {
            "ce": float(np.mean(ce)),
            "tier": rows,
            "mbar": mbar.round(5).tolist(),
            "width_implied": p_w.round(5).tolist(),
            "l1_vs_width_implied": float(np.abs(mbar - p_w[None, :]).mean()),
            "js_vs_width_implied": float(np.mean([js_vec(mbar[l], p_w) for l in range(L)])),
            "js_token": float(js_all.mean()),
            "js_token_p90": float(np.percentile(js_all, 90)),
            "js_between_pos": js_btw, "js_within_pos": js_wth, "js_series": js_ser,
            "js_struct_vs_payload": float(np.mean([js_vec(m_struct[l], m_pay[l])
                                                   for l in range(L)])),
            "eta2_pos_mean": float(np.mean([r["eta2_pos"] for r in rows])),
            "eta2_typ_mean": float(np.mean([r["eta2_typ"] for r in rows])),
            "share": sh.round(4).tolist(),
            "w_x_share_cv": float(ws.std() / ws.mean()),
            "slope_logshare_logw": float(np.polyfit(lw, ls, 1)[0]),
            "spearman_w_share": float(np.corrcoef(
                np.argsort(np.argsort(w))[None, :].repeat(L, 0).reshape(-1),
                np.argsort(np.argsort(sh, axis=1), axis=1).reshape(-1))[0, 1]),
        }
        r = res["per_seed"][seed]
        print("[s%d] CE %.3f  w %.1f  | JS tok %.3f (pos間 %.3f / pos内 %.3f / 系列 %.4f)"
              % (seed, r["ce"], float((sh @ w).mean()), r["js_token"],
                 js_btw, js_wth, js_ser), flush=True)
        print("     eta2_pos %.3f  eta2_typ %.3f  JS(struct,payload) %.3f  1/W との L1 %.3f"
              % (r["eta2_pos_mean"], r["eta2_typ_mean"], r["js_struct_vs_payload"],
                 r["l1_vs_width_implied"]), flush=True)
        print("     w*share CV %.3f  slope %+.2f  spearman %+.2f  | 小 expert 選択率 %s"
              % (r["w_x_share_cv"], r["slope_logshare_logw"], r["spearman_w_share"],
                 np.round(sh[:, :2].mean(1), 3).tolist()), flush=True)

    with open(os.path.join(HERE, "pc1b_tier_mass_q.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2, default=float)
    print("\n=== seed 平均 ===")
    for k in ["ce", "js_token", "js_between_pos", "js_within_pos", "js_series",
              "js_struct_vs_payload", "eta2_pos_mean", "eta2_typ_mean",
              "l1_vs_width_implied", "js_vs_width_implied",
              "w_x_share_cv", "slope_logshare_logw", "spearman_w_share"]:
        v = [res["per_seed"][s][k] for s in res["per_seed"]]
        print("  %-24s %s  mean %.4f" % (k, np.round(v, 3).tolist(), np.mean(v)))
    print("\nsaved: pc1b_tier_mass_q.json")
    os._exit(0)


if __name__ == "__main__":
    main()
