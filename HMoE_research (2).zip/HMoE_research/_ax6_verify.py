# -*- coding: utf-8 -*-
"""AX6 Step 4: 独立再計算（ax6_transfer.py を import しない別経路）。

scipy.stats.ttest_rel 経路で Δ・se・t・p・Holm・MDE・上位 1% 寄与率を作り直し、
npz の生配列から分割・決定・mean_k・8-gram・校正・H3 重みを再構築して
ax6_transfer.json と突合する。使い方: python _ax6_verify.py [tag]
"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats as scistats

HERE = os.path.dirname(os.path.abspath(__file__))
TAG = sys.argv[1] if len(sys.argv) > 1 else "ax6"
ALPHA = 0.05
N_LAYERS = 16
H3_NS = [48, 102, 181, 340, 630, 1224]
H3_ARMS = ["uni48", "uni102", "uni181", "uni340", "uni630", "uni1224"]
SEED_RAND = 6201

ITEMS, MISMATCH = [], []


def chk(name, got, exp, rtol=1e-6, atol=1e-9):
    ITEMS.append(name)
    ok = False
    if isinstance(exp, (list, tuple)):
        ok = (list(got) == list(exp))
    elif isinstance(exp, bool) or isinstance(exp, str):
        ok = (got == exp)
    elif isinstance(exp, (int, np.integer)) and isinstance(got, (int, np.integer)):
        ok = (int(got) == int(exp))
    else:
        try:
            ok = math.isclose(float(got), float(exp), rel_tol=rtol, abs_tol=atol)
        except Exception:
            ok = False
    if not ok:
        MISMATCH.append((name, got, exp))


def rst(d, tok_per_win=255):
    d = np.asarray(d, dtype=np.float64).ravel()
    n = d.size
    m = float(d.mean())
    t, p = scistats.ttest_rel(d, np.zeros_like(d))
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    tc975 = float(scistats.t.ppf(0.975, n - 1))
    tc95 = float(scistats.t.ppf(0.95, n - 1))
    wm = d.reshape(-1, tok_per_win).mean(axis=1)
    sew = float(wm.std(ddof=1) / math.sqrt(wm.size))
    srt = np.sort(np.abs(d))[::-1]
    k1 = max(1, int(math.ceil(0.01 * n)))
    return {"mean": m, "sd": sd, "se": se, "t": float(t), "p_two": float(p),
            "mde": tc975 * se, "ci95": [m - tc975 * se, m + tc975 * se],
            "ci90": [m - tc95 * se, m + tc95 * se],
            "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
            "median": float(np.median(d)), "se_win": sew,
            "top1_abs_share": float(srt[:k1].sum() / srt.sum())}


def holm_adj(pvals):
    ids = sorted(pvals, key=lambda k: pvals[k])
    out, run = {}, 0.0
    for i, k in enumerate(ids):
        run = max(run, (len(ids) - i) * pvals[k])
        out[k] = min(1.0, run)
    return out


def grams8(x):
    return set(tuple(int(v) for v in x[i:i + 8]) for i in range(len(x) - 7))


def overlap8(a, b):
    gb = grams8(b)
    return float(np.mean([tuple(int(v) for v in a[i:i + 8]) in gb
                         for i in range(len(a) - 7)]))


def uniform_lengths(n_unit, total):
    base, rem = divmod(total, n_unit)
    lens = np.full(n_unit, base, dtype=np.int64)
    lens[:rem] += 1
    return lens


def uid_from_lens(lens):
    return np.repeat(np.arange(len(lens), dtype=np.int32), lens)


def unit_targets(c8, c7, uid, n_unit):
    cnt = np.bincount(uid, minlength=n_unit).astype(np.float64)
    a = np.stack([np.bincount(uid, weights=c8[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    b = np.stack([np.bincount(uid, weights=c7[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    return np.concatenate([a, b], axis=1)


def unit_decision(Y):
    cut = np.argmin(Y[:, N_LAYERS:], axis=1).astype(np.int8)
    Q = Y[:, :N_LAYERS].copy()
    Q[np.arange(Y.shape[0]), cut] = -np.inf
    prot = np.argmax(Q, axis=1).astype(np.int8)
    return cut, prot


def mean_k_from(uid, cut, prot, n_tok, nw, n_eval, ln):
    km = np.full((N_LAYERS, n_tok), 7, dtype=np.int8)
    for u in range(len(cut)):
        sel = (uid == u)
        km[cut[u], sel] = 6
        km[prot[u], sel] = 8
    km = km.reshape(N_LAYERS, nw, n_eval)
    km = np.concatenate([km, np.full((N_LAYERS, nw, 1), 7, dtype=np.int8)], axis=2)
    return float(km.mean())


def main():
    z = np.load(os.path.join(HERE, "%s_transfer.npz" % TAG))
    with open(os.path.join(HERE, "%s_transfer.json" % TAG), encoding="utf-8") as fp:
        J = json.load(fp)
    n_tok = J["meta"]["n_tok"]
    nw = J["meta"]["windows"]
    n_eval = n_tok // nw
    ln = J["meta"]["len"]
    arms = [k[4:] for k in z.files if k.startswith("nll_")]
    N = {a: z["nll_" + a].astype(np.float64) for a in arms}
    c8, c7 = z["c8"].astype(np.float64), z["c7"].astype(np.float64)
    u7 = N["u7"]

    chk("meta.n_arms", len(arms), J["meta"]["n_arms"])
    chk("meta.n_tok", int(n_tok), J["meta"]["n_tok"])
    for a in arms:
        v = z["nll_" + a]
        chk("C4.shape_" + a, bool(v.shape == (n_tok,)), True)
        chk("C4.finite_" + a, bool(np.isfinite(v).all()), True)

    # ---- C2 8-gram ----
    z3 = np.load(os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz"), allow_pickle=True)
    z6 = np.load(os.path.join(HERE, "corpus_ids_ax6_w24_l256.npz"), allow_pickle=True)
    ov = {lg: overlap8(z3[lg + "_ids"], z6[lg + "_ids"]) for lg in ("en", "ja")}
    chk("C2.ov_en", ov["en"], J["calib"]["C2"]["overlap8_en"])
    chk("C2.ov_ja", ov["ja"], J["calib"]["C2"]["overlap8_ja"])
    chk("C2.pass", bool(ov["en"] < 0.05 and ov["ja"] < 0.20), J["calib"]["C2"]["pass"])

    # ---- 分割の独立再構築 ----
    parts = {"global1": np.zeros(n_tok, dtype=np.int32),
             "uni48": np.repeat(np.arange(nw, dtype=np.int32), n_eval),
             "tok12240": np.arange(n_tok, dtype=np.int32)}
    for n in (102, 181, 340, 630, 1224):
        parts["uni%d" % n] = uid_from_lens(uniform_lengths(n, n_tok))
    parts["rand340"] = parts["uni340"].copy()
    for nm, uid in parts.items():
        chk("C3.uid_" + nm, int((uid != z["uid_" + nm]).sum()), 0)

    # ---- 決定の再現 ----
    mk, cuts = {}, {}
    for nm, uid in parts.items():
        nu = int(uid.max()) + 1
        if nm == "rand340":
            rng = np.random.RandomState(SEED_RAND)
            cut = rng.randint(0, N_LAYERS, size=nu).astype(np.int8)
            draw = rng.randint(0, N_LAYERS - 1, size=nu)
            prot = (draw + (draw >= cut)).astype(np.int8)
        else:
            cut, prot = unit_decision(unit_targets(c8, c7, uid, nu))
        cuts[nm] = (cut, prot)
        chk("C5.cut_" + nm, int((cut != z["cut_" + nm]).sum()), 0)
        chk("C5.prot_" + nm, int((prot != z["prot_" + nm]).sum()), 0)
        chk("C5.conflict_" + nm, int((cut == prot).sum()), 0)
        mk[nm] = mean_k_from(uid, cut, prot, n_tok, nw, n_eval, ln)
        chk("C3.meank_" + nm, mk[nm], float(J["calib"]["C3"]["mean_k"][nm]))
    chk("C3.replay_all", all(v == 1 for v in J["calib"]["C3"]["decision_replay"].values()), True)
    chk("C3.n_bad", int(J["calib"]["C3"]["n_bad"]), 0)

    # ---- C1 ----
    d1 = N["base_rep"] - N["base"]
    chk("C1.maxdiff", float(np.abs(d1).max()), J["calib"]["C1"]["base_maxdiff"])
    exp_tier = "SKIP" if J["meta"]["smoke"] else \
        ("A" if float(np.abs(d1).max()) == 0.0 else "FAIL")
    chk("C1.tier", J["calib"]["C1"]["tier"], exp_tier)

    # ---- C6 / C7 ----
    C6 = J["calib"]["C6"]
    chk("C6.random_le_oracle",
        bool((u7 - N["rand340"]).mean() <= (u7 - N["tok12240"]).mean()),
        C6["random_le_oracle"])
    chk("C6.random_gain", float((u7 - N["rand340"]).mean()), C6["random_gain"])
    chk("C6.oracle_gain", float((u7 - N["tok12240"]).mean()), C6["oracle_gain"])
    w = np.log(np.array(H3_NS, dtype=np.float64))
    w -= w.mean()
    with open(os.path.join(HERE, "ax5_granularity_mech.json"), encoding="utf-8") as fp:
        w5 = np.array(json.load(fp)["manipulation_check_H3"]["weights"])
    chk("C7.weights_npz", float(np.abs(z["w"] - w).max()), 0.0)
    chk("C7.weights_ax5", float(np.abs(w - w5).max()), 0.0)
    chk("C7.sum", float(w.sum()), 0.0, atol=1e-12)
    chk("C7.pass", bool(np.abs(w - w5).max() < 1e-12), J["calib"]["C7"]["pass"])

    # ---- 確認的 ----
    d_k1 = np.zeros(n_tok, dtype=np.float64)
    for wk, nm in zip(w, H3_ARMS):
        d_k1 -= wk * N[nm]
    d_k2 = N["uni48"] - N["uni1224"]
    for sid, d, key in (("K1", d_k1, "K1_h3_contrast"),
                        ("K2", d_k2, "K2_endpoints")):
        s = rst(d, n_eval)
        rj = J["confirmatory"][key]
        for f in ("mean", "sd", "se", "t", "p_two", "mde", "median",
                  "se_win", "top1_abs_share"):
            chk("%s.%s" % (sid, f), s[f], rj[f])
        chk("%s.n_pos" % sid, s["n_pos"], rj["n_pos"])
        chk("%s.n_neg" % sid, s["n_neg"], rj["n_neg"])
        for f in ("ci95", "ci90"):
            chk("%s.%s_lo" % (sid, f), s[f][0], rj[f][0])
            chk("%s.%s_hi" % (sid, f), s[f][1], rj[f][1])
    ph = holm_adj({"K1": J["confirmatory"]["K1_h3_contrast"]["p_two"],
                   "K2": J["confirmatory"]["K2_endpoints"]["p_two"]})
    for k, v in ph.items():
        chk("holm." + k, v, J["confirmatory"]["holm"][k])
    rej = {k: ph[k] < ALPHA for k in ph}
    m1, m2 = float(d_k1.mean()), float(d_k2.mean())
    case = ("A" if (rej["K1"] and m1 > 0 and rej["K2"] and m2 > 0) else
            "B" if (rej["K1"] and m1 > 0) else
            "D" if (rej["K1"] and m1 < 0) else "C")
    chk("case", case, J["confirmatory"]["case"])

    # ---- gains / curve ----
    for nm in list(parts) + ["base", "base_rep"]:
        chk("gain." + nm, float((u7 - N[nm]).mean()), J["gains"][nm]["mean"])
    for nm in H3_ARMS:
        chk("curve." + nm, float((u7 - N[nm]).mean()),
            J["exploratory"]["granularity_curve"][nm])
    chk("exp.top1_K1", rst(d_k1, n_eval)["top1_abs_share"],
        J["exploratory"]["top1_abs_share_K1"])
    chk("exp.top1_K2", rst(d_k2, n_eval)["top1_abs_share"],
        J["exploratory"]["top1_abs_share_K2"])

    # ---- 非有限値（AX5 查読指摘 1 の反映確認） ----
    bad = []

    def walk(x, p=""):
        if isinstance(x, dict):
            for k, v in x.items():
                walk(v, p + "/" + k)
        elif isinstance(x, list):
            for i, v in enumerate(x):
                walk(v, p + "/%d" % i)
        elif isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
            bad.append(p)

    walk(J)
    chk("json.non_finite", len(bad), 0)

    lines = ["AX6 Step 4 verify (tag=%s)" % TAG,
             "items=%d  mismatches=%d" % (len(ITEMS), len(MISMATCH))]
    for nm, got, exp in MISMATCH[:25]:
        lines.append("  MISMATCH %s: got=%r exp=%r" % (nm, got, exp))
    txt = "\n".join(lines)
    print(txt)
    with open(os.path.join(HERE, "_ax6_verify_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write(txt + "\n")


if __name__ == "__main__":
    main()
