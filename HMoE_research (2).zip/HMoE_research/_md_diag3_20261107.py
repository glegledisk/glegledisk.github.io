# -*- coding: utf-8 -*-
"""_md_diag3_20261107.py — CJK 間の余計な空白の場所を出す使い捨て診断。"""
import re
import sys
from markdown_it import MarkdownIt

path = sys.argv[1]
lines = open(path, encoding="utf-8").read().split("\n")
md = MarkdownIt("commonmark").enable("table")
html = md.render("\n".join(lines))
body = re.sub(r"<pre>.*?</pre>", "", html, flags=re.S)
body = re.sub(r"<code>.*?</code>", "<code>X</code>", body, flags=re.S)
for m in re.finditer(r"[\u3040-\u30ff\u4e00-\u9fff]\s+[\u3040-\u30ff\u4e00-\u9fff]", body):
    a, b = max(0, m.start() - 70), min(len(body), m.end() + 70)
    print(repr(body[a:b]))
    print("---")
