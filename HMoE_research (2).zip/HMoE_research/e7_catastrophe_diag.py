# -*- coding: utf-8 -*-
"""e7_catastrophe_diag.py — 壊滅的 seed の診断（ウォームアップバイアスが訓練を不安定化するメカニズム）

## 動機（warm_bias 感度・13 seed レポート）
sp_wb3_w10 は s7 で CE 1.389、sp_wb4_w10 は s8 で CE 2.439 の壊滅的失敗。典型 seed では
CE 0.02〜0.05（全アーム中最良）なので、「なぜ特定 seed で訓練が壊れるのか」を特定する。

## 仮説
- H1: warmup 中のソフトバイアスで ff 位置の identity gate が飽和 → FFN Expert が
  梯度飢餓 → 解凍後に戻せない。
- H2: router logit が warmup 中に爆発/飽和 → 解凍後に勾配が消え学習が停止する。
- H3: entropy 項 / コスト項との相互作用で warmup 中に最適化が不安定化する。
- H4: seed 自体が不安定（warm bias なしでも壊れる）—— warm bias は無実。

## ラン（すべて tokid + entropy β=0.05, λ=0.15, warmup 10 ep, 60 epoch）
| ラン | 内容 | CSV 値 |
|---|---|---|
| wb3_s7 | 壊滅的本体 | 1.389 |
| wb3_s0 | 健全コントロール | 0.020 |
| wb2_s7 / wb4_s7 | 同一 seed の用量比較（s7 では両方健全） | 0.112 / 0.070 |
| bias10_s7 / tokid_entropy_s7 | warm bias なし（H4 の検証） | 0.158 / — |
| wb3_s7_noent | 反実仮想: β=0（H3） | — |
| wb3_s7_nolam | 反実仮想: warmup 中 λ=0（H3） | — |
| wb4_s8 / wb3_s8 / wb2_s8 | 第 2 の壊滅 seed での一般性 | 2.439 / 0.139 / 0.020 |

判定: ①最終 CE が CSV と一致（再現性）②発散 epoch・フェーズ ③発散時のゲート状態
（idmass・in-zone・Expert 質量・logit 規模・gate entropy）④同 seed の warm bias なしランとの比較。
"""
import json
import os
import time

import numpy as np
import pandas as pd
import torch

from e7_stabilize_task import run, make_lookup_table, ROLE_NAME

HERE = os.path.dirname(os.path.abspath(__file__))
DEV = "cuda" if torch.cuda.is_available() else "cpu"
tab = make_lookup_table(64)
CFG = dict(L=16, A=64, w_freq=0.75, freq_vals=tuple(range(16)), d=64, epochs=60)
SPEC_FREE = dict(route="free", router="linear", stab="entropy", extra="tokid")

RUNS = {
    # name: (variant, seed, kwargs)
    "wb3_s7":        ("sp_wb3_w10", 7, dict(warmup=10, warm_bias=3.0, lam_post=0.15)),
    "wb3_s0":        ("sp_wb3_w10", 0, dict(warmup=10, warm_bias=3.0, lam_post=0.15)),
    "wb2_s7":        ("sp_wb2_w10", 7, dict(warmup=10, warm_bias=2.0, lam_post=0.15)),
    "wb4_s7":        ("sp_wb4_w10", 7, dict(warmup=10, warm_bias=4.0, lam_post=0.15)),
    "bias10_s7":     ("bias10", 7, dict(warmup=0, id_bias=1.0, lam_post=0.15)),
    "tokid_ent_s7":  ("tokid_entropy", 7, dict(warmup=0, lam_post=0.15)),
    "wb3_s7_noent":  ("sp_wb3_w10", 7, dict(warmup=10, warm_bias=3.0, lam_post=0.15, ent_beta=0.0)),
    "wb3_s7_nolam":  ("sp_wb3_w10", 7, dict(warmup=10, warm_bias=3.0, lam_post=0.15, lam_cost=0.0)),
    "wb4_s8":        ("sp_wb4_w10", 8, dict(warmup=10, warm_bias=4.0, lam_post=0.15)),
    "wb3_s8":        ("sp_wb3_w10", 8, dict(warmup=10, warm_bias=3.0, lam_post=0.15)),
    "wb2_s8":        ("sp_wb2_w10", 8, dict(warmup=10, warm_bias=2.0, lam_post=0.15)),
}

csv = pd.read_csv(os.path.join(HERE, "e7_staged_7seed.csv"))
OUTJ = os.path.join(HERE, "e7_catastrophe_traces.json")
results, traces = {}, {}
if os.path.exists(OUTJ):
    old = json.load(open(OUTJ, encoding="utf-8"))
    results, traces = old.get("results", {}), old.get("traces", {})
    print(f"既存 {len(results)} ランを再利用")

t0 = time.time()
for name, (variant, seed, kw) in RUNS.items():
    if name in results:
        continue
    base = dict(table=tab, device=DEV, spec=SPEC_FREE, lam_cost=0.15, ent_beta=0.05,
                trace=True, **CFG)
    base.update(kw)                      # アーム固有の指定が既定を上書きする
    r = run(variant, seed, **base)
    results[name] = {k: v for k, v in r.items() if k not in ("trace", "probe_log")}
    traces[name] = json.loads(r["trace"])
    # 逐次保存（失敗しても完了分は残す）
    json.dump({"results": results, "traces": traces},
              open(OUTJ, "w", encoding="utf-8"), indent=2, ensure_ascii=False)
    m = csv[(csv.variant == variant) & (csv.seed == seed)]
    old_ce = float(m.iloc[0]["ce_all"]) if len(m) else float("nan")
    repro = "" if not len(m) else ("  [再現OK]" if abs(r["ce_all"] - old_ce) < 1e-9
                                   else f"  [不一致! CSV {old_ce:.4f}]")
    print(f"[{name:14s}] CE {r['ce_all']:.4f}  FFN {r['ffn_cost']:.3f}  acc {r['acc_all']:.4f} "
          f"(ff {r['acc_ff']:.3f} / fr {r['acc_fr']:.3f} / rr {r['acc_rr']:.3f}){repro}  "
          f"{time.time()-t0:.0f}s", flush=True)

json.dump({"results": results, "traces": traces},
          open(OUTJ, "w", encoding="utf-8"), indent=2, ensure_ascii=False)

EPOCHS = [0, 1, 2, 4, 6, 8, 9, 10, 11, 12, 14, 16, 20, 25, 30, 40, 50, 59]
COLS = ["train_ce", "val_ce", "ce_ff", "ce_fr", "ce_rr", "ffn_cost", "idmass_ff", "idmass_fr",
        "idmass_rr", "tr_inzone_ff", "tr_inzone_rr", "tr_margin_p50_ff", "gate_ent",
        "lg_absmax", "gnorm_router"]

print("\n=== 発散の特定（val_ce > 0.3 を最初に超えた epoch） ===")
print(f"{'run':14s} {'finalCE':>8s} {'div_ep':>6s} {'phase':>6s} {'val@div':>8s} {'ce_ff@div':>9s} "
      f"{'ce_rr@div':>9s} {'idm_ff@div':>9s} {'inz_ff@div':>9s} {'ent@div':>7s} {'lgmax@div':>8s}")
div_info = {}
for name, tr in traces.items():
    div = next((e for e, r in enumerate(tr) if r["val_ce"] > 0.3), None)
    div_info[name] = div
    r = tr[div] if div is not None else tr[-1]
    print(f"{name:14s} {results[name]['ce_all']:8.4f} "
          f"{'—' if div is None else div:>6} {'—' if div is None else r['phase']:>6s} "
          f"{'—' if div is None else round(r['val_ce'], 4):>8} "
          f"{'—' if div is None else round(r['ce_ff'], 4):>9} "
          f"{'—' if div is None else round(r['ce_rr'], 4):>9} "
          f"{'—' if div is None else round(r['idmass_ff'], 3):>9} "
          f"{'—' if div is None else round(r['tr_inzone_ff'], 3):>9} "
          f"{'—' if div is None else round(r['gate_ent'], 3):>7} "
          f"{'—' if div is None else round(r['lg_absmax'], 1):>8}")

print("\n=== 最終状態（val_ce は trace プローブ、finalCE は本eval） ===")
print(f"{'run':14s} {'finalCE':>8s} {'val_ce':>8s} {'ffn':>5s} {'idm_ff':>6s} {'idm_rr':>6s} "
      f"{'inz_ff':>6s} {'m50_ff':>7s} {'ent':>5s} {'lgmax':>7s} {'out_ent':>7s} {'mode%':>6s}")
for name in RUNS:
    r, tr = results[name], traces[name][-1]
    print(f"{name:14s} {r['ce_all']:8.4f} {tr['val_ce']:8.4f} {tr['ffn_cost']:5.3f} "
          f"{tr['idmass_ff']:6.3f} {tr['idmass_rr']:6.3f} {tr['tr_inzone_ff']:6.3f} "
          f"{tr['tr_margin_p50_ff']:+7.2f} {tr['gate_ent']:5.3f} {tr['lg_absmax']:7.1f} "
          f"{r['out_ent']:7.3f} {r['pred_mode_frac']:6.3f}")

print("\n=== per-epoch トレース（主要ラン） ===")
for name in ["wb3_s0", "wb3_s7", "bias10_s7", "tokid_ent_s7", "wb3_s7_noent", "wb3_s7_nolam",
             "wb4_s8", "wb3_s8", "wb2_s7", "wb4_s7", "wb2_s8"]:
    tr = traces[name]
    print(f"\n-- {name} --   ep phase " + " ".join(f"{c[:7]:>7s}" for c in COLS))
    for rec in tr:
        if rec["epoch"] in EPOCHS:
            vals = []
            for c in COLS:
                v = rec[c]
                vals.append("   None" if v is None else f"{v:7.3f}")
            print(f"      {rec['epoch']:3d} {rec['phase']:5s} " + " ".join(vals))

print("\n=== Expert 質量の推移（l1, emass0〜7。7=恒等） ===")
for name in ["wb3_s0", "wb3_s7", "wb4_s8", "bias10_s7"]:
    tr = traces[name]
    print(f"\n-- {name} --")
    print("   ep " + "".join(f"{'e'+str(e):>7s}" for e in range(8)) + "   min(FFN)")
    for rec in tr:
        if rec["epoch"] in (0, 4, 9, 10, 12, 15, 20, 30, 45, 59):
            em = [rec[f"emass{e}"] for e in range(8)]
            print(f"  {rec['epoch']:3d} " + "".join(f"{x:7.3f}" for x in em)
                  + f" {min(em[:7]):9.4f}")

print("\n=== 同一 seed での用量比較（final CE / ffn / idm_ff） ===")
for s in (7, 8):
    names = [n for n in RUNS if n.endswith(f"_s{s}")]
    print(f" seed {s}: " + "  |  ".join(
        f"{n}: CE {results[n]['ce_all']:.3f} ffn {results[n]['ffn_cost']:.2f} "
        f"idm_ff {traces[n][-1]['idmass_ff']:.2f}" for n in names))

print("\nsaved e7_catastrophe_traces.json")
