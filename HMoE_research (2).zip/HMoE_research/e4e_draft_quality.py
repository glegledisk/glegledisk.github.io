# -*- coding: utf-8 -*-
"""e4e_draft_quality.py — ② ドラフトを十分に学習させ、一致度シグナルを再評価する

E4d の `draft_agree` は AUC 0.500（完全無情報）だった。原因候補は 2 つ:
  (a) 特徴の設計が悪い（一致度は編集位置を反映しない）
  (b) ドラフト自体が弱い（linear 1 層、補助 CE の重み 0.1 だけ）

ここでは (b) を潰す。補助 CE の重みとドラフトの容量を上げ、
「本物のドラフト」にしてから一致度シグナルを測り直す。

**重要な理論的制約**:
  この課題では編集位置が内容と独立に一様抽選される（`rng.choice` が src と無関係）。
  したがって任意の因果的信号は (j, r) を超えられず、
  **一致度シグナルの AUC は 0.6209（(j,r) のベイズ最適 AUC）を超えないはず**。
  これを実測で確認する（超えたら実装バグかリーク）。

構成:
  λ_draft ∈ {0.1, 1.0, 3.0} × draft_hidden ∈ {0(linear), 128(MLP)}
  のうち代表 4 条件 × 3 seed。ルータには E4d と同じ 3 次元の一致度特徴を渡す。
"""
import os, json, time
import numpy as np
import pandas as pd
from e4d_prefix_stats import run_arm

HERE = os.path.dirname(os.path.abspath(__file__))
CEIL = 0.6209  # (j,r) のベイズ最適 AUC（e4d_ceiling.json）

CONFIGS = [
    (0.1, 0, "E4d と同一（linear, λ=0.1）"),
    (1.0, 0, "linear, λ=1.0"),
    (1.0, 128, "MLP128, λ=1.0"),
    (3.0, 128, "MLP128, λ=3.0"),
]
SEEDS = [0, 1, 2]

rows = []
t0 = time.time()
for lam_d, hid, label in CONFIGS:
    for s in SEEDS:
        r = run_arm("draft_agree", s, lam_draft=lam_d, draft_hidden=hid)
        r.update({"lam_draft": lam_d, "draft_hidden": hid, "label": label})
        rows.append(r)
        print(f"  λd={lam_d:<4} hid={hid:<3} s{s} | draftCE {r['draft_ce']:.3f} "
              f"| acc(c/e) {r['draft_acc_copy']:.3f}/{r['draft_acc_edit']:.3f} "
              f"| p_src(c/e) {r['draft_psrc_copy']:.3f}/{r['draft_psrc_edit']:.3f} "
              f"| AUC p_src {r['draft_auc_psrc']:.3f} top1 {r['draft_auc_top1']:.3f} "
              f"| Δ {r['sel_delta']:+.3f} FFN {r['ffn_cost']:.3f} CE {r['ce_all']:.4f}", flush=True)
    print(f"    ({time.time()-t0:.0f}s)", flush=True)

df = pd.DataFrame(rows)
df.to_csv(os.path.join(HERE, "e4e_draft_quality_results.csv"), index=False)

print("\n=== ドラフトの品質（3 seeds 平均±SD） ===")
print(f"{'config':24s} {'draftCE':>16s} {'acc copy':>9s} {'acc edit':>9s} "
      f"{'p_src copy':>11s} {'p_src edit':>11s} {'AUC(p_src)':>16s} {'AUC(top1)':>16s}")
for lam_d, hid, label in CONFIGS:
    d = df[(df.lam_draft == lam_d) & (df.draft_hidden == hid)]
    print(f"{label:24s} {d['draft_ce'].mean():.3f}±{d['draft_ce'].std():.3f}  "
          f"{d['draft_acc_copy'].mean():9.3f} {d['draft_acc_edit'].mean():9.3f} "
          f"{d['draft_psrc_copy'].mean():11.3f} {d['draft_psrc_edit'].mean():11.3f} "
          f"{d['draft_auc_psrc'].mean():.3f}±{d['draft_auc_psrc'].std():.3f} "
          f"{d['draft_auc_top1'].mean():.3f}±{d['draft_auc_top1'].std():.3f}")

print(f"\n 参考: (j,r) のベイズ最適 AUC = {CEIL:.4f}（この課題の情報上限）")
best = df["draft_auc_psrc"].max()
print(f" 実測の最大 AUC(p_src) = {best:.4f}  -> 上限との差 {CEIL - best:+.4f}")

print("\n=== ルータは使ったか（3 seeds 平均±SD） ===")
print(f"{'config':24s} {'Δ':>16s} {'FFN cost':>16s} {'CE all':>16s}")
for lam_d, hid, label in CONFIGS:
    d = df[(df.lam_draft == lam_d) & (df.draft_hidden == hid)]
    print(f"{label:24s} {d['sel_delta'].mean():+.3f}±{d['sel_delta'].std():.3f}  "
          f"{d['ffn_cost'].mean():.3f}±{d['ffn_cost'].std():.3f}  "
          f"{d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}")

json.dump({"ceiling_jr_auc": CEIL, "configs": [
    {"label": lb, "lam_draft": lm, "draft_hidden": hd,
     "draft_ce": float(df[(df.lam_draft == lm) & (df.draft_hidden == hd)]["draft_ce"].mean()),
     "auc_psrc": float(df[(df.lam_draft == lm) & (df.draft_hidden == hd)]["draft_auc_psrc"].mean()),
     "auc_top1": float(df[(df.lam_draft == lm) & (df.draft_hidden == hd)]["draft_auc_top1"].mean()),
     "sel_delta": float(df[(df.lam_draft == lm) & (df.draft_hidden == hd)]["sel_delta"].mean()),
     "ffn_cost": float(df[(df.lam_draft == lm) & (df.draft_hidden == hd)]["ffn_cost"].mean()),
     "ce_all": float(df[(df.lam_draft == lm) & (df.draft_hidden == hd)]["ce_all"].mean())}
    for lm, hd, lb in CONFIGS], "raw": rows},
    open(os.path.join(HERE, "e4e_draft_quality.json"), "w", encoding="utf-8"),
    indent=2, ensure_ascii=False)
print("\nsaved e4e_draft_quality_results.csv / .json")
