#!/usr/bin/env python3
"""Q8: 静的型ディスパッチ HMoE（Static Type-Dispatched HMoE）の検証。

背景:
Q1〜Q7 により、学習ルータは「頻度ペナルティ（p_pen）」と「自由度の非対称性」に阻まれ、
計算トークン（payload）に自発的に大容量を割り当てることができないことが確定した。
また、負荷分散損失を切ると（Q7）、難課題（hard: ×3 連鎖）で expert が死滅して
完走率が 0.447 → 0.141 に崩壊した。
これに対し、直前の考察で「トークン種別（struct vs payload）ごとに専用の expert プールを
静的に直交割り当て（ディスパッチ）する」アーキテクチャを提案した。

本実験の問い:
1. トークン型に応じて expert プールを静的に固定ディスパッチ（struct → 幅 32×2, payload → 幅 224×2）
   した場合、負荷分散損失ゼロ（auxw=0）でもルータ崩壊（死滅）を回避できるか？
2. 動的ルータ（auxw 0.05 / 0.0）で破綻した難課題（hard: ×3 連鎖）を、静的ディスパッチは克服できるか？
3. payload 幅が 224（最大容量）に 100% 保証されることで、系列完走率（instr_valid）は動的ルータを
   大幅に凌駕するか？

設計:
- タスク:
    hard    : ×3 連鎖（難課題、Q2/Q7）
    compute : A/S/D 混在（標準タスク、Q1/Q5/Q7）
- モデル構成（H+LB: 幅 32/32/96/96/160/160/224/224, L=4, d=128, k=2）:
    1. dynamic_lb   : 動的学習ルータ + auxw 0.05（標準対照）
    2. dynamic_no_lb: 動的学習ルータ + auxw 0.0（完全自由・崩壊リスク対照）
    3. static_type  : 静的型ディスパッチ（auxw 0.0）
                      位置 t のトークン種別（t+1 の予測対象）に応じて:
                        struct  → expert (0, 1) [幅 32×2 = 64] に確定固定
                        payload → expert (6, 7) [幅 224×2 = 448] に確定固定
                      （ルータ損失 auxw=0、ゲートは各プール内で 0.5 ずつ均等分配）
- シード: 0..5（各 6 本）
- 計: 2 タスク × 3 条件 × 6 seed = 36 ラン

事前登録:
  P1（崩壊回避）: static_type は auxw=0 でも死滅 expert がゼロ（全 assigned expert が活用される）。
  P2（容量保証）: static_type は payload 幅が 224.0、struct 幅が 32.0 に 100% 固定される。
  P3（性能飛躍）: 難課題（hard）において、static_type の系列完走率（instr_valid）は
     dynamic_no_lb（Q7 実測 0.141）および dynamic_lb（Q7 実測 0.447）を有意に上回る。
  Kill 条件: static_type の hard タスクの instr_valid が dynamic_lb を下回った場合、
     「静的ディスパッチによる容量保証は表現獲得に寄与しない」と判定。

出力: simulation_hmoe_mmlu/data/q8/H+LB_{task}_{mode}_s{seed}.json / q8_results.json
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import q2_difficulty_ladder as Q2  # noqa: E402
from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS  # noqa: E402
import e2b_rewrite_routing_fixed as E2  # noqa: E402

OUTDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q8")


def usage_entropy(u):
    p = np.asarray(u, float)
    p = p / max(1.0, p.sum())
    p = p[p > 0]
    if len(p) <= 1:
        return 0.0
    return float(-(p * np.log(p)).sum() / np.log(len(u)))


def forward_dispatch(model, idx, typ=None, mode="dynamic_lb"):
    """Q8 専用 forward 関数。

    Args:
        model: RewriteMoE
        idx: (B, T)
        typ: (B, T) トークン種別。static_type で必須
        mode: "dynamic_lb" / "dynamic_no_lb" / "static_type"

    Returns:
        out: (B, T, V)
        aux: scalar
        idx_l: 各層の (B, T, k)
    """
    p = model.p
    B, T = idx.shape
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    aux_sum = torch.zeros(())
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    idx_l = []

    # static_type 用のマスク準備
    if mode == "static_type":
        assert typ is not None, "static_type mode requires typ tensor"
        # 位置 t は t+1 の予測を担当するため、t のルータは typ[:, t+1] の種別を見る
        # t=T-1 は系列末尾なので直前の型を便宜上用いる
        target_typ = torch.zeros_like(typ)
        target_typ[:, :-1] = typ[:, 1:]
        target_typ[:, -1] = typ[:, -1]
        target_typ_flat = target_typ.reshape(-1) # (B*T,)

        # struct: e0, e1 (幅 32)
        # payload: e6, e7 (幅 224)
        # それ以外（初期値など input 領域）: e0, e1 にデフォルト割り当て
        is_payload = (target_typ_flat == Q2.TYP_PAYLOAD)

    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        y = torch.zeros_like(h)

        if mode == "static_type":
            # 静的ディスパッチ: ルータ計算をバイパスして確定分岐
            # struct (is_payload == False) -> e0, e1
            # payload (is_payload == True) -> e6, e7
            topi = torch.zeros((B * T, 2), dtype=torch.int64, device=idx.device)
            topi[~is_payload, 0] = 0
            topi[~is_payload, 1] = 1
            topi[is_payload, 0] = 6
            topi[is_payload, 1] = 7

            gate = torch.zeros((B * T, model.E), dtype=h.dtype, device=idx.device)
            gate[~is_payload, 0] = 0.5
            gate[~is_payload, 1] = 0.5
            gate[is_payload, 6] = 0.5
            gate[is_payload, 7] = 0.5

            for i in (0, 1, 6, 7):
                tok, _ = (topi == i).nonzero(as_tuple=True)
                if tok.numel() == 0:
                    continue
                x_tok = h[tok]
                h1 = F.relu(F.linear(x_tok, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
                y.index_add_(0, tok,
                             F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                             * gate[tok, i].unsqueeze(1))
            aux = torch.zeros(())
        else:
            # dynamic モード
            logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
            topv, topi = logits.topk(model.k, dim=1)
            gate = torch.softmax(
                torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)

            for i in range(model.E):
                tok, _ = (topi == i).nonzero(as_tuple=True)
                if tok.numel() == 0:
                    continue
                x_tok = h[tok]
                h1 = F.relu(F.linear(x_tok, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
                y.index_add_(0, tok,
                             F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                             * gate[tok, i].unsqueeze(1))

            if mode == "dynamic_lb":
                top1 = topi[:, 0]
                f = torch.zeros(model.E, dtype=logits.dtype)
                f.scatter_add_(0, top1, torch.ones_like(top1, dtype=logits.dtype))
                f = f / h.shape[0]
                P = torch.softmax(logits, dim=1).mean(0)
                dims = torch.tensor(model.dims, dtype=logits.dtype)
                aux = model.E * (f * P * (dims / dims.mean())).sum()
            else:
                aux = torch.zeros(())

        h = h + y
        aux_sum = aux_sum + aux
        idx_l.append(topi.reshape(B, T, 2))

    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, -1)
    return out, aux_sum / model.L, idx_l


@torch.no_grad()
def evaluate_q8(model, seq, typ, mode="dynamic_lb", bs=128):
    n = seq.shape[0]
    dims = np.array(model.dims, dtype=np.float32)
    ce = np.zeros((n, Q2.T_LEN - Q2.TRACE0), dtype=np.float32)
    hit = np.zeros((n, Q2.T_LEN - Q2.TRACE0), dtype=bool)
    wid = np.zeros((n, Q2.T_LEN - Q2.TRACE0), dtype=np.float32)
    top1_l = np.zeros((model.L, n, Q2.T_LEN - Q2.TRACE0), dtype=np.int64)

    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = torch.from_numpy(seq[s])
        t_batch = torch.from_numpy(typ[s])
        logits, _, idx_l = forward_dispatch(model, x, typ=t_batch, mode=mode)
        lg = logits[:, Q2.TRACE0 - 1:-1, :len(Q2.VOCAB)]
        tgt = torch.from_numpy(seq[s, Q2.TRACE0:])
        lp = F.cross_entropy(lg.reshape(-1, len(Q2.VOCAB)), tgt.reshape(-1),
                             reduction="none").reshape(-1, Q2.T_LEN - Q2.TRACE0)
        ce[s] = lp.numpy()
        hit[s] = (lg.argmax(-1).numpy() == tgt.numpy())

        for l, ti in enumerate(idx_l):
            a = ti.numpy()[:, Q2.TRACE0 - 1:-1, :]
            top1_l[l][s] = a[:, :, 0]
            wid[s] += dims[a].mean(-1) / model.L

    ty = typ[:, Q2.TRACE0:]
    m_st, m_pl = (ty == Q2.TYP_STRUCT), (ty == Q2.TYP_PAYLOAD)

    u_l0 = np.bincount(top1_l[0].reshape(-1), minlength=model.E)
    ent = usage_entropy(u_l0)
    maxshare = float(u_l0.max() / max(1.0, u_l0.sum()))
    dead_cnt = int(np.sum((u_l0 / max(1.0, u_l0.sum())) < 0.01))

    hp = hit.reshape(n, Q2.P_STEPS, Q2.TPI)[:, :, 2:]
    instr_ok = hp.all(-1)

    out = {
        "ce_all": float(ce.mean()),
        "ce_struct": float(ce[m_st].mean()),
        "ce_payload": float(ce[m_pl].mean()),
        "acc_struct": float(hit[m_st].mean()),
        "acc_payload": float(hit[m_pl].mean()),
        "width_struct": float(wid[m_st].mean()),
        "width_payload": float(wid[m_pl].mean()),
        "small_struct": float(np.isin(top1_l[-1][m_st], Q2.SMALL).mean()),
        "small_payload": float(np.isin(top1_l[-1][m_pl], Q2.SMALL).mean()),
        "usage_l0": u_l0.tolist(),
        "usage_entropy": ent,
        "usage_share_max": maxshare,
        "dead_experts": dead_cnt,
        "instr_valid": float(instr_ok.all(-1).mean()),
        "instr_acc": float(instr_ok.mean()),
        "payload_token_acc": float(hp.mean()),
    }
    return out


def run(task, mode, seed, n_seqs, epochs, bs, lr):
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    model = RewriteMoE(WIDTHS["H+LB"], seed=seed)
    opt = Adam(model.params(), lr=lr)
    nparam = sum(v.numel() for v in model.params().values())

    steps_per_ep = max(1, n_seqs // bs)
    t0 = time.time()
    hist = []
    auxw = 0.05 if mode == "dynamic_lb" else 0.0

    for ep in range(epochs):
        run_loss = 0.0
        for _ in range(steps_per_ep):
            seq, typ = Q2.make_trace_batch(rng, bs, task=task)
            x = torch.from_numpy(seq)
            t_batch = torch.from_numpy(typ)
            logits, aux, _ = forward_dispatch(model, x, typ=t_batch, mode=mode)
            loss = Q2.trace_loss(logits, seq) + auxw * aux
            loss.backward()
            opt.step(model.params())
            run_loss += float(loss.detach())
        hist.append(run_loss / steps_per_ep)
        print(f"    [H+LB {task} {mode} s{seed}] ep{ep+1}/{epochs} "
              f"loss={hist[-1]:.4f} ({time.time()-t0:.0f}s)", flush=True)

    ev_rng = np.random.default_rng(777)
    seq, typ = Q2.make_trace_batch(ev_rng, 1024, task=task)
    ev_base = evaluate_q8(model, seq, typ, mode=mode)

    out = {"arm": "H+LB", "seed": seed, "task": task, "mode": mode, "auxw": auxw,
           "nparam": nparam, "loss_hist": hist, "n_eval": 1024,
           "sec": round(time.time() - t0, 1), "eval": {"base": ev_base}}
    os.makedirs(OUTDIR, exist_ok=True)
    torch.save({k: v.detach() for k, v in model.params().items()},
               os.path.join(OUTDIR, f"ckpt_H+LB_{task}_{mode}_s{seed}.pt"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tasks", nargs="+", default=["compute", "hard"])
    ap.add_argument("--modes", nargs="+", default=["dynamic_lb", "dynamic_no_lb", "static_type"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4, 5])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--resume", action="store_true")
    args = ap.parse_args()

    os.makedirs(OUTDIR, exist_ok=True)
    torch.set_num_threads(6)
    print(f"Q8: tasks={args.tasks} modes={args.modes} seeds={args.seeds}", flush=True)

    rows = []
    for task in args.tasks:
        for mode in args.modes:
            for seed in args.seeds:
                p = os.path.join(OUTDIR, f"H+LB_{task}_{mode}_s{seed}.json")
                if args.resume and os.path.exists(p):
                    try:
                        with open(p, encoding="utf-8") as f:
                            r = json.load(f)
                        if r.get("n_eval") == 1024:
                            print(f"  [skip] {task} {mode} s{seed}", flush=True)
                            rows.append(r)
                            continue
                    except (json.JSONDecodeError, OSError):
                        pass
                r = run(task, mode, seed, args.seqs, args.epochs, args.bs, args.lr)
                rows.append(r)
                e = r["eval"]["base"]
                d = e["small_payload"] - e["small_struct"]
                print(f"  -> {task} {mode} s{seed}: "
                      f"acc pl={e['acc_payload']:.4f} iv={e['instr_valid']:.3f} "
                      f"Δ={d:+.3f} w_st/pl={e['width_struct']:.1f}/{e['width_payload']:.1f} "
                      f"H={e['usage_entropy']:.3f} dead={e['dead_experts']}/8", flush=True)
                with open(p, "w", encoding="utf-8") as f:
                    json.dump(r, f, ensure_ascii=False, indent=2)

    with open(os.path.join(OUTDIR, "q8_results.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
    print(f"[write] {OUTDIR}", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
