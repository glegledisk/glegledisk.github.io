# -*- coding: utf-8 -*-
"""_probe_qwen.py — Phase 0 の計器検証（使い捨て）

確認すること:
  1. Qwen3-0.6B が thinking モードで動くか、出力形式はどうか
  2. greedy が 2 回でビット一致するか（決定性）
  3. 難度（桁数）で pass が分かれるか（床・天井に張り付かないか）
  4. 生成トークン数と所要時間（スループット見積り）
"""
import os
import re
import time

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "qwen3-0.6b")

from transformers import AutoModelForCausalLM, AutoTokenizer

tok = AutoTokenizer.from_pretrained(MODEL)
model = AutoModelForCausalLM.from_pretrained(MODEL, torch_dtype=torch.bfloat16,
                                             device_map="cuda").eval()
print("loaded. n_params=%.0fM" % (sum(p.numel() for p in model.parameters()) / 1e6))

SYS = "You are a careful arithmetic assistant. Solve the problem and give the final answer."


def build(a, b, think=True):
    msgs = [{"role": "system", "content": SYS},
            {"role": "user", "content": "Compute %d + %d." % (a, b)}]
    return tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True,
                                   enable_thinking=think)


def gen(prompt, max_new=1024, temp=0.0):
    ids = tok(prompt, return_tensors="pt").to(model.device)
    t0 = time.time()
    with torch.no_grad():
        out = model.generate(**ids, max_new_tokens=max_new, do_sample=(temp > 0),
                             temperature=max(temp, 1e-5), top_p=1.0,
                             pad_token_id=tok.eos_token_id)
    n_new = out.shape[1] - ids["input_ids"].shape[1]
    txt = tok.decode(out[0, ids["input_ids"].shape[1]:], skip_special_tokens=True)
    return txt, n_new, time.time() - t0


# --- 1. 形式と決定性 ---
p = build(37, 48)
t1, n1, dt1 = gen(p)
t2, n2, dt2 = gen(p)
print("\n--- sample (37+48) ---")
print(t1[:600])
print("... [len=%d tokens, %.1f s, %.1f tok/s]" % (n1, dt1, n1 / dt1))
print("deterministic:", t1 == t2)

# --- 2. 難度別の pass ---
print("\n--- difficulty sweep (greedy, 1 sample) ---")
cases = [(37, 48), (437, 289), (4837, 2915), (48371, 29158)]
for a, b in cases:
    txt, nn, dt = gen(build(a, b))
    nums = re.findall(r"-?\d+", txt.replace(",", ""))
    ok = str(a + b) in nums
    print("  %6d + %6d = %-7d  gen=%4d tok  correct=%s  tail=%r"
          % (a, b, a + b, nn, ok, txt.strip()[-70:]))

# --- 3. thinking off ---
print("\n--- thinking off (37+48) ---")
txt, nn, dt = gen(build(37, 48, think=False))
print("len=%d  %r" % (nn, txt.strip()[-160:]))
