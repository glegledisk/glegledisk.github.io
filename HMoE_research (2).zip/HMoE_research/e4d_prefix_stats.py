# -*- coding: utf-8 -*-
"""e4d_prefix_stats.py — E4d: 推論時計算可能な prefix 統計によるルータ可視性の検証

E4c の結論「vanilla 自己回帰では難度信号は原理的に不可視」を検証する。
E4c が見落としていた 2 つの**因果的に計算可能な**信号を明示特徴として与える:

  信号 A: 残り編集数 (edit_count)
    位置 j までに観測された編集数 r から、P(edit at j | r, j) を推定できる。
    k∈{1,2,3} 一様・位置一様抽出なら r は十分統計量。
    例: j=8, r=0 で P=0.19（周辺 0.125 の 1.5 倍）。情報はゼロではない。

  信号 B: ドラフトと SRC の一致度 (draft_agree)
    1 層目隠れ状態からの軽量ドラフト予測が SRC[j] と一致するか。
    E4c は「エントロピー」だけを使ったが、一致度の方が直接的なコピー/編集の手がかり。
    ※ 本実装ではドラフトヘッドに補助 CE を与え「本物のドラフト」にする（E4c より強い設定）。

アーム: baseline / edit_count / draft_agree / hybrid / oracle(PLAN)
指標: 線形・非線形(MLP)プローブ AUC、選択性 Δ、held-out CE、FFN コスト、正解率
参照: (j, r) のみから計算した**ベイズ最適 AUC**（この信号で理論上どこまで行けるか）

すべて CPU。E4c と同じハイパーパラメータで比較可能。
"""
import os, math, json, time
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import pandas as pd

os.environ["CUDA_VISIBLE_DEVICES"] = ""
HERE = os.path.dirname(os.path.abspath(__file__))

BASE_VOCAB = "()[]{}0123456789+-*/ abcdefgh"
PLAN_TOKENS = ["<COPY>", "<EDIT>"]
ALL_VOCAB = list(BASE_VOCAB) + PLAN_TOKENS
V = len(ALL_VOCAB)
C2I = {c: i for i, c in enumerate(ALL_VOCAB)}
SEP = C2I[" "]
TOK_PLAN_COPY, TOK_PLAN_EDIT = C2I["<COPY>"], C2I["<EDIT>"]

L_SRC = 16
L_OUT = 16
D_MODEL = 64
N_HEAD = 4
N_LAYERS = 2
E_NUM = 8
TOPK = 2
W_FF = 64
ID_IDX = 7
POS_OUT = L_SRC + 1          # OUT の先頭 index
OUT_START = POS_OUT - 1      # logits の開始位置（=L_SRC）


# ---------------- データ ----------------
def make_batch(rng, n, mode="no_plan", max_k=3):
    base_v = len(BASE_VOCAB) - 2
    src = rng.integers(0, base_v, size=(n, L_SRC))
    out = src.copy()
    edit_mask = np.zeros((n, L_OUT), dtype=bool)
    for i in range(n):
        k = int(rng.integers(1, max_k + 1))
        for p in rng.choice(L_OUT, size=k, replace=False):
            alt = int(rng.integers(0, base_v - 1))
            if alt >= out[i, p]:
                alt += 1
            out[i, p] = alt
            edit_mask[i, p] = True
    if mode == "oracle_plan":
        plan = np.full((n, L_SRC), TOK_PLAN_COPY, dtype=np.int64)
        for i in range(n):
            plan[i, edit_mask[i]] = TOK_PLAN_EDIT
        seq = np.empty((n, 2 * L_SRC + L_OUT + 2), dtype=np.int64)
        seq[:, 0:L_SRC] = src
        seq[:, L_SRC] = SEP
        seq[:, L_SRC + 1:2 * L_SRC + 1] = plan
        seq[:, 2 * L_SRC + 1] = SEP
        seq[:, 2 * L_SRC + 2:] = out
        pos_out = 2 * L_SRC + 2
    else:
        seq = np.empty((n, L_SRC + 1 + L_OUT), dtype=np.int64)
        seq[:, 0:L_SRC] = src
        seq[:, L_SRC] = SEP
        seq[:, L_SRC + 1:] = out
        pos_out = L_SRC + 1
    return torch.from_numpy(seq), edit_mask, pos_out


# ---------------- ベイズ最適 AUC の参照 ----------------
def bayes_posterior_table():
    """(j, r) から計算した P(edit at j | r edits in [0,j)) の厳密値"""
    from math import comb
    tab = {}
    for j in range(L_OUT):
        for r in range(0, j + 1):
            num = den = 0.0
            for k in (1, 2, 3):
                if r > k or k - r > L_OUT - j:
                    continue
                lik = comb(j, r) * comb(L_OUT - j, k - r) / comb(L_OUT, k)
                den += lik
                num += lik * (k - r) / (L_OUT - j)
            tab[(j, r)] = num / den if den > 0 else 0.0
    return tab


def bayes_auc(edit_mask, tab):
    scores, labels = [], []
    n = edit_mask.shape[0]
    for i in range(n):
        r = 0
        for j in range(L_OUT):
            scores.append(tab[(j, min(r, j))])
            labels.append(edit_mask[i, j])
            r += int(edit_mask[i, j])
    s = np.asarray(scores); y = np.asarray(labels)
    order = np.argsort(s, kind="mergesort")
    ranks = np.empty(len(s)); ranks[order] = np.arange(1, len(s) + 1)
    # 同順位は平均ランク
    uniq, inv, cnt = np.unique(s, return_inverse=True, return_counts=True)
    sums = np.bincount(inv, weights=ranks)
    ranks = (sums / cnt)[inv]
    n1 = y.sum(); n0 = len(y) - n1
    return float((ranks[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


# ---------------- モデル ----------------
class MoELayer(nn.Module):
    def __init__(self, extra_dim=0, route_mode="free"):
        super().__init__()
        self.n_head, self.d_head = N_HEAD, D_MODEL // N_HEAD
        self.route_mode = route_mode
        self.q = nn.Linear(D_MODEL, D_MODEL, bias=False)
        self.k = nn.Linear(D_MODEL, D_MODEL, bias=False)
        self.v = nn.Linear(D_MODEL, D_MODEL, bias=False)
        self.o = nn.Linear(D_MODEL, D_MODEL, bias=False)
        self.router = nn.Linear(D_MODEL + extra_dim, E_NUM, bias=False)
        self.up = nn.Parameter(torch.randn(E_NUM, D_MODEL, W_FF) * 0.05)
        self.down = nn.Parameter(torch.randn(E_NUM, W_FF, D_MODEL) * 0.05)

    def forward(self, x, mask, extra=None):
        B, T, _ = x.shape
        q = self.q(x).view(B, T, self.n_head, self.d_head).transpose(1, 2)
        k = self.k(x).view(B, T, self.n_head, self.d_head).transpose(1, 2)
        v = self.v(x).view(B, T, self.n_head, self.d_head).transpose(1, 2)
        s = (q @ k.transpose(-2, -1)) / math.sqrt(self.d_head)
        s = s.masked_fill(mask == 0, -1e9)
        a = F.softmax(s, dim=-1)
        x = x + self.o((a @ v).transpose(1, 2).reshape(B, T, D_MODEL))
        r_in = x if extra is None else torch.cat([x, extra], dim=-1)
        if self.route_mode == "identity":
            # ルーティングを完全固定: 全スロットを恒等パスに（ゲート 0.5+0.5 で合計 1）
            ti = torch.full((B, T, TOPK), ID_IDX, dtype=torch.long)
            tg = torch.full((B, T, TOPK), 1.0 / TOPK)
        else:
            lg = self.router(r_in)
            if self.route_mode == "ffn_only":
                # ルーティングを FFN に固定（恒等パスを選択不可にする）
                lg = lg.clone()
                lg[..., ID_IDX] = -1e9
            tl, ti = torch.topk(lg, TOPK, dim=-1)
            tg = F.softmax(tl, dim=-1)
        out = torch.zeros_like(x)
        for ki in range(TOPK):
            ei, g = ti[:, :, ki], tg[:, :, ki].unsqueeze(-1)
            out = out + torch.where((ei == ID_IDX).unsqueeze(-1), g * x, torch.zeros_like(x))
            for e in range(E_NUM):
                if e == ID_IDX:
                    continue
                m = (ei == e).unsqueeze(-1)
                if m.any():
                    f = F.relu(x @ self.up[e]) @ self.down[e]
                    out = out + torch.where(m, g * f, torch.zeros_like(x))
        return x + out, x, r_in, ti, tg


class Net(nn.Module):
    def __init__(self, arm, route_mode="free", draft_hidden=0):
        super().__init__()
        self.arm = arm
        self.edit_dim = 4 if arm in ("edit_count", "hybrid") else 0
        self.draft_dim = 3 if arm in ("draft_agree", "hybrid") else 0
        extra = self.edit_dim + self.draft_dim
        self.tok = nn.Embedding(V, D_MODEL)
        self.pos = nn.Embedding(64, D_MODEL)
        self.l0 = MoELayer(0, route_mode)
        self.l1 = MoELayer(extra, route_mode)
        self.head = nn.Linear(D_MODEL, V)
        if self.draft_dim:
            if draft_hidden and draft_hidden > 0:
                self.draft = nn.Sequential(nn.Linear(D_MODEL, draft_hidden), nn.ReLU(),
                                           nn.Linear(draft_hidden, V, bias=False))
            else:
                self.draft = nn.Linear(D_MODEL, V, bias=False)

    def forward(self, ids, pos_out):
        B, T = ids.shape
        out_start = pos_out - 1
        x = self.tok(ids) + self.pos(torch.arange(T).unsqueeze(0))
        mask = torch.tril(torch.ones(T, T)).unsqueeze(0).unsqueeze(0)
        x, h0, _, ti0, tg0 = self.l0(x, mask)

        feats, draft_logits = [], None
        if self.edit_dim:
            # 出力位置 j における「観測済み編集数」(OUT[0..j-1]) を x_ids から因果的に計算。
            # 入力は 1 トークン短いので OUT[L_OUT-1] は未観測 → 累積和の末尾で補う。
            out_avail = ids[:, pos_out:]                    # OUT[0..L_OUT-2]
            n_av = out_avail.shape[1]
            src_tok = ids[:, :n_av]
            neq = (out_avail != src_tok).float()
            incl = torch.cumsum(neq, dim=1)
            seen = torch.cat([incl - neq, incl[:, -1:]], dim=1)   # (B, L_OUT) exclusive
            jj = torch.arange(L_OUT).float().unsqueeze(0).expand(B, L_OUT)
            fe = torch.stack([jj / L_OUT, seen / L_OUT,
                              seen / (L_OUT - jj).clamp(min=1.0),
                              torch.ones(B, L_OUT)], dim=-1)      # (B,L_OUT,4)
            feats.append(torch.cat([torch.zeros(B, out_start, 4), fe], dim=1))

        if self.draft_dim:
            draft_logits = self.draft(h0)           # 位置 t は token t+1 を予測
            pr = F.softmax(draft_logits, dim=-1)
            src_tok = ids[:, :L_OUT]
            tgt_pos = torch.arange(out_start, out_start + L_OUT)
            p = pr[:, tgt_pos, :]                                   # (B,L_OUT,V)
            p_src = p.gather(-1, src_tok.unsqueeze(-1)).squeeze(-1)
            p_max = p.max(dim=-1).values
            is_top1 = (p.argmax(dim=-1) == src_tok).float()
            fd = torch.stack([p_src, p_max, is_top1], dim=-1)       # (B, L_OUT, 3)
            feats.append(torch.cat([torch.zeros(B, out_start, 3), fd], dim=1))

        extra = torch.cat(feats, dim=-1) if feats else None
        x, h1, r1, ti1, tg1 = self.l1(x, mask, extra)
        return self.head(x), (h0, h1), (r1,), (ti0, ti1), (tg0, tg1), draft_logits


# ---------------- プローブ ----------------
def auc_score(s, y):
    order = np.argsort(s, kind="mergesort")
    r = np.empty(len(s)); r[order] = np.arange(1, len(s) + 1)
    u, inv, c = np.unique(s, return_inverse=True, return_counts=True)
    r = (np.bincount(inv, weights=r) / c)[inv]
    n1 = y.sum(); n0 = len(y) - n1
    if n1 == 0 or n0 == 0:
        return 0.5
    return float((r[y == 1].sum() - n1 * (n1 + 1) / 2) / (n1 * n0))


def linear_probe(Xtr, ytr, Xte, yte, steps=150):
    mu, sd = Xtr.mean(0), Xtr.std(0) + 1e-6
    Xtr = torch.from_numpy((Xtr - mu) / sd).float()
    Xte = torch.from_numpy((Xte - mu) / sd).float()
    yt = torch.from_numpy(ytr).float()
    w = torch.zeros(Xtr.shape[1], requires_grad=True)
    b = torch.zeros(1, requires_grad=True)
    opt = torch.optim.Adam([w, b], lr=0.08)
    for _ in range(steps):
        loss = F.binary_cross_entropy_with_logits(Xtr @ w + b, yt)
        opt.zero_grad(); loss.backward(); opt.step()
    with torch.no_grad():
        return auc_score((Xte @ w + b).numpy(), yte)


def mlp_probe(Xtr, ytr, Xte, yte, hidden=64, steps=300):
    mu, sd = Xtr.mean(0), Xtr.std(0) + 1e-6
    Xtr = torch.from_numpy((Xtr - mu) / sd).float()
    Xte = torch.from_numpy((Xte - mu) / sd).float()
    yt = torch.from_numpy(ytr).float().unsqueeze(-1)
    torch.manual_seed(0)
    net = nn.Sequential(nn.Linear(Xtr.shape[1], hidden), nn.ReLU(), nn.Linear(hidden, 1))
    opt = torch.optim.Adam(net.parameters(), lr=0.01, weight_decay=1e-4)
    for _ in range(steps):
        loss = F.binary_cross_entropy_with_logits(net(Xtr), yt)
        opt.zero_grad(); loss.backward(); opt.step()
    with torch.no_grad():
        return auc_score(net(Xte).squeeze(-1).numpy(), yte)


# ---------------- 学習・評価 ----------------
def run_arm(arm, seed, n_train=3500, n_val=2048, epochs=12, bs=64, lam_cost=0.15, lam_draft=0.1,
            route_mode="free", draft_hidden=0):
    rng = np.random.default_rng(seed); torch.manual_seed(seed)
    mode = "oracle_plan" if arm == "oracle" else "no_plan"
    net = Net(arm, route_mode=route_mode, draft_hidden=draft_hidden)
    opt = torch.optim.AdamW(net.parameters(), lr=3e-3, weight_decay=1e-4)
    pos_out = 2 * L_SRC + 2 if mode == "oracle_plan" else L_SRC + 1
    os_ = pos_out - 1
    for ep in range(epochs):
        net.train()
        # E4c と同一条件: エポックごとに学習データを再生成（3500 系列/epoch）
        seq, _, _ = make_batch(rng, n_train, mode)
        perm = torch.randperm(n_train)
        for i in range(0, n_train, bs):
            b = seq[perm[i:i + bs]]
            inp, tgt = b[:, :-1], b[:, 1:]
            opt.zero_grad()
            logits, _, _, (ti0, ti1), (tg0, tg1), dlg = net(inp, pos_out)
            ce = F.cross_entropy(logits[:, os_:].reshape(-1, V), tgt[:, os_:].reshape(-1))
            g0 = (tg0[:, os_:] * (ti0[:, os_:] == ID_IDX).float()).sum(-1).mean()
            g1 = (tg1[:, os_:] * (ti1[:, os_:] == ID_IDX).float()).sum(-1).mean()
            loss = ce + lam_cost * (2.0 - (g0 + g1))
            if dlg is not None and lam_draft > 0:
                loss = loss + lam_draft * F.cross_entropy(
                    dlg[:, os_:].reshape(-1, V), tgt[:, os_:].reshape(-1))
            loss.backward(); opt.step()

    net.eval()
    vs, vm, pos_out = make_batch(rng, n_val, mode)
    with torch.no_grad():
        logits, (h0, h1), (r1,), (ti0, ti1), (tg0, tg1), dlg = net(vs[:, :-1], pos_out)
        tgt = vs[:, 1:]
        lo = logits[:, os_:]
        lt = tgt[:, os_:]
        ce_tok = F.cross_entropy(lo.reshape(-1, V), lt.reshape(-1), reduction="none").reshape(n_val, L_OUT)
        preds = lo.argmax(-1)
        ti1o, tg1o = ti1[:, os_:], tg1[:, os_:]
        is_id = (ti1o[:, :, 0] == ID_IDX).numpy()
        gate_id = (tg1o * (ti1o == ID_IDX).float()).sum(-1).mean().item()
        H1 = h1[:, os_:].reshape(-1, D_MODEL).numpy()
        R1 = r1[:, os_:].reshape(-1, r1.shape[-1]).numpy()

        # --- ドラフトの品質と「一致度シグナル」単体の AUC ---
        d_ce = d_acc_c = d_acc_e = d_psrc_c = d_psrc_e = float("nan")
        d_auc_psrc = d_auc_top1 = float("nan")
        if dlg is not None:
            src_tok = vs[:, :L_OUT]
            pr = F.softmax(dlg[:, os_:], dim=-1)                  # (B,L_OUT,V) 位置 t は token t+1
            d_ce = float(F.cross_entropy(dlg[:, os_:].reshape(-1, V), lt.reshape(-1)))
            p_src = pr.gather(-1, src_tok.unsqueeze(-1)).squeeze(-1).numpy()
            top1 = pr.argmax(-1).numpy()
            agree = (top1 == src_tok.numpy()).astype(float)
            d_acc_c = float(agree[~vm].mean()); d_acc_e = float(agree[vm].mean())
            d_psrc_c = float(p_src[~vm].mean()); d_psrc_e = float(p_src[vm].mean())
            y = vm.reshape(-1).astype(int)
            d_auc_psrc = auc_score(-p_src.reshape(-1), y)   # p_src が低いほど edit → 符号反転
            d_auc_top1 = auc_score(1.0 - agree.reshape(-1), y)
    m = vm.reshape(-1)
    split = int(0.7 * len(m))
    ytr, yte = m[:split].astype(int), m[split:].astype(int)

    return {
        "arm": arm, "seed": seed,
        "auc_h_lin": linear_probe(H1[:split], ytr, H1[split:], yte),
        "auc_h_mlp": mlp_probe(H1[:split], ytr, H1[split:], yte),
        "auc_rin_lin": linear_probe(R1[:split], ytr, R1[split:], yte),
        "id_copy": float(is_id[~vm].mean()), "id_edit": float(is_id[vm].mean()),
        "sel_delta": float(is_id[~vm].mean() - is_id[vm].mean()),
        "ffn_cost": float(1.0 - gate_id),
        "ce_all": float(ce_tok.mean()), "ce_copy": float(ce_tok[~vm].mean()),
        "ce_edit": float(ce_tok[vm].mean()),
        "acc_all": float((preds == lt).float().mean()),
        "acc_copy": float((preds[~vm] == lt[~vm]).float().mean()),
        "acc_edit": float((preds[vm] == lt[vm]).float().mean()),
        "draft_ce": d_ce, "draft_acc_copy": d_acc_c, "draft_acc_edit": d_acc_e,
        "draft_psrc_copy": d_psrc_c, "draft_psrc_edit": d_psrc_e,
        "draft_auc_psrc": d_auc_psrc, "draft_auc_top1": d_auc_top1,
    }


def main():
    arms = ["baseline", "edit_count", "draft_agree", "hybrid", "oracle"]
    seeds = [0, 1, 2]
    tab = bayes_posterior_table()
    rng = np.random.default_rng(999)
    _, bmask, _ = make_batch(rng, 4096, "no_plan")
    b_auc = bayes_auc(bmask, tab)
    print(f"[参照] (j,r) のみから計算したベイズ最適 AUC = {b_auc:.4f}")
    print(f"       （位置の周辺確率だけ使う場合の理論上限。これを超えたら r 以外の情報が効いている）\n")

    rows = []
    t0 = time.time()
    for arm in arms:
        for s in seeds:
            r = run_arm(arm, s)
            rows.append(r)
            print(f"  {arm:12s} s{s} | AUC(h,lin) {r['auc_h_lin']:.3f} (MLP {r['auc_h_mlp']:.3f}) "
                  f"| AUC(rin) {r['auc_rin_lin']:.3f} | Δ {r['sel_delta']:+.3f} "
                  f"| CE {r['ce_all']:.4f} | FFN {r['ffn_cost']:.3f} | acc {r['acc_all']:.4f}", flush=True)
        print(f"    ({time.time()-t0:.0f}s elapsed)", flush=True)

    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(HERE, "e4d_prefix_stats_results.csv"), index=False)
    agg = df.groupby("arm").agg(["mean", "std"]).reset_index()
    print("\n=== 集約 (3 seeds) ===")
    cols = ["auc_h_lin", "auc_h_mlp", "auc_rin_lin", "sel_delta", "ffn_cost", "ce_all", "acc_all"]
    for arm in arms:
        row = df[df.arm == arm]
        print(f" {arm:12s} " + "  ".join(
            f"{c}={row[c].mean():.3f}±{row[c].std():.3f}" for c in cols))

    out = {"bayes_auc_jr": b_auc,
           "summary": [{**{k: float(df[df.arm == a][k].mean()) for k in cols},
                        **{k + "_std": float(df[df.arm == a][k].std()) for k in cols},
                        "arm": a} for a in arms]}
    json.dump(out, open(os.path.join(HERE, "e4d_prefix_stats_summary.json"), "w", encoding="utf-8"),
              indent=2, ensure_ascii=False)
    print("\nsaved e4d_prefix_stats_results.csv / e4d_prefix_stats_summary.json")


if __name__ == "__main__":
    main()
