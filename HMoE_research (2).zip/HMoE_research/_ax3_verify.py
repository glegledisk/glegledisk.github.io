# -*- coding: utf-8 -*-
"""AX3 Step 4: 独立再計算（ax3_transfer.py を import しない別経路）。

scipy.stats.ttest_rel 経路で Δ・se・t・p・Holm・TOST・MDE・上位 1% 寄与率を
作り直し、npz の生配列から決定・mean_k・校正・probe 品質・探索的量を再構築して
ax3_transfer.json と突合する。使い方: python _ax3_verify.py [tag]
"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats as scistats

HERE = os.path.dirname(os.path.abspath(__file__))
TAG = sys.argv[1] if len(sys.argv) > 1 else "ax3"
ALPHA = 0.05
DELTA = 0.01
PERM_SEED = 777
RAND_WIN_SEED = 901
RAND_TOK_SEED = 7
N_LAYERS = 16

ITEMS, MISMATCH = [], []


def chk(name, got, exp, rtol=1e-6, atol=1e-9):
    ITEMS.append(name)
    ok = False
    if isinstance(exp, (list, tuple)):
        ok = (list(got) == list(exp))
    elif isinstance(exp, bool) or isinstance(exp, str):
        ok = (got == exp)
    elif isinstance(exp, (int, np.integer)) and isinstance(got, (int, np.integer)):
        ok = (int(got) == int(exp))
    else:
        try:
            ok = math.isclose(float(got), float(exp), rel_tol=rtol, abs_tol=atol)
        except Exception:
            ok = False
    if not ok:
        MISMATCH.append((name, got, exp))


def rst(d, tok_per_win=255):
    """paired stats（ttest_rel 別経路）。"""
    d = np.asarray(d, dtype=np.float64).ravel()
    n = d.size
    m = float(d.mean())
    t, p = scistats.ttest_rel(d, np.zeros_like(d))
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    tc975 = float(scistats.t.ppf(0.975, n - 1))
    tc95 = float(scistats.t.ppf(0.95, n - 1))
    wm = d.reshape(-1, tok_per_win).mean(axis=1)
    sew = float(wm.std(ddof=1) / math.sqrt(wm.size))
    srt = np.sort(np.abs(d))[::-1]
    k1 = max(1, int(math.ceil(0.01 * n)))
    return {"mean": m, "sd": sd, "se": se, "t": float(t), "p_two": float(p),
            "mde": tc975 * se, "ci95": [m - tc975 * se, m + tc975 * se],
            "ci90": [m - tc95 * se, m + tc95 * se],
            "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
            "median": float(np.median(d)), "se_win": sew,
            "top1_abs_share": float(srt[:k1].sum() / srt.sum())}


def tost_p(m, se, df, delta):
    p_low = float(scistats.t.sf((m + delta) / se, df))
    p_high = float(scistats.t.cdf((m - delta) / se, df))
    return max(p_low, p_high), p_low, p_high


def holm_adj(pvals):
    ids = sorted(pvals, key=lambda k: pvals[k])
    out, run = {}, 0.0
    for i, k in enumerate(ids):
        run = max(run, (len(ids) - i) * pvals[k])
        out[k] = min(1.0, run)
    return out


def spearman(a, b):
    ra = np.argsort(np.argsort(a)).astype(np.float64)
    rb = np.argsort(np.argsort(b)).astype(np.float64)
    ra -= ra.mean()
    rb -= rb.mean()
    den = np.sqrt((ra ** 2).sum() * (rb ** 2).sum())
    return float((ra * rb).sum() / den) if den > 0 else float("nan")


def grams8(x):
    return set(tuple(int(v) for v in x[i:i + 8]) for i in range(len(x) - 7))


def overlap8(a, b):
    gb = grams8(b)
    return float(np.mean([tuple(int(v) for v in a[i:i + 8]) in gb
                         for i in range(len(a) - 7)]))


def main():
    z = np.load(os.path.join(HERE, "%s_transfer.npz" % TAG))
    with open(os.path.join(HERE, "%s_transfer.json" % TAG), encoding="utf-8") as fp:
        J = json.load(fp)
    n_tok = J["meta"]["n_tok"]
    nw = J["meta"]["windows"]
    n_eval = n_tok // nw
    ln = J["meta"]["len"]
    lang = z["lang"]
    arms = [k[4:] for k in z.files if k.startswith("nll_")]
    N = {a: z["nll_" + a].astype(np.float64) for a in arms}

    # ---- C4 ----
    for a in arms:
        v = z["nll_" + a]
        chk("C4.shape_" + a, bool(v.shape == (n_tok,)), True)
        chk("C4.finite_" + a, bool(np.isfinite(v).all()), True)
        chk("C4.nonneg_" + a, bool((v >= 0).all()), True)
    chk("C4.lang_en", bool(np.all(lang[:nw // 2] == "en")), True)
    chk("C4.lang_ja", bool(np.all(lang[nw // 2:] == "ja")), True)
    chk("C4.n_arms", len(arms), J["meta"]["n_arms"])

    # ---- 結果表 ----
    for a in arms:
        r = J["results"][a]
        chk("arm.ce_" + a, float(N[a].mean()), r["ce"])
        chk("arm.dce_" + a, float((N[a] - N["u7"]).mean()), r["delta_vs_u7"])
        chk("arm.top1_" + a, float(z["acc1_" + a].mean()), r["top1"])
        if r["mean_k"] is not None and a in J["calib"]["C5"]["mean_k"]:
            chk("arm.meank_" + a, float(r["mean_k"]), float(J["calib"]["C5"]["mean_k"][a]))

    # ---- 確認的 ----
    d1 = N["u7"] - N["lay_tok_oracle"]
    d2 = N["u7"] - N["lay_win_mlp"]
    d3 = N["tok_probe50"] - N["lay_win_mlp"]
    for sid, d, key in (("W1", d1, "W1_lay_tok_oracle"), ("W2", d2, "W2_lay_win_mlp"),
                        ("W3", d3, "W3_diff")):
        s = rst(d, n_eval)
        rj = J["confirmatory"][key]
        for f in ("mean", "sd", "se", "t", "p_two", "mde", "median",
                  "se_win", "top1_abs_share"):
            chk("%s.%s" % (sid, f), s[f], rj[f])
        chk("%s.n_pos" % sid, s["n_pos"], rj["n_pos"])
        chk("%s.n_neg" % sid, s["n_neg"], rj["n_neg"])
        for f in ("ci95", "ci90"):
            chk("%s.%s_lo" % (sid, f), s[f][0], rj[f][0])
            chk("%s.%s_hi" % (sid, f), s[f][1], rj[f][1])
    m3 = float(d3.mean())
    se3 = float(d3.std(ddof=1) / math.sqrt(n_tok))
    p_tost, p_low, p_high = tost_p(m3, se3, n_tok - 1, DELTA)
    to3 = J["confirmatory"]["W3_tost"]
    chk("W3.p_tost", p_tost, to3["p_tost"])
    chk("W3.p_low", p_low, to3["p_low"])
    chk("W3.p_high", p_high, to3["p_high"])
    lo90 = m3 - float(scistats.t.ppf(0.95, n_tok - 1)) * se3
    hi90 = m3 + float(scistats.t.ppf(0.95, n_tok - 1)) * se3
    equiv = bool((p_tost < ALPHA) and (lo90 > -DELTA) and (hi90 < DELTA))
    chk("W3.equivalent", equiv, to3["equivalent"])
    ph = holm_adj({"W1": J["confirmatory"]["W1_lay_tok_oracle"]["p_two"],
                   "W2": J["confirmatory"]["W2_lay_win_mlp"]["p_two"],
                   "W3": p_tost})
    for k, v in ph.items():
        chk("holm." + k, v, J["confirmatory"]["holm"][k])
    rej = {k: ph[k] < ALPHA for k in ph}
    g1, g2 = float(d1.mean()), float(d2.mean())
    case = ("A" if (rej["W2"] and g2 > 0 and not equiv) else
            "B" if (rej["W2"] and g2 > 0 and equiv) else
            "C" if (rej["W1"] and not rej["W2"] and equiv) else
            "D" if (not rej["W1"]) else
            "E" if (rej["W2"] and g2 < 0) else "UNLISTED")
    chk("case", case, J["confirmatory"]["case"])

    # ---- 校正 C1/C2/C3 ----
    c1 = J["calib"]["C1"]
    d_c1 = N["base_rep"] - N["base"]
    chk("C1.maxdiff", float(np.abs(d_c1).max()), c1["maxdiff"])
    chk("C1.meandiff", float(d_c1.mean()), c1["meandiff"])
    z2 = np.load(os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"))
    z3 = np.load(os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz"))
    ov = {lg: overlap8(z2[lg + "_ids"], z3[lg + "_ids"]) for lg in ("en", "ja")}
    chk("C2.ov_en", ov["en"], J["calib"]["C2"]["overlap8_en"])
    chk("C2.ov_ja", ov["ja"], J["calib"]["C2"]["overlap8_ja"])
    chk("C2.pass", bool(ov["en"] < 0.05 and ov["ja"] < 0.20), J["calib"]["C2"]["pass"])
    d_c3 = N["mask7"] - N["u7"]
    chk("C3.meandiff", float(d_c3.mean()), J["calib"]["C3"]["meandiff"])
    chk("C3.sd", float(d_c3.std(ddof=1)), J["calib"]["C3"]["sd"])
    chk("C3.maxdiff", float(np.abs(d_c3).max()), J["calib"]["C3"]["maxdiff"])

    # ---- 決定の再構築 ----
    c8, c7, oof = z["c8"], z["c7"], z["oof_tok"]
    Y = z["Y"]
    W_mlp = z["win_mlp"]
    ar = np.arange(n_tok)
    cut_tok_o = np.argmin(c7.astype(np.float32), axis=0)
    m8 = c8.astype(np.float32).copy()
    m8[cut_tok_o, ar] = -np.inf
    prot_tok_o = np.argmax(m8, axis=0)
    chk("dec.cut_tok_o", int((cut_tok_o != z["cut_tok_o"]).sum()), 0)
    chk("dec.prot_tok_o", int((prot_tok_o != z["prot_tok_o"]).sum()), 0)
    pc7 = oof[:, N_LAYERS:2 * N_LAYERS].T.astype(np.float32)
    pc8 = oof[:, :N_LAYERS].T.astype(np.float32)
    cut_tok_r = np.argmin(pc7, axis=0)
    m8r = pc8.copy()
    m8r[cut_tok_r, ar] = -np.inf
    prot_tok_r = np.argmax(m8r, axis=0)
    chk("dec.cut_tok_r", int((cut_tok_r != z["cut_tok_r"]).sum()), 0)
    chk("dec.prot_tok_r", int((prot_tok_r != z["prot_tok_r"]).sum()), 0)

    def win_dec(P, cut_key, prot_key):
        cut = np.argmin(P[:, N_LAYERS:], axis=1)
        Q = P[:, :N_LAYERS].copy()
        Q[np.arange(nw), cut] = -np.inf
        prot = np.argmax(Q, axis=1)
        chk("dec." + cut_key, int((cut != z[cut_key]).sum()), 0)
        chk("dec." + prot_key, int((prot != z[prot_key]).sum()), 0)
        chk("dec.conflict_" + cut_key, int((cut == prot).sum()), 0)
        km = np.full((N_LAYERS, nw * ln), 7, dtype=np.int8)
        for w in range(nw):
            sl = slice(w * ln, (w + 1) * ln)
            km[cut[w], sl] = 6
            km[prot[w], sl] = 8
        return float(km.mean())

    mk_win_o = win_dec(Y, "cut_w_o", "prot_w_o")
    mk_win_r = win_dec(z["win_ridge"], "cut_w_r", "prot_w_r")
    mk_win_m = win_dec(W_mlp, "cut_w_m", "prot_w_m")
    rng_w = np.random.RandomState(RAND_WIN_SEED)
    cut_rand = rng_w.randint(0, N_LAYERS, size=nw)
    draw = rng_w.randint(0, N_LAYERS - 1, size=nw)
    prot_rand = draw + (draw >= cut_rand)
    chk("dec.cut_w_rand", int((cut_rand != z["cut_w_rand"]).sum()), 0)
    chk("dec.prot_w_rand", int((prot_rand != z["prot_w_rand"]).sum()), 0)
    km_rand = np.full((N_LAYERS, nw * ln), 7, dtype=np.int8)
    for w in range(nw):
        sl = slice(w * ln, (w + 1) * ln)
        km_rand[cut_rand[w], sl] = 6
        km_rand[prot_rand[w], sl] = 8
    mk_rand = float(km_rand.mean())

    def tok_kmat(cut, prot):
        km = np.full((N_LAYERS, n_tok), 7, dtype=np.int8)
        km[cut, ar] = 6
        km[prot, ar] = 8
        km = km.reshape(N_LAYERS, nw, n_eval)
        km = np.concatenate([km, np.full((N_LAYERS, nw, 1), 7, dtype=np.int8)], axis=2)
        return float(km.mean())

    def topk_k(mat, f, lo=6, hi=8):
        out = np.full(mat.shape, lo, dtype=np.float32)
        m = int(round(f * mat.size))
        order = np.argsort(-mat.ravel())
        keep = np.zeros(mat.size, bool)
        keep[order[:m]] = True
        out.ravel()[keep] = hi
        kv = np.concatenate([out, np.full((nw, 1), 6, dtype=np.float32)], axis=1)
        return float(np.tile(kv[None, :, :], (N_LAYERS, 1, 1)).mean())

    d_j = z["d_j"]
    rng_t = np.random.RandomState(RAND_TOK_SEED)
    exp_mk = {"base": 8.0, "base_rep": 8.0, "u7": 7.0, "u6": 6.0,
              "mask7": 7.0,
              "lay_tok_oracle": tok_kmat(cut_tok_o, prot_tok_o),
              "lay_tok_ridge": tok_kmat(cut_tok_r, prot_tok_r),
              "lay_win_oracle": mk_win_o, "lay_win_ridge": mk_win_r,
              "lay_win_mlp": mk_win_m, "lay_win_random": mk_rand,
              "tok_oracle50": topk_k(d_j.reshape(nw, n_eval), 0.5),
              "tok_probe50": topk_k(oof[:, 2 * N_LAYERS].reshape(nw, n_eval), 0.5),
              "tok_random50": topk_k(rng_t.rand(nw, n_eval).astype(np.float32), 0.5)}
    for L in range(N_LAYERS):
        exp_mk["ab7_%02d" % L] = (15 * 8 + 7) / 16
        exp_mk["ab6_%02d" % L] = (15 * 8 + 6) / 16
    for a, v in exp_mk.items():
        chk("C5." + a, float(J["calib"]["C5"]["mean_k"][a]), v)
        chk("C5.exp_" + a, float(J["calib"]["C5"]["expected"][a]), v)

    # ---- C7 ----
    C7 = J["calib"]["C7"]
    chk("C7.conf_mlp", int((z["cut_w_m"] == z["prot_w_m"]).sum()), C7["win_conflict_mlp"])
    for i in range(N_LAYERS):
        chk("C7.cut_mlp_%02d" % i, int((z["cut_w_m"] == i).sum()), C7["cut_hist_mlp"][i])
        chk("C7.prot_mlp_%02d" % i, int((z["prot_w_m"] == i).sum()), C7["prot_hist_mlp"][i])

    # ---- probe 品質 ----
    cols = J["meta"]["oof_tok_columns"]
    tdict = {}
    for L in range(N_LAYERS):
        tdict["c8_%02d" % L] = c8[L].astype(np.float64)
        tdict["c7_%02d" % L] = c7[L].astype(np.float64)
    tdict["d_j"] = d_j.astype(np.float64)
    for i, nm in enumerate(cols):
        y, pred = tdict[nm], oof[:, i].astype(np.float64)
        r2 = 1.0 - float(((y - pred) ** 2).sum() / ((y - y.mean()) ** 2).sum())
        chk("probe.rho_" + nm, spearman(y, pred), J["probe_quality"][nm]["spearman"])
        chk("probe.r2_" + nm, r2, J["probe_quality"][nm]["r2"])
    for nm, key in (("ridge", "window_ridge_quality"), ("mlp", "window_mlp_quality")):
        pred = z["win_" + nm] if nm == "ridge" else z["win_mlp"]
        r2 = 1.0 - float(((Y - pred) ** 2).sum() / ((Y - Y.mean(0)) ** 2).sum())
        chk("win.r2_" + nm, r2, J["exploratory"][key]["r2"])
        chk("win.rho_mean_" + nm,
            float(np.mean([abs(spearman(Y[:, j], pred[:, j])) for j in range(32)])),
            float(np.mean(np.abs(J["exploratory"][key]["spearman"]))))

    # ---- C6 permutation ----
    perm = np.random.RandomState(PERM_SEED).permutation(nw)
    Yp = Y[perm]
    for nm, key in (("ridge", "perm_ridge"), ("mlp", "perm_mlp")):
        if key in z.files:
            pred = z[key]
            mx = float(max(abs(spearman(Yp[:, j], pred[:, j])) for j in range(32)))
            chk("C6.max_abs_rho_" + nm, mx, J["calib"]["C6"]["perm"][nm]["max_abs_rho"])
        else:
            ITEMS.append("C6.skipped_" + nm)   # smoke 等の旧 npz には保存予測が無い
    chk("C6.pass", bool(J["calib"]["C6"]["max_abs_rho"] < 0.15), J["calib"]["C6"]["pass"])

    # ---- 探索的 ----
    E = J["exploratory"]
    for nm, s in E["gains"].items():
        chk("exp.gain_" + nm, float((N["u7"] - N[nm]).mean()), s["mean"])
    lang_tok = np.repeat(lang, n_eval)
    for lg in ("en", "ja"):
        sel = lang_tok == lg
        for nm, s in E["by_lang"][lg].items():
            d = (N["u7"] - N[nm])[sel]
            chk("exp.lang_%s_%s_mean" % (lg, nm), float(d.mean()), s["mean"])
            chk("exp.lang_%s_%s_n" % (lg, nm), int(d.size), s["n"])
    chk("exp.top1_W2", rst(d2, n_eval)["top1_abs_share"], E["top1_abs_share_W2"])
    chk("exp.top1_W1", rst(d1, n_eval)["top1_abs_share"], E["top1_abs_share_W1"])

    lines = ["AX3 Step 4 verify (tag=%s)" % TAG,
             "items=%d  mismatches=%d" % (len(ITEMS), len(MISMATCH))]
    for nm, got, exp in MISMATCH[:25]:
        lines.append("  MISMATCH %s: got=%r exp=%r" % (nm, got, exp))
    txt = "\n".join(lines)
    print(txt)
    with open(os.path.join(HERE, "_ax3_verify_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write(txt + "\n")


if __name__ == "__main__":
    main()
