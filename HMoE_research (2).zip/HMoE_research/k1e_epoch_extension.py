#!/usr/bin/env python3
"""K1e: epoch を増やして「未収束 run」が消えるかを確かめる。

動機（K1d）
  6 epoch では 10 本中 3 本が未収束（CE 0.507 / 0.630 / 1.052、健康域 0.352〜0.443）。
  その混合分布のせいで ΔCE の SD が 0.018 → 0.253 に膨れ、MDE は 0.056 → 0.251 に悪化した。
  3 本とも最終 epoch で損失が下降中なので、**訓練を長くすれば消える**はず。

設計
  K1/K1c と同一条件で **epoch だけ 16 に増やす**（3000 系列 × 16, bs 32, lr 2e-3）。
  教師 H+LB top-2 / 生徒 dense W=161。評価は seed 777 の 2048 系列（同一）。
  **ckpt と出力は `--tag` で分離**（6 epoch の結果を上書きしない）。

並列
  seed は独立。1 プロセス 1 スレッドで 6 本まで並列（16GB / 空き 7GB、1 本 0.76GB）。

出力: k1c_results_<tag>.json / k1c_out_utf8_<tag>.txt
"""
import argparse
import json
import os
import sys
import time
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

LOG = os.path.join(HERE, "k1c_out_utf8.txt")


def log(msg):
    print(msg, flush=True)
    with open(LOG, "a", encoding="utf-8") as f:
        f.write(msg + "\n")


def worker(job):
    seed, width, seqs, epochs, n_eval, suf = job
    import numpy as np
    import torch
    from p13c_retrain import (E2DIR, make_batch, run_cond, train_dense, train_moe, OL)

    torch.set_num_threads(1)
    t0 = time.time()
    ev = np.random.default_rng(777)
    src, out, em, ks = make_batch(ev, n_eval)

    tm = train_moe("H+LB", seed, seqs, epochs, 32, 2e-3, 0.05)
    rt = run_cond(tm, src, out, em, None, 2)
    dm = train_dense(width, seed, seqs, epochs, 32, 2e-3)
    rs = run_cond(dm, src, out, em, None, 1)

    ce_t = np.array(rt["ce_seq"], dtype=np.float64)
    ce_s = np.array(rs["ce_seq"], dtype=np.float64)
    d = ce_s - ce_t
    outdir = os.path.join(E2DIR, "data", "k1")
    os.makedirs(outdir, exist_ok=True)
    torch.save({k: v.detach() for k, v in tm.params().items()},
               os.path.join(outdir, "ckpt_teacher_s%d%s.pt" % (seed, suf)))
    torch.save({k: v.detach() for k, v in dm.params().items()},
               os.path.join(outdir, "ckpt_dense%d_s%d%s.pt" % (width, seed, suf)))
    return {
        "seed": seed, "width": width, "epochs": epochs,
        "ce_t": rt["ce_all"], "ce_s": rs["ce_all"],
        "ce_copy_t": rt["ce_copy"], "ce_copy_s": rs["ce_copy"],
        "ce_edit_t": rt["ce_edit"], "ce_edit_s": rs["ce_edit"],
        "w_teacher": rt["width"],
        "delta": float(d.mean()),
        "se_seq": float(d.std(ddof=1) / np.sqrt(len(d))),
        "t_seq": float(d.mean() / (d.std(ddof=1) / np.sqrt(len(d)))),
        "n_neg_seq": int((d < 0).sum()),
        "n_eval": len(d),
        "sec": round(time.time() - t0, 1),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=list(range(10)))
    ap.add_argument("--width", type=int, default=161)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=16)
    ap.add_argument("--n_eval", type=int, default=2048)
    ap.add_argument("--tag", type=str, default="e16")
    args = ap.parse_args()

    suf = ("_" + args.tag) if args.tag else ""
    global LOG
    LOG = os.path.join(HERE, "k1c_out_utf8%s.txt" % suf)
    if os.path.exists(LOG):
        os.remove(LOG)
    log("K1e: epochs=%d（6 epoch の未収束 3/10 が消えるか）" % args.epochs)
    log("seeds=%s width=%d workers=%d seqs=%d tag=%s"
        % (args.seeds, args.width, args.workers, args.seqs, suf))
    t0 = time.time()

    jobs = [(s, args.width, args.seqs, args.epochs, args.n_eval, suf) for s in args.seeds]
    rows = []
    part = os.path.join(HERE, "k1c_partial%s.json" % suf)
    with Pool(processes=args.workers) as pool:
        for r in pool.imap_unordered(worker, jobs):
            rows.append(r)
            log("  s%-2d  CE_t %.4f / CE_s %.4f  Δ %+.4f  (t_seq %+.1f, %.0fs)"
                % (r["seed"], r["ce_t"], r["ce_s"], r["delta"], r["t_seq"], r["sec"]))
            with open(part, "w", encoding="utf-8") as f:
                json.dump({"rows": rows}, f, ensure_ascii=False, indent=2)
    rows.sort(key=lambda r: r["seed"])

    import numpy as np
    d = np.array([r["delta"] for r in rows])
    n = len(d)
    se = float(d.std(ddof=1) / np.sqrt(n))
    coef = {2: 5.36, 5: 3.49}.get(n - 1, 2.95 if n < 12 else 2.85)
    ce_t = np.array([r["ce_t"] for r in rows])
    ce_s = np.array([r["ce_s"] for r in rows])
    log("")
    log("== 集計（n=%d, epochs=%d） ==" % (n, args.epochs))
    log("  ΔCE = %+.4f  中央値 %+.4f  SD %.4f  se %.4f  t %+.2f  %d/%d 負  MDE %.4f"
        % (d.mean(), np.median(d), d.std(ddof=1), se, d.mean() / se,
           int((d < 0).sum()), n, coef * se))
    log("  CE_教師: 平均 %.4f  SD %.4f  最大 %.4f" % (ce_t.mean(), ce_t.std(ddof=1), ce_t.max()))
    log("  CE_生徒: 平均 %.4f  SD %.4f  最大 %.4f" % (ce_s.mean(), ce_s.std(ddof=1), ce_s.max()))
    log("  未収束（CE>0.47）: %d 本" % int(((ce_t > 0.47) | (ce_s > 0.47)).sum()))
    log("  壁時計 %.0f 分" % ((time.time() - t0) / 60))

    with open(os.path.join(HERE, "k1c_results%s.json" % suf), "w", encoding="utf-8") as f:
        json.dump({"rows": rows, "epochs": args.epochs,
                   "agg": {"delta_mean": float(d.mean()), "median": float(np.median(d)),
                           "sd": float(d.std(ddof=1)), "se": se,
                           "t": float(d.mean() / se), "n": n, "mde": coef * se,
                           "n_neg": int((d < 0).sum()),
                           "n_fail": int(((ce_t > 0.47) | (ce_s > 0.47)).sum())},
                   "args": vars(args)}, f, ensure_ascii=False, indent=2)
    log("[write] k1c_results%s.json" % suf)
    os._exit(0)


if __name__ == "__main__":
    main()
