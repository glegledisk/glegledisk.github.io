# -*- coding: utf-8 -*-
"""clip 5/50 x lr 5e-4/2e-4 の 2x2 検算。

主眼は交互作用:
  I = [CE(c5,l5) - CE(c50,l5)] - [CE(c5,l2) - CE(c50,l2)]
clip が単なる lr スケール（加法的）なら I ~ 0。
独自効果（勾配方向の正規化など）があれば I != 0。
"""
import json
import os
import re

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
STEPS = 4680
T_CRIT = float(stats.t.ppf(0.975, 1))


def load(tag):
    p = os.path.join(HERE, "pc2_results_%s.json" % tag)
    by = {}
    if not os.path.exists(p):
        return by
    for r in json.load(open(p, encoding="utf-8"))["rows"]:
        by.setdefault(r["cfg"], {})[r["seed"]] = r
    return by


cur = load("n15k_clipxlr")
w3 = load("n15k_w3clip")
w10 = load("n15k_w10")
if not cur:
    raise SystemExit("pc2_results_n15k_clipxlr.json が無い。本番が未完了。")


def spec(cfg):
    ml = re.search(r"_lr([0-9.]+)", cfg)
    mc = re.search(r"_clip([0-9.]+)", cfg)
    mw = re.search(r"\+kd_w([0-9.]+)_T([0-9.]+)", cfg)
    return {
        "lr": float(ml.group(1)) if ml else 5e-4,
        "clip": float(mc.group(1)) if mc else 5.0,
        "w": float(mw.group(1)) if mw else None,
        "T": float(mw.group(2)) if mw else None,
        "kd": mw is not None,
    }


print("== 設定の assert（腕名と記録値の一致）==")
for cfg, d in sorted(cur.items()):
    sp = spec(cfg)
    for s, r in sorted(d.items()):
        assert abs(r["clip"] - sp["clip"]) < 1e-9, (s, cfg, "clip")
        assert abs(r["lr"] - sp["lr"]) < 1e-12, (s, cfg, "lr")
        if sp["kd"]:
            assert abs(r["kd_w"] - sp["w"]) < 1e-9, (s, cfg, "kd_w")
            assert abs(r["kd_T"] - sp["T"]) < 1e-9, (s, cfg, "kd_T")
        else:
            assert r["kd_w"] == 0.0, (s, cfg, "kd_w should be 0")
        assert r["N"] == 15000 and r["per_key"] == 2 and r["epochs"] == 10
print("  OK: %d 腕 x %d seed、clip / lr / kd_w / kd_T / N / per_key / epochs すべて一致"
      % (len(cur), len(next(iter(cur.values())))))

# --- 2x2 のセルを組む ---
cell = {}
for cfg in cur:
    sp = spec(cfg)
    if not sp["kd"] or sp["w"] != 10.0 or sp["T"] != 1.0:
        continue
    cell[(int(sp["clip"]), round(sp["lr"], 6))] = cfg
need = [(5, 0.0005), (5, 0.0002), (50, 0.0005), (50, 0.0002)]
missing = [k for k in need if k not in cell]
assert not missing, "2x2 のセルが欠けている: %s" % missing

base = {0.0005: "half:scratch", 0.0002: "half:scratch_lr0.0002"}
print("\n== 水準（N=1.5e4, per_key=2, 10ep, w=10, T=1, n=2）==")
print("  %-46s %5s %8s %8s %8s %9s %9s %11s"
      % ("cfg", "clip", "lr", "CE", "acc", "発動", "ΔCE", "KD ep1→10"))
for k in need:
    cfg = cell[k]
    d = cur[cfg]
    ce = np.mean([v["ce"] for v in d.values()])
    ac = np.mean([v["acc"] for v in d.values()])
    ncl = np.mean([v["n_clip"] for v in d.values()])
    bc = cur[base[k[1]]]
    ks = sorted(set(d) & set(bc))
    dd = np.array([d[s]["ce"] - bc[s]["ce"] for s in ks])
    kd1 = np.mean([v["ce_hist"][0]["kd"] for v in d.values()])
    kd10 = np.mean([v["ce_hist"][-1]["kd"] for v in d.values()])
    print("  %-46s %5d %8.0e %8.4f %8.4f %5.0f(%4.1f%%) %+9.4f %11s"
          % (cfg, k[0], k[1], ce, ac, ncl, 100 * ncl / STEPS, dd.mean(),
             "%.3f→%.3f" % (kd1, kd10)))

print("\n== 対照（lr 別）==")
for lr, cfg in base.items():
    d = cur[cfg]
    print("  lr %-8.0e %-24s CE %.4f  acc %.4f  clip 発動 %.0f"
          % (lr, cfg, np.mean([v["ce"] for v in d.values()]),
             np.mean([v["acc"] for v in d.values()]),
             np.mean([v["n_clip"] for v in d.values()])))

print("\n== 各セル − 同じ lr の scratch（同一 seed, df=1）==")
for k in need:
    cfg, bcfg = cell[k], base[k[1]]
    d, bc = cur[cfg], cur[bcfg]
    ks = sorted(set(d) & set(bc))
    x = np.array([d[s]["ce"] for s in ks])
    y = np.array([bc[s]["ce"] for s in ks])
    diff = x - y
    t, p = stats.ttest_rel(x, y)
    se = diff.std(ddof=1) / np.sqrt(len(diff))
    print("  clip %-3d lr %-8.0e ΔCE %+.4f  se %.4f  t %+.2f  p %.4f  %d/%d  検知限界 %.4f"
          % (k[0], k[1], diff.mean(), se, t, p,
             int((diff < 0).sum()), len(diff), T_CRIT * se))

print("\n== 2x2 の主効果と交互作用（同一 seed, df=1）==")
seeds = sorted(set.intersection(*[set(cur[cell[k]]) for k in need]))


def ce(k, s):
    return cur[cell[k]][s]["ce"]


def contrast(name, f):
    v = np.array([f(s) for s in seeds])
    se = v.std(ddof=1) / np.sqrt(len(v)) if len(v) > 1 else float("nan")
    t, p = stats.ttest_1samp(v, 0.0) if len(v) > 1 and se > 0 else (float("nan"), float("nan"))
    print("  %-42s %+9.4f  se %.4f  t %+7.2f  p %.4f  検知限界 %.4f  (%d/%d)"
          % (name, v.mean(), se, t, p, T_CRIT * se,
             int((v < 0).sum()), len(v)))
    return v


contrast("clip 主効果 @ lr 5e-4  [c5 - c50]",
         lambda s: ce((5, 0.0005), s) - ce((50, 0.0005), s))
contrast("clip 主効果 @ lr 2e-4  [c5 - c50]",
         lambda s: ce((5, 0.0002), s) - ce((50, 0.0002), s))
contrast("lr 主効果 @ clip 5   [l5 - l2]",
         lambda s: ce((5, 0.0005), s) - ce((5, 0.0002), s))
contrast("lr 主効果 @ clip 50  [l5 - l2]",
         lambda s: ce((50, 0.0005), s) - ce((50, 0.0002), s))
print("  ---")
contrast("★ 交互作用 I = (c5-c50)@l5 - (c5-c50)@l2",
         lambda s: (ce((5, 0.0005), s) - ce((50, 0.0005), s))
                   - (ce((5, 0.0002), s) - ce((50, 0.0002), s)))
contrast("対応 A: [clip5,lr2e-4] - [clip50,lr5e-4]",
         lambda s: ce((5, 0.0002), s) - ce((50, 0.0005), s))
contrast("対応 B: [clip5,lr5e-4] - [clip50,lr2e-4]",
         lambda s: ce((5, 0.0005), s) - ce((50, 0.0002), s))

print("\n== 校正: 前回実行との一致 ==")
for cfg, tags in [
    ("half:scratch", [("w3clip", w3), ("w10", w10)]),
    ("half:scratch+kd_w10.0_T1.0", [("w10", w10)]),
    ("half:scratch+kd_w10.0_T1.0_clip50", [("w3clip", w3), ("w10", w10)]),
]:
    if cfg not in cur:
        continue
    a = np.mean([v["ce"] for v in cur[cfg].values()])
    for tag, by in tags:
        if cfg in by:
            b = np.mean([v["ce"] for v in by[cfg].values()])
            print("  %-46s vs %-8s 今回 %.4f 前回 %.4f 差 %+.4f"
                  % (cfg, tag, a, b, a - b))
