# -*- coding: utf-8 -*-
"""audit3_20261024.py — bpb_verification の BPB 差に信頼区間を与える
per-token NLL を保存し、移動ブロック・ブートストラップ（block=50 token）で
bpb と bpb 差の 95%CI を推定する。文書内自己相関を考慮するため iid ブートストラップは使わない。
"""
import os, glob, math, json
import numpy as np
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM

os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["TOKENIZERS_PARALLELISM"] = "false"
HERE = os.path.dirname(os.path.abspath(__file__))

def get_texts():
    en_files = sorted(glob.glob(os.path.join(HERE, "english_version", "**", "*.md"), recursive=True))
    en_text = ""
    for f in en_files:
        en_text += open(f, encoding="utf-8").read() + "\n\n"
        if len(en_text.encode()) > 150000: break
    ja_files = [f for f in sorted(glob.glob(os.path.join(HERE, "*.md"), recursive=True)) if "english_version" not in f]
    ja_text = ""
    for f in ja_files:
        ja_text += open(f, encoding="utf-8").read() + "\n\n"
        if len(ja_text.encode()) > 150000: break
    return {"en": en_text.encode()[:32768].decode("utf-8", "ignore"),
            "ja": ja_text.encode()[:32768].decode("utf-8", "ignore")}

def _b2u():
    bs = (list(range(ord("!"), ord("~")+1)) + list(range(ord("\u00a1"), ord("\u00ac")+1))
          + list(range(ord("\u00ae"), ord("\u00ff")+1)))
    cs = bs[:]; n = 0
    for b in range(256):
        if b not in bs:
            bs.append(b); cs.append(256+n); n += 1
    return {chr(c): b for b, c in zip(bs, cs)}
U2B = _b2u()

def raw_tok_bytes(s):
    """バイトレベルBPEの語彙表記 -> 生バイト列。部分バイトトークンでも正しい長さになる。"""
    o = bytearray()
    for ch in s:
        b = U2B.get(ch)
        if b is None:
            return s.encode("utf-8", "ignore")
        o.append(b)
    return bytes(o)

def per_token_nll(model_dir, text, max_tokens=1536, chunk=512):
    tok = AutoTokenizer.from_pretrained(model_dir, local_files_only=True)
    mdl = AutoModelForCausalLM.from_pretrained(model_dir, local_files_only=True,
                                               dtype=torch.float32, low_cpu_mem_usage=True)
    mdl.eval()
    ids = tok(text, add_special_tokens=False)["input_ids"][:max_tokens]
    nll, nbytes = [], []
    with torch.no_grad():
        for s in range(0, len(ids) - 1, chunk):
            c = ids[s:s + chunk + 1]
            if len(c) < 2: break
            inp = torch.tensor([c[:-1]]); tgt = torch.tensor([c[1:]])
            lg = mdl(inp).logits
            lp = torch.log_softmax(lg, dim=-1)
            v = -lp[0, torch.arange(len(c) - 1), tgt[0]].numpy()
            nll.extend(v.tolist())
            for t in c[1:]:
                nbytes.append(len(raw_tok_bytes(tok.convert_ids_to_tokens(t))))
    return np.array(nll), np.array(nbytes, float)

texts = get_texts()
res = {}
for name in ["qwen3-0.6b", "smollm-135m"]:
    p = os.path.join(HERE, "models", name)
    if not os.path.isdir(p): continue
    res[name] = {}
    for lang in ["en", "ja"]:
        nll, nb = per_token_nll(p, texts[lang])
        bits = nll / math.log(2.0)
        bpb = bits.sum() / nb.sum()
        # moving-block bootstrap
        L = len(bits); B = 50; nb_blocks = int(np.ceil(L / B)); rng = np.random.default_rng(0)
        vals = []
        for _ in range(4000):
            st = rng.integers(0, L - B + 1, nb_blocks)
            idx = (st[:, None] + np.arange(B)[None, :]).ravel()
            idx = idx[idx < L]
            vals.append(bits[idx].sum() / nb[idx].sum())
        vals = np.array(vals)
        res[name][lang] = {"bpb": float(bpb), "lo": float(np.percentile(vals, 2.5)),
                           "hi": float(np.percentile(vals, 97.5)),
                           "bpt": float(nb.sum() / len(bits)),
                           "ce_bits_per_token": float(bits.mean()),
                           "n_tokens": int(len(bits)),
                           "_bits": bits, "_nb": nb}
        print("[%s/%s] bpb=%.4f  95%%CI=[%.4f, %.4f]  bits/tok=%.3f  bpt=%.3f  n=%d"
              % (name, lang, bpb, res[name][lang]["lo"], res[name][lang]["hi"],
                 bits.mean(), nb.sum() / len(bits), len(bits)))

print("\n=== 差の検定（共通のブートストラップ添字で対応づけ） ===")
for lang in ["en", "ja"]:
    if "qwen3-0.6b" not in res or "smollm-135m" not in res: continue
    a = res["qwen3-0.6b"][lang]; b = res["smollm-135m"][lang]
    # 同一添字でリサンプルして差の分布を得る（共通ブロック境界を使うため長さを揃える）
    L = min(len(a["_bits"]), len(b["_bits"])); B = 50
    A, Bb, NA, NB = a["_bits"][:L], b["_bits"][:L], a["_nb"][:L], b["_nb"][:L]
    rng = np.random.default_rng(1); nb_blocks = int(np.ceil(L / B)); d = []
    for _ in range(4000):
        st = rng.integers(0, L - B + 1, nb_blocks)
        idx = (st[:, None] + np.arange(B)[None, :]).ravel(); idx = idx[idx < L]
        d.append(Bb[idx].sum() / NB[idx].sum() - A[idx].sum() / NA[idx].sum())
    d = np.array(d)
    print("%s: bpb(smollm)-bpb(qwen) = %+.4f  95%%CI=[%+.4f, %+.4f]  P(>0)=%.3f"
          % (lang, b["bpb"] - a["bpb"], np.percentile(d, 2.5), np.percentile(d, 97.5), float((d > 0).mean())))

for k in res:
    for l in res[k]:
        res[k][l].pop("_bits", None); res[k][l].pop("_nb", None)
json.dump(res, open(os.path.join(HERE, "audit3_bpb_ci.json"), "w", encoding="utf-8"), indent=2, ensure_ascii=False)
print("\nsaved audit3_bpb_ci.json")
