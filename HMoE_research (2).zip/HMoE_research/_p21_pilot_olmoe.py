# -*- coding: utf-8 -*-
"""P21 パイロット: OLMoE-1B-7B（base LM）が生成 QA に使えるか（使い捨て）

OLMoE は chat_template を持たない base LM（13.8GB, 64 expert / top-8）。
8GB GPU には収まらないので device_map="auto" で CPU offload する。
best-of-N のハーネスに載せる前に、
  (1) 算術の答えを parse できる形で出せるか
  (2) 速度は実用的か（サンプル数 × token 数の見積り）
を測る。

出力: _p21_pilot_out_utf8.txt
"""
import json
import os
import re
import time

import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "olmoe-1b-7b")
VAL_RE = re.compile(r"-?\d+")
OUT = []


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def main():
    from transformers import AutoModelForCausalLM, AutoTokenizer
    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token

    t0 = time.time()
    # 13.8GB (bf16) は 8GB GPU に載らず、RAM も 8GB しか空いていない（disk offload は MoE で不可）。
    # → 4-bit 量子化で GPU に載せる。量子化ノイズは結果の解釈に明記する。
    from transformers import BitsAndBytesConfig
    bnb = BitsAndBytesConfig(load_in_4bit=True,
                             bnb_4bit_compute_dtype=torch.bfloat16,
                             bnb_4bit_quant_type="nf4",
                             bnb_4bit_use_double_quant=True)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, quantization_config=bnb, device_map="cuda",
        attn_implementation="sdpa").eval()
    log("load %.0fs (4-bit nf4)" % (time.time() - t0))
    log("gpu mem: %.2f GB" % (torch.cuda.memory_allocated() / 1e9))

    probs = [{"q": "Compute 12345 + 67890.", "gold": str(12345 + 67890)},
             {"q": "Compute 48213 + 5917.", "gold": str(48213 + 5917)}]

    few = ("Compute 21 + 34.\nAnswer: 55\n\n"
           "Compute 108 + 7.\nAnswer: 115\n\n"
           "Compute 4002 + 31.\nAnswer: 4033\n\n")

    variants = {
        "zs": lambda q: "%s\nThe answer is" % q,
        "fs": lambda q: "%s%s\nAnswer:" % (few, q),
        "qa": lambda q: "Question: %s\nAnswer:" % q,
    }

    n_samp = 2
    cap = 64
    for name, fn in variants.items():
        t0 = time.time()
        ntok = 0
        parsed = 0
        ok = 0
        samples = []
        for p in probs:
            pr = fn(p["q"])
            enc = tok([pr] * n_samp, return_tensors="pt", padding=True,
                      add_special_tokens=False).to(model.device)
            with torch.no_grad():
                o = model.generate(**enc, max_new_tokens=cap, do_sample=True,
                                   temperature=0.9, top_p=0.95,
                                   pad_token_id=tok.pad_token_id)
            gen = o[:, enc["input_ids"].shape[1]:]
            for j in range(n_samp):
                ids = [t for t in gen[j].tolist() if t != tok.pad_token_id]
                txt = tok.decode(ids, skip_special_tokens=True)
                ntok += len(ids)
                nums = VAL_RE.findall(txt.replace(",", ""))
                pred = nums[-1] if nums else None
                parsed += int(pred is not None)
                ok += int(pred == p["gold"])
                samples.append((p["q"], pred, p["gold"], txt[:110].replace("\n", " ")))
        dt = time.time() - t0
        log("\n[%s] %.0fs  %d tok  %.2f tok/s  parsed=%d/%d  correct=%d"
            % (name, dt, ntok, ntok / max(dt, 1e-9), parsed, len(samples), ok))
        for s in samples:
            log("   q=%s pred=%s gold=%s | %s" % s)

    with open(os.path.join(HERE, "_p21_pilot_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    os._exit(0)


if __name__ == "__main__":
    main()
