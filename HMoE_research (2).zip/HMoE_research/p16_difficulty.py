# -*- coding: utf-8 -*-
"""P16: 難度ラダーで best-of-N の較正を測る（P15 の天井を外す）

P15 は clean プールが 37/40 正解で飽和していた。較正ギャップ −0.002 が
「天井の産物」かどうかは、正解率が中間の課題でしか判定できない。
また P15 の実務則「打ち切りを答えなしとして除く」が、打ち切りが 7 割出る
難課題でも成り立つかは未検証。

3 水準（同一トークン予算 cap=96 で難度だけ変える）:
  add5 : 5 桁 + 5 桁        （P14 と同型。基準）
  sub5 : 5 桁 − 5 桁        （中間）
  mul2 : 2 桁 × 2 桁        （打ち切り多発。フィルタの stress test）

手続は p14_bestofn.py と同一（score_sample を import して計器を共有）。
20 問 × 8 サンプル × 2 ラウンド + greedy 8 問/水準（slack 検査用）。

出力: p16_difficulty.jsonl / p16_meta.json
"""

import argparse
import json
import os
import random

import numpy as np
import torch

from p14_bestofn import score_sample, extract_value   # 計器を共有（同一実装で測る）

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "qwen3-0.6b")
SYS = "You are a careful arithmetic assistant. Solve the problem and give the final answer."
LEVELS = ["add5", "sub5", "mul2"]


def log(m):
    print(m, flush=True)


def make(level, n, rnd):
    out = []
    for _ in range(n):
        if level == "add5":
            a, b = rnd.randint(10001, 99999), rnd.randint(10001, 99999)
            out.append({"q": "Compute %d + %d." % (a, b), "gold": str(a + b)})
        elif level == "sub5":
            a, b = rnd.randint(50001, 99999), rnd.randint(10001, 49999)
            out.append({"q": "Compute %d - %d." % (a, b), "gold": str(a - b)})
        elif level == "mul2":
            a, b = rnd.randint(11, 99), rnd.randint(11, 99)
            out.append({"q": "Compute %d * %d." % (a, b), "gold": str(a * b)})
        else:
            raise ValueError(level)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_prob", type=int, default=20)
    ap.add_argument("--n_samp", type=int, default=8)
    ap.add_argument("--rounds", type=int, default=2)
    ap.add_argument("--seed", type=int, default=41)
    ap.add_argument("--n_greedy", type=int, default=8)
    ap.add_argument("--tag", type=str, default="p16")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer
    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    eos_id = tok.eos_token_id
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, torch_dtype=torch.bfloat16, device_map="cuda",
        attn_implementation="sdpa").eval()

    rnd = random.Random(args.seed)
    probs = {lv: make(lv, args.n_prob, rnd) for lv in LEVELS}
    prompts = {}
    prompt_ids = {}
    for lv in LEVELS:
        prompts[lv] = [tok.apply_chat_template(
            [{"role": "system", "content": SYS}, {"role": "user", "content": p["q"]}],
            tokenize=False, add_generation_prompt=True, enable_thinking=False)
            for p in probs[lv]]
        prompt_ids[lv] = [tok(pr, add_special_tokens=False)["input_ids"]
                          for pr in prompts[lv]]
    log("problems: %d per level (%s)" % (args.n_prob, ",".join(LEVELS)))

    recs = []
    for r_i in range(args.rounds):
        for lv in LEVELS:
            torch.manual_seed(args.seed + 100 + r_i)
            for i, p in enumerate(probs[lv]):
                enc = tok([prompts[lv][i]] * args.n_samp, return_tensors="pt",
                          padding=True, add_special_tokens=False).to(model.device)
                with torch.no_grad():
                    o = model.generate(**enc, max_new_tokens=96, do_sample=True,
                                       temperature=0.9, top_p=0.95,
                                       pad_token_id=tok.pad_token_id)
                gen = o[:, enc["input_ids"].shape[1]:]
                samples = []
                for j in range(args.n_samp):
                    ids = [t for t in gen[j].tolist() if t != tok.pad_token_id]
                    txt = tok.decode(ids, skip_special_tokens=True)
                    try:
                        sc = score_sample(model, tok, prompt_ids[lv][i], txt, eos_id,
                                          ids_gen=ids)
                    except Exception as e:                       # noqa: BLE001
                        sc = {"p_ans": None, "p_full": None, "n_ans": 0,
                              "err": str(e)[:120], "retok": None}
                    pred = extract_value(txt)
                    samples.append({
                        "pred": pred,
                        "correct": None if pred is None else (pred == p["gold"]),
                        "p_ans": sc["p_ans"], "p_full": sc["p_full"],
                        "n_ans": sc["n_ans"], "err": sc["err"], "retok": sc["retok"],
                        "ntok": len(ids), "tail": txt.strip()[-60:]})
                recs.append({"round": r_i, "level": lv, "q": p["q"],
                             "gold": p["gold"], "samples": samples})
            log("round %d / %s done" % (r_i, lv))

    greedy = []
    torch.manual_seed(args.seed + 999)
    for lv in LEVELS:
        for i, p in enumerate(probs[lv][:args.n_greedy]):
            enc = tok(prompts[lv][i], return_tensors="pt",
                      add_special_tokens=False).to(model.device)
            with torch.no_grad():
                o = model.generate(**enc, max_new_tokens=96, do_sample=False,
                                   pad_token_id=tok.pad_token_id)
            ids = o[0, enc["input_ids"].shape[1]:].tolist()
            txt = tok.decode(ids, skip_special_tokens=True)
            try:
                sc = score_sample(model, tok, prompt_ids[lv][i], txt, eos_id,
                                  ids_gen=ids, slack=True)
            except Exception as e:                               # noqa: BLE001
                sc = {"p_ans": None, "p_full": None, "n_ans": 0,
                      "err": str(e)[:120], "slack": None, "retok": None}
            pred = extract_value(txt)
            greedy.append({"round": "greedy", "level": lv, "q": p["q"], "gold": p["gold"],
                           "pred": pred,
                           "correct": None if pred is None else (pred == p["gold"]),
                           "p_ans": sc["p_ans"], "p_full": sc["p_full"],
                           "n_ans": sc["n_ans"], "err": sc["err"],
                           "slack": sc["slack"], "retok": sc["retok"],
                           "ntok": len(ids), "tail": txt.strip()[-60:]})
    log("greedy arm done")

    sl = [g["slack"] for g in greedy if g.get("slack") is not None]
    log("greedy argmax-slack: mean=%.6f max=%.6f (n=%d)"
        % (float(np.mean(sl)), float(np.max(sl)), len(sl)))
    if float(np.mean(sl)) > 0.02:
        log("WARN: slack too large — scoring convention suspect")

    n_retok_bad = (sum(1 for r in recs for s in r["samples"] if s.get("retok") is False)
                   + sum(1 for g in greedy if g.get("retok") is False))
    meta = {"n_prob_per_level": args.n_prob, "levels": LEVELS, "n_samp": args.n_samp,
            "rounds": args.rounds, "seed": args.seed, "temperature": 0.9, "top_p": 0.95,
            "max_new_tokens": 96, "n_recs": len(recs), "n_samples": len(recs) * args.n_samp,
            "n_greedy": len(greedy), "n_retok_mismatch": n_retok_bad,
            "n_scored": sum(1 for r in recs for s in r["samples"] if s["p_ans"] is not None),
            "slack": {"mean": float(np.mean(sl)), "max": float(np.max(sl))},
            "instrument": "score_sample imported from p14_bestofn.py (identical scoring)",
            "model": MODEL}
    with open(os.path.join(HERE, "%s_difficulty.jsonl" % args.tag), "w", encoding="utf-8") as fp:
        for r in recs:
            fp.write(json.dumps(r, ensure_ascii=False) + "\n")
        for g in greedy:
            fp.write(json.dumps(g, ensure_ascii=False) + "\n")
    with open(os.path.join(HERE, "%s_meta.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(meta, fp, ensure_ascii=False, indent=2)
    log(json.dumps(meta, ensure_ascii=False))
    os._exit(0)


if __name__ == "__main__":
    main()
