import json, numpy as np
s = json.load(open("p3_topk_summary.json", encoding="utf-8"))
print("p3 summary: seed=%s windows=%s len=%s n=%s" % (s.get("seed"), s.get("windows_per_lang"), s.get("window_len"), s.get("n_tokens")))
a = np.load("p3_topk_nll.npz", allow_pickle=True); b = np.load("p6a_decision_curve.npz", allow_pickle=True)
x, y = a["k8"].astype(float), b["k8_nll"].astype(float)
lang = a["lang"]
win = np.repeat(np.arange(lang.size), 255)
for u in ("en", "ja"):
    m = lang[win] == u
    print("%s: p3=%.5f p6a=%.5f  maxdiff=%.3g" % (u, x[m].mean(), y[m].mean(), np.abs(x[m]-y[m]).max()))