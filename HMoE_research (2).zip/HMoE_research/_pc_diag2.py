#!/usr/bin/env python3
"""q12b の ckpt を Q8 の forward と自前 forward で比べる（CE の食い違いの原因切り分け）。"""
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))

import q2_difficulty_ladder as Q2
import q8_static_dispatch as Q8
from e2b_rewrite_routing_fixed import RewriteMoE, WIDTHS
import e2b_rewrite_routing_fixed as E2

print("E2.SEQ =", E2.SEQ)
p = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q12b",
                 "ckpt_H+LB_hard_dynamic_lb_s0.pt")
sd = torch.load(p, map_location="cpu")
print("pos.w shape", tuple(sd["pos.w"].shape), " head.w", tuple(sd["head.w"].shape))
m = RewriteMoE(WIDTHS["H+LB"], seed=0)
print("model pos.w shape", tuple(m.p["pos.w"].shape))
m.p = {k: v for k, v in sd.items()}
for k in m.p:
    m.p[k].requires_grad_(False)

rng = np.random.default_rng(777)
seq, typ = Q2.make_trace_batch(rng, 256, task="hard")
x = torch.from_numpy(seq)
tb = torch.from_numpy(typ)


def ce_of(logits):
    lg = logits[:, Q2.TRACE0 - 1:-1, :len(Q2.VOCAB)]
    tgt = torch.from_numpy(seq[:, Q2.TRACE0:])
    lp = F.cross_entropy(lg.reshape(-1, len(Q2.VOCAB)), tgt.reshape(-1),
                         reduction="none").reshape(-1, Q2.T_LEN - Q2.TRACE0)
    ty = typ[:, Q2.TRACE0:]
    return (float(lp.mean()), float(lp[ty == Q2.TYP_STRUCT].mean()),
            float(lp[ty == Q2.TYP_PAYLOAD].mean()),
            float((lg.argmax(-1).numpy() == tgt.numpy()).mean()))


with torch.no_grad():
    lo, _, _ = Q8.forward_dispatch(m, x, typ=tb, mode="dynamic_lb")
    print("Q8.forward_dispatch : CE %.4f struct %.4f payload %.4f acc %.4f" % ce_of(lo))
    print("Q8.evaluate_q8      :", Q8.evaluate_q8(m, seq, typ, mode="dynamic_lb"))
    lo2, _, _ = m(x, aux_mode="none", need_idx=True)
    print("model.forward       : CE %.4f struct %.4f payload %.4f acc %.4f" % ce_of(lo2))
os._exit(0)
