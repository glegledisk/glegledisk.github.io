# -*- coding: utf-8 -*-
"""P11 解析: 決定単位の順序と閾値運用

入力: p11_decision.npz
出力: p11_analysis.json / p11_analysis_out_utf8.txt

見るもの:
  (1) 4 択 AUROC が保たれるか（順序）
  (2) τ=0.8 の運用点（水準）
  (3) 新規越境の誤り率とその CI（P6c の再現）
"""

import json
import math
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
CONDS = ["base", "f1", "u1", "f1_rs"]


def wilson(k, n, z=1.96):
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0.0, c - h), min(1.0, c + h))


def auroc(score, label):
    score = np.asarray(score, np.float64)
    label = np.asarray(label, bool)
    npos = int(label.sum())
    nneg = label.size - npos
    if npos == 0 or nneg == 0:
        return float("nan")
    order = np.argsort(score, kind="mergesort")
    ranks = np.empty(score.size, np.float64)
    ranks[order] = np.arange(1, score.size + 1)
    s = score[order]
    i = 0
    while i < s.size:
        j = i
        while j + 1 < s.size and s[j + 1] == s[i]:
            j += 1
        if j > i:
            ranks[order[i:j + 1]] = (i + j + 2) / 2.0
        i = j + 1
    return float((ranks[label].sum() - npos * (npos + 1) / 2) / (npos * nneg))


def main():
    z = np.load(os.path.join(HERE, "p11_decision.npz"), allow_pickle=True)
    lang = z["lang"]
    d = {c: {f: z["%s_%s" % (c, f)] for f in ("nll", "ptop", "correct", "conf4", "correct4")}
         for c in CONDS}
    n = d["base"]["nll"].size
    nw = lang.size
    per = n // nw
    tok_lang = np.repeat(lang, per)

    lines = []
    def emit(s=""):
        lines.append(s)
        print(s, flush=True)

    emit("=== P11 決定単位（4 択, n=%d, %d 窓）===" % (n, nw))
    emit("")
    out = {"n_tokens": int(n), "n_windows": int(nw)}

    emit("[0] 水準と順序")
    emit("%-7s %8s %9s %9s %9s %9s" %
         ("cond", "acc4", "conf4", "AUROC4", "AUROC_tok", "gap4"))
    for c in CONDS:
        r = d[c]
        a4 = auroc(r["conf4"], r["correct4"])
        at = auroc(r["ptop"], r["correct"])
        emit("%-7s %8.4f %9.4f %9.4f %9.4f %+9.4f"
             % (c, r["correct4"].mean(), r["conf4"].mean(), a4, at,
                r["conf4"].mean() - r["correct4"].mean()))
        out.setdefault("levels", {})[c] = {
            "acc4": float(r["correct4"].mean()), "conf4": float(r["conf4"].mean()),
            "auroc4": a4, "auroc_tok": at}
    emit("")

    emit("[1] τ=0.8 の運用（4 択の確信度）")
    emit("%-7s %8s %12s %10s %14s" % ("cond", "自動化率", "自動化内誤り", "新規越境率", "新規越境の誤り[95%CI]"))
    out["threshold"] = {}
    hb = d["base"]["conf4"] >= 0.8
    for c in CONDS:
        r = d[c]
        hi = r["conf4"] >= 0.8
        new = hi & ~hb
        ea = float((~r["correct4"][hi]).mean()) if hi.sum() else float("nan")
        k_new = int((~r["correct4"][new]).sum())
        nn = int(new.sum())
        lo, up = wilson(k_new, nn)
        emit("%-7s %8.4f %12.4f %10.4f %10.4f [%.2f,%.2f] (n=%d)"
             % (c, hi.mean(), ea, new.mean(),
                (k_new / nn) if nn else float("nan"), lo, up, nn))
        out["threshold"][c] = {"auto_rate": float(hi.mean()), "err_in_auto": ea,
                               "new_rate": float(new.mean()),
                               "err_new": (k_new / nn) if nn else None,
                               "err_new_ci": [lo, up], "n_new": nn,
                               "k_new_wrong": k_new}
    emit("")

    emit("[2] 既存越境（base でも閾値を越えていた）の誤り")
    for c in CONDS:
        r = d[c]
        hi = r["conf4"] >= 0.8
        old = hi & hb
        k_old = int((~r["correct4"][old]).sum())
        nn = int(old.sum())
        lo, up = wilson(k_old, nn)
        emit("    %-7s %.4f [%.2f,%.2f] (n=%d)"
             % (c, (k_old / nn) if nn else float("nan"), lo, up, nn))
        out["threshold"][c].update({"err_old": (k_old / nn) if nn else None,
                                    "err_old_ci": [lo, up], "n_old": nn})
    emit("")

    emit("[3] 言語別 AUROC4")
    out["per_lang"] = {}
    for lg in ("en", "ja"):
        sel = (tok_lang == lg)
        row = {c: auroc(d[c]["conf4"][sel], d[c]["correct4"][sel]) for c in CONDS}
        emit("    %s: %s" % (lg, "  ".join("%s %.4f" % (c, row[c]) for c in CONDS)))
        out["per_lang"][lg] = row
    emit("")

    # ---------- 4. 閾値を再較正したら消えるか ----------
    emit("[4] 自動化率を base に揃えるよう閾値を選び直したときの誤り")
    emit("    （AUROC が保たれているなら、ここで base と同じ誤りに戻るはず）")
    target = float((d["base"]["conf4"] >= 0.8).mean())
    emit("    目標の自動化率 = %.4f（base の τ=0.8）" % target)
    emit("%-7s %10s %12s %12s" % ("cond", "新しい τ", "自動化率", "自動化内誤り"))
    out["recalibrated"] = {}
    for c in CONDS:
        conf = d[c]["conf4"]
        tau = float(np.quantile(conf, 1.0 - target))
        hi = conf >= tau
        err = float((~d[c]["correct4"][hi]).mean()) if hi.sum() else float("nan")
        lo, up = wilson(int((~d[c]["correct4"][hi]).sum()), int(hi.sum()))
        emit("%-7s %10.4f %12.4f %10.4f [%.2f,%.2f]"
             % (c, tau, hi.mean(), err, lo, up))
        out["recalibrated"][c] = {"tau": tau, "auto_rate": float(hi.mean()),
                                  "err": err, "ci": [lo, up]}
    emit("")
    emit("    読み方: base の τ=0.8 のままだと f1 は 0.1693、u1 は 0.1739（§1）。")
    emit("    再較正後が base の 0.1666 に戻れば、害は「閾値のずれ」だけで説明できる。")

    with open(os.path.join(HERE, "p11_analysis.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2, default=float)
    with open(os.path.join(HERE, "p11_analysis_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(lines) + "\n")
    print("saved: p11_analysis.json / p11_analysis_out_utf8.txt")


if __name__ == "__main__":
    main()
