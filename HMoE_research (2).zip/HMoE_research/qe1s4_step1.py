# -*- coding: utf-8 -*-
"""QE1S4 Step 1: entropy-matched uniform support calibration; no training/GPU."""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(HERE / "不均一MoE-Corpus"))

from corpus_common import COPY_WINDOW, N_TYPES, SEQ_LEN, TRAIN_SEED_BASE, V_IDENT, V_SYNTAX, VOCAB
from qe1_make_task import (CALIB_SEED, EDIT_RULES, EPS_EDIT, EPS_EDIT_MI, EPS_POS,
                           N_CALIB_SEQ, POS_BINS, calibrate, eta2_categorical,
                           joint_table, make_task, mi_over_entropy, pos_bins)

TAG = "qe1s4_s1"
K_IDENT = 180
EPS_H_MATCH = 0.10
MIN_P_COPYABLE = 0.10
FREQS = ("zipf", "uniform_k")
ARRAY_KEYS = ("tokens", "types", "next_tok", "copy_mask", "is_syntax",
              "ident_rank", "type_draw", "a", "changed", "base")
S3_ARRAYS = HERE / "qe1s3_step1_arrays.npz"


def build(freq: str):
    return make_task(CALIB_SEED, N_CALIB_SEQ, base=TRAIN_SEED_BASE,
                     freq=freq, init_type="uniform", ident_vocab_size=K_IDENT,
                     paired_frequency=True)


def entropy_copy(c) -> float:
    x = np.asarray(c.next_tok, dtype=np.int64)[np.asarray(c.copy_mask, dtype=bool)]
    if x.size == 0:
        return 0.0
    counts = np.bincount(x, minlength=VOCAB).astype(np.float64)
    p = counts[counts > 0] / x.size
    return float(-np.sum(p * np.log(p)))


def recurrence(c) -> float:
    mask = np.asarray(c.copy_mask, dtype=bool)
    tok = np.asarray(c.tokens, dtype=np.int64)
    nxt = np.asarray(c.next_tok, dtype=np.int64)
    rows, cols = np.nonzero(mask)
    if rows.size == 0:
        return 0.0
    found = np.zeros(rows.size, dtype=bool)
    target = nxt[rows, cols]
    for lag in range(1, COPY_WINDOW + 1):
        src = cols - lag
        valid = src >= 0
        found[valid] |= tok[rows[valid], src[valid]] == target[valid]
    return float(found.mean())


def measure(freq: str, c) -> dict:
    cal = calibrate(c, f"qe1s4_{freq}")
    pb = pos_bins(c.tokens.shape)
    h = entropy_copy(c)
    p_rule = {r: float(cal["by_edit_rule"][r]["p_copyable"]) for r in EDIT_RULES}
    return {
        "freq": freq, "n_seq": int(c.tokens.shape[0]), "n_tokens": int(c.tokens.size),
        "R_copy": float(np.asarray(c.copy_mask, dtype=np.float64).mean()),
        "H_emp": h, "P_rule": p_rule, "P_re": recurrence(c),
        "N_syn": float(np.asarray(c.next_tok)[np.asarray(c.copy_mask, dtype=bool)].__lt__(V_SYNTAX).mean()),
        "C2_eta2_type_pos": float(cal["C2_eta2_type_pos"]),
        "C2_mi_type_pos_norm": float(cal["C2_mi_type_pos_norm"]),
        "C3_eta2_edit_given_pos": float(cal["C3_eta2_edit_given_pos"]),
        "C3_mi_edit_norm": float(cal["C3_mi_edit_norm"]),
        "C7_eta2_a_pos": float(eta2_categorical(c.a, pb, POS_BINS, N_TYPES)),
        "C7_mi_a_pos_norm": float(mi_over_entropy(joint_table(pb, c.a, POS_BINS, N_TYPES))),
        "copy_positions": int(np.asarray(c.copy_mask, dtype=bool).sum()),
        "P_copyable_pass": bool(p_rule["copy"] >= MIN_P_COPYABLE),
    }


def arrays_of(c) -> dict:
    return {k: np.asarray(getattr(c, k)) for k in ARRAY_KEYS}


def maxdiff(a, b) -> int:
    assert a.shape == b.shape, (a.shape, b.shape)
    return int(np.max(np.abs(a.astype(np.int64) - b.astype(np.int64)))) if a.size else 0


def default_compatibility() -> dict:
    assert S3_ARRAYS.exists(), f"missing calibration baseline: {S3_ARRAYS}"
    baseline = np.load(S3_ARRAYS, allow_pickle=False)
    result = {}
    for f in ("zipf", "uniform"):
        a = make_task(CALIB_SEED, N_CALIB_SEQ, base=TRAIN_SEED_BASE,
                      freq=f, init_type="uniform")
        b = make_task(CALIB_SEED, N_CALIB_SEQ, base=TRAIN_SEED_BASE,
                      freq=f, init_type="uniform")
        per = {}
        for key in ARRAY_KEYS:
            old_key = f"{f}_{key}"
            if old_key in baseline.files:
                ref = baseline[old_key]
            elif key == "types":
                ref = baseline[f"{f}_a"]
            elif key == "is_syntax":
                ref = baseline[f"{f}_tokens"] < V_SYNTAX
            else:
                raise KeyError(f"no historical baseline for {old_key}")
            per[key] = maxdiff(np.asarray(getattr(a, key)), np.asarray(ref))
            per[f"repeat_{key}"] = maxdiff(np.asarray(getattr(a, key)), np.asarray(getattr(b, key)))
        result[f] = {"per_array_maxdiff": per,
                     "pass": bool(max(per.values(), default=0) == 0)}
    return result


def main() -> None:
    corpora = {f: build(f) for f in FREQS}
    measured = {f: measure(f, corpora[f]) for f in FREQS}
    z, u = measured["zipf"], measured["uniform_k"]
    d_h = float(u["H_emp"] - z["H_emp"])
    common = {}
    for key in ("type_draw", "is_syntax", "a"):
        common[key] = maxdiff(np.asarray(getattr(corpora["zipf"], key)),
                              np.asarray(getattr(corpora["uniform_k"], key)))
    syntax_ids_equal = bool(np.array_equal(
        np.asarray(corpora["zipf"].tokens)[np.asarray(corpora["zipf"].is_syntax, dtype=bool)],
        np.asarray(corpora["uniform_k"].tokens)[np.asarray(corpora["uniform_k"].is_syntax, dtype=bool)]))
    c1 = default_compatibility()
    checks = {
        "C1_default_path_bit_identical_to_QE1S3_and_reproducible": bool(
            all(v["pass"] for v in c1.values())),
        "C2_common_type_syntax_and_rule_streams": bool(
            all(v == 0 for v in common.values()) and syntax_ids_equal),
        "C3_entropy_match": bool(abs(d_h) <= EPS_H_MATCH),
        "C4_uniform_support_recurrence": bool(u["P_rule"]["copy"] >= MIN_P_COPYABLE),
        "C5_position_independence": bool(all(
            measured[f][k] < EPS_POS for f in FREQS for k in
            ("C2_eta2_type_pos", "C2_mi_type_pos_norm", "C7_eta2_a_pos", "C7_mi_a_pos_norm"))),
        "C6_edit_signal": bool(all(
            measured[f]["C3_eta2_edit_given_pos"] > EPS_EDIT and
            measured[f]["C3_mi_edit_norm"] > EPS_EDIT_MI for f in FREQS)),
        "C7_copy_mask_integrity": bool(all(
            abs(measured[f]["P_re"] - 1.0) < 1e-12 and
            abs(measured[f]["N_syn"]) < 1e-12 for f in FREQS)),
    }
    arrays = {}
    for f, c in corpora.items():
        for key, val in arrays_of(c).items():
            arrays[f"{f}_{key}"] = val
    arrays["zipf_pos_bin"] = pos_bins(corpora["zipf"].tokens.shape).astype(np.int8)
    arrays["uniform_k_pos_bin"] = pos_bins(corpora["uniform_k"].tokens.shape).astype(np.int8)
    np.savez_compressed(HERE / f"{TAG}_arrays.npz", **arrays)
    out = {
        "tag": TAG, "design": "QE1S4課題設計書_エントロピーを揃えた一様頻度対照でT3を再検定する_20261116.md",
        "phase": "generation calibration; no training, no GPU, no confirmatory test",
        "prereg": {"K_IDENT": K_IDENT, "K_RULE": "round(exp(QE1S3 H_emp(zipf)))",
                   "H_zipf_reference": 5.193622395572733, "effective_K_reference": math.exp(5.193622395572733),
                   "EPS_H_MATCH": EPS_H_MATCH, "MIN_P_COPYABLE": MIN_P_COPYABLE,
                   "CALIB_SEED": CALIB_SEED, "N_CALIB_SEQ": N_CALIB_SEQ,
                   "INIT_TYPE": "uniform", "paired_frequency": True,
                   "FREQS": list(FREQS), "COPY_WINDOW": COPY_WINDOW,
                   "EPS_POS": EPS_POS, "EPS_EDIT": EPS_EDIT, "EPS_EDIT_MI": EPS_EDIT_MI},
        "default_compatibility": c1,
        "paired_stream_maxdiff": common,
        "syntax_ids_equal": syntax_ids_equal,
        "measurement": measured,
        "delta_H_uniform_k_minus_zipf": d_h,
        "checks": checks,
        "verdict": "PASS" if all(checks.values()) else "FAIL",
    }
    bad = []
    def scan(x, path="root"):
        if isinstance(x, dict):
            for k, v in x.items(): scan(v, f"{path}.{k}")
        elif isinstance(x, list):
            for i, v in enumerate(x): scan(v, f"{path}[{i}]")
        elif isinstance(x, float) and not np.isfinite(x):
            bad.append(path)
    scan(out)
    out["C8_nonfinite"] = {"paths": bad, "pass": not bad}
    if bad:
        out["verdict"] = "FAIL"
    (HERE / f"{TAG}_metrics.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    lines = [f"tag={TAG}", f"verdict={out['verdict']}",
             f"H_emp zipf={z['H_emp']:.8f} uniform_k={u['H_emp']:.8f} delta={d_h:.8f}",
             f"P_rule(copy) zipf={z['P_rule']['copy']:.8f} uniform_k={u['P_rule']['copy']:.8f}",
             f"R_copy zipf={z['R_copy']:.8f} uniform_k={u['R_copy']:.8f}",
             f"common_stream_maxdiff={common} syntax_ids_equal={syntax_ids_equal}",
             f"checks={checks}", f"nonfinite={bad}", ""]
    (HERE / f"{TAG}.log").write_text("\n".join(lines), encoding="utf-8")
    sys.stdout.write("\n".join(lines)); sys.stdout.flush()


if __name__ == "__main__":
    main()
