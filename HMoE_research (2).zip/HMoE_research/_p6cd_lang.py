import numpy as np, math
def tl_of(z):
    lang=z["lang"]; n=z["base_nll"].size
    return np.repeat(lang, n//lang.size)
def gap(z,c):
    return z["%s_ptop1"%c].astype(float)-z["%s_top1"%c].astype(float)
def t(a,b):
    d=np.asarray(a,float)-np.asarray(b,float); se=d.std(ddof=1)/math.sqrt(d.size)
    return d.mean(), d.mean()/se

print("=== P6c: rescale の効き方を言語別に（較正ギャップ, pt）===")
z=np.load("p6e_rescale_cal.npz",allow_pickle=True); tl=tl_of(z)
print("%-14s %12s %12s %12s" % ("比較","全体","en","ja"))
for a,b,lab in (("k6","base","k6 - base"),("k6_rs","base","k6_rs - base"),
                ("k6","k6_rs","k6 - k6_rs (質量)"),("u7","base","u7 - base"),
                ("u7","u7_rs","u7 - u7_rs (質量)")):
    ga,gb=gap(z,a),gap(z,b)
    m,tt=t(ga,gb); row=[100*m,tt]
    s=[]
    for u in ("en","ja"):
        k=tl==u; mm,ttt=t(ga[k],gb[k]); s.append((100*mm,ttt))
    print("%-14s %+8.3f(t%+5.1f) %+8.3f(t%+5.1f) %+8.3f(t%+5.1f)"
          % (lab,row[0],row[1],s[0][0],s[0][1],s[1][0],s[1][1]))

print()
print("=== P6d: 層の非対称性と rescale を言語別に（較正ギャップ, pt）===")
z=np.load("p6g_layer_rescale.npz",allow_pickle=True); tl=tl_of(z)
for a,b,lab in (("f8b6","f6b8","f8b6 - f6b8"),("f8b6_rs","f6b8_rs","RS: f8b6 - f6b8"),
                ("f8b6","f8b6_rs","f8b6 - f8b6_rs (質量)"),
                ("f6b8","f6b8_rs","f6b8 - f6b8_rs (質量)")):
    ga,gb=gap(z,a),gap(z,b)
    m,tt=t(ga,gb); s=[]
    for u in ("en","ja"):
        k=tl==u; mm,ttt=t(ga[k],gb[k]); s.append((100*mm,ttt))
    print("%-20s %+8.3f(t%+5.1f) %+8.3f(t%+5.1f) %+8.3f(t%+5.1f)"
          % (lab,100*m,tt,s[0][0],s[0][1],s[1][0],s[1][1]))