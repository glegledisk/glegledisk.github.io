# Table 9 of arXiv:2609.12303 の内訳検算 + 系列長スケーリング
# 単位: 1 トークン(=1 unit) あたり forward FLOPs。総 FLOPs は 3x (fwd+bwd)。
d = 2048
ffn = 5632
L = 25
Vtok, Vbyte, Veot = 128256, 260, 261
Ls = {"Token-1B": 2048, "Bytes-1B": 9216, "EOT-1B": 11264}
V = {"Token-1B": Vtok, "Bytes-1B": Vbyte, "EOT-1B": Veot}

def parts(name, Lseq):
    sa = 2 * Lseq * d * L          # self-attention (per-token, linear in L)
    qkvo = 8 * d * d * L           # 4 projections, 2 flops each
    ff = 4 * d * ffn * L           # up + down
    de = 2 * d * V[name]
    return dict(sa=sa, qkvo=qkvo, ff=ff, de=de)

print("=== 再現 (論文 Table 9 との一致確認) ===")
for n in Ls:
    p = parts(n, Ls[n])
    tot = sum(p.values())
    print(f"{n:10s} sa={p['sa']:>13,} qkvo={p['qkvo']:>13,} ff={p['ff']:>13,} de={p['de']:>11,} "
          f"tot={tot:>14,} x3={3*tot:>14,}")

print("\n=== 構成比 (forward 比、3x は共通なので比は不変) ===")
for n in Ls:
    p = parts(n, Ls[n])
    tot = sum(p.values())
    print(f"{n:10s} out={100*p['de']/tot:6.2f}%  FFN={100*p['ff']/tot:6.2f}%  "
          f"attn={100*(p['sa']+p['qkvo'])/tot:6.2f}%  (QKVO={100*p['qkvo']/tot:5.2f}, SA={100*p['sa']/tot:5.2f})")

print("\n=== 系列長を伸ばしたときの FFN 比率 (=MoE で削れる上限) ===")
print(f"{'L倍':>4} {'Bytes L':>9} {'FFN%':>7} {'attn%':>7} {'EOT L':>9} {'FFN%':>7} {'attn%':>7}")
for k in [1, 2, 4, 8]:
    row = [f"{k:>4}"]
    for n in ["Bytes-1B", "EOT-1B"]:
        p = parts(n, Ls[n] * k)
        tot = sum(p.values())
        row += [f"{Ls[n]*k:>9,}", f"{100*p['ff']/tot:7.2f}", f"{100*(p['sa']+p['qkvo'])/tot:7.2f}"]
    print(" ".join(row))

print("\n=== EOT vs Bytes: 1 unit あたり / 1 テキストトークン(=5.5 unit) あたり ===")
pb, pe = parts("Bytes-1B", 9216), parts("EOT-1B", 11264)
tb, te = 3 * sum(pb.values()), 3 * sum(pe.values())
print(f"per unit : {tb:,.0f} -> {te:,.0f}  = +{100*(te/tb-1):.2f}%")
print(f"per text token (4.5 vs 5.5 units): {4.5*tb:,.0f} -> {5.5*te:,.0f} = +{100*(5.5*te/(4.5*tb)-1):.2f}%")
print(f"EOT vs Token-1B per text token: {5.5*te:,.0f} vs {3*sum(parts('Token-1B',2048).values()):,.0f} = x{(5.5*te)/(3*sum(parts('Token-1B',2048).values())):.2f}")

print("\n=== 語彙層が解放するパラメータ (embed+head, 重み共有なし仮定) ===")
pe_tok = 2 * d * Vtok
pe_byte = 2 * d * Veot
layer = 1_284_608_000
print(f"Token-1B embed+head = {pe_tok:,} ({100*pe_tok/(pe_tok+layer):.1f}% of total)")
print(f"EOT-1B   embed+head = {pe_byte:,}")
print(f"解放 = {pe_tok-pe_byte:,} = layer パラメータの {100*(pe_tok-pe_byte)/layer:.1f}%")

print("\n=== EOT の境界密度と、境界のみ大 expert に流した場合の平均 FFN コスト ===")
# 1 <eot> per 4.5 bytes -> 境界位置の割合
for ratio in [1/4.5, 1/5.5]:
    pass
p_b = 1 / 5.5  # 全 unit のうち <eot> の割合 (EOT は 4.5 内容バイト + 1 eot)
print(f"<eot> の割合 = {100*p_b:.2f}% of units")
for small_ratio in [0.25, 0.5]:
    avg = p_b * 1.0 + (1 - p_b) * small_ratio
    print(f"  小 expert の幅 = 大 expert の {small_ratio:.2f} 倍 -> 平均 FFN = {avg:.3f} (削減 {100*(1-avg):.1f}%)"
          f" -> 総 FLOPs 削減 ≈ {100*(1-avg)*36.65:.1f}% (FFN 比率 36.65%)")

print("\n=== HMoE 3B: 活性パラメータ削減率 ===")
print(f"0.68/1.23 = {100*0.68/1.23:.1f}% (削減 {100*(1-0.68/1.23):.1f}%)")
