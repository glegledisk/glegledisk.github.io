# -*- coding: utf-8 -*-
"""P19 補助: makespan 比を JSON から計算（使い捨て）"""
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
d = json.load(open(os.path.join(HERE, "p19_fanout.json"), encoding="utf-8"))
KS = [0, 1, 2, 4]
print("makespan_ratio = (max_share_H / max_share_U) * (flops_H / flops_U)")
ratios = []
for k in KS:
    row = []
    for s in ["0", "1", "2"]:
        h = d["arms"]["H+LB"]["seeds"][s]["per_k"][str(k)]
        u = d["arms"]["U+LB"]["seeds"][s]["per_k"][str(k)]
        r = (h["max_share_flops"] / u["max_share_flops"]) * (h["flops_per_token_mean"]
                                                            / u["flops_per_token_mean"])
        row.append(r)
        ratios.append(r)
    print("  k=%d  " % k + "  ".join("%.3f" % x for x in row) + "   mean=%.3f" % np.mean(row))
print("overall mean=%.3f  min=%.3f max=%.3f  (n=%d)" %
      (np.mean(ratios), np.min(ratios), np.max(ratios), len(ratios)))

print("\nper-seed summary")
for s in ["0", "1", "2"]:
    for arm in ["U+LB", "H+LB"]:
        p = d["arms"][arm]["seeds"][s]["per_k"]["0"]
        print("  s%s %-5s flops=%.1f cv=%.3f maxsel=%.3f maxflops=%.3f eff=%.3f"
              % (s, arm, p["flops_per_token_mean"], p["flops_per_token_cv"],
                 p["max_share_sel"], p["max_share_flops"], p["parallel_eff"]))
