# -*- coding: utf-8 -*-
"""S1b analysis: decompose toc - toc_drop into gold-row vs competitor-row effects.

Reads s1_core.npz (toc / toc_drop / none) and s1b_distractor_drop.npz (dd),
pairs on (domain, query_id), and reports

    A = toc - toc_drop          gold row removed
    B = toc - distractor_drop   sibling row removed
    A + B                       asymmetry (0 under pure relative visibility)

Also reports the far candidate under the same dd prompt as a placebo.
"""
import json
import math
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
LINES = []


def w(s=""):
    LINES.append(str(s))
    print(s, flush=True)


def paired(d, name=""):
    d = np.asarray(d, float)
    d = d[np.isfinite(d)]
    n = d.size
    if n < 3:
        return dict(name=name, n=int(n), mean=float("nan"))
    m = float(d.mean())
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    t = m / se
    p = float(stats.t.sf(abs(t), n - 1) * 2)
    a = np.sort(np.abs(d))[::-1]
    k = max(1, int(math.ceil(0.01 * n)))
    return dict(name=name, n=int(n), mean=m, se=se, t=t, p=p, mde=2.8 * se,
                median=float(np.median(d)), top1=float(a[:k].sum() / (np.abs(d).sum() + 1e-30)),
                mn=float(d.min()), mx=float(d.max()))


def show(tag, s):
    w("%-38s %+0.4f (se %0.4f, t=%+0.2f, p=%.4f, n=%d, MDE %.3f, med %+0.3f, max %+0.3f)"
      % (tag, s["mean"], s["se"], s["t"], s["p"], s["n"], s["mde"], s["median"], s["mx"]))


# ---------------------------------------------------------------- core npz
z = np.load(os.path.join(HERE, "s1_core.npz"), allow_pickle=True)
n = len(z["row_domain"])
keys = [(str(z["row_domain"][i]), int(z["row_query_id"][i]),
         str(z["row_prompt"][i]), str(z["row_ablation"][i])) for i in range(n)]
is_gold = z["row_is_gold"].astype(int)
ctype = np.array([str(x) for x in z["row_cand_type"]], dtype=object)
div_idx = z["row_div_idx"].astype(int)
logp_div = z["row_logp_div"].astype(float)

gold_keys = [k for k, g in zip(keys, is_gold) if g == 1]
gpos = {k: i for i, k in enumerate(gold_keys)}
margin_core = np.full(n, np.nan)
for i in range(n):
    if is_gold[i]:
        continue
    k = keys[i]
    if k not in gpos:
        continue
    j = div_idx[i]
    C = int(z["gold_len"][gpos[k]])
    if 0 <= j < C and np.isfinite(logp_div[i]):
        margin_core[i] = float(z["gold_logp"][gpos[k], j]) - logp_div[i]

core_plen = {}
for i in range(n):
    if is_gold[i] and keys[i][2] == "toc":
        core_plen[(keys[i][0], keys[i][1])] = int(z["row_prompt_len"][i])


def qmap_core(prompt, t):
    acc = {}
    for i in range(n):
        if is_gold[i] or ctype[i] != t:
            continue
        k = keys[i]
        if k[2] != prompt or k[3] != "base":
            continue
        acc.setdefault((k[0], k[1]), []).append(margin_core[i])
    return {k: float(np.nanmean(v)) for k, v in acc.items() if np.isfinite(v).any()}


# ---------------------------------------------------------------- dd npz
d = np.load(os.path.join(HERE, "s1b_distractor_drop.npz"), allow_pickle=True)
dn = len(d["row_domain"])
dkeys = [(str(d["row_domain"][i]), int(d["row_query_id"][i]),
          str(d["row_cand_type"][i])) for i in range(dn)]
dgold = d["row_is_gold"].astype(int)
ddiv = d["row_div_idx"].astype(int)
dlogp = d["row_logp_div"].astype(float)

dgpos = {(dkeys[i][0], dkeys[i][1]): i for i in range(dn) if dgold[i]}
# row index != gold_tok index; gold_tok is in gold-row order
dgidx = {}
for k, i in enumerate([i for i in range(dn) if dgold[i]]):
    dgidx[(dkeys[i][0], dkeys[i][1])] = k
margin_dd = np.full(dn, np.nan)
for i in range(dn):
    if dgold[i]:
        continue
    k = (dkeys[i][0], dkeys[i][1])
    if k not in dgpos:
        continue
    j = ddiv[i]
    C = int(d["gold_len"][dgidx[k]])
    if 0 <= j < C and np.isfinite(dlogp[i]):
        margin_dd[i] = float(d["gold_logp"][dgidx[k], j]) - dlogp[i]


def qmap_dd(t):
    acc = {}
    for i in range(dn):
        if dgold[i] or dkeys[i][2] != t:
            continue
        acc.setdefault((dkeys[i][0], dkeys[i][1]), []).append(margin_dd[i])
    return {k: float(np.nanmean(v)) for k, v in acc.items() if np.isfinite(v).any()}


dd_plen = {}
for i in range(dn):
    if dgold[i]:
        dd_plen[(dkeys[i][0], dkeys[i][1])] = int(d["row_prompt_len"][i])

meta = json.loads(str(d["meta"][0]))
w("dd meta: n_queries=%d n_rows=%d n_fwd=%d elapsed=%.0f s checks=%s"
  % (meta["n_queries"], meta["n_rows"], meta["n_fwd"], meta["elapsed_s"], json.dumps(meta["checks"])))

# ---------------------------------------------------------------- pairing
S = qmap_core("toc", "sibling")
SD = qmap_core("toc_drop", "sibling")
SN = qmap_core("none", "sibling")
DD = qmap_dd("sibling")
F = qmap_core("toc", "far")
FN = qmap_core("none", "far")
FDD = qmap_dd("far")

common = sorted(set(S) & set(SD) & set(SN) & set(DD))
w("paired queries: %d (sibling)" % len(common))

w("\n== absolute margins (sibling, n=%d) ==" % len(common))
for name, m in (("toc", S), ("toc_drop", SD), ("distractor_drop", DD), ("none", SN)):
    v = np.array([m[k] for k in common])
    show(name, paired(v))

w("\n== key decomposition ==")
A = np.array([S[k] - SD[k] for k in common])
B = np.array([S[k] - DD[k] for k in common])
show("A = toc - toc_drop (gold removed)", paired(A))
show("B = toc - distractor_drop (sib removed)", paired(B))
show("A + B (asymmetry; 0 = pure visibility)", paired(A + B))
show("distractor_drop - toc_drop", paired(np.array([DD[k] - SD[k] for k in common])))
show("distractor_drop - none", paired(np.array([DD[k] - SN[k] for k in common])))
show("toc_drop - none", paired(np.array([SD[k] - SN[k] for k in common])))

w("\n== far placebo (same dd prompt; far decision should not care) ==")
fc = sorted(set(F) & set(FN) & set(FDD))
show("toc - distractor_drop (far)", paired(np.array([F[k] - FDD[k] for k in fc])))
show("distractor_drop - none (far)", paired(np.array([FDD[k] - FN[k] for k in fc])))

w("\n== 2x2 decomposition (gold present x sibling present) ==")
gold_main = np.array([((S[k] - SD[k]) + (DD[k] - SN[k])) / 2 for k in common])
comp_main = np.array([((S[k] - DD[k]) + (SD[k] - SN[k])) / 2 for k in common])
inter = np.array([(S[k] - DD[k]) - (SD[k] - SN[k]) for k in common])
show("gold present (main effect)", paired(gold_main))
show("sibling present (main effect)", paired(comp_main))
show("interaction", paired(inter))
w("  cell means: toc(+g,+s)=%+.3f  dd(+g,-s)=%+.3f  none(-g,-s)=%+.3f  toc_drop(-g,+s)=%+.3f"
  % (np.mean([S[k] for k in common]), np.mean([DD[k] for k in common]),
     np.mean([SN[k] for k in common]), np.mean([SD[k] for k in common])))

w("\n== ratios (descriptive) ==")
a_m = float(A.mean())
b_m = float(B.mean())
w("  -B/A = %+.3f   (1.0 = removing the competitor helps as much as adding the gold)" % (-b_m / a_m))
w("  (A+B)/A = %+.3f   (0 = pure visibility, 1 = gold-specific)" % ((a_m + b_m) / a_m))
w("  corr(A, B) = %+.3f" % float(np.corrcoef(A, B)[0, 1]))

w("\n== per domain ==")
doms = sorted(set(k[0] for k in common))
domA, domB = [], []
dom_out = {}
for dom in doms:
    idx = [i for i, k in enumerate(common) if k[0] == dom]
    domA.append(float(A[idx].mean()))
    domB.append(float(B[idx].mean()))
    show("  %-16s A" % dom, paired(A[idx]))
    show("  %-16s B" % dom, paired(B[idx]))
    show("  %-16s A+B" % dom, paired((A + B)[idx]))
    dom_out[dom] = {"A": paired(A[idx]), "B": paired(B[idx]), "A_plus_B": paired((A + B)[idx])}
w("  domain-level corr(A, B) = %+.3f  (n=5 domains; descriptive only)"
  % float(np.corrcoef(domA, domB)[0, 1]))
w("  A by domain: " + " ".join("%+.3f" % v for v in domA))
w("  B by domain: " + " ".join("%+.3f" % v for v in domB))

w("\n== prompt length ==")
pl_toc = np.array([core_plen[k] for k in common], float)
pl_dd = np.array([dd_plen[k] for k in common], float)
w("  toc = %.1f (sd %.1f)   distractor_drop = %.1f (sd %.1f)   drop = %.1f tokens"
  % (pl_toc.mean(), pl_toc.std(ddof=1), pl_dd.mean(), pl_dd.std(ddof=1), (pl_toc - pl_dd).mean()))
w("  (toc_drop in S1 was 802.1 vs toc 812.9 -> drop 10.8 tokens; matched)")

w("\n== tail / sign ==")
for name, v in (("A", A), ("B", B), ("A+B", A + B)):
    w("  %-4s positive %d / negative %d / zero %d  (n=%d)"
      % (name, int((v > 0).sum()), int((v < 0).sum()), int((v == 0).sum()), v.size))

out = {
    "description": "S1b: distractor_drop control for the sibling claim",
    "n_paired": len(common),
    "absolute": {name: paired(np.array([m[k] for k in common]))
                 for name, m in (("toc", S), ("toc_drop", SD), ("distractor_drop", DD), ("none", SN))},
    "A_toc_minus_toc_drop": paired(A),
    "B_toc_minus_distractor_drop": paired(B),
    "asymmetry_A_plus_B": paired(A + B),
    "two_by_two": {
        "gold_main": paired(gold_main),
        "sibling_main": paired(comp_main),
        "interaction": paired(inter),
        "cells": {"toc": float(np.mean([S[k] for k in common])),
                  "dd": float(np.mean([DD[k] for k in common])),
                  "none": float(np.mean([SN[k] for k in common])),
                  "toc_drop": float(np.mean([SD[k] for k in common]))},
    },
    "dd_minus_toc_drop": paired(np.array([DD[k] - SD[k] for k in common])),
    "dd_minus_none": paired(np.array([DD[k] - SN[k] for k in common])),
    "toc_drop_minus_none": paired(np.array([SD[k] - SN[k] for k in common])),
    "far_placebo": {
        "toc_minus_dd": paired(np.array([F[k] - FDD[k] for k in fc])),
        "dd_minus_none": paired(np.array([FDD[k] - FN[k] for k in fc])),
    },
    "ratios": {"minus_B_over_A": -b_m / a_m, "A_plus_B_over_A": (a_m + b_m) / a_m,
               "corr_A_B": float(np.corrcoef(A, B)[0, 1])},
    "by_domain": dom_out,
    "prompt_len": {"toc": float(pl_toc.mean()), "dd": float(pl_dd.mean()),
                   "drop": float((pl_toc - pl_dd).mean())},
    "meta": meta,
}
with open(os.path.join(HERE, "s1b_analysis.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=1, default=float)
with open(os.path.join(HERE, "s1b_analysis_out_utf8.txt"), "w", encoding="utf-8") as f:
    f.write("\n".join(LINES))
print("wrote s1b_analysis.json / s1b_analysis_out_utf8.txt")
