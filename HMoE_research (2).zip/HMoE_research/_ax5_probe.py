#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX5 事前調査: 粒度カーブの機構分解が c8/c7 配列だけで計算できるかを確認する。

新規 forward なし。ax4_sentence_bound.npz / ax3_transfer.npz のみ。
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
N_LAYERS = 16
N_WIN = 48
N_EVAL = 255
N_TOK = N_WIN * N_EVAL


def unit_decision(Y):
    n = Y.shape[0]
    cut = np.argmin(Y[:, N_LAYERS:], axis=1).astype(np.int8)
    Q = Y[:, :N_LAYERS].copy()
    Q[np.arange(n), cut] = -np.inf
    prot = np.argmax(Q, axis=1).astype(np.int8)
    return cut, prot


def unit_targets(c8, c7, sid, n_unit):
    c8u = np.stack([np.bincount(sid, weights=c8[L], minlength=n_unit)
                    for L in range(N_LAYERS)], axis=1)
    c7u = np.stack([np.bincount(sid, weights=c7[L], minlength=n_unit)
                    for L in range(N_LAYERS)], axis=1)
    cnt = np.bincount(sid, minlength=n_unit).astype(np.float64)
    return np.concatenate([c8u / cnt[:, None], c7u / cnt[:, None]], axis=1)


def pred_gain(c8, c7, sid, cut, prot):
    """per-token predicted gain of unit decisions: -c7[cut,t] - c8[prot,t]."""
    return -c7[cut[sid], np.arange(N_TOK)] - c8[prot[sid], np.arange(N_TOK)]


def main():
    z4 = np.load(os.path.join(HERE, "ax4_sentence_bound.npz"))
    c8 = z4["c8"].astype(np.float64)
    c7 = z4["c7"].astype(np.float64)
    nll = {k[4:]: z4[k].astype(np.float64) for k in z4.files if k.startswith("nll_")}
    u7 = nll["u7_rep"]
    ar = np.arange(N_TOK)

    print("c8 mean by layer:", np.round(c8.mean(1), 6))
    print("c7 mean by layer:", np.round(c7.mean(1), 6))

    # per-token oracle
    cut_t = np.argmin(c7, axis=0).astype(np.int8)
    Q = c8.copy()
    Q[cut_t, ar] = -np.inf
    prot_t = np.argmax(Q, axis=0).astype(np.int8)
    pg_tok = pred_gain(c8, c7, np.arange(N_TOK), cut_t, prot_t)  # sid==idx -> per token
    # careful: pred_gain uses cut[sid]; sid=ar gives per-token decision
    real_tok = u7 - nll["sent_oracle"]  # placeholder, replaced below
    real_tok = u7 - np.load(os.path.join(HERE, "ax3_transfer.npz"))["nll_lay_tok_oracle"]

    print("\nper-token predicted gain %.8f  realized %.8f  ratio %.4f"
          % (pg_tok.mean(), real_tok.mean(), real_tok.mean() / pg_tok.mean()))
    print("corr(pred_tok, real_tok) %.4f  spearman %.4f"
          % (np.corrcoef(pg_tok, real_tok)[0, 1],
             np.corrcoef(np.argsort(np.argsort(pg_tok)),
                         np.argsort(np.argsort(real_tok)))[0, 1]))

    # existing partitions
    parts = {
        "win48": None,
        "sent4_102": z4["sent4"],
        "sent2_181": z4["sent2"],
        "sent_340": z4["sent"],
        "sent_nl_630": z4["sent_nl"],
    }
    # window partition
    sid_win = np.repeat(np.arange(N_WIN), N_EVAL).astype(np.int32)
    parts["win48"] = sid_win
    real = {
        "win48": u7 - np.load(os.path.join(HERE, "ax3_transfer.npz"))["nll_lay_win_oracle"],
        "sent4_102": u7 - nll["sent4_oracle"],
        "sent2_181": u7 - nll["sent2_oracle"],
        "sent_340": u7 - nll["sent_oracle"],
        "sent_nl_630": u7 - nll["sent_nl_oracle"],
    }

    print("\n%-12s %6s %8s %8s %8s %8s %8s %8s %8s" %
          ("part", "n_unit", "len_mu", "len_cv", "len_max", "G_pred", "G_real", "ratio", "agree"))
    rows = {}
    for nm in ("win48", "sent4_102", "sent2_181", "sent_340", "sent_nl_630"):
        sid = parts[nm]
        n_u = int(sid.max()) + 1
        lens = np.bincount(sid)
        Y = unit_targets(c8, c7, sid, n_u)
        cut, prot = unit_decision(Y)
        pg = pred_gain(c8, c7, sid, cut, prot)
        agree_cut = float((cut[sid] == cut_t).mean())
        agree_prot = float((prot[sid] == prot_t).mean())
        agree = float(((cut[sid] == cut_t) & (prot[sid] == prot_t)).mean())
        # realized
        gr = float(real[nm].mean())
        rows[nm] = {"n_unit": n_u, "len_mean": float(lens.mean()),
                    "len_cv": float(lens.std() / lens.mean()),
                    "len_max": int(lens.max()),
                    "G_pred": float(pg.mean()), "G_real": gr,
                    "ratio": gr / float(pg.mean()),
                    "agree_cut": agree_cut, "agree_prot": agree_prot,
                    "agree_both": agree}
        print("%-12s %6d %8.2f %8.3f %8d %8.5f %8.5f %8.3f %8.3f" %
              (nm, n_u, lens.mean(), lens.std() / lens.mean(), lens.max(),
               pg.mean(), gr, gr / pg.mean(), agree))

    # Jensen gap decomposition for each partition (cut side / protect side)
    print("\nJensen gap: per-token optimal vs unit-level optimal")
    per_tok_c7 = c7[cut_t, ar].mean()
    per_tok_c8 = c8[prot_t, ar].mean()
    for nm in ("win48", "sent4_102", "sent2_181", "sent_340", "sent_nl_630"):
        sid = parts[nm]
        n_u = int(sid.max()) + 1
        Y = unit_targets(c8, c7, sid, n_u)
        cut, prot = unit_decision(Y)
        unit_c7 = c7[cut[sid], ar].mean()
        unit_c8 = c8[prot[sid], ar].mean()
        print("%-12s cut gap %+.6f  prot gap %+.6f  total %+.6f"
              % (nm, unit_c7 - per_tok_c7, unit_c8 - per_tok_c8,
                 (unit_c7 - per_tok_c7) + (unit_c8 - per_tok_c8)))

    # sentence length stats
    lens = np.bincount(z4["sent"])
    print("\nsentence len: mean %.2f median %.1f cv %.3f skew %.3f min %d max %d"
          % (lens.mean(), np.median(lens), lens.std() / lens.mean(),
             float(((lens - lens.mean()) ** 3).mean() / lens.std() ** 3),
             lens.min(), lens.max()))
    print("quantiles:", np.percentile(lens, [5, 10, 25, 50, 75, 90, 95, 99]).round(1))
    print("n windows per lang: en 24 / ja 24; lengths by window min/max:",
          min(np.bincount(z4["sent"][w * N_EVAL:(w + 1) * N_EVAL]).max()
              for w in range(N_WIN)),
          max(np.bincount(z4["sent"][w * N_EVAL:(w + 1) * N_EVAL]).max()
              for w in range(N_WIN)))

    with open(os.path.join(HERE, "_ax5_probe.json"), "w", encoding="utf-8") as fp:
        json.dump({"rows": rows, "per_token_pred": float(pg_tok.mean()),
                   "per_token_real": float(real_tok.mean()),
                   "len_stats": {"mean": float(lens.mean()),
                                 "median": float(np.median(lens)),
                                 "cv": float(lens.std() / lens.mean()),
                                 "max": int(lens.max())}}, fp,
                  ensure_ascii=False, indent=2)
    print("\nsaved _ax5_probe.json")


if __name__ == "__main__":
    main()
