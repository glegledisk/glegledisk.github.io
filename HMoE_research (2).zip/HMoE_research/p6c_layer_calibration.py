# -*- coding: utf-8 -*-
"""p6c_layer_calibration.py — H3 の測定: 層の非対称性は較正指標で再現するか

H3（考察_HMoEと決定モデルJev_20261027.md §6）:
    P3b の層非対称性（後半を削るのは前半の 1.66 倍高くつく）は
    較正指標（ECE / Brier / 較正ギャップ）では再現しない。
    反証条件: 較正でも同じ順序（f8b6 が f6b8 より悪い）が出る。

P3b は per-token NLL しか保存していないので、同じ 4 配分を
**確率つき**で測り直す。コーパスは凍結 ID（corpus_ids_seed11_w24_l256.npz）を使う。

出力: p6c_layer_cal.npz / p6c_out_utf8.txt

実行:
  python p6c_layer_calibration.py --gpu-gib 7.5 --cpu-gib 12.0
"""

import argparse
import json
import os
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


ALLOCS = {
    "base": None,                      # 全層 top-8
    "u7": "all:7",
    "f6b8": "0-7:6,8-15:8",
    "f8b6": "0-7:8,8-15:6",
}


def parse_alloc(spec, n_layers, full_k):
    ks = [full_k] * n_layers
    if not spec:
        return ks
    for part in spec.split(","):
        rng, k = part.split(":")
        k = int(k)
        if rng.strip() == "all":
            idx = range(n_layers)
        elif "-" in rng:
            a, b = rng.split("-")
            idx = range(int(a), int(b) + 1)
        else:
            idx = [int(rng)]
        for i in idx:
            ks[i] = k
    return ks


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--ids", type=str, default=os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz"))
    ap.add_argument("--gpu-gib", type=float, default=7.5)
    ap.add_argument("--cpu-gib", type=float, default=12.0)
    args = ap.parse_args()

    import torch
    import torch.nn.functional as F  # noqa: F401  (未使用だが import 経路を揃える)
    from transformers import AutoModelForCausalLM

    log("[1/3] loading %s" % args.model)
    t0 = time.time()
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      loaded in %.0f s" % (time.time() - t0))

    n_layers = int(model.config.num_hidden_layers)
    FULL_K = int(model.config.num_experts_per_tok)
    gates = [layer.mlp.gate for layer in model.model.layers]

    z = np.load(args.ids, allow_pickle=True)
    seqs = []
    for lang in ("en", "ja"):
        ids = torch.from_numpy(z["%s_ids" % lang].astype(np.int64))
        for w in range(ids.numel() // 256):
            seqs.append((lang, ids[w * 256:(w + 1) * 256]))
    lang_arr = np.array([s[0] for s in seqs])
    log("[2/3] frozen corpus: %d windows x 256 = %d tokens" % (len(seqs), len(seqs) * 256))

    store = {}
    for name, spec in ALLOCS.items():
        ks = parse_alloc(spec, n_layers, FULL_K)
        for i, g in enumerate(gates):
            g.top_k = ks[i]
        t1 = time.time()
        ch = {key: [] for key in ("nll", "ptop1", "top1", "mass5", "in5")}
        with torch.no_grad():
            for lang, ids in seqs:
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                lg = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                logZ = torch.logsumexp(lg, dim=-1)
                true_l = lg.gather(1, tgt.unsqueeze(-1)).squeeze(-1)
                rank = (lg > true_l.unsqueeze(-1)).sum(dim=-1) + 1
                top1_l, _ = lg.max(dim=-1)
                ptop1 = torch.exp(top1_l - logZ)
                top5_l = torch.topk(lg, 5, dim=-1).values
                mass5 = torch.exp(torch.logsumexp(top5_l, dim=-1) - logZ)
                ch["nll"].append((logZ - true_l).cpu().numpy())
                ch["ptop1"].append(ptop1.cpu().numpy())
                ch["top1"].append((rank == 1).float().cpu().numpy())
                ch["mass5"].append(mass5.cpu().numpy())
                ch["in5"].append((rank <= 5).float().cpu().numpy())
                del out, lg, logZ, true_l, rank, top5_l
                torch.cuda.empty_cache()
        store[name] = {k: np.concatenate(v) for k, v in ch.items()}
        log("      %-5s ks=%s  CE %.5f  p_top1 %.4f  acc %.4f  (%.0f s)"
            % (name, "".join(str(k) for k in ks), store[name]["nll"].mean(),
               store[name]["ptop1"].mean(), store[name]["top1"].mean(), time.time() - t1))

    np.savez_compressed(os.path.join(HERE, "p6c_layer_cal.npz"), lang=lang_arr,
                        **{("%s_%s" % (n, k)): store[n][k] for n in store for k in store[n]})
    with open(os.path.join(HERE, "p6c_out_utf8.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(LOG))
    log("saved p6c_layer_cal.npz")
    import sys
    sys.stdout.flush()
    os._exit(0)


if __name__ == "__main__":
    main()
