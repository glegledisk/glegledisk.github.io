"""zdiag_cpu2.py — 任意の小モデルを CPU で回し、実 p_T で TV を測る（汎用版）

TV(q_EOT, q_MI) = T/Z を、実際の教師分布 p_T で評価する。

  python zdiag_cpu2.py --repo Qwen/Qwen3-0.6B --name qwen3-0.6b --langs en,ja

- GPU 不使用
- モデルは HF の resolve URL から urllib で直接取得（hf_hub_download は snapshot 作成で失敗する）
"""

import argparse
import bisect
import glob
import json
import os
import sys
import time
import urllib.request

os.environ["CUDA_VISIBLE_DEVICES"] = ""
os.environ["TOKENIZERS_PARALLELISM"] = "false"

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))


def fetch_list(repo):
    url = f"https://huggingface.co/api/models/{repo}"
    req = urllib.request.Request(url, headers={"User-Agent": "curl/8"})
    with urllib.request.urlopen(req, timeout=60) as r:
        j = json.loads(r.read())
    return [s["rfilename"] for s in j.get("siblings", [])]


def dl(repo, name):
    d = os.path.join(HERE, "models", name)
    os.makedirs(d, exist_ok=True)
    try:
        files = fetch_list(repo)
    except Exception as e:
        print(f"[warn] file list 取得失敗: {e}")
        files = ["config.json", "model.safetensors", "tokenizer.json",
                 "tokenizer_config.json", "generation_config.json", "special_tokens_map.json"]
    want = [f for f in files
            if f.endswith(".json") or f.endswith(".safetensors") or f.endswith(".txt")]
    for fn in want:
        dst = os.path.join(d, fn)
        if os.path.exists(dst) and os.path.getsize(dst) > 0:
            continue
        url = f"https://huggingface.co/{repo}/resolve/main/{fn}"
        t0 = time.time()
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "curl/8"})
            with urllib.request.urlopen(req, timeout=1800) as r:
                data = r.read()
            with open(dst, "wb") as f:
                f.write(data)
            print(f"[dl] {fn} {len(data)/1e6:.2f} MB {time.time()-t0:.1f}s", flush=True)
        except Exception as e:
            print(f"[FAIL] {fn}: {type(e).__name__}: {str(e)[:120]}", flush=True)
    return d


def bytes_to_unicode():
    bs = (list(range(ord("!"), ord("~") + 1))
          + list(range(ord("¡"), ord("¬") + 1))
          + list(range(ord("®"), ord("ÿ") + 1)))
    cs = bs[:]
    n = 0
    for b in range(256):
        if b not in bs:
            bs.append(b)
            cs.append(256 + n)
            n += 1
    return {chr(c): b for b, c in zip(bs, cs)}


UNI2BYTE = bytes_to_unicode()


def token_bytes(s):
    out = bytearray()
    for ch in s:
        b = UNI2BYTE.get(ch)
        if b is None:
            return None
        out.append(b)
    return bytes(out)


class Lattice:
    def __init__(self, tokenizer_json):
        from tokenizers import Tokenizer
        self.tk = Tokenizer.from_file(tokenizer_json)
        pairs = []
        for s, i in self.tk.get_vocab().items():
            b = token_bytes(s)
            if b:
                pairs.append((b, i))
        pairs.sort()
        self.keys = [p[0] for p in pairs]
        self.ids = np.array([p[1] for p in pairs], dtype=np.int64)
        self.pos = {b: k for k, (b, _) in enumerate(pairs)}
        self.maxlen = max(len(b) for b in self.keys)
        self.n = len(pairs)
        self.id2bytes = {i: b for b, i in pairs}
        self.V = self.tk.get_vocab_size()
        self._rng = {}

    def subtree_range(self, p):
        r = self._rng.get(p)
        if r is None:
            lo = bisect.bisect_left(self.keys, p)
            hi = bisect.bisect_left(self.keys, p + b"\xff" * (self.maxlen + 1))
            r = (lo, hi)
            self._rng[p] = r
        return r


def load_corpus(lang, ntok):
    if lang == "en":
        files = glob.glob(os.path.join(HERE, "english_version", "**", "*.md"), recursive=True)
    else:
        files = [f for f in glob.glob(os.path.join(HERE, "*.md"), recursive=True)]
    text = "\n\n".join(open(f, encoding="utf-8", errors="ignore").read() for f in sorted(files))
    return text, len(files)


def measure(model, lat, ids, L=512):
    import torch
    chunks = []
    t0 = time.time()
    with torch.no_grad():
        for s in range(0, len(ids) - 1, L):
            c = ids[s:s + L]
            if len(c) < 2:
                break
            chunks.append(model(torch.tensor([c], dtype=torch.long)).logits[0].float().numpy())
    fwd = time.time() - t0

    counts = np.bincount(ids, minlength=lat.V + 1).astype(np.float64)
    pu_all = counts[lat.ids] / counts.sum()
    cumu_all = np.concatenate(([0.0], np.cumsum(pu_all)))

    tv_m, tv_u, js, ents, Tmass = [], [], [], [], []
    pos = 0
    for lg in chunks:
        for t in range(lg.shape[0] - 1):
            cur = pos + t
            if cur + 1 >= len(ids):
                break
            w = ids[cur + 1]
            b = lat.id2bytes.get(w)
            if not b or len(b) < 2:
                continue
            z = lg[t].astype(np.float64)
            z -= z.max()
            p = np.exp(z)
            p /= p.sum()
            ps = p[lat.ids]
            cum = np.concatenate(([0.0], np.cumsum(ps)))
            ent = float(-(p[p > 0] * np.log(p[p > 0])).sum())
            for j in range(1, len(b)):
                lo, hi = lat.subtree_range(b[:j])
                Z = cum[hi] - cum[lo]
                Zu = cumu_all[hi] - cumu_all[lo]
                k = lat.pos.get(b[:j])
                T = ps[k] if k is not None else 0.0
                Tu = pu_all[k] if k is not None else 0.0
                tv_m.append(T / Z if Z > 0 else 0.0)
                tv_u.append(Tu / Zu if Zu > 0 else 0.0)
                js.append(j)
                ents.append(ent)
                Tmass.append(T)
        pos += lg.shape[0]

    return (np.array(tv_m), np.array(tv_u), np.array(js), np.array(ents),
            np.array(Tmass), fwd)


def report(tag, tv_m, tv_u, js, ents, Tmass):
    print(f"\n=== {tag} ===")
    print(f"positions {len(tv_m)}   meanTV(real) {tv_m.mean():.4f}   meanTV(unigram) {tv_u.mean():.4f}")
    print(f"median {np.median(tv_m):.4f}  p90 {np.quantile(tv_m,0.9):.4f}  p99 {np.quantile(tv_m,0.99):.4f}")
    print(f"frac>0.05 {(tv_m>0.05).mean():.3f}  frac>0.10 {(tv_m>0.10).mean():.3f}  meanT {Tmass.mean():.5f}")
    print(f"entropy mean {ents.mean():.3f} median {np.median(ents):.3f}")
    row = [f"  j={j}: n={int((js==j).sum()):5d} TV={tv_m[js==j].mean():.4f} (uni {tv_u[js==j].mean():.4f})"
           for j in range(1, 9) if (js == j).sum()]
    print("\n".join(row))
    qs = np.quantile(ents, [0.2, 0.4, 0.6, 0.8])
    bins = np.digitize(ents, qs)
    print("  entropy quintiles: " + "  ".join(
        f"Q{k+1}={tv_m[bins==k].mean():.4f}(H={ents[bins==k].mean():.2f})" for k in range(5) if (bins == k).sum()))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default="Qwen/Qwen3-0.6B")
    ap.add_argument("--name", default="qwen3-0.6b")
    ap.add_argument("--langs", default="en,ja")
    ap.add_argument("--ntok", type=int, default=3000)
    args = ap.parse_args()

    d = dl(args.repo, args.name)
    tok_json = os.path.join(d, "tokenizer.json")
    if not os.path.exists(tok_json):
        print("[abort] tokenizer.json が無い")
        return 1
    lat = Lattice(tok_json)
    print(f"[tok] vocab={lat.V} lattice={lat.n} max_bytes={lat.maxlen}")

    import torch
    from transformers import AutoModelForCausalLM
    torch.set_num_threads(max(1, (os.cpu_count() or 4) - 1))
    t0 = time.time()
    try:
        model = AutoModelForCausalLM.from_pretrained(d, dtype=torch.float32)
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(d, torch_dtype=torch.float32)
    model.eval()
    print(f"[model] {time.time()-t0:.1f}s  params={sum(p.numel() for p in model.parameters())/1e6:.0f}M")

    out = {}
    for lang in args.langs.split(","):
        text, nf = load_corpus(lang, args.ntok)
        ids = lat.tk.encode(text, add_special_tokens=False).ids[:args.ntok]
        print(f"\n[corpus:{lang}] {len(text):,} chars / {nf} files -> {len(ids)} tokens")
        r = measure(model, lat, ids)
        report(f"{args.name}/{lang}", *r[:5])
        out[lang] = {k: v for k, v in zip(["tv_m", "tv_u", "j", "ent", "T"], r[:5])}
        print(f"[fwd] {r[5]:.1f}s")

    np.savez(os.path.join(HERE, "lattice_out", f"zdiag_{args.name}.npz"),
             **{f"{lg}_{k}": v for lg, dd in out.items() for k, v in dd.items()})
    print(f"\n[saved] lattice_out/zdiag_{args.name}.npz")
    return 0


if __name__ == "__main__":
    sys.exit(main())
