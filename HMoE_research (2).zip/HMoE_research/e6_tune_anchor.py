# -*- coding: utf-8 -*-
"""e6_tune_anchor.py — アンカー率を上げて FFN の寄与を増やす

E6 (A=64, アンカー 11.3%) の結果:
  ΔCE = 0.1792 ± 0.1041（4 seeds）— E5 d=64 の 0.028 の 6.4 倍
  しかし frozen_identity がアンカーの 61% を覚えてしまう。

問題: FFN の寄与は「アンカー率 × アンカーでの CE 差」で決まる。
  アンカー 11.3% だと理論上限は 0.113 × log(64) = 0.47。実際は 0.179。

対策: アンカー率を 11.3% → 25%（anchor_vals を 8 → 16 個）に上げる。
  理論上限は 0.25 × 4.16 = 1.04。
  sidecar の信号（src[i] ∈ anchor_vals）は依然として入力から読めるので、
  依存構造の検証という目的は損なわれない。
"""
import os, json, time
import numpy as np
import pandas as pd
from e6_memory_task import run, make_lookup_table

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = dict(L=16, A=64, lag=3, anchor_vals=tuple(range(16)), d=64)
ARMS = ["frozen_ffn", "frozen_identity"]
SEEDS = [0, 1, 2]
OUT = os.path.join(HERE, "e6_tune_anchor.csv")
tab = make_lookup_table(64)

rows = []
if os.path.exists(OUT):
    rows = pd.read_csv(OUT).to_dict("records")
have = {(r["arm"], int(r["seed"])) for r in rows}

t0 = time.time()
for arm in ARMS:
    for s in SEEDS:
        if (arm, s) in have:
            continue
        r = run(arm, s, table=tab, **CFG)
        r["arm"] = arm
        rows.append(r)
        pd.DataFrame(rows).to_csv(OUT, index=False)
        print(f"  {arm:16s} s{s} | CE {r['ce_all']:.4f} | acc {r['acc_all']:.4f} "
              f"(anchor {r['acc_anchor']:.3f}) | FFN {r['ffn_cost']:.3f} | {time.time()-t0:.0f}s", flush=True)

df = pd.DataFrame(rows)
print("\n=== E6 tuned (A=64, アンカー 25%), d=64, 60 epoch ===")
for a in ARMS:
    d = df[df.arm == a]
    print(f" {a:16s} n={len(d)}  CE {d['ce_all'].mean():.4f}±{d['ce_all'].std():.4f}  "
          f"acc {d['acc_all'].mean():.4f}  anchor {d['acc_anchor'].mean():.4f}")

piv = df.pivot_table(index="seed", columns="arm", values="ce_all")
diff = (piv["frozen_identity"] - piv["frozen_ffn"]).dropna()
print(f"\n FFN の寄与 ΔCE = {diff.mean():+.4f} ± {diff.std(ddof=1):.4f} "
      f"(n={len(diff)}, 各 seed: {[round(x,4) for x in diff.values]})")

# 前回 (アンカー 11.3%) と比較
old = pd.read_csv(os.path.join(HERE, "e6_ffn_necessity.csv"))
op = old.pivot_table(index="seed", columns="arm", values="ce_all")
od = (op["frozen_identity"] - op["frozen_ffn"]).dropna()
print("\n === アンカー率による比較 ===")
print(f"  アンカー 11.3%: ΔCE {od.mean():+.4f} ± {od.std(ddof=1):.4f} (n={len(od)})")
print(f"  アンカー 25.0%: ΔCE {diff.mean():+.4f} ± {diff.std(ddof=1):.4f} (n={len(diff)})")

json.dump({"config": {k: (list(v) if isinstance(v, tuple) else v) for k, v in CFG.items()},
           "dce_mean": float(diff.mean()), "dce_sd": float(diff.std(ddof=1)),
           "ce_ffn": float(piv["frozen_ffn"].mean()), "ce_id": float(piv["frozen_identity"].mean()),
           "dce_prev": float(od.mean()), "raw": rows},
          open(os.path.join(HERE, "e6_tune_anchor.json"), "w", encoding="utf-8"),
          indent=2, ensure_ascii=False)
print("\nsaved e6_tune_anchor.csv / .json")
