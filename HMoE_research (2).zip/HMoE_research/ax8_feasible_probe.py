#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""AX8: 別コーパス（2 スライス目）で probe 腕を置き feasible 利得を再測定する

設計書: AX8課題設計書_別コーパスでprobe腕を置きfeasible利得が再現するかを検証する_20261113.md
（走行前にコーパス・文境界・probe 定義・確認的家族・δ・校正を凍結）

新規 forward 7 本 = base_cap / u7_rep / sent_oracle / sent_random /
  sent_probe / uni48_probe / uni340_probe

確認的（Holm m=2, alpha=0.05, 両側）
  S1（主）: G_sent_probe = 0
  S2      : G_sent_oracle - G_sent_probe = 0
TOST delta=0.005 は Holm 家族の外で独立報告。

実行:
  python ax8_feasible_probe.py --dry-run
  python ax8_feasible_probe.py --smoke --tag ax8smoke
  python ax8_feasible_probe.py --tag ax8
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from ax2_layer_cost import (  # noqa: E402  純関数のみ
    paired, tost, holm, spearman, gate_stats, randproj,
)

N_LAYERS = 16
H_STRATA = (0, 5, 10, 15)
ALPHA = 0.05
LAM = 10.0
DELTA_TOST = 0.005
MIN_SENT = 8
BOUND_PERIOD = (2, 15, 32, 4340)
RAND_SEED = 1201
PERM_SEED = 4400
NPERM = 100

AX6_NPZ = os.path.join(HERE, "ax6_transfer.npz")
AX6_CORPUS = os.path.join(HERE, "corpus_ids_ax6_w24_l256.npz")
AX3_CORPUS = os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz")
AX4_NPZ = os.path.join(HERE, "ax4_sentence_bound.npz")
DESIGN = "AX8課題設計書_別コーパスでprobe腕を置きfeasible利得が再現するかを検証する_20261113.md"

TEE = None


def log(msg):
    print(msg, flush=True)
    if TEE is not None:
        TEE.write(msg + "\n")
        TEE.flush()


def assert_finite(obj, path="root"):
    bad = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            bad += assert_finite(v, path + "/" + str(k))
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            bad += assert_finite(v, path + "/%d" % i)
    elif isinstance(obj, (float, np.floating)) and not np.isfinite(obj):
        bad.append(path)
    elif isinstance(obj, np.ndarray) and not np.isfinite(obj).all():
        bad.append(path)
    return bad


# ---------------------------------------------------------------- 文境界（AX4 と同一）
def build_sent_ids(ids, bset, n_win, ln, minlen=MIN_SENT):
    n = len(ids)
    sent = np.zeros(n, dtype=np.int32)
    sid, lens, n_merged = 0, [], 0
    for w in range(n_win):
        seg = ids[w * ln:(w + 1) * ln]
        ends = np.where(np.isin(seg, list(bset)))[0]
        cuts, start = [], 0
        for e in ends:
            if e + 1 - start >= minlen:
                cuts.append([start, e + 1])
                start = e + 1
        if start < ln:
            if cuts:
                cuts[-1][1] = ln
                n_merged += 1
            else:
                cuts.append([0, ln])
        for a, b in cuts:
            sent[w * ln + a:w * ln + b] = sid
            lens.append(b - a)
            sid += 1
    lens = np.array(lens)
    assert sent.shape == (n,) and np.array_equal(np.unique(sent), np.arange(sid))
    assert lens.min() >= minlen, lens.min()
    return sent, lens, n_merged


def sent_ids_tok(sent, n_win, n_eval):
    out = np.zeros(n_win * n_eval, dtype=np.int32)
    for w in range(n_win):
        out[w * n_eval:(w + 1) * n_eval] = sent[w * 256:w * 256 + n_eval]
    return out


# ---------------------------------------------------------------- 分割・決定（AX4/AX6 と同一）
def unit_targets(c8, c7, uid, n_unit):
    cnt = np.bincount(uid, minlength=n_unit).astype(np.float64)
    assert cnt.min() > 0
    a = np.stack([np.bincount(uid, weights=c8[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    b = np.stack([np.bincount(uid, weights=c7[L], minlength=n_unit) / cnt
                  for L in range(N_LAYERS)], axis=1)
    return np.concatenate([a, b], axis=1)


def unit_decision(Y):
    cut = np.argmin(Y[:, N_LAYERS:], axis=1).astype(np.int8)
    Q = Y[:, :N_LAYERS].copy()
    Q[np.arange(Y.shape[0]), cut] = -np.inf
    prot = np.argmax(Q, axis=1).astype(np.int8)
    assert (cut != prot).all(), "cut == protect"
    return cut, prot


def kmat_from_units(uid, cut, prot, n_tok):
    km = np.full((N_LAYERS, n_tok), 7, dtype=np.int8)
    for u in range(len(cut)):
        sel = (uid == u)
        km[cut[u], sel] = 6
        km[prot[u], sel] = 8
    return km


def to_windows(kmat_eval, nw, n_eval, ln, pad_val=7):
    km = kmat_eval.reshape(N_LAYERS, nw, n_eval)
    km = np.concatenate([km, np.full((N_LAYERS, nw, 1), pad_val, dtype=np.int8)], axis=2)
    return km.reshape(N_LAYERS, nw * ln)


def ridge_loo(W, Y, lam=LAM):
    """AX4 と同一: fold ごとに訓練分割で標準化し直す leave-one-unit-out ridge。"""
    n = W.shape[0]
    pred = np.zeros_like(Y, dtype=np.float64)
    for f in range(n):
        tr = np.arange(n) != f
        Xtr, Xte = W[tr], W[f:f + 1]
        mu, sd = Xtr.mean(0), Xtr.std(0) + 1e-8
        A, B = (Xtr - mu) / sd, (Xte - mu) / sd
        ym = Y[tr].mean(0)
        d = A.shape[1]
        if d <= A.shape[0]:
            w = np.linalg.solve(A.T @ A + lam * np.eye(d), A.T @ (Y[tr] - ym))
        else:
            a = np.linalg.solve(A @ A.T + lam * np.eye(A.shape[0]), Y[tr] - ym)
            w = A.T @ a
        pred[f] = (B @ w + ym)[0]
    return pred


def safe_max_abs_rho(Y, pred):
    vals = []
    for j in range(Y.shape[1]):
        r = spearman(Y[:, j], pred[:, j])
        vals.append(abs(r) if np.isfinite(r) else 0.0)
    return float(max(vals))


def grams8(x):
    return set(tuple(int(v) for v in x[i:i + 8]) for i in range(len(x) - 7))


def overlap8(a, b):
    gb = grams8(b)
    return float(np.mean([tuple(int(v) for v in a[i:i + 8]) in gb
                         for i in range(len(a) - 7)]))


def renumber(uid):
    """保存 uid をスライスしたとき 0 から連番へ振り直す（smoke 用）。"""
    _, inv = np.unique(uid, return_inverse=True)
    return inv.astype(np.int32)


# ---------------------------------------------------------------- main
def main():
    global TEE
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--dry-run", action="store_true")
    ap.add_argument("--tag", type=str, default="ax8")
    args = ap.parse_args()
    tag = args.tag
    TEE = open(os.path.join(HERE, "%s_out_utf8.txt" % tag), "w", encoding="utf-8")

    n_win = 3 if args.smoke else args.windows
    ln, n_eval = args.len, args.len - 1
    nw, n_tok = 2 * n_win, 2 * n_win * n_eval
    sl = slice(0, n_tok)

    log("[1] corpus / partitions")
    zc = np.load(AX6_CORPUS, allow_pickle=True)
    z3 = np.load(AX3_CORPUS, allow_pickle=True)
    za = np.load(AX6_NPZ, allow_pickle=True)

    # ★ AX7 の罠: smoke は en のみ 6 窓にして保存配列の先頭と完全一致させる
    langs = ("en",) if args.smoke else ("en", "ja")
    n_lg = 2 * n_win if args.smoke else n_win
    seqs = []
    sent_all, bstats = [], {}
    for lg in langs:
        ids = zc[lg + "_ids"].astype(np.int64)[:n_lg * ln]
        assert ids.size >= n_lg * ln
        s, lens, nm = build_sent_ids(ids, BOUND_PERIOD, n_lg, ln)
        sent_all.append(sent_ids_tok(s, n_lg, n_eval))
        bstats[lg] = {"n_sent": int(lens.size), "mean_len": float(lens.mean()),
                      "median_len": float(np.median(lens)), "min_len": int(lens.min()),
                      "max_len": int(lens.max()), "n_merged": int(nm)}
        log("    %s n_sent %d mean %.1f max %d merged %d"
            % (lg, lens.size, lens.mean(), lens.max(), nm))
    # 窓順は en[0..n_lg-1] → ja[0..n_lg-1]（AX6 と同一）
    seqs = []
    for lg in langs:
        ids = zc[lg + "_ids"].astype(np.int64)[:n_lg * ln]
        for w in range(n_lg):
            seqs.append((lg, torch.from_numpy(ids[w * ln:(w + 1) * ln])))
    assert len(seqs) == nw, (len(seqs), nw)

    # 言語ごとの文 ID を offset 付きで連結
    off = 0
    joined = []
    for x in sent_all:
        joined.append(x + off)
        off = int(x.max()) + 1
    sent = np.concatenate(joined).astype(np.int32)
    n_sent = int(sent.max()) + 1
    n_sent_en = bstats["en"]["n_sent"]
    split_tok = n_lg * n_eval if not args.smoke else n_tok
    log("    total n_sent %d (en %d)  tokens %d  windows %d"
        % (n_sent, n_sent_en, n_tok, nw))

    parts = {"sent": sent,
             "uni48": renumber(za["uid_uni48"][sl]),
             "uni340": renumber(za["uid_uni340"][sl])}
    for nm, uid in parts.items():
        assert uid.shape == (n_tok,), (nm, uid.shape)
        assert np.array_equal(np.unique(uid), np.arange(uid.max() + 1)), nm
        assert np.bincount(uid).min() >= 1, nm

    # C2: 8-gram 非重複（AX6 と同一閾値）
    ov = {lg: overlap8(z3[lg + "_ids"], zc[lg + "_ids"]) for lg in ("en", "ja")}
    c2_pass = bool(ov["en"] < 0.05 and ov["ja"] < 0.20)
    log("    overlap8 en %.6f ja %.6f  pass %s" % (ov["en"], ov["ja"], c2_pass))

    # C3 の分割側（文 ID の健全性）
    seen, no_cross = set(), True
    for w in range(nw):
        sw = set(np.unique(sent[w * n_eval:(w + 1) * n_eval]).tolist())
        if sw & seen:
            no_cross = False
        seen |= sw
    assert no_cross, "文が窓をまたいでいる"
    # 言語境界をまたがない単位か（smoke は en のみなのでスキップ）
    n_en_units = {}
    for nm, uid in parts.items():
        a = int(uid[:split_tok].max()) + 1
        n_en_units[nm] = a
        if split_tok < n_tok:
            assert int(uid[split_tok:].min()) >= a, (nm, a)
    log("    n_en_units sent %d / uni48 %d / uni340 %d"
        % (n_en_units["sent"], n_en_units["uni48"], n_en_units["uni340"]))

    c8 = za["c8"][:, sl].astype(np.float64)
    c7 = za["c7"][:, sl].astype(np.float64)
    base_ax6 = za["nll_base"][sl].astype(np.float64)
    u7_ax6 = za["nll_u7"][sl].astype(np.float64)
    REUSE = {nm: za["nll_" + nm][sl].astype(np.float64)
             for nm in ("uni48", "uni340", "tok12240", "rand340", "global1")}

    Y = {nm: unit_targets(c8, c7, uid, int(uid.max()) + 1)
         for nm, uid in parts.items()}
    DEC_ORACLE = {nm: unit_decision(Y[nm]) for nm in parts}

    if args.dry_run:
        # モデルをロードせず、分割・決定・予算会計だけを検証
        for nm, (cut, prot) in DEC_ORACLE.items():
            km = kmat_from_units(parts[nm], cut, prot, n_tok)
            assert km.shape == (N_LAYERS, n_tok)
            kmw = to_windows(km, nw, n_eval, ln)
            assert abs(float(kmw.mean()) - 7.0) < 1e-9, (nm, kmw.mean())
        log("    dry-run OK (no model, no forward): parts=%s" % list(parts))
        TEE.close()
        return

    # ---------------------------------------------------------------- モデル
    log("[2] load model")
    t0 = time.time()
    from transformers import AutoModelForCausalLM, AutoTokenizer
    AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    d_model = int(model.config.hidden_size)
    full_k = int(model.config.num_experts_per_tok)
    assert full_k == 8 and int(model.config.num_hidden_layers) == N_LAYERS
    gates = [l.mlp.gate for l in model.model.layers]
    gate_fwd = [g.forward for g in gates]
    log("    %.0f s  (%d windows)" % (time.time() - t0, nw))

    STATE = {"kmat": None}

    def make_masked(orig, li):
        def _patched(hidden_states):
            logits, scores, idx = orig(hidden_states)
            km = STATE["kmat"]
            if km is not None and scores.shape[-1] == full_k:
                kk = km[li]
                if kk.numel() == scores.shape[0]:
                    ar = torch.arange(scores.shape[-1], device=scores.device, dtype=torch.float32)
                    scores = scores * (ar[None, :] < kk[:, None]).to(scores.dtype)
            return logits, scores, idx
        return _patched

    for i, g in enumerate(gates):
        g.forward = make_masked(gate_fwd[i], i)

    # AX4 と同一の capture hook
    CAP = {"on": False, "g": None, "h": None}

    def gate_hook(li):
        def fn(module, inp, out):
            if CAP["on"]:
                CAP["g"][li] = out[0].detach().float().cpu()
        return fn

    def mlp_hook(s):
        def fn(module, inp, out):
            if CAP["on"]:
                CAP["h"][s] = inp[0].detach().float().cpu()[0]
        return fn

    for i, g in enumerate(gates):
        g.register_forward_hook(gate_hook(i))
    for s in H_STRATA:
        model.model.layers[s].mlp.register_forward_hook(mlp_hook(s))
    Rs = {s: torch.from_numpy(randproj(d_model, 256, seed=100 + s)) for s in H_STRATA}

    cache_dir = os.path.join(HERE, "_ax8_cache_%s" % tag)
    os.makedirs(cache_dir, exist_ok=True)

    def run_eval(name, native_topks=None, capture=False, kmat_windows=None):
        cf = os.path.join(cache_dir, name + ".npz")
        if os.path.exists(cf):
            c = np.load(cf)
            log("    %-16s CACHED CE %.5f" % (name, float(c["nll"].mean())))
            r = {"nll": c["nll"], "acc1": c["acc1"]}
            if capture:
                r.update({"G": c["G"], "H": c["H"], "ent": c["ent"]})
            return r
        t1 = time.time()
        if kmat_windows is not None:
            for g in gates:
                g.top_k = full_k
        else:
            STATE["kmat"] = None
            tk = full_k if native_topks is None else native_topks
            for i, g in enumerate(gates):
                g.top_k = int(tk[i] if not np.isscalar(tk) else tk)
        nll_c, a1_c, ent_c = [], [], []
        capG = [None] * N_LAYERS
        capH = {s: None for s in H_STRATA}
        G_big = np.zeros((N_LAYERS, n_tok, 64), dtype=np.float32) if capture else None
        H_big = np.zeros((len(H_STRATA), n_tok, 256), dtype=np.float32) if capture else None
        CAP["on"] = capture
        CAP["g"], CAP["h"] = capG, capH
        with torch.no_grad():
            for wi, (lg, ids) in enumerate(seqs):
                if kmat_windows is not None:
                    STATE["kmat"] = torch.from_numpy(
                        kmat_windows[:, wi * ln:(wi + 1) * ln].astype(np.float32)
                    ).to(model.device)
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                logit = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(logit, tgt, reduction="none")
                true_l = logit.gather(1, tgt.unsqueeze(-1))
                a1_c.append(((logit > true_l).sum(-1) == 0).float().cpu().numpy())
                nll_c.append(nll.cpu().numpy())
                if capture:
                    p = torch.softmax(logit, dim=-1)
                    ent_c.append(-(p * torch.log(p + 1e-12)).sum(-1).cpu().numpy())
                    ssl = slice(wi * n_eval, (wi + 1) * n_eval)
                    for i in range(N_LAYERS):
                        G_big[i, ssl] = capG[i].numpy()[:n_eval]
                    for si, s in enumerate(H_STRATA):
                        H_big[si, ssl] = capH[s].numpy()[:n_eval] @ Rs[s].numpy()
                del out, logit
        STATE["kmat"] = None
        CAP["on"] = False
        nll = np.concatenate(nll_c).astype(np.float32)
        a1 = np.concatenate(a1_c).astype(np.float32)
        r = {"nll": nll, "acc1": a1}
        if capture:
            r.update({"G": G_big, "H": H_big, "ent": np.concatenate(ent_c)})
        save = {"nll": nll, "acc1": a1}
        if capture:
            save.update({"G": G_big, "H": H_big, "ent": r["ent"]})
        np.savez_compressed(cf, **save)
        log("    %-16s CE %.5f  top1 %.4f  (%.0f s)"
            % (name, nll.mean(), a1.mean(), time.time() - t1))
        return r

    # ---------------------------------------------------------------- 校正 forward
    log("[3] calibration forwards")
    r_base = run_eval("base_cap", native_topks=[full_k] * N_LAYERS, capture=True)
    r_u7 = run_eval("u7_rep", native_topks=[7] * N_LAYERS)
    c1 = {"base_maxdiff": float(np.abs(r_base["nll"].astype(np.float64) - base_ax6).max()),
          "u7_maxdiff": float(np.abs(r_u7["nll"].astype(np.float64) - u7_ax6).max()),
          "scope": "smoke_en6" if args.smoke else "full_48"}
    c1["tier"] = "A" if (c1["base_maxdiff"] == 0.0 and c1["u7_maxdiff"] == 0.0) else "B"
    log("    C1 %s  base %.3e  u7 %.3e  scope %s"
        % (c1["tier"], c1["base_maxdiff"], c1["u7_maxdiff"], c1["scope"]))
    assert c1["tier"] == "A", "C1 FAIL: 保存 NLL と本次 forward のコーパスが不一致"

    # ---------------------------------------------------------------- 124 列特徴 S
    log("[4] unit features / probes")
    G_big, ent = r_base["G"], r_base["ent"].astype(np.float64)
    nll_b = r_base["nll"].astype(np.float64)
    a1_b = r_base["acc1"].astype(np.float64)

    def make_S(uid, nm):
        n_unit = int(uid.max()) + 1
        cnt = np.bincount(uid, minlength=n_unit).astype(np.float64)
        cols = []
        for L in range(N_LAYERS):
            gs = gate_stats(G_big[L]).astype(np.float64)
            cols.append(np.stack([np.bincount(uid, weights=gs[:, j], minlength=n_unit) / cnt
                                  for j in range(7)], axis=1))
        S_gstat = np.concatenate(cols, axis=1)
        S_stat = []
        for u in range(n_unit):
            m = (uid == u)
            nb, eb, ab = nll_b[m], ent[m], a1_b[m]
            S_stat.append([nb.mean(), nb.std(), np.percentile(nb, 90), nb.max(), np.median(nb),
                           eb.mean(), eb.std(), ab.mean(), ab.std(),
                           float(np.abs(np.diff(nb)).mean()) if nb.size > 1 else 0.0])
        S_stat = np.array(S_stat)
        a = n_en_units[nm]
        S_pos = np.stack([np.arange(n_unit) % max(1, a),
                          np.concatenate([np.zeros(a), np.ones(n_unit - a)])], axis=1)
        S = np.concatenate([S_gstat, S_stat, S_pos], axis=1)
        assert S.shape[1] == 124, S.shape
        return S

    probe_dec, probe_quality, S_all, pred_all = {}, {}, {}, {}
    for nm in ("uni48", "sent", "uni340"):
        t1 = time.time()
        uid = parts[nm]
        S = make_S(uid, nm)
        pred = ridge_loo(S, Y[nm])
        probe_dec[nm] = unit_decision(pred)
        S_all[nm], pred_all[nm] = S, pred
        probe_quality[nm] = {
            "n_unit": int(Y[nm].shape[0]),
            "r2": 1.0 - float(((Y[nm] - pred) ** 2).sum()
                              / ((Y[nm] - Y[nm].mean(0)) ** 2).sum()),
            "max_abs_rho": safe_max_abs_rho(Y[nm], pred),
        }
        log("    %-10s S %s  R2 %+.4f  rho %.4f  (%.0f s)"
            % (nm, S.shape, probe_quality[nm]["r2"],
               probe_quality[nm]["max_abs_rho"], time.time() - t1))

    # C7: permutation（記録のみ・合否なし）
    log("    C7 permutation (%d)" % NPERM)
    rng = np.random.RandomState(PERM_SEED)
    null = []
    S_sent, Y_sent = S_all["sent"], Y["sent"]
    for it in range(NPERM):
        p = rng.permutation(Y_sent.shape[0])
        Yp = Y_sent[p]
        pr = ridge_loo(S_sent, Yp)
        null.append(safe_max_abs_rho(Yp, pr))
        if (it + 1) % 25 == 0:
            log("      perm %d/%d" % (it + 1, NPERM))
    null = np.array(null)
    c7cal = {"observed_statistic": "max_j abs(Spearman(Y_sent[:,j], pred_loo[:,j]))",
          "observed": probe_quality["sent"]["max_abs_rho"],
          "n_perm": NPERM, "null_mean": float(null.mean()),
          "null_p95": float(np.percentile(null, 95)), "null_max": float(null.max()),
          "judgement": "record_only"}

    # ---------------------------------------------------------------- 腕
    log("[5] arms")
    rng_r = np.random.RandomState(RAND_SEED)
    n_s = Y["sent"].shape[0]
    cut_r = rng_r.randint(0, N_LAYERS, size=n_s).astype(np.int8)
    draw = rng_r.randint(0, N_LAYERS - 1, size=n_s)
    prot_r = (draw + (draw >= cut_r)).astype(np.int8)
    assert (cut_r != prot_r).all()

    def km_of(nm, cut, prot):
        return to_windows(kmat_from_units(parts[nm], cut, prot, n_tok), nw, n_eval, ln, 7)

    c_s, p_s = DEC_ORACLE["sent"]
    arms = [("sent_oracle", km_of("sent", c_s, p_s)),
            ("sent_random", km_of("sent", cut_r, prot_r)),
            ("sent_probe", km_of("sent", *probe_dec["sent"])),
            ("uni48_probe", km_of("uni48", *probe_dec["uni48"])),
            ("uni340_probe", km_of("uni340", *probe_dec["uni340"]))]
    for nm, km in arms:
        assert abs(float(km.mean()) - 7.0) < 1e-9, (nm, km.mean())

    N = {"base_cap": r_base["nll"].astype(np.float64),
         "u7_rep": r_u7["nll"].astype(np.float64)}
    for nm, km in arms:
        N[nm] = run_eval(nm, kmat_windows=km)["nll"].astype(np.float64)
    N.update({"uni48_oracle": REUSE["uni48"], "uni340_oracle": REUSE["uni340"],
              "tok_oracle": REUSE["tok12240"], "rand340_ax6": REUSE["rand340"],
              "global1_ax6": REUSE["global1"]})

    # ---------------------------------------------------------------- 統計
    log("[6] stats / calibration")
    u7 = N["u7_rep"]
    gains = {}
    for nm in ("sent_oracle", "sent_random", "sent_probe", "uni48_probe",
               "uni340_probe", "uni48_oracle", "uni340_oracle", "tok_oracle",
               "rand340_ax6", "global1_ax6"):
        gains[nm] = paired(u7 - N[nm], nw, n_eval)

    st1 = gains["sent_probe"]
    st2 = paired(N["sent_probe"] - N["sent_oracle"], nw, n_eval)
    ph = holm({"S1": st1["p_two"], "S2": st2["p_two"]})
    rej = {k: bool(ph[k] < ALPHA) for k in ph}
    eq = tost(st1, DELTA_TOST)
    if rej["S1"] and st1["mean"] > 0:
        case = "A"
    elif rej["S1"] and st1["mean"] < 0:
        case = "D"
    elif not rej["S1"] and rej["S2"]:
        case = "B"
    else:
        case = "C"

    # AX4 参照（独立標本・点推定のみ）
    z4 = np.load(AX4_NPZ)
    u4 = z4["nll_u7_rep"].astype(np.float64)
    ax4 = {"G_sent_probe": float((u4 - z4["nll_sent_probe"].astype(np.float64)).mean()),
           "G_sent_oracle": float((u4 - z4["nll_sent_oracle"].astype(np.float64)).mean()),
           "G_sent_random": float((u4 - z4["nll_sent_random"].astype(np.float64)).mean()),
           "gap": float((z4["nll_sent_probe"].astype(np.float64)
                         - z4["nll_sent_oracle"].astype(np.float64)).mean())}

    # 校正
    dec_all = {nm: DEC_ORACLE[nm] for nm in parts}
    dec_all.update({nm + "_probe": probe_dec[nm] for nm in probe_dec})
    dec_all["sent_random"] = (cut_r, prot_r)
    # 決定の再現先: oracle 腕は真の Y、probe 腕は LOO 予測、random 腕は対象外
    replay = {nm: Y[nm] for nm in parts}
    replay.update({nm + "_probe": pred_all[nm] for nm in probe_dec})
    c3 = {"decision_replay": {}, "mean_k": {}, "n_bad": 0}
    c4 = {"slots_per_token": 112, "n_bad": 0}
    c5 = {"conflicts": {}, "tie_min": 0}
    for nm, (cut, prot) in dec_all.items():
        base_nm = nm.replace("_probe", "").replace("_random", "")
        if nm in replay:
            rc, rp = unit_decision(replay[nm])
            ok = int(np.array_equal(cut, rc) and np.array_equal(prot, rp))
        else:
            ok = 1
        km = kmat_from_units(parts[base_nm], cut, prot, n_tok)
        c3["decision_replay"][nm] = ok
        c3["mean_k"][nm] = float(km.mean())
        c5["conflicts"][nm] = int((cut == prot).sum())
        if abs(float(km.mean()) - 7.0) >= 1e-9 or not ok:
            c3["n_bad"] += 1
        if not np.all(km.sum(0) == 112):
            c4["n_bad"] += 1
    c5["cut_hist_sent"] = np.bincount(c_s.astype(int), minlength=N_LAYERS).tolist()
    c6 = {"uniform": "u7_rep", "random": "sent_random", "oracle": "sent_oracle",
          "probe": "sent_probe",
          "random_gain": gains["sent_random"]["mean"],
          "oracle_gain": gains["sent_oracle"]["mean"],
          "probe_gain": gains["sent_probe"]["mean"],
          "random_le_oracle": bool(gains["sent_random"]["mean"]
                                   <= gains["sent_oracle"]["mean"])}
    calib = {"C1": c1,
             "C2": {"overlap_en": ov["en"], "overlap_ja": ov["ja"], "pass": c2_pass},
             "C3": {"sent_contiguity": True, "no_cross_window": bool(no_cross),
                    "n_sent": n_sent, "n_sent_en": n_sent_en,
                    "min_len_ok": bool(bstats["en"]["min_len"] >= MIN_SENT),
                    **c3},
             "C4": c4, "C5": c5, "C6": c6, "C7": c7cal}

    out = {
        "meta": {"tag": tag, "smoke": bool(args.smoke), "windows": nw, "len": ln,
                 "n_tok": int(n_tok), "n_new_forwards": 7, "n_sent": n_sent,
                 "seed_rand": RAND_SEED, "seed_perm": PERM_SEED, "lam": LAM,
                 "delta_tost": DELTA_TOST, "design": DESIGN},
        "confirmatory": {"S1_probe": st1, "S2_gap": st2, "holm": ph,
                         "reject": rej, "tost": eq, "case": case},
        "calib": calib, "gains": gains,
        "exploratory": {
            "sentence_stats": bstats,
            "probe_quality": probe_quality,
            "feasible_curve": {nm: gains[nm]["mean"] for nm in
                               ("uni48_probe", "sent_probe", "uni340_probe")},
            "oracle_curve": {nm: gains[nm]["mean"] for nm in
                             ("uni48_oracle", "sent_oracle", "uni340_oracle", "tok_oracle")},
            "ax4_reference": ax4,
            "boundary_probe_diff": gains["sent_probe"]["mean"] - gains["uni340_probe"]["mean"],
            "granularity_probe_diff": gains["sent_probe"]["mean"] - gains["uni48_probe"]["mean"],
        },
    }
    bad = assert_finite(out)
    assert not bad, "非有限値が JSON に混入: %s" % bad[:8]

    log("[7] save")
    with open(os.path.join(HERE, "%s_feasible_probe.json" % tag), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2, allow_nan=False)
    save = {("nll_" + k): v for k, v in N.items()}
    save.update({"c8": c8, "c7": c7, "sent": sent})
    for nm in parts:
        save["Y_" + nm] = Y[nm]
    for nm in pred_all:
        save["S_" + nm] = S_all[nm]
        save["pred_" + nm] = pred_all[nm]
    for nm, uid in parts.items():
        save["uid_" + nm] = uid
    for nm, (cut, prot) in dec_all.items():
        save["cut_" + nm], save["prot_" + nm] = cut, prot
    for k, v in save.items():
        assert isinstance(v, np.ndarray) and v.dtype.kind in "fiu", \
            "npz に非数値が混入: %s (%s)" % (k, type(v))
    np.savez_compressed(os.path.join(HERE, "%s_feasible_probe.npz" % tag), **save)

    log("")
    log("== confirmatory (Holm m=2, alpha=%.2f) ==" % ALPHA)
    log("S1 G_sent_probe  %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
        % (st1["mean"], st1["t"], st1["p_two"], ph["S1"], st1["mde"]))
    log("S2 gap           %+.8f  t %+.4f  p %.6g  holm %.6g  MDE %.8f"
        % (st2["mean"], st2["t"], st2["p_two"], ph["S2"], st2["mde"]))
    log("TOST delta %.3f  p_tost %.6g  equivalent %s" % (DELTA_TOST, eq["p_tost"], eq["equivalent"]))
    log("case = %s   (AX4 G_sent_probe %+.8f / gap %+.8f)"
        % (case, ax4["G_sent_probe"], ax4["gap"]))
    log("feasible: uni48 %+.8f  sent %+.8f  uni340 %+.8f"
        % (gains["uni48_probe"]["mean"], gains["sent_probe"]["mean"],
           gains["uni340_probe"]["mean"]))
    log("calib C1 %s (%s)  C2 %s  C3 bad %d  C4 bad %d  C6 %s  C7 p95 %.4f"
        % (c1["tier"], c1["scope"], c2_pass, c3["n_bad"], c4["n_bad"],
           c6["random_le_oracle"], c7cal["null_p95"]))
    log("saved: %s_feasible_probe.npz / .json  (non-finite check OK)" % tag)
    TEE.close()
    os._exit(0)


if __name__ == "__main__":
    main()
