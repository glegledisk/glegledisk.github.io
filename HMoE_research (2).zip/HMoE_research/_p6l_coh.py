import numpy as np, math
z = np.load("p6k_head_proj.npz", allow_pickle=True)
C = ["f6b8","f6b8_rs","f8b6","f8b6_rs"]
print("%-9s %10s %10s %10s %10s %10s" % ("cond","E[dl]","E|dl|","sd(dl)","t(vs0)","coherence"))
for c in C:
    d = z["%s_dlogit" % c].astype(float)
    n = d.size; se = d.std(ddof=1)/math.sqrt(n)
    print("%-9s %+10.4f %10.4f %10.4f %+10.2f %10.3f"
          % (c, d.mean(), np.abs(d).mean(), d.std(ddof=1), d.mean()/se,
             d.mean()/np.abs(d).mean()))
print()
print("符号の一致率（base top-1 の logit が上がった割合）:")
for c in C:
    d = z["%s_dlogit" % c].astype(float)
    print("  %-9s %.3f" % (c, (d > 0).mean()))
print()
print("|dh| と E|dl| の比（= a1 * ||w|| 相当）:")
for c in C:
    dh = z["%s_dh_norm" % c].astype(float); d = np.abs(z["%s_dlogit" % c].astype(float))
    print("  %-9s |dh|=%.3f  E|dl|=%.4f  E|dl|/|dh|=%.5f" % (c, dh.mean(), d.mean(), d.mean()/dh.mean()))