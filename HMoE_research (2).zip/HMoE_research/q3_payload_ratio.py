#!/usr/bin/env python3
"""Q3: payload 率の直接操作（80% → 67% → 50% → 33%）— 頻度仮説の直接検証。

背景: Q1 は「トレースでは難しい payload が小さい expert に送られる」ことを見つけ、機構を
「payload が 80% の多数派で、p_pen が幅に比例するから多数派を細く寄せる」と読んだ。
Q2 は難度を上げても Δ が負に転じないことを示し、残件として「payload 率そのものを動かす」
（Q2 §7-5）を挙げた。本スクリプトがそれ。

設計: **計算を一切変えず、struct トークンの数だけを変える。**
  1 命令 = [op] + ['#' x (T_STRUCT-2)] + ['='] + 値 8 桁
  - 値の計算（A/S/D の固定プログラム、mod 10^8、初期値は一様乱数）は全条件で同一
  - T_STRUCT = 2 / 4 / 8 / 16  →  payload 率 = 8/(8+T_STRUCT) = 80 / 67 / 50 / 33%
  - '#' は位置で決まる定数（エントロピーゼロ）なので、純粋な「頻度」の操作になる
  - '=' は常に値の直前に置く（payload 周辺の局所構造を全条件で揃える）

  交絡（明記）: T_STRUCT を増やすと「直前の値ブロックまでの距離」が伸びる（10 → 24 トークン）。
  これは課題を**難しくする**方向で、Q2 によれば難度は Δ を**上げる**。したがって
  「Δ が下がる」観測は交絡に逆らった証拠になる（「Δ が上がる」場合は解釈不能）。

事前登録:
  P1（操作チェック）: payload の acc / CE は 4 条件でほぼ一定（計算は同一なので）
  P2（主予測）: payload 率が下がると small_payload ↓ / small_struct ↑ → Δ ↓、50% 付近で 0 を跨ぎ、
     33% で負に転じる
  P3（副次）: payload 率が下がると payload の平均幅は広がる（幅を買えるようになる）
  Kill 条件: 33% でも Δ > +0.3 なら頻度仮説は反証（別の機構が支配している）

出力: simulation_hmoe_mmlu/data/q3/H+LB_ts{T}_s{seed}.json / q3_results.json / summary_q3.csv
"""
import argparse
import csv
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, E2DIR)
from e2b_rewrite_routing_fixed import RewriteMoE, Adam, WIDTHS  # noqa: E402
import e2b_rewrite_routing_fixed as E2  # noqa: E402

E2.SEQ = 256          # T_STRUCT=16 で T=153 になるため

OUTDIR = os.path.join(E2DIR, "data", "q3")

# ---------------------------------------------------------------------------
# 語彙とタスク
# ---------------------------------------------------------------------------
DIG = "0123456789"
OPS = "ASD"
VOCAB = DIG + OPS + "=:#"          # 16 文字（モデル側の埋め込みは 29 なので収まる）
C2I = {c: i for i, c in enumerate(VOCAB)}
ID_A, ID_S, ID_D = C2I["A"], C2I["S"], C2I["D"]
ID_EQ, ID_SEP, ID_PAD = C2I["="], C2I[":"], C2I["#"]

P_STEPS = 6
N_DIG = 8
MOD = 10 ** N_DIG
FIXED_OPS = "ADADSD"
assert len(FIXED_OPS) == P_STEPS

TYP_INPUT, TYP_STRUCT, TYP_PAYLOAD = 0, 1, 2

# configure() で設定する（T_STRUCT ごとに変わる）
T_STRUCT = 2
TPI = T_STRUCT + N_DIG
T_LEN = N_DIG + 1 + TPI * P_STEPS
TRACE0 = N_DIG + 1


def configure(t_struct):
    global T_STRUCT, TPI, T_LEN, TRACE0
    T_STRUCT = int(t_struct)
    assert T_STRUCT >= 2, "op と '=' で最低 2 トークン要る"
    TPI = T_STRUCT + N_DIG
    T_LEN = N_DIG + 1 + TPI * P_STEPS
    TRACE0 = N_DIG + 1
    return T_LEN


def payload_frac(t_struct):
    return N_DIG / (N_DIG + t_struct)


def apply_op(v, op_code):
    """op_code: 0=A(+1) 1=S(-1) 2=D(x2)"""
    return np.where(op_code == 0, v + 1,
                    np.where(op_code == 1, v - 1, v * 2)) % MOD


def make_trace_batch(rng, n, p_steps=P_STEPS):
    """-> seq (n,T), typ (n,T)

    1 命令 = [op] + ['#' x (T_STRUCT-2)] + ['='] + 値 8 桁。
    計算は T_STRUCT に依存しない（頻度だけを動かす）。
    """
    T = N_DIG + 1 + TPI * p_steps
    v0 = rng.integers(0, MOD, size=n).astype(np.int64)
    v = v0.copy()
    seq = np.zeros((n, T), dtype=np.int64)
    typ = np.zeros((n, T), dtype=np.int64)

    for k in range(N_DIG):
        seq[:, k] = (v0 // (10 ** (N_DIG - 1 - k))) % 10
    seq[:, N_DIG] = ID_SEP

    for s in range(p_steps):
        base = N_DIG + 1 + TPI * s
        op = OPS.index(FIXED_OPS[s])
        seq[:, base] = op + ID_A
        typ[:, base] = TYP_STRUCT
        for j in range(1, T_STRUCT - 1):
            seq[:, base + j] = ID_PAD
            typ[:, base + j] = TYP_STRUCT
        seq[:, base + T_STRUCT - 1] = ID_EQ
        typ[:, base + T_STRUCT - 1] = TYP_STRUCT
        v = apply_op(v, op)
        for k in range(N_DIG):
            seq[:, base + T_STRUCT + k] = (v // (10 ** (N_DIG - 1 - k))) % 10
            typ[:, base + T_STRUCT + k] = TYP_PAYLOAD
    return seq, typ


# ---------------------------------------------------------------------------
# forward（k を層ごとに変えられる / 許可 expert を絞れる）
# ---------------------------------------------------------------------------
def forward_q3(model, idx, k_by_layer=None, allow=None, need_idx=False):
    p = model.p
    B, T = idx.shape
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    idx_l = []
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
        if allow is not None:
            mask = torch.full_like(logits, float("-inf"))
            mask[:, list(allow)] = 0.0
            logits = logits + mask
        kl = model.k if k_by_layer is None else k_by_layer[l]
        topv, topi = logits.topk(kl, dim=1)
        gate = torch.softmax(
            torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
        y = torch.zeros_like(h)
        for i in range(model.E):
            tok, _ = (topi == i).nonzero(as_tuple=True)
            if tok.numel() == 0:
                continue
            x = h[tok]
            h1 = F.relu(F.linear(x, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
            y.index_add_(0, tok,
                         F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                         * gate[tok, i].unsqueeze(1))
        h = h + y
        if need_idx:
            idx_l.append(topi.reshape(B, T, -1))
    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, -1)
    return out, idx_l


def trace_loss(logits, seq):
    # 位置 t の logits は t+1 を予測する（Q1 の罠）。TRACE0 以降を当てるには t = TRACE0-1 .. T-2。
    lg = logits[:, TRACE0 - 1:-1, :len(VOCAB)].reshape(-1, len(VOCAB))
    tgt = torch.from_numpy(seq[:, TRACE0:]).reshape(-1)
    return F.cross_entropy(lg, tgt)


# ---------------------------------------------------------------------------
# 評価
# ---------------------------------------------------------------------------
SMALL = (0, 1)
LARGE = (6, 7)


@torch.no_grad()
def evaluate(model, seq, typ, conds, bs=128):
    n = seq.shape[0]
    dims = np.array(model.dims, dtype=np.float32)
    ntok = T_LEN - TRACE0
    res = {}
    for cname, (kbl, allow) in conds.items():
        ce = np.zeros((n, ntok), dtype=np.float32)
        hit = np.zeros((n, ntok), dtype=bool)
        wid = np.zeros((n, ntok), dtype=np.float32)
        top1_l = np.zeros((model.L, n, ntok), dtype=np.int64)
        wid_l = np.zeros((model.L, n, ntok), dtype=np.float32)
        for i in range(0, n, bs):
            s = slice(i, min(i + bs, n))
            x = torch.from_numpy(seq[s])
            logits, idx_l = forward_q3(model, x, k_by_layer=kbl, allow=allow, need_idx=True)
            lg = logits[:, TRACE0 - 1:-1, :len(VOCAB)]
            tgt = torch.from_numpy(seq[s, TRACE0:])
            lp = F.cross_entropy(lg.reshape(-1, len(VOCAB)), tgt.reshape(-1),
                                 reduction="none").reshape(-1, ntok)
            ce[s] = lp.numpy()
            hit[s] = (lg.argmax(-1).numpy() == tgt.numpy())
            for l, ti in enumerate(idx_l):
                # 位置 t のルーティングは t+1 を予測するときのもの → 種別も t+1 側に合わせる
                a = ti.numpy()[:, TRACE0 - 1:-1, :]
                wid_l[l][s] = dims[a].mean(-1)
                top1_l[l][s] = a[:, :, 0]
                wid[s] += dims[a].mean(-1) / model.L
        ty = typ[:, TRACE0:]
        m_st, m_pl = (ty == TYP_STRUCT), (ty == TYP_PAYLOAD)
        out = {
            "ce_all": float(ce.mean()),
            "ce_struct": float(ce[m_st].mean()),
            "ce_payload": float(ce[m_pl].mean()),
            "acc_struct": float(hit[m_st].mean()),
            "acc_payload": float(hit[m_pl].mean()),
            "width_struct": float(wid[m_st].mean()),
            "width_payload": float(wid[m_pl].mean()),
            "small_struct": float(np.isin(top1_l[-1][m_st], SMALL).mean()),
            "small_payload": float(np.isin(top1_l[-1][m_pl], SMALL).mean()),
            "width_struct_l": [float(wid_l[l][m_st].mean()) for l in range(model.L)],
            "width_payload_l": [float(wid_l[l][m_pl].mean()) for l in range(model.L)],
            "small_struct_l": [float(np.isin(top1_l[l][m_st], SMALL).mean())
                               for l in range(model.L)],
            "small_payload_l": [float(np.isin(top1_l[l][m_pl], SMALL).mean())
                                for l in range(model.L)],
            "usage_l0": np.bincount(top1_l[0].reshape(-1), minlength=model.E).tolist(),
        }
        hp = hit.reshape(n, P_STEPS, TPI)[:, :, T_STRUCT:]
        instr_ok = hp.all(-1)
        out["instr_valid"] = float(instr_ok.all(-1).mean())
        out["instr_acc"] = float(instr_ok.mean())
        out["payload_token_acc"] = float(hp.mean())
        first = np.where(~instr_ok, np.arange(P_STEPS)[None, :], 10 ** 6).min(-1)
        out["first_err_mean"] = float(np.where(first >= 10 ** 6, P_STEPS, first).mean())
        out["seq_valid"] = float((first >= 10 ** 6).mean())
        res[cname] = out
    return res


# ---------------------------------------------------------------------------
# 訓練
# ---------------------------------------------------------------------------
def run_arm(arm, seed, t_struct, n_seqs, epochs, bs, lr, auxw):
    T = configure(t_struct)
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)     # Q1/Q2 と同一の系列分布
    widths = WIDTHS[arm]
    aux_mode = "p_pen" if arm.startswith("H") else "switch"
    model = RewriteMoE(widths, seed=seed)
    opt = Adam(model.params(), lr=lr)
    nparam = sum(v.numel() for v in model.params().values())

    steps_per_ep = max(1, n_seqs // bs)
    t0 = time.time()
    hist = []
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps_per_ep):
            seq, _ = make_trace_batch(rng, bs)
            x = torch.from_numpy(seq)
            logits, aux, _ = model(x, aux_mode=aux_mode)
            loss = trace_loss(logits, seq) + auxw * aux
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        hist.append(run / steps_per_ep)
        print(f"    [{arm} ts{t_struct} s{seed}] ep{ep+1}/{epochs} loss={hist[-1]:.4f} "
              f"({time.time()-t0:.0f}s)", flush=True)

    ev_rng = np.random.default_rng(777)
    seq, typ = make_trace_batch(ev_rng, 1024)
    conds = {
        "base": (None, None),
        "k1": ([1] * model.L, None),
        "force_small": (None, SMALL),
    }
    ev = evaluate(model, seq, typ, conds)
    out = {"arm": arm, "seed": seed, "t_struct": t_struct, "T": T,
           "payload_frac": payload_frac(t_struct), "nparam": nparam,
           "loss_hist": hist, "n_eval": 1024, "sec": round(time.time() - t0, 1), "eval": ev}
    os.makedirs(OUTDIR, exist_ok=True)
    torch.save({k: v.detach() for k, v in model.params().items()},
               os.path.join(OUTDIR, f"ckpt_{arm}_ts{t_struct}_s{seed}.pt"))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", nargs="+", default=["H+LB"])
    ap.add_argument("--tstruct", nargs="+", type=int, default=[2, 4, 8, 16])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--auxw", type=float, default=0.05)
    ap.add_argument("--resume", action="store_true")
    args = ap.parse_args()

    os.makedirs(OUTDIR, exist_ok=True)
    torch.set_num_threads(6)
    print(f"N_DIG={N_DIG} P_STEPS={P_STEPS} prog={FIXED_OPS} "
          f"payload_frac={[round(payload_frac(t), 3) for t in args.tstruct]}", flush=True)

    rows = []
    for arm in args.arms:
        for ts in args.tstruct:
            for seed in args.seeds:
                p = os.path.join(OUTDIR, f"{arm}_ts{ts}_s{seed}.json")
                if args.resume and os.path.exists(p):
                    with open(p, encoding="utf-8") as f:
                        r = json.load(f)
                    if r.get("n_eval") == 1024:
                        print(f"  [skip] {arm} ts{ts} s{seed}", flush=True)
                        rows.append(r)
                        continue
                r = run_arm(arm, seed, ts, args.seqs, args.epochs, args.bs, args.lr, args.auxw)
                rows.append(r)
                e = r["eval"]["base"]
                print(f"  -> {arm} ts{ts} ({r['payload_frac']:.2f}) s{seed}: "
                      f"acc st/pl = {e['acc_struct']:.3f}/{e['acc_payload']:.3f} "
                      f"small st/pl = {e['small_struct']:.3f}/{e['small_payload']:.3f} "
                      f"Δ = {e['small_payload']-e['small_struct']:+.3f} "
                      f"width pl = {e['width_payload']:.1f}", flush=True)
                with open(p, "w", encoding="utf-8") as f:
                    json.dump(r, f, ensure_ascii=False, indent=2)

    with open(os.path.join(OUTDIR, "q3_results.json"), "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)

    keys = ["arm", "t_struct", "payload_frac", "seed", "ce_all", "ce_struct", "ce_payload",
            "acc_struct", "acc_payload", "width_struct", "width_payload",
            "small_struct", "small_payload", "instr_valid", "seq_valid", "sec"]
    with open(os.path.join(OUTDIR, "summary_q3.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            row = {k: r[k] for k in ("arm", "t_struct", "payload_frac", "seed", "sec")}
            row.update({k: r["eval"]["base"][k] for k in keys if k in r["eval"]["base"]})
            w.writerow(row)
    print(f"[write] {OUTDIR}", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
