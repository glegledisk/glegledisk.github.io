#!/usr/bin/env python3
"""A3 の図。data/a3/a3_analysis.json を読むだけ。"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

matplotlib.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "MS Gothic", "sans-serif"]
matplotlib.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a3")
J = json.load(open(os.path.join(D, "a3_analysis.json"), encoding="utf-8"))
A = J["aggregate"]
C = {(c["a"], c["b"], c["metric"]): c for c in J["contrasts"]}

PAIRS = [("relu_1x", "relu_15x", "ReLU", "#55a868"),
         ("relu2_1x", "relu2_15x", "ReLU²", "#c44e52"),
         ("swiglu_1x", "swiglu_15x", "SwiGLU", "#dd8452")]

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.0, 4.9),
                               gridspec_kw={"width_ratios": [1.2, 1]})

# --- (a) 幅 1x vs 1.5x の対 ---
xs = np.arange(len(PAIRS))
w = 0.34
for i, (a1, a15, name, col) in enumerate(PAIRS):
    v1, v15 = A[a1]["iv"], A[a15]["iv"]
    s1, s15 = A[a1]["iv_sd"], A[a15]["iv_sd"]
    ax1.bar(i - w / 2, v1, w, yerr=s1, capsize=3, color=col, alpha=0.45,
            edgecolor="black", linewidth=0.6, label="幅 1.0×" if i == 0 else None)
    ax1.bar(i + w / 2, v15, w, yerr=s15, capsize=3, color=col,
            edgecolor="black", linewidth=0.6, label="幅 1.5×" if i == 0 else None)
    ax1.annotate("", xy=(i + w / 2, v15 + 0.03), xytext=(i - w / 2, v1 + 0.03),
                 arrowprops=dict(arrowstyle="->", color="black", lw=1.2))
    ax1.text(i, max(v1, v15) + 0.09, f"{v15 - v1:+.3f}", ha="center", fontsize=10,
             fontweight="bold")
ax1.set_xticks(xs)
ax1.set_xticklabels([f"{n}\n({A[a]['nparam']/1e3:.0f}k→{A[b]['nparam']/1e3:.0f}k params)"
                     for a, b, n, _ in PAIRS], fontsize=9)
ax1.set_ylabel("instr_valid（平均 ± SD, n=6）")
ax1.set_title("(a) 幅 1.5 倍の効き方 — ReLU だけが応答する", fontsize=11)
ax1.legend(fontsize=9, loc="upper left")
ax1.grid(axis="y", alpha=0.3)
ax1.set_ylim(0, 0.85)

# --- (b) 分解 ---
wv = C[("relu2_15x", "relu2_1x", "instr_valid")]["mean"]
sv = -C[("relu2_1x", "swiglu_1x", "instr_valid")]["mean"]
tv = C[("relu2_15x", "swiglu_1x", "instr_valid")]["mean"]
labels = ["幅の得\n(relu²1.5x − relu²1x)", "3 行列との差\n(swiglu1x − relu²1x)",
          "残差\n(relu²1.5x − swiglu1x)"]
vals = [wv, sv, tv]
cols = ["#4c72b0", "#dd8452", "#c44e52"]
bars = ax2.bar(range(3), vals, color=cols, edgecolor="black", linewidth=0.6)
ax2.axhline(0, color="black", lw=1)
for b, v in zip(bars, vals):
    ax2.text(b.get_x() + b.get_width() / 2, v + (0.012 if v >= 0 else -0.022),
             f"{v:+.3f}", ha="center", fontsize=10, fontweight="bold")
ax2.set_xticks(range(3))
ax2.set_xticklabels(labels, fontsize=8)
ax2.set_ylabel("Δinstr_valid")
ax2.set_title("(b) 「幅で説明できる」なら残差が 0 になる", fontsize=11)
ax2.grid(axis="y", alpha=0.3)
ax2.set_ylim(-0.25, 0.25)

plt.tight_layout()
out = os.path.join(D, "a3_figure.png")
plt.savefig(out, dpi=150)
print(f"[write] {out}")
