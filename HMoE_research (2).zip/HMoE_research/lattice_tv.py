"""lattice_tv.py — Marginalize-It の近似誤差を GPU なしで測る

理論（このスクリプトの中心）:
  位置 j の prefix p について
    Z = Σ_{v: bytes(v) が p で始まる} p_T(v)
    T = Σ_{v: bytes(v) == p}          p_T(v)      ← prefix で「終端する」語の質量
    S_b = Σ_{v: bytes(v) が p+b で始まる} p_T(v)
  Marginalize-It のターゲット  q_MI(b) = S_b/(Z-T)
  End-Of-Token のターゲット     q_EOT(b) = S_b/Z,  q_EOT(<eot>) = T/Z
  => TV(q_EOT, q_MI) = T/Z   （厳密）

  TV の導出:
    Σ_b |S_b/Z - S_b/(Z-T)| = (Z-T)·T/(Z(Z-T)) = T/Z
    |T/Z - 0| = T/Z
    TV = 1/2 (T/Z + T/Z) = T/Z                                  ∎

  意味: 近似の大きさ = 「その prefix でトークンが終わる確率」。
  同じ prefix に対して「続く」未来と「終わる」未来が T:(Z-T) で分岐している量。
  Marginalize-It は片方の未来だけを条件にしたターゲットを作るので、
  同一 prefix に 2 つの異なるターゲットが割り当たる（＝ラベルの不整合）。

  教師分布 p_T は未知なので、コーパス単語頻度と一様分布の混合で近似する:
    p_λ(v) = (1-λ)·f(v)/N + λ/V
  λ は「語彙の未観測部分」の重み。λ=0 は最鋭、λ=1 は型一様（純構造）。

使い方:
  python lattice_tv.py --corpus . --out lattice_out
"""

import argparse
import bisect
import csv
import glob
import json
import os
from collections import Counter, defaultdict

os.environ["CUDA_VISIBLE_DEVICES"] = ""  # GPU は一切使わない


def bytes_to_unicode():
    bs = (list(range(ord("!"), ord("~") + 1))
          + list(range(ord("¡"), ord("¬") + 1))
          + list(range(ord("®"), ord("ÿ") + 1)))
    cs = bs[:]
    n = 0
    for b in range(256):
        if b not in bs:
            bs.append(b)
            cs.append(256 + n)
            n += 1
    return {chr(c): b for b, c in zip(bs, cs)}


UNI2BYTE = bytes_to_unicode()


def token_bytes(tok_str):
    out = bytearray()
    for ch in tok_str:
        b = UNI2BYTE.get(ch)
        if b is None:
            return None
        out.append(b)
    return bytes(out)


class Lattice:
    def __init__(self, tokenizer_json):
        from tokenizers import Tokenizer
        self.tk = Tokenizer.from_file(tokenizer_json)
        pairs = []
        for s, i in self.tk.get_vocab().items():
            b = token_bytes(s)
            if b:
                pairs.append((b, i))
        pairs.sort()
        self.keys = [p[0] for p in pairs]
        self.ids = [p[1] for p in pairs]
        self.pos = {b: k for k, (b, _) in enumerate(pairs)}
        self.maxlen = max(len(b) for b in self.keys)
        self.n_vocab = len(self.keys)
        self.id2bytes = {i: b for b, i in pairs}
        self._cache = {}

    def build(self, freq_counts):
        """counts: dict id->count。累積和（質量）と型数を作る。"""
        n = self.n_vocab
        cum = [0] * (n + 1)
        cumt = [0] * (n + 1)
        for k, i in enumerate(self.ids):
            cum[k + 1] = cum[k] + freq_counts.get(i, 0)
            cumt[k + 1] = cumt[k] + 1
        self.cum, self.cumt = cum, cumt
        self._cache = {}
        return cum[-1]

    def TZ(self, p):
        hit = self._cache.get(p)
        if hit is not None:
            return hit
        lo = bisect.bisect_left(self.keys, p)
        hi = bisect.bisect_left(self.keys, p + b"\xff" * (self.maxlen + 1))
        Zc = self.cum[hi] - self.cum[lo]
        Zt = self.cumt[hi] - self.cumt[lo]
        k = self.pos.get(p)
        Tc = (self.cum[k + 1] - self.cum[k]) if k is not None else 0
        Tt = 1 if k is not None else 0
        self._cache[p] = (Tc, Zc, Tt, Zt)
        return self._cache[p]

    def encode(self, text):
        return self.tk.encode(text, add_special_tokens=False).ids


def tv_lambda(Tc, Zc, Tt, Zt, N, V, lam):
    """p_λ = (1-λ)·f/N + λ/V の下での T/Z。"""
    T = (1 - lam) * Tc / N + lam * Tt / V
    Z = (1 - lam) * Zc / N + lam * Zt / V
    return T / Z if Z > 0 else 0.0


def analyse(lat, ids, N, lams, label, out_csv):
    V = lat.n_vocab
    acc = {l: 0.0 for l in lams}
    by_j = defaultdict(lambda: [0.0, 0])   # j -> [sum TV(λ=0), count]
    n_pos = n_amb = tot_bytes = 0
    hist = Counter()

    for tid in ids:
        b = lat.id2bytes.get(tid)
        if not b:
            continue
        m = len(b)
        tot_bytes += m
        for j in range(1, m):
            Tc, Zc, Tt, Zt = lat.TZ(b[:j])
            n_pos += 1
            if Tc > 0:
                n_amb += 1
            for l in lams:
                acc[l] += tv_lambda(Tc, Zc, Tt, Zt, N, V, l)
            tv0 = tv_lambda(Tc, Zc, Tt, Zt, N, V, 0.0)
            by_j[j][0] += tv0
            by_j[j][1] += 1
            hist[min(9, int(tv0 * 10))] += 1

    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["j", "count", "mean_TV_lam0", "frac_positions_ge_j"])
        for j in sorted(by_j):
            w.writerow([j, by_j[j][1], round(by_j[j][0] / by_j[j][1], 5),
                        round(by_j[j][1] / n_pos, 5)])

    s = {"label": label, "n_tokens": len(ids), "n_positions": n_pos,
         "bytes_per_token": round(tot_bytes / max(1, len(ids)), 3),
         "frac_positions_with_T_gt_0": round(n_amb / max(1, n_pos), 4)}
    for l in lams:
        s[f"meanTV_lam{l}"] = round(acc[l] / max(1, n_pos), 4)
    s["hist_lam0"] = {f"{i/10:.1f}-{(i+1)/10:.1f}": hist[i] for i in range(10) if hist[i]}
    return s


def selftest():
    p = {"isu": 0.5, "isk": 0.125, "is": 0.125}
    Z, T = sum(p.values()), p["is"]
    q_eot = {"u": 0.5 / Z, "k": 0.125 / Z, "<eot>": T / Z}
    q_mi = {"u": 0.5 / (Z - T), "k": 0.125 / (Z - T)}
    tv_direct = 0.5 * (abs(q_eot["u"] - q_mi["u"]) + abs(q_eot["k"] - q_mi["k"]) + q_eot["<eot>"])
    print(f"[selftest] T/Z={T/Z:.4f}  TV(direct)={tv_direct:.4f}  "
          f"q_EOT={ {k: round(v,3) for k,v in q_eot.items()} }  q_MI={ {k: round(v,3) for k,v in q_mi.items()} }")
    assert abs(T / Z - tv_direct) < 1e-12 and abs(T / Z - 1 / 6) < 1e-12
    print("[selftest] OK (論文の Tiramisu 例と一致)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--corpus", default=".")
    ap.add_argument("--out", default="lattice_out")
    args = ap.parse_args()

    selftest()
    os.makedirs(args.out, exist_ok=True)

    files = glob.glob(os.path.join(args.corpus, "**", "*.md"), recursive=True)
    en, ja = [], []
    for f in files:
        t = open(f, encoding="utf-8", errors="ignore").read()
        (en if os.sep + "english_version" + os.sep in f else ja).append(t)
    corpora = {"en": "\n".join(en), "ja": "\n".join(ja)}
    for k, v in corpora.items():
        print(f"[corpus] {k}: {len(v):,} chars")

    toks = {"llama3_128k": "llama3.json", "olmo2_100k": "olmo2.json", "qwen3_152k": "qwen3.json"}
    lams = [0.0, 0.1, 0.25, 1.0]
    rows = []
    for name, fn in toks.items():
        path = os.path.join("tok_cache", fn)
        if not os.path.exists(path):
            print(f"[skip] {name}")
            continue
        lat = Lattice(path)
        print(f"\n=== {name}: vocab={lat.n_vocab} ===")
        for lang, text in corpora.items():
            ids = lat.encode(text)
            N = lat.build(Counter(ids))
            s = analyse(lat, ids, N, lams, f"{name}/{lang}",
                        os.path.join(args.out, f"{name}_{lang}.csv"))
            rows.append(s)
            print(json.dumps(s, ensure_ascii=False))

    if rows:
        keys = []
        for r in rows:
            for k in r:
                if k not in keys:
                    keys.append(k)
        with open(os.path.join(args.out, "summary.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            for r in rows:
                w.writerow({k: json.dumps(r[k], ensure_ascii=False) if k == "hist_lam0" else r.get(k, "") for k in keys})
        print(f"\n[saved] {args.out}/summary.csv")


if __name__ == "__main__":
    main()
