# -*- coding: utf-8 -*-
"""_ax6_freeze.py — AX6 用の別コーパスを凍結する（走行前に 1 回だけ実行）。

設計書: AX6課題設計書_別コーパスでper-token限界コストを測り直しlog-N対比が再現するかを検証する_20261112.md

en: data_searchtome/*_corpus.jsonl の 6 ドメインから、AX3 が使った先頭 1024
    トークンではなく **オフセット 2048 から 1024 トークン** を取る。
ja: root *.md の sorted glob で **start = 120000**（AX3 は 20000）。

AX3 / AX4 / AX5 の corpus_ids_ax3_w24_l256.npz は一切書き換えない。
独立性は位置ではなく ID 列の共通 8-gram で判定する（glob が増減するため）。

出力: corpus_ids_ax6_w24_l256.npz (en_ids / ja_ids / meta)
"""
import glob
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from _freeze_corpus import load_corpus as load_corpus_ax2  # noqa: E402

WIN, LEN = 24, 256
EN_OFFSET = 2048
JA_START = 120000
DOMAINS = ("education", "finance", "law", "medicine", "natural_sciences", "social_sciences")
OUT = os.path.join(HERE, "corpus_ids_ax6_w24_l256.npz")
AX3 = os.path.join(HERE, "corpus_ids_ax3_w24_l256.npz")


def grams8(x):
    return set(tuple(int(v) for v in x[i:i + 8]) for i in range(len(x) - 7))


def overlap8(a, b):
    gb = grams8(b)
    return float(np.mean([tuple(int(v) for v in a[i:i + 8]) in gb
                         for i in range(len(a) - 7)]))


def main():
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(os.path.join(HERE, "models", "olmoe-1b-7b"))
    need = WIN * LEN
    en_parts, used = [], {}
    for dom in DOMAINS:
        f = os.path.join(HERE, "data_searchtome", "%s_corpus.jsonl" % dom)
        texts = []
        with open(f, encoding="utf-8", errors="replace") as fp:
            for line in fp:
                line = line.strip()
                if not line:
                    continue
                c = json.loads(line).get("content")
                if isinstance(c, str) and c:
                    texts.append(c)
        ids = tok("\n\n".join(texts), return_tensors="pt",
                  add_special_tokens=False).input_ids[0]
        take = 4 * LEN
        if ids.numel() < EN_OFFSET + take:
            raise RuntimeError("domain too short: %s (%d)" % (dom, ids.numel()))
        en_parts.append(ids[EN_OFFSET:EN_OFFSET + take].numpy().astype(np.int32))
        used[dom] = {"file": os.path.basename(f), "n_records": len(texts),
                     "tokens": int(ids.numel()), "offset": EN_OFFSET, "take": int(take)}
        print("en %-20s tokens %7d  offset %d  take %d"
              % (dom, ids.numel(), EN_OFFSET, take))
    en_ids = np.concatenate(en_parts)
    assert en_ids.size == need

    ja_all = tok(load_corpus_ax2("ja", 400000), return_tensors="pt",
                 add_special_tokens=False).input_ids[0]
    if ja_all.numel() < JA_START + need:
        raise RuntimeError("ja corpus too short: %d" % ja_all.numel())
    ja_ids = ja_all[JA_START:JA_START + need].numpy().astype(np.int32)
    print("ja corpus tokens %d  start %d  take %d" % (ja_all.numel(), JA_START, need))

    z3 = np.load(AX3, allow_pickle=True)
    ov = {lg: overlap8(z3[lg + "_ids"], en_ids if lg == "en" else ja_ids)
          for lg in ("en", "ja")}
    print("8-gram overlap with AX3: en %.6f  ja %.6f" % (ov["en"], ov["ja"]))
    assert ov["en"] < 0.05 and ov["ja"] < 0.20, ov

    meta = {
        "name": "AX6 independent corpus", "created": "2026-11-12",
        "windows": WIN, "len": LEN, "n_per_lang": need,
        "en": {"source": "data_searchtome/*_corpus.jsonl", "offset": EN_OFFSET,
               "domains": used, "note": "AX3 は先頭 0、AX6 はオフセット 2048"},
        "ja": {"source": "root *.md glob (_freeze_corpus.load_corpus)",
               "start": JA_START, "corpus_tokens": int(ja_all.numel()),
               "note": "AX3 は start 20000。位置の対応は保証しない"},
        "overlap8_with_ax3": ov,
    }
    np.savez_compressed(OUT, en_ids=en_ids, ja_ids=ja_ids,
                        meta=np.array([json.dumps(meta, ensure_ascii=False)]))
    print("saved %s  en %d / ja %d" % (os.path.basename(OUT), en_ids.size, ja_ids.size))


if __name__ == "__main__":
    main()
