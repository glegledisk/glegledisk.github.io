# -*- coding: utf-8 -*-
"""_fix_emph.py — レンダリング後に ** が残るファイルを機械的に修復する。

方針: **「レンダリング後の ** の数が減る」編集だけを採用する**。
ソース上の見た目で判断すると、正しく動いている強調を壊す危険があるため、
必ず markdown-it で HTML にして数え、strict に減ったときだけ適用する。

触る候補は「前後 1 文字が空白か約物」の ** だけ（そこが崩れる場所）。
  - 直後の空白を削る（開き記号の直後の空白を消す）
  - 直後に空白を入れる（閉じ括弧の直後の ** を閉じ記号にする）
  - 直前の空白を削る / 直前に入れる
"""
import os
import re
import sys
import unicodedata

from markdown_it import MarkdownIt

MD = MarkdownIt("commonmark").enable("table")
SP = " \u3000"


def is_punct(ch):
    """CommonMark の「約物」は Unicode の P* と S*。`%` `）` `」` `。` を含む。"""
    return bool(ch) and unicodedata.category(ch)[0] in ("P", "S")


def is_space(ch):
    return bool(ch) and (ch in SP or ch.isspace())


def count_lit(src):
    html = MD.render(src)
    body = re.sub(r"<pre>.*?</pre>", "", html, flags=re.S)
    body = re.sub(r"<code>.*?</code>", "", body, flags=re.S)
    return len(re.findall(r"\*\*", body))


def structure(src):
    """構造の指紋。編集でこれが変わったら採用しない（リストや表を壊した印）。"""
    html = MD.render(src)
    return (html.count("<li>"), html.count("<tr>"), html.count("<h1>"),
            html.count("<h2>"), html.count("<h3>"), html.count("<ol>"), html.count("<ul>"))


LIST_MARK = re.compile(r"(^|\n)[ \t]*(\d+\.|[-*+])[ \t]*$")


def candidates(src):
    """**前後 1 文字を触る**候補だけ。既知の 3 つの失敗パターンに限定する。

    (A) 開き記号の直後が空白: `** 1 箇所` → 空白を削る（リスト記号の直後は除く）
    (B) 閉じ記号の直前が約物: `」**である` → 直後に空白を入れる
    (C) 開き記号の直後が約物: `**「…」**` → 直前に空白を入れる
    """
    out = []
    for m in re.finditer(r"\*\*", src):
        i = m.start()
        j = i + 2
        prev = src[i - 1] if i > 0 else "\n"
        nxt = src[j] if j < len(src) else "\n"
        # (A) 直後が空白 → 開き記号が壊れている
        if is_space(nxt) and not LIST_MARK.search(src[:i]):
            out.append(src[:j] + src[j + 1:])
            continue
        # (B) 直前が約物・直後が文字 → 閉じ記号になれない
        if is_punct(prev) and nxt != "\n" and not is_space(nxt):
            out.append(src[:j] + " " + src[j:])
        # (C) 直後が約物・直前が文字 → 開き記号になれない
        if is_punct(nxt) and prev != "\n" and not is_space(prev):
            out.append(src[:i] + " " + src[i:])
    return out


def batch_insert(src):
    """約物境界の ** に空白を入れる。**開きと閉じを交互に判定**する。

    行ごとに `**` を順に見て、偶数番目を開き・奇数番目を閉じとみなす。
    （開きに「直後へ空白」を入れると開きが壊れるので、向きを取り違えないこと。
    最初の実装はこれで `（**強調**）` を壊した。）
    """
    edits = []
    for line_start, line in _iter_lines(src):
        k = 0
        for m in re.finditer(r"\*\*", line):
            i = line_start + m.start()
            j = i + 2
            prev = src[i - 1] if i > 0 else "\n"
            nxt = src[j] if j < len(src) else "\n"
            is_open = (k % 2 == 0)
            k += 1
            if is_open and is_punct(nxt) and prev != "\n" and not is_space(prev):
                edits.append(("before", i))
            elif (not is_open) and is_punct(prev) and nxt != "\n" and not is_space(nxt):
                edits.append(("after", i))
    s = src
    for kind, i in sorted(edits, key=lambda x: -x[1]):
        j = i + 2
        s = (s[:j] + " " + s[j:]) if kind == "after" else (s[:i] + " " + s[i:])
    return s


def _iter_lines(src):
    pos = 0
    for line in src.split("\n"):
        yield pos, line
        pos += len(line) + 1


def repair(src, max_iter=60):
    n0 = n = count_lit(src)
    st = structure(src)
    edits = 0
    for _ in range(max_iter):
        if n == 0:
            break
        best = None
        # 1 手で改善するならそれ
        for cand in candidates(src):
            if structure(cand) != st:      # 構造を壊す編集は捨てる
                continue
            m = count_lit(cand)
            if m < n and (best is None or m < best[0]):
                best = (m, cand)
        # 1 手では改善しない型（`**「…」**` は両側を直さないと成立しない）は 2 手で探す。
        # 候補が多いと組合せが爆発するので、少ないときだけ。
        if best is None:
            c1 = [c for c in candidates(src) if structure(c) == st]
            if len(c1) <= 8:
                for a in c1:
                    for b in candidates(a):
                        if structure(b) != st:
                            continue
                        m = count_lit(b)
                        if m < n and (best is None or m < best[0]):
                            best = (m, b)
        if best is None:
            bat = batch_insert(src)
            if structure(bat) == st and count_lit(bat) < n:
                best = (count_lit(bat), bat)
        if best is None:
            break
        n, src = best
        edits += 1
    return src, n0, n, edits


def main():
    apply = "--apply" in sys.argv
    paths = [a for a in sys.argv[1:] if not a.startswith("--")]
    fixed = partial = skipped = 0
    for p in paths:
        src = open(p, encoding="utf-8").read()
        if count_lit(src) == 0:
            skipped += 1
            continue
        new, n0, n, e = repair(src)
        if n == 0:
            fixed += 1
            status = "OK"
        elif n < n0:
            partial += 1
            status = f"部分 ({n0}->{n})"
        else:
            status = f"不可 ({n0})"
        print(f"  {status:14s} edits={e:2d}  {os.path.basename(p)}")
        if apply and n < n0:
            open(p, "w", encoding="utf-8", newline="\n").write(new)
    print(f"\n修復 {fixed} / 部分 {partial} / 変更不要 {skipped}"
          f"  ({'適用済み' if apply else 'dry-run'})")


if __name__ == "__main__":
    main()
