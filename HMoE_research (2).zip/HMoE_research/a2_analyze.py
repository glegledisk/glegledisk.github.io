#!/usr/bin/env python3
"""A2 の検算と集計。「sigmoid は質量介入である」を 3 つの角度から見る。

角度 1（構成的）: 正規化版どうしは**質量が厳密に同じ 1.0**。ここで差が出れば
                  「質量」ではなく「重みの形」の効果である。
角度 2（横断）  : 4 アームの Δ質量 と Δ較正ギャップ が対応するか。
角度 3（within）: 同一アーム内で、トークンごとの質量と確信度が相関するか。
                  質量が過信を作るなら r > 0 のはず（P6c の機構）。
"""
import argparse
import json
import math
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a2")
ORDER = ["sm_norm", "sig_norm", "sig_raw", "sm_raw"]

import sys
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "simulation_hmoe_mmlu"))
import q1_trace_routing as Q1                      # noqa: E402


def ece(conf, hit, n_bins=15):
    """期待較正誤差。ギャップ（平均差）より裾に敏感。"""
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    e, N = 0.0, conf.size
    for i in range(n_bins):
        lo, hi = edges[i], edges[i + 1]
        m = (conf >= lo) & ((conf < hi) if i < n_bins - 1 else (conf <= 1.0))
        if m.sum() == 0:
            continue
        e += (m.sum() / N) * abs(float(hit[m].mean()) - float(conf[m].mean()))
    return float(e)


def load():
    with open(os.path.join(D, "a2_results.json"), encoding="utf-8") as fh:
        rows = [r for r in json.load(fh) if "evals" in r]
    for r in rows:
        z = np.load(os.path.join(D, f"ptok_{r['arm']}_s{r['seed']}.npz"))
        r["_ce"], r["_conf"], r["_mass"], r["_hit"] = z["ce"], z["conf"], z["mass"], z["hit"]
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", default="a2_analysis.json")
    args = ap.parse_args()

    rows = load()
    arms = [a for a in ORDER if any(r["arm"] == a for r in rows)]
    E = len(rows[0]["evals"])

    print("=== 1. 再計算の突合（npz から引き直す）===")
    bad = [(r["arm"], r["seed"]) for r in rows
           if abs(float(r["_ce"].mean()) - r["evals"][-1]["ce_all"]) > 1e-6]
    print("  NG:", bad) if bad else print(
        f"  OK  {len(rows)} 本すべて json と npz が一致（|Δ| < 1e-6）")
    print("  n per arm:", {a: sum(1 for r in rows if r["arm"] == a) for a in arms})

    print("\n=== 2. 学習前の選択同一性と質量（同一 logits、構成的な確認）===")
    with open(os.path.join(D, "a2_identity.json"), encoding="utf-8") as fh:
        ident = json.load(fh)
    for a in arms:
        v = ident[a]
        print(f"  {a:9s} 選択一致={v.get('selection_identical', 'base')!s:5s} "
              f"mass={v['mass_mean']:.4f}±{v['mass_sd']:.4f} "
              f"[{v['mass_min']:.3f},{v['mass_max']:.3f}] gate_max={v['gate_max_mean']:.3f}")

    def col(a, key, ep=-1):
        return np.array([r["evals"][ep][key] for r in rows if r["arm"] == a])

    print("\n=== 3. 到達点（最終 epoch, n=6）===")
    print(f"  {'arm':9s}{'mass':>16s}{'mass(init)':>11s}{'gap_all':>9s}{'gap_pl':>9s}"
          f"{'conf':>7s}{'acc':>7s}{'instr':>7s}{'CE':>8s}{'logit':>7s}")
    for a in arms:
        rs = [r for r in rows if r["arm"] == a]
        m = col(a, "mass_mean")
        mi = np.array([r["init_eval"]["mass_mean"] for r in rs])
        print(f"  {a:9s}{m.mean():>9.4f}±{m.std(ddof=1):.4f}{mi.mean():>11.4f}"
              f"{col(a,'gap_all').mean():>+9.4f}{col(a,'gap_payload').mean():>+9.4f}"
              f"{col(a,'conf_all').mean():>7.4f}{col(a,'acc_all').mean():>7.4f}"
              f"{col(a,'instr_valid').mean():>7.3f}{col(a,'ce_all').mean():>8.4f}"
              f"{col(a,'logit_rms').mean():>7.3f}")

    print("\n=== 4. 質量の軌跡（層平均、epoch ごと）===")
    for a in arms:
        cells = "".join(f"{col(a,'mass_mean',k).mean():>9.4f}" for k in range(E))
        print(f"  {a:9s}{cells}")

    def paired(a, b, key, ep=-1):
        da = {r["seed"]: r["evals"][ep][key] for r in rows if r["arm"] == a}
        db = {r["seed"]: r["evals"][ep][key] for r in rows if r["arm"] == b}
        ks = sorted(set(da) & set(db))
        if len(ks) < 3:
            return None
        x = np.array([da[i] for i in ks])
        y = np.array([db[i] for i in ks])
        d = x - y
        n = len(d)
        se = d.std(ddof=1) / math.sqrt(n)
        t, p = stats.ttest_rel(x, y)
        ci = stats.t.ppf(0.975, n - 1) * se
        mde = (stats.t.ppf(0.975, n - 1) + stats.t.ppf(0.80, n - 1)) * se
        return dict(a=a, b=b, metric=key, n=n, mean=float(d.mean()), se=float(se),
                    t=float(t), p=float(p), ci_lo=float(d.mean() - ci),
                    ci_hi=float(d.mean() + ci), pos=int((d > 0).sum()), mde=float(mde),
                    per_seed=d.round(5).tolist())

    CONTRASTS = [
        ("sig_norm", "sm_norm", "活性化だけ（質量は厳密に同じ 1.0）"),
        ("sig_raw", "sig_norm", "質量だけ（sigmoid 側、初期 +7%）"),
        ("sm_raw", "sm_norm", "質量だけ（softmax 側、初期 −71%）"),
        ("sig_raw", "sm_norm", "sigmoid の素朴な導入（質量＋形）"),
    ]
    print("\n=== 5. 対比（seed 対応、n=6、最終 epoch）===")
    res = []
    for a, b, lab in CONTRASTS:
        if a not in arms or b not in arms:
            continue
        print(f"  [{lab}]  {a} − {b}")
        for key in ("mass_mean", "gap_all", "gap_payload", "acc_all", "instr_valid", "ce_all"):
            c = paired(a, b, key)
            if not c:
                continue
            c["label"] = lab
            res.append(c)
            star = " *" if c["p"] < 0.05 else "  "
            print(f"    {key:12s} Δ={c['mean']:+.4f} se={c['se']:.4f} t={c['t']:+.2f} "
                  f"p={c['p']:.4f}{star} {c['pos']}/{c['n']} "
                  f"CI[{c['ci_lo']:+.4f},{c['ci_hi']:+.4f}] MDE={c['mde']:.4f}")

    print("\n=== 6. Δ質量 と Δギャップ は対応するか（4 アーム、最終 epoch）===")
    base = "sm_norm"
    pts = []
    for a in arms:
        if a == base:
            continue
        cm = paired(a, base, "mass_mean")
        cg = paired(a, base, "gap_all")
        ca = paired(a, base, "acc_all")
        if cm and cg:
            pts.append((a, cm["mean"], cg["mean"], ca["mean"]))
            print(f"  {a:9s} vs {base}: Δmass={cm['mean']:+.4f} "
                  f"Δgap={cg['mean']:+.4f} Δacc={ca['mean']:+.4f}")
    if len(pts) >= 3:
        dm = np.array([p[1] for p in pts])
        dg = np.array([p[2] for p in pts])
        r, p = stats.pearsonr(dm, dg)
        print(f"  Pearson r(Δmass, Δgap) = {r:+.3f} (p={p:.3f}, n={len(pts)})"
              "  ※ n=3 なので参考値")

    print("\n=== 7. within-arm: トークンごとの質量と確信度の相関 ===")
    print("  （質量が過信を作るなら r > 0。P6c の機構の直接検定）")
    for a in arms:
        rs = [r for r in rows if r["arm"] == a]
        rr = []
        for r in rs:
            m = r["_mass"].ravel()
            c = r["_conf"].ravel()
            if m.std() > 1e-9:
                rr.append(float(np.corrcoef(m, c)[0, 1]))
        rr = np.array(rr)
        if rr.size:
            print(f"  {a:9s} r = {rr.mean():+.4f} ± {rr.std(ddof=1):.4f}  "
                  f"（seed 別: {', '.join(f'{v:+.3f}' for v in rr)}）")

    # --- 8. ECE（ギャップは飽和するので、ビン別の較正誤差も見る）---
    _, typ = Q1.make_trace_batch(np.random.default_rng(777), 1024)
    m_pl = (typ[:, Q1.TRACE0:] == Q1.TYP_PAYLOAD)
    print("\n=== 8. ECE（15 ビン、payload 位置）===")
    ece_by = {}
    for a in arms:
        rs = [r for r in rows if r["arm"] == a]
        v, v_all = [], []
        for r in rs:
            v.append(ece(r["_conf"][m_pl], r["_hit"][m_pl]))
            v_all.append(ece(r["_conf"].ravel(), r["_hit"].ravel()))
        ece_by[a] = (float(np.mean(v)), float(np.std(v, ddof=1)), float(np.mean(v_all)))
        print(f"  {a:9s} ECE(payload) = {np.mean(v):.4f} ± {np.std(v, ddof=1):.4f}"
              f"   ECE(all) = {np.mean(v_all):.4f}")
    for a, b, lab in CONTRASTS:
        if a not in arms or b not in arms:
            continue
        da = {r["seed"]: ece(r["_conf"][m_pl], r["_hit"][m_pl]) for r in rows if r["arm"] == a}
        db = {r["seed"]: ece(r["_conf"][m_pl], r["_hit"][m_pl]) for r in rows if r["arm"] == b}
        ks = sorted(set(da) & set(db))
        d = np.array([da[i] - db[i] for i in ks])
        se = d.std(ddof=1) / math.sqrt(len(d))
        t, p = stats.ttest_rel([da[i] for i in ks], [db[i] for i in ks])
        print(f"  {a} − {b}: ΔECE = {d.mean():+.4f} se={se:.4f} t={t:+.2f} p={p:.4f}")

    agg = {}
    for a in arms:
        agg[a] = {k: float(col(a, k).mean()) for k in
                  ("mass_mean", "mass_sd", "gap_all", "gap_payload", "conf_all",
                   "acc_all", "instr_valid", "ce_all", "logit_rms", "out_rms")}
        agg[a]["mass_init"] = float(np.mean([r["init_eval"]["mass_mean"]
                                             for r in rows if r["arm"] == a]))
        agg[a]["mass_by_ep"] = [float(col(a, "mass_mean", k).mean()) for k in range(E)]
        agg[a]["gap_by_ep"] = [float(col(a, "gap_all", k).mean()) for k in range(E)]
    out = {"aggregate": agg, "contrasts": res, "epochs": E, "n_runs": len(rows),
           "identity": ident}
    with open(os.path.join(D, args.json), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    print(f"\n[write] {os.path.join(D, args.json)}")


if __name__ == "__main__":
    main()
