# -*- coding: utf-8 -*-
"""_analyze_structure.py — en/ja の差は「言語」か「構造（コーディング的要素）」か

wikitext(raw) は = 見出し = / @-@ / 表組み などのマークアップを含む。
ja 側（プロジェクト md）も表・数式・箇条書きを含む。
どちらが「予測しやすい（＝反復的）」かを実測し、層の非対称性が
「予測しやすさ」に乗っているかを見る。

出すもの:
  1. マークアップ度: 記号だけのトークン率、@-@ の出現率
  2. 予測しやすさ: NLL<0.05 の率、p_top1>0.9 の率（言語別）
  3. 層の非対称性（f6b8−f8b6 の較正ギャップ）を「予測しやすさ」ビン別に
"""
import math

import numpy as np

LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


# ---------------------------------------------------------------- 1. マークアップ度
from transformers import AutoTokenizer  # noqa: E402

tok = AutoTokenizer.from_pretrained("models/olmoe-1b-7b")
z = np.load("corpus_ids_seed11_w24_l256.npz", allow_pickle=True)

log("=== 1. トークンの見た目（凍結コーパス 6,144 トークン/言語） ===")
log("%-4s %8s %10s %10s %10s %10s" %
    ("lang", "tokens", "記号のみ%", "@含む%", "空白始%", "平均文字数"))
struct = {}
for lang in ("en", "ja"):
    ids = z["%s_ids" % lang]
    toks = [tok.decode([int(i)]) for i in ids]
    n = len(toks)
    sym_only = sum(1 for t in toks if t.strip() and all(not c.isalnum() for c in t.strip()))
    at = sum(1 for t in toks if "@" in t)
    sp = sum(1 for t in toks if t.startswith(" "))
    avglen = sum(len(t) for t in toks) / n
    struct[lang] = dict(sym_only=sym_only / n, at=at / n, sp=sp / n, avglen=avglen)
    log("%-4s %8d %10.2f %10.2f %10.2f %10.2f"
        % (lang, n, 100 * sym_only / n, 100 * at / n, 100 * sp / n, avglen))

# ---------------------------------------------------------------- 2. 予測しやすさ
d = np.load("p6a_decision_curve.npz", allow_pickle=True)
nll8 = d["k8_nll"].astype(float)
p1_8 = d["k8_ptop1"].astype(float)
lang_arr = d["lang"]
tok_lang = np.repeat(lang_arr, nll8.size // lang_arr.size)

log("")
log("=== 2. 予測しやすさ（P6a の base, 6,120 トークン/言語） ===")
log("%-4s %10s %10s %10s %10s %10s" %
    ("lang", "NLL<0.05%", "NLL<0.5%", "p>0.9%", "p>0.99%", "平均NLL"))
pred = {}
for u in ("en", "ja"):
    m = tok_lang == u
    row = dict(lo005=float((nll8[m] < 0.05).mean()), lo05=float((nll8[m] < 0.5).mean()),
               p90=float((p1_8[m] > 0.9).mean()), p99=float((p1_8[m] > 0.99).mean()),
               mean=float(nll8[m].mean()))
    pred[u] = row
    log("%-4s %10.2f %10.2f %10.2f %10.2f %10.3f"
        % (u, 100 * row["lo005"], 100 * row["lo05"], 100 * row["p90"], 100 * row["p99"], row["mean"]))

# ---------------------------------------------------------------- 3. 非対称性 × 予測しやすさ
c = np.load("p6c_layer_cal.npz", allow_pickle=True)
tl = np.repeat(c["lang"], c["base_nll"].size // c["lang"].size)
gap6 = c["f6b8_ptop1"].astype(float) - c["f6b8_top1"].astype(float)
gap8 = c["f8b6_ptop1"].astype(float) - c["f8b6_top1"].astype(float)
dg = gap6 - gap8                     # 負 = f6b8 の方がギャップ小 = 後半削りが悪い
base_nll = c["base_nll"].astype(float)


def ttest(a):
    se = a.std(ddof=1) / math.sqrt(a.size)
    return a.mean(), se, a.mean() / se if se > 0 else float("nan")


log("")
log("=== 3. 層の非対称性（f6b8−f8b6 のギャップ差, pt）を予測しやすさ別に ===")
log("  NLL が小さい = 予測しやすい（マークアップ・定型句）。負なら後半削りが悪い。")
EDGES = [0.0, 0.05, 0.5, 2.0, 5.0, 1e9]
log("%-14s %10s %10s %10s %10s" % ("NLL ビン", "n", "全体", "en", "ja"))
rows = {}
for i in range(len(EDGES) - 1):
    m = (base_nll >= EDGES[i]) & (base_nll < EDGES[i + 1])
    if m.sum() < 50:
        continue
    lab = "%.2f-%.2f" % (EDGES[i], min(EDGES[i + 1], 99))
    mm, se, tt = ttest(dg[m])
    parts = []
    for u in ("en", "ja"):
        s = m & (tl == u)
        if s.sum() < 30:
            parts.append("     n/a")
            continue
        a, b, t2 = ttest(dg[s])
        parts.append("%+6.2f(t%+4.1f)" % (100 * a, t2))
    log("%-14s %10d %+10.3f %10s %10s" % (lab, m.sum(), 100 * mm, parts[0], parts[1]))
    rows[lab] = dict(n=int(m.sum()), all=100 * mm, en=parts[0], ja=parts[1])

# 予測しやすい側とそうでない側の寄与
hi = base_nll < 0.5
lo = base_nll >= 0.5
log("")
log("予測しやすい（NLL<0.5）トークンの割合: en %.1f%% / ja %.1f%%"
    % (100 * hi[tl == "en"].mean(), 100 * hi[tl == "ja"].mean()))
for u in ("en", "ja"):
    s = tl == u
    a, _, t2 = ttest(dg[s & hi])
    b, _, t3 = ttest(dg[s & lo])
    log("  %s: NLL<0.5 %+7.3f pt (t=%+6.2f, n=%d) / NLL>=0.5 %+7.3f pt (t=%+6.2f, n=%d)"
        % (u, 100 * a, t2, int((s & hi).sum()), 100 * b, t3, int((s & lo).sum())))

with open("_analyze_structure_out.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(LOG))
