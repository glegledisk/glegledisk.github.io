#!/usr/bin/env python3
"""K6: 「容量が縛られる系」を作る — 任意の key→code ルックアップ課題。

動機（`考察_どんなデータ系でHMoE教師が有効か_20261101.md` §5-1）
  K5 の合成プログラムは知識が **320 bit** しかなく、生徒のパラメータ（3.5e6 bit）の 0.01% だった。
  だから「容量が律速になる」条件 C を検定できなかった。ここでは**知識量を N で直接振る**。

タスク
  系列 = KEY(3) + SEP(1) + CODE(4) = 8 tokens
  KEY  : 語彙 28 文字（SEP を除く）の 3 連 → **28³ = 21,952 通りの同定子**
  CODE : 10 進 4 桁。**key → code は一様ランダムな固定表**（構造なし＝暗記しかない）
  -> 知識量 = N × log2(10⁴) = N × 13.29 bit。N=1e4 で **1.3e5 bit**、N=2e4 で 2.7e5 bit。
  -> 1 トークンあたりの計算は浅い（表引き）。**深さ型でなく容量型**を狙う。

頻度
  --freq uniform : 全 key が等頻度（容量の純粋な検定。位置の効果を排除）
  --freq zipf    : p_i ∝ 1/i^a（頭と裾を作る。条件 D の検定用）

測るもの
  評価は訓練と同じ分布から N × n_eval_per_key 本。per-key CE を出し、
  freq=zipf では**頻度分位ごと**に集計する（頭で当たって裾で落ちるかを見る）。

出力: k6_results_<tag>.json / k6_out_utf8_<tag>.txt
"""
import argparse
import json
import os
import sys
import time
from multiprocessing import Pool

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SIM = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, HERE)
sys.path.insert(0, SIM)

KEY_LEN = 3
CODE_LEN = 4
SL_ = KEY_LEN
OL_ = CODE_LEN
SEQ_ = KEY_LEN + 1 + CODE_LEN
NKEY_SYM = 28          # SEP(index 20) を除く 28 文字を key に使う
SEP_IDX = 20
DIGIT0 = 6             # VOCAB の '0'

# key 記号 0..27 -> 語彙添字（SEP を飛ばす）
LUT = np.array([j if j < SEP_IDX else j + 1 for j in range(NKEY_SYM)], dtype=np.int64)


def build_table(N, seed):
    rng = np.random.default_rng(seed)
    return rng.integers(0, 10, size=(N, CODE_LEN)).astype(np.int64)


def key_tokens(ids):
    toks = np.zeros((len(ids), KEY_LEN), dtype=np.int64)
    x = np.asarray(ids).copy()
    for j in range(KEY_LEN - 1, -1, -1):
        toks[:, j] = x % NKEY_SYM
        x //= NKEY_SYM
    return LUT[toks]


def make_sampler(N, freq, a):
    """-> (cdf, ids_fn)。uniform は integers で速く引く。"""
    if freq == "uniform":
        return None, (lambda rng, n: rng.integers(0, N, size=n))
    i = np.arange(1, N + 1, dtype=np.float64)
    p = i ** (-a)
    cdf = np.cumsum(p)
    cdf /= cdf[-1]
    return cdf, (lambda rng, n: np.searchsorted(cdf, rng.random(n), side="right"))


def make_batch(rng, n, table, ids_fn):
    ids = np.clip(ids_fn(rng, n), 0, len(table) - 1)
    return key_tokens(ids), table[ids] + DIGIT0, ids


def to_seq(src, out, sep):
    s = np.empty((src.shape[0], SEQ_), dtype=np.int64)
    s[:, :SL_] = src
    s[:, SL_] = sep
    s[:, SL_ + 1:] = out
    return s


def _clean(o):
    """json 用に numpy / torch のスカラー・配列を素の Python に落とす。"""
    if isinstance(o, dict):
        return {str(k): _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if o is None or isinstance(o, (bool, int, float, str)):
        return o
    if isinstance(o, np.generic):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    try:
        if hasattr(o, "numel") and o.numel() == 1:
            return float(o)
    except Exception:
        pass
    try:
        return float(o)
    except Exception:
        return str(o)


def worker(job):
    cfg, seed, N, per_key, epochs, bs, lr, auxw, freq, a, n_eval_per_key, clip = job
    import torch
    import torch.nn.functional as F
    import e2b_rewrite_routing_fixed as e2b

    torch.set_num_threads(1)
    e2b.SEQ = SEQ_                       # pos embedding の長さを差し替え（構築より前）
    e2b.SL, e2b.OL = SL_, OL_
    V, SEP = e2b.V, e2b.SEP

    t0 = time.time()
    table = build_table(N, 10_000 + seed)
    _, ids_fn = make_sampler(N, freq, a)

    if cfg.startswith("dense"):
        width = int(cfg.split(":")[1])
        model = e2b.RewriteMoE([width], seed=seed, topk=1)
        arm, k = "none", 1
    else:
        arm = cfg.split(":")[1]
        model = e2b.RewriteMoE(e2b.WIDTHS[arm], seed=seed)
        k = 2
    opt = e2b.Adam(model.params(), lr=lr)
    dims = torch.tensor(model.dims, dtype=torch.float64)

    # --- 評価（毎 epoch 呼ぶ）---
    ev_rng = np.random.default_rng(4242)
    n_ev = int(min(N * n_eval_per_key, 200_000))
    ev_src, ev_out, ev_ids = make_batch(ev_rng, n_ev, table, ids_fn)

    def evaluate():
        ce = np.zeros((n_ev, OL_), dtype=np.float32)
        hit = np.zeros((n_ev, OL_), dtype=bool)
        wsum, wn = 0.0, 0
        with torch.no_grad():
            for i in range(0, n_ev, 512):
                s = slice(i, min(i + 512, n_ev))
                x = torch.from_numpy(to_seq(ev_src[s], ev_out[s], SEP))
                logits, _, idxs = model(x, aux_mode="none", need_idx=True)
                lg = logits[:, SL_:SL_ + OL_, :]
                lp = F.cross_entropy(lg.reshape(-1, V),
                                     torch.from_numpy(ev_out[s]).reshape(-1),
                                     reduction="none").reshape(-1, OL_)
                ce[s] = lp.numpy()
                hit[s] = (lg.argmax(-1).numpy() == ev_out[s])
                for aa in idxs:
                    wsum += float(dims[aa].sum(-1).sum())
                    wn += aa.shape[0] * aa.shape[1]
        return ce, hit, wsum / max(wn, 1)

    rng = np.random.default_rng(1000 + seed)
    n_tr = int(N * per_key)
    steps = max(1, n_tr // bs)
    hist = []
    for ep in range(epochs):
        run, nclip = 0.0, 0
        for _ in range(steps):
            src, out, _ = make_batch(rng, bs, table, ids_fn)
            x = torch.from_numpy(to_seq(src, out, SEP))
            logits, aux, _ = model(x, aux_mode=arm)
            lg = logits[:, SL_:SL_ + OL_, :].reshape(-1, V)
            tgt = torch.from_numpy(out).reshape(-1)
            loss = F.cross_entropy(lg, tgt) + (auxw * aux if arm != "none" else 0.0)
            loss.backward()
            if clip > 0:                       # 大域ノルムでクリップ（容量限界では発散しやすい）
                tot = 0.0
                for v in model.params().values():
                    if v.grad is not None:
                        tot += float(v.grad.pow(2).sum())
                tot = tot ** 0.5
                if tot > clip:
                    s = clip / (tot + 1e-12)
                    for v in model.params().values():
                        if v.grad is not None:
                            v.grad.mul_(s)
                    nclip += 1
            opt.step(model.params())
            run += float(loss.detach())
        ce_ep, _, w_ep = evaluate()
        hist.append({"ep": ep + 1, "loss": run / steps, "ce": float(ce_ep.mean()),
                     "w": float(w_ep), "nclip": nclip})
        print("    [%s s%d N=%d] ep%d/%d loss=%.4f CE=%.4f w=%.1f clip=%d (%.0fs)"
              % (cfg, seed, N, ep + 1, epochs, run / steps, ce_ep.mean(), w_ep,
                 nclip, time.time() - t0), flush=True)

    # 最終 3 epoch の中央値（単点評価は裾を過大評価する）
    tail = hist[-3:] if len(hist) >= 3 else hist
    ce, hit, width_mean = evaluate()
    ce_med = float(np.median([h["ce"] for h in tail]))
    w_med = float(np.median([h["w"] for h in tail]))

    # 頻度分位（zipf のとき意味がある）
    if freq == "zipf":
        i = np.arange(1, N + 1, dtype=np.float64)
        p = i ** (-a)
        order = np.argsort(-p)
        rank = np.empty(N, dtype=np.int64)
        rank[order] = np.arange(N)
        q = rank[ev_ids] * 10 // N
    else:
        q = np.zeros(n_ev, dtype=np.int64)
    by_q = {}
    for b in range(10):
        m = q == b
        if m.sum() == 0:
            continue
        by_q[b] = {"n": int(m.sum()), "ce": float(ce[m].mean()),
                   "acc": float(hit[m].mean())}

    return {
        "cfg": cfg, "seed": seed, "N": N, "per_key": per_key, "epochs": epochs,
        "freq": freq, "zipf_a": a, "n_train": n_tr, "steps": steps,
        "knowledge_bits": float(N * np.log2(10 ** CODE_LEN)),
        "ce": ce_med, "ce_last": float(hist[-1]["ce"]), "ce_hist": hist,
        "ce_pos": [float(v) for v in ce.mean(0)],
        "acc": float(hit.mean()), "acc_pos": [float(v) for v in hit.mean(0)],
        "ce_by_decile": by_q,
        "width_mean": w_med,
        "macs": float(4 * (4 * 128 * 128 + 2 * 128 * w_med + 128 * model.E)),
        "nparam": int(sum(v.numel() for v in model.params().values())),
        "nparam_ffn": int(sum(v.numel() for kk, v in model.params().items()
                              if kk.startswith("l") and ".e" in kk)),
        "n_clip": int(sum(h["nclip"] for h in hist)),
        "sec": round(time.time() - t0, 1),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", nargs="+", default=["dense:107"])
    ap.add_argument("--Ns", nargs="+", type=int, default=[1000])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0])
    ap.add_argument("--per_key", type=int, default=5, help="1 epoch あたりの key 露出回数")
    ap.add_argument("--epochs", type=int, default=10)
    ap.add_argument("--bs", type=int, default=64)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--clip", type=float, default=1.0, help="大域ノルムのクリップ（0 で無効）")
    ap.add_argument("--auxw", type=float, default=0.05)
    ap.add_argument("--freq", default="uniform", choices=["uniform", "zipf"])
    ap.add_argument("--zipf_a", type=float, default=1.0)
    ap.add_argument("--n_eval_per_key", type=int, default=1)
    ap.add_argument("--workers", type=int, default=4)
    ap.add_argument("--tag", type=str, default="ladder")
    args = ap.parse_args()

    suf = ("_" + args.tag) if args.tag else ""
    LOG = os.path.join(HERE, "k6_out_utf8%s.txt" % suf)
    if os.path.exists(LOG):
        os.remove(LOG)

    def log(msg):
        print(msg, flush=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")

    log("K6: 容量が縛られる系（任意 key→code ルックアップ）")
    log("KEY=%d CODE=%d SEQ=%d  語彙 29  key 記号 %d（%d³=%d 通り）"
        % (KEY_LEN, CODE_LEN, SEQ_, NKEY_SYM, NKEY_SYM, NKEY_SYM ** KEY_LEN))
    log("configs=%s Ns=%s seeds=%s per_key=%d epochs=%d freq=%s a=%.2f"
        % (args.configs, args.Ns, args.seeds, args.per_key, args.epochs,
           args.freq, args.zipf_a))
    log("")

    jobs = [(cfg, s, N, args.per_key, args.epochs, args.bs, args.lr, args.auxw,
             args.freq, args.zipf_a, args.n_eval_per_key, args.clip)
            for cfg in args.configs for N in args.Ns for s in args.seeds]
    t0 = time.time()
    rows = []
    part = os.path.join(HERE, "k6_partial%s.json" % suf)
    with Pool(processes=min(args.workers, len(jobs))) as pool:
        for r in pool.imap_unordered(worker, jobs):
            rows.append(r)
            log("  %-12s N=%-6d s%d  CE %.4f  acc %.4f  幅 %6.1f  MACs %7d  知識 %.2e bit  (%.0fs)"
                % (r["cfg"], r["N"], r["seed"], r["ce"], r["acc"], r["width_mean"],
                   r["macs"], r["knowledge_bits"], r["sec"]))
            with open(part, "w", encoding="utf-8") as f:
                json.dump(_clean({"rows": rows}), f, ensure_ascii=False, indent=2)
    rows.sort(key=lambda r: (r["cfg"], r["N"], r["seed"]))

    log("")
    log("== 集計 ==")
    log("  %-12s %7s %10s %9s %9s %7s %8s %8s"
        % ("cfg", "N", "知識bit", "CE", "acc", "幅", "MACs", "param"))
    for r in rows:
        log("  %-12s %7d %10.2e %9.4f %9.4f %7.1f %8d %8d"
            % (r["cfg"], r["N"], r["knowledge_bits"], r["ce"], r["acc"],
               r["width_mean"], r["macs"], r["nparam"]))
    log("")
    log("  参考: 4 桁すべてチャンスなら CE = %.4f（1 桁 log10 = %.4f）"
        % (4 * np.log(10), np.log(10)))
    log("  壁時計 %.0f 分" % ((time.time() - t0) / 60))

    with open(os.path.join(HERE, "k6_results%s.json" % suf), "w", encoding="utf-8") as f:
        json.dump(_clean({"rows": rows, "args": vars(args)}), f,
                  ensure_ascii=False, indent=2)
    log("[write] k6_results%s.json" % suf)
    os._exit(0)


if __name__ == "__main__":
    main()
