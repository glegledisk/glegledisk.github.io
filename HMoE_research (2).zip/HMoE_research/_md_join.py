# -*- coding: utf-8 -*-
"""_md_join.py — 日本語の軟改行を結合する。

Markdown は段落内の改行を空白に変換する。日本語ではこれが**文の途中に空白を挿入**するため、
「H+LB を 同一条件」「だけが パラメータ数」のような崩れになる。
段落・リスト項目の継続行を 1 行に結合して除く。

- コードフェンス / 表 / 見出し / 箇条書きの開始 / 水平線 は結合しない
- 結合子は、両側とも非 CJK のときだけ半角空白、それ以外は空
"""
import re
import sys

path = sys.argv[1]
src = open(path, encoding="utf-8").read()
lines = src.split("\n")


PUNCT = set("、。，．・：；？！）」』】〉》〕｝…‥")


def is_cjk(ch):
    o = ord(ch)
    return (0x3000 <= o <= 0x30FF) or (0x4E00 <= o <= 0x9FFF) or (0xFF00 <= o <= 0xFFEF)


def is_block_start(ln):
    s = ln.lstrip()
    if not s:
        return True
    if s.startswith(("#", "|", ">", "```", "- ", "* ", "+ ")):
        return True
    if re.match(r"^\d+\.\s", s):
        return True
    if s.strip() == "---":
        return True
    # ヘッダの項目は行を保つ（他報告と同じ見た目にする）
    if re.match(r"^(実施日|スクリプト|出力|前提|手法|判定|対象指針|予備測定|対象)[:：]", s):
        return True
    return False


def is_boundary_prev(ln):
    """直前の行が「継続を受け付けない」種類か。箇条書きの開始は受け付ける。"""
    s = ln.lstrip()
    return (not s) or s.startswith(("#", "|", ">", "```")) or s.strip() == "---"


out = []
in_fence = False
joined = 0
for ln in lines:
    if ln.lstrip().startswith("```"):
        in_fence = not in_fence
        out.append(ln)
        continue
    if in_fence:
        out.append(ln)
        continue
    # blockquote の継続行を結合する（`>` 行が続く場合）。
    # これをやらないと `>` の中の軟改行が空白になる（A7 で 4 箇所踏んだ）。
    if ln.lstrip().startswith(">") and out and out[-1].lstrip().startswith(">"):
        cur = ln.lstrip()[1:].lstrip()
        if cur and not re.match(r"^([-*+]|\d+\.|#|\||```)", cur):
            prev = out[-1].rstrip()
            a, b = prev[-1], cur[0]
            sep = "" if (a in PUNCT or (is_cjk(a) and is_cjk(b))) else " "
            out[-1] = prev + sep + cur
            joined += 1
            continue
    if is_block_start(ln):
        out.append(ln)
        continue
    prev = out[-1] if out else ""
    if not prev.strip() or is_boundary_prev(prev):
        out.append(ln)
        continue
    a, b = prev.rstrip()[-1], ln.lstrip()[0]
    if a in PUNCT or (is_cjk(a) and is_cjk(b)):
        sep = ""
    else:
        sep = " "
    out[-1] = prev.rstrip() + sep + ln.lstrip()
    joined += 1

new = "\n".join(out)
if not new.endswith("\n"):
    new += "\n"
open(path, "w", encoding="utf-8", newline="\n").write(new)
print(f"joined {joined} lines, {len(lines)} -> {len(out)} lines")
