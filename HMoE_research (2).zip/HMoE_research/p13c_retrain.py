#!/usr/bin/env python3
"""P13c: ゲート添字バグを直した E2b で、HMoE / 同質 MoE / 小型 dense を訓練し直す。

E2 の元実装は `gate[tok, slot]`（slot は top-k 内の位置）で引いていたため、top-2 では
expert 2〜7 の寄与が恒等的に 0 だった。修正版 e2b_rewrite_routing_fixed.py を使う。

訓練条件は E2 と完全に同一（seqs=3000, epochs=6, bs=32, lr=2e-3, auxw=0.05）。
評価は seed 777 の 2048 系列（E2 の evaluate と同一）。

アーム:
  H+LB : 幅 32/32/96/96/160/160/224/224, top-2, p_pen aux
  U+LB : 幅 128 x 8, top-2, switch aux
  dense: 幅 W の 2 層 MLP（E=1, k=1）を W=97/180/256 で

出力: p13c_results.json / p13c_results.csv（ckpt は data/e2b）
"""
import argparse
import csv
import json
import math
import os
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, E2DIR)
from e2b_rewrite_routing_fixed import (  # noqa: E402
    RewriteMoE, Adam, make_batch, to_seq, out_loss, SL, OL, V, WIDTHS)

OUTDIR = os.path.join(E2DIR, "data", "e2b")

MAIN = [("top1", None, 1), ("base", None, 2), ("top3", None, 3), ("all8", None, 8)]
SUB = [
    ("s1", (0,), 1), ("s2", (0, 1), 2), ("m2", (0, 2), 2), ("u2", (2, 3), 2),
    ("q4", (0, 1, 2, 3), 4), ("l2", (6, 7), 2), ("r2", "rand", 2),
]


def forward_forced(model, idx, force=None, k=None):
    """修正版: ゲートは expert 添字 i で引く。"""
    p = model.p
    B, T = idx.shape
    h = p["emb.w"][idx] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)
    causal = torch.triu(torch.ones(T, T, dtype=torch.bool), diagonal=1)
    idx_l = []
    for l in range(model.L):
        hb = h.reshape(B, T, -1)
        q = F.linear(hb, p[f"l{l}.q.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        kk = F.linear(hb, p[f"l{l}.k.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        v = F.linear(hb, p[f"l{l}.v.w"]).reshape(B, T, model.nh, model.dh).transpose(1, 2)
        att = (q @ kk.transpose(-1, -2)) / math.sqrt(model.dh)
        att = att.masked_fill(causal, float("-inf")).softmax(-1)
        o = (att @ v).transpose(1, 2).reshape(B, T, -1)
        h = hb + F.linear(o, p[f"l{l}.o.w"])
        h = h.reshape(B * T, -1)

        logits = F.linear(h, p[f"l{l}.r.w"], p[f"l{l}.r.b"])
        if force is None:
            topv, topi = logits.topk(k, dim=1)
        else:
            topi = torch.tensor(list(force), dtype=torch.long).expand(h.shape[0], -1)
            topv = logits.gather(1, topi)
        gate = torch.softmax(
            torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
        idx_l.append(topi.reshape(B, T, -1))
        y = torch.zeros_like(h)
        for i in range(model.E):
            tok, _ = (topi == i).nonzero(as_tuple=True)
            if tok.numel() == 0:
                continue
            x = h[tok]
            h1 = F.relu(F.linear(x, p[f"l{l}.e{i}.w1"], p[f"l{l}.e{i}.b1"]))
            y.index_add_(0, tok,
                         F.linear(h1, p[f"l{l}.e{i}.w2"], p[f"l{l}.e{i}.b2"])
                         * gate[tok, i].unsqueeze(1))
        h = h + y
    out = F.linear(h, p["head.w"], p["head.b"]).reshape(B, T, V)
    return out, idx_l


@torch.no_grad()
def run_cond(model, src, out, em, force, k, bs=128):
    n = src.shape[0]
    ce = np.zeros((n, OL), dtype=np.float32)
    hit_c = np.zeros((n, OL), dtype=bool)
    hit_e = np.zeros((n, OL), dtype=bool)
    widths = np.zeros((n, OL), dtype=np.float32)
    usage = np.zeros((model.L, model.E))
    dims = np.array(model.dims, float)
    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = to_seq(src[s], out[s])
        logits, idx_l = forward_forced(model, x, force=force, k=k)
        lg = logits[:, SL:SL + OL, :]
        tgt = torch.from_numpy(out[s])
        lp = F.cross_entropy(lg.reshape(-1, V), tgt.reshape(-1),
                             reduction="none").reshape(-1, OL)
        ce[s] = lp.numpy()
        pred = lg.argmax(-1).numpy()
        m = em[s]
        hit_c[s] = (pred == tgt.numpy()) & (~m)
        hit_e[s] = (pred == tgt.numpy()) & m
        for l, ti in enumerate(idx_l):
            a = ti.numpy()[:, SL:SL + OL, :]
            widths[s] += dims[a].sum(-1)
            for e in range(model.E):
                usage[l, e] += float((a == e).any(-1).sum())
    widths /= max(1, len(idx_l))
    mask = em
    ntok = src.shape[0] * OL
    return {
        "ce_copy": float(ce[~mask].mean()), "ce_edit": float(ce[mask].mean()),
        "ce_all": float(ce.mean()),
        "acc_copy": float(hit_c.sum() / max(1, (~mask).sum())),
        "acc_edit": float(hit_e.sum() / max(1, mask.sum())),
        "width": float(widths.mean()),
        "width_p10": float(np.percentile(widths, 10)),
        "width_p90": float(np.percentile(widths, 90)),
        "usage": (usage / max(1, ntok)).round(4).tolist(),
        "ce_seq": ce.mean(1).astype(np.float64).tolist(),
    }


def train_moe(arm, seed, n_seqs, epochs, bs, lr, auxw):
    torch.manual_seed(seed)
    rng = np.random.default_rng(1000 + seed)
    model = RewriteMoE(WIDTHS[arm], seed=seed)
    opt = Adam(model.params(), lr=lr)
    steps = max(1, n_seqs // bs)
    t0 = time.time()
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps):
            src, out, em, _ = make_batch(rng, bs)
            x = to_seq(src, out)
            logits, aux, _ = model(x, aux_mode={"H+LB": "p_pen", "U+LB": "switch"}[arm])
            loss = out_loss(logits, out) + auxw * aux
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        print("    [%s s%d] ep%d/%d loss=%.4f (%.0fs)"
              % (arm, seed, ep + 1, epochs, run / steps, time.time() - t0), flush=True)
    return model


def train_dense(width, seed, n_seqs, epochs, bs, lr):
    torch.manual_seed(seed)
    rng = np.random.default_rng(1000 + seed)
    model = RewriteMoE([width], seed=seed, topk=1)
    opt = Adam(model.params(), lr=lr)
    steps = max(1, n_seqs // bs)
    t0 = time.time()
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps):
            src, out, em, _ = make_batch(rng, bs)
            x = to_seq(src, out)
            logits, _, _ = model(x, aux_mode="none")
            loss = out_loss(logits, out)
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        print("    [dense%d s%d] ep%d/%d loss=%.4f (%.0fs)"
              % (width, seed, ep + 1, epochs, run / steps, time.time() - t0), flush=True)
    return model


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", nargs="+", default=["H+LB", "U+LB"])
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2])
    ap.add_argument("--dense_widths", nargs="+", type=int, default=[97, 180, 256])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=6)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--auxw", type=float, default=0.05)
    ap.add_argument("--n_eval", type=int, default=2048)
    ap.add_argument("--sub", action="store_true")
    args = ap.parse_args()
    torch.set_num_threads(6)
    os.makedirs(OUTDIR, exist_ok=True)

    ev = np.random.default_rng(777)
    src, out, em, ks = make_batch(ev, args.n_eval)
    print("eval: n=%d OUT=%d k_mean=%.2f edit率=%.3f"
          % (src.shape[0], OL, ks.mean(), em.mean()), flush=True)

    res = {}
    conds = MAIN + (SUB if args.sub else [])
    for arm in args.arms:
        for seed in args.seeds:
            print("\n[%s s%d] widths=%s" % (arm, seed, list(WIDTHS[arm])), flush=True)
            model = train_moe(arm, seed, args.seqs, args.epochs, args.bs,
                              args.lr, args.auxw)
            torch.save({k: v.detach() for k, v in model.params().items()},
                       os.path.join(OUTDIR, "ckpt_%s_s%d.pt" % (arm, seed)))
            for name, force, k in conds:
                if force == "rand":
                    rng = np.random.default_rng(99 + seed)
                    force = tuple(sorted(rng.choice(model.E, k, replace=False).tolist()))
                r = run_cond(model, src, out, em, force, k)
                r.update({"arm": arm, "seed": seed, "cond": name,
                          "force": list(force) if force is not None else "natural",
                          "k": k, "n_eval": args.n_eval})
                res["%s:s%d:%s" % (arm, seed, name)] = r
                print("  %-5s w=%4.0f [%3.0f,%3.0f]  CE %.4f  copy %.4f  edit %.4f"
                      % (name, r["width"], r["width_p10"], r["width_p90"],
                         r["ce_all"], r["acc_copy"], r["acc_edit"]), flush=True)
                if name == "base":
                    print("        layer別: %s" % " | ".join(
                        " ".join("%.2f" % x for x in row) for row in r["usage"]),
                        flush=True)

    for w in args.dense_widths:
        for seed in args.seeds:
            print("\n[dense W=%d s%d]" % (w, seed), flush=True)
            model = train_dense(w, seed, args.seqs, args.epochs, args.bs, args.lr)
            torch.save({k: v.detach() for k, v in model.params().items()},
                       os.path.join(OUTDIR, "ckpt_dense%d_s%d.pt" % (w, seed)))
            r = run_cond(model, src, out, em, None, 1)
            r.update({"arm": "dense", "seed": seed, "cond": "dense",
                      "force": "natural", "k": 1, "n_eval": args.n_eval,
                      "nparam": int(sum(v.numel() for v in model.params().values()))})
            res["dense:s%d:w%d" % (seed, w)] = r
            print("  -> W=%d s%d  CE %.4f  copy %.4f  params %d"
                  % (w, seed, r["ce_all"], r["acc_copy"], r["nparam"]), flush=True)

    with open(os.path.join(HERE, "p13c_results.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2, default=float)
    keys = ["arm", "seed", "cond", "force", "k", "width", "width_p10", "width_p90",
            "ce_all", "ce_copy", "ce_edit", "acc_copy", "acc_edit", "nparam"]
    with open(os.path.join(HERE, "p13c_results.csv"), "w", newline="",
              encoding="utf-8") as f:
        w_ = csv.DictWriter(f, fieldnames=keys)
        w_.writeheader()
        for r in res.values():
            w_.writerow({k: (json.dumps(r[k]) if isinstance(r.get(k), list)
                             else r.get(k, "")) for k in keys})
    print("\nsaved: p13c_results.json / p13c_results.csv")
    os._exit(0)


if __name__ == "__main__":
    main()
