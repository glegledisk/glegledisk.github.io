# -*- coding: utf-8 -*-
"""_act_moments.py — 活性関数の二次モーメント・勾配・コスト侵食を数値で出す（使い捨て検算）

報告書 考察_HMoEに最適な活性化関数_20261101.md の数値の一次ソース。
乱数を使わず Gauss-Hermite 求積で決定的に計算する。
"""
import json
import numpy as np

OUT = {}


def moments(f, name):
    """u ~ N(0,1) に対する E[f], E[f^2], E[f^4] を Gauss-Hermite で。"""
    x, w = np.polynomial.hermite_e.hermegauss(200)
    w = w / w.sum()
    v = f(x)
    return {
        "E_f": float((w * v).sum()),
        "E_f2": float((w * v * v).sum()),
        "E_f4": float((w * v**4).sum()),
        "min": float(v.min()),
    }


def silu(x):
    return x / (1.0 + np.exp(-x))


def relu(x):
    return np.maximum(x, 0.0)


def drelu_gate(x):
    # dReLU のゲート側: ReLU(x) をそのまま使う（TurboSparse は両側 ReLU）
    return np.maximum(x, 0.0)


acts = {
    "silu": silu,
    "relu": relu,
    "relu2": lambda x: relu(x) ** 2,
    "gelu_tanh": lambda x: 0.5 * x * (1 + np.tanh(np.sqrt(2 / np.pi) * (x + 0.044715 * x**3))),
}
for k, f in acts.items():
    OUT[f"act_{k}"] = moments(f, k)

# --- FFN 出力の二次モーメント（入力 z1,z2 ~ N(0, s^2) 独立、s=1 で規格化）---
# SwiGLU: out = SiLU(z1) * z2  -> E[out^2] = E[SiLU(u)^2] * E[u^2] = c1
c1 = OUT["act_silu"]["E_f2"] * 1.0
# GeGLU: out = GELU(z1) * z2
c1g = OUT["act_gelu_tanh"]["E_f2"] * 1.0
# ReLU^2: out = ReLU(z)^2 -> E[out^2] = E[ReLU(u)^4] = 1.5
# 注意: act_relu2.E_f4 は E[ReLU^8] なので使わない（2026-11-01 に一度踏んだ罠）
c2 = OUT["act_relu"]["E_f4"]
# ReGLU: out = ReLU(z1) * z2 -> E[out^2] = E[ReLU(u)^2] * 1
c3 = OUT["act_relu"]["E_f2"]
# dReLU: out = ReLU(z1) * ReLU(z2) -> E[out^2] = E[ReLU^2]^2
c4 = OUT["act_relu"]["E_f2"] ** 2

OUT["ffn_out_second_moment"] = {
    "swiglu": float(c1),
    "geglu": float(c1g),
    "relu2": float(c2),
    "reglu": float(c3),
    "drelu": float(c4),
}
OUT["rms_ratio_relu2_over_swiglu"] = float(np.sqrt(c2 / c1))
OUT["rms_ratio_relu2_over_drelu"] = float(np.sqrt(c2 / c4))
OUT["rms_ratio_swiglu_over_drelu"] = float(np.sqrt(c1 / c4))

# --- 勾配: z が 0 近傍のときの |d out/dz| ---
# ReLU^2: 2z (z>0), 0 (z<0)。SwiGLU のゲート側: SiLU'(z) * z2
# ここでは「ユニット 1 本あたりの、ゲート入力に対する勾配」を比較する
eps = np.array([1e-4, 1e-3, 1e-2, 1e-1, 0.5, 1.0])
silu_p = lambda z: (1 / (1 + np.exp(-z))) * (1 + z * (1 - 1 / (1 + np.exp(-z))))
OUT["grad_at_small_z"] = {
    f"{e:.0e}": {
        "relu2_dz": float(2 * e),
        "silu_dz": float(silu_p(e)),
        "relu_dz": 1.0,
        "ratio_silu_over_relu2": float(silu_p(e) / (2 * e)),
    }
    for e in eps
}

# 負側（z<0）で勾配が完全に 0 になる割合: N(0,1) なら 50%。
# 「学習が止まる深さ」= z が [-d, d] に入る確率（ReLU2 はここで勾配 2z → 0）
from math import erf, sqrt

def phi_interval(d):
    return erf(d / sqrt(2))

OUT["shell_probability"] = {
    f"|z|<{d}": float(phi_interval(d)) for d in (1e-3, 1e-2, 1e-1, 0.5)
}

# --- コスト侵食: c(w) = c0 + a*w、P7c の「半幅は丸ごと落とすコストの 66%」から c0/a を出す ---
# c(0.5w)/c(w) = (c0 + 0.5 a w)/(c0 + a w) = 0.66  ->  r = c0/(a w)
r = (0.5 - 0.66) / (0.66 - 1.0)  # 解くと r = (0.5-0.66)/(0.66-1)
OUT["cost_model"] = {"ratio_half_over_full_P7c": 0.66, "c0_over_aw": float(r)}
# 同一幅で SwiGLU(3dw) -> ReLU2(2dw) にしたときのコスト比
c_swiglu = r + 1.0
c_relu2_same_w = r + 2.0 / 3.0
OUT["cost_model"]["same_width_relu2_over_swiglu"] = float(c_relu2_same_w / c_swiglu)
# 等パラメータ（w -> 1.5w）にしたときのコスト比: c0 + a*1.5w
c_relu2_eqparam = r + 1.5
OUT["cost_model"]["eqparam_relu2_over_swiglu"] = float(c_relu2_eqparam / c_swiglu)

# 勾配の交差点: 2z = SiLU'(z) を満たす z（これ未満で ReLU2 の方が勾配が小さい）
from scipy.optimize import brentq

f_cross = lambda z: 2 * z - silu_p(z)
try:
    zc = brentq(f_cross, 1e-6, 3.0)
    OUT["grad_crossing_z"] = float(zc)
    OUT["grad_crossing_prob_mass_below"] = float(phi_interval(zc))
except Exception as e:  # pragma: no cover
    OUT["grad_crossing_z"] = None
    OUT["grad_crossing_error"] = str(e)

# --- 疎性の上限: ダウン投影しか飛ばせない ---
# SwiGLU: MACs = 2dw (gate,up) + dw (down)。飛ばせるのは down の (1-s)。
for s in (0.5, 0.7, 0.9):
    OUT.setdefault("sparsity_flops_saving", {})[f"s={s}"] = {
        "swiglu": float((1 - s) * 1 / 3),
        "drelu": float((1 - s) * 1 / 3),
        "relu2": float((1 - s) * 1 / 2),
    }

print(json.dumps(OUT, indent=2, ensure_ascii=False))
with open("_act_moments_results.json", "w", encoding="utf-8") as fh:
    json.dump(OUT, fh, indent=2, ensure_ascii=False)
