#!/usr/bin/env python3
"""e2b の ckpt が壊れているかを見る（CE / acc / logit スケール / パラメータノルム）。"""
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, E2DIR)
from e2b_rewrite_routing_fixed import (  # noqa: E402
    RewriteMoE, make_batch, to_seq, SL, OL, V, WIDTHS)


@torch.no_grad()
def diag(path, seed):
    m = RewriteMoE(WIDTHS["H+LB"], seed=seed)
    sd = torch.load(path, map_location="cpu")
    m.p = {k: v for k, v in sd.items()}
    for k in m.p:
        m.p[k].requires_grad_(False)
    rng = np.random.default_rng(777)
    src, out, em, ks = make_batch(rng, 256)
    x = to_seq(src, out)
    logits, aux, idx = m(x, aux_mode="none", need_idx=True)
    lg = logits[:, SL:SL + OL, :]
    tgt = torch.from_numpy(out)
    ce = F.cross_entropy(lg.reshape(-1, V), tgt.reshape(-1)).item()
    acc = (lg.argmax(-1).numpy() == out).mean()
    print("%-42s CE %.4f  acc %.4f  |logit|max %.2f  |head.w| %.2f  |emb.w| %.2f"
          % (os.path.basename(path), ce, acc, lg.abs().max().item(),
             m.p["head.w"].abs().max().item(), m.p["emb.w"].abs().max().item()))
    print("   norm: " + "  ".join("%s=%.3f" % (k, float(v.norm()))
                                  for k, v in list(m.p.items())[:6]))


if __name__ == "__main__":
    for tag in ("e2", "e2b"):
        for s in (0, 1, 2):
            p = os.path.join(E2DIR, "data", tag, "ckpt_H+LB_s%d.pt" % s)
            if os.path.exists(p):
                diag(p, s)
    os._exit(0)
