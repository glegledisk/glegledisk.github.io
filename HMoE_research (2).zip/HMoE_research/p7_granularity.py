# -*- coding: utf-8 -*-
"""P7: スロットの粒度と凸性比 ρ

問い:
  P3b の「層方向の不均一は報われない」（1.66 < 1+ρ=3.44）は、本物の性質か、
  それとも「1 スロット = expert 1 個」という離散化の人工物か。
  スロットを半分に刻めるなら、ρ は下がり、前重みが勝つ余地が出るか。

介入:
  ゲート重みの α スケーリング。rank 8（最小重み）の重みを α 倍すると、
  その expert の寄与が α 倍になる。α=1 が top-8、α=0 が top-7。
  norm_topk_prob=False なので MoE 出力は Σ w_i E_i で、α 倍は厳密に線形。
  α ∈ {0, 0.5} のみを使う（bf16 で正確に表現できる値だけ）。

条件（すべて同一スライス・同一 seed・全 16 層に適用）:
  base  top-8
  u1    8番目 α=0 全層            = top-7 相当（P6c の +0.01497 と一致するはず）
  u05   8番目 α=0.5 全層          = C(0.5)（加法性の検算にも使う）
  f05   前半のみ α=0.5            = C_f(0.5)
  f1    前半のみ α=0              = C_f(1)（P3b の f6b8 と同型）
  b05   後半のみ α=0.5            = C_b(0.5)
  b1    後半のみ α=0              = C_b(1)（P3b の f8b6 と同型）
  h15f  前半 α=0(8番目)+α=0.5(7番目)、後半 α=0.5(8番目)
        = 前半 1.5 / 後半 0.5 スロット（予算 16 = 均一と同じ）

判定する不等式（細粒度で前重みが勝つ条件）:
  C_f(1) − C_f(0.5)  <  C_b(0.5) − C_b(0)
  左 = 前半の「2 本目の半スロット」のコスト
  右 = 後半の「1 本目の半スロット」のコスト
  成り立てば、半スロットを後半から前半へ移すと得。
  すなわち P3b の負の結果は離散化の人工物であり、粒度を上げれば覆る。

出力:
  p7_granularity.npz   条件ごとの per-token NLL / top1 / 保持質量 / 言語ラベル
  p7_granularity.json  水準と基本統計

実行:
  python p7_granularity.py --windows 24 --len 256 --tag p7
  python p7_granularity.py --smoke --conds base,u1     # 機構の検証
"""

import argparse
import json
import os
import time

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
FROZEN = os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz")

# rank_from_end, alpha
#   rank 1 = 8 番目（最小重み）, rank 2 = 7 番目
FRONT = list(range(0, 8))
BACK = list(range(8, 16))

CONDS = {
    "base": {},
    "u1":   {L: [(1, 0.0)] for L in FRONT + BACK},
    "u05":  {L: [(1, 0.5)] for L in FRONT + BACK},
    "f05":  {L: [(1, 0.5)] for L in FRONT},
    "f1":   {L: [(1, 0.0)] for L in FRONT},
    "b05":  {L: [(1, 0.5)] for L in BACK},
    "b1":   {L: [(1, 0.0)] for L in BACK},
    "h15f": dict(
        [(L, [(1, 0.0), (2, 0.5)]) for L in FRONT]
        + [(L, [(1, 0.5)]) for L in BACK]
    ),
    # --- 追加（曲線を 0/0.5/1/1.5/2 に伸ばす）---
    "f15":  {L: [(1, 0.0), (2, 0.5)] for L in FRONT},
    "b15":  {L: [(1, 0.0), (2, 0.5)] for L in BACK},
    "u15":  {L: [(1, 0.0), (2, 0.5)] for L in FRONT + BACK},
    "f2":   {L: [(1, 0.0), (2, 0.0)] for L in FRONT},   # = P3b の f6b8（前半 top-6）
    "b2":   {L: [(1, 0.0), (2, 0.0)] for L in BACK},    # = P3b の f8b6（後半 top-6）
}

ORDER = ["base", "u1", "u05", "f05", "f1", "b05", "b1", "h15f"]


def log(msg):
    print(msg, flush=True)


def paired(a, b):
    d = np.asarray(a, np.float64) - np.asarray(b, np.float64)
    n = d.size
    m = float(d.mean())
    sd = float(d.std(ddof=1))
    se = sd / np.sqrt(n)
    return {"mean": m, "se": se, "t": m / se if se > 0 else float("nan"),
            "n": int(n), "sd": sd,
            "ci95": [m - 1.96 * se, m + 1.96 * se]}


def load_frozen(n_win, ln):
    """凍結コーパス（en 24 win -> ja 24 win の順）。p3 と同じ並び。"""
    z = np.load(FROZEN, allow_pickle=True)
    seqs = []
    for lang in ("en", "ja"):
        ids = torch.from_numpy(z["%s_ids" % lang].astype(np.int64))
        assert ids.numel() >= n_win * ln, (lang, ids.numel())
        for w in range(n_win):
            seqs.append((lang, ids[w * ln:(w + 1) * ln]))
    return seqs


def make_scaled(orig, mods):
    """mods: [(rank_from_end, alpha), ...]。scores の該当列を alpha 倍する。"""
    def _patched(hidden_states):
        out = orig(hidden_states)
        logits, scores, idx = out[0], out[1], out[2]
        if mods:
            s = scores.clone()
            k = s.shape[-1]
            for rank, alpha in mods:
                if rank <= k:
                    s[:, -rank] = s[:, -rank] * alpha
            scores = s
        return logits, scores, idx
    return _patched


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24, help="言語あたりのウィンドウ数（凍結は 24 まで）")
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--conds", type=str, default=",".join(ORDER))
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--tag", type=str, default="p7")
    args = ap.parse_args()

    conds = [c.strip() for c in args.conds.split(",") if c.strip()]
    for c in conds:
        if c not in CONDS:
            raise SystemExit("unknown cond: %s" % c)
    n_win = 1 if args.smoke else args.windows

    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[1/4] loading model: " + args.model)
    t0 = time.time()
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        torch_dtype=torch.bfloat16,
        device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      loaded in %.0f s" % (time.time() - t0))

    n_layers = int(model.config.num_hidden_layers)
    n_experts = int(model.config.num_experts)
    log("      experts=%d layers=%d top_k=%d" % (n_experts, n_layers,
                                                 int(model.config.num_experts_per_tok)))

    gates = [layer.mlp.gate for layer in model.model.layers]
    # accelerate が差し替えた後の forward を保存（クラス側パッチは効かない）
    orig_fwd = [g.forward for g in gates]

    # ルーティング統計（保持質量・8 番目の重み）
    stats = {"mass": [], "w8": []}

    def make_hook():
        def hook(module, inp, out):
            s = out[1].detach().float()
            stats["mass"].append(s.sum(-1).cpu())
            stats["w8"].append(s[:, -1].cpu())
        return hook

    handles = [g.register_forward_hook(make_hook()) for g in gates]

    log("[2/4] corpus (frozen)")
    seqs = load_frozen(n_win, args.len)
    lang_arr = np.array([lg for lg, _ in seqs])
    log("      %d windows x %d = %d tokens (%d en / %d ja)"
        % (len(seqs), args.len, len(seqs) * args.len,
           int((lang_arr == "en").sum()), int((lang_arr == "ja").sum())))

    log("[3/4] forward")
    res = {}
    for cname in conds:
        spec = CONDS[cname]
        for i, g in enumerate(gates):
            mods = spec.get(i, [])
            g.forward = make_scaled(orig_fwd[i], mods) if mods else orig_fwd[i]
        stats["mass"].clear()
        stats["w8"].clear()
        nll_c, acc_c = [], []
        t1 = time.time()
        with torch.no_grad():
            for lg, ids in seqs:
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                logit = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(logit, tgt, reduction="none")
                true_l = logit.gather(1, tgt.unsqueeze(-1))
                rank = (logit > true_l).sum(dim=-1) + 1
                acc_c.append((rank == 1).float().cpu().numpy())
                nll_c.append(nll.cpu().numpy())
                del out, logit, rank
        nll = np.concatenate(nll_c)
        mass = torch.cat(stats["mass"]).numpy()
        w8 = torch.cat(stats["w8"]).numpy()
        res[cname] = {"nll": nll, "acc1": np.concatenate(acc_c),
                      "mass": mass, "w8": w8}
        log("      %-5s CE %.5f  top1 %.4f  mass %.4f  w8 %.4f  (%.0f s)"
            % (cname, nll.mean(), res[cname]["acc1"].mean(), mass.mean(),
               w8.mean(), time.time() - t1))

    for h in handles:
        h.remove()

    log("[4/4] summary")
    base = res["base"]["nll"] if "base" in res else res[conds[0]]["nll"]
    out = {"model": args.model, "n_windows_per_lang": n_win, "window_len": args.len,
           "n_tokens": int(base.size), "n_layers": n_layers,
           "n_experts": n_experts, "conds": conds, "results": {}}
    for cname in conds:
        r = res[cname]
        row = {"ce": float(r["nll"].mean()),
               "ppl": float(np.exp(r["nll"].mean())),
               "top1": float(r["acc1"].mean()),
               "mass_kept": float(r["mass"].mean()),
               "w8": float(r["w8"].mean()),
               "per_lang": {}}
        for lg in ("en", "ja"):
            sel = (lang_arr == lg)
            row["per_lang"][lg] = float(r["nll"].reshape(len(seqs), -1)[sel].mean())
        if cname != conds[0]:
            row["delta_ce"] = paired(r["nll"], base)
            row["delta_top1"] = paired(r["acc1"], res[conds[0]]["acc1"])
        out["results"][cname] = row

    np.savez_compressed(os.path.join(HERE, "%s_granularity.npz" % args.tag),
                        **{"nll_%s" % c: res[c]["nll"] for c in conds},
                        **{"acc1_%s" % c: res[c]["acc1"] for c in conds},
                        **{"mass_%s" % c: res[c]["mass"] for c in conds},
                        lang=lang_arr)
    with open(os.path.join(HERE, "%s_granularity.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)

    log("")
    log("%-6s %10s %8s %10s %8s %8s" % ("cond", "CE", "dCE", "t", "top1", "mass"))
    for cname in conds:
        r = out["results"][cname]
        d = r.get("delta_ce")
        log("%-6s %10.5f %8s %10s %8.4f %8.4f" % (
            cname, r["ce"],
            ("%+.5f" % d["mean"]) if d else "  (base)",
            ("%+.1f" % d["t"]) if d else "",
            r["top1"], r["mass_kept"]))
    log("saved: %s_granularity.npz / %s_granularity.json" % (args.tag, args.tag))


if __name__ == "__main__":
    main()
