#!/usr/bin/env python3
"""A2: 仮説「sigmoid は質量介入である」の検証。

`考察_HMoEに最適な活性化関数_20261101.md` §5 の予測を測る。要点は
**ルータの活性化は expert の選択を変えず、重みと質量だけを変える**という主張。

2×2 で切る（選択は 4 変種で同一、変わるのは重みと質量だけ）
  arm        router    top-k 正規化   Σ_i g_i
  sm_norm    softmax   on             1.000（現行 = A1 の relu アームと同一）
  sig_norm   sigmoid   on             1.000
  sig_raw    sigmoid   off            Σσ(z_i)（トークン依存）
  sm_raw     softmax   off            Σ_{i∈topk} softmax(z)_i（トークン依存、除外 expert の分だけ減る）

予測（P6c の機構から）
  - sm_norm と sig_norm は質量が同じ 1.0 → **較正ギャップは動かない**はず。
    「sigmoid は質量介入」が正しいなら、正規化版では介入にならない。
  - sig_raw と sm_raw だけ質量が動く → ギャップが動くはず。
  - 精度（instr_valid）は 4 本とも動かないはず（質量は内容ではない）。

測るもの
  ゲート質量（層平均、トークンごと）/ 最大ゲート / 予測確信度 / 較正ギャップ /
  logit RMS / 最終層 h の RMS / CE / instr_valid

出力: data/a2/{arm}_s{seed}.json, ptok_{arm}_s{seed}.npy, a2_results.json, a2_summary.csv
"""
import argparse
import json
import math
import os
import sys
import time
import traceback

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

import q1_trace_routing as Q1                        # noqa: E402
import a1_activation_ffn as A1                       # noqa: E402
from a1_activation_ffn import ActMoE, Adam, BASE_W   # noqa: E402

OUTDIR = os.path.join(HERE, "data", "a2")

ARMS = {
    "sm_norm":  dict(router="sm",  norm=True),
    "sig_norm": dict(router="sig", norm=True),
    "sig_raw":  dict(router="sig", norm=False),
    "sm_raw":   dict(router="sm",  norm=False),
}


def make_model(arm, seed):
    c = ARMS[arm]
    return ActMoE(BASE_W, "relu", seed=seed, router=c["router"], norm=c["norm"])


@torch.no_grad()
def selection_identity(n_seq=64):
    """同一の logits に対して 4 変種の選択が一致することを確かめる（学習前）。"""
    torch.manual_seed(0)
    m = ActMoE(BASE_W, "relu", seed=0)
    rng = np.random.default_rng(999)
    seq, _ = Q1.make_trace_batch(rng, n_seq)
    x = torch.from_numpy(seq)
    B, T = x.shape
    h = (m.p["emb.w"][x] + m.p["pos.w"][:T]).reshape(B * T, -1)
    logits = F.linear(h, m.p["l0.r.w"], m.p["l0.r.b"])
    topv, topi = logits.topk(m.k, dim=1)
    res = {}
    base_set = None
    for arm, c in ARMS.items():
        m.router, m.norm, m.mass_log = c["router"], c["norm"], []
        g = m.gate_of(logits, topv, topi)
        mass = g.sum(1)
        res[arm] = dict(mass_mean=float(mass.mean()), mass_sd=float(mass.std()),
                        mass_min=float(mass.min()), mass_max=float(mass.max()),
                        gate_max_mean=float(g.max(1).values.mean()))
        key = topi.cpu().numpy()
        if base_set is None:
            base_set = key
        else:
            res[arm]["selection_identical"] = bool((key == base_set).all())
    m.mass_log = None
    return res


@torch.no_grad()
def evaluate(model, seq, typ, bs=128):
    n = seq.shape[0]
    W = Q1.T_LEN - Q1.TRACE0
    ce = np.zeros((n, W), dtype=np.float32)
    hit = np.zeros((n, W), dtype=bool)
    conf = np.zeros((n, W), dtype=np.float32)
    mass = np.zeros((n, W), dtype=np.float32)
    logit_rms, h_rms = [], []
    for i in range(0, n, bs):
        s = slice(i, min(i + bs, n))
        x = torch.from_numpy(seq[s])
        model.mass_log = []
        logits, _, _ = model(x, aux_mode="none")
        ms = torch.stack(model.mass_log).mean(0)        # 層平均 (N,)
        model.mass_log = None
        lg = logits[:, Q1.TRACE0 - 1:-1, :len(Q1.VOCAB)]
        tgt = torch.from_numpy(seq[s, Q1.TRACE0:])
        pr = lg.softmax(-1)
        ce[s] = F.cross_entropy(lg.reshape(-1, len(Q1.VOCAB)), tgt.reshape(-1),
                                reduction="none").reshape(-1, W).numpy()
        hit[s] = (pr.argmax(-1).numpy() == tgt.numpy())
        conf[s] = pr.max(-1).values.numpy()
        mass[s] = ms.numpy().reshape(-1, Q1.T_LEN)[:, Q1.TRACE0:]
        logit_rms.append(float(lg.pow(2).mean().sqrt()))
        h_rms.append(float(logits.pow(2).mean().sqrt()))
    ty = typ[:, Q1.TRACE0:]
    m_st, m_pl = (ty == Q1.TYP_STRUCT), (ty == Q1.TYP_PAYLOAD)
    hp = hit.reshape(n, Q1.P_STEPS, Q1.TPI)[:, :, 2:]
    instr_ok = hp.all(-1)
    acc = float(hit.mean())
    c = float(conf.mean())
    acc_pl = float(hit[m_pl].mean())
    c_pl = float(conf[m_pl].mean())
    return {
        "ce_all": float(ce.mean()),
        "ce_payload": float(ce[m_pl].mean()),
        "acc_all": acc,
        "acc_payload": acc_pl,
        "instr_valid": float(instr_ok.all(-1).mean()),
        "conf_all": c,
        "conf_payload": c_pl,
        "gap_all": c - acc,
        "gap_payload": c_pl - acc_pl,
        "mass_mean": float(mass.mean()),
        "mass_sd": float(mass.std()),
        "mass_p05": float(np.percentile(mass, 5)),
        "mass_p95": float(np.percentile(mass, 95)),
        "logit_rms": float(np.mean(logit_rms)),
        "out_rms": float(np.mean(h_rms)),
    }, ce, conf, mass, hit


def run_one(arm, seed, n_seqs, epochs, bs, lr, auxw, eval_every=1):
    torch.set_num_threads(1)
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    model = make_model(arm, seed)
    opt = Adam(model.params(), lr=lr)
    nparam = sum(v.numel() for v in model.params().values())

    # 学習前の質量（初期化点）
    ev_rng = np.random.default_rng(777)
    ev_seq, ev_typ = Q1.make_trace_batch(ev_rng, 1024)
    init_ev, _, _, _, _ = evaluate(model, ev_seq, ev_typ)

    steps_per_ep = max(1, n_seqs // bs)
    t0 = time.time()
    hist, evals = [], []
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps_per_ep):
            seq, _ = Q1.make_trace_batch(rng, bs)
            x = torch.from_numpy(seq)
            logits, aux, _ = model(x, aux_mode="p_pen")
            loss = Q1.trace_loss(logits, seq) + auxw * aux
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        hist.append(run / steps_per_ep)
        if (ep + 1) % eval_every == 0 or ep == epochs - 1:
            ev, ce, cf, ms, ht = evaluate(model, ev_seq, ev_typ)
            ev["ep"] = ep + 1
            evals.append(ev)

    out = {"arm": arm, "seed": seed, "router": ARMS[arm]["router"],
           "norm": ARMS[arm]["norm"], "nparam": nparam, "loss_hist": hist,
           "evals": evals, "init_eval": init_ev, "sec": round(time.time() - t0, 1)}
    os.makedirs(OUTDIR, exist_ok=True)
    np.savez_compressed(os.path.join(OUTDIR, f"ptok_{arm}_s{seed}.npz"),
                        ce=ce, conf=cf, mass=ms, hit=ht)
    with open(os.path.join(OUTDIR, f"{arm}_s{seed}.json"), "w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=2)
    return out


def _worker(job):
    arm, seed, kw = job
    try:
        return run_one(arm, seed, **kw)
    except Exception:
        return {"arm": arm, "seed": seed, "error": traceback.format_exc()}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--arms", nargs="+", default=list(ARMS))
    ap.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4, 5])
    ap.add_argument("--seqs", type=int, default=3000)
    ap.add_argument("--epochs", type=int, default=3)
    ap.add_argument("--bs", type=int, default=32)
    ap.add_argument("--lr", type=float, default=2e-3)
    ap.add_argument("--auxw", type=float, default=0.05)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--smoke", action="store_true")
    args = ap.parse_args()

    os.makedirs(OUTDIR, exist_ok=True)
    if args.smoke:
        args.arms, args.seeds, args.epochs, args.workers = ["sm_norm", "sig_raw"], [0], 1, 2

    ident = selection_identity()
    print("=== 選択の同一性（学習前、同一 logits）===", flush=True)
    for a, v in ident.items():
        print(f"  {a:9s} mass={v['mass_mean']:.4f}±{v['mass_sd']:.4f} "
              f"[{v['mass_min']:.3f},{v['mass_max']:.3f}] "
              f"gate_max={v['gate_max_mean']:.3f} "
              f"selection_identical={v.get('selection_identical', 'base')}", flush=True)
    with open(os.path.join(OUTDIR, "a2_identity.json"), "w", encoding="utf-8") as fh:
        json.dump(ident, fh, ensure_ascii=False, indent=2)

    kw = dict(n_seqs=args.seqs, epochs=args.epochs, bs=args.bs, lr=args.lr, auxw=args.auxw,
              eval_every=1)
    jobs = [(a, s, kw) for a in args.arms for s in args.seeds]
    print(f"\njobs={len(jobs)} epochs={args.epochs} workers={args.workers}", flush=True)

    from concurrent.futures import ProcessPoolExecutor, as_completed
    rows, t0 = [], time.time()
    with ProcessPoolExecutor(max_workers=args.workers) as ex:
        futs = {ex.submit(_worker, j): j for j in jobs}
        for k, fu in enumerate(as_completed(futs), 1):
            r = fu.result()
            if "error" in r:
                print(f"[FAIL] {r['arm']} s{r['seed']}\n{r['error']}", flush=True)
                continue
            rows.append(r)
            e = r["evals"][-1]
            print(f"[{k}/{len(jobs)}] {r['arm']:9s} s{r['seed']} CE={e['ce_all']:.4f} "
                  f"iv={e['instr_valid']:.3f} mass={e['mass_mean']:.3f}±{e['mass_sd']:.3f} "
                  f"gap={e['gap_all']:+.3f} ({r['sec']:.0f}s, tot {time.time()-t0:.0f}s)",
                  flush=True)

    with open(os.path.join(OUTDIR, "a2_results.json"), "w", encoding="utf-8") as fh:
        json.dump(rows, fh, ensure_ascii=False, indent=2)
    print(f"\n[write] {OUTDIR} ({time.time()-t0:.0f}s)", flush=True)
    os._exit(0)


if __name__ == "__main__":
    main()
