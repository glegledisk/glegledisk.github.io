# -*- coding: utf-8 -*-
"""p6h_layer_rescale_analysis.py — 層の非対称性は質量で説明できるか（GPU 不要）

非対称性（後半を削る方が p を押し上げる）を
    total   = p(f8b6)    - p(f6b8)
    content = p(f8b6_rs) - p(f6b8_rs)      rescale 後も残る
    mass    = total - content              質量を戻すと消える
に分解する。total = content + mass は恒等的。

出力: p6h_analysis.json / p6h_out_utf8.txt / p6h_layer_rescale.png
"""
import json
import math

import numpy as np

LOG = []


def log(s):
    print(s, flush=True)
    LOG.append(str(s))


def ttest(a, b):
    d = np.asarray(a, float) - np.asarray(b, float)
    n = d.size
    se = d.std(ddof=1) / math.sqrt(n)
    return float(d.mean()), float(se), float(d.mean() / se) if se > 0 else float("nan")


def ece(p, y, nbins=10):
    edges = np.linspace(0.0, 1.0, nbins + 1)
    b = np.clip(np.digitize(p, edges) - 1, 0, nbins - 1)
    tot = 0.0
    for i in range(nbins):
        m = b == i
        if m.sum() == 0:
            continue
        tot += m.sum() / p.size * abs(y[m].mean() - p[m].mean())
    return float(tot)


z = np.load("p6g_layer_rescale.npz", allow_pickle=True)
CONDS = ["base", "f6b8", "f6b8_rs", "f8b6", "f8b6_rs"]
OUT = {"n_tokens": int(z["base_nll"].size)}

log("tokens=%d" % z["base_nll"].size)
log("")
log("=== 1. 水準 ===")
log("%-9s %9s %9s %9s %10s %8s %10s %9s" %
    ("cond", "CE", "p_top1", "acc", "gap(pt)", "ECE(pt)", "Brier", "mass"))
tab = {}
for c in CONDS:
    p = z["%s_ptop1" % c].astype(float)
    y = z["%s_top1" % c].astype(float)
    tab[c] = dict(ce=float(z["%s_nll" % c].astype(float).mean()),
                  p=float(p.mean()), acc=float(y.mean()),
                  gap=float(p.mean() - y.mean()), ece=ece(p, y),
                  brier=float(np.mean((p - y) ** 2)),
                  mass=float(z["%s_kept_mass_by_layer" % c].mean()))
    log("%-9s %9.5f %9.4f %9.4f %+10.2f %8.2f %10.5f %9.4f"
        % (c, tab[c]["ce"], tab[c]["p"], tab[c]["acc"], 100 * tab[c]["gap"],
           100 * tab[c]["ece"], tab[c]["brier"], tab[c]["mass"]))
OUT["levels"] = tab

log("")
log("=== 2. 削る場所で何が違うか（base からの変化） ===")
log("%-9s %12s %12s %12s %12s" % ("cond", "dCE", "dp_top1", "d(acc)", "d(gap)pt"))
for c in CONDS[1:]:
    log("%-9s %+12.5f %+12.5f %+12.5f %+12.2f"
        % (c, tab[c]["ce"] - tab["base"]["ce"], tab[c]["p"] - tab["base"]["p"],
           tab[c]["acc"] - tab["base"]["acc"],
           100 * (tab[c]["gap"] - tab["base"]["gap"])))

log("")
log("=== 3. 非対称性（f8b6 - f6b8）と rescale での分解 ===")


def asym(hi, lo, key):
    return tab[hi][key] - tab[lo][key]


rows = {}
for key, label, scale in (("p", "p_top1", 1.0), ("gap", "較正ギャップ(pt)", 100.0),
                          ("ce", "CE", 1.0), ("acc", "正解率", 1.0)):
    tot = scale * asym("f8b6", "f6b8", key)
    con = scale * asym("f8b6_rs", "f6b8_rs", key)
    mas = tot - con
    rows[key] = dict(total=tot, content=con, mass=mas,
                     share_content=con / tot if tot != 0 else float("nan"))
    log("  %-16s total %+9.5f = content %+9.5f (%6.1f%%) + mass %+9.5f"
        % (label, tot, con, 100 * rows[key]["share_content"], mas))
OUT["asym_decomp"] = rows

log("")
log("=== 4. 対応検定 ===")
PAIRS = [("f8b6", "f6b8", "非対称性（rescale なし）"),
         ("f8b6_rs", "f6b8_rs", "非対称性（rescale あり）"),
         ("f6b8", "f6b8_rs", "前半削りへの rescale"),
         ("f8b6", "f8b6_rs", "後半削りへの rescale")]
pairs = {}
for a, b, label in PAIRS:
    pa, ya = z["%s_ptop1" % a].astype(float), z["%s_top1" % a].astype(float)
    pb, yb = z["%s_ptop1" % b].astype(float), z["%s_top1" % b].astype(float)
    rec = {}
    for nm, xa, xb in (("CE", z["%s_nll" % a], z["%s_nll" % b]),
                       ("p", pa, pb), ("acc", ya, yb), ("gap", pa - ya, pb - yb)):
        m, se, t = ttest(xa, xb)
        rec[nm] = dict(d=m, se=se, t=t)
    pairs["%s-%s" % (a, b)] = rec
    log("  %-24s CE %+.5f (t=%+.2f) | p %+.5f (t=%+.2f) | acc %+.5f (t=%+.2f) | gap %+.5f (t=%+.2f)"
        % (label, rec["CE"]["d"], rec["CE"]["t"], rec["p"]["d"], rec["p"]["t"],
           rec["acc"]["d"], rec["acc"]["t"], rec["gap"]["d"], rec["gap"]["t"]))
OUT["pairs"] = pairs

log("")
log("=== 5. 層別の保持質量（どこで失っているか） ===")
log("%3s %8s %8s %8s %8s %8s" % ("L", "base", "f6b8", "f6b8_rs", "f8b6", "f8b6_rs"))
km = {c: z["%s_kept_mass_by_layer" % c] for c in CONDS}
for i in range(len(km["base"])):
    log("%3d %8.4f %8.4f %8.4f %8.4f %8.4f"
        % (i, km["base"][i], km["f6b8"][i], km["f6b8_rs"][i], km["f8b6"][i], km["f8b6_rs"][i]))
front = slice(0, 8)
back = slice(8, 16)
for c in CONDS[1:]:
    lost_f = km["base"][front].mean() - km[c][front].mean()
    lost_b = km["base"][back].mean() - km[c][back].mean()
    log("  %-9s 失った質量: 前半 %.4f / 後半 %.4f / 合計 %.4f"
        % (c, lost_f, lost_b, 8 * lost_f + 8 * lost_b))
    OUT.setdefault("mass_loss", {})[c] = dict(front=float(lost_f), back=float(lost_b),
                                             total=float(8 * lost_f + 8 * lost_b))

log("")
log("=== 6. 運用指標（tau=0.8） ===")
log("%-9s %10s %10s %10s" % ("cond", "自動化率", "自動化内誤り", "全体コスト"))
ops = {}
for c in CONDS:
    p = z["%s_ptop1" % c].astype(float)
    y = z["%s_top1" % c].astype(float)
    commit = p >= 0.8
    cost = commit * (1 - y) + 0.2 * (~commit)
    ops[c] = dict(rate=float(commit.mean()),
                  err=float((1 - y)[commit].mean()) if commit.sum() else float("nan"),
                  cost=float(cost.mean()))
    log("%-9s %10.4f %10.4f %10.5f" % (c, commit.mean(), ops[c]["err"], cost.mean()))
OUT["ops"] = ops

with open("p6h_analysis.json", "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=2)
with open("p6h_out_utf8.txt", "w", encoding="utf-8") as f:
    f.write("\n".join(LOG))

# ---------------------------------------------------------------- 図
try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(1, 2, figsize=(11.5, 4.3), dpi=140)
    xs = np.arange(2)
    keys = [("p", "p_top1 (x100)"), ("gap", "calib gap (pt)")]
    con = [rows[k]["content"] * (100 if k == "p" else 1) for k, _ in keys]
    mas = [rows[k]["mass"] * (100 if k == "p" else 1) for k, _ in keys]
    ax[0].bar(xs, con, 0.45, label="content (survives rescale)", color="C3")
    ax[0].bar(xs, mas, 0.45, bottom=con, label="mass (removed by rescale)", color="C0")
    ax[0].axhline(0, color="k", lw=0.8)
    for x, cc, mm in zip(xs, con, mas):
        ax[0].annotate("content %+.3f" % cc, (x, cc), textcoords="offset points",
                       xytext=(0, -14), ha="center", fontsize=8, color="C3")
        ax[0].annotate("total %+.3f" % (cc + mm), (x, cc + mm), textcoords="offset points",
                       xytext=(0, 4), ha="center", fontsize=8)
    ax[0].set_xticks(xs)
    ax[0].set_xticklabels([l for _, l in keys])
    ax[0].set_ylabel("asymmetry: back-cut minus front-cut")
    ax[0].set_title("Is the layer asymmetry mass-driven?")
    ax[0].legend(fontsize=8)
    ax[0].grid(alpha=0.3, axis="y")

    for c, col, ls in (("base", "gray", "-"), ("f6b8", "C2", "--"), ("f6b8_rs", "C2", "-"),
                       ("f8b6", "C3", "--"), ("f8b6_rs", "C3", "-")):
        ax[1].plot(km[c], ls, color=col, marker="o", ms=3, lw=1.2, label=c,
                   alpha=0.95 if "rs" in c or c == "base" else 0.55)
    ax[1].axvline(7.5, color="k", lw=0.6, ls=":")
    ax[1].set_xlabel("layer (dotted = front/back boundary)")
    ax[1].set_ylabel("kept routing mass")
    ax[1].set_title("Where the mass is lost, and where it is restored")
    ax[1].legend(fontsize=7, ncol=2)
    ax[1].grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig("p6h_layer_rescale.png")
    log("\nsaved p6h_layer_rescale.png")
except Exception as e:
    log("figure failed: %s" % e)
