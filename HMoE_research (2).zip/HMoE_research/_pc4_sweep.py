# -*- coding: utf-8 -*-
"""KD 掃引（kd_w × T）の水準と対応差を並べ直す。"""
import json
import os
import re

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
j = json.load(open(os.path.join(HERE, "pc2_results_n15k_kdsweep.json"), encoding="utf-8"))
rows = j["rows"]
by = {}
for r in rows:
    by.setdefault(r["cfg"], {})[r["seed"]] = r


def parse(cfg):
    m = re.search(r"\+kd_w([0-9.]+)_T([0-9.]+)", cfg)
    return (float(m.group(1)), float(m.group(2))) if m else (None, None)


print("== 水準（N=1.5e4, per_key=2, 10ep, lr 5e-4, n=2, 生徒 W=512, 教師 W=1024）==")
print("  %-26s %8s %8s %8s %8s %9s" % ("cfg", "CE", "sd", "acc", "clip", "KD ep1→10"))
ref = by.get("half:scratch", {})
order = [c for c in by if c != "half:scratch"]
order.sort(key=lambda c: (parse(c)[1] or 0, parse(c)[0] or 0))
for cfg in ["half:scratch"] + order:
    d = by[cfg]
    ce = np.array([v["ce"] for v in d.values()])
    acc = np.array([v["acc"] for v in d.values()])
    cl = np.mean([v["n_clip"] for v in d.values()])
    kd1 = np.mean([v["ce_hist"][0]["kd"] for v in d.values() if v["ce_hist"][0]["kd"] is not None])
    kd10 = np.mean([v["ce_hist"][-1]["kd"] for v in d.values() if v["ce_hist"][-1]["kd"] is not None])
    print("  %-26s %8.4f %8.4f %8.4f %8.0f %9s"
          % (cfg, ce.mean(), ce.std(ddof=1) if len(ce) > 1 else float("nan"),
             acc.mean(), cl,
             ("%.3f→%.3f" % (kd1, kd10)) if kd1 == kd1 else "-"))

print("\n== 各 KD 腕 − scratch（対照は同一プロセス・同一 seed）==")
base = {s: v["ce"] for s, v in ref.items()}
for cfg in order:
    d = by[cfg]
    ks = sorted(set(d) & set(base))
    x = np.array([d[k]["ce"] for k in ks])
    y = np.array([base[k] for k in ks])
    diff = x - y
    t, p = stats.ttest_rel(x, y)
    se = diff.std(ddof=1) / np.sqrt(len(diff))
    w, T = parse(cfg)
    print("  w=%-4s T=%-4s  ΔCE %+0.4f  se %.4f  t %+0.2f  p %.4f  n %d  負 %d"
          % (w, T, diff.mean(), se, t, p, len(diff), int((diff < 0).sum())))

print("\n== 最良の腕 vs 初期化（prune）==")
if "half:prune" in by:
    pr = {s: v["ce"] for s, v in by["half:prune"].items()}
    best = None
    for cfg in order:
        d = by[cfg]
        ks = sorted(set(d) & set(pr))
        diff = np.array([d[k]["ce"] - pr[k] for k in ks])
        if best is None or diff.mean() < best[1]:
            best = (cfg, diff.mean())
    print("  最良の KD 腕 = %s（prune との差 %+0.4f）" % (best[0], best[1]))
