#!/usr/bin/env python3
"""Q3 の解析: payload 率（80/67/50/33%）に対する Δ（小 expert 選択率 payload − struct）の応答。

入力: simulation_hmoe_mmlu/data/q3/H+LB_ts{T}_s{seed}.json
出力: data/q3/q3_analysis.json / 標準出力に表
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
QDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q3")

ARM = "H+LB"
TSTRUCTS = [2, 4, 8, 16]
SEEDS = [0, 1, 2, 3, 4, 5]


def load(ts, seed):
    p = os.path.join(QDIR, f"{ARM}_ts{ts}_s{seed}.json")
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8") as f:
        r = json.load(f)
    if r.get("n_eval") != 1024:
        return None
    return r


def available_seeds():
    """全 ts に揃っている seed だけ返す（欠けた seed は解析から落とす）。"""
    ok = []
    for s in SEEDS:
        if all(load(ts, s) is not None for ts in TSTRUCTS):
            ok.append(s)
    return ok


def stat(xs):
    a = np.asarray(xs, dtype=float)
    n = len(a)
    m = float(a.mean())
    sd = float(a.std(ddof=1)) if n > 1 else float("nan")
    se = sd / np.sqrt(n) if n > 1 else float("nan")
    t = m / se if se and se > 0 else float("nan")
    return m, sd, se, t


def main():
    seeds = available_seeds()
    print(f"[seeds] {seeds} (n={len(seeds)})")
    by_ts = {}
    for ts in TSTRUCTS:
        rows = [load(ts, s) for s in seeds]
        if not rows or any(r is None for r in rows):
            print(f"[skip] ts={ts}: 欠けている seed がある")
            continue
        b = [r["eval"]["base"] for r in rows]
        d = [x["small_payload"] - x["small_struct"] for x in b]
        dw = [x["width_payload"] - x["width_struct"] for x in b]
        m, sd, se, t = stat(d)
        by_ts[ts] = {
            "payload_frac": rows[0]["payload_frac"],
            "T": rows[0]["T"],
            "acc_struct": [x["acc_struct"] for x in b],
            "acc_payload": [x["acc_payload"] for x in b],
            "ce_struct": [x["ce_struct"] for x in b],
            "ce_payload": [x["ce_payload"] for x in b],
            "small_struct": [x["small_struct"] for x in b],
            "small_payload": [x["small_payload"] for x in b],
            "width_struct": [x["width_struct"] for x in b],
            "width_payload": [x["width_payload"] for x in b],
            "d": d, "d_mean": m, "d_sd": sd, "d_se": se, "d_t": t,
            "sign_positive": int(sum(x > 0 for x in d)),
            "dw_mean": float(np.mean(dw)),
            "seq_valid": [x["seq_valid"] for x in b],
            "instr_valid": [x["instr_valid"] for x in b],
            "small_struct_l": [x["small_struct_l"] for x in b],
            "small_payload_l": [x["small_payload_l"] for x in b],
            "force_small_acc": [r["eval"]["force_small"]["acc_payload"] for r in rows],
        }

    # 対応差（同一 seed）
    paired = {}
    for ts in TSTRUCTS:
        if ts == TSTRUCTS[0] or ts not in by_ts or TSTRUCTS[0] not in by_ts:
            continue
        diff = np.array(by_ts[ts]["d"]) - np.array(by_ts[TSTRUCTS[0]]["d"])
        m, sd, se, t = stat(diff)
        # 連続量（幅）の対応差も出す — 二値より検出力が高い
        dws = np.array(by_ts[ts]["width_struct"]) - np.array(by_ts[TSTRUCTS[0]]["width_struct"])
        dwp = np.array(by_ts[ts]["width_payload"]) - np.array(by_ts[TSTRUCTS[0]]["width_payload"])
        mws, _, sews, tws = stat(dws)
        mwp, _, sewp, twp = stat(dwp)
        paired[f"ts{ts}_minus_ts{TSTRUCTS[0]}"] = {
            "diff": diff.tolist(), "mean": m, "sd": sd, "se": se, "t": t,
            "n_negative": int((diff < 0).sum()), "n": int(len(diff)),
            "dwidth_struct": dws.tolist(), "dwidth_struct_mean": mws,
            "dwidth_struct_se": sews, "dwidth_struct_t": tws,
            "dwidth_struct_negative": int((dws < 0).sum()),
            "dwidth_payload": dwp.tolist(), "dwidth_payload_mean": mwp,
            "dwidth_payload_se": sewp, "dwidth_payload_t": twp,
            "dwidth_payload_positive": int((dwp > 0).sum()),
        }

    # 傾き（per-seed で Δ ~ frac の最小二乗）
    slopes = []
    fracs = [by_ts[ts]["payload_frac"] for ts in TSTRUCTS if ts in by_ts]
    for i, seed in enumerate(seeds):
        ys = [by_ts[ts]["d"][i] for ts in TSTRUCTS if ts in by_ts]
        if len(ys) == len(fracs):
            slopes.append(float(np.polyfit(fracs, ys, 1)[0]))
    sm, ssd, sse, st = stat(slopes) if slopes else (float("nan"),) * 4

    # 両側符号検定（傾きの符号が偏っているか）
    from math import comb
    kpos = sum(x > 0 for x in slopes)
    nn = len(slopes)
    kk = min(kpos, nn - kpos)
    p_sign = min(1.0, 2 * sum(comb(nn, i) for i in range(kk + 1)) / 2 ** nn) if nn else float("nan")

    out = {"by_ts": by_ts, "paired": paired,
           "slope_per_seed": slopes, "slope_mean": sm, "slope_sd": ssd,
           "slope_se": sse, "slope_t": st, "slope_sign_p": p_sign,
           "n_slope_positive": int(kpos), "n_seed": nn}

    with open(os.path.join(QDIR, "q3_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print(f"\n{'ts':>3} {'frac':>5} {'T':>4} {'acc_st':>7} {'acc_pl':>7} "
          f"{'CE_pl':>7} {'sm_st':>6} {'sm_pl':>6} {'Δ':>7} {'se':>6} {'t':>7} {'+':>3} "
          f"{'wid_st':>7} {'wid_pl':>7} {'valid':>6}")
    for ts in TSTRUCTS:
        if ts not in by_ts:
            continue
        r = by_ts[ts]
        print(f"{ts:>3} {r['payload_frac']:>5.2f} {r['T']:>4} "
              f"{np.mean(r['acc_struct']):>7.3f} {np.mean(r['acc_payload']):>7.3f} "
              f"{np.mean(r['ce_payload']):>7.3f} "
              f"{np.mean(r['small_struct']):>6.3f} {np.mean(r['small_payload']):>6.3f} "
              f"{r['d_mean']:>+7.3f} {r['d_se']:>6.3f} {r['d_t']:>+7.2f} "
              f"{r['sign_positive']}/{len(seeds)} "
              f"{np.mean(r['width_struct']):>7.1f} {np.mean(r['width_payload']):>7.1f} "
              f"{np.mean(r['seq_valid']):>6.3f}")

    print("\nper-seed Δ:")
    for ts in TSTRUCTS:
        if ts in by_ts:
            print(f"  ts{ts:<3} " + "  ".join(f"{x:+.3f}" for x in by_ts[ts]["d"]))

    print("\n対応差（同一 seed）:")
    for k, v in paired.items():
        print(f"  {k:22s} Δ {v['mean']:+.3f}  se {v['se']:.3f}  t {v['t']:+.2f}  "
              f"負 {v['n_negative']}/{v['n']}")
        print(f"  {'':22s} width_struct {v['dwidth_struct_mean']:+.1f}  "
              f"se {v['dwidth_struct_se']:.1f}  t {v['dwidth_struct_t']:+.2f}  "
              f"負 {v['dwidth_struct_negative']}/{v['n']}")
        print(f"  {'':22s} width_payload {v['dwidth_payload_mean']:+.1f}  "
              f"se {v['dwidth_payload_se']:.1f}  t {v['dwidth_payload_t']:+.2f}  "
              f"正 {v['dwidth_payload_positive']}/{v['n']}")

    print("\nper-seed width_struct / width_payload:")
    for ts in TSTRUCTS:
        if ts in by_ts:
            print(f"  ts{ts:<3} st " + " ".join(f"{x:6.1f}" for x in by_ts[ts]["width_struct"]) +
                  "   pl " + " ".join(f"{x:6.1f}" for x in by_ts[ts]["width_payload"]))

    print(f"\n傾き（Δ per payload 率, per-seed）: "
          f"{', '.join(f'{x:+.2f}' for x in slopes)}  "
          f"mean {sm:+.2f}  se {sse:.2f}  t {st:+.2f}  正 {out['n_slope_positive']}/{len(slopes)}  "
          f"符号検定 p={p_sign:.3f}")

    print("\nforce_small の payload acc（参考）:")
    for ts in TSTRUCTS:
        if ts in by_ts:
            print(f"  ts{ts:<3} " + "  ".join(f"{x:.3f}" for x in by_ts[ts]["force_small_acc"]))


if __name__ == "__main__":
    main()
    sys.exit(0)
