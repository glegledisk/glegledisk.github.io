# -*- coding: utf-8 -*-
"""P15 解析: P14 の「反選択」と「アンダーコンフィデンス」は候補プールの汚染が作っていたか

新規生成なし。P14 の生データ（p14_bestofn.jsonl）の再解析。
P14 §7-5 / §9-1 が「次の最優先候補」と明記した対照を実行する。

対照設計:
  pool = all        … P14 そのまま（8 本全部を候補にする）
  pool = clean      … ntok < 96（打ち切りを「答えなし」として候補から外す。観測可能・GT 不要）
  pool = nans3      … n_ans >= 3（span が短すぎるものを外す。同じく観測可能）
  pool = rdrop      … 対照: clean と同じ本数をランダムに外す（プール縮小だけの効果）

規則:
  s1        … 1 本目（基準）
  rand      … プールから一様ランダムに 1 本（200 回平均）
  confmax   … p_ans 最大（P14 の反選択の再現）
  confmaxF  … p_full 最大（生成全体の幾何平均。P14 は取得したが未解析）
  maj       … 多数決。conf = 有効票プール内の得票率（share_pool）
  majnom    … 多数決。conf = 名目 N 分母の得票率（P14 の share。分母汚染の実証用）
  oracle    … pass@N（上限）

単位は (round, problem) = 40 ペア。対応差は ttest_1samp、正解率差は exact McNemar。
AUROC の CI は**問題単位のクラスタ bootstrap**（同一問題の 8 本は独立でない）。
出力: p15_analysis.json / p15_analysis_out_utf8.txt
"""

import argparse
import json
import os
import re
from collections import Counter

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = []


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def load(tag="p14"):
    recs, greedy = [], []
    with open(os.path.join(HERE, "%s_bestofn.jsonl" % tag), encoding="utf-8") as fp:
        for line in fp:
            line = line.strip()
            if not line:
                continue
            r = json.loads(line)
            (greedy if r.get("round") == "greedy" else recs).append(r)
    return recs, greedy


def auroc(scores, labels):
    s = np.asarray(scores, float)
    y = np.asarray(labels, bool)
    ok = np.isfinite(s)
    s, y = s[ok], y[ok]
    pos, neg = s[y], s[~y]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    d = (pos[:, None] > neg[None, :]).sum() + 0.5 * (pos[:, None] == neg[None, :]).sum()
    return float(d / (len(pos) * len(neg)))


def auroc_cluster(scores, labels, clusters, n_boot=2000, seed=0):
    """問題単位でリサンプルする bootstrap CI（8 本/問題の依存を吸収）。"""
    s = np.asarray(scores, float)
    y = np.asarray(labels, bool)
    cl_in = list(clusters)
    ok = np.isfinite(s)
    s, y = s[ok], y[ok]
    cl = [cl_in[i] for i in np.where(ok)[0]]
    point = auroc(s, y)
    uniq = sorted(set(cl))
    idx_by = {}
    for k, c in enumerate(cl):
        idx_by.setdefault(c, []).append(k)
    idx_by = {c: np.array(v) for c, v in idx_by.items()}
    rng = np.random.default_rng(seed)
    vals = []
    for _ in range(n_boot):
        pick = [uniq[j] for j in rng.integers(0, len(uniq), len(uniq))]
        idx = np.concatenate([idx_by[c] for c in pick])
        v = auroc(s[idx], y[idx])
        if np.isfinite(v):
            vals.append(v)
    if not vals:
        return point, (float("nan"), float("nan"))
    return point, (float(np.percentile(vals, 2.5)), float(np.percentile(vals, 97.5)))


def paired(arr):
    a = np.asarray(arr, float)
    a = a[np.isfinite(a)]
    assert len(a) > 1, "paired needs >=2"
    mean = float(np.mean(a))
    sd = float(np.std(a, ddof=1))
    se = sd / np.sqrt(len(a))
    if sd > 0:
        t, p = stats.ttest_1samp(a, 0.0)
        mde = float(2.802 * sd / np.sqrt(len(a)))
    else:
        t, p, mde = float("nan"), float("nan"), float("nan")
    return {"mean": mean, "se": float(se), "t": float(t), "p": float(p),
            "n": int(len(a)), "mde80": mde}


# ---------------- プール定義（すべて生成時に観測可能。gold を使わない） ----------------
POOLS = {
    "all": lambda s: True,
    "clean": lambda s: s["ntok"] < 96,
    "nans3": lambda s: s["n_ans"] >= 3,
}


def pick_confmax(sub, pool, key="p_ans"):
    cand = [(j, s) for j, s in enumerate(sub)
            if s[key] is not None and s["pred"] is not None and pool(s)]
    if not cand:
        return None
    return max(cand, key=lambda t: (t[1][key], -t[0]))[1]


def maj(sub, pool, nominal_n):
    cand = [s for s in sub if s["pred"] is not None and pool(s)]
    if not cand:
        return None
    by = {}
    for s in cand:
        by.setdefault(s["pred"], []).append(s)
    best = None
    for pred, lst in by.items():
        k = (len(lst), max(x["p_ans"] for x in lst))
        if best is None or k > best[0]:
            best = (k, pred, lst)
    _, pred, lst = best
    rep = max(lst, key=lambda s: s["p_ans"])
    return {"pred": pred, "share_pool": len(lst) / float(len(cand)),
            "share_nominal": len(lst) / float(nominal_n),
            "rep_conf": rep["p_ans"], "n_pool": len(cand)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tag", default="p14")
    ap.add_argument("--n_draw", type=int, default=200)
    args = ap.parse_args()

    recs, greedy = load(args.tag)
    rounds = sorted(set(r["round"] for r in recs))
    P = len([r for r in recs if r["round"] == rounds[0]])
    R = len(rounds)
    assert len(recs) == R * P
    for r in recs:
        m = re.match(r"Compute (\d+) \+ (\d+)\.", r["q"])
        assert m and str(int(m.group(1)) + int(m.group(2))) == r["gold"], r["q"]
        assert len(r["samples"]) == 8
    log("check: rounds=%d n_prob=%d pairs=%d" % (R, P, R * P))

    # ---------------- 0. プール汚染の構造 ----------------
    S = [s for r in recs for s in r["samples"]]
    n = len(S)
    ntok = np.array([s["ntok"] for s in S], float)
    nans = np.array([s["n_ans"] for s in S], float)
    corr = np.array([bool(s["correct"]) for s in S])
    trunc = ntok >= 96
    short = nans <= 2
    log("\n[0] pool contamination (samples=%d)" % n)
    log("  truncated (ntok==96): %d (%.3f)  acc=%.4f"
        % (int(trunc.sum()), trunc.mean(), corr[trunc].mean()))
    log("  complete            : %d (%.3f)  acc=%.4f"
        % (int((~trunc).sum()), (~trunc).mean(), corr[~trunc].mean()))
    log("  n_ans<=2            : %d (%.3f)  acc=%.4f  (subset of truncated: %s)"
        % (int(short.sum()), short.mean(), corr[short].mean(),
           bool(np.all(trunc[short]))))
    # プール汚染の会計: 名目分母だと得票率の上限が下がる
    junk_per_pair = np.array([sum(1 for s in r["samples"] if s["ntok"] >= 96)
                              for r in recs], float)
    log("  junk per pair: mean=%.3f  -> 名目 share の上限は平均 %.4f"
        % (junk_per_pair.mean(), float(np.mean((8 - junk_per_pair) / 8.0))))

    # ---------------- 1. 規則 × プールの (acc, conf, gap) ----------------
    rng = np.random.default_rng(7)
    cells = {}          # (pool, rule) -> {"acc":[...], "conf":[...], "ok":[...]}
    per_pair = []       # 対照用の生値
    for ri_idx, ri in enumerate(rounds):
        rec0 = [r for r in recs if r["round"] == ri]
        for i in range(P):
            r = rec0[i]
            sub, gold = r["samples"], r["gold"]
            per_pair.append({"round": ri, "i": i, "gold": gold, "sub": sub})
            s1 = sub[0]
            for pool_name, pool in POOLS.items():
                # s1 / oracle はプール非依存（各プール表に同じ値を並べる）
                cells.setdefault((pool_name, "s1"), {"acc": [], "conf": []})
                cells[(pool_name, "s1")]["acc"].append(float(s1["pred"] == gold))
                cells[(pool_name, "s1")]["conf"].append(s1["p_ans"])
                cells.setdefault((pool_name, "oracle"), {"acc": [], "conf": []})
                cells[(pool_name, "oracle")]["acc"].append(
                    float(any(x["correct"] for x in sub if pool(x))))
                cells[(pool_name, "oracle")]["conf"].append(np.nan)
                # rand: プールから 1 本
                cand = [x for x in sub if pool(x) and x["pred"] is not None]
                accs = [float(x["pred"] == gold) for x in cand]
                confs = [x["p_ans"] for x in cand]
                pick = rng.integers(0, len(cand), args.n_draw)
                cells.setdefault((pool_name, "rand"), {"acc": [], "conf": []})
                cells[(pool_name, "rand")]["acc"].append(float(np.mean([accs[k] for k in pick])))
                cells[(pool_name, "rand")]["conf"].append(float(np.mean([confs[k] for k in pick])))
                # confmax (p_ans)
                cm = pick_confmax(sub, pool)
                cells.setdefault((pool_name, "confmax"), {"acc": [], "conf": []})
                cells[(pool_name, "confmax")]["acc"].append(float(cm["pred"] == gold))
                cells[(pool_name, "confmax")]["conf"].append(cm["p_ans"])
                # confmax (p_full)
                cf = pick_confmax(sub, pool, key="p_full")
                cells.setdefault((pool_name, "confmaxF"), {"acc": [], "conf": []})
                cells[(pool_name, "confmaxF")]["acc"].append(float(cf["pred"] == gold))
                cells[(pool_name, "confmaxF")]["conf"].append(cf["p_full"])
                # majority
                mj = maj(sub, pool, 8)
                cells.setdefault((pool_name, "maj"), {"acc": [], "conf": []})
                cells[(pool_name, "maj")]["acc"].append(float(mj["pred"] == gold))
                cells[(pool_name, "maj")]["conf"].append(mj["share_pool"])
                cells.setdefault((pool_name, "majnom"), {"acc": [], "conf": []})
                cells[(pool_name, "majnom")]["acc"].append(float(mj["pred"] == gold))
                cells[(pool_name, "majnom")]["conf"].append(mj["share_nominal"])
                cells.setdefault((pool_name, "majrep"), {"acc": [], "conf": []})
                cells[(pool_name, "majrep")]["acc"].append(float(mj["pred"] == gold))
                cells[(pool_name, "majrep")]["conf"].append(mj["rep_conf"])

    log("\n[1] rule x pool (n=%d per cell)" % (R * P))
    rows = []
    for pool_name in POOLS:
        for rule in ["s1", "rand", "confmax", "confmaxF", "maj", "majnom", "majrep", "oracle"]:
            c = cells[(pool_name, rule)]
            a = np.asarray(c["acc"], float)
            cf = np.asarray(c["conf"], float)
            ok = np.isfinite(a)
            row = {"pool": pool_name, "rule": rule, "n": int(ok.sum()),
                   "acc": float(np.mean(a[ok])), "conf": None, "gap": None}
            okc = ok & np.isfinite(cf)
            if okc.sum() == ok.sum() and okc.sum() > 0:
                row["conf"] = float(np.mean(cf[okc]))
                row["gap"] = row["conf"] - row["acc"]
            rows.append(row)
            log("  %-6s %-9s n=%-3d acc=%.4f conf=%s gap=%s"
                % (pool_name, rule, row["n"], row["acc"],
                   "   -  " if row["conf"] is None else "%.4f" % row["conf"],
                   "   -  " if row["gap"] is None else "%+.4f" % row["gap"]))

    # ---------------- 2. 対応差（vs s1） ----------------
    def diffs(pool_name, rule):
        a1 = np.asarray(cells[("all", "s1")]["acc"], float)
        c1 = np.asarray(cells[("all", "s1")]["conf"], float)
        a2 = np.asarray(cells[(pool_name, rule)]["acc"], float)
        c2 = np.asarray(cells[(pool_name, rule)]["conf"], float)
        return a1, c1, a2, c2

    tests = []
    for pool_name in ["all", "clean", "nans3"]:
        for rule in ["confmax", "confmaxF", "maj", "majnom", "majrep"]:
            a1, c1, a2, c2 = diffs(pool_name, rule)
            d_conf, d_acc = c2 - c1, a2 - a1
            d_gap = d_conf - d_acc
            w10 = int(np.sum(a2.astype(bool) & ~a1.astype(bool)))
            w01 = int(np.sum(~a2.astype(bool) & a1.astype(bool)))
            p_mc = (float(stats.binomtest(w10, w10 + w01, 0.5).pvalue)
                    if (w10 + w01) > 0 else float("nan"))
            t_ = {"name": "%s / %s - s1" % (pool_name, rule),
                  "conf": paired(d_conf), "acc": paired(d_acc), "gap": paired(d_gap),
                  "mcnemar": {"w_rule": w10, "w_base": w01, "p": p_mc}}
            assert abs(t_["gap"]["mean"] - (t_["conf"]["mean"] - t_["acc"]["mean"])) < 1e-9
            tests.append(t_)

    log("\n[2] paired diffs vs s1 (n=%d)" % (R * P))
    for t_ in tests:
        mc = t_["mcnemar"]
        log("  %-24s dConf=%+.4f(t=%+.2f,p=%.3g) dAcc=%+.4f(t=%+.2f,McN %d/%d p=%.3g) "
            "dGap=%+.4f(t=%+.2f,p=%.3g,MDE80=%.4f)"
            % (t_["name"], t_["conf"]["mean"], t_["conf"]["t"], t_["conf"]["p"],
               t_["acc"]["mean"], t_["acc"]["t"], mc["w_rule"], mc["w_base"], mc["p"],
               t_["gap"]["mean"], t_["gap"]["t"], t_["gap"]["p"], t_["gap"]["mde80"]))

    # ---------------- 3. 対照: 同じ本数のランダム除外 ----------------
    log("\n[3] control: random drop of the same count (n_draw=%d)" % args.n_draw)
    rd_rng = np.random.default_rng(11)
    rd = {"confmax": {"acc": [], "conf": []}, "maj": {"acc": [], "conf": []},
          "confmaxF": {"acc": [], "conf": []}}
    for pp in per_pair:
        sub, gold = pp["sub"], pp["gold"]
        k = sum(1 for s in sub if s["ntok"] >= 96)
        for _ in range(args.n_draw):
            idx = list(range(8))
            drop = set(rd_rng.choice(idx, k, replace=False).tolist()) if k > 0 else set()
            keep = [sub[j] for j in range(8) if j not in drop]
            if not keep:
                continue
            pool = lambda s, keep_ids=set(id(x) for x in keep): id(s) in keep_ids  # noqa: E731
            cm = pick_confmax(sub, pool)
            cf = pick_confmax(sub, pool, key="p_full")
            mj = maj(sub, pool, len(keep))
            rd["confmax"]["acc"].append(float(cm["pred"] == gold))
            rd["confmax"]["conf"].append(cm["p_ans"])
            rd["confmaxF"]["acc"].append(float(cf["pred"] == gold))
            rd["confmaxF"]["conf"].append(cf["p_full"])
            rd["maj"]["acc"].append(float(mj["pred"] == gold))
            rd["maj"]["conf"].append(mj["share_pool"])
    for rule in ["confmax", "confmaxF", "maj"]:
        a = np.asarray(rd[rule]["acc"], float)
        c = np.asarray(rd[rule]["conf"], float)
        clean_acc = float(np.mean(cells[("clean", rule)]["acc"]))
        log("  rdrop %-9s acc=%.4f conf=%.4f gap=%+.4f  (clean acc=%.4f, clean-rdrop=%+.4f)"
            % (rule, a.mean(), c.mean(), c.mean() - a.mean(), clean_acc, clean_acc - a.mean()))

    # ---------------- 4. AUROC（問題クラスタ bootstrap） ----------------
    log("\n[4] AUROC with problem-level cluster bootstrap (2000, seed 0)")
    aurocs = []

    def one(name, scores, labels, clusters):
        pt, (lo, hi) = auroc_cluster(scores, labels, clusters)
        s_f = np.asarray(scores, float)
        ok = np.isfinite(s_f)
        y = np.asarray(labels, bool)[ok]
        aurocs.append({"name": name, "auc": pt, "ci": [lo, hi],
                       "n": int(ok.sum()), "pos": int(y.sum()),
                       "neg": int(len(y) - y.sum())})
        log("  %-34s AUC=%.3f [%.3f, %.3f]  n=%d pos=%d neg=%d"
            % (name, pt, lo, hi, aurocs[-1]["n"], aurocs[-1]["pos"], aurocs[-1]["neg"]))

    # sample level（320 本）
    cl_s = [(r["round"], k) for r in recs for k in range(8)]
    for key, lab in [("p_ans", "p_ans"), ("p_full", "p_full")]:
        one("sample %s (all 320)" % lab, [s[key] for s in S], corr, cl_s)
        m = ~trunc
        one("sample %s (complete)" % lab,
            [S[i][key] for i in np.where(m)[0]], corr[m], [cl_s[i] for i in np.where(m)[0]])

    # pair level（40）
    cl_p = [(pp["round"], pp["i"]) for pp in per_pair]
    for pool_name in ["all", "clean"]:
        one("confmax8 %s p_ans" % pool_name,
            cells[(pool_name, "confmax")]["conf"], cells[(pool_name, "confmax")]["acc"], cl_p)
        one("confmax8 %s p_full" % pool_name,
            cells[(pool_name, "confmaxF")]["conf"], cells[(pool_name, "confmaxF")]["acc"], cl_p)
        one("maj8 %s share_pool" % pool_name,
            cells[(pool_name, "maj")]["conf"], cells[(pool_name, "maj")]["acc"], cl_p)
    one("maj8 all share_nominal",
        cells[("all", "majnom")]["conf"], cells[("all", "majnom")]["acc"], cl_p)
    one("maj8 all rep_token_conf",
        cells[("all", "majrep")]["conf"], cells[("all", "majrep")]["acc"], cl_p)

    # ---------------- 5. 検算 ----------------
    log("\n[5] verification")
    # (a) clean プールで候補が空になるペアがない
    empty = sum(1 for pp in per_pair if not any(POOLS["clean"](s) for s in pp["sub"]))
    log("  pairs with empty clean pool: %d" % empty)
    assert empty == 0
    # (b) 多数決の独立再計算（clean プール）
    bad = 0
    for pp in per_pair:
        cand = [s for s in pp["sub"] if POOLS["clean"](s) and s["pred"] is not None]
        cnt = Counter([s["pred"] for s in cand])
        if sum(1 for v in cnt.values() if v == cnt.most_common(1)[0][1]) > 1:
            continue                      # 同点は tie-break 差なので比較しない
        top = cnt.most_common(1)[0][0]
        j = [k for k, p in enumerate(per_pair) if p is pp][0]
        if float(top == pp["gold"]) != cells[("clean", "maj")]["acc"][j]:
            bad += 1
    log("  majority(clean) independent recount: disagree=%d" % bad)
    assert bad == 0
    # (c) 名目 share の上限会計
    pred_cap = float(np.mean((8 - junk_per_pair) / 8.0))
    obs_nom = float(np.mean(cells[("all", "majnom")]["conf"]))
    obs_pool = float(np.mean(cells[("all", "maj")]["conf"]))
    log("  share: nominal=%.4f (上限会計 %.4f) / pool=%.4f" % (obs_nom, pred_cap, obs_pool))
    # (d) p_full が None のサンプルがない
    log("  p_full missing: %d" % sum(1 for s in S if s["p_full"] is None))
    # (e) greedy の slack（P14 の採点規約が有効なことの再確認）
    sl = [g["slack"] for g in greedy if g.get("slack") is not None]
    log("  greedy argmax-slack mean=%.6f max=%.6f n=%d"
        % (float(np.mean(sl)), float(np.max(sl)), len(sl)))
    assert float(np.mean(sl)) < 0.05

    # ---------------- 6. 規則間の一致（p_full は多数決の代理か） ----------------
    log("\n[6] rule agreement (how often two rules pick the same string)")
    picks = {}
    for pool_name in ["all", "clean"]:
        for rule in ["confmax", "confmaxF", "maj"]:
            picks[(pool_name, rule)] = []
    for pp in per_pair:
        sub, gold = pp["sub"], pp["gold"]
        for pool_name, pool in POOLS.items():
            if pool_name == "nans3":
                continue
            picks[(pool_name, "confmax")].append(pick_confmax(sub, pool)["pred"])
            picks[(pool_name, "confmaxF")].append(pick_confmax(sub, pool, "p_full")["pred"])
            picks[(pool_name, "maj")].append(maj(sub, pool, 8)["pred"])
    agree = []
    for pool_name in ["all", "clean"]:
        keys = ["confmax", "confmaxF", "maj"]
        for a in range(len(keys)):
            for b in range(a + 1, len(keys)):
                pa, pb = picks[(pool_name, keys[a])], picks[(pool_name, keys[b])]
                k = int(sum(1 for x, y in zip(pa, pb) if x == y))
                agree.append({"pool": pool_name, "a": keys[a], "b": keys[b],
                              "agree": k, "n": len(pa)})
                log("  %-6s %-9s == %-9s : %d/%d" % (pool_name, keys[a], keys[b], k, len(pa)))

    # プールサイズの分布（clean）
    sz = [sum(1 for s in pp["sub"] if POOLS["clean"](s)) for pp in per_pair]
    log("  clean pool size: mean=%.2f min=%d max=%d  (==8 のペア: %d/%d)"
        % (np.mean(sz), min(sz), max(sz), sum(1 for k in sz if k == 8), len(sz)))

    summary = {"pairs": R * P, "rounds": rounds, "n_prob": P,
               "contamination": {"truncated": int(trunc.sum()), "n": n,
                                 "acc_trunc": float(corr[trunc].mean()),
                                 "acc_complete": float(corr[~trunc].mean()),
                                 "junk_per_pair": float(junk_per_pair.mean()),
                                 "nominal_share_cap": pred_cap},
               "table": rows, "tests": tests, "aurocs": aurocs,
               "agreement": agree, "clean_pool_size": {"mean": float(np.mean(sz)),
                                                       "min": int(min(sz)), "max": int(max(sz)),
                                                       "n_full": int(sum(1 for k in sz if k == 8))},
               "rdrop_control": {k: {"acc": float(np.mean(v["acc"])),
                                     "conf": float(np.mean(v["conf"]))}
                                 for k, v in rd.items()},
               "share_nominal_obs": obs_nom, "share_pool_obs": obs_pool}
    with open(os.path.join(HERE, "p15_analysis.json"), "w", encoding="utf-8") as fp:
        json.dump(summary, fp, ensure_ascii=False, indent=2)
    with open(os.path.join(HERE, "p15_analysis_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    log("saved: p15_analysis.json")
    os._exit(0)


if __name__ == "__main__":
    main()
