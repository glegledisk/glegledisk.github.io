#!/usr/bin/env python3
"""診断 3: ループ内の tok 数・contrib ノルム・ゲートを expert 別に出す。"""
import math
import os
import sys

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
E2DIR = os.path.join(HERE, "simulation_hmoe_mmlu")
sys.path.insert(0, E2DIR)
from e2_rewrite_routing import RewriteMoE, make_batch, to_seq, WIDTHS  # noqa

OUTDIR = os.path.join(E2DIR, "data", "e2")


def main():
    torch.set_num_threads(4)
    arm, seed = "H+LB", 1
    model = RewriteMoE(WIDTHS[arm], seed=seed)
    model.p = {k: v for k, v in torch.load(
        os.path.join(OUTDIR, "ckpt_%s_s%d.pt" % (arm, seed)),
        map_location="cpu").items()}
    for k in model.p:
        model.p[k].requires_grad_(False)
    p = model.p

    print("[0] 重みのスケール（layer 0）")
    for i in range(8):
        print("    e%d w=%3d  |w1|max=%.3e  |b1|max=%.3e  |w2|max=%.3e  |b2|max=%.3e"
              % (i, WIDTHS[arm][i],
                 float(p["l0.e%d.w1" % i].abs().max()),
                 float(p["l0.e%d.b1" % i].abs().max()),
                 float(p["l0.e%d.w2" % i].abs().max()),
                 float(p["l0.e%d.b2" % i].abs().max())))

    ev = np.random.default_rng(777)
    src, out, em, _ = make_batch(ev, 32)
    xin = to_seq(src, out)
    B, T = xin.shape
    h = p["emb.w"][xin] + p["pos.w"][:T].unsqueeze(0)
    h = h.reshape(B * T, -1)

    print("\n[1] expand した topi のマスクが機能するか")
    topi = torch.tensor([2, 3], dtype=torch.long).expand(h.shape[0], -1)
    for i in (0, 1, 2, 3, 6, 7):
        tok, slot = (topi == i).nonzero(as_tuple=True)
        print("    i=%d  mask.sum=%5d  tok.numel=%5d" % (i, int((topi == i).sum()), tok.numel()))

    print("\n[2] ループ内の中間量（force=(2,3)）")
    logits = F.linear(h, p["l0.r.w"], p["l0.r.b"])
    topv = logits.gather(1, topi)
    gate = torch.softmax(torch.full_like(logits, float("-inf")).scatter(1, topi, topv), dim=1)
    print("    gate[0] = %s  (sum=%.4f)"
          % (["%.4f" % v for v in gate[0].tolist()], float(gate[0].sum())))
    for i in range(8):
        tok, slot = (topi == i).nonzero(as_tuple=True)
        if tok.numel() == 0:
            print("    e%d: skip (no token)" % i)
            continue
        xx = h[tok]
        h1 = F.relu(F.linear(xx, p["l0.e%d.w1" % i], p["l0.e%d.b1" % i]))
        contrib = F.linear(h1, p["l0.e%d.w2" % i], p["l0.e%d.b2" % i])
        print("    e%d: n=%4d  ||xx||=%.3f  ||h1||=%.4f  非零率=%.3f  "
              "||contrib||=%.4e  gate=%.4f  ||g*contrib||=%.4e"
              % (i, tok.numel(), xx.norm(dim=1).mean(), h1.norm(dim=1).mean(),
                 float((h1 != 0).float().mean()), contrib.norm(dim=1).mean(),
                 float(gate[tok, slot].mean()),
                 float((contrib * gate[tok, slot].unsqueeze(1)).norm(dim=1).mean())))

    os._exit(0)


if __name__ == "__main__":
    main()
