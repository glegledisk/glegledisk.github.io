# -*- coding: utf-8 -*-
"""P7c: 実幅 expert — α 代理は幅の代理になるか

問い:
  P7 は「ゲート重みを 0.5 倍する」ことで半スロットを作った。しかし重みのスケールは
  幅の削減ではない（計算は 1 ビットも減らないし、関数も変わらない）。
  本当に expert を半幅にしたとき、コストは同じか。

介入（P7 と同じ rank-8 = 各トークンで最小重みの expert を狙う）:
  OlmoeExperts は per-expert ループなので、rank-8 のトークンだけ
  `gate_up_proj[e][:512]` / `[1024:1536]` / `down_proj[e][:, :512]` で計算できる。
  これは**本物の半幅計算**で、FLOPs も半分になる。

実装の要点:
  accelerate が offload した層は `experts.forward` が onload ラッパーで、これを差し替えると
  重みが meta のまま NaN になる（踏んだ）。ラッパーが保持する `_old_forward` を差し替えると
  **重みが実体化された後**に呼ばれ、maxdiff 0.0 で通る。offload の無い層は forward を差し替える。

条件:
  base    元の forward
  split   forward を書き直しただけ（枝を分ける）。base との差 = 分割の丸め
  a05     split + rank-8 のゲート重みを 0.5 倍（P7 の u05 と同じ）
  p05     split + rank-8 を前半 512 ニューロンで計算
  p05r    split + rank-8 をランダムな 512 ニューロンで計算
  p1      split + rank-8 の寄与を落とす（= α=0。P7 の u1 と同じ）

判定:
  p05 − a05 が「代理の誤差」。p05 は FLOPs が 4.7% 少ないので、
  p05 ≤ a05 + 0.00045（0.5 スロット分）なら p05 が FLOPs あたりで勝つ。

出力: p7c_width.npz / p7c_width.json
"""

import argparse
import json
import os
import time
import types

import numpy as np
import torch
import torch.nn.functional as F

HERE = os.path.dirname(os.path.abspath(__file__))
FROZEN = os.path.join(HERE, "corpus_ids_seed11_w24_l256.npz")

FRONT = list(range(0, 8))
BACK = list(range(8, 16))

# 層 -> {rank_from_end: 'half'|'skip'}。None は「介入なし」。
CONDS = {
    "base": None,
    "split": {L: {} for L in FRONT + BACK},
    "a05": "alpha",
    "p05": {L: {1: "half"} for L in FRONT + BACK},
    "p05r": {L: {1: "half"} for L in FRONT + BACK},
    "p1": {L: {1: "skip"} for L in FRONT + BACK},
    "p05f": {**{L: {1: "half"} for L in FRONT}, **{L: {} for L in BACK}},
    "p05b": {**{L: {} for L in FRONT}, **{L: {1: "half"} for L in BACK}},
    # 前半: 8 番目を落として 7 番目を半幅 / 後半: 8 番目を半幅 = P7 の h15f を実幅で
    "p15f": {**{L: {1: "skip", 2: "half"} for L in FRONT},
             **{L: {1: "half"} for L in BACK}},
}


def log(msg):
    print(msg, flush=True)


def load_frozen(n_win, ln):
    z = np.load(FROZEN, allow_pickle=True)
    seqs = []
    for lang in ("en", "ja"):
        ids = torch.from_numpy(z["%s_ids" % lang].astype(np.int64))
        assert ids.numel() >= n_win * ln
        for w in range(n_win):
            seqs.append((lang, ids[w * ln:(w + 1) * ln]))
    return seqs


def make_forward(spec, half_idx):
    """spec: {rank_from_end: 'half'|'skip'}。書かれていない rank は full。

    例: {1: 'half'} = rank-8 だけ半幅 / {1: 'skip', 2: 'half'} = 8 番目を落として 7 番目を半幅。
    """
    def fwd(self, hidden_states, top_k_index, top_k_weights):
        final = torch.zeros_like(hidden_states)
        K = top_k_index.shape[-1]
        d_ff = self.down_proj.shape[-1]
        with torch.no_grad():
            mask = F.one_hot(top_k_index, num_classes=self.num_experts + 1).permute(2, 1, 0)
            hit = torch.greater(mask.sum(dim=(-1, -2)), 0).nonzero()
        for ei in hit:
            e = int(ei[0])
            if e == self.num_experts:
                continue
            pos, tok = torch.where(mask[e])
            rank = K - pos                       # 1 = 最後（rank-8）
            act = torch.zeros_like(pos)          # 0=full 1=half 2=skip
            for r, a in spec.items():
                act = torch.where(rank == r, torch.full_like(act, 1 if a == "half" else 2), act)
            gu = self.gate_up_proj[e]
            dn = self.down_proj[e]
            hi = half_idx.to(gu.device)

            m_full = (act == 0)
            if m_full.any():
                x = hidden_states[tok[m_full]]
                g, u = F.linear(x, gu).chunk(2, dim=-1)
                h = F.linear(self.act_fn(g) * u, dn)
                h = h * top_k_weights[tok[m_full], pos[m_full], None]
                final.index_add_(0, tok[m_full], h.to(final.dtype))

            m_half = (act == 1)
            if m_half.any():
                x = hidden_states[tok[m_half]]
                g = F.linear(x, gu[hi])
                u = F.linear(x, gu[d_ff + hi])
                h = F.linear(self.act_fn(g) * u, dn[:, hi])
                h = h * top_k_weights[tok[m_half], pos[m_half], None]
                final.index_add_(0, tok[m_half], h.to(final.dtype))
            # act == 2（skip）は何も足さない
        return final
    return fwd


def make_scaled(orig, alpha):
    def _patched(hidden_states):
        logits, scores, idx = orig(hidden_states)
        s = scores.clone()
        s[:, -1] = s[:, -1] * alpha
        return logits, s, idx
    return _patched


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", type=str, default=os.path.join(HERE, "models", "olmoe-1b-7b"))
    ap.add_argument("--windows", type=int, default=24)
    ap.add_argument("--len", type=int, default=256)
    ap.add_argument("--conds", type=str, default="base,split,a05,p05,p05r,p1")
    ap.add_argument("--gpu-gib", type=float, default=7.0)
    ap.add_argument("--cpu-gib", type=float, default=8.5)
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--tag", type=str, default="p7c")
    args = ap.parse_args()

    conds = [c.strip() for c in args.conds.split(",") if c.strip()]
    n_win = 1 if args.smoke else args.windows

    from transformers import AutoModelForCausalLM, AutoTokenizer

    log("[1/4] load model")
    t0 = time.time()
    tok = AutoTokenizer.from_pretrained(args.model)
    model = AutoModelForCausalLM.from_pretrained(
        args.model, torch_dtype=torch.bfloat16, device_map="auto",
        max_memory={0: "%.1fGiB" % args.gpu_gib, "cpu": "%.1fGiB" % args.cpu_gib},
    ).eval()
    log("      %.0f s" % (time.time() - t0))

    n_layers = model.config.num_hidden_layers
    d_ff = model.config.intermediate_size
    gates = [l.mlp.gate for l in model.model.layers]
    experts = [l.mlp.experts for l in model.model.layers]
    gate_fwd = [g.forward for g in gates]
    exp_fwd = [e.forward for e in experts]
    exp_old = [getattr(e, "_old_forward", None) for e in experts]
    n_old = sum(1 for x in exp_old if x is not None)
    log("      layers=%d d_ff=%d  _old_forward を持つ層=%d/%d"
        % (n_layers, d_ff, n_old, n_layers))

    half = d_ff // 2
    first = torch.arange(half)
    rng = np.random.RandomState(13)
    rand = torch.from_numpy(np.sort(rng.permutation(d_ff)[:half])).long()

    log("[2/4] corpus")
    seqs = load_frozen(n_win, args.len)
    lang = np.array([lg for lg, _ in seqs])
    log("      %d windows, %d tokens" % (len(seqs), len(seqs) * args.len))

    def restore():
        for i, e in enumerate(experts):
            if exp_old[i] is not None:
                e._old_forward = exp_old[i]
            else:
                e.forward = exp_fwd[i]
            gates[i].forward = gate_fwd[i]

    log("[3/4] forward")
    res = {}
    for cname in conds:
        restore()
        if cname not in CONDS:
            raise SystemExit("unknown cond " + cname)
        spec = CONDS[cname]
        if cname == "base":
            pass
        elif spec == "alpha":
            for i, e in enumerate(experts):
                fn = make_forward({}, first)
                if hasattr(e, "_old_forward"):
                    e._old_forward = types.MethodType(fn, e)
                else:
                    e.forward = types.MethodType(fn, e)
                gates[i].forward = make_scaled(gate_fwd[i], 0.5)
        else:
            idx = rand if cname == "p05r" else first
            for i, e in enumerate(experts):
                fn = make_forward(spec.get(i, {}), idx)
                if hasattr(e, "_old_forward"):
                    e._old_forward = types.MethodType(fn, e)
                else:
                    e.forward = types.MethodType(fn, e)

        nll_c, acc_c = [], []
        t1 = time.time()
        with torch.no_grad():
            for lg, ids in seqs:
                x = ids.unsqueeze(0).to(model.device)
                out = model(input_ids=x, use_cache=False)
                logit = out.logits[0, :-1].float()
                tgt = x[0, 1:]
                nll = F.cross_entropy(logit, tgt, reduction="none")
                true_l = logit.gather(1, tgt.unsqueeze(-1))
                acc_c.append(((logit > true_l).sum(-1) == 0).float().cpu().numpy())
                nll_c.append(nll.cpu().numpy())
                del out, logit
        res[cname] = {"nll": np.concatenate(nll_c), "acc1": np.concatenate(acc_c)}
        log("      %-6s CE %.5f  top1 %.4f  (%.0f s)"
            % (cname, res[cname]["nll"].mean(), res[cname]["acc1"].mean(), time.time() - t1))

    restore()

    log("[4/4] summary")
    base = res["base"]["nll"]
    out = {"n_tokens": int(base.size), "n_windows": len(seqs),
           "half_neurons": half, "results": {}}
    for c in conds:
        d = (res[c]["nll"] - base).astype(np.float64)
        out["results"][c] = {"ce": float(res[c]["nll"].mean()),
                             "dce": float(d.mean()),
                             "top1": float(res[c]["acc1"].mean())}
    np.savez_compressed(os.path.join(HERE, "%s_width.npz" % args.tag),
                        **{"nll_%s" % c: res[c]["nll"] for c in conds},
                        **{"acc1_%s" % c: res[c]["acc1"] for c in conds}, lang=lang)
    with open(os.path.join(HERE, "%s_width.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)

    log("")
    log("%-6s %10s %11s %8s" % ("cond", "CE", "dCE", "top1"))
    for c in conds:
        r = out["results"][c]
        log("%-6s %10.5f %+11.5f %8.4f" % (c, r["ce"], r["dce"], r["top1"]))
    log("saved: %s_width.npz / %s_width.json" % (args.tag, args.tag))


if __name__ == "__main__":
    main()
