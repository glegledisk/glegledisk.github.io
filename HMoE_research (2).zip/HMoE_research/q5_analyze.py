#!/usr/bin/env python3
"""Q5 の解析: auxw（p_pen 強度）に対する Δ と幅の dose-response。

入力: simulation_hmoe_mmlu/data/q5/H+LB_{task}_aw{auxw}_s{seed}.json
出力: data/q5/q5_analysis.json / 標準出力
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "q5")
TASK = "compute"
AUXWS = ["0", "0.05", "0.2"]
SEEDS = [0, 1, 2, 3, 4, 5]


def load(aw, s):
    p = os.path.join(D, f"H+LB_{TASK}_aw{aw}_s{s}.json")
    if not os.path.exists(p):
        return None
    try:
        with open(p, encoding="utf-8") as f:
            r = json.load(f)
    except (json.JSONDecodeError, OSError):
        return None
    return r if r.get("n_eval") == 1024 else None


def stat(xs):
    a = np.asarray(xs, float)
    n = len(a)
    m = float(a.mean())
    se = float(a.std(ddof=1) / np.sqrt(n)) if n > 1 else float("nan")
    return m, se, (m / se if se and se > 0 else float("nan"))


def main():
    out = {}
    for aw in AUXWS:
        rows = [r for r in (load(aw, s) for s in SEEDS) if r is not None]
        if not rows:
            print(f"[skip] auxw={aw}")
            continue
        b = [r["eval"]["base"] for r in rows]
        dd = [x["small_payload"] - x["small_struct"] for x in b]
        dw = [x["width_payload"] - x["width_struct"] for x in b]
        m, se, t = stat(dd)
        out[aw] = {
            "n": len(rows), "seeds": [r["seed"] for r in rows],
            "acc_payload": [x["acc_payload"] for x in b],
            "ce_payload": [x["ce_payload"] for x in b],
            "instr_valid": [x["instr_valid"] for x in b],
            "small_struct": [x["small_struct"] for x in b],
            "small_payload": [x["small_payload"] for x in b],
            "width_struct": [x["width_struct"] for x in b],
            "width_payload": [x["width_payload"] for x in b],
            "d": dd, "d_mean": m, "d_se": se, "d_t": t,
            "n_neg": int(sum(x < 0 for x in dd)),
            "dw_mean": float(np.mean(dw)),
            "usage_H": [x["usage_entropy"] for x in b],
            "usage_maxshare": [x["usage_share_max"] for x in b],
        }

    with open(os.path.join(D, "q5_analysis.json"), "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)

    print(f"\n{'auxw':>6} {'n':>2} {'acc_pl':>7} {'CE_pl':>7} {'instr':>6} "
          f"{'sm_st':>6} {'sm_pl':>6} {'Δ':>7} {'se':>6} {'t':>7} {'Δ<0':>4} "
          f"{'wid_st':>7} {'wid_pl':>7} {'widΔ':>7} {'H(use)':>7} {'maxsh':>6}")
    for aw in AUXWS:
        if aw not in out:
            continue
        r = out[aw]
        print(f"{aw:>6} {r['n']:>2} {np.mean(r['acc_payload']):>7.4f} "
              f"{np.mean(r['ce_payload']):>7.4f} {np.mean(r['instr_valid']):>6.3f} "
              f"{np.mean(r['small_struct']):>6.3f} {np.mean(r['small_payload']):>6.3f} "
              f"{r['d_mean']:>+7.3f} {r['d_se']:>6.3f} {r['d_t']:>+7.2f} "
              f"{r['n_neg']}/{r['n']} "
              f"{np.mean(r['width_struct']):>7.1f} {np.mean(r['width_payload']):>7.1f} "
              f"{r['dw_mean']:>+7.1f} {np.mean(r['usage_H']):>7.3f} "
              f"{np.mean(r['usage_maxshare']):>6.3f}")

    print("\nper-seed Δ:")
    for aw in AUXWS:
        if aw in out:
            print(f"  aw{aw:<5} " + " ".join(f"{x:+.3f}" for x in out[aw]["d"]) +
                  f"   (seeds {out[aw]['seeds']})")

    print("\n対応差（共通 seed）:")
    for a, b in [("0.2", "0.05"), ("0.05", "0"), ("0.2", "0")]:
        if a not in out or b not in out:
            continue
        sa = dict(zip(out[a]["seeds"], out[a]["d"]))
        sb = dict(zip(out[b]["seeds"], out[b]["d"]))
        common = sorted(set(sa) & set(sb))
        if len(common) < 2:
            continue
        diff = np.array([sa[s] - sb[s] for s in common])
        m, se, t = stat(diff)
        wsa = dict(zip(out[a]["seeds"], out[a]["width_struct"]))
        wsb = dict(zip(out[b]["seeds"], out[b]["width_struct"]))
        dws = np.array([wsa[s] - wsb[s] for s in common])
        mws, sews, tws = stat(dws)
        print(f"  aw{a} − aw{b}: Δ {m:+.3f}  se {se:.3f}  t {t:+.2f}  "
              f"正 {int((diff>0).sum())}/{len(common)}  |  width_struct {mws:+.1f} "
              f"(se {sews:.1f}, t {tws:+.2f}, 負 {int((dws<0).sum())}/{len(common)})")

    # 単調性（per-seed で Δ(0) < Δ(0.05) < Δ(0.2) か）
    if all(aw in out for aw in AUXWS):
        s0 = dict(zip(out["0"]["seeds"], out["0"]["d"]))
        s1 = dict(zip(out["0.05"]["seeds"], out["0.05"]["d"]))
        s2 = dict(zip(out["0.2"]["seeds"], out["0.2"]["d"]))
        common = sorted(set(s0) & set(s1) & set(s2))
        mono = sum(1 for s in common if s0[s] < s1[s] < s2[s])
        slopes = []
        xs = np.array([0.0, 0.05, 0.2])
        for s in common:
            ys = np.array([s0[s], s1[s], s2[s]])
            slopes.append(float(np.polyfit(xs, ys, 1)[0]))
        m, se, t = stat(slopes)
        print(f"\n単調性: Δ(0) < Δ(0.05) < Δ(0.2) を満たす seed は {mono}/{len(common)}")
        print(f"傾き（Δ per auxw, per-seed）: "
              f"{', '.join(f'{x:+.2f}' for x in slopes)}  "
              f"mean {m:+.2f}  se {se:.2f}  t {t:+.2f}  正 {sum(1 for x in slopes if x>0)}/{len(slopes)}")

    # collapse 判定
    if "0" in out:
        h = np.mean(out["0"]["usage_H"])
        print(f"\ncollapse 判定: auxw=0 の正規化使用率エントロピー {h:.3f}"
              f"（<0.5 なら Δ は解釈不能）")


if __name__ == "__main__":
    main()
    sys.exit(0)
