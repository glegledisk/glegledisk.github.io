# -*- coding: utf-8 -*-
"""w=3.0 / clip 50 の検算: 校正・clip 依存・同一 clip での w 比較。

前回（n15k_w10）とのビット一致を確認した上で、
  (a) w=3.0 の -0.109 が clip 交絡でどれだけ水増しされていたか
  (b) 交絡を除いた KD 効果が w によらず ~0.08 で一定か
を決める。
"""
import json
import os
import re

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
STEPS = 4680                      # 10 epoch x 468 steps
T_CRIT_DF1 = float(stats.t.ppf(0.975, 1))   # 12.706


def load(tag):
    p = os.path.join(HERE, "pc2_results_%s.json" % tag)
    by = {}
    if not os.path.exists(p):
        return by
    for r in json.load(open(p, encoding="utf-8"))["rows"]:
        by.setdefault(r["cfg"], {})[r["seed"]] = r
    return by


cur = load("n15k_w3clip")
prev = load("n15k_w10")
sweep = load("n15k_kdsweep")
if not cur:
    raise SystemExit("pc2_results_n15k_w3clip.json が無い。本番が未完了。")


def parse(cfg):
    m = re.search(r"\+kd_w([0-9.]+)_T([0-9.]+)", cfg)
    mc = re.search(r"_clip([0-9.]+)", cfg)
    w, T = (float(m.group(1)), float(m.group(2))) if m else (None, None)
    cl = float(mc.group(1)) if mc else 5.0
    return (w, T), cl


print("== 設定の assert（腕名と記録値の一致）==")
for cfg, d in cur.items():
    (w, T), cl = parse(cfg)
    for s, r in sorted(d.items()):
        assert abs(float(r["clip"]) - cl) < 1e-9, \
            "s%d %s: clip 記録 %.3f != 腕名 %.3f" % (s, cfg, r["clip"], cl)
        if w is not None:
            assert abs(float(r["kd_w"]) - w) < 1e-9, \
                "s%d %s: kd_w 記録 %.3f != 腕名 %.3f" % (s, cfg, r["kd_w"], w)
            assert abs(float(r["kd_T"]) - T) < 1e-9, \
                "s%d %s: kd_T 記録 %.3f != 腕名 %.3f" % (s, cfg, r["kd_T"], T)
        assert r["per_key"] == 2 and r["N"] == 15000 and r["epochs"] == 10
        assert abs(float(r["lr"]) - 5e-4) < 1e-12
print("  OK: %d 腕 x %d seed、clip / kd_w / kd_T / N / per_key / epochs / lr すべて一致"
      % (len(cur), len(next(iter(cur.values())))))

print("\n== 水準（N=1.5e4, per_key=2, 10ep, lr 5e-4, n=2, 生徒 W=512, 教師 W=1024）==")
print("  %-38s %8s %8s %8s %7s %8s %11s %8s"
      % ("cfg", "CE", "sd", "acc", "clip設定", "発動", "KD ep1→10", "幅"))
others = [c for c in cur if c not in ("half:scratch", "half:prune")]
others.sort(key=lambda c: (parse(c)[0][0] or 0, parse(c)[1]))
order = ["half:scratch"] + others + (["half:prune"] if "half:prune" in cur else [])
for cfg in order:
    d = cur[cfg]
    ce = np.array([v["ce"] for v in d.values()])
    acc = np.array([v["acc"] for v in d.values()])
    cl = np.mean([v["n_clip"] for v in d.values()])
    kd1 = [v["ce_hist"][0]["kd"] for v in d.values()
           if v["ce_hist"][0]["kd"] is not None]
    kd10 = [v["ce_hist"][-1]["kd"] for v in d.values()
            if v["ce_hist"][-1]["kd"] is not None]
    w = np.mean([v["width_mean"] for v in d.values()])
    kd_s = ("%.3f→%.3f" % (np.mean(kd1), np.mean(kd10))) if kd1 else "-"
    print("  %-38s %8.4f %8.4f %8.4f %7.0f %8.0f %11s %8.1f"
          % (cfg, ce.mean(), ce.std(ddof=1) if len(ce) > 1 else float("nan"),
             acc.mean(), parse(cfg)[1], cl, kd_s, w))

print("\n== clip 発動率 ==")
for cfg in order:
    d = cur[cfg]
    n = np.mean([v["n_clip"] for v in d.values()])
    print("  %-38s %6.0f / %d  (%5.1f%%)"
          % (cfg, n, STEPS, 100 * n / STEPS))

print("\n== 各腕 − scratch（同一プロセス・同一 seed, df=1）==")
base = {s: v["ce"] for s, v in cur.get("half:scratch", {}).items()}
print("  %-38s %9s %8s %8s %9s %5s %11s"
      % ("cfg", "ΔCE", "se", "t", "p", "負", "検知限界"))
for cfg in others + (["half:prune"] if "half:prune" in cur else []):
    d = cur[cfg]
    ks = sorted(set(d) & set(base))
    x = np.array([d[k]["ce"] for k in ks])
    y = np.array([base[k] for k in ks])
    diff = x - y
    t, p = stats.ttest_rel(x, y)
    se = diff.std(ddof=1) / np.sqrt(len(diff)) if len(diff) > 1 else float("nan")
    print("  %-38s %+9.4f %8.4f %+8.2f %9.4f %2d/%d %11.4f"
          % (cfg, diff.mean(), se, t, p, int((diff < 0).sum()), len(diff),
             T_CRIT_DF1 * se))
print("  （検知限界 = t_0.975,df=1 × se = 12.706 × se。n=2 なので名目 p は探索的）")

print("\n== 校正: 前回 w=10 実行 / 前々回 sweep との一致 ==")
for cfg in ["half:scratch", "half:prune",
            "half:scratch+kd_w3.0_T1.0", "half:scratch+kd_w10.0_T1.0_clip50"]:
    if cfg not in cur:
        continue
    a = np.mean([v["ce"] for v in cur[cfg].values()])
    for tag, by in [("w10", prev), ("sweep", sweep)]:
        if cfg in by:
            b = np.mean([v["ce"] for v in by[cfg].values()])
            print("  %-38s vs %-6s 今回 %.4f  前回 %.4f  差 %+.4f"
                  % (cfg, tag, a, b, a - b))

print("\n== 本命 1: w=3.0 の clip 依存 ==")
w3 = [c for c in others if parse(c)[0] == (3.0, 1.0)]
w3.sort(key=lambda c: parse(c)[1])
for c in w3:
    d = cur[c]
    print("  clip %-4.0f  CE %.4f  acc %.4f  発動 %5.0f (%5.1f%%)  KD loss ep10 %.3f"
          % (parse(c)[1], np.mean([v["ce"] for v in d.values()]),
             np.mean([v["acc"] for v in d.values()]),
             np.mean([v["n_clip"] for v in d.values()]),
             100 * np.mean([v["n_clip"] for v in d.values()]) / STEPS,
             np.mean([v["ce_hist"][-1]["kd"] for v in d.values()])))
if len(w3) >= 2:
    a, b = cur[w3[0]], cur[w3[-1]]
    ks = sorted(set(a) & set(b))
    diff = np.array([b[k]["ce"] - a[k]["ce"] for k in ks])
    print("  ΔCE(clip %0.0f − clip %0.0f) = %+.4f  (%d/%d が改善)"
          % (parse(w3[-1])[1], parse(w3[0])[1], diff.mean(),
             int((diff < 0).sum()), len(diff)))

print("\n== 本命 2: 同一 clip 50 での w=3.0 vs w=10 ==")
c3 = "half:scratch+kd_w3.0_T1.0_clip50"
c10 = "half:scratch+kd_w10.0_T1.0_clip50"
if c3 in cur and c10 in cur:
    ks = sorted(set(cur[c3]) & set(cur[c10]))
    x = np.array([cur[c3][k]["ce"] for k in ks])
    y = np.array([cur[c10][k]["ce"] for k in ks])
    diff = x - y
    t, p = stats.ttest_rel(x, y)
    print("  w=3.0 %.4f  w=10 %.4f  Δ(w3−w10) %+.4f  t %+.2f  p %.4f  (%d/%d)"
          % (x.mean(), y.mean(), diff.mean(), t, p,
             int((diff < 0).sum()), len(diff)))

print("\n== 参考: 初期化との比 ==")
if "half:prune" in cur and "half:scratch" in cur:
    s = np.mean([v["ce"] for v in cur["half:scratch"].values()])
    pce = np.mean([v["ce"] for v in cur["half:prune"].values()])
    for cfg in others:
        d = cur[cfg]
        best = np.mean([v["ce"] for v in d.values()]) - s
        print("  %-38s Δ %+.4f  / 初期化 Δ %+.4f  = 1/%.1f"
              % (cfg, best, pce - s, abs((pce - s) / best) if best else float("inf")))
