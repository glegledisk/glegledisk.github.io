#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Z1: Y1 の等 MACs 対角 P2 (H_1024 - U_688) だけを 24 seed に拡張し、
TOST 等価検定で「H の優位は等 MACs で消える」を確定するか判定する。

事前登録: `Z1課題設計書_P2のみ24seedへ拡張し等価検定で優位消失を確定_20261108.md`。
腕は 2 個だけ。既存 8 seed は W2 / Y1 の ckpt を流用し、seed 8..23 だけを
W2 / Y1 と同一レシピ（1 スレッド・6 epoch）で新規訓練してプールする。

★ 中心命題（保留 1）の検定ではない。P1 は再計算しない。

出力: z1_results.json / z1_delta.npz / z1_analysis.json / z1_calib.json /
      z1_train.json / z1_out_utf8.txt / simulation_hmoe_mmlu/data/z1/ckpt_*.pt
"""
import argparse
import json
import math
import os
import sys
import time

import numpy as np
import torch
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
for _p in (HERE, os.path.join(HERE, "simulation_hmoe_mmlu")):
    if _p not in sys.path:
        sys.path.insert(0, _p)

# Y1 のハーネスをそのまま流用（module レベルで Q8/Q2/E2 の import 順も継承）
import y1_equal_macs_2x2 as Y1            # noqa: E402
from e2b_rewrite_routing_fixed import Adam  # noqa: E402

Q2, Q8 = Y1.Q2, Y1.Q8
assert Y1.E2.SEQ == 128

W2DIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "w2")
Y1DIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "y1")
Z1DIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "z1")
Z1SMOKEDIR = os.path.join(HERE, "simulation_hmoe_mmlu", "data", "z1_smoke")
ACTIVE_Z1DIR = Z1DIR

ARMS = ("H_1024", "U_688")
ORACLE_ARMS = ("oracle_H_1024", "oracle_U_688")
ALL_ARMS = ARMS + ORACLE_ARMS
SEEDS_REUSE = tuple(range(8))
SEEDS_NEW = tuple(range(8, 24))
SEEDS_ALL = tuple(range(24))

# 腕ごとの「元の出所」を明示する。seed 0..7 は既存 ckpt、8..23 は Z1。
SOURCE = {"H_1024": W2DIR, "U_688": Y1DIR}
ORIG_NAME = {
    "H_1024": lambda s: f"ckpt_H_s{s}.pt",
    "U_688": lambda s: f"ckpt_U_688_s{s}.pt",
}
WIDTHS_A = {a: Y1.WIDTHS_A[a] for a in ARMS}
NPARAM_EXPECT = {"H_1024": 1346877, "U_688": 1001469}

SEQS, EPOCHS, BS, LR, AUXW = 3000, 6, 32, 2e-3, 0.05
N_EVAL, EVAL_SEED = 1024, 777
SPAN = Q2.T_LEN - Q2.TRACE0
CAL_FIELDS = Y1.CAL_FIELDS

# 事前登録（設計書 §3 / §4）。実行前に固定し、結果を見て変更しない。
MARGIN_CE = 0.04141674564862646   # Y1 P2 の MDE(n=8)
REF_IV = 0.1467                  # Y1 P3 / W2 の H-U_1024 点推定
MARGIN_IV_EXPLORE = 0.1467
MARGIN_CE_STRICT = 0.030
ALPHA = 0.05
TRAIN_LOG = os.path.join(HERE, "z1_train.json")

for a in ARMS:
    assert len(WIDTHS_A[a]) == 8 and sum(WIDTHS_A[a]) in (1024, 688)
assert sum(WIDTHS_A["H_1024"]) == 1024 and sum(WIDTHS_A["U_688"]) == 688
assert WIDTHS_A["H_1024"] == tuple(Y1.H_1024)
assert WIDTHS_A["U_688"] == tuple(Y1.U_688)


# ---------------------------------------------------------------------------
# ckpt / 訓練
# ---------------------------------------------------------------------------
def ckpt_path(arch, seed, active_dir=None):
    if arch not in ARMS:
        raise ValueError(f"未登録の腕: {arch}")
    if seed in SEEDS_REUSE:
        return os.path.join(SOURCE[arch], ORIG_NAME[arch](seed))
    return os.path.join(active_dir or ACTIVE_Z1DIR, f"ckpt_{arch}_s{seed}.pt")


def build_model(arch, seed):
    if arch not in WIDTHS_A:
        raise ValueError(f"未登録のアーキテクチャ: {arch}")
    return Y1.build_model(arch, seed)


def load_arch(arch, seed, active_dir=None):
    path = ckpt_path(arch, seed, active_dir)
    td = torch.load(path, map_location="cpu")
    model = build_model(arch, seed)
    assert set(td.keys()) == set(model.p.keys()), f"{arch} s{seed}: ckpt キー不一致"
    for kk in td:
        assert tuple(td[kk].shape) == tuple(model.p[kk].shape), \
            f"{arch} s{seed}: {kk} の形が違う"
    clean = {k: v.detach().clone() for k, v in td.items()}
    return model, clean


def train_one(arch, seed, epochs=EPOCHS, active_dir=None, save_path=None):
    """腕ごとに「元の訓練経路」を再現する。

    H_1024 は W2.run_one と同じ Q8.forward_dispatch(dynamic_lb)、
    U_688 は Y1.train_one と同じ forward_generic を使う（C2 でビット再現を確認）。
    ★ save_path を渡さないとき seed 0..7 は既存 ckpt のパスに戻るため、
      C2 の再訓練では必ず専用パスを渡す（元 ckpt を上書きしない）。
    """
    torch.manual_seed(seed)
    rng = np.random.default_rng(2000 + seed)
    model = build_model(arch, seed)
    assert list(model.dims) == list(WIDTHS_A[arch])
    opt = Adam(model.params(), lr=LR)
    nparam = int(sum(v.numel() for v in model.params().values()))
    steps = max(1, SEQS // BS)
    hist = []
    t0 = time.time()
    for ep in range(epochs):
        run = 0.0
        for _ in range(steps):
            xs, ty = Q2.make_trace_batch(rng, BS, task="hard")
            x = torch.from_numpy(xs)
            t = torch.from_numpy(ty)
            if arch == "H_1024":
                logits, aux, _ = Q8.forward_dispatch(
                    model, x, typ=t, mode="dynamic_lb")
            else:
                logits, aux, _ = Y1.forward_generic(model, x, typ=t, k=2)
            loss = Q2.trace_loss(logits, xs) + AUXW * aux
            loss.backward()
            opt.step(model.params())
            run += float(loss.detach())
        hist.append(float(run / steps))
    params = {k: v.detach().clone() for k, v in model.params().items()}
    path = save_path or ckpt_path(arch, seed, active_dir)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    torch.save(params, path)
    row = {"arch": arch, "seed": seed, "widths": list(WIDTHS_A[arch]),
           "nparam": nparam, "loss_hist": hist,
           "backend": "Q8" if arch == "H_1024" else "generic",
           "sec": round(time.time() - t0, 1)}
    return row, params, path


def fresh(model, clean):
    return Y1.fresh(model, clean)


def apply_oracle(model, clean):
    return Y1.apply_oracle(model, clean)


def evaluate(model, seq, typ):
    return Y1.evaluate_generic(model, seq, typ, k=2)


# ---------------------------------------------------------------------------
# 統計（設計書 §3）
# ---------------------------------------------------------------------------
def paired(d):
    d = np.asarray(d, dtype=float)
    n = len(d)
    mean = float(d.mean())
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    df = n - 1
    t = mean / se if se > 0 else 0.0
    p = float(2 * stats.t.sf(abs(t), df)) if se > 0 else 1.0
    return {
        "delta": mean, "sd": sd, "se": se, "t": float(t), "p": p, "n": n,
        "df": df,
        "mde": float(stats.t.ppf(0.975, df) * se),
        "ci90": [float(mean - stats.t.ppf(0.95, df) * se),
                 float(mean + stats.t.ppf(0.95, df) * se)],
        "ci95": [float(mean - stats.t.ppf(0.975, df) * se),
                 float(mean + stats.t.ppf(0.975, df) * se)],
        "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
        "per_seed": [float(x) for x in d],
    }


def tost(d, margin):
    r = paired(d)
    t_low = (r["delta"] + margin) / r["se"]
    t_high = (r["delta"] - margin) / r["se"]
    p_low = float(stats.t.sf(t_low, r["df"]))
    p_high = float(stats.t.cdf(t_high, r["df"]))
    p_tost = max(p_low, p_high)
    ci = r["ci90"]
    return {"margin": float(margin), "p_low": p_low, "p_high": p_high,
            "p_tost": p_tost, "ci90": ci,
            "equivalent_raw": bool(p_tost < ALPHA and
                                   ci[0] > -margin and ci[1] < margin),
            "delta": r["delta"], "se": r["se"]}


def one_sided_vs_ref(d, ref):
    r = paired(d)
    t = (r["delta"] - ref) / r["se"]
    p = float(stats.t.cdf(t, r["df"]))
    return {"ref": float(ref), "t": float(t), "p": p,
            "upper95": r["ci90"][1], "upper975": r["ci95"][1],
            "reject_raw": bool(p < ALPHA and r["ci90"][1] < ref),
            "delta": r["delta"], "se": r["se"]}


def holm2(pairs):
    """Holm m=2。pairs は (name, p)。単調性を保った補正 p を返す。"""
    order = sorted(pairs, key=lambda kv: kv[1])
    run, out = 0.0, {}
    for rank, (name, p) in enumerate(order):
        run = max(run, min(1.0, (len(order) - rank) * p))
        out[name] = {"p_raw": float(p), "p_holm": float(run),
                     "rank": rank + 1, "m": len(order)}
    return out


# ---------------------------------------------------------------------------
# 校正
# ---------------------------------------------------------------------------
def calibration(seq, typ, active_dir, tag, log, do_repro=True):
    items = []

    def add(check, arch, seed, field, want, got):
        if isinstance(want, list):
            diff = float(np.max(np.abs(np.array(got, dtype=float) -
                                       np.array(want, dtype=float))))
        else:
            diff = abs(float(want) - float(got))
        items.append({"check": check, "arch": arch, "seed": seed,
                      "field": field, "want": want, "got": got,
                      "abs_diff": diff, "bit_match": bool(diff < 1e-12)})

    with open(os.path.join(HERE, "y1_results.json"), encoding="utf-8") as f:
        y1_rows = json.load(f)["rows"]
    with open(os.path.join(HERE, "w2_results.json"), encoding="utf-8") as f:
        w2_rows = json.load(f)["rows"]

    # C1: 既存 8 seed の再評価（y1_results 80 項目 + w2_results 40 項目）
    for arch in ARMS:
        for seed in SEEDS_REUSE:
            model, clean = load_arch(arch, seed, active_dir)
            fresh(model, clean)
            m, _ = evaluate(model, seq, typ)
            ref_y1 = next(r for r in y1_rows
                          if r["arm"] == arch and r["seed"] == seed)
            for fld in CAL_FIELDS:
                add("C1_y1", arch, seed, fld, ref_y1[fld], m[fld])
            if arch == "H_1024":
                ref_w2 = next(r["eval"] for r in w2_rows
                              if r["arm"] == "H" and r["seed"] == seed)
                for fld in CAL_FIELDS:
                    add("C1_w2", arch, seed, fld, ref_w2[fld], m[fld])

    # C2: 訓練経路のビット再現（6 epoch × 2 腕）
    if do_repro:
        for arch in ARMS:
            repro_path = os.path.join(active_dir, f"repro_{arch}_s0.pt")
            _, params, _ = train_one(arch, 0, epochs=EPOCHS,
                                     active_dir=active_dir,
                                     save_path=repro_path)
            orig = torch.load(ckpt_path(arch, 0), map_location="cpu")
            diff = 0.0
            assert set(orig.keys()) == set(params.keys())
            for kk in orig:
                diff = max(diff, float((orig[kk] - params[kk]).abs().max()))
            add("C2_repro", arch, 0, "all_params_max_abs", 0.0, diff)

    # C3: nparam / widths / 未知名で例外
    for arch in ARMS:
        m0 = build_model(arch, 0)
        add("C3", arch, 0, "nparam", NPARAM_EXPECT[arch],
            int(sum(v.numel() for v in m0.params().values())))
        add("C3", arch, 0, "widths", list(WIDTHS_A[arch]), list(m0.dims))
    raised = 0
    try:
        build_model("__unknown__", 0)
    except ValueError:
        raised += 1
    add("C3", "-", 0, "unknown_raises", 1, raised)

    # C5: forward_generic と Q8.forward_dispatch のビット一致
    model, clean = load_arch("H_1024", 0, active_dir)
    fresh(model, clean)
    x = torch.from_numpy(seq[:32])
    t = torch.from_numpy(typ[:32])
    with torch.no_grad():
        a, auxa, ia = Q8.forward_dispatch(model, x, typ=t, mode="dynamic_lb")
        b, auxb, ib = Y1.forward_generic(model, x, typ=t, k=2)
    d_logit = float((a - b).abs().max())
    d_aux = abs(float(auxa) - float(auxb))
    d_idx = float(max(float((x1 != x2).float().max()) for x1, x2 in zip(ia, ib)))
    add("C5", "H_1024", 0, "logits", 0.0, d_logit)
    add("C5", "H_1024", 0, "aux_and_topi", 0.0, d_aux + d_idx)

    ok = all(it["bit_match"] for it in items)
    with open(os.path.join(HERE, f"{tag}_calib.json"), "w", encoding="utf-8") as f:
        json.dump({"items": items, "n": len(items), "all_bit_match": bool(ok)},
                  f, ensure_ascii=False, indent=2, default=float)
    log(f"校正: {sum(it['bit_match'] for it in items)}/{len(items)} bit-match "
        f"all={ok}")
    for it in items:
        if not it["bit_match"]:
            log(f"  MISMATCH {it['check']} {it['arch']} s{it['seed']} "
                f"{it['field']}: want={it['want']} got={it['got']} "
                f"diff={it['abs_diff']}")
    return items, ok


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", nargs="+", type=int, default=list(SEEDS_ALL))
    ap.add_argument("--train_seeds", nargs="+", type=int,
                    default=list(SEEDS_NEW))
    ap.add_argument("--tag", default="z1")
    ap.add_argument("--threads", type=int, default=1)
    ap.add_argument("--n_eval", type=int, default=N_EVAL)
    ap.add_argument("--epochs", type=int, default=EPOCHS)
    ap.add_argument("--reuse", action="store_true")
    ap.add_argument("--train_only", action="store_true")
    ap.add_argument("--smoke", action="store_true")
    ap.add_argument("--no_repro", action="store_true",
                    help="校正 C2 の再訓練をスキップ（本番では使わない）")
    args = ap.parse_args()

    global ACTIVE_Z1DIR
    ACTIVE_Z1DIR = Z1SMOKEDIR if args.smoke else Z1DIR
    train_log = os.path.join(HERE, "z1_smoke_train.json") \
        if args.smoke else TRAIN_LOG
    if args.smoke:
        args.seeds = list(SEEDS_REUSE)
        args.train_seeds = []
    torch.set_num_threads(args.threads)
    torch.manual_seed(12345)

    tag = args.tag
    LOG = os.path.join(HERE, f"{tag}_out_utf8.txt")
    if os.path.exists(LOG):
        os.remove(LOG)

    def log(msg):
        print(msg, flush=True)
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(msg + "\n")

    for s in args.seeds:
        assert s in SEEDS_ALL, f"未登録の seed: {s}"
    log(f"Z1: threads={args.threads} arms={list(ALL_ARMS)} "
        f"eval_seeds={len(args.seeds)} train_seeds={len(args.train_seeds)} "
        f"n_eval={args.n_eval} epochs={args.epochs} reuse={args.reuse} "
        f"train_only={args.train_only} smoke={args.smoke}")
    for a in ARMS:
        log(f"  {a:<8s} widths={WIDTHS_A[a]} sum={sum(WIDTHS_A[a])} "
            f"nparam={NPARAM_EXPECT[a]}")
    log(f"  MARGIN_CE={MARGIN_CE:.8f} REF_IV={REF_IV} ALPHA={ALPHA}")

    ev_rng = np.random.default_rng(EVAL_SEED)
    seq, typ = Q2.make_trace_batch(ev_rng, args.n_eval, task="hard")
    log(f"eval batch: seq={seq.shape} typ={typ.shape} SPAN={SPAN}")

    # ---------------- 校正 ----------------
    calib, ok_calib = [], True
    if not args.train_only:
        t0 = time.time()
        calib, ok_calib = calibration(seq, typ, ACTIVE_Z1DIR, tag, log,
                                      do_repro=not args.no_repro)
        log(f"校正所要 {time.time()-t0:.0f}s")
        if not ok_calib:
            log("校正が落ちたので本番を走らせない。原因を調べること。")
            os._exit(1)

    # ---------------- 新規 seed の訓練 ----------------
    train_rows = []
    for seed in args.train_seeds:
        for arch in ARMS:
            path = ckpt_path(arch, seed, ACTIVE_Z1DIR)
            if args.reuse and os.path.exists(path):
                log(f"  [reuse] {arch} s{seed}")
                continue
            r, _, _ = train_one(arch, seed, epochs=args.epochs,
                                active_dir=ACTIVE_Z1DIR)
            train_rows.append(r)
            log(f"  [train] {arch} s{seed} backend={r['backend']} "
                f"nparam={r['nparam']} loss[-1]={r['loss_hist'][-1]:.4f} "
                f"{r['sec']}s")

    if args.train_only:
        if os.path.exists(train_log):
            with open(train_log, encoding="utf-8") as f:
                prev = json.load(f).get("rows", [])
            merged = {f"{r['arch']}_s{r['seed']}": r for r in prev}
            for r in train_rows:
                merged[f"{r['arch']}_s{r['seed']}"] = r
            train_rows = list(merged.values())
        with open(train_log, "w", encoding="utf-8") as f:
            json.dump({"rows": train_rows, "args": vars(args)},
                      f, ensure_ascii=False, indent=2, default=float)
        log(f"train_only 完了: 今回 {len(args.train_seeds)*len(ARMS)} 走行、"
            f"{os.path.basename(train_log)} 累計 {len(train_rows)} 走行")
        os._exit(0)

    if not train_rows and os.path.exists(train_log):
        with open(train_log, encoding="utf-8") as f:
            train_rows = json.load(f).get("rows", [])
        log(f"  G1 用に {os.path.basename(train_log)} から "
            f"{len(train_rows)} 走行を復元")

    # ---------------- 本番評価 ----------------
    na, ns = len(ALL_ARMS), len(args.seeds)
    aa = {a: i for i, a in enumerate(ALL_ARMS)}
    sa = {s: j for j, s in enumerate(args.seeds)}
    iv = np.full((na, ns), np.nan)
    ce_all = np.full((na, ns), np.nan)
    act_w = np.full((na, ns), np.nan)
    instr_seq = np.zeros((na, ns, args.n_eval), dtype=np.int8)
    ce_seq = np.zeros((na, ns, args.n_eval), dtype=np.float64)
    nparam_arr = np.zeros(na, dtype=np.int64)
    rows = []

    for arm in ALL_ARMS:
        base = arm[len("oracle_"):] if arm.startswith("oracle_") else arm
        for seed in args.seeds:
            model, clean = load_arch(base, seed, ACTIVE_Z1DIR)
            if arm.startswith("oracle_"):
                info = apply_oracle(model, clean)
            else:
                fresh(model, clean)
                info = {"n_zeroed": 0, "keys": []}
            m, x = evaluate(model, seq, typ)
            i, j = aa[arm], sa[seed]
            iv[i, j] = m["instr_valid"]
            ce_all[i, j] = m["ce_all"]
            act_w[i, j] = m["active_width"]
            instr_seq[i, j] = x["instr_seq"]
            ce_seq[i, j] = x["ce_seq"]
            nparam_arr[i] = int(sum(v.numel() for v in clean.values()))
            rows.append({"arm": arm, "arch": base, "seed": seed, **m,
                         "n_zeroed": info["n_zeroed"],
                         "nparam": int(nparam_arr[i]),
                         "ckpt": os.path.relpath(
                             ckpt_path(base, seed, ACTIVE_Z1DIR), HERE)})
            log(f"  {arm:<16s} s{seed:2d} iv={m['instr_valid']:.4f} "
                f"ce={m['ce_all']:.5f} actW={m['active_width']:.1f}")

    # ---------------- 保存 ----------------
    with open(os.path.join(HERE, f"{tag}_results.json"), "w",
              encoding="utf-8") as f:
        json.dump({"rows": rows, "train_rows": train_rows,
                   "args": vars(args), "arms": list(ALL_ARMS),
                   "seeds": list(args.seeds),
                   "widths": {a: list(WIDTHS_A[a]) for a in ARMS},
                   "margin_ce": MARGIN_CE, "ref_iv": REF_IV},
                  f, ensure_ascii=False, indent=2, default=float)
    np.savez_compressed(
        os.path.join(HERE, f"{tag}_delta.npz"),
        arms=np.array(ALL_ARMS, dtype=object), seeds=np.array(args.seeds),
        iv=iv, ce_all=ce_all, active_width=act_w,
        instr_seq=instr_seq, ce_seq=ce_seq, nparam=nparam_arr)

    # ---------------- C6: 既存 8 seed の P2 が Y1 とビット一致するか ----------------
    yd_all = np.load(os.path.join(HERE, "y1_delta.npz"), allow_pickle=True)
    yarms_all = [str(x) for x in yd_all["arms"]]
    yseed_all = [int(x) for x in yd_all["seeds"]]
    yh, yu = yarms_all.index("H_1024"), yarms_all.index("U_688")
    present = [s for s in SEEDS_REUSE if s in sa]
    mine_c6 = [sa[s] for s in present]
    cols_c6 = [yseed_all.index(s) for s in present]
    H6, U6 = aa["H_1024"], aa["U_688"]
    d_ce_c6 = ce_seq[H6][mine_c6] - ce_seq[U6][mine_c6]
    d_iv_c6 = iv[H6][mine_c6] - iv[U6][mine_c6]
    ref_ce_c6 = yd_all["ce_seq"][yh][cols_c6] - yd_all["ce_seq"][yu][cols_c6]
    ref_iv_c6 = yd_all["iv"][yh][cols_c6] - yd_all["iv"][yu][cols_c6]
    c6 = {"n_seed": len(present), "n_values": int(d_ce_c6.size + d_iv_c6.size),
          "max_abs_ce_seq": float(np.abs(d_ce_c6 - ref_ce_c6).max()),
          "max_abs_iv": float(np.abs(d_iv_c6 - ref_iv_c6).max()),
          "bit_match": bool(np.abs(d_ce_c6 - ref_ce_c6).max() < 1e-12 and
                            np.abs(d_iv_c6 - ref_iv_c6).max() < 1e-12)}
    log(f"C6 (Y1 P2 ビット一致): {c6}")
    ok_calib = bool(ok_calib and c6["bit_match"])
    cpath = os.path.join(HERE, f"{tag}_calib.json")
    if os.path.exists(cpath):
        with open(cpath, encoding="utf-8") as f:
            cj = json.load(f)
        cj["items"].append({"check": "C6_y1_p2_bitmatch", "arch": "P2",
                            "seed": -1, "field": "max_abs", "want": 0.0,
                            "got": max(c6["max_abs_ce_seq"], c6["max_abs_iv"]),
                            "abs_diff": max(c6["max_abs_ce_seq"],
                                            c6["max_abs_iv"]),
                            "bit_match": c6["bit_match"]})
        cj["n"] = len(cj["items"])
        cj["all_bit_match"] = bool(ok_calib)
        with open(cpath, "w", encoding="utf-8") as f:
            json.dump(cj, f, ensure_ascii=False, indent=2, default=float)

    # ---------------- 集計 ----------------
    H, U = aa["H_1024"], aa["U_688"]
    d_ce = (ce_seq[H] - ce_seq[U]).mean(1)
    d_iv = iv[H] - iv[U]
    dseq = ce_seq[H] - ce_seq[U]
    ab = np.abs(dseq.reshape(-1))
    ntop = max(1, int(math.ceil(len(ab) * 0.01)))

    r_ce, r_iv = paired(d_ce), paired(d_iv)
    t1 = tost(d_ce, MARGIN_CE)
    t2 = one_sided_vs_ref(d_iv, REF_IV)
    holm = holm2([("T1_tost_ce", t1["p_tost"]),
                  ("T2_onesided_iv", t2["p"])])
    t1["p_holm"] = holm["T1_tost_ce"]["p_holm"]
    t2["p_holm"] = holm["T2_onesided_iv"]["p_holm"]
    t1["reject_holm"] = bool(t1["p_holm"] < ALPHA and t1["equivalent_raw"])
    t2["reject_holm"] = bool(t2["p_holm"] < ALPHA and t2["reject_raw"])

    exploratory = {
        "tost_ce_strict_delta030": tost(d_ce, MARGIN_CE_STRICT),
        "tost_iv_delta01467": tost(d_iv, MARGIN_IV_EXPLORE),
        "overlap8_iv_U688_minus_U1024": None,
    }
    # 重複 8 seed だけの paired 対比（H が代数で消える）。y1_delta.npz から参照。
    if all(s in sa for s in SEEDS_REUSE):
        yd = np.load(os.path.join(HERE, "y1_delta.npz"), allow_pickle=True)
        yarms = [str(x) for x in yd["arms"]]
        yseed = [int(x) for x in yd["seeds"]]
        ui = yarms.index("U_1024")
        cols = [yseed.index(s) for s in SEEDS_REUSE]
        mine = [sa[s] for s in SEEDS_REUSE]
        diff8 = iv[U][mine] - yd["iv"][ui][cols]
        exploratory["overlap8_iv_U688_minus_U1024"] = paired(diff8)

    # ゲート
    losses = [r["loss_hist"][-1] for r in train_rows
              if r["seed"] in SEEDS_NEW]
    g1 = {"n": len(losses),
          "median_last_loss": float(np.median(losses)) if losses else None,
          "n_below_030": int(np.sum(np.array(losses) < 0.30)) if losses else 0,
          "pass": bool(losses and len(losses) >= 32 and
                       float(np.median(losses)) < 0.30 and
                       int(np.sum(np.array(losses) < 0.30)) >= 28)}
    g2_thresh = max(1, int(math.ceil(0.80 * ns)))
    g2 = {a: {"threshold": g2_thresh,
              "n_iv_ge_010": int((iv[aa[a]] >= 0.10).sum()),
              "pass": bool(int((iv[aa[a]] >= 0.10).sum()) >= g2_thresh)}
          for a in ARMS}
    g3 = {}
    for a in ARMS:
        o = aa[f"oracle_{a}"]
        dd = (ce_seq[o] - ce_seq[aa[a]]).mean(1)
        g3[a] = {"min_delta_ce_seq": float(dd.min()),
                 "mean_delta_ce_seq": float(dd.mean()),
                 "n_below_030": int((dd < 0.30).sum()),
                 "pass": bool(dd.min() >= 0.30)}
    h_w = float(act_w[H].mean())
    u_w = float(act_w[U].mean())
    c4 = {"H_1024": h_w, "U_688": u_w,
          "rel_diff": abs(h_w - u_w) / max(1e-12, 0.5 * (h_w + u_w)),
          "pass": bool(abs(h_w - u_w) / max(1e-12, 0.5 * (h_w + u_w)) <= 0.10)}

    established = bool(ok_calib and g1["pass"] and g2["H_1024"]["pass"] and
                       g2["U_688"]["pass"] and
                       all(v["pass"] for v in g3.values()) and c4["pass"] and
                       t1["reject_holm"] and t2["reject_holm"])

    analysis = {
        "calibration": {"n": len(calib) + 1,
                        "all_bit_match": bool(ok_calib),
                        "C6_y1_p2_bitmatch": c6},
        "primary": {
            "P2_ce_seq": r_ce, "P2_instr_valid": r_iv,
            "T1_tost": t1, "T2_onesided": t2, "holm": holm,
            "ce_top1_share": float(np.sort(ab)[-ntop:].sum() /
                                   max(1e-12, ab.sum())),
            "ce_diff_median": float(np.median(dseq)),
            "ce_diff_max": float(ab.max()),
        },
        "exploratory": exploratory,
        "gates": {"G1_train_convergence": g1, "G2_iv_floor": g2,
                  "G3_oracle_sensitivity": g3},
        "C4_active_width": c4,
        "baseline": {a: {"iv": float(iv[aa[a]].mean()),
                         "ce_all": float(ce_all[aa[a]].mean()),
                         "active_width": float(act_w[aa[a]].mean()),
                         "nparam": int(nparam_arr[aa[a]])}
                     for a in ARMS},
        "verdict": {"established": established,
                    "T1_reject": bool(t1["reject_holm"]),
                    "T2_reject": bool(t2["reject_holm"]),
                    "gates_ok": bool(g1["pass"] and
                                     all(v["pass"] for v in g2.values()) and
                                     all(v["pass"] for v in g3.values()) and
                                     c4["pass"]),
                    "calibration_ok": bool(ok_calib)},
        "meta": {"threads": args.threads, "n_eval": args.n_eval,
                 "eval_seed": EVAL_SEED, "epochs": args.epochs,
                 "seqs": SEQS, "bs": BS, "lr": LR, "auxw": AUXW,
                 "seeds": list(args.seeds), "arms": list(ALL_ARMS),
                 "n_rows": len(rows), "n_train": len(train_rows),
                 "smoke": args.smoke, "margin_ce": MARGIN_CE,
                 "ref_iv": REF_IV, "alpha": ALPHA},
    }
    with open(os.path.join(HERE, f"{tag}_analysis.json"), "w",
              encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2, default=float)

    log("")
    p = analysis["primary"]
    log(f"== P2 ce_seq: Δ={p['P2_ce_seq']['delta']:+.6f} "
        f"se={p['P2_ce_seq']['se']:.6f} t={p['P2_ce_seq']['t']:+.3f} "
        f"p={p['P2_ce_seq']['p']:.6f} MDE={p['P2_ce_seq']['mde']:.6f} "
        f"90%CI={p['P2_ce_seq']['ci90']} 符号 "
        f"{p['P2_ce_seq']['n_pos']}正/{p['P2_ce_seq']['n_neg']}負")
    log(f"== T1 TOST δ={MARGIN_CE:.6f}: p_low={t1['p_low']:.6g} "
        f"p_high={t1['p_high']:.6g} p_tost={t1['p_tost']:.6g} "
        f"Holm={t1['p_holm']:.6g} reject={t1['reject_holm']}")
    log(f"== P2 instr_valid: Δ={p['P2_instr_valid']['delta']:+.6f} "
        f"se={p['P2_instr_valid']['se']:.6f} "
        f"MDE={p['P2_instr_valid']['mde']:.6f}")
    log(f"== T2 one-sided ref={REF_IV}: p={t2['p']:.6g} "
        f"Holm={t2['p_holm']:.6g} upper95={t2['upper95']:.6f} "
        f"reject={t2['reject_holm']}")
    log(f"== gates G1={g1['pass']} G2={g2} G3="
        f"{ {k: v['pass'] for k, v in g3.items()} } C4={c4}")
    log(f"== verdict: {analysis['verdict']}")
    log(f"saved: {tag}_results.json / {tag}_delta.npz / "
        f"{tag}_analysis.json / {tag}_calib.json")
    os._exit(0)


if __name__ == "__main__":
    main()
