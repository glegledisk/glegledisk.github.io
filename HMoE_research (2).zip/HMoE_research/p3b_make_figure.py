"""P3b の図: 均一配分 vs 非一様配分の Pareto 比較。"""
import json
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams["font.family"] = ["Yu Gothic", "Meiryo", "Noto Sans JP", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

HERE = os.path.dirname(os.path.abspath(__file__))
p3 = json.load(open(os.path.join(HERE, "p3_topk_summary.json"), encoding="utf-8"))
b = json.load(open(os.path.join(HERE, "p3b_alloc_summary.json"), encoding="utf-8"))

# 均一配分の曲線（P3 の k=8,7,6,4）
uni = [(0, 0.0)]
for k in (7, 6, 4):
    r = p3["results"][str(k)]
    uni.append(((8 - k) * 16, r["delta_ce"]["mean"]))
uni_x = [u[0] for u in uni]
uni_y = [u[1] for u in uni]

# 非一様の点
pts = {}
for lab, r in b["results"].items():
    if lab == "base":
        continue
    pts[lab] = (r["slots_saved"], r["delta_ce"]["mean"], r["delta_ce"]["se"])
# 8 スロットの 2 点は P3 の層別測定から
c8a = json.load(open(os.path.join(HERE, "p3c8a_topk_summary.json"), encoding="utf-8"))
c8b = json.load(open(os.path.join(HERE, "p3c8b_topk_summary.json"), encoding="utf-8"))
pts["f7b8"] = (8, c8a["results"]["7"]["delta_ce"]["mean"], c8a["results"]["7"]["delta_ce"]["se"])
pts["f8b7"] = (8, c8b["results"]["7"]["delta_ce"]["mean"], c8b["results"]["7"]["delta_ce"]["se"])

fig = plt.figure(figsize=(13.5, 4.3))

# (a) Pareto: ΔCE vs 削減スロット数
ax = fig.add_subplot(1, 3, 1)
ax.plot(uni_x, uni_y, "o-", color="#2c3e50", lw=2, ms=7, label="均一配分（全層で同じ k）")
front = ["f6b8", "f6b7", "f7b8"]
back = ["f8b6", "f7b6", "f8b7"]
for labs, col, mk, name in [(front, "#c0392b", "^", "前重み（前半を深く削る）"),
                            (back, "#2980b9", "v", "後重み（後半を深く削る）")]:
    xs, ys, es = [], [], []
    for lab in labs:
        if lab in pts:
            xs.append(pts[lab][0]); ys.append(pts[lab][1]); es.append(1.96 * pts[lab][2])
    ax.errorbar(xs, ys, yerr=es, fmt=mk, color=col, ms=9, capsize=4, ls="none", label=name)
ax.set_xlabel("削減した Expert スロット数 / トークン（＝計算予算）")
ax.set_ylabel(r"$\Delta$CE (nats/token)")
ax.set_title("(a) 同じ予算なら均一配分が最良", fontsize=11)
ax.legend(fontsize=8)
ax.grid(alpha=0.3)
ax.set_xlim(-4, 70)

# (b) 同予算の直接比較
ax = fig.add_subplot(1, 3, 2)
groups = [("16 スロット", [("u7", "均一 top-7"), ("f6b8", "前6/後8"), ("f8b6", "前8/後6")]),
          ("24 スロット", [("f6b7", "前6/後7"), ("f7b6", "前7/後6")])]
xpos = 0
ticks, labels = [], []
for gname, items in groups:
    for lab, nm in items:
        if lab not in pts:
            continue
        v, e = pts[lab][1], 1.96 * pts[lab][2]
        col = "#2c3e50" if lab.startswith("u") else ("#c0392b" if "f6" in lab or "f7b8" == lab else "#2980b9")
        ax.bar(xpos, v, 0.7, yerr=e, capsize=4, color=col)
        ax.annotate("%+.4f" % v, (xpos, v), textcoords="offset points", xytext=(0, 4),
                    ha="center", fontsize=7.5)
        ticks.append(xpos); labels.append(nm); xpos += 1
    xpos += 0.6
ax.set_xticks(ticks)
ax.set_xticklabels(labels, fontsize=8, rotation=20)
ax.set_ylabel(r"$\Delta$CE (nats/token)")
ax.set_title("(b) 同予算での直接比較（95% CI）", fontsize=11)
ax.grid(alpha=0.3, axis="y")

# (c) 均一配分の限界コスト（スロットあたり）
ax = fig.add_subplot(1, 3, 3)
edges = [(0, 16), (16, 32), (32, 64)]
mc, lab2 = [], []
for a, bb in edges:
    ya = dict(uni)[a] if a in dict(uni) else None
    yb = dict(uni)[bb]
    mc.append((yb - ya) / (bb - a))
    lab2.append("%d→%d" % (a, bb))
ax.bar(range(len(mc)), mc, 0.6, color=["#7f8c8d", "#e67e22", "#c0392b"])
for i, v in enumerate(mc):
    ax.annotate("%.5f" % v, (i, v), textcoords="offset points", xytext=(0, 4), ha="center", fontsize=8.5)
ax.set_xticks(range(len(mc)))
ax.set_xticklabels(lab2, fontsize=9)
ax.set_xlabel("削減スロット数（均一配分）")
ax.set_ylabel("1 スロットあたりの ΔCE")
ax.set_title("(c) コストは k について強い凸", fontsize=11)
ax.grid(alpha=0.3, axis="y")

fig.tight_layout()
out = os.path.join(HERE, "p3b_alloc_pareto.png")
fig.savefig(out, dpi=140)
print("saved", out)
print("marginal cost per slot:", ["%.5f" % v for v in mc])
