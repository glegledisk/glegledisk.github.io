# -*- coding: utf-8 -*-
"""P24 の検算: npz から ΔCE・c(1)・c(2)・ρ・条件式を独立に再計算する。

出力: p24_verify_out_utf8.txt
"""
import json
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
NPZ = os.path.join(HERE, "p24_layer_cost.npz")
OUT = os.path.join(HERE, "p24_verify_out_utf8.txt")
N_WIN, WIN = 48, 255
GROUPS = ["G0", "G1", "G2", "G3"]
lines = []


def w(s=""):
    lines.append(s)


z = np.load(NPZ, allow_pickle=True)
base = z["nll_base"]
w("=== P24 検算 ===")
w(f"n_tokens={base.size}（48 窓 × 255 = {N_WIN*WIN}）")
w(f"base CE = {base.mean():.5f}  ← P6c/P7c の校正値 2.68932 と一致すること")
w("")

w("[1] 各条件の ΔCE（2 通りで計算して一致を確認）")
w(f"{'cond':>6} {'ΔCE(token)':>12} {'ΔCE(窓平均)':>13} {'差':>10} {'se(窓)':>9} {'t':>7}")
res = {}
for g in GROUPS:
    for lv in ("h", "s", "t"):
        c = f"{g}{lv}"
        d = (z[f"nll_{c}"] - base).astype(np.float64)
        m_tok = d.mean()
        d_w = d.reshape(N_WIN, WIN).mean(1)
        m_win = d_w.mean()
        se = d_w.std(ddof=1) / np.sqrt(N_WIN)
        res[c] = m_win
        w(f"{c:>6} {m_tok:>+12.5f} {m_win:>+13.5f} {m_tok-m_win:>10.1e} "
          f"{se:>9.5f} {m_win/se:>+7.2f}")
w("")

w("[2] 群ごとの c(1), c(2), ρ")
c1, c2, rho = {}, {}, {}
for g in GROUPS:
    c1[g] = res[f"{g}s"]
    c2[g] = res[f"{g}t"] - res[f"{g}s"]
    rho[g] = c2[g] / c1[g]
    half_ratio = res[f"{g}h"] / res[f"{g}s"]
    w(f"  {g}: c(1)={c1[g]:+.5f}  c(2)={c2[g]:+.5f}  ρ={rho[g]:.2f}  "
      f"C(0.5)/C(1)={half_ratio:.2f}")
w("")

w("[3] 条件式の判定（12 組すべて）")
wins = 0
for i in GROUPS:
    for j in GROUPS:
        if i == j:
            continue
        A = c1[j] / c1[i]
        ok = (A > 1 + rho[i]) and (c2[i] < c1[j])
        wins += int(ok)
        w(f"  i={i} j={j}: A={A:.2f}  1+ρ_i={1+rho[i]:.2f}  c_i(2)={c2[i]:+.5f}  "
          f"c_j(1)={c1[j]:+.5f}  → {'得' if ok else '損'}")
w(f"  条件を満たす組: {wins}/12")
w("")

w("[4] 2 分割との整合（P7/P7c との突き合わせ）")
front = c1["G0"] + c1["G1"]
back = c1["G2"] + c1["G3"]
w(f"  前半 8 層（G0+G1）c(1) = {front:+.5f}   P7 の c_f = +0.00506")
w(f"  後半 8 層（G2+G3）c(1) = {back:+.5f}   P7 の c_b = +0.00946")
w(f"  比 = {back/front:.2f}（P7 は 1.87）")
w(f"  全 16 層の 1 スロット和 = {front+back:+.5f}   P7c の実幅 p1 = +0.01443")
w(f"  → 4 群に分けて足すと {100*(front+back)/0.01443:.0f}%（非加法性の分だけ小さい）")
w("")
w("[5] 深さ方向の傾向")
w("  ρ: " + " ".join(f"{g}={rho[g]:.2f}" for g in GROUPS) + "  → 単調増加か確認")
w("  c(1): " + " ".join(f"{g}={c1[g]:+.5f}" for g in GROUPS) + "  → 単調でないこと")
w("  C(0.5)/C(1): " + " ".join(f"{g}={res[g+'h']/res[g+'s']:.2f}" for g in GROUPS))
w("")

w("[6] ρ の窓ブートストラップ 95%CI（比の推定なので必須）")
rng = np.random.default_rng(0)
base_w = base.reshape(N_WIN, WIN)
dw_all = {}
for g in GROUPS:
    for lv in ("h", "s", "t"):
        d = (z[f"nll_{g}{lv}"] - base).astype(np.float64)
        dw_all[f"{g}{lv}"] = d.reshape(N_WIN, WIN).mean(1)

for g in GROUPS:
    c1w, c2w = dw_all[f"{g}s"], dw_all[f"{g}t"] - dw_all[f"{g}s"]
    boots = []
    for _ in range(2000):
        idx = rng.integers(0, N_WIN, N_WIN)
        a = c1w[idx].mean()
        b = c2w[idx].mean()
        if a > 0:
            boots.append(b / a)
    lo, hi = np.percentile(boots, [2.5, 97.5])
    w(f"  {g}: ρ={rho[g]:.2f}  CI [{lo:.2f}, {hi:.2f}]  （{len(boots)}/2000 有効）")
w("  → **CI が非常に広い。ρ の点推定の単調性は確立していない。**")
w("")

w("[7] 判定に直接効く量 c_i(2) − c_j(1) のブートストラップ 95%CI")
w("    負なら「j の 1 本を i へ移すと得」。0 を含むなら検出できず。")
for i in GROUPS:
    for j in GROUPS:
        if i == j:
            continue
        qi = dw_all[f"{i}t"] - dw_all[f"{i}s"]      # c_i(2)
        qj = dw_all[f"{j}s"]                        # c_j(1)
        obs = qi.mean() - qj.mean()
        boots = []
        for _ in range(2000):
            idx = rng.integers(0, N_WIN, N_WIN)
            boots.append(qi[idx].mean() - qj[idx].mean())
        lo, hi = np.percentile(boots, [2.5, 97.5])
        verdict = "得（CI<0）" if hi < 0 else ("損（CI>0）" if lo > 0 else "検出できず")
        w(f"  i={i} j={j}: c_i(2)−c_j(1) = {obs:+.5f}  CI [{lo:+.5f}, {hi:+.5f}]  → {verdict}")

with open(OUT, "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")
print("\n".join(lines))
