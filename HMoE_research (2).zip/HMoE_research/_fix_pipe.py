import io
FIX = [
 ("検証報告_P13_ゲート添字バグとHMoE高速経路の再測定_20261029.md",
  [("`max|logits(2,3) − logits(6,7)|`", "`max\\|logits(2,3) − logits(6,7)\\|`")]),
 ("検証報告_P6f_減衰説は符号の一貫性として正しい_20261027.md",
  [("`||Δh||`", "`\\|\\|Δh\\|\\|`"),
   ("`E\\|Δlogit\\| / ||Δh||`", "`E\\|Δlogit\\| / \\|\\|Δh\\|\\|`")]),
]
for path, pairs in FIX:
    t = io.open(path, encoding="utf-8").read()
    for a, b in pairs:
        if a in t:
            t = t.replace(a, b)
            print(f"OK  {path[:28]}  {a[:26]}")
        else:
            print(f"MISS {path[:28]}  {a[:26]}")
    io.open(path, "w", encoding="utf-8", newline="\n").write(t)