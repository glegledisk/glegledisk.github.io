# -*- coding: utf-8 -*-
"""p6k_analysis.py — P6k の解析（GPU 不要）

問い: P6e の位置依存（f8b6 は乖離 1 単位あたり 15.8 倍効く）は
「乖離が LM head 読み出し方向に整列する」ことで説明できるか。

指標:
  a1    = |<dh, ŵ_top1(base)>| / ||dh||      読み出し方向 top1 への整列度 (0〜1)
  q10   = ||{<dh, ŵ_i>}_{top10}|| / ||dh||   上位 10 部分空間への整列度 (0〜1)
  p1    = <dh, ŵ_top1(base)>                 予測 top1 logit 変化
  dlogit 実測 top1 logit 変化（p1 と一致するはず → 測定器の検算）
出力: p6k_analysis.json / p6k_analysis.png
"""
import itertools
import json
import math
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
Z = np.load(os.path.join(HERE, "p6k_head_proj.npz"), allow_pickle=True)
OUT = {}

CONDS = ["f6b8", "f6b8_rs", "f8b6", "f8b6_rs"]
BASE_CONTRASTS = [
    ("f6b8", "f8b6", "後半削り − 前半削り"),
    ("f8b6", "f8b6_rs", "rescale − 無rescale"),
    ("f6b8_rs", "f8b6_rs", "RS: 後半削り − 前半削り"),
]


def t_test(d):
    d = np.asarray(d, np.float64)
    n = d.size
    m = d.mean()
    se = d.std(ddof=1) / math.sqrt(n)
    t = m / se if se > 0 else float("nan")
    p = math.erfc(abs(t) / math.sqrt(2))  # 正規近似（df ≈ 1.2e4）
    return m, se, t, p, n


def arr(c, k):
    return Z["%s_%s" % (c, k)]


def s1(c):
    """符号付き整列効率: <dh, ŵ_top1>/||dh||。正=乖離が top1 を押し上げる"""
    return arr(c, "p1") / np.maximum(arr(c, "dh_norm"), 1e-9)


# ---- 0. 測定器の検算: p1（予測） vs dlogit（実測）----
print("== 測定器の検算 ==")
for c in CONDS:
    p1, dl = arr(c, "p1"), arr(c, "dlogit")
    r = np.corrcoef(p1, dl)[0, 1]
    mae = np.abs(p1 - dl).mean()
    print("%-8s corr(p1,dlogit)=%.4f  MAE=%.4f  mean p1=%+.4f mean dlogit=%+.4f" % (c, r, mae, p1.mean(), dl.mean()))
    OUT["check_%s" % c] = {"corr": float(r), "mae": float(mae)}

# ---- 1. 条件別の整列度 ----
print("\n== 条件別（トークン平均） ==")
head = ["cond", "a1_mean", "a1_med", "q10_mean", "q10_med", "dh_mean", "dh_med", "|p1|_mean", "s1_mean"]
rows = []
for c in CONDS:
    a1, q10 = arr(c, "a1"), arr(c, "q10")
    dh, p1 = arr(c, "dh_norm"), np.abs(arr(c, "p1"))
    key_cols = {"a1": a1.mean(), "q10": q10.mean(), "dh": dh.mean(), "abs_p1": p1.mean(), "s1": s1(c).mean(), "s1_sign": float(np.sign(s1(c).mean()))}
    rows.append([c] + [key_cols["a1"], np.median(a1), key_cols["q10"], np.median(q10), dh.mean(), np.median(dh), p1.mean(), key_cols["s1"]])
    print("%-8s a1=%.4f/%.4f  q10=%.4f/%.4f  ||dh||=%.4f/%.4f  |p1|=%.4f  s1=%+.5f" % (
        c, a1.mean(), np.median(a1), q10.mean(), np.median(q10), dh.mean(), np.median(dh), p1.mean(), key_cols["s1"]))
OUT["per_cond"] = [head] + [[r[0]] + [float(x) for x in r[1:]] for r in rows]

# ---- 2. 対比（paired per-token）----
print("\n== 対比（paired）: Δ = B − A ==")
OUT["contrasts"] = []
for A, B, label in BASE_CONTRASTS:
    for key in ["a1", "q10", "dh_norm", "p1", "ptop1", "nll", "s1"]:
        if key == "s1":
            d = s1(B) - s1(A)
        else:
            d = arr(B, key) - arr(A, key)
        m, se, t, p, n = t_test(d)
        OUT["contrasts"].append({"A": A, "B": B, "key": key, "m": float(m), "se": float(se),
                                 "t": float(t), "p": float(p), "n": int(n)})
        print("%-20s %-8s Δ=%+.5f  se=%.5f  t=%+.2f  p=%.2e  n=%d" % (label, key, m, se, t, p, n))
    ratio_a1 = arr(B, "a1").mean() / arr(A, "a1").mean()
    ratio_p1 = np.abs(arr(B, "p1")).mean() / np.abs(arr(A, "p1")).mean()
    OUT["contrasts"].append({"A": A, "B": B, "key": "ratio_a1", "m": float(ratio_a1)})
    OUT["contrasts"].append({"A": A, "B": B, "key": "ratio_abs_p1", "m": float(ratio_p1)})
    print("%-20s ratio: a1=%.2fx  |p1|=%.2fx" % (label, ratio_a1, ratio_p1))

# ---- 3. 整列度の比が P6e の 15.8 倍を説明するか ----
print("\n== P6e との突き合わせ ==")
# P6e: p 移動 9.2 倍、max logit 移動 19.8 倍、乖離 1.25 倍 → 効率 15.8 倍
r_dh = arr("f8b6", "dh_norm").mean() / arr("f6b8", "dh_norm").mean()
r_a1 = arr("f8b6", "a1").mean() / arr("f6b8", "a1").mean()
r_q10 = arr("f8b6", "q10").mean() / arr("f6b8", "q10").mean()
r_p1 = np.abs(arr("f8b6", "p1")).mean() / np.abs(arr("f6b8", "p1")).mean()
print("乖離 ||dh|| 比 = %.2fx（P6e: 1.25x）" % r_dh)
print("整列 a1 比     = %.2fx" % r_a1)
print("整列 q10 比    = %.2fx" % r_q10)
print("|p1| 比        = %.2fx（≈ top1 logit の動きの比。P6e の ~19.8x に対応）" % r_p1)
print("効率 ||dh||×a1 = %.2fx（P6e: 15.8x）" % (r_dh * r_a1))
OUT["ratios_vs_p6e"] = {"dh": float(r_dh), "a1": float(r_a1), "q10": float(r_q10),
                        "abs_p1": float(r_p1), "dh_x_a1": float(r_dh * r_a1)}

# ---- 3b. 符号の反転（核心）と Δlogp / ΔlogZ 近似分解 ----
# s1 = p1/||dh|| は符号を持つ。前半削りは top1 を押し下げ、後半削りは押し上げる？
print("\n== 符号付き整列 s1 = p1/||dh|| ==")
for c in CONDS:
    v = s1(c)
    print("%-8s s1 mean=%+.5f med=%+.5f  正=乖離が top1 を押し上げ" % (c, v.mean(), np.median(v)))
OUT["s1_mean"] = {c: float(s1(c).mean()) for c in CONDS}

print("\n== Δlogp と logZ の近似分解（argmax 不変のトークンでは Δlogit_max = p1） ==")
# P6e の実測 Δmax: f6b8 +0.00445 / f8b6 +0.08798 → f8b6 は p1(mean) と一致規模、f6b8 は argmax 入れ替わりで酔い止められる
lp_b = np.log(np.clip(arr("base", "ptop1"), 1e-9, None))
for c in ["f6b8", "f8b6"]:
    dlp = np.log(np.clip(arr(c, "ptop1"), 1e-9, None)) - lp_b   # Δlog p_top1
    dlZ = arr(c, "p1") - dlp                                     # ΔlogZ ≈ p1 − Δlogp（近似）
    print("%-8s Δlogp=%+.5f  ΔlogZ≈%+.5f  p1(mean)=%+.4f  [P6e Δmax=%s]" % (
        c, dlp.mean(), dlZ.mean(), arr(c, "p1").mean(),
        "+0.00445" if c == "f6b8" else "+0.08798"))
    OUT["logp_logz_%s" % c] = {"dlogp": float(dlp.mean()), "dlogZ_est": float(dlZ.mean())}

# ---- 4. 裾チェック: |p1| の上位 1% 寄与（§7-5） ----
print("\n== 裾チェック ==")
for c in CONDS:
    v = np.abs(arr(c, "p1"))
    s = v.argsort()[::-1]
    k1 = max(1, int(0.01 * v.size))
    frac = v[s[:k1]].sum() / v.sum()
    print("%-8s |p1| 上位1%%寄与 = %.1f%%" % (c, 100 * frac))
    OUT["tail_top1pct_%s" % c] = float(frac)

# ---- 5. en/ja 分割（頑健性）----
print("\n== en/ja 分割: Δs1 = f8b6 − f6b8 ==")
lang_win = Z["lang"]                       # 窓単位 (48,)
LANG = np.repeat(lang_win, 255)            # トークン単位へ展開
n_tok = arr("f6b8", "a1").size
LANG = LANG[:n_tok]
print("lang: %d tokens (en=%d, ja=%d)" % (n_tok, int((LANG == "en").sum()), int((LANG == "ja").sum())))
for nm in ("en", "ja"):
    mask = LANG == nm
    d = s1("f8b6")[mask] - s1("f6b8")[mask]
    m, se, t, p, n = t_test(d)
    print("%s: Δs1=%+.5f se=%.5f t=%+.2f p=%.2e n=%d" % (nm, m, se, t, p, n))
    OUT["by_lang_s1_%s" % nm] = {"m": float(m), "se": float(se), "t": float(t), "p": float(p), "n": int(n)}

with open(os.path.join(HERE, "p6k_analysis.json"), "w", encoding="utf-8") as f:
    json.dump(OUT, f, ensure_ascii=False, indent=1)
print("\nsaved p6k_analysis.json")

# ---- 図 ----
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams["font.family"] = ["Yu Gothic", "MS Gothic", "sans-serif"]
plt.rcParams["axes.unicode_minus"] = False

fig, axes = plt.subplots(1, 3, figsize=(15, 4.4))
for ax, key, title, ylabel in [
    (axes[0], "a1", "読み出し方向 top1 への整列度（絶対値）", "a1 = |<dh,ŵ_t1>|/||dh||"),
    (axes[1], "q10", "上位 10 部分空間への整列度", "q10"),
    (axes[2], "s1", "符号付き整列効率（核心）", "s1 = p1/||dh||（+ = top1 を押し上げ）"),
]:
    if key == "s1":
        means = [s1(c).mean() for c in CONDS]
        ses = [np.asarray(s1(c), np.float64).std(ddof=1) / math.sqrt(s1(c).size) for c in CONDS]
    else:
        means, ses = [], []
        for c in CONDS:
            v = arr(c, key)
            d = np.asarray(v, np.float64)
            means.append(d.mean())
            ses.append(d.std(ddof=1) / math.sqrt(d.size))
    x = np.arange(len(CONDS))
    ax.bar(x, means, yerr=ses, capsize=4, color=["#999", "#4C8", "#C55", "#59C"], alpha=0.85)
    ax.set_xticks(x)
    ax.set_xticklabels(CONDS, rotation=20)
    ax.set_title(title, fontsize=11)
    ax.set_ylabel(ylabel)
fig.suptitle("P6k: 乖離は LM head 方向に乗っているか（48窓×255トークン, n=12240 per token paired）", fontsize=12)
fig.tight_layout()
fig.savefig(os.path.join(HERE, "p6k_analysis.png"), dpi=150)
print("saved p6k_analysis.png")
