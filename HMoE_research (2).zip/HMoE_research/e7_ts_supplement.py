# -*- coding: utf-8 -*-
"""e7_ts_supplement.py — tokid + 安定化の追加解析"""
import numpy as np
import pandas as pd

df = pd.read_csv("e7_tokid_stab_7seed.csv")
df["obj015"] = df["ce_all"] + 0.15 * df["ffn_cost"]
a4 = pd.read_csv("e7_stabilize_7seed.csv")
a4["obj015"] = a4["ce_all"] + 0.15 * a4["ffn_cost"]
e7 = pd.read_csv("e7_routing_7seed.csv")
e7["obj015"] = e7["ce_all"] + 0.15 * e7["ffn_cost"]

tok = a4[a4.variant == "free_tokid"].set_index("seed")
te = df[df.variant == "tokid_entropy"].set_index("seed")
tb = df[df.variant == "tokid_balance"].set_index("seed")
ffn = e7[e7.arm == "frozen_ffn"].set_index("seed")

print("=== seed 別 obj（frozen_ffn / tokid / tokid_entropy） ===")
for s in range(7):
    print(f" s{s}: ffn {ffn.loc[s,'obj015']:.4f}  tokid {tok.loc[s,'obj015']:.4f}  "
          f"tokid_ent {te.loc[s,'obj015']:.4f}  差(te-ffn) {te.loc[s,'obj015']-ffn.loc[s,'obj015']:+.4f}")

print("\n=== E6 効果量からの回復率 ===")
e6 = {"obj": -0.1509, "ce": -0.0320, "ffn": -0.7929}
for name, d in [("E7 free", e7[e7.arm == "free"].set_index("seed")), ("free_tokid", tok), ("tokid_entropy", te)]:
    o = d["obj015"].mean() - ffn["obj015"].mean()
    c = d["ce_all"].mean() - ffn["ce_all"].mean()
    f = d["ffn_cost"].mean() - ffn["ffn_cost"].mean()
    print(f" {name:14s} obj {o:+.4f}（E6 の {100*o/e6['obj']:5.1f}%）  "
          f"CE {c:+.4f}（E6 の {100*c/e6['ce']:5.1f}%）  FFN {f:+.4f}（E6 の {100*f/e6['ffn']:5.1f}%）")

print("\n=== tokid_entropy: FFN cost と CE の関係（seed 内） ===")
for s in range(7):
    print(f" s{s}: FFN {te.loc[s,'ffn_cost']:.3f}  CE {te.loc[s,'ce_all']:.4f}  "
          f"id_ff {te.loc[s,'id_rate_ff']:.3f}  id_rr {te.loc[s,'id_rate_rr']:.3f}  "
          f"acc_rr {te.loc[s,'acc_rr']:.3f}")
r = np.corrcoef(te["ffn_cost"], te["ce_all"])[0, 1]
print(f" 相関 r(FFN cost, CE) = {r:+.3f}（n=7）")

print("\n=== CE の役割別分解（n_role × ce_role） ===")
for name, d in [("frozen_ffn", ffn), ("free_tokid", tok), ("tokid_entropy", te), ("tokid_balance", tb)]:
    contrib = {nm: float((d[f"n_{nm}"] * d[f"ce_{nm}"]).mean()) for nm in ["ff", "fr", "rr"]}
    tot = sum(contrib.values())
    print(f" {name:14s} " + " ".join(f"{nm} {contrib[nm]:.3f} ({100*contrib[nm]/tot:3.0f}%)" for nm in ["ff", "fr", "rr"]))

print("\n=== 最適方針への接近 ===")
nff = float(ffn["n_ff"].mean())
print(f" 最適（ff のみ恒等）: FFN cost {1-nff:.3f}")
for name, d in [("free", e7[e7.arm == "free"].set_index("seed")), ("free_tokid", tok),
                ("tokid_entropy", te), ("tokid_balance", tb)]:
    print(f" {name:14s} FFN cost {d['ffn_cost'].mean():.3f}  id_ff {d['id_rate_ff'].mean():.3f}  "
          f"（ff の {100*d['id_rate_ff'].mean():.0f}% を逃がした）")
