#!/usr/bin/env python3
"""PC2 の 20 epoch 版を検算し、10 epoch 版と突き合わせる。"""
import json
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))


def load(tag):
    j = json.load(open(os.path.join(HERE, "pc2_results_%s.json" % tag), encoding="utf-8"))
    by = {}
    for r in j["rows"]:
        by.setdefault(r["cfg"], {})[r["seed"]] = r
    return by


a = load("n3k")     # 10 epoch
b = load("e20")     # 20 epoch

print("== 水準 ==")
for tag, by in (("e10", a), ("e20", b)):
    for cfg, d in by.items():
        ce = np.array([v["ce"] for v in d.values()])
        acc = np.array([v["acc"] for v in d.values()])
        w = np.array([v["width_mean"] for v in d.values()])
        print("  %-3s %-13s n=%d  CE %.4f (sd %.4f)  acc %.4f  幅 %.1f  MACs %d"
              % (tag, cfg, len(d), ce.mean(), ce.std(ddof=1), acc.mean(), w.mean(),
                 d[list(d)[0]]["macs"]))

print("\n== 対応差（同一 seed で突き合わせ）==")
pairs = [
    ("teacher20 - teacher10", b["teacher"], a["teacher"]),
    ("scratch20 - scratch10", b["half:scratch"], a["half:scratch"]),
    ("teacher20 - A(prune10)", b["teacher"], a["half:prune"]),
    ("scratch20 - A(prune10)", b["half:scratch"], a["half:prune"]),
    ("teacher20 - scratch20", b["teacher"], b["half:scratch"]),
    ("teacher10 - scratch10", a["teacher"], a["half:scratch"]),
    ("A(prune10) - scratch10", a["half:prune"], a["half:scratch"]),
]
for name, A, B in pairs:
    ks = sorted(set(A) & set(B))
    x = np.array([A[k]["ce"] for k in ks])
    y = np.array([B[k]["ce"] for k in ks])
    d = x - y
    t, p = stats.ttest_rel(x, y)
    se = d.std(ddof=1) / np.sqrt(len(d))
    mde = (stats.t.ppf(0.975, len(d) - 1) + stats.t.ppf(0.8, len(d) - 1)) * d.std(ddof=1) / np.sqrt(len(d))
    print("  %-24s ΔCE %+0.4f  se %.4f  t %+0.2f  p %.4f  n %d  負 %d  MDE %.4f"
          % (name, d.mean(), se, t, p, len(d), int((d < 0).sum()), mde))

print("\n== 学習曲線の後半（teacher20 / scratch20、CE）==")
for cfg in ("teacher", "half:scratch"):
    for s in sorted(b[cfg]):
        h = [round(x["ce"], 3) for x in b[cfg][s]["ce_hist"]]
        print("  %-12s s%d  ep11-20 %s" % (cfg, s, h[10:]))
