# -*- coding: utf-8 -*-
"""AX7 Step 4: 独立再計算（ax7_plateau.py を import しない別経路）。

scipy.stats.ttest_rel 経路で Δ・se・t・p・Holm・MDE・上位 1% 寄与率を作り直し、
npz の生配列から分割・決定・mean_k・校正・探索的分解を再構築して
ax7_plateau.json と突合する。使い方: python _ax7_verify.py [tag]
"""
import json
import math
import os
import sys

import numpy as np
from scipy import stats as scistats

HERE = os.path.dirname(os.path.abspath(__file__))
TAG = sys.argv[1] if len(sys.argv) > 1 else "ax7"
ALPHA = 0.05
N_LAYERS = 16
SEED_A, SEED_B = 7201, 7202

ITEMS, MISMATCH = [], []


def chk(name, got, exp, rtol=1e-6, atol=1e-9):
    ITEMS.append(name)
    ok = False
    if isinstance(exp, (list, tuple)):
        try:
            ok = (len(got) == len(exp) and all(
                math.isclose(float(a), float(b), rel_tol=rtol, abs_tol=atol)
                for a, b in zip(got, exp)))
        except Exception:
            ok = (list(got) == list(exp))
    elif isinstance(exp, bool) or isinstance(exp, str):
        ok = (got == exp)
    elif isinstance(exp, (int, np.integer)) and isinstance(got, (int, np.integer)):
        ok = (int(got) == int(exp))
    else:
        try:
            ok = math.isclose(float(got), float(exp), rel_tol=rtol, abs_tol=atol)
        except Exception:
            ok = False
    if not ok:
        MISMATCH.append((name, got, exp))


def rst(d, tok_per_win=255):
    """paired stats の独立実装（scipy ttest_rel 経路）。"""
    d = np.asarray(d, dtype=np.float64).ravel()
    n = d.size
    m = float(d.mean())
    t, p = scistats.ttest_rel(d, np.zeros_like(d))
    sd = float(d.std(ddof=1))
    se = sd / math.sqrt(n)
    tc975 = float(scistats.t.ppf(0.975, n - 1))
    tc95 = float(scistats.t.ppf(0.95, n - 1))
    wm = d.reshape(-1, tok_per_win).mean(axis=1)
    sew = float(wm.std(ddof=1) / math.sqrt(wm.size))
    srt = np.sort(np.abs(d))[::-1]
    k1 = max(1, int(math.ceil(0.01 * n)))
    return {"mean": m, "sd": sd, "se": se, "t": float(t), "p_two": float(p),
            "mde": tc975 * se, "ci95": [m - tc975 * se, m + tc975 * se],
            "ci90": [m - tc95 * se, m + tc95 * se],
            "n_pos": int((d > 0).sum()), "n_neg": int((d < 0).sum()),
            "median": float(np.median(d)), "se_win": sew,
            "top1_abs_share": float(srt[:k1].sum() / srt.sum())}


def holm_adj(pvals):
    ids = sorted(pvals, key=lambda k: pvals[k])
    out, run = {}, 0.0
    for i, k in enumerate(ids):
        run = max(run, (len(ids) - i) * pvals[k])
        out[k] = min(1.0, run)
    return out


def decision_indep(c8, c7, uid, n_unit):
    """np.add.at 経由（本体の np.bincount とは別経路）。"""
    cnt = np.zeros(n_unit, dtype=np.float64)
    np.add.at(cnt, uid, 1.0)
    assert cnt.min() > 0
    a = np.zeros((n_unit, N_LAYERS), dtype=np.float64)
    b = np.zeros((n_unit, N_LAYERS), dtype=np.float64)
    for L in range(N_LAYERS):
        ta = np.zeros(n_unit, dtype=np.float64)
        tb = np.zeros(n_unit, dtype=np.float64)
        np.add.at(ta, uid, c8[L])
        np.add.at(tb, uid, c7[L])
        a[:, L] = ta / cnt
        b[:, L] = tb / cnt
    cut = np.argmin(b, axis=1).astype(np.int8)
    Q = a.copy()
    Q[np.arange(n_unit), cut] = -np.inf
    prot = np.argmax(Q, axis=1).astype(np.int8)
    return cut, prot


def mean_k_indep(uid, cut, prot, n_tok, nw, n_eval):
    km = np.full((N_LAYERS, n_tok), 7.0, dtype=np.float64)
    for u in range(len(cut)):
        sel = (uid == u)
        km[cut[u], sel] = 6.0
        km[prot[u], sel] = 8.0
    kmw = km.reshape(N_LAYERS, nw, n_eval)
    kmw = np.concatenate([kmw, np.full((N_LAYERS, nw, 1), 7.0)], axis=2)
    return float(kmw.mean()), float(kmw.sum(axis=0).max())


def split_stats_indep(uid, k=None, n_win=48, n_eval=255, sent=None):
    ls = np.bincount(uid).astype(np.float64)
    sh = ls / ls.sum()
    d = {"N": int(ls.size), "mean": float(ls.mean()),
         "cv": float(ls.std(ddof=1) / ls.mean()), "min": float(ls.min()),
         "max": float(ls.max()), "eff_units": float(1.0 / (sh ** 2).sum()),
         "short_le20_share": float((ls <= 20).mean()),
         "short_le40_share": float((ls <= 40).mean())}
    if k is not None and sent is not None:
        per = {}
        for w in range(n_win):
            sl = slice(w * n_eval, (w + 1) * n_eval)
            u, s = uid[sl], sent[sl]
            for x in np.unique(u):
                per.setdefault(int(x), set()).update(np.unique(s[u == x]).tolist())
        d["partial_share"] = float(sum(1 for v in per.values() if len(v) < k) / len(per))
    return d


def finite_bad(obj, path="root"):
    bad = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            bad += finite_bad(v, path + "/" + str(k))
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            bad += finite_bad(v, path + "/%d" % i)
    elif isinstance(obj, (float, np.floating)) and (np.isnan(obj) or np.isinf(obj)):
        bad.append(path)
    return bad


def main():
    J = json.load(open(os.path.join(HERE, "%s_plateau.json" % TAG), encoding="utf-8"))
    z = np.load(os.path.join(HERE, "%s_plateau.npz" % TAG))
    meta = J["meta"]
    n_tok = int(meta["n_tok"])
    nw = int(meta["windows"])
    n_eval = int(meta["len"]) - 1
    c8 = z["c8"].astype(np.float64)
    c7 = z["c7"].astype(np.float64)
    sent = z["sent"].astype(np.int64)
    N = {k[4:]: z[k].astype(np.float64) for k in z.files if k.startswith("nll_")}
    u7 = N["u7"]
    assert c8.shape == (N_LAYERS, n_tok) and u7.shape == (n_tok,)

    # ---- 1. gains 全腕 ----
    for nm, rj in J["gains"].items():
        s = rst(u7 - N[nm], n_eval)
        for key, val in s.items():
            chk("gain.%s.%s" % (nm, key), rj[key], val)

    # ---- 2. 確認的 3 検定を生配列から再構成 ----
    d1 = 0.5 * ((N["uni102"] - N["shift102"]) + (N["uni181"] - N["shift181"]))
    d2 = 0.5 * ((N["shift102"] - N["sent4"]) + (N["shift181"] - N["sent2"]))
    d3 = (N["sent4"] - N["sent2"]) - (N["uni102"] - N["uni181"])
    conf = J["confirmatory"]
    st = {}
    for key, d in (("P1_length", d1), ("P2_alignment", d2), ("P3_flat", d3)):
        s = rst(d, n_eval)
        st[key] = s
        rj = conf[key]
        for k, val in s.items():
            chk("confirm.%s.%s" % (key, k), rj[k], val)
        chk("confirm.%s.n" % key, rj["n"], n_tok)
        chk("confirm.%s.df" % key, rj["df"], n_tok - 1)
    ph = holm_adj({"P1": st["P1_length"]["p_two"], "P2": st["P2_alignment"]["p_two"],
                   "P3": st["P3_flat"]["p_two"]})
    for k, v in ph.items():
        chk("holm." + k, conf["holm"][k], v)
        chk("reject." + k, conf["reject"][k], bool(v < ALPHA))
    rej = {k: bool(v < ALPHA) for k, v in ph.items()}
    case = "A" if rej["P1"] else ("B" if rej["P2"] else ("C" if rej["P3"] else "D"))
    chk("case", conf["case"], case)

    # ---- 3. 分割・決定・mean_k ----
    uid_keys = sorted(k[4:] for k in z.files if k.startswith("uid_"))
    chk("n_parts", len(uid_keys), 13)
    parts = {}
    for nm in uid_keys:
        uid = z["uid_" + nm].astype(np.int64)
        parts[nm] = uid
        chk("part.shape." + nm, int(uid.size), n_tok)
        chk("part.contiguous." + nm, int(np.array_equal(np.unique(uid),
                                                        np.arange(uid.max() + 1))), 1)
        chk("part.coverage." + nm, int(np.bincount(uid).sum()), n_tok)
        nu = int(uid.max()) + 1
        c_re, p_re = decision_indep(c8, c7, uid, nu)
        chk("dec.cut." + nm, int((c_re != z["cut_" + nm]).sum()), 0)
        chk("dec.prot." + nm, int((p_re != z["prot_" + nm]).sum()), 0)
        mk, slots = mean_k_indep(uid, c_re, p_re, n_tok, nw, n_eval)
        chk("mean_k." + nm, mk, 7.0, atol=1e-9)
        chk("slots." + nm, slots, 112.0, atol=1e-9)
        k = 4 if nm == "sent4" else (2 if nm == "sent2" else None)
        ss = split_stats_indep(uid, k, nw, n_eval, sent)
        for key, val in ss.items():
            chk("split.%s.%s" % (nm, key), J["exploratory"]["split_stats"][nm][key], val)

    # C2: 多重集合
    for N_, src in ((102, "sent4"), (181, "sent2")):
        a = np.sort(np.bincount(parts[src]))
        for nm in ("shift%d" % N_, "shift%db" % N_):
            chk("multiset." + nm, int(np.array_equal(a, np.sort(np.bincount(parts[nm])))), 1)

    # ---- 4. 校正 ----
    cal = J["calib"]
    if cal["C1"]["tier"] == "SKIP":
        chk("C1.tier", cal["C1"]["tier"], "SKIP")
    else:
        zd = np.load(os.path.join(HERE, "ax4_sentence_bound.npz"))
        bd = float(np.abs(N["base_rep"] -
                          zd["nll_base_rep"][:n_tok].astype(np.float64)).max())
        ud = float(np.abs(N["u7_rep"] -
                          zd["nll_u7_rep"][:n_tok].astype(np.float64)).max())
        chk("C1.base_maxdiff", cal["C1"]["base_maxdiff"], bd)
        chk("C1.u7_maxdiff", cal["C1"]["u7_maxdiff"], ud)
        chk("C1.tier", cal["C1"]["tier"], "A" if bd == 0.0 and ud == 0.0 else "FAIL")
    chk("C2.multiset102", cal["C2"]["multiset_shift102"], True)
    chk("C2.multiset181", cal["C2"]["multiset_shift181"], True)
    chk("C3.n_bad", cal["C3"]["n_bad"], 0)
    for nm, v in cal["C3"]["mean_k"].items():
        chk("C3.mean_k." + nm, v, 7.0, atol=1e-9)
    for nm, v in cal["C3"]["decision_replay"].items():
        chk("C3.replay." + nm, v, 1)
    chk("C4.n_bad", cal["C4"]["n_bad"], 0)
    chk("C4.slots", cal["C4"]["slots_per_token"], 112)
    for nm, v in cal["C5"]["conflicts"].items():
        chk("C5.conflict." + nm, v, 0)
    gr = float((u7 - N["sent_random"]).mean())
    go = float((u7 - N["tok12240"]).mean())
    chk("C6.random_gain", cal["C6"]["random_gain"], gr)
    chk("C6.oracle_gain", cal["C6"]["oracle_gain"], go)
    chk("C6.random_le_oracle", cal["C6"]["random_le_oracle"], bool(gr <= go))
    G = {nm: float((u7 - N[nm]).mean()) for nm in N if nm != "u7"}
    n102 = abs(G["shift102"] - G["shift102b"])
    n181 = abs(G["shift181"] - G["shift181b"])
    chk("C7.noise102", cal["C7"]["noise102"], n102)
    chk("C7.noise181", cal["C7"]["noise181"], n181)
    chk("C7.judgement", cal["C7"]["judgement"], "record_only")

    # ---- 5. 探索的 ----
    ex = J["exploratory"]
    for N_, s, u in ((102, "sent4", "uni102"), (181, "sent2", "uni181")):
        sh = "shift%d" % N_
        d = ex["decomposition_N%d" % N_]
        chk("decomp%d.total" % N_, d["total"], G[s] - G[u])
        chk("decomp%d.alignment" % N_, d["alignment"], G[s] - G[sh])
        chk("decomp%d.length" % N_, d["length"], G[sh] - G[u])
    we = ex["window_effect"]
    chk("we.sent4_glob4", we["sent4_minus_glob4"], G["sent4"] - G["glob4"])
    chk("we.sent2_glob2", we["sent2_minus_glob2"], G["sent2"] - G["glob2"])
    chk("we.uni102w", we["uni102w_minus_uni102"], G["uni102w"] - G["uni102"])
    chk("we.uni181w", we["uni181w_minus_uni181"], G["uni181w"] - G["uni181"])
    fl = ex["flat"]
    chk("flat.F_sent", fl["F_sent_ax4"], G["sent2"] - G["sent4"])
    chk("flat.F_uni", fl["F_uni_ax5"], G["uni181"] - G["uni102"])
    chk("flat.F_shift", fl["F_shift"], G["shift181"] - G["shift102"])
    keys = [nm for nm in parts if nm in G]
    rc, _ = scistats.spearmanr([J["exploratory"]["split_stats"][k]["cv"] for k in keys],
                               [G[k] for k in keys])
    re, _ = scistats.spearmanr([J["exploratory"]["split_stats"][k]["eff_units"] for k in keys],
                               [G[k] for k in keys])
    chk("descriptive.rho_cv", ex["descriptive"]["spearman_cv_vs_G"],
        float(rc) if np.isfinite(rc) else 0.0)
    chk("descriptive.rho_eff", ex["descriptive"]["spearman_eff_units_vs_G"],
        float(re) if np.isfinite(re) else 0.0)
    chk("descriptive.n_arms", ex["descriptive"]["n_arms"], len(keys))
    for k in ("P1_length", "P2_alignment", "P3_flat"):
        chk("top1." + k, ex["top1_abs_share"][k], st[k]["top1_abs_share"])

    chk("nonfinite", len(finite_bad(J)), 0)
    chk("meta.n_arms", meta["n_arms"], len(J["gains"]))
    chk("meta.n_tok", meta["n_tok"], n_tok)

    print("AX7 Step 4 verify (tag=%s)" % TAG)
    print("items=%d  mismatches=%d" % (len(ITEMS), len(MISMATCH)))
    for nm, got, exp in MISMATCH[:20]:
        print("  MISMATCH %-46s got=%r exp=%r" % (nm, got, exp))
    return 1 if MISMATCH else 0


if __name__ == "__main__":
    sys.exit(main())
