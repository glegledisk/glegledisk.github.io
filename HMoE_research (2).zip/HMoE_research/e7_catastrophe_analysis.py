# -*- coding: utf-8 -*-
"""e7_catastrophe_analysis.py — 壊滅的 seed のトレース詳細解析。

診断ラン（e7_catastrophe_traces.json）から:
1. 爆発の時系列（ep 40〜59）を全メトリクスで表示
2. 「bump」イベントの検出（val_ce が直前より 3 倍以上 & >0.1）と回復の有無
3. 仮説の検定:
   - H-A（境界仮説）: |m50_ff| が小さい（ゲートが決定境界の近く）epoch ほど CE が揺れる
   - H-B（勾配スパイク）: gnorm_router のスパイクが CE の跳ねを予測する
   - H-C（warmup 仮説）: 爆発は warmup 中の状態で決まるか（ep10 の状態と最終 CE の相関）
   - H-D（後期不安定性）: 爆発は warmup と無関係に最終盤で起きるか（爆発 epoch の分布）
"""
import json
import os

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
D = json.load(open(os.path.join(HERE, "e7_catastrophe_traces.json"), encoding="utf-8"))
R, T = D["results"], D["traces"]

COLS = ["train_ce", "val_ce", "ce_ff", "ce_fr", "ce_rr", "ffn_cost", "idmass_ff", "tr_inzone_ff",
        "tr_margin_p50_ff", "gate_ent", "lg_absmax", "gnorm_router"]

print("=== 1. 爆発の時系列（ep 40〜59） ===")
for name in ["wb3_s7", "wb4_s8", "wb3_s0", "bias10_s7", "wb3_s7_nolam"]:
    tr = T[name]
    print(f"\n-- {name} --   ep " + " ".join(f"{c.replace('tr_','').replace('_margin','m')[:7]:>7s}"
                                             for c in COLS))
    for rec in tr:
        if rec["epoch"] >= 40:
            print(f"      {rec['epoch']:3d} " + " ".join(
                "   None" if rec[c] is None else f"{rec[c]:7.3f}" for c in COLS))

print("\n\n=== 2. bump イベントの検出（val_ce > 1.5 × 直前 3 epoch の最小値 + 0.05） ===")
for name, tr in T.items():
    ev = []
    for i, rec in enumerate(tr):
        if i < 3:
            continue
        base = min(r["val_ce"] for r in tr[i - 3:i])
        if rec["val_ce"] > 1.5 * base + 0.05:
            ev.append((rec["epoch"], round(base, 4), round(rec["val_ce"], 3),
                       round(rec["gnorm_router"], 2) if rec["gnorm_router"] else None))
    fin = tr[-1]["val_ce"]
    print(f" {name:14s} final {fin:7.4f}  bumps: " +
          ("  ".join(f"ep{e}({b}->{v},g={g})" for e, b, v, g in ev) if ev else "なし"))

print("\n\n=== 3. 仮説の検定 ===")
# H-A: 境界近傍ほど CE が揺れるか（全ラン・全 epoch をプール）
rows = []
for name, tr in T.items():
    for i in range(1, len(tr)):
        d = abs(tr[i]["val_ce"] - tr[i - 1]["val_ce"])
        rows.append(dict(run=name, ep=tr[i]["epoch"], dce=d, m50=tr[i]["tr_margin_p50_ff"],
                         absm50=abs(tr[i]["tr_margin_p50_ff"]), gnorm=tr[i]["gnorm_router"],
                         ent=tr[i]["gate_ent"], val=tr[i]["val_ce"], phase=tr[i]["phase"]))
df = pd.DataFrame(rows)
late = df[df.ep >= 30]
print(f" H-A 境界仮説: corr(|m50_ff|, |Δval_ce|) 全 epoch {df['absm50'].corr(df['dce']):+.3f} / "
      f"ep>=30 {late['absm50'].corr(late['dce']):+.3f}  (n={len(df)}/{len(late)})")
big = late[late.dce > 0.05]
print(f"     |Δval_ce|>0.05 の epoch: {len(big)}/{len(late)}  "
      f"その |m50_ff| 中央値 {big['absm50'].median():.2f} vs 他 {late[late.dce <= 0.05]['absm50'].median():.2f}")
# H-B: gnorm スパイク → 次 epoch の CE 跳ね
g = late.dropna(subset=["gnorm"]).copy()
g["dce_next"] = [df[(df.run == r) & (df.ep == e + 1)]["dce"].iloc[0]
                 if len(df[(df.run == r) & (df.ep == e + 1)]) else np.nan
                 for r, e in zip(g["run"], g["ep"])]
print(f" H-B 勾配仮説: corr(gnorm_t, |Δval_ce|_t) {g['gnorm'].corr(g['dce']):+.3f} / "
      f"corr(gnorm_t, |Δval_ce|_t+1) {g['gnorm'].corr(g['dce_next']):+.3f}")
hi = g[g.gnorm > g.gnorm.quantile(0.9)]
print(f"     gnorm 上位 10%（>{g.gnorm.quantile(0.9):.2f}）の同時 |Δval_ce| 中央値 "
      f"{hi['dce'].median():.3f} vs 他 {g[g.gnorm <= g.gnorm.quantile(0.9)]['dce'].median():.3f}")
# H-C: ep10 の状態と最終 CE
print(" H-C warmup 仮説: ep10（解凍直後）の状態と最終 CE")
for name, tr in T.items():
    r10 = next(r for r in tr if r["epoch"] == 10)
    print(f"     {name:14s} ep10: idm_ff {r10['idmass_ff']:.3f} inz_ff {r10['tr_inzone_ff']:.3f} "
          f"m50 {r10['tr_margin_p50_ff']:+6.2f} ent {r10['gate_ent']:.3f} → final {tr[-1]['val_ce']:.4f}")
# H-D: 爆発 epoch の分布（warmup 中 0-9 / 中期 10-39 / 終盤 40-59）
print(" H-D 後期不安定性: 最大の |Δval_ce| が起きた epoch")
for name, tr in T.items():
    d = [abs(tr[i]["val_ce"] - tr[i - 1]["val_ce"]) for i in range(1, len(tr))]
    j = int(np.argmax(d)) + 1
    print(f"     {name:14s} 最大跳ね ep{j:2d} ({tr[j-1]['val_ce']:.3f}→{tr[j]['val_ce']:.3f}) "
          f"phase={tr[j]['phase']}")

print("\n\n=== 4. 終盤の「静かな劣化」か「突然の爆発」か（ep 45〜59 の val_ce） ===")
for name in ["wb3_s7", "wb4_s8", "bias10_s7", "wb2_s7", "wb3_s0"]:
    print(f" {name:14s} " + " ".join(f"{r['val_ce']:6.3f}" for r in T[name] if r["epoch"] >= 45))
