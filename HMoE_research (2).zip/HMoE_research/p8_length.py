# -*- coding: utf-8 -*-
"""P8: 長さ L の検証パイロット（ガイド Phase A の A1 / A2）

問い:
  A1  P(pass at L) は凹か S 字か（L を配分する余地があるか）
  A2  失敗は「観測できる」のか。打ち切りで答えなしにする条件（hard-A）と、
      同じ打ち切りで強制解答する条件（hard-B）、短く考えさせる条件（soft）を比べる。

モデル: Qwen3-0.6B（thinking 対応）。OLMoE は base LM で生成 QA に使えないため。
課題: 4 桁加算（難）と 3 桁加算（易）。機械判定。

条件:
  cap128 / cap256 / cap512 / cap1024   上限だけ。自然停止するか、答えが出るか
  force256                             上限 256 で切ったあと「Final answer:」を付けて 24 トークン強制
  soft                                 「Think briefly」指示 + 上限 1024

測るもの:
  答えなし率 / 正解率 / 確信度つき誤答率 / 確信度の AUROC / 較正ギャップ
  確信度 = 生成末尾 8 トークンの平均 logprob を exp したもの（解答領域の代理）

出力: p8_length.jsonl / p8_length.json
"""

import argparse
import json
import os
import random
import re
import time

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "qwen3-0.6b")
SYS = "You are a careful arithmetic assistant. Solve the problem and give the final answer."
FORCE = "\nFinal answer: "
TAU = 0.8


def log(m):
    print(m, flush=True)


def build(tok, q, think=True, extra=""):
    msgs = [{"role": "system", "content": SYS},
            {"role": "user", "content": q + (("\n" + extra) if extra else "")}]
    return tok.apply_chat_template(msgs, tokenize=False, add_generation_prompt=True,
                                   enable_thinking=think)


def extract_box(txt):
    """\\boxed{...} があればそれを解答とみなす。無ければ None（＝答えなし）。"""
    m = re.findall(r"\\boxed\{([^}]*)\}", txt)
    return m[-1].strip() if m else None


def extract_last(txt):
    nums = re.findall(r"-?\d+", txt.replace(",", ""))
    return nums[-1] if nums else None


def make_problems(n_hard, n_easy, seed):
    rnd = random.Random(seed)
    out = []
    for _ in range(n_hard):
        a, b = rnd.randint(1001, 9999), rnd.randint(1001, 9999)
        out.append({"q": "Compute %d + %d." % (a, b), "gold": str(a + b), "level": "add4"})
    for _ in range(n_easy):
        a, b = rnd.randint(101, 999), rnd.randint(101, 999)
        out.append({"q": "Compute %d + %d." % (a, b), "gold": str(a + b), "level": "add3"})
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--hard", type=int, default=20)
    ap.add_argument("--easy", type=int, default=10)
    ap.add_argument("--bs", type=int, default=8)
    ap.add_argument("--seed", type=int, default=21)
    ap.add_argument("--tag", type=str, default="p8")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer

    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, torch_dtype=torch.bfloat16, device_map="cuda",
        attn_implementation="sdpa").eval()

    probs = make_problems(args.hard, args.easy, args.seed)
    log("problems: %d (add4=%d, add3=%d)" % (len(probs), args.hard, args.easy))

    def gen_batch(prompts, max_new, bs):
        """返り値: [(text, ntok, finished, mean_logprob_tail8)]"""
        out_all = []
        for i in range(0, len(prompts), bs):
            chunk = prompts[i:i + bs]
            enc = tok(chunk, return_tensors="pt", padding=True,
                      add_special_tokens=False).to(model.device)
            with torch.no_grad():
                o = model.generate(**enc, max_new_tokens=max_new, do_sample=False,
                                   pad_token_id=tok.pad_token_id)
            new = o[:, enc["input_ids"].shape[1]:] if not hasattr(o, "sequences") else \
                o.sequences[:, enc["input_ids"].shape[1]:]
            for j in range(len(chunk)):
                ids = new[j]
                ntok = int((ids != tok.pad_token_id).sum())
                fin = bool((ids == tok.eos_token_id).any())
                out_all.append((tok.decode(ids, skip_special_tokens=True), ntok, fin,
                                float("nan")))
        return out_all

    records = []

    def add(cond, cap, extra="", force=False, think=True):
        t0 = time.time()
        prompts = [build(tok, p["q"], think, extra) for p in probs]
        res = gen_batch(prompts, cap, args.bs)
        ntok_total = sum(r[1] for r in res)
        for p, (txt, ntok, fin, conf) in zip(probs, res):
            rec = {"cond": cond, "cap": cap, "level": p["level"], "q": p["q"],
                   "gold": p["gold"], "ntok": ntok, "finished": fin,
                   "text_tail": txt.strip()[-120:]}
            if force:
                # 切ったあとに「Final answer:」を付けて 24 トークンだけ生成
                p2 = [build(tok, p["q"]) + txt + FORCE]
                r2 = gen_batch(p2, 24, 1)[0]
                ans_txt = r2[0]
                pred = extract_box(ans_txt) or extract_last(ans_txt)
                rec.update({"pred": pred, "conf": r2[3],
                            "forced_ntok": r2[1], "forced_tail": ans_txt.strip()[-60:]})
                ntok_total += r2[1]
            else:
                pred = extract_box(txt)          # 箱が無ければ「答えなし」
                rec.update({"pred": pred, "conf": conf if pred is not None else float("nan")})
            rec["correct"] = (rec["pred"] == p["gold"])
            rec["answered"] = rec["pred"] is not None
            records.append(rec)
        dt = time.time() - t0
        log("  %-9s cap=%4d  %3d 問  %6d tok  %.0f s  %.0f tok/s"
            % (cond, cap, len(probs), ntok_total, dt, ntok_total / dt))

    log("[1/2] 長さスイープ（A1）")
    for cap in (128, 256, 512, 1024):
        add("cap%d" % cap, cap)

    log("[2/2] 失敗の観測可能性（A2）")
    add("force256", 256, force=True)
    add("soft", 1024, extra="Think briefly, then give the final answer.")
    add("nothink", 1024, think=False)

    with open(os.path.join(HERE, "%s_length.jsonl" % args.tag), "w", encoding="utf-8") as fp:
        for r in records:
            fp.write(json.dumps(r, ensure_ascii=False) + "\n")

    # ---- 集計 ----
    ORDER = ["cap128", "cap256", "cap512", "cap1024", "force256", "soft", "nothink"]
    log("")
    log("%-9s %-6s %6s %8s %8s %8s %8s" %
        ("cond", "level", "ans", "acc_all", "acc_ans", "silent", "med_tok"))
    summary = {}
    for cond in sorted(set(r["cond"] for r in records), key=ORDER.index):
        for lv in ("add4", "add3"):
            sel = [r for r in records if r["cond"] == cond and r["level"] == lv]
            if not sel:
                continue
            ansr = [r for r in sel if r["answered"]]
            ans = len(ansr) / len(sel)
            acc_all = float(np.mean([r["correct"] for r in sel]))
            acc_ans = float(np.mean([r["correct"] for r in ansr])) if ansr else float("nan")
            silent = float(np.mean([(r["answered"] and not r["correct"]) for r in sel]))
            med = float(np.median([r["ntok"] for r in sel]))
            log("%-9s %-6s %6.2f %8.2f %8.2f %8.2f %8.0f"
                % (cond, lv, ans, acc_all, acc_ans, silent, med))
            summary["%s:%s" % (cond, lv)] = {
                "n": len(sel), "answer_rate": ans, "acc_all": acc_all,
                "acc_answered": acc_ans, "silent_failure": silent,
                "median_tokens": med,
                "finished_rate": float(np.mean([r["finished"] for r in sel]))}
    with open(os.path.join(HERE, "%s_length.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump({"tau": TAU, "summary": summary}, fp, ensure_ascii=False, indent=2)
    log("")
    log("saved: %s_length.jsonl / %s_length.json" % (args.tag, args.tag))


if __name__ == "__main__":
    main()
