# -*- coding: utf-8 -*-
"""_ax5_audit.py — opencode 製 AX5 成果物の独立監査（読み取り専用）。

報告書の主要数値を ax5_granularity_mech.json / .npz から引き直し、
利得スケールの符号・H3 の対比・粒度カーブ・N=340 の帯・比・分解・
非有限値の所在を確認する。Step 4 (_ax5_verify.py) とは別経路。

使い方: python _ax5_audit.py
"""
import json
import math
import os

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
J = json.load(open(os.path.join(HERE, "ax5_granularity_mech.json"), encoding="utf-8"))
Z = np.load(os.path.join(HERE, "ax5_granularity_mech.npz"))
N_TOK = J["meta"]["n_tok"]

lines = []


def say(s):
    lines.append(s)
    print(s)


def g(name):
    return J["exploratory"]["gains"][name]["mean"]


say("AX5 independent audit (read-only)")
say("meta: n_tok=%d  n_arms=%d  seeds=%s" % (N_TOK, J["meta"]["n_arms"], J["meta"]["seeds"]))

# ---- 1. H1 / H2 の利得スケール ----
h1_json = J["confirmatory"]["H1_uniform_minus_sent"]["mean"]
h2_json = J["confirmatory"]["H2_sent_minus_shift"]["mean"]
say("\n[H1/H2] json means: H1 %+.8f  H2 %+.8f  (nll スケール)" % (h1_json, h2_json))
say("  G_uni - G_sent = %+.8f  (報告 +0.00027426)" % (-h1_json))
say("  G_sent - G_shift = %+.8f  (報告 -0.00029407)" % (h2_json))
say("  H1 Holm %.6g  H2 Holm %.6g  case %s"
    % (J["confirmatory"]["holm"]["H1"], J["confirmatory"]["holm"]["H2"],
       J["confirmatory"]["case"]))

# ---- 2. H3 の対比 ----
ns = [48, 102, 181, 340, 630, 1224]
arms = ["win48", "uni102", "uni181", "uni340", "uni630", "uni1224"]
w = np.log(np.array(ns, dtype=np.float64))
w -= w.mean()
gv = np.array([g(a) for a in arms])
contrast = float((w * gv).sum())
h3 = J["manipulation_check_H3"]
say("\n[H3] weights sum %.3e  Σw_k G_k = %+.8f  json H3 = %+.8f  diff %.2e"
    % (w.sum(), contrast, h3["mean"], abs(contrast - h3["mean"])))
say("  t %+.4f  p %.6g  MDE %.8f  reject %s"
    % (h3["t"], h3["p_two"], h3["mde"], h3["reject"]))
say("  ※ 傾きではなく対比ベクトルの重み付き和（設計書 §5）")

# ---- 3. 粒度カーブと単調性 ----
curve = J["exploratory"]["granularity_curve"]
say("\n[curve]")
for k, v in curve.items():
    say("  %-20s %+.8f" % (k, v))
order = ["global1", "win48", "uni102", "uni181", "uni340", "uni630",
         "uni1224", "tok12240"]
seq = np.array([curve[k] for k in order])
diffs = np.diff(seq)
say("  uniform+anchors order: %s" % " -> ".join(order))
say("  monotonic_nonneg=%s  min_adj_diff %+.8f"
    % (bool((diffs >= 0).all()), float(diffs.min())))

# ---- 4. N=340 の帯と比 ----
names340 = ["sent340_rep", "uni340", "shift340", "shift340b", "lognorm340",
            "alt340", "uni340w", "shift340w"]
v340 = np.array([g(n) for n in names340])
tok = g("tok12240")
say("\n[N=340] band %.8f  min %+.8f  max %+.8f  tok %+.8f"
    % (v340.max() - v340.min(), v340.min(), v340.max(), tok))
for n in ("sent340_rep", "uni340", "shift340"):
    say("  %-14s G %+.8f  G/G_tok %.2f%%" % (n, g(n), 100 * g(n) / tok))

# ---- 5. C7 の符号 ----
c7 = J["calib"]["C7"]
say("\n[C7] json mean (nll_a - nll_b) %+.8f  flag %s" % (c7["mean"], c7["flag_partition_noise"]))
say("  G_shift_a - G_shift_b = %+.8f  (報告 +0.00132332)" % (-c7["mean"]))
say("  |C7| / |H2| = %.2f  (設計 §7 の 0.5 倍条件: %s)"
    % (abs(c7["mean"]) / abs(h2_json),
       abs(c7["mean"]) > 0.5 * abs(h2_json)))

# ---- 6. per-token 割当 ----
rand = g("tok_randmatch")
say("\n[tok] G_randmatch %+.8f  G_tok - G_randmatch %+.8f  (報告 +0.04317349)"
    % (rand, tok - rand))
dec = J["exploratory"]["decomposition"]
say("  G_global1 %+.8f  G_specific_340 %+.8f  G_specific_tok %+.8f"
    % (dec["G_global1"]["mean"], dec["G_specific_340"]["mean"],
       dec["G_specific_tok"]["mean"]))

# ---- 7. 記述的解析 ----
jens = J["exploratory"]["jensen"]
reg = J["exploratory"]["regression"]
say("\n[descriptive] Jensen R2 %.6f  coef %s"
    % (jens["r2_uniform"], [round(c, 8) for c in jens["coef"]]))
say("  regression R2 %.6f  LOO R2 %.6f  (LOO<0 なので予測モデルに使わない)"
    % (reg["r2"], reg["r2_loo"]))

# ---- 8. 校正と裾 ----
cal = J["calib"]
say("\n[calib] C1 %s (u7 %.1f / sent %.1f)  C3 max_mismatch %d  C4 n_bad %d  C5 max_conflict %d  C6 random_le_oracle %s"
    % (cal["C1"]["tier"], cal["C1"]["u7_maxdiff"], cal["C1"]["sent_maxdiff"],
       max(cal["C3"].values()), cal["C4"]["n_bad"],
       max(cal["C5"]["conflicts"].values()),
       cal["C6"]["random_le_oracle"]))
say("  top1_abs_share H1 %.4f  H2 %.4f  median H1 %+.8f  H2 %+.8f"
    % (J["confirmatory"]["H1_uniform_minus_sent"]["top1_abs_share"],
       J["confirmatory"]["H2_sent_minus_shift"]["top1_abs_share"],
       J["confirmatory"]["H1_uniform_minus_sent"]["median"],
       J["confirmatory"]["H2_sent_minus_shift"]["median"]))

# ---- 9. 非有限値 ----
bad = []


def walk(x, p=""):
    if isinstance(x, dict):
        for k, v in x.items():
            walk(v, p + "/" + str(k))
    elif isinstance(x, list):
        for i, v in enumerate(x):
            walk(v, p + "/%d" % i)
    elif isinstance(x, float) and (math.isnan(x) or math.isinf(x)):
        bad.append(p)


walk(J)
say("\n[non-finite] %d 個: %s" % (len(bad), bad[:8]))
say("  すべて gains/u7_rep の自己比較（u7-u7=0）由来か: %s"
    % all("/gains/u7_rep/" in p for p in bad))

# ---- 10. npz の分割 ----
say("\n[npz] keys %d" % len(Z.files))
for k in sorted(Z.files):
    if k.startswith("uid_") or k.startswith("lens_"):
        a = Z[k]
        say("  %-22s %s %s" % (k, a.shape, a.dtype))

with open(os.path.join(HERE, "_ax5_audit_out_utf8.txt"), "w", encoding="utf-8") as fp:
    fp.write("\n".join(lines) + "\n")
