# -*- coding: utf-8 -*-
import re
from markdown_it import MarkdownIt

path = "考察_未解決課題マップ_データ側が律速である_20261104.md"
with open(path, encoding="utf-8") as fh:
    src = fh.read()
html = MarkdownIt("commonmark").enable("table").render(src)
body = re.sub(r"<pre>.*?</pre>", "", html, flags=re.S)
body = re.sub(r"<code>.*?</code>", "<code>X</code>", body, flags=re.S)

out = []
for m in re.finditer(r"\*\*", body):
    out.append("STAR: ..." + body[max(0, m.start() - 70):m.end() + 70].replace("\n", " ") + "...")
for m in re.finditer(r"[\u3040-\u30ff\u4e00-\u9fff]\s+[\u3040-\u30ff\u4e00-\u9fff]", body):
    out.append("CJKSPACE: " + repr(body[max(0, m.start() - 70):m.end() + 70].replace("\n", " ")))

with open("_map_md_probe_out.txt", "w", encoding="utf-8") as fh:
    fh.write("\n".join(out) + "\n")
print("done", len(out))
