#!/usr/bin/env python3
"""A6: 冗長性の予算 — 幅の広い順に k 個を ReLU² にして、どこで壊れるか。

曲線を作る点
  k=0  all_relu        （A4）
  k=1  deg_e6 / deg_e7 （A5 の予備測定、4 seed）
  k=2  large_relu2     （A4）
  k=4  wide4           （本走）
  k=6  wide6           （本走）
  k=8  all_relu2       （A4）

各点で「FFN 幅のうち厳密ゼロ疎になる割合」を出し、品質コストと並べる。
品質コストが MDE を超える最初の k が**冗長性の予算**である。
"""
import argparse
import json
import math
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
D = os.path.join(HERE, "data", "a4")


def load(fn):
    p = os.path.join(D, fn)
    if not os.path.exists(p):
        return []
    with open(p, encoding="utf-8") as fh:
        return [r for r in json.load(fh) if "evals" in r]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", default="a6_budget.json")
    args = ap.parse_args()

    base_rows = load("a4_results.json")
    probe = load("a4_results_p.json")
    wide = load("a4_results_w.json")

    base = [r for r in base_rows if r["arm"] == "all_relu"]
    W = base[0]["widths"]
    TOT = sum(W)
    order = sorted(range(len(W)), key=lambda i: -W[i])

    # (k, ラベル, 行, 劣化する expert 集合)
    pts = []
    pts.append((0, "all_relu", base, []))
    for i in (order[0], order[1]):
        rows = [r for r in probe if r["arm"] == f"deg_e{i}"]
        if rows:
            pts.append((1, f"deg_e{i}", rows, [i]))
    for k, arm in ((2, "large_relu2"), (4, "wide4"), (6, "wide6"), (8, "all_relu2")):
        rows = [r for r in (wide if arm.startswith("wide") else base_rows) if r["arm"] == arm]
        if rows:
            pts.append((k, arm, rows, order[:k]))
    # 対照: 小に置く（A4）
    sm = [r for r in base_rows if r["arm"] == "small_relu2"]
    if sm:
        pts.append((2, "small_relu2", sm, [0, 1]))

    print("=== 1. 予算曲線 ===")
    print(f"  {'k':>2s}{'arm':12s}{'劣化 expert':>22s}{'幅シェア':>9s}"
          f"{'CE':>9s}{'instr':>8s}{'Δinstr':>9s}{'p':>8s}{'MDE':>7s}")
    out = []
    for k, arm, rows, idx in pts:
        seeds = sorted({r["seed"] for r in rows} & {r["seed"] for r in base})
        # **seed で整列して対応させる**（json の並びは完了順で seed 順ではない）
        m_iv = {r["seed"]: r["evals"][-1]["instr_valid"] for r in rows}
        m_ce = {r["seed"]: r["evals"][-1]["ce_all"] for r in rows}
        b_iv_m = {r["seed"]: r["evals"][-1]["instr_valid"] for r in base}
        iv = np.array([m_iv[s] for s in seeds])
        ce = np.array([m_ce[s] for s in seeds])
        b_iv = np.array([b_iv_m[s] for s in seeds])
        d = iv - b_iv
        se = d.std(ddof=1) / math.sqrt(len(d)) if len(d) > 1 else float("nan")
        t, p = stats.ttest_rel(iv, b_iv) if len(d) > 2 else (float("nan"), float("nan"))
        mde = ((stats.t.ppf(0.975, len(d) - 1) + stats.t.ppf(0.80, len(d) - 1)) * se
               if len(d) > 1 else float("nan"))
        wshare = sum(W[i] for i in idx) / TOT
        out.append(dict(k=k, arm=arm, idx=idx, wshare=float(wshare), n=len(seeds),
                        ce=float(ce.mean()), iv=float(iv.mean()),
                        div=float(d.mean()), t=float(t), p=float(p), mde=float(mde)))
        print(f"  {k:>2d}{arm:12s}{str(idx):>22s}{wshare:>9.3f}"
              f"{ce.mean():>9.4f}{iv.mean():>8.3f}{d.mean():>+9.3f}"
              f"{p:>8.4f}{mde:>7.3f}")

    print("\n=== 2. 予算の判定（品質コストが MDE を超えた最初の点）===")
    budget = None
    for r in sorted(out, key=lambda x: x["wshare"]):
        if r["k"] == 0 or not np.isfinite(r["mde"]):
            continue
        sig = (r["p"] < 0.05) or (abs(r["div"]) > 2 * r["mde"])
        mark = "  ← ここで破れる" if sig and budget is None else ""
        if sig and budget is None:
            budget = r
        print(f"  k={r['k']} ({r['arm']}, 幅 {r['wshare']*100:.1f}%) "
              f"Δinstr={r['div']:+.3f} p={r['p']:.3f} MDE={r['mde']:.3f} "
              f"{'×' if sig else '○ 無料'}{mark}")
    if budget:
        print(f"\n  → 予算は **幅の {budget['wshare']*100:.1f}% まで**"
              f"（k={budget['k']} で破れる）")
    else:
        print("\n  → 測った範囲（幅 93.8% まで）では破れなかった")

    print("\n=== 3. 効率: 幅 10% あたりの品質コスト ===")
    for r in sorted(out, key=lambda x: x["wshare"]):
        if r["k"] == 0 or r["wshare"] == 0:
            continue
        print(f"  {r['arm']:12s} 幅 {r['wshare']*100:>5.1f}%  "
              f"Δinstr/10% = {r['div']/(r['wshare']*10):+.3f}")

    with open(os.path.join(D, args.json), "w", encoding="utf-8") as fh:
        json.dump({"points": out, "widths": W, "total_width": TOT}, fh,
                  ensure_ascii=False, indent=2)
    print(f"\n[write] {os.path.join(D, args.json)}")


if __name__ == "__main__":
    main()
