# -*- coding: utf-8 -*-
"""P22 解析: 思考中の数字を span から除くと何が変わるか

比較する 2 つの抽出規則（同一 80 サンプル）:
  whole  : 全文の最後の数字列（P20 の規則）
  region : ``</think>`` 以降の最後の数字列。``</think>`` が無ければ「答えなし」

見るもの:
  答えあり率 / 答えあり中の正解率 / 全問題での正解率（答えなしを誤りと数える）
  ペア単位の被覆・多数決・confmax・oracle
  p_ans の判別力（全文基準 vs 答え領域基準）
出力: p22_analysis.json / p22_analysis_out_utf8.txt
"""
import json
import os
from collections import Counter

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = []


def log(m):
    OUT.append(str(m))
    print(m, flush=True)


def auroc(scores, labels):
    s = np.asarray(scores, float)
    y = np.asarray(labels, bool)
    ok = np.isfinite(s)
    s, y = s[ok], y[ok]
    pos, neg = s[y], s[~y]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    d = (pos[:, None] > neg[None, :]).sum() + 0.5 * (pos[:, None] == neg[None, :]).sum()
    return float(d / (len(pos) * len(neg)))


def maj(vals):
    c = Counter([v for v in vals if v is not None])
    if not c:
        return None
    best = max(c.values())
    for v in vals:
        if v is not None and c[v] == best:
            return v
    return None


def main():
    recs = [json.loads(l) for l in open(os.path.join(HERE, "p22_span.jsonl"),
                                        encoding="utf-8") if l.strip()]
    S = [s for r in recs for s in r["samples"]]
    n = len(S)
    log("samples=%d pairs=%d" % (n, len(recs)))

    # ---- 1. サンプル単位の比較 ----
    w_ans = [s["pred_whole"] for s in S]
    r_ans = [s["pred_ans"] for s in S]
    w_ok = np.array([bool(s["correct_whole"]) for s in S])
    r_ok = np.array([s["correct_ans"] is True for s in S])
    has_end = np.array([s["has_end"] for s in S])
    log("\n[1] サンプル単位（n=%d）" % n)
    log("  答えあり率: whole %.3f / region %.3f" % (np.mean([a is not None for a in w_ans]),
                                                   np.mean([a is not None for a in r_ans])))
    log("  正解率（答えあり中）: whole %.4f / region %.4f"
        % (w_ok.sum() / max(1, sum(a is not None for a in w_ans)),
           r_ok.sum() / max(1, sum(a is not None for a in r_ans))))
    log("  正解率（全サンプル, 答えなし=誤り）: whole %.4f / region %.4f"
        % (w_ok.mean(), r_ok.mean()))
    log("  region で答えが出た %d 本のうち、whole と答えが一致: %d"
        % (int(has_end.sum()),
           int(sum(1 for s in S if s["has_end"] and s["pred_ans"] == s["pred_whole"]))))
    # 差が出たサンプル
    diff = [s for s in S if s["has_end"] and s["pred_ans"] != s["pred_whole"]]
    log("  region と whole で答えが違う: %d 本" % len(diff))
    for s in diff[:5]:
        log("    whole=%s region=%s (正誤 whole=%s region=%s)"
            % (s["pred_whole"], s["pred_ans"], s["correct_whole"], s["correct_ans"]))
    # 思考が閉じた 26 本の内訳
    log("\n  </think> がある %d 本の内訳:" % int(has_end.sum()))
    for lab, m in [("完走", np.array([s["finished"] for s in S]) & has_end),
                   ("打ち切り", ~np.array([s["finished"] for s in S]) & has_end)]:
        if m.sum():
            log("    %-8s n=%-3d 正解率(region)=%.4f" % (lab, int(m.sum()), r_ok[m].mean()))

    # ---- 2. ペア単位 ----
    log("\n[2] ペア単位（%d ペア, N=%d）" % (len(recs), len(recs[0]["samples"])))
    res = {}
    for rule, key_pred, key_ok in [("whole", "pred_whole", "correct_whole"),
                                   ("region", "pred_ans", "correct_ans")]:
        cov, acc_ans, acc_all, s1, orc, sizes = [], [], [], [], [], []
        for r in recs:
            sub = r["samples"]
            ans = [s for s in sub if s[key_pred] is not None]
            sizes.append(len(ans))
            if not ans:
                cov.append(0.0)
                acc_ans.append(np.nan)
                acc_all.append(0.0)
                s1.append(0.0)
                orc.append(0.0)
                continue
            cov.append(1.0)
            mp = maj([s[key_pred] for s in ans])
            ok = float(mp == r["gold"])
            acc_ans.append(ok)
            acc_all.append(ok)
            s1.append(float(sub[0][key_ok] is True))
            orc.append(float(any(s[key_ok] is True for s in ans)))
        res[rule] = {"coverage": float(np.mean(cov)), "mean_pool": float(np.mean(sizes)),
                     "maj_answered": float(np.nanmean(acc_ans)),
                     "maj_all": float(np.mean(acc_all)),
                     "s1": float(np.mean(s1)), "oracle": float(np.mean(orc)),
                     "n_covered": int(sum(cov))}
        log("  %-7s 被覆=%.3f 平均プール=%.2f | 多数決(答えあり中)=%.4f 多数決(全問題)=%.4f | s1=%.4f oracle=%.4f"
            % (rule, res[rule]["coverage"], res[rule]["mean_pool"],
               res[rule]["maj_answered"], res[rule]["maj_all"],
               res[rule]["s1"], res[rule]["oracle"]))

    # confmax（p_ans の argmax）
    log("\n[3] confmax（p_ans の argmax）")
    for rule, key_pred, key_ok, key_p in [
            ("whole", "pred_whole", "correct_whole", "p_ans_whole"),
            ("region", "pred_ans", "correct_ans", "p_ans_region")]:
        accs, confs = [], []
        for r in recs:
            cand = [(j, s) for j, s in enumerate(r["samples"])
                    if s[key_pred] is not None and s[key_p] is not None]
            if not cand:
                continue
            best = max(cand, key=lambda t: (t[1][key_p], -t[0]))[1]
            accs.append(float(best[key_ok] is True))
            confs.append(best[key_p])
        log("  %-7s confmax 正解率=%.4f (n=%d)  AUC=%.3f"
            % (rule, np.mean(accs), len(accs), auroc(confs, accs)))
        res[rule]["confmax"] = float(np.mean(accs))
        res[rule]["confmax_auc"] = auroc(confs, accs)

    # ---- 4. p_ans の判別力（サンプル単位） ----
    log("\n[4] p_ans の判別力（サンプル単位）")
    for lab, key_p, key_ok, mask in [
            ("whole / 全 80", "p_ans_whole", "correct_whole", np.ones(n, bool)),
            ("region / </think> あり 26", "p_ans_region", "correct_ans", has_end)]:
        sc = [S[i][key_p] for i in np.where(mask)[0]]
        y = [S[i][key_ok] is True for i in np.where(mask)[0]]
        log("  %-26s n=%-3d AUC=%.3f (pos=%d)" % (lab, int(mask.sum()), auroc(sc, y),
                                                   int(sum(y))))
    # p_full は P20 の値（全 80）
    log("  %-26s n=%-3d AUC=%.3f" % ("p_full / 全 80",
                                     n, auroc([s["p_full"] for s in S], w_ok)))

    # ---- 5. P20 との対応 ----
    log("\n[5] P20（whole 規則）との対応")
    log("  P20: サンプル正解率 0.3250 / 多数決(all) 0.5500 / pass@4 0.7000 / 被覆 1.000")
    log("  P22 region: サンプル正解率(答えなし=誤り) %.4f / 多数決(全問題) %.4f / 被覆 %.3f"
        % (r_ok.mean(), res["region"]["maj_all"], res["region"]["coverage"]))
    log("  → 「答えなし」を誤りと数えると P20 より悪く見える。**答えあり中の正解率 %.4f** が実力。"
        % res["region"]["maj_answered"])

    out = {"n_samples": n, "n_pairs": len(recs),
           "has_end_rate": float(has_end.mean()),
           "sample_acc_whole": float(w_ok.mean()),
           "sample_acc_region_all": float(r_ok.mean()),
           "sample_acc_region_answered": float(r_ok.sum() / max(1, has_end.sum())),
           "rules": res}
    with open(os.path.join(HERE, "p22_analysis.json"), "w", encoding="utf-8") as fp:
        json.dump(out, fp, ensure_ascii=False, indent=2)
    with open(os.path.join(HERE, "p22_analysis_out_utf8.txt"), "w", encoding="utf-8") as fp:
        fp.write("\n".join(OUT) + "\n")
    log("saved: p22_analysis.json")
    os._exit(0)


if __name__ == "__main__":
    main()
