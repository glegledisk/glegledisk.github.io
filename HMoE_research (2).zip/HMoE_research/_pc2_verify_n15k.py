#!/usr/bin/env python3
"""N=1.5e4（lr 5e-4）の 3 条件を突き合わせる。教師は別 tag なので 2 つの json を結合する。"""
import json
import os

import numpy as np
from scipy import stats

HERE = os.path.dirname(os.path.abspath(__file__))


def load(tags):
    by = {}
    for t in tags:
        p = os.path.join(HERE, "pc2_results_%s.json" % t)
        if not os.path.exists(p):
            print("  [missing] %s" % p)
            continue
        for r in json.load(open(p, encoding="utf-8"))["rows"]:
            by.setdefault(r["cfg"], {})[r["seed"]] = r
    return by


by = load(["n15k_lr5e4", "n15k_lr5e4b"])

print("== 水準（N=1.5e4, lr 5e-4, 10 epoch）==")
for cfg, d in by.items():
    ce = np.array([v["ce"] for v in d.values()])
    acc = np.array([v["acc"] for v in d.values()])
    w = np.array([v["width_mean"] for v in d.values()])
    print("  %-13s n=%d  init %.4f  CE %.4f (sd %.4f)  acc %.4f  幅 %.1f  MACs %d"
          % (cfg, len(d), np.mean([v["ce_init"] for v in d.values()]),
             ce.mean(), ce.std(ddof=1) if len(d) > 1 else float("nan"),
             acc.mean(), w.mean(), d[list(d)[0]]["macs"]))
    for s in sorted(d):
        print("      s%d  CE %.4f  acc %.4f  clip計 %d"
              % (s, d[s]["ce"], d[s]["acc"], d[s]["n_clip"]))

print("\n== 対応差 ==")
for a, b in [("teacher", "half:scratch"), ("teacher", "half:prune"),
             ("half:prune", "half:scratch")]:
    if a not in by or b not in by:
        continue
    ks = sorted(set(by[a]) & set(by[b]))
    x = np.array([by[a][k]["ce"] for k in ks])
    y = np.array([by[b][k]["ce"] for k in ks])
    d = x - y
    if len(d) > 1:
        t, p = stats.ttest_rel(x, y)
        se = d.std(ddof=1) / np.sqrt(len(d))
        print("  %-13s - %-13s ΔCE %+0.4f  se %.4f  t %+0.2f  p %.4f  n %d  負 %d"
              % (a, b, d.mean(), se, t, p, len(d), int((d < 0).sum())))
    else:
        print("  %-13s - %-13s ΔCE %+0.4f  n %d（検定不能）"
              % (a, b, d.mean(), len(d)))

print("\n== 参考: N=3e3 の同条件（10 epoch, lr 2e-3）==")
by3 = load(["n3k"])
for cfg, d in by3.items():
    ce = np.array([v["ce"] for v in d.values()])
    print("  %-13s n=%d  CE %.4f  acc %.4f  幅 %.1f"
          % (cfg, len(d), ce.mean(), np.mean([v["acc"] for v in d.values()]),
             np.mean([v["width_mean"] for v in d.values()])))
