# -*- coding: utf-8 -*-
"""P9: 本数 N のパイロット（ガイド Phase B の B1 / B2 の縮小版）

問い:
  best-of-N は正解率を上げるか。上げたぶん確信度（多数決の得票率）も上がるか。
  ギャップ = 平均得票率 − 正解率 は N で広がるか（N1）。

設定:
  モデル Qwen3-0.6B / thinking off（短く速い）/ 5 桁加算（pass@1 が床でも天井でもない帯を狙う）
  20 問 × 8 サンプル（T=0.9, top_p=0.95）
  選択器: (i) 1 サンプル（pass@1）(ii) 多数決 (iii) oracle（どれか 1 つ正解 = pass@N）

出力: p9_count.jsonl / p9_count.json
"""

import argparse
import json
import os
import random
import re
import time
from collections import Counter

import numpy as np
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
MODEL = os.path.join(HERE, "models", "qwen3-0.6b")
SYS = "You are a careful arithmetic assistant. Solve the problem and give the final answer."


def log(m):
    print(m, flush=True)


def extract(txt):
    nums = re.findall(r"-?\d+", txt.replace(",", ""))
    return nums[-1] if nums else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n_prob", type=int, default=20)
    ap.add_argument("--n_samp", type=int, default=8)
    ap.add_argument("--bs", type=int, default=8)
    ap.add_argument("--seed", type=int, default=31)
    ap.add_argument("--tag", type=str, default="p9")
    args = ap.parse_args()

    from transformers import AutoModelForCausalLM, AutoTokenizer

    tok = AutoTokenizer.from_pretrained(MODEL)
    tok.padding_side = "left"
    if tok.pad_token_id is None:
        tok.pad_token = tok.eos_token
    model = AutoModelForCausalLM.from_pretrained(
        MODEL, torch_dtype=torch.bfloat16, device_map="cuda",
        attn_implementation="sdpa").eval()

    rnd = random.Random(args.seed)
    probs = []
    for _ in range(args.n_prob):
        a, b = rnd.randint(10001, 99999), rnd.randint(10001, 99999)
        probs.append({"q": "Compute %d + %d." % (a, b), "gold": str(a + b)})

    prompts = []
    for p in probs:
        msgs = [{"role": "system", "content": SYS}, {"role": "user", "content": p["q"]}]
        prompts.append(tok.apply_chat_template(msgs, tokenize=False,
                                               add_generation_prompt=True,
                                               enable_thinking=False))

    torch.manual_seed(args.seed)
    log("problems=%d samples=%d" % (len(probs), args.n_samp))
    recs = []
    t0 = time.time()
    for i, p in enumerate(probs):
        outs = []
        for s in range(0, args.n_samp, args.bs):
            k = min(args.bs, args.n_samp - s)
            enc = tok([prompts[i]] * k, return_tensors="pt", padding=True,
                      add_special_tokens=False).to(model.device)
            with torch.no_grad():
                o = model.generate(**enc, max_new_tokens=96, do_sample=True,
                                   temperature=0.9, top_p=0.95,
                                   pad_token_id=tok.pad_token_id)
            new = o[:, enc["input_ids"].shape[1]:]
            for j in range(k):
                txt = tok.decode(new[j], skip_special_tokens=True)
                outs.append({"pred": extract(txt), "tail": txt.strip()[-60:]})
        recs.append({"q": p["q"], "gold": p["gold"], "samples": outs})
    dt = time.time() - t0
    log("generated %d sequences in %.0f s" % (len(recs) * args.n_samp, dt))

    with open(os.path.join(HERE, "%s_count.jsonl" % args.tag), "w", encoding="utf-8") as fp:
        for r in recs:
            fp.write(json.dumps(r, ensure_ascii=False) + "\n")

    # ---- 集計 ----
    log("")
    log("%4s %10s %10s %10s %10s" % ("N", "pass@1", "pass@N", "majority", "vote_share"))
    summary = {}
    for N in (1, 2, 4, 8):
        if N > args.n_samp:
            continue
        p1, pn, maj, shares = [], [], [], []
        for r in recs:
            for rep in range(4):          # サブサンプルを 4 回引いて平均
                sub = r["samples"][:N] if N == args.n_samp else \
                    [r["samples"][j] for j in rnd.sample(range(args.n_samp), N)]
                correct = [s["pred"] == r["gold"] for s in sub]
                p1.append(np.mean(correct))
                pn.append(any(correct))
                votes = Counter([s["pred"] for s in sub if s["pred"] is not None])
                if votes:
                    top, cnt = votes.most_common(1)[0]
                    maj.append(top == r["gold"])
                    shares.append(cnt / N)
                else:
                    maj.append(False)
                    shares.append(0.0)
        log("%4d %10.3f %10.3f %10.3f %10.3f"
            % (N, np.mean(p1), np.mean(pn), np.mean(maj), np.mean(shares)))
        summary["N%d" % N] = {"pass@1": float(np.mean(p1)), "pass@N": float(np.mean(pn)),
                              "majority": float(np.mean(maj)),
                              "vote_share": float(np.mean(shares)),
                              "gap": float(np.mean(shares) - np.mean(maj))}
    with open(os.path.join(HERE, "%s_count.json" % args.tag), "w", encoding="utf-8") as fp:
        json.dump({"n_prob": len(probs), "n_samp": args.n_samp, "summary": summary},
                  fp, ensure_ascii=False, indent=2)
    log("saved: %s_count.jsonl / %s_count.json" % (args.tag, args.tag))


if __name__ == "__main__":
    main()
